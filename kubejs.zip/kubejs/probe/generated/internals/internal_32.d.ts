/// <reference path="./internal_*.d.ts" />
declare namespace vectorwing.farmersdelight.common.item {
    class ConsumableItem extends Internal.Item {
        constructor(properties: Internal.Item$Properties_)
        constructor(properties: Internal.Item$Properties_, hasFoodEffectTooltip: boolean)
        constructor(properties: Internal.Item$Properties_, hasFoodEffectTooltip: boolean, hasCustomTooltip: boolean)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, level: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, isAdvanced: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        affectConsumer(stack: Internal.ItemStack_, level: Internal.Level_, consumer: Internal.LivingEntity_): void;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem(stack: Internal.ItemStack_, level: Internal.Level_, consumer: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type ConsumableItem_ = ConsumableItem;
}
declare namespace Internal {
    class Excluder implements Internal.TypeAdapterFactory, Internal.Cloneable {
        constructor()
        getClass(): typeof any;
        excludeField(arg0: Internal.Field_, arg1: boolean): boolean;
        toString(): string;
        withModifiers(...arg0: number[]): this;
        notifyAll(): void;
        disableInnerClassSerialization(): this;
        create<T>(arg0: Internal.Gson_, arg1: com.google.gson.reflect.TypeToken_<T>): Internal.TypeAdapter<T>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        withVersion(arg0: number): this;
        excludeClass(arg0: typeof any, arg1: boolean): boolean;
        hashCode(): number;
        withExclusionStrategy(arg0: Internal.ExclusionStrategy_, arg1: boolean, arg2: boolean): this;
        wait(): void;
        wait(arg0: number): void;
        excludeFieldsWithoutExposeAnnotation(): this;
        equals(arg0: any): boolean;
        get class(): typeof any
        static readonly DEFAULT: (Internal.Excluder) & (Internal.Excluder);
    }
    type Excluder_ = Excluder;
    interface RegionBasedStorageSectionExtended <R> {
        abstract getInChunkColumn(arg0: number, arg1: number): Internal.Iterable<R>;
        abstract getWithinChunkColumn(arg0: number, arg1: number): Internal.Stream<R>;
    }
    type RegionBasedStorageSectionExtended_<R> = RegionBasedStorageSectionExtended<R>;
    class Markings extends Internal.Enum<Internal.Markings> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        toString(): string;
        getDeclaringClass(): typeof Internal.Markings;
        notifyAll(): void;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.Markings>>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        static valueOf($$0: string): Internal.Markings;
        name(): string;
        hashCode(): number;
        compareTo(arg0: Internal.Markings_): number;
        static byId($$0: number): Internal.Markings;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        static values(): Internal.Markings[];
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        getId(): number;
        "compareTo(net.minecraft.world.entity.animal.horse.Markings)"(arg0: Internal.Markings_): number;
        get class(): typeof any
        get declaringClass(): typeof Internal.Markings
        get id(): number
        static readonly BLACK_DOTS: (Internal.Markings) & (Internal.Markings);
        static readonly WHITE_FIELD: (Internal.Markings) & (Internal.Markings);
        static readonly NONE: (Internal.Markings) & (Internal.Markings);
        static readonly WHITE: (Internal.Markings) & (Internal.Markings);
        static readonly WHITE_DOTS: (Internal.Markings) & (Internal.Markings);
    }
    type Markings_ = "white_field" | "white" | "black_dots" | Markings | "white_dots" | "none";
    class NormalNoise$NoiseParameters extends Internal.Record {
        constructor($$0: number, $$1: Internal.DoubleList_)
        constructor($$0: number, $$1: number, ...$$2: number[])
        constructor($$0: number, $$1: Internal.List_<number>)
        getClass(): typeof any;
        hashCode(): number;
        amplitudes(): Internal.DoubleList;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals($$0: any): boolean;
        notify(): void;
        firstOctave(): number;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        static readonly DIRECT_CODEC: Internal.Codec<Internal.NormalNoise$NoiseParameters>;
        static readonly CODEC: Internal.Codec<Internal.Holder<Internal.NormalNoise$NoiseParameters>>;
    }
    type NormalNoise$NoiseParameters_ = Special.Noise | NormalNoise$NoiseParameters;
    interface HolderGetter <T> {
        abstract "get(net.minecraft.tags.TagKey)"(arg0: Internal.TagKey_<T>): Optional<Internal.HolderSet$Named<T>>;
        abstract get(arg0: Internal.TagKey_<T>): Optional<Internal.HolderSet$Named<T>>;
        "getOrThrow(net.minecraft.resources.ResourceKey)"($$0: Internal.ResourceKey_<T>): Internal.Holder$Reference<T>;
        abstract "get(net.minecraft.resources.ResourceKey)"(arg0: Internal.ResourceKey_<T>): Optional<Internal.Holder$Reference<T>>;
        abstract get(arg0: Internal.ResourceKey_<T>): Optional<Internal.Holder$Reference<T>>;
        "getOrThrow(net.minecraft.tags.TagKey)"($$0: Internal.TagKey_<T>): Internal.HolderSet$Named<T>;
        getOrThrow($$0: Internal.TagKey_<T>): Internal.HolderSet$Named<T>;
        getOrThrow($$0: Internal.ResourceKey_<T>): Internal.Holder$Reference<T>;
    }
    type HolderGetter_<T> = HolderGetter<T>;
    class PlanestridersSashItem extends Internal.SojournersSashItem {
        constructor(props: Internal.Item$Properties_)
        static onPlayerJump(living: Internal.LivingEntity_): void;
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        hasRender(stack: Internal.ItemStack_, living: Internal.LivingEntity_): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, world: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, flags: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        hasPhantomInk(stack: Internal.ItemStack_): boolean;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        canEquip(stack: Internal.ItemStack_, entity: Internal.LivingEntity_): boolean;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        getEquippedAttributeModifiers(stack: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        static tickBelt(player: Internal.Player_): void;
        onWornTick(stack: Internal.ItemStack_, entity: Internal.LivingEntity_): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        static onPlayerFall(entity: Internal.Player_, dist: number): number;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setCosmeticItem(stack: Internal.ItemStack_, cosmetic: Internal.ItemStack_): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        commitPositionAndCompare(stack: Internal.ItemStack_, player: Internal.Player_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        onEquipped(stack: Internal.ItemStack_, entity: Internal.LivingEntity_): void;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getRenderTexture(): ResourceLocation;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        onNotMovingTick(stack: Internal.ItemStack_, player: Internal.Player_): void;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        setPhantomInk(stack: Internal.ItemStack_, ink: boolean): void;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        onUnequipped(stack: Internal.ItemStack_, entity: Internal.LivingEntity_): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        onMovedTick(stack: Internal.ItemStack_, player: Internal.Player_): void;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        static getBaubleUUID(stack: Internal.ItemStack_): Internal.UUID;
        getCosmeticItem(stack: Internal.ItemStack_): Internal.ItemStack;
        equals(arg0: any): boolean;
        getSpeed(stack: Internal.ItemStack_): number;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get renderTexture(): ResourceLocation
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type PlanestridersSashItem_ = PlanestridersSashItem;
    class DummySensor extends Internal.Sensor<Internal.LivingEntity> {
        constructor()
        getClass(): typeof any;
        toString(): string;
        static isEntityTargetable($$0: Internal.LivingEntity_, $$1: Internal.LivingEntity_): boolean;
        notifyAll(): void;
        static isEntityAttackableIgnoringLineOfSight($$0: Internal.LivingEntity_, $$1: Internal.LivingEntity_): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        tick($$0: Internal.ServerLevel_, $$1: Internal.LivingEntity_): void;
        wait(): void;
        getLastSenseTime(): number;
        static isEntityAttackable($$0: Internal.LivingEntity_, $$1: Internal.LivingEntity_): boolean;
        wait(arg0: number): void;
        getSenseInterval(): number;
        setLastSenseTime(arg0: number): void;
        equals(arg0: any): boolean;
        requires(): Internal.Set<Internal.MemoryModuleType<any>>;
        get class(): typeof any
        get lastSenseTime(): number
        get senseInterval(): number
        set lastSenseTime(arg0: number)
    }
    type DummySensor_ = DummySensor;
    class ServerData implements Internal.ServerDataExtension {
        constructor($$0: string, $$1: string, $$2: boolean)
        getClass(): typeof any;
        setResourcePackStatus($$0: Internal.ServerData$ServerPackStatus_): void;
        write(): Internal.CompoundTag;
        setIconBytes($$0: number[]): void;
        toString(): string;
        notifyAll(): void;
        setEnforcesSecureChat($$0: boolean): void;
        notify(): void;
        setBetterData(status: Internal.BetterStatus_): void;
        wait(arg0: number, arg1: number): void;
        getIconBytes(): number[];
        isLan(): boolean;
        hashCode(): number;
        enforcesSecureChat(): boolean;
        wait(): void;
        wait(arg0: number): void;
        static read($$0: Internal.CompoundTag_): Internal.ServerData;
        copyNameIconFrom($$0: Internal.ServerData_): void;
        equals(arg0: any): boolean;
        getResourcePackStatus(): Internal.ServerData$ServerPackStatus;
        copyFrom($$0: Internal.ServerData_): void;
        getBetterData(): Internal.BetterStatus;
        get class(): typeof any
        set resourcePackStatus($$0: Internal.ServerData$ServerPackStatus_)
        set iconBytes($$0: number[])
        set enforcesSecureChat($$0: boolean)
        set betterData(status: Internal.BetterStatus_)
        get iconBytes(): number[]
        get lan(): boolean
        get resourcePackStatus(): Internal.ServerData$ServerPackStatus
        get betterData(): Internal.BetterStatus
        name: string;
        playerList: Internal.List<net.minecraft.network.chat.Component>;
        ip: string;
        players: Internal.ServerStatus$Players;
        ping: number;
        motd: net.minecraft.network.chat.Component;
        betterStatus: Internal.BetterStatus;
        pinged: boolean;
        version: net.minecraft.network.chat.Component;
        status: net.minecraft.network.chat.Component;
        protocol: number;
    }
    type ServerData_ = ServerData;
    class FoodProperties {
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        getEffects(): Internal.List<com.mojang.datafixers.util.Pair<Internal.MobEffectInstance, number>>;
        notify(): void;
        canAlwaysEat(): boolean;
        wait(arg0: number, arg1: number): void;
        getSaturationModifier(): number;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        isFastFood(): boolean;
        getNutrition(): number;
        isMeat(): boolean;
        equals(arg0: any): boolean;
        get class(): typeof any
        get effects(): Internal.List<com.mojang.datafixers.util.Pair<Internal.MobEffectInstance, number>>
        get saturationModifier(): number
        get fastFood(): boolean
        get nutrition(): number
        get meat(): boolean
    }
    type FoodProperties_ = FoodProperties;
    class CauldronBlock extends Internal.AbstractCauldronBlock {
        constructor($$0: Internal.BlockBehaviour$Properties_)
        /**
         * @deprecated
        */
        getOcclusionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        /**
         * @deprecated
        */
        getSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        axiom$customPickBlockStack(): Internal.ItemStack;
        getSoundType($$0: Internal.BlockState_): SoundType;
        /**
         * @deprecated
        */
        getVisualShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        handler$efo000$collective$Block_playerDestroy(level: Internal.Level_, player: Internal.Player_, blockPos: BlockPos_, blockState: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number, $$5: number): void;
        /**
         * @deprecated
        */
        randomTick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: Internal.BlockEntity_): void;
        static canSupportRigidBlock($$0: Internal.BlockGetter_, $$1: BlockPos_): boolean;
        static popResource($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.ItemStack_): void;
        setRandomTickCallback(callback: Internal.Consumer_<any>): void;
        getDescriptionId(): string;
        stepOn($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Entity_): void;
        fallOn($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: BlockPos_, $$3: Internal.Entity_, $$4: number): void;
        getSettings(): Internal.BlockBehaviour$Properties;
        getExplosionResistance(): number;
        asItem(): Internal.Item;
        /**
         * @deprecated
        */
        triggerEvent($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: number, $$4: number): boolean;
        getTypeData(): Internal.CompoundTag;
        setFriction(arg0: number): void;
        /**
         * @deprecated
        */
        getRenderShape($$0: Internal.BlockState_): Internal.RenderShape;
        canCull(): boolean;
        customShapeUpdate(blockState: Internal.CustomBlockState_, levelReader: Internal.LevelReader_, blockPos: BlockPos_): Internal.CustomBlockState;
        getJumpFactor(): number;
        getSpeedFactor(): number;
        static canSupportCenter($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        skipRendering($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getLightBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        playerDestroy($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.BlockEntity_, $$5: Internal.ItemStack_): void;
        shouldAttemptToCull(state: Internal.BlockState_): boolean;
        isPossibleToRespawnInThis($$0: Internal.BlockState_): boolean;
        getCustomStateForPlacement(blockPlaceContext: Internal.BlockPlaceContext_): Internal.CustomBlockState;
        /**
         * @deprecated
        */
        getDirectSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        getProperties(): Internal.BlockBehaviour$Properties;
        playerWillDestroy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Player_): void;
        getClass(): typeof any;
        getMaxVerticalOffset(): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.item.context.BlockPlaceContext)"($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        useShapeForLightOcclusion($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        getDrops($$0: Internal.BlockState_, $$1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getStateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>;
        /**
         * @deprecated
        */
        entityInside($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Entity_): void;
        setBlockBuilder(b: Internal.BlockBuilder_): void;
        handler$ldb000$puzzleslib$playerDestroy$0(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        setRequiresTool(v: boolean): void;
        setSpeedFactor(arg0: number): void;
        axiom$getPossibleCustomStates(): Internal.List<any>;
        setExplosionResistance(arg0: number): void;
        toString(): string;
        port_lib$popExperience(arg0: Internal.ServerLevel_, arg1: BlockPos_, arg2: number): void;
        notifyAll(): void;
        getToolModifiedState(state: Internal.BlockState_, world: Internal.Level_, pos: BlockPos_, player: Internal.Player_, stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): Internal.BlockState;
        getId(): string;
        getLootTable(): ResourceLocation;
        puzzleslib$setItem(arg0: Internal.Item_): void;
        getInteractionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        axiom$translationKey(): string;
        propagatesSkylightDown($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        setPlacedBy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.LivingEntity_, $$4: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        onPlace($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Block>;
        static popResourceFromFace($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.ItemStack_): void;
        getFriction(): number;
        handlePrecipitation($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Biome$Precipitation_): void;
        hasAnalogOutputSignal($$0: Internal.BlockState_): boolean;
        wait(arg0: number): void;
        /**
         * @deprecated
        */
        getFluidState($$0: Internal.BlockState_): Internal.FluidState;
        handler$koh000$porting_lib_entity$getDestroySpeed(blockState: Internal.BlockState_, player: Internal.Player_, blockGetter: Internal.BlockGetter_, pos: BlockPos_, cir: Internal.CallbackInfoReturnable_<any>): void;
        /**
         * @deprecated
        */
        getAnalogOutputSignal($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): number;
        handler$efo000$collective$Block_setPlacedBy(level: Internal.Level_, blockPos: BlockPos_, blockState: Internal.BlockState_, livingEntity: Internal.LivingEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        tick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        supportsExternalFaceHiding(state: Internal.BlockState_): boolean;
        handler$ldb000$puzzleslib$playerDestroy$1(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        notify(): void;
        axiom$asItemStack(): Internal.ItemStack;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        neighborChanged($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Block_, $$4: BlockPos_, $$5: boolean): void;
        handler$zhd000$additionalentityattributes$additionalEntityAttributes$saveBreakingPlayer(world: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, stack: Internal.ItemStack_, callbackInfo: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        getBlockSupportShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        canSustainPlant(state: Internal.BlockState_, world: Internal.BlockGetter_, pos: BlockPos_, facing: Internal.Direction_, plantable: Internal.IPlantable_): boolean;
        /**
         * @deprecated
        */
        isCollisionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static isFaceFull($$0: Internal.VoxelShape_, $$1: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getMenuProvider($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): Internal.MenuProvider;
        static byItem($$0: Internal.Item_): Internal.Block;
        static updateFromNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        updateIndirectNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: number, $$4: number): void;
        destroy($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): void;
        handler$fdc000$everycomp$addSimpleFastECdrops(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, cir: Internal.CallbackInfoReturnable_<any>, resId: ResourceLocation_, lootParams: Internal.LootParams_, serverLevel: Internal.ServerLevel_, lootTable: Internal.LootTable_): void;
        getToolModifiedState(state: Internal.BlockState_, context: Internal.UseOnContext_, toolAction: Internal.ToolAction_, simulate: boolean): Internal.BlockState;
        use($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_, $$4: Internal.InteractionHand_, $$5: Internal.BlockHitResult_): Internal.InteractionResult;
        setLightEmission(v: number): void;
        doNormalInteractions(): boolean;
        setJumpFactor(arg0: number): void;
        /**
         * @deprecated
        */
        canSurvive($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        isFull($$0: Internal.BlockState_): boolean;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): void;
        /**
         * @deprecated
        */
        getShadeBrightness($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        getAppearance(state: Internal.BlockState_, renderView: Internal.BlockAndTintGetter_, pos: BlockPos_, side: Internal.Direction_, sourceState: Internal.BlockState_, sourcePos: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        getCollisionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        setDestroySpeed(v: number): void;
        defaultBlockState(): Internal.BlockState;
        usesCustomShouldDrawFace(state: Internal.BlockState_): boolean;
        getStateForPlacement($$0: Internal.BlockPlaceContext_): Internal.BlockState;
        cantCullAgainst(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        arch$holder(): Internal.Holder<Internal.Block>;
        wait(): void;
        getCloneItemStack($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        hasDynamicShape(): boolean;
        getMaxHorizontalOffset(): number;
        /**
         * @deprecated
        */
        getDestroyProgress($$0: Internal.BlockState_, $$1: Internal.Player_, $$2: Internal.BlockGetter_, $$3: BlockPos_): number;
        /**
         * @deprecated
        */
        getSeed($$0: Internal.BlockState_, $$1: BlockPos_): number;
        defaultDestroyTime(): number;
        dropFromExplosion($$0: Internal.Explosion_): boolean;
        /**
         * @deprecated
        */
        updateShape($$0: Internal.BlockState_, $$1: Internal.Direction_, $$2: Internal.BlockState_, $$3: Internal.LevelAccessor_, $$4: BlockPos_, $$5: BlockPos_): Internal.BlockState;
        isRandomlyTicking($$0: Internal.BlockState_): boolean;
        static isShapeFullBlock(shape: Internal.VoxelShape_): boolean;
        withPropertiesOf($$0: Internal.BlockState_): Internal.BlockState;
        static isExceptionForConnection($$0: Internal.BlockState_): boolean;
        setIsRandomlyTicking(arg0: boolean): void;
        hidesNeighborFace(level: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, neighborState: Internal.BlockState_, dir: Internal.Direction_): boolean;
        onTreeGrow(state: Internal.BlockState_, level: Internal.LevelReader_, placeFunction: Internal.BiConsumer_<BlockPos, Internal.BlockState>, randomSource: Internal.RandomSource_, pos: BlockPos_, config: Internal.TreeConfiguration_): boolean;
        /**
         * @deprecated
        */
        rotate($$0: Internal.BlockState_, $$1: Internal.Rotation_): Internal.BlockState;
        defaultMapColor(): Internal.MapColor;
        getStateAtViewpoint(state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_, viewpoint: Vec3d_): Internal.BlockState;
        wait(arg0: number, arg1: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.BlockGetter_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        setNameKey(arg0: string): void;
        static box($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): Internal.VoxelShape;
        /**
         * @deprecated
        */
        mirror($$0: Internal.BlockState_, $$1: Internal.Mirror_): Internal.BlockState;
        wasExploded($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Explosion_): void;
        getName(): Internal.MutableComponent;
        updateEntityAfterFallOn($$0: Internal.BlockGetter_, $$1: Internal.Entity_): void;
        animateTick($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        customShouldDrawFace(view: Internal.BlockGetter_, thisState: Internal.BlockState_, sideState: Internal.BlockState_, thisPos: BlockPos_, sidePos: BlockPos_, side: Internal.Direction_): Optional<boolean>;
        axiom$getResourceLocation(): ResourceLocation;
        arch$registryName(): ResourceLocation;
        axiom$getProperties(): Internal.Collection<any>;
        getBlockBuilder(): Internal.BlockBuilder;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        isSignalSource($$0: Internal.BlockState_): boolean;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number): void;
        /**
         * @deprecated
        */
        attack($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): void;
        getShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        shouldAttemptToCull(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        onProjectileHit($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockHitResult_, $$3: Internal.Projectile_): void;
        static stateById($$0: number): Internal.BlockState;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): Internal.List<Internal.ItemStack>;
        requiredFeatures(): Internal.FeatureFlagSet;
        hashCode(): number;
        axiom$defaultCustomState(): Internal.CustomBlockState;
        setCanCull(canCull: boolean): void;
        /**
         * @deprecated
        */
        isOcclusionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static getId($$0: Internal.BlockState_): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.material.Fluid)"($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        static pushEntitiesUp($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): Internal.BlockState;
        isPathfindable($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.PathComputationType_): boolean;
        setSoundType(arg0: SoundType_): void;
        handler$cef000$betterend$be_getDroppedStacks(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, info: Internal.CallbackInfoReturnable_<any>): void;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_): Internal.List<Internal.ItemStack>;
        /**
         * @deprecated
        */
        onRemove($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        cantCullAgainst(state: Internal.BlockState_): boolean;
        setHasCollision(arg0: boolean): void;
        static shouldRenderFace($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_, $$4: BlockPos_): boolean;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        spawnAfterBreak($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.ItemStack_, $$4: boolean): void;
        set randomTickCallback(callback: Internal.Consumer_<any>)
        get descriptionId(): string
        get settings(): Internal.BlockBehaviour$Properties
        get explosionResistance(): number
        get typeData(): Internal.CompoundTag
        set friction(arg0: number)
        get jumpFactor(): number
        get speedFactor(): number
        get properties(): Internal.BlockBehaviour$Properties
        get class(): typeof any
        get maxVerticalOffset(): number
        get stateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>
        set blockBuilder(b: Internal.BlockBuilder_)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        set speedFactor(arg0: number)
        set explosionResistance(arg0: number)
        get id(): string
        get lootTable(): ResourceLocation
        get friction(): number
        set lightEmission(v: number)
        set jumpFactor(arg0: number)
        set destroySpeed(v: number)
        get maxHorizontalOffset(): number
        set isRandomlyTicking(arg0: boolean)
        set nameKey(arg0: string)
        get name(): Internal.MutableComponent
        get blockBuilder(): Internal.BlockBuilder
        get idLocation(): ResourceLocation
        get mod(): string
        set canCull(canCull: boolean)
        set soundType(arg0: SoundType_)
        set hasCollision(arg0: boolean)
    }
    type CauldronBlock_ = CauldronBlock;
    class ChatType$Bound extends Internal.Record {
        constructor($$0: Internal.ChatType_, $$1: net.minecraft.network.chat.Component_, $$2: net.minecraft.network.chat.Component_)
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        decorate($$0: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        withTargetName($$0: net.minecraft.network.chat.Component_): this;
        chatType(): Internal.ChatType;
        toNetwork($$0: Internal.RegistryAccess_): Internal.ChatType$BoundNetwork;
        hashCode(): number;
        decorateNarration($$0: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        wait(): void;
        wait(arg0: number): void;
        name(): net.minecraft.network.chat.Component;
        equals($$0: any): boolean;
        targetName(): net.minecraft.network.chat.Component;
        get class(): typeof any
    }
    type ChatType$Bound_ = ChatType$Bound;
    interface ToIntFunction <T> {
        abstract applyAsInt(arg0: T): number;
        (arg0: T): number;
    }
    type ToIntFunction_<T> = ToIntFunction<T> | ((arg0: T)=> number);
    class BlendMode {
        constructor()
        constructor($$0: number, $$1: number, $$2: number)
        constructor($$0: number, $$1: number, $$2: number, $$3: number, $$4: number)
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        static stringToBlendFactor($$0: string): number;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        apply(): void;
        hashCode(): number;
        isOpaque(): boolean;
        wait(): void;
        wait(arg0: number): void;
        equals($$0: any): boolean;
        static stringToBlendFunc($$0: string): number;
        get class(): typeof any
        get opaque(): boolean
    }
    type BlendMode_ = BlendMode;
    class RewardTable extends Internal.QuestObjectBase {
        constructor(id: number, file: Internal.BaseQuestFile_, filename: string)
        constructor(id: number, file: Internal.BaseQuestFile_)
        writeData(nbt: Internal.CompoundTag_): void;
        getMutableTitle(): Internal.MutableComponent;
        getTitleOrElse(def: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        readData(nbt: Internal.CompoundTag_): void;
        editedFromGUI(): void;
        notify(): void;
        compareTo(arg0: any): number;
        clearCachedData(): void;
        getRawTitle(): string;
        static isNull(object: Internal.QuestObjectBase_): boolean;
        deleteSelf(): void;
        makeWeightedItemReward(stack: Internal.ItemStack_, weight: number): Internal.WeightedReward;
        componentsToRefresh(): Internal.Set<Internal.RecipeModHelper$Components>;
        static getID(object: Internal.QuestObjectBase_): number;
        removeReward(weightedReward: Internal.WeightedReward_): void;
        isValid(): boolean;
        static parseCodeString(id: string): number;
        deleteChildren(): void;
        getTags(): Internal.Set<string>;
        forceProgress(teamData: Internal.TeamData_, progressChange: Internal.ProgressChange_): void;
        static "getCodeString(dev.ftb.mods.ftbquests.quest.QuestObjectBase)"(object: Internal.QuestObjectBase_): string;
        addMouseOverText(list: Internal.TooltipList_, includeWeight: boolean, includeEmpty: boolean): void;
        wait(): void;
        getTitle(): net.minecraft.network.chat.Component;
        setRawIcon(rawIcon: Internal.ItemStack_): void;
        static shouldSendNotifications(): boolean;
        "compareTo(java.lang.Object)"(arg0: any): number;
        getAltIcon(): Internal.Icon;
        onEditButtonClicked(gui: Internal.Runnable_): void;
        static titleToID(s: string): Optional<string>;
        getClass(): typeof any;
        static getCodeString(object: Internal.QuestObjectBase_): string;
        getCodeString(): string;
        static copy<T extends Internal.QuestObjectBase>(orig: T, factory: Internal.Supplier_<T>): T;
        static getCodeString(id: number): string;
        getLootCrate(): Internal.LootCrate;
        addReward(weightedReward: Internal.WeightedReward_): void;
        createSubGroup(group: Internal.ConfigGroup_): Internal.ConfigGroup;
        getParentID(): number;
        wait(arg0: number, arg1: number): void;
        fillConfigGroup(config: Internal.ConfigGroup_): void;
        getFakeQuest(): Internal.Quest;
        getWeightedRewards(): Internal.List<Internal.WeightedReward>;
        toggleLootCrate(): Internal.LootCrate;
        getIcon(): Internal.Icon;
        getFilename(): string;
        getAltTitle(): net.minecraft.network.chat.Component;
        static "getCodeString(long)"(id: number): string;
        generateWeightedRandomRewards(random: Internal.RandomSource_, nAttempts: number, includeEmpty: boolean): Internal.Collection<Internal.WeightedReward>;
        "compareTo(dev.ftb.mods.ftbquests.quest.QuestObjectBase)"(other: Internal.QuestObjectBase_): number;
        readNetData(buffer: Internal.FriendlyByteBuf_): void;
        hasTag(tag: string): boolean;
        compareTo(other: Internal.QuestObjectBase_): number;
        setRawTitle(rawTitle: string): void;
        toString(): string;
        getFile(): Internal.BaseQuestFile;
        getQuestChapter(): Internal.Chapter;
        notifyAll(): void;
        getQuestFile(): Internal.BaseQuestFile;
        getObjectType(): Internal.QuestObjectType;
        forceProgressRaw(teamData: Internal.TeamData_, progressChange: Internal.ProgressChange_): void;
        static parseHexId(id: string): Optional<number>;
        hashCode(): number;
        getPath(): Optional<string>;
        shouldShowTooltip(): boolean;
        writeNetData(buffer: Internal.FriendlyByteBuf_): void;
        editedFromGUIOnServer(): void;
        onCreated(): void;
        wait(arg0: number): void;
        getTotalWeight(includeEmpty: boolean): number;
        equals(object: any): boolean;
        get mutableTitle(): Internal.MutableComponent
        get rawTitle(): string
        get valid(): boolean
        get tags(): Internal.Set<string>
        get title(): net.minecraft.network.chat.Component
        set rawIcon(rawIcon: Internal.ItemStack_)
        get altIcon(): Internal.Icon
        get class(): typeof any
        get codeString(): string
        get lootCrate(): Internal.LootCrate
        get parentID(): number
        get fakeQuest(): Internal.Quest
        get weightedRewards(): Internal.List<Internal.WeightedReward>
        get icon(): Internal.Icon
        get filename(): string
        get altTitle(): net.minecraft.network.chat.Component
        set rawTitle(rawTitle: string)
        get file(): Internal.BaseQuestFile
        get questChapter(): Internal.Chapter
        get questFile(): Internal.BaseQuestFile
        get objectType(): Internal.QuestObjectType
        get path(): Optional<string>
    }
    type RewardTable_ = RewardTable;
    class SpireFeature extends Internal.DefaultFeature {
        constructor()
        static getPosOnSurfaceWG(world: Internal.WorldGenLevel_, pos: BlockPos_): BlockPos;
        getClass(): typeof any;
        static getPosOnSurface(world: Internal.WorldGenLevel_, pos: BlockPos_): BlockPos;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        place($$0: Internal.NoneFeatureConfiguration_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        static getPosOnSurfaceRaycast(world: Internal.WorldGenLevel_, pos: BlockPos_): BlockPos;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        place(featureConfig: Internal.FeaturePlaceContext_<Internal.NoneFeatureConfiguration>): boolean;
        static getYOnSurfaceWG(world: Internal.WorldGenLevel_, x: number, z: number): number;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        static getPosOnSurfaceRaycast(world: Internal.WorldGenLevel_, pos: BlockPos_, dist: number): BlockPos;
        wait(): void;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.NoneFeatureConfiguration, Feature<Internal.NoneFeatureConfiguration>>>;
        static getYOnSurface(world: Internal.WorldGenLevel_, x: number, z: number): number;
        get class(): typeof any
    }
    type SpireFeature_ = SpireFeature;
    class LerpingBossEvent extends Internal.BossEvent {
        constructor($$0: Internal.UUID_, $$1: net.minecraft.network.chat.Component_, $$2: number, $$3: Internal.BossEvent$BossBarColor_, $$4: Internal.BossEvent$BossBarOverlay_, $$5: boolean, $$6: boolean, $$7: boolean)
        shouldCreateWorldFog(): boolean;
        getColor(): Internal.BossEvent$BossBarColor;
        setCreateWorldFog($$0: boolean): Internal.BossEvent;
        getClass(): typeof any;
        getProgress(): number;
        setPlayBossMusic($$0: boolean): Internal.BossEvent;
        getName(): net.minecraft.network.chat.Component;
        toString(): string;
        getOverlay(): Internal.BossEvent$BossBarOverlay;
        setOverlay($$0: Internal.BossEvent$BossBarOverlay_): void;
        notifyAll(): void;
        setColor($$0: Internal.BossEvent$BossBarColor_): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        setProgress($$0: number): void;
        setDarkenScreen($$0: boolean): Internal.BossEvent;
        setName($$0: net.minecraft.network.chat.Component_): void;
        shouldPlayBossMusic(): boolean;
        wait(): void;
        getId(): Internal.UUID;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        shouldDarkenScreen(): boolean;
        get color(): Internal.BossEvent$BossBarColor
        set createWorldFog($$0: boolean)
        get class(): typeof any
        get progress(): number
        set playBossMusic($$0: boolean)
        get name(): net.minecraft.network.chat.Component
        get overlay(): Internal.BossEvent$BossBarOverlay
        set overlay($$0: Internal.BossEvent$BossBarOverlay_)
        set color($$0: Internal.BossEvent$BossBarColor_)
        set progress($$0: number)
        set darkenScreen($$0: boolean)
        set name($$0: net.minecraft.network.chat.Component_)
        get id(): Internal.UUID
    }
    type LerpingBossEvent_ = LerpingBossEvent;
    interface IProgressStyle {
        abstract vertical(arg0: boolean): this;
        abstract textColor(arg0: number): this;
        color(color: number): this;
        abstract render(arg0: Internal.GuiGraphics_, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: net.minecraft.network.chat.Component_): void;
        abstract overlay(arg0: Internal.IElement_): this;
        abstract color(arg0: number, arg1: number): this;
    }
    type IProgressStyle_ = IProgressStyle;
    class LakeFeature$Configuration extends Internal.Record implements Internal.FeatureConfiguration {
        constructor($$0: Internal.BlockStateProvider_, $$1: Internal.BlockStateProvider_)
        getClass(): typeof any;
        hashCode(): number;
        getFeatures(): Internal.Stream<Internal.ConfiguredFeature<any, any>>;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        barrier(): Internal.BlockStateProvider;
        fluid(): Internal.BlockStateProvider;
        equals($$0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        get features(): Internal.Stream<Internal.ConfiguredFeature<any, any>>
        static readonly CODEC: Internal.Codec<Internal.LakeFeature$Configuration>;
    }
    type LakeFeature$Configuration_ = LakeFeature$Configuration;
    class ConduitBlock extends Internal.BaseEntityBlock implements Internal.SimpleWaterloggedBlock {
        constructor($$0: Internal.BlockBehaviour$Properties_)
        /**
         * @deprecated
        */
        getOcclusionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        /**
         * @deprecated
        */
        getSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getPickupSound(): Optional<Internal.SoundEvent>;
        axiom$customPickBlockStack(): Internal.ItemStack;
        getSoundType($$0: Internal.BlockState_): SoundType;
        /**
         * @deprecated
        */
        getVisualShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        handler$efo000$collective$Block_playerDestroy(level: Internal.Level_, player: Internal.Player_, blockPos: BlockPos_, blockState: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number, $$5: number): void;
        /**
         * @deprecated
        */
        randomTick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: Internal.BlockEntity_): void;
        static canSupportRigidBlock($$0: Internal.BlockGetter_, $$1: BlockPos_): boolean;
        static popResource($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.ItemStack_): void;
        setRandomTickCallback(callback: Internal.Consumer_<any>): void;
        getDescriptionId(): string;
        stepOn($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Entity_): void;
        fallOn($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: BlockPos_, $$3: Internal.Entity_, $$4: number): void;
        getSettings(): Internal.BlockBehaviour$Properties;
        triggerEvent($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: number, $$4: number): boolean;
        getExplosionResistance(): number;
        asItem(): Internal.Item;
        getTypeData(): Internal.CompoundTag;
        setFriction(arg0: number): void;
        getRenderShape($$0: Internal.BlockState_): Internal.RenderShape;
        canCull(): boolean;
        customShapeUpdate(blockState: Internal.CustomBlockState_, levelReader: Internal.LevelReader_, blockPos: BlockPos_): Internal.CustomBlockState;
        getJumpFactor(): number;
        getSpeedFactor(): number;
        static canSupportCenter($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        skipRendering($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getLightBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        playerDestroy($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.BlockEntity_, $$5: Internal.ItemStack_): void;
        shouldAttemptToCull(state: Internal.BlockState_): boolean;
        isPossibleToRespawnInThis($$0: Internal.BlockState_): boolean;
        getCustomStateForPlacement(blockPlaceContext: Internal.BlockPlaceContext_): Internal.CustomBlockState;
        /**
         * @deprecated
        */
        getDirectSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        getProperties(): Internal.BlockBehaviour$Properties;
        playerWillDestroy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Player_): void;
        getClass(): typeof any;
        getMaxVerticalOffset(): number;
        newBlockEntity($$0: BlockPos_, $$1: Internal.BlockState_): Internal.BlockEntity;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.item.context.BlockPlaceContext)"($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        useShapeForLightOcclusion($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        getDrops($$0: Internal.BlockState_, $$1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getStateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>;
        pickupBlock($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        /**
         * @deprecated
        */
        entityInside($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Entity_): void;
        setBlockBuilder(b: Internal.BlockBuilder_): void;
        handler$ldb000$puzzleslib$playerDestroy$0(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        setRequiresTool(v: boolean): void;
        setSpeedFactor(arg0: number): void;
        axiom$getPossibleCustomStates(): Internal.List<any>;
        setExplosionResistance(arg0: number): void;
        toString(): string;
        port_lib$popExperience(arg0: Internal.ServerLevel_, arg1: BlockPos_, arg2: number): void;
        notifyAll(): void;
        getToolModifiedState(state: Internal.BlockState_, world: Internal.Level_, pos: BlockPos_, player: Internal.Player_, stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): Internal.BlockState;
        getId(): string;
        getLootTable(): ResourceLocation;
        puzzleslib$setItem(arg0: Internal.Item_): void;
        axiom$translationKey(): string;
        /**
         * @deprecated
        */
        getInteractionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        setPlacedBy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.LivingEntity_, $$4: Internal.ItemStack_): void;
        propagatesSkylightDown($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        /**
         * @deprecated
        */
        onPlace($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Block>;
        static popResourceFromFace($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.ItemStack_): void;
        getFriction(): number;
        handlePrecipitation($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Biome$Precipitation_): void;
        /**
         * @deprecated
        */
        hasAnalogOutputSignal($$0: Internal.BlockState_): boolean;
        wait(arg0: number): void;
        getFluidState($$0: Internal.BlockState_): Internal.FluidState;
        handler$koh000$porting_lib_entity$getDestroySpeed(blockState: Internal.BlockState_, player: Internal.Player_, blockGetter: Internal.BlockGetter_, pos: BlockPos_, cir: Internal.CallbackInfoReturnable_<any>): void;
        /**
         * @deprecated
        */
        getAnalogOutputSignal($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): number;
        handler$efo000$collective$Block_setPlacedBy(level: Internal.Level_, blockPos: BlockPos_, blockState: Internal.BlockState_, livingEntity: Internal.LivingEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        tick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        supportsExternalFaceHiding(state: Internal.BlockState_): boolean;
        handler$ldb000$puzzleslib$playerDestroy$1(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        notify(): void;
        axiom$asItemStack(): Internal.ItemStack;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        neighborChanged($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Block_, $$4: BlockPos_, $$5: boolean): void;
        handler$zhd000$additionalentityattributes$additionalEntityAttributes$saveBreakingPlayer(world: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, stack: Internal.ItemStack_, callbackInfo: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        getBlockSupportShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        canSustainPlant(state: Internal.BlockState_, world: Internal.BlockGetter_, pos: BlockPos_, facing: Internal.Direction_, plantable: Internal.IPlantable_): boolean;
        /**
         * @deprecated
        */
        isCollisionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static isFaceFull($$0: Internal.VoxelShape_, $$1: Internal.Direction_): boolean;
        getTicker<T extends Internal.BlockEntity>($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockEntityType_<T>): Internal.BlockEntityTicker<T>;
        getMenuProvider($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): Internal.MenuProvider;
        static byItem($$0: Internal.Item_): Internal.Block;
        static updateFromNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        updateIndirectNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: number, $$4: number): void;
        destroy($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): void;
        handler$fdc000$everycomp$addSimpleFastECdrops(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, cir: Internal.CallbackInfoReturnable_<any>, resId: ResourceLocation_, lootParams: Internal.LootParams_, serverLevel: Internal.ServerLevel_, lootTable: Internal.LootTable_): void;
        getToolModifiedState(state: Internal.BlockState_, context: Internal.UseOnContext_, toolAction: Internal.ToolAction_, simulate: boolean): Internal.BlockState;
        /**
         * @deprecated
        */
        use($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_, $$4: Internal.InteractionHand_, $$5: Internal.BlockHitResult_): Internal.InteractionResult;
        setLightEmission(v: number): void;
        doNormalInteractions(): boolean;
        setJumpFactor(arg0: number): void;
        /**
         * @deprecated
        */
        canSurvive($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): void;
        /**
         * @deprecated
        */
        getShadeBrightness($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        getAppearance(state: Internal.BlockState_, renderView: Internal.BlockAndTintGetter_, pos: BlockPos_, side: Internal.Direction_, sourceState: Internal.BlockState_, sourcePos: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        getCollisionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        setDestroySpeed(v: number): void;
        defaultBlockState(): Internal.BlockState;
        usesCustomShouldDrawFace(state: Internal.BlockState_): boolean;
        getStateForPlacement($$0: Internal.BlockPlaceContext_): Internal.BlockState;
        cantCullAgainst(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        placeLiquid($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.FluidState_): boolean;
        getListener<T extends Internal.BlockEntity>($$0: Internal.ServerLevel_, $$1: T): Internal.GameEventListener;
        arch$holder(): Internal.Holder<Internal.Block>;
        wait(): void;
        getCloneItemStack($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        hasDynamicShape(): boolean;
        getMaxHorizontalOffset(): number;
        /**
         * @deprecated
        */
        getDestroyProgress($$0: Internal.BlockState_, $$1: Internal.Player_, $$2: Internal.BlockGetter_, $$3: BlockPos_): number;
        /**
         * @deprecated
        */
        getSeed($$0: Internal.BlockState_, $$1: BlockPos_): number;
        defaultDestroyTime(): number;
        updateShape($$0: Internal.BlockState_, $$1: Internal.Direction_, $$2: Internal.BlockState_, $$3: Internal.LevelAccessor_, $$4: BlockPos_, $$5: BlockPos_): Internal.BlockState;
        dropFromExplosion($$0: Internal.Explosion_): boolean;
        isRandomlyTicking($$0: Internal.BlockState_): boolean;
        static isShapeFullBlock(shape: Internal.VoxelShape_): boolean;
        withPropertiesOf($$0: Internal.BlockState_): Internal.BlockState;
        static isExceptionForConnection($$0: Internal.BlockState_): boolean;
        setIsRandomlyTicking(arg0: boolean): void;
        canPlaceLiquid($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Fluid_): boolean;
        hidesNeighborFace(level: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, neighborState: Internal.BlockState_, dir: Internal.Direction_): boolean;
        onTreeGrow(state: Internal.BlockState_, level: Internal.LevelReader_, placeFunction: Internal.BiConsumer_<BlockPos, Internal.BlockState>, randomSource: Internal.RandomSource_, pos: BlockPos_, config: Internal.TreeConfiguration_): boolean;
        /**
         * @deprecated
        */
        rotate($$0: Internal.BlockState_, $$1: Internal.Rotation_): Internal.BlockState;
        defaultMapColor(): Internal.MapColor;
        getStateAtViewpoint(state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_, viewpoint: Vec3d_): Internal.BlockState;
        wait(arg0: number, arg1: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.BlockGetter_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        setNameKey(arg0: string): void;
        static box($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): Internal.VoxelShape;
        /**
         * @deprecated
        */
        mirror($$0: Internal.BlockState_, $$1: Internal.Mirror_): Internal.BlockState;
        wasExploded($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Explosion_): void;
        getName(): Internal.MutableComponent;
        updateEntityAfterFallOn($$0: Internal.BlockGetter_, $$1: Internal.Entity_): void;
        animateTick($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        customShouldDrawFace(view: Internal.BlockGetter_, thisState: Internal.BlockState_, sideState: Internal.BlockState_, thisPos: BlockPos_, sidePos: BlockPos_, side: Internal.Direction_): Optional<boolean>;
        axiom$getResourceLocation(): ResourceLocation;
        arch$registryName(): ResourceLocation;
        axiom$getProperties(): Internal.Collection<any>;
        getBlockBuilder(): Internal.BlockBuilder;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        isSignalSource($$0: Internal.BlockState_): boolean;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number): void;
        /**
         * @deprecated
        */
        attack($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): void;
        getShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        shouldAttemptToCull(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        onProjectileHit($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockHitResult_, $$3: Internal.Projectile_): void;
        static stateById($$0: number): Internal.BlockState;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): Internal.List<Internal.ItemStack>;
        requiredFeatures(): Internal.FeatureFlagSet;
        hashCode(): number;
        axiom$defaultCustomState(): Internal.CustomBlockState;
        setCanCull(canCull: boolean): void;
        /**
         * @deprecated
        */
        isOcclusionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static getId($$0: Internal.BlockState_): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.material.Fluid)"($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        static pushEntitiesUp($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): Internal.BlockState;
        isPathfindable($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.PathComputationType_): boolean;
        setSoundType(arg0: SoundType_): void;
        handler$cef000$betterend$be_getDroppedStacks(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, info: Internal.CallbackInfoReturnable_<any>): void;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_): Internal.List<Internal.ItemStack>;
        /**
         * @deprecated
        */
        onRemove($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        cantCullAgainst(state: Internal.BlockState_): boolean;
        setHasCollision(arg0: boolean): void;
        static shouldRenderFace($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_, $$4: BlockPos_): boolean;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        spawnAfterBreak($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.ItemStack_, $$4: boolean): void;
        get pickupSound(): Optional<Internal.SoundEvent>
        set randomTickCallback(callback: Internal.Consumer_<any>)
        get descriptionId(): string
        get settings(): Internal.BlockBehaviour$Properties
        get explosionResistance(): number
        get typeData(): Internal.CompoundTag
        set friction(arg0: number)
        get jumpFactor(): number
        get speedFactor(): number
        get properties(): Internal.BlockBehaviour$Properties
        get class(): typeof any
        get maxVerticalOffset(): number
        get stateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>
        set blockBuilder(b: Internal.BlockBuilder_)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        set speedFactor(arg0: number)
        set explosionResistance(arg0: number)
        get id(): string
        get lootTable(): ResourceLocation
        get friction(): number
        set lightEmission(v: number)
        set jumpFactor(arg0: number)
        set destroySpeed(v: number)
        get maxHorizontalOffset(): number
        set isRandomlyTicking(arg0: boolean)
        set nameKey(arg0: string)
        get name(): Internal.MutableComponent
        get blockBuilder(): Internal.BlockBuilder
        get idLocation(): ResourceLocation
        get mod(): string
        set canCull(canCull: boolean)
        set soundType(arg0: SoundType_)
        set hasCollision(arg0: boolean)
        static readonly WATERLOGGED: (Internal.BooleanProperty) & (Internal.BooleanProperty);
    }
    type ConduitBlock_ = ConduitBlock;
    abstract class AbstractObject2ByteSortedMap <K> extends Internal.AbstractObject2ByteMap<K> implements Internal.Object2ByteSortedMap<K> {
        /**
         * @deprecated
        */
        containsValue(arg0: any): boolean;
        /**
         * @deprecated
        */
        andThen<T>(arg0: Internal.Function_<number, T>): Internal.Function<K, T>;
        composeByte(arg0: Internal.Byte2ObjectFunction_<K>): Internal.Byte2ByteFunction;
        "put(java.lang.Object,byte)"(arg0: K, arg1: number): number;
        /**
         * @deprecated
        */
        put(arg0: K, arg1: number): number;
        /**
         * @deprecated
        */
        "remove(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): boolean;
        /**
         * @deprecated
        */
        "merge(java.lang.Object,java.lang.Object,java.util.function.BiFunction)"(arg0: any, arg1: any, arg2: Internal.BiFunction_<any, any, any>): any;
        /**
         * @deprecated
        */
        putIfAbsent(arg0: K, arg1: number): number;
        andThenChar(arg0: Internal.Byte2CharFunction_): Internal.Object2CharFunction<K>;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V): Internal.Map<K, V>;
        /**
         * @deprecated
        */
        computeByteIfAbsent(arg0: K, arg1: Internal.ToIntFunction_<K>): number;
        "merge(java.lang.Object,byte,java.util.function.BiFunction)"(arg0: K, arg1: number, arg2: Internal.BiFunction_<number, number, number>): number;
        /**
         * @deprecated
        */
        "replace(java.lang.Object,java.lang.Object,java.lang.Object)"(arg0: any, arg1: any, arg2: any): boolean;
        removeByte(arg0: any): number;
        composeObject<T>(arg0: Internal.Object2ObjectFunction_<T, K>): Internal.Object2ByteFunction<T>;
        mergeByte(arg0: K, arg1: number, arg2: Internal.IntBinaryOperator_): number;
        /**
         * @deprecated
        */
        put(arg0: any, arg1: any): any;
        values(): Internal.Collection<any>;
        composeFloat(arg0: Internal.Float2ObjectFunction_<K>): Internal.Float2ByteFunction;
        "replace(java.lang.Object,byte)"(arg0: K, arg1: number): number;
        "replace(java.lang.Object,byte,byte)"(arg0: K, arg1: number, arg2: number): boolean;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V): Internal.Map<K, V>;
        /**
         * @deprecated
        */
        replace(arg0: K, arg1: number): number;
        applyAsInt(arg0: K): number;
        /**
         * @deprecated
        */
        computeByteIfAbsentPartial(arg0: K, arg1: Internal.Object2ByteFunction_<K>): number;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: number): number;
        "computeIfAbsent(java.lang.Object,it.unimi.dsi.fastutil.objects.Object2ByteFunction)"(arg0: K, arg1: Internal.Object2ByteFunction_<K>): number;
        static ofEntries<K, V>(...arg0: Internal.Map$Entry_<K, V>[]): Internal.Map<K, V>;
        putIfAbsent(arg0: K, arg1: number): number;
        andThenReference<T>(arg0: Internal.Byte2ReferenceFunction_<T>): Internal.Object2ReferenceFunction<K, T>;
        /**
         * @deprecated
        */
        putIfAbsent(arg0: any, arg1: any): any;
        static of<K, V>(arg0: K, arg1: V): Internal.Map<K, V>;
        getClass(): typeof any;
        getOrDefault(arg0: any, arg1: number): number;
        andThenInt(arg0: Internal.Byte2IntFunction_): Internal.Object2IntFunction<K>;
        /**
         * @deprecated
        */
        "getOrDefault(java.lang.Object,java.lang.Byte)"(arg0: any, arg1: number): number;
        static of<K, V>(): Internal.Map<K, V>;
        /**
         * @deprecated
        */
        "putIfAbsent(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): any;
        replace(arg0: K, arg1: number, arg2: number): boolean;
        remove(arg0: any, arg1: number): boolean;
        /**
         * @deprecated
        */
        "replace(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): any;
        mergeByte(arg0: K, arg1: number, arg2: Internal.ByteBinaryOperator_): number;
        /**
         * @deprecated
        */
        "getOrDefault(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): any;
        containsValue(arg0: number): boolean;
        /**
         * @deprecated
        */
        "replace(java.lang.Object,java.lang.Byte)"(arg0: K, arg1: number): number;
        andThenByte(arg0: Internal.Byte2ByteFunction_): Internal.Object2ByteFunction<K>;
        apply(arg0: K): number;
        andThenFloat(arg0: Internal.Byte2FloatFunction_): Internal.Object2FloatFunction<K>;
        merge(arg0: K, arg1: number, arg2: Internal.BiFunction_<number, number, number>): number;
        /**
         * @deprecated
        */
        mergeByte(arg0: K, arg1: number, arg2: Internal.BiFunction_<number, number, number>): number;
        toString(): string;
        notifyAll(): void;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V): Internal.Map<K, V>;
        /**
         * @deprecated
        */
        remove(arg0: any, arg1: any): boolean;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V): Internal.Map<K, V>;
        "remove(java.lang.Object,byte)"(arg0: any, arg1: number): boolean;
        "getOrDefault(java.lang.Object,byte)"(arg0: any, arg1: number): number;
        computeByteIfPresent(arg0: K, arg1: Internal.BiFunction_<K, number, number>): number;
        "putIfAbsent(java.lang.Object,byte)"(arg0: K, arg1: number): number;
        abstract lastKey(): K;
        abstract size(): number;
        composeInt(arg0: Internal.Int2ObjectFunction_<K>): Internal.Int2ByteFunction;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V, arg16: K, arg17: V): Internal.Map<K, V>;
        clear(): void;
        wait(arg0: number): void;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V): Internal.Map<K, V>;
        composeShort(arg0: Internal.Short2ObjectFunction_<K>): Internal.Short2ByteFunction;
        replaceAll(arg0: Internal.BiFunction_<K, number, number>): void;
        computeIfPresent(arg0: K, arg1: Internal.BiFunction_<K, number, number>): number;
        /**
         * @deprecated
        */
        "put(java.lang.Object,java.lang.Byte)"(arg0: K, arg1: number): number;
        andThenObject<T>(arg0: Internal.Byte2ObjectFunction_<T>): Internal.Object2ObjectFunction<K, T>;
        "computeIfAbsent(java.lang.Object,java.util.function.ToIntFunction)"(arg0: K, arg1: Internal.ToIntFunction_<K>): number;
        notify(): void;
        /**
         * @deprecated
        */
        "put(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): any;
        compose<V>(arg0: Internal.Function_<V, K>): Internal.Function<V, number>;
        keySet(): Internal.Set<any>;
        abstract comparator(): Comparator<K>;
        abstract defaultReturnValue(arg0: number): void;
        /**
         * @deprecated
        */
        "putIfAbsent(java.lang.Object,java.lang.Byte)"(arg0: K, arg1: number): number;
        /**
         * @deprecated
        */
        "merge(java.lang.Object,java.lang.Byte,java.util.function.BiFunction)"(arg0: K, arg1: number, arg2: Internal.BiFunction_<number, number, number>): number;
        /**
         * @deprecated
        */
        replace(arg0: any, arg1: any, arg2: any): boolean;
        /**
         * @deprecated
        */
        remove(arg0: any): number;
        abstract defaultReturnValue(): number;
        static copyOf<K, V>(arg0: Internal.Map_<K, V>): Internal.Map<K, V>;
        subMap(arg0: any, arg1: any): Internal.SortedMap<any, any>;
        /**
         * @deprecated
        */
        entrySet(): Internal.ObjectSet<any>;
        compute(arg0: K, arg1: Internal.BiFunction_<K, number, number>): number;
        andThenLong(arg0: Internal.Byte2LongFunction_): Internal.Object2LongFunction<K>;
        /**
         * @deprecated
        */
        replace(arg0: K, arg1: number, arg2: number): boolean;
        andThenShort(arg0: Internal.Byte2ShortFunction_): Internal.Object2ShortFunction<K>;
        abstract getByte(arg0: any): number;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V): Internal.Map<K, V>;
        /**
         * @deprecated
        */
        "replace(java.lang.Object,java.lang.Byte,java.lang.Byte)"(arg0: K, arg1: number, arg2: number): boolean;
        wait(): void;
        andThenDouble(arg0: Internal.Byte2DoubleFunction_): Internal.Object2DoubleFunction<K>;
        abstract tailMap(arg0: K): Internal.Object2ByteSortedMap<K>;
        static identity<T>(): Internal.Function<T, T>;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: any): any;
        put(arg0: K, arg1: number): number;
        isEmpty(): boolean;
        static entry<K, V>(arg0: K, arg1: V): Internal.Map$Entry<K, V>;
        wait(arg0: number, arg1: number): void;
        "mergeByte(java.lang.Object,byte,java.util.function.IntBinaryOperator)"(arg0: K, arg1: number, arg2: Internal.IntBinaryOperator_): number;
        containsKey(arg0: any): boolean;
        /**
         * @deprecated
        */
        "mergeByte(java.lang.Object,byte,java.util.function.BiFunction)"(arg0: K, arg1: number, arg2: Internal.BiFunction_<number, number, number>): number;
        composeChar(arg0: Internal.Char2ObjectFunction_<K>): Internal.Char2ByteFunction;
        "mergeByte(java.lang.Object,byte,it.unimi.dsi.fastutil.bytes.ByteBinaryOperator)"(arg0: K, arg1: number, arg2: Internal.ByteBinaryOperator_): number;
        computeIfAbsent(arg0: K, arg1: Internal.Object2ByteFunction_<K>): number;
        "containsValue(byte)"(arg0: number): boolean;
        abstract object2ByteEntrySet(): Internal.ObjectSortedSet<Internal.Object2ByteMap$Entry<K>>;
        composeDouble(arg0: Internal.Double2ObjectFunction_<K>): Internal.Double2ByteFunction;
        computeIfAbsent(arg0: K, arg1: Internal.Function_<K, number>): number;
        computeIfAbsent(arg0: K, arg1: Internal.ToIntFunction_<K>): number;
        putAll(arg0: Internal.Map_<K, number>): void;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V): Internal.Map<K, V>;
        headMap(arg0: any): Internal.SortedMap<any, any>;
        "computeIfAbsent(java.lang.Object,java.util.function.Function)"(arg0: K, arg1: Internal.Function_<K, number>): number;
        computeByte(arg0: K, arg1: Internal.BiFunction_<K, number, number>): number;
        forEach(arg0: Internal.BiConsumer_<K, number>): void;
        /**
         * @deprecated
        */
        merge(arg0: K, arg1: number, arg2: Internal.BiFunction_<number, number, number>): number;
        hashCode(): number;
        composeReference<T>(arg0: Internal.Reference2ObjectFunction_<T, K>): Internal.Reference2ByteFunction<T>;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V, arg16: K, arg17: V, arg18: K, arg19: V): Internal.Map<K, V>;
        replace(arg0: K, arg1: number): number;
        /**
         * @deprecated
        */
        replace(arg0: any, arg1: any): any;
        composeLong(arg0: Internal.Long2ObjectFunction_<K>): Internal.Long2ByteFunction;
        /**
         * @deprecated
        */
        "containsValue(java.lang.Object)"(arg0: any): boolean;
        /**
         * @deprecated
        */
        merge(arg0: any, arg1: any, arg2: Internal.BiFunction_<any, any, any>): any;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        get(arg0: any): any;
        abstract firstKey(): K;
        get class(): typeof any
        get empty(): boolean
    }
    type AbstractObject2ByteSortedMap_<K> = AbstractObject2ByteSortedMap<K>;
    class ShapedRecipeSchema$ShapedRecipeJS extends Internal.RecipeJS {
        constructor()
        /**
         * @deprecated
        */
        getGroup(): string;
        convertJavaToJs(cx: Internal.Context_, scope: Internal.Scriptable_, staticType: typeof any): Internal.Scriptable;
        getSerializationTypeFunction(): Internal.RecipeTypeFunction;
        inputValues(): Internal.RecipeComponentValue<any>[];
        notify(): void;
        replaceIngredient(filter: Internal.IngredientActionFilter_, item: Internal.ItemStack_): Internal.RecipeJS;
        customIngredientAction(filter: Internal.IngredientActionFilter_, id: string): Internal.RecipeJS;
        remove(): void;
        writeOutputFluid(value: Internal.OutputFluid_): Internal.JsonElement;
        readOutputFluid(from: any): Internal.OutputFluid;
        stage(s: string): Internal.RecipeJS;
        inputItemHasPriority(from: any): boolean;
        getOriginalRecipe(): Internal.Recipe<any>;
        noMirror(): Internal.RecipeJS;
        group(g: string): Internal.RecipeJS;
        hasChanged(): boolean;
        initValues(created: boolean): void;
        readInputItem(from: any): InputItem;
        createRecipe(): Internal.Recipe<any>;
        outputItemHasPriority(from: any): boolean;
        modifyResult(callback: Internal.ModifyRecipeResultCallback_): Internal.RecipeJS;
        get(key: string): any;
        replaceInput(match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): boolean;
        id(_id: ResourceLocation_): Internal.RecipeJS;
        /**
         * @deprecated
        */
        getType(): ResourceLocation;
        getOriginalRecipeResult(): Internal.ItemStack;
        inputFluidHasPriority(from: any): boolean;
        setValue<T>(key: Internal.RecipeKey_<T>, value: T): Internal.RecipeJS;
        wait(): void;
        readInputFluid(from: any): Internal.InputFluid;
        set(key: string, value: any): Internal.RecipeJS;
        getAllValueMap(): Internal.Map<string, Internal.RecipeComponentValue<any>>;
        getFromToString(): string;
        getClass(): typeof any;
        outputFluidHasPriority(from: any): boolean;
        writeInputItem(value: InputItem_): Internal.JsonElement;
        outputValues(): Internal.RecipeComponentValue<any>[];
        /**
         * @deprecated
        */
        getSchema(): Internal.RecipeSchema;
        deserialize(merge: boolean): void;
        wait(arg0: number, arg1: number): void;
        writeOutputItem(value: OutputItem_): Internal.JsonElement;
        ingredientAction(filter: Internal.IngredientActionFilter_, action: Internal.IngredientAction_): Internal.RecipeJS;
        getValue<T>(key: Internal.RecipeKey_<T>): T;
        serialize(): void;
        getPath(): string;
        keepIngredient(filter: Internal.IngredientActionFilter_): Internal.RecipeJS;
        getMod(): string;
        hasOutput(match: Internal.ReplacementMatch_): boolean;
        toString(): string;
        notifyAll(): void;
        writeInputFluid(value: Internal.InputFluid_): Internal.JsonElement;
        consumeIngredient(filter: Internal.IngredientActionFilter_): Internal.RecipeJS;
        damageIngredient(filter: Internal.IngredientActionFilter_): Internal.RecipeJS;
        getId(): string;
        save(): void;
        afterLoaded(): void;
        /**
         * @deprecated
        */
        setGroup(group: string): void;
        hashCode(): number;
        /**
         * @deprecated
        */
        getOrCreateId(): ResourceLocation;
        merge(j: Internal.JsonObject_): Internal.RecipeJS;
        noShrink(): Internal.RecipeJS;
        hasInput(match: Internal.ReplacementMatch_): boolean;
        getOriginalRecipeIngredients(): Internal.List<Internal.Ingredient>;
        readOutputItem(from: any): OutputItem;
        damageIngredient(filter: Internal.IngredientActionFilter_, damage: number): Internal.RecipeJS;
        wait(arg0: number): void;
        replaceOutput(match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): boolean;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        get group(): string
        get serializationTypeFunction(): Internal.RecipeTypeFunction
        get originalRecipe(): Internal.Recipe<any>
        /**
         * @deprecated
        */
        get type(): ResourceLocation
        get originalRecipeResult(): Internal.ItemStack
        get allValueMap(): Internal.Map<string, Internal.RecipeComponentValue<any>>
        get fromToString(): string
        get class(): typeof any
        /**
         * @deprecated
        */
        get schema(): Internal.RecipeSchema
        get path(): string
        get mod(): string
        get id(): string
        /**
         * @deprecated
        */
        set group(group: string)
        /**
         * @deprecated
        */
        get orCreateId(): ResourceLocation
        get originalRecipeIngredients(): Internal.List<Internal.Ingredient>
    }
    type ShapedRecipeSchema$ShapedRecipeJS_ = ShapedRecipeSchema$ShapedRecipeJS;
    abstract class MapBlockMarker <D extends Internal.CustomMapDecoration> {
        getFlags(): number;
        getClass(): typeof any;
        getRotation(): number;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        shouldRefresh(): boolean;
        getPos(): BlockPos;
        createDecorationFromMarker(data: Internal.MapItemSavedData_): D;
        setName(name: net.minecraft.network.chat.Component_): void;
        getMarkerId(): string;
        shouldSave(): boolean;
        setPersistent(persistent: boolean): void;
        getName(): net.minecraft.network.chat.Component;
        toString(): string;
        setPos(pos: BlockPos_): void;
        setRotation(rot: number): void;
        notifyAll(): void;
        hasFlag(flag: number): boolean;
        getTypeId(): string;
        hashCode(): number;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        saveToNBT(compound: Internal.CompoundTag_): Internal.CompoundTag;
        loadFromNBT(compound: Internal.CompoundTag_): void;
        wait(): void;
        wait(arg0: number): void;
        saveToNBT(): Internal.CompoundTag;
        getType(): Internal.MapDecorationType<D, any>;
        equals(o: any): boolean;
        get flags(): number
        get class(): typeof any
        get rotation(): number
        get pos(): BlockPos
        set name(name: net.minecraft.network.chat.Component_)
        get markerId(): string
        set persistent(persistent: boolean)
        get name(): net.minecraft.network.chat.Component
        set pos(pos: BlockPos_)
        set rotation(rot: number)
        get typeId(): string
        get type(): Internal.MapDecorationType<D, any>
        static readonly HAS_SMALL_TEXTURE_FLAG: (1) & (number);
    }
    type MapBlockMarker_<D extends Internal.CustomMapDecoration> = MapBlockMarker<D>;
    interface DataHolder <T> {
    }
    type DataHolder_<T> = DataHolder<T>;
    class DamageSources implements Internal.DamageSourcesAccessor {
        constructor($$0: Internal.RegistryAccess_)
        genericKill(): DamageSource;
        source($$0: Internal.ResourceKey_<Internal.DamageType>, $$1: Internal.Entity_, $$2: Internal.Entity_): DamageSource;
        thrown($$0: Internal.Entity_, $$1: Internal.Entity_): DamageSource;
        lightningBolt(): DamageSource;
        fireball($$0: Internal.Fireball_, $$1: Internal.Entity_): DamageSource;
        starve(): DamageSource;
        source($$0: Internal.ResourceKey_<Internal.DamageType>, $$1: Internal.Entity_): DamageSource;
        notify(): void;
        sting($$0: Internal.LivingEntity_): DamageSource;
        playerAttack($$0: Internal.Player_): DamageSource;
        getRegistry(): Internal.Registry<any>;
        indirectMagic($$0: Internal.Entity_, $$1: Internal.Entity_): DamageSource;
        wither(): DamageSource;
        sonicBoom($$0: Internal.Entity_): DamageSource;
        thorns($$0: Internal.Entity_): DamageSource;
        fallingStalactite($$0: Internal.Entity_): DamageSource;
        outOfBorder(): DamageSource;
        mobProjectile($$0: Internal.Entity_, $$1: Internal.LivingEntity_): DamageSource;
        mobAttack($$0: Internal.LivingEntity_): DamageSource;
        stalagmite(): DamageSource;
        fall(): DamageSource;
        witherSkull($$0: Internal.WitherSkull_, $$1: Internal.Entity_): DamageSource;
        wait(): void;
        cactus(): DamageSource;
        fellOutOfWorld(): DamageSource;
        generic(): DamageSource;
        getClass(): typeof any;
        freeze(): DamageSource;
        onFire(): DamageSource;
        cramming(): DamageSource;
        fireworks($$0: Internal.FireworkRocketEntity_, $$1: Internal.Entity_): DamageSource;
        magic(): DamageSource;
        fallingBlock($$0: Internal.Entity_): DamageSource;
        lava(): DamageSource;
        wait(arg0: number, arg1: number): void;
        dragonBreath(): DamageSource;
        inFire(): DamageSource;
        trident($$0: Internal.Entity_, $$1: Internal.Entity_): DamageSource;
        dryOut(): DamageSource;
        noAggroMobAttack($$0: Internal.LivingEntity_): DamageSource;
        anvil($$0: Internal.Entity_): DamageSource;
        toString(): string;
        notifyAll(): void;
        arrow($$0: Internal.AbstractArrow_, $$1: Internal.Entity_): DamageSource;
        explosion($$0: Internal.Entity_, $$1: Internal.Entity_): DamageSource;
        source($$0: Internal.ResourceKey_<Internal.DamageType>): DamageSource;
        hotFloor(): DamageSource;
        explosion($$0: Internal.Explosion_): DamageSource;
        inWall(): DamageSource;
        hashCode(): number;
        flyIntoWall(): DamageSource;
        drown(): DamageSource;
        badRespawnPointExplosion($$0: Vec3d_): DamageSource;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        sweetBerryBush(): DamageSource;
        get registry(): Internal.Registry<any>
        get class(): typeof any
        readonly damageTypes: Internal.Registry<Internal.DamageType>;
    }
    type DamageSources_ = DamageSources;
    interface ByteBufAllocator {
        abstract compositeDirectBuffer(arg0: number): Internal.CompositeByteBuf;
        abstract directBuffer(arg0: number, arg1: number): Internal.ByteBuf;
        abstract buffer(): Internal.ByteBuf;
        abstract compositeHeapBuffer(arg0: number): Internal.CompositeByteBuf;
        abstract compositeDirectBuffer(): Internal.CompositeByteBuf;
        abstract compositeBuffer(): Internal.CompositeByteBuf;
        abstract heapBuffer(arg0: number, arg1: number): Internal.ByteBuf;
        abstract ioBuffer(): Internal.ByteBuf;
        abstract heapBuffer(): Internal.ByteBuf;
        abstract heapBuffer(arg0: number): Internal.ByteBuf;
        abstract ioBuffer(arg0: number): Internal.ByteBuf;
        abstract compositeBuffer(arg0: number): Internal.CompositeByteBuf;
        abstract directBuffer(): Internal.ByteBuf;
        abstract isDirectBufferPooled(): boolean;
        abstract calculateNewCapacity(arg0: number, arg1: number): number;
        abstract directBuffer(arg0: number): Internal.ByteBuf;
        abstract ioBuffer(arg0: number, arg1: number): Internal.ByteBuf;
        abstract buffer(arg0: number, arg1: number): Internal.ByteBuf;
        abstract compositeHeapBuffer(): Internal.CompositeByteBuf;
        abstract buffer(arg0: number): Internal.ByteBuf;
        get directBufferPooled(): boolean
        readonly DEFAULT: (Internal.PooledByteBufAllocator) & (Internal.ByteBufAllocator);
    }
    type ByteBufAllocator_ = ByteBufAllocator;
    interface InvokerAxe {
        abstract invokeGetStrippedState(arg0: Internal.BlockState_): Optional<Internal.BlockState>;
        (arg0: Internal.BlockState): Optional_<Internal.BlockState>;
    }
    type InvokerAxe_ = ((arg0: Internal.BlockState)=> Optional_<Internal.BlockState>) | InvokerAxe;
    class ORFilterItem extends Internal.InventoryFilterItem {
        constructor()
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, world: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, flag: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getDisplayItemStacks(filter: Internal.ItemStack_, list: Internal.List_<Internal.ItemStack>): void;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        addSlots(filter: Internal.ItemStack_, list: Internal.List_<Internal.InventoryFilterItem$FilterSlot>): void;
        getInventorySize(filter: Internal.ItemStack_): number;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(world: Internal.Level_, player: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        filterItem(filter: Internal.ItemStack_, item: Internal.Item_): boolean;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        addInfo(filter: Internal.ItemStack_, info: Internal.FilterInfo_, expanded: boolean): void;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        static getInventory(stack: Internal.ItemStack_): Internal.ItemInventory;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        resetFilterData(filter: Internal.ItemStack_): void;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        filter(filter: Internal.ItemStack_, stack: Internal.ItemStack_): boolean;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick(stack: Internal.ItemStack_, level: Internal.Level_, entity: Internal.Entity_, i: number, bl: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        clearFilterCache(filter: Internal.ItemStack_): void;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type ORFilterItem_ = ORFilterItem;
    interface IEMFTextureSizeSupplier {
        abstract emf$getTextureSize(): number[];
        abstract emf$setTextureSize(arg0: number[]): void;
    }
    type IEMFTextureSizeSupplier_ = IEMFTextureSizeSupplier;
    interface CapturedDropsEntity {
        abstract puzzleslib$acceptCapturedDrops(arg0: Internal.Collection_<Internal.ItemEntity>): Internal.Collection<Internal.ItemEntity>;
        (arg0: Internal.Collection<Internal.ItemEntity>): Internal.Collection_<Internal.ItemEntity>;
    }
    type CapturedDropsEntity_ = CapturedDropsEntity | ((arg0: Internal.Collection<Internal.ItemEntity>)=> Internal.Collection_<Internal.ItemEntity>);
    interface Long2IntMap extends Internal.Map<number, number>, Internal.Long2IntFunction {
        composeDouble(arg0: Internal.Double2LongFunction_): Internal.Double2IntFunction;
        "replace(long,int)"(arg0: number, arg1: number): number;
        /**
         * @deprecated
        */
        containsValue(arg0: any): boolean;
        "put(long,int)"(arg0: number, arg1: number): number;
        composeObject<T>(arg0: Internal.Object2LongFunction_<T>): Internal.Object2IntFunction<T>;
        /**
         * @deprecated
        */
        "remove(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): boolean;
        /**
         * @deprecated
        */
        "merge(java.lang.Object,java.lang.Object,java.util.function.BiFunction)"(arg0: any, arg1: any, arg2: Internal.BiFunction_<any, any, any>): any;
        abstract values(): Internal.IntCollection;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V): Internal.Map<K, V>;
        /**
         * @deprecated
        */
        "replace(java.lang.Object,java.lang.Object,java.lang.Object)"(arg0: any, arg1: any, arg2: any): boolean;
        /**
         * @deprecated
        */
        put(arg0: any, arg1: any): any;
        andThenObject<T>(arg0: Internal.Int2ObjectFunction_<T>): Internal.Long2ObjectFunction<T>;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: number): number;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V): Internal.Map<K, V>;
        /**
         * @deprecated
        */
        "computeIfAbsent(java.lang.Object,java.util.function.Function)"(arg0: any, arg1: Internal.Function_<any, any>): any;
        /**
         * @deprecated
        */
        put(arg0: number, arg1: number): number;
        "compute(long,java.util.function.BiFunction)"(arg0: number, arg1: Internal.BiFunction_<number, number, number>): number;
        computeIfAbsent(arg0: number, arg1: Internal.LongToIntFunction_): number;
        /**
         * @deprecated
        */
        "put(java.lang.Long,java.lang.Integer)"(arg0: number, arg1: number): number;
        remove(arg0: number, arg1: number): boolean;
        /**
         * @deprecated
        */
        replace(arg0: number, arg1: number): number;
        "remove(long,int)"(arg0: number, arg1: number): boolean;
        /**
         * @deprecated
        */
        "getOrDefault(java.lang.Object,java.lang.Integer)"(arg0: any, arg1: number): number;
        composeShort(arg0: Internal.Short2LongFunction_): Internal.Short2IntFunction;
        andThenReference<T>(arg0: Internal.Int2ReferenceFunction_<T>): Internal.Long2ReferenceFunction<T>;
        mergeInt(arg0: number, arg1: number, arg2: it.unimi.dsi.fastutil.ints.IntBinaryOperator_): number;
        ofEntries<K, V>(...arg0: Internal.Map$Entry_<K, V>[]): Internal.Map<K, V>;
        abstract putAll(arg0: Internal.Map_<number, number>): void;
        andThenChar(arg0: Internal.Int2CharFunction_): Internal.Long2CharFunction;
        merge(arg0: number, arg1: number, arg2: Internal.BiFunction_<number, number, number>): number;
        /**
         * @deprecated
        */
        "merge(java.lang.Long,java.lang.Integer,java.util.function.BiFunction)"(arg0: number, arg1: number, arg2: Internal.BiFunction_<number, number, number>): number;
        composeLong(arg0: Internal.Long2LongFunction_): Internal.Long2IntFunction;
        "mergeInt(long,int,it.unimi.dsi.fastutil.ints.IntBinaryOperator)"(arg0: number, arg1: number, arg2: it.unimi.dsi.fastutil.ints.IntBinaryOperator_): number;
        /**
         * @deprecated
        */
        putIfAbsent(arg0: any, arg1: any): any;
        of<K, V>(arg0: K, arg1: V): Internal.Map<K, V>;
        /**
         * @deprecated
        */
        "containsKey(java.lang.Object)"(arg0: any): boolean;
        /**
         * @deprecated
        */
        "replace(java.lang.Long,java.lang.Integer)"(arg0: number, arg1: number): number;
        /**
         * @deprecated
        */
        "computeIfPresent(java.lang.Object,java.util.function.BiFunction)"(arg0: any, arg1: Internal.BiFunction_<any, any, any>): any;
        /**
         * @deprecated
        */
        andThen<T>(arg0: Internal.Function_<number, T>): Internal.Function<number, T>;
        abstract long2IntEntrySet(): Internal.ObjectSet<Internal.Long2IntMap$Entry>;
        of<K, V>(): Internal.Map<K, V>;
        /**
         * @deprecated
        */
        "putIfAbsent(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): any;
        /**
         * @deprecated
        */
        computeIfPresent(arg0: number, arg1: Internal.BiFunction_<number, number, number>): number;
        /**
         * @deprecated
        */
        replace(arg0: number, arg1: number, arg2: number): boolean;
        /**
         * @deprecated
        */
        putIfAbsent(arg0: number, arg1: number): number;
        mergeInt(arg0: number, arg1: number, arg2: Internal.IntBinaryOperator_): number;
        /**
         * @deprecated
        */
        "replace(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): any;
        /**
         * @deprecated
        */
        "getOrDefault(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): any;
        /**
         * @deprecated
        */
        merge(arg0: number, arg1: number, arg2: Internal.BiFunction_<number, number, number>): number;
        applyAsInt(arg0: number): number;
        andThenByte(arg0: Internal.Int2ByteFunction_): Internal.Long2ByteFunction;
        /**
         * @deprecated
        */
        "compute(java.lang.Long,java.util.function.BiFunction)"(arg0: number, arg1: Internal.BiFunction_<number, number, number>): number;
        "putIfAbsent(long,int)"(arg0: number, arg1: number): number;
        putIfAbsent(arg0: number, arg1: number): number;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V): Internal.Map<K, V>;
        /**
         * @deprecated
        */
        remove(arg0: any, arg1: any): boolean;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V): Internal.Map<K, V>;
        compute(arg0: number, arg1: Internal.BiFunction_<number, number, number>): number;
        "replace(long,int,int)"(arg0: number, arg1: number, arg2: number): boolean;
        abstract size(): number;
        /**
         * @deprecated
        */
        "compute(java.lang.Object,java.util.function.BiFunction)"(arg0: any, arg1: Internal.BiFunction_<any, any, any>): any;
        composeInt(arg0: Internal.Int2LongFunction_): Internal.Int2IntFunction;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V, arg16: K, arg17: V): Internal.Map<K, V>;
        clear(): void;
        /**
         * @deprecated
        */
        "remove(java.lang.Object)"(arg0: any): number;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V): Internal.Map<K, V>;
        /**
         * @deprecated
        */
        compose<T>(arg0: Internal.Function_<T, number>): Internal.Function<T, number>;
        /**
         * @deprecated
        */
        computeIfPresent(arg0: any, arg1: Internal.BiFunction_<any, any, any>): any;
        composeFloat(arg0: Internal.Float2LongFunction_): Internal.Float2IntFunction;
        /**
         * @deprecated
        */
        "get(java.lang.Object)"(arg0: any): any;
        abstract defaultReturnValue(): number;
        replace(arg0: number, arg1: number): number;
        replaceAll(arg0: Internal.BiFunction_<number, number, number>): void;
        abstract get(arg0: number): number;
        /**
         * @deprecated
        */
        "put(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): any;
        /**
         * @deprecated
        */
        "putIfAbsent(java.lang.Long,java.lang.Integer)"(arg0: number, arg1: number): number;
        keySet(): Internal.Set<any>;
        computeIfAbsentNullable(arg0: number, arg1: Internal.LongFunction_<number>): number;
        replace(arg0: number, arg1: number, arg2: number): boolean;
        /**
         * @deprecated
        */
        replace(arg0: any, arg1: any, arg2: any): boolean;
        copyOf<K, V>(arg0: Internal.Map_<K, V>): Internal.Map<K, V>;
        /**
         * @deprecated
        */
        entrySet(): Internal.Set<any>;
        abstract "containsValue(int)"(arg0: number): boolean;
        "computeIfAbsent(long,it.unimi.dsi.fastutil.longs.Long2IntFunction)"(arg0: number, arg1: Internal.Long2IntFunction_): number;
        andThenLong(arg0: Internal.Int2LongFunction_): Internal.Long2LongFunction;
        abstract containsKey(arg0: number): boolean;
        /**
         * @deprecated
        */
        computeIfAbsent(arg0: any, arg1: Internal.Function_<any, any>): any;
        forEach(arg0: Internal.BiConsumer_<number, number>): void;
        composeChar(arg0: Internal.Char2LongFunction_): Internal.Char2IntFunction;
        composeByte(arg0: Internal.Byte2LongFunction_): Internal.Byte2IntFunction;
        "merge(long,int,java.util.function.BiFunction)"(arg0: number, arg1: number, arg2: Internal.BiFunction_<number, number, number>): number;
        /**
         * @deprecated
        */
        "replace(java.lang.Long,java.lang.Integer,java.lang.Integer)"(arg0: number, arg1: number, arg2: number): boolean;
        /**
         * @deprecated
        */
        compute(arg0: number, arg1: Internal.BiFunction_<number, number, number>): number;
        remove(arg0: number): number;
        "getOrDefault(long,int)"(arg0: number, arg1: number): number;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V): Internal.Map<K, V>;
        "computeIfAbsent(long,java.util.function.LongToIntFunction)"(arg0: number, arg1: Internal.LongToIntFunction_): number;
        apply(arg0: number): number;
        "mergeInt(long,int,java.util.function.IntBinaryOperator)"(arg0: number, arg1: number, arg2: Internal.IntBinaryOperator_): number;
        /**
         * @deprecated
        */
        compute(arg0: any, arg1: Internal.BiFunction_<any, any, any>): any;
        identity<T>(): Internal.Function<T, T>;
        "computeIfPresent(long,java.util.function.BiFunction)"(arg0: number, arg1: Internal.BiFunction_<number, number, number>): number;
        "remove(long)"(arg0: number): number;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: any): any;
        abstract "containsKey(long)"(arg0: number): boolean;
        abstract isEmpty(): boolean;
        getOrDefault(arg0: number, arg1: number): number;
        entry<K, V>(arg0: K, arg1: V): Internal.Map$Entry<K, V>;
        andThenFloat(arg0: Internal.Int2FloatFunction_): Internal.Long2FloatFunction;
        computeIfPresent(arg0: number, arg1: Internal.BiFunction_<number, number, number>): number;
        abstract "get(long)"(arg0: number): number;
        /**
         * @deprecated
        */
        containsKey(arg0: any): boolean;
        andThenInt(arg0: Internal.Int2IntFunction_): Internal.Long2IntFunction;
        abstract containsValue(arg0: number): boolean;
        composeReference<T>(arg0: Internal.Reference2LongFunction_<T>): Internal.Reference2IntFunction<T>;
        computeIfAbsent(arg0: number, arg1: Internal.Long2IntFunction_): number;
        andThenShort(arg0: Internal.Int2ShortFunction_): Internal.Long2ShortFunction;
        /**
         * @deprecated
        */
        remove(arg0: any): number;
        /**
         * @deprecated
        */
        "computeIfPresent(java.lang.Long,java.util.function.BiFunction)"(arg0: number, arg1: Internal.BiFunction_<number, number, number>): number;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V): Internal.Map<K, V>;
        /**
         * @deprecated
        */
        "computeIfAbsent(java.lang.Long,java.util.function.Function)"(arg0: number, arg1: Internal.Function_<number, number>): number;
        abstract hashCode(): number;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V, arg16: K, arg17: V, arg18: K, arg19: V): Internal.Map<K, V>;
        abstract defaultReturnValue(arg0: number): void;
        /**
         * @deprecated
        */
        computeIfAbsent(arg0: number, arg1: Internal.Function_<number, number>): number;
        /**
         * @deprecated
        */
        replace(arg0: any, arg1: any): any;
        put(arg0: number, arg1: number): number;
        /**
         * @deprecated
        */
        "containsValue(java.lang.Object)"(arg0: any): boolean;
        /**
         * @deprecated
        */
        merge(arg0: any, arg1: any, arg2: Internal.BiFunction_<any, any, any>): any;
        /**
         * @deprecated
        */
        computeIfAbsentPartial(arg0: number, arg1: Internal.Long2IntFunction_): number;
        abstract equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        get(arg0: any): any;
        andThenDouble(arg0: Internal.Int2DoubleFunction_): Internal.Long2DoubleFunction;
        get empty(): boolean
    }
    type Long2IntMap_ = Long2IntMap;
    abstract class ContextFeature <FC extends Internal.FeatureConfiguration> extends Feature<FC> {
        constructor(codec: Internal.Codec_<FC>)
        getClass(): typeof any;
        place($$0: FC, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        toString(): string;
        place(ctx: Internal.FeaturePlaceContext_<FC>): boolean;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        notify(): void;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<FC, Feature<FC>>>;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        get class(): typeof any
    }
    type ContextFeature_<FC extends Internal.FeatureConfiguration> = ContextFeature<FC>;
    class Villager extends Internal.AbstractVillager implements Internal.VillagerDataHolder, Internal.AccessorVillager, Internal.VillagerWerepyreAccessor, Internal.VillagerAccessor, Internal.ReputationEventHandler, Internal.VillagerEntityAccessor {
        constructor($$0: Internal.EntityType_<Internal.Villager>, $$1: Internal.Level_)
        constructor($$0: Internal.EntityType_<Internal.Villager>, $$1: Internal.Level_, $$2: Internal.VillagerType_)
        getVillagerData(): Internal.VillagerData;
        restock(): void;
        handler$hak000$gobber2$gobberOccludeVibrationSignals(cir: Internal.CallbackInfoReturnable_<any>): void;
        handler$fed001$extraalchemy$writeNbt(tag: Internal.CompoundTag_, cb: Internal.CallbackInfo_): void;
        etf$getType(): Internal.EntityType<any>;
        getUpVector($$0: number): Vec3d;
        gameEvent($$0: Internal.GameEvent_, $$1: Internal.Entity_): void;
        static checkMobSpawnRules($$0: Internal.EntityType_<Internal.Mob>, $$1: Internal.LevelAccessor_, $$2: Internal.MobSpawnType_, $$3: BlockPos_, $$4: Internal.RandomSource_): boolean;
        setDefaultMovementSpeedMultiplier(speed: number): void;
        isSuppressingBounce(): boolean;
        setTarget($$0: Internal.LivingEntity_): void;
        handler$han001$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        setCulled(value: boolean): void;
        handler$leb003$puzzleslib$hurt(source: DamageSource_, amount: number, callback: Internal.CallbackInfoReturnable_<any>): void;
        isOnFire(): boolean;
        getPositionCodec(): Internal.VecDeltaCodec;
        setMaxUpStep($$0: number): void;
        updateFluidHeightAndDoFluidPushing($$0: Internal.TagKey_<Internal.Fluid>, $$1: number): boolean;
        convertTo<T extends Internal.Mob>($$0: Internal.EntityType_<T>, $$1: boolean): T;
        getFallFlyingTicks(): number;
        setPosition(x: number, y: number, z: number): void;
        runCommandSilent(command: string): number;
        chunkPosition(): Internal.ChunkPos;
        emf$isOnGround(): boolean;
        dropLeash($$0: boolean, $$1: boolean): void;
        getVariant(): Internal.VillagerType;
        gameEvent($$0: Internal.GameEvent_): void;
        setXxa($$0: number): void;
        setDelayedLeashHolderId($$0: number): void;
        isShiftKeyDown(): boolean;
        setUUID($$0: Internal.UUID_): void;
        checkBelowWorld(): void;
        handler$leb000$puzzleslib$startUsingItem(hand: Internal.InteractionHand_, callback: Internal.CallbackInfo_): void;
        setMotionZ(z: number): void;
        "deserializeNBT(net.minecraft.nbt.Tag)"(arg0: Internal.Tag_): void;
        canFreeze(): boolean;
        ignoreExplosion(): boolean;
        getBlockY(): number;
        getIsInsideStructureTracker(): Internal.IsInsideStructureTracker;
        setPlayerHitTimer(arg0: number): void;
        isSpectator(): boolean;
        getVillagerXp(): number;
        setMainHandItem(item: Internal.ItemStack_): void;
        removeEffectNoUpdate($$0: Internal.MobEffect_): Internal.MobEffectInstance;
        spawnAtLocation($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        getPersistentData(): Internal.CompoundTag;
        getHealth(): number;
        getMaxHealth(): number;
        emf$isGlowing(): boolean;
        setPathfindingMalus($$0: Internal.BlockPathTypes_, $$1: number): void;
        isRegisteredToWorld(): boolean;
        getRandomZ($$0: number): number;
        pehkui_getOnGround(): boolean;
        setAggressive($$0: boolean): void;
        handler$lef000$puzzleslib$checkDespawn(callback: Internal.CallbackInfo_): void;
        getFusionModel(layerIndex: number): Internal.Triple<any, any, any>;
        setRemoved($$0: Internal.Entity$RemovalReason_): void;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>, initializer: Internal.Supplier_<A>): A;
        getDistanceSq($$0: number, $$1: number, $$2: number): number;
        isInWaterRainOrBubble(): boolean;
        getRemovalReason(): Internal.Entity$RemovalReason;
        etf$getVelocity(): Vec3d;
        hex$markHurt(): void;
        resetFallDistance(): void;
        refreshBrain($$0: Internal.ServerLevel_): void;
        canSprint(): boolean;
        blockPosition(): BlockPos;
        setBoundingBox($$0: Internal.AABB_): void;
        isAmbientCreature(): boolean;
        static "fabric_setItemFoodValues$fabric-content-registries-v0_$md$424943$1"(arg0: Internal.Map_<any, any>): void;
        setZza($$0: number): void;
        getBlock(): Internal.BlockContainerJS;
        setEquipment(slot: Internal.EquipmentSlot_, item: Internal.ItemStack_): void;
        etf$getHandItems(): Internal.Iterable<any>;
        randomTeleport($$0: number, $$1: number, $$2: number, $$3: boolean): boolean;
        getName(): net.minecraft.network.chat.Component;
        playAmbientSound(): void;
        onGround(): boolean;
        handler$leb000$puzzleslib$canBeAffected(effectInstance: Internal.MobEffectInstance_, callback: Internal.CallbackInfoReturnable_<any>): void;
        getControlledVehicle(): Internal.Entity;
        isOnSameTeam($$0: Internal.Entity_): boolean;
        getArmorValue(): number;
        tick(): void;
        localvar$lef000$puzzleslib$setTarget(entity: Internal.LivingEntity_): Internal.LivingEntity;
        getKillCredit(): Internal.LivingEntity;
        emf$isTouchingWater(): boolean;
        emf$getVariableMap(): Internal.Object2FloatOpenHashMap<any>;
        getComponentContainer(): Internal.ComponentContainer;
        hasPermissions($$0: number): boolean;
        setVillagerData($$0: Internal.VillagerData_): void;
        getDynamicLightPrevZ(): number;
        notifyTradeUpdated($$0: Internal.ItemStack_): void;
        getUnhappyCounter(): number;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        pehkui_readScaleNbt(nbt: Internal.CompoundTag_): void;
        setVillagerXp($$0: number): void;
        setOutOfCamera(value: boolean): void;
        static createMobAttributes(): Internal.AttributeSupplier$Builder;
        isAutoSpinAttack(): boolean;
        getRemainingFireTicks(): number;
        botania_getAmbientSound(): Internal.SoundEvent;
        onlyOpCanSetNbt(): boolean;
        tcdcommons_getCustomData(): Internal.GenericProperties<any>;
        fireImmune(): boolean;
        addMotion($$0: number, $$1: number, $$2: number): void;
        getMaxFallDistance(): number;
        isHolding($$0: Internal.Item_): boolean;
        getZ($$0: number): number;
        static areAllEffectsAmbient($$0: Internal.Collection_<Internal.MobEffectInstance>): boolean;
        doHurtTarget($$0: Internal.Entity_): boolean;
        getTicksFrozen(): number;
        wrapWithCondition$kom000$porting_lib_entity$port_lib$captureDrops(level: Internal.Level_, entity: Internal.Entity_): boolean;
        handler$lef000$puzzleslib$addAdditionalSaveData(compound: Internal.CompoundTag_, callback: Internal.CallbackInfo_): void;
        deflect(chance: number, source: Internal.Entity_): boolean;
        getRandomX($$0: number): number;
        getDynamicLightZ(): number;
        spawnAtLocation($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        pick($$0: number, $$1: number, $$2: boolean): Internal.HitResult;
        getVoicePitch(): number;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        setSleepingPos($$0: BlockPos_): void;
        changeDimension(p_20118_: Internal.ServerLevel_, teleporter: Internal.ITeleporter_): Internal.Entity;
        isDescending(): boolean;
        getAttributeBaseValue($$0: Internal.Attribute_): number;
        emf$getPitch(): number;
        sendEffectToPassengers($$0: Internal.MobEffectInstance_): void;
        getHeadRotSpeed(): number;
        getLastHurtByPlayer(): Internal.Player;
        getYHeadRot(): number;
        handler$cbi000$besmirchment$isTeammate(other: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>): void;
        localvar$leb000$puzzleslib$addEffect(oldEffectInstance: Internal.MobEffectInstance_, effectInstance: Internal.MobEffectInstance_, entity: Internal.Entity_): Internal.MobEffectInstance;
        getProjectile($$0: Internal.ItemStack_): Internal.ItemStack;
        static getAlpha(le: Internal.LivingEntity_, partialTicks: number): number;
        frameworkGetDataHolder(): com.mrcrayfish.framework.entity.sync.DataHolder;
        handler$mag000$smarterfarmers$smarterFarmers$addEatingParticles(pId: number, ci: Internal.CallbackInfo_): void;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        syncPacketPositionCodec($$0: number, $$1: number, $$2: number): void;
        setAbsorptionAmount($$0: number): void;
        setRecallData(pos: Internal.DimensionalPosition_): void;
        port_lib$spawnItemParticles(arg0: Internal.ItemStack_, arg1: number): void;
        shouldRenderAtSqrDistance($$0: number): boolean;
        getAttachedOrSet<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        damageSources(): Internal.DamageSources;
        removeAttached<A>(type: Internal.AttachmentType_<A>): A;
        removeAllGoals($$0: Internal.Predicate_<Internal.Goal>): void;
        swing(): void;
        recreateFromPacket($$0: Internal.ClientboundAddEntityPacket_): void;
        setDeltaMovement($$0: Vec3d_): void;
        getLeashOffset($$0: number): Vec3d;
        isBaby(): boolean;
        isCulled(): boolean;
        damageEquipment(slot: Internal.EquipmentSlot_): void;
        isGlowing(): boolean;
        getWalkTargetValue($$0: BlockPos_): number;
        canBreatheUnderwater(): boolean;
        getLeashedByEntities(): Internal.Set<any>;
        die($$0: DamageSource_): void;
        etf$getOptifineId(): number;
        removeAllEffects(): boolean;
        dynamicLightWorld(): Internal.Level;
        getLeashOffset(): Vec3d;
        hasLineOfSight($$0: Internal.Entity_): boolean;
        hex$getLastHurt(): number;
        onClimbable(): boolean;
        isAttackable(): boolean;
        getSlot($$0: number): Internal.SlotAccess;
        shouldRestock(): boolean;
        "deserializeNBT(net.minecraft.nbt.CompoundTag)"(nbt: Internal.CompoundTag_): void;
        emf$isInLava(): boolean;
        pehkui_constructScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        static fabric_getGatherableItems(): Internal.Set<Internal.Item>;
        stopSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isUnderWater(): boolean;
        stopRiding(): void;
        getLeashHolder(): Internal.Entity;
        getX($$0: number): number;
        getSensing(): Internal.Sensing;
        localvar$kpc000$porting_lib_entity$port_lib$modifyMultiplier(multiplier: number): number;
        getLegsArmorItem(): Internal.ItemStack;
        getLuminance(): number;
        callUnsetRemoved(): void;
        captureDrops(value: Internal.Collection_<Internal.ItemEntity>): Internal.Collection<Internal.ItemEntity>;
        getSelfAndPassengers(): Internal.Stream<any>;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        handler$egi000$collective$LivingEntity_hurt(damageSource: DamageSource_, f: number, ci: Internal.CallbackInfoReturnable_<any>): void;
        getDeltaMovement(): Vec3d;
        canTakeItem($$0: Internal.ItemStack_): boolean;
        playWorkSound(): void;
        shouldDropExperience(): boolean;
        hasPassenger($$0: Internal.Entity_): boolean;
        be_getTravelerState(): Internal.TravelerState;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        getDynamicLightX(): number;
        setSecondsOnFire($$0: number): void;
        moveTo($$0: number, $$1: number, $$2: number): void;
        assignProfessionWhenSpawned(): boolean;
        emf$getZ(): number;
        "getDisplayName()"(): net.minecraft.network.chat.Component;
        getLootTable(): ResourceLocation;
        getTicksUsingItem(): number;
        bettertrims$getWornMaterials(): Internal.List<any>;
        getArrowCount(): number;
        getMoveControl(): Internal.MoveControl;
        setMotion($$0: number, $$1: number, $$2: number): void;
        playSound($$0: Internal.SoundEvent_): void;
        readInventoryFromTag($$0: Internal.CompoundTag_): void;
        getDefaultMovementSpeed(): number;
        handler$ikg000$lithium$tryShortcutFluidPushing(tag: Internal.TagKey_<any>, speed: number, cir: Internal.CallbackInfoReturnable_<any>, box: Internal.AABB_, x1: number, x2: number, y1: number, y2: number, z1: number, z2: number, zero: number): void;
        handler$hak000$gobber2$setFrozenTicks(frozenTicks: number, ci: Internal.CallbackInfo_): void;
        restoreFrom($$0: Internal.Entity_): void;
        isPeacefulCreature(): boolean;
        setOnGround($$0: boolean): void;
        addEffect($$0: Internal.MobEffectInstance_, $$1: Internal.Entity_): boolean;
        emf$getYaw(): number;
        ate(): void;
        setPos($$0: number, $$1: number, $$2: number): void;
        notify(): void;
        setPersistenceRequired(): void;
        getLastHurtByMobTimestamp(): number;
        getVehicle(): Internal.Entity;
        isEffectiveAi(): boolean;
        handler$kom000$porting_lib_entity$port_lib$startRiding(entity: Internal.Entity_, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        startRiding($$0: Internal.Entity_, $$1: boolean): boolean;
        getStringUuid(): string;
        setSwimming($$0: boolean): void;
        getMainArm(): Internal.HumanoidArm;
        checkSpawnRules($$0: Internal.LevelAccessor_, $$1: Internal.MobSpawnType_): boolean;
        getRotationVector(): Internal.Vec2;
        getHurtDir(): number;
        etf$getBlockY(): number;
        isSprinting(): boolean;
        isMaxGroupSizeReached($$0: number): boolean;
        getMotionY(): number;
        getOffhandItem(): Internal.ItemStack;
        canCollideWith($$0: Internal.Entity_): boolean;
        setLuminance(luminance: number): void;
        getBlockExplosionResistance($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.FluidState_, $$5: number): number;
        handler$hcp000$hexcasting$onThunderHit(serverLevel: Internal.ServerLevel_, lightningBolt: Internal.LightningBolt_, ci: Internal.CallbackInfo_, newWitch: Internal.Witch_): void;
        setLootTable(arg0: ResourceLocation_): void;
        clearSleepingPos(): void;
        canSpawnSprintParticle(): boolean;
        "moveTo(net.minecraft.core.BlockPos,float,float)"($$0: BlockPos_, $$1: number, $$2: number): void;
        hex$checkTotemDeathProtection(arg0: DamageSource_): boolean;
        getLastHurtMob(): Internal.LivingEntity;
        moveRelative($$0: number, $$1: Vec3d_): void;
        eatAndDigestFood(): void;
        saveAsPassenger($$0: Internal.CompoundTag_): boolean;
        static gatherClosestChunks(chunks: Internal.LongSet_, x: number, y: number, z: number): void;
        handler$kom000$porting_lib_entity$afterSave(nbt: Internal.CompoundTag_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDamageSource(): DamageSource;
        getSoundSource(): Internal.SoundSource;
        setNoActionTime($$0: number): void;
        setMovementSpeedAddition(speed: number): void;
        removeAfterChangingDimensions(): void;
        equipmentHasChanged($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        getPose(): Internal.Pose;
        showProgressBar(): boolean;
        getAttribute($$0: Internal.Attribute_): Internal.AttributeInstance;
        setPositionAndRotation($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        canBeAffected($$0: Internal.MobEffectInstance_): boolean;
        ageUp($$0: number): void;
        getRestrictCenter(): BlockPos;
        isLeftHanded(): boolean;
        invokeShouldDropLoot(): boolean;
        handler$kpc000$porting_lib_entity$port_lib$onFinishUsing(ci: Internal.CallbackInfo_, hand: Internal.InteractionHand_, result: Internal.ItemStack_): void;
        etf$getUuid(): Internal.UUID;
        removeVehicle(): void;
        shouldFusionRecomputeModel(layerIndex: number): boolean;
        modifyExpressionValue$zcl000$porting_lib_base$port_lib$canContinueUsing(original: boolean): boolean;
        setZ(z: number): void;
        getY(): number;
        deserializeNBT(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        eat($$0: Internal.Level_, $$1: Internal.ItemStack_): Internal.ItemStack;
        bookshelf$makePoofParticles(): void;
        isWithinMeleeAttackRange($$0: Internal.LivingEntity_): boolean;
        setCurrentModifyFoodPowers(powers: Internal.List_<any>): void;
        broadcastBreakEvent($$0: Internal.EquipmentSlot_): void;
        modifyExpressionValue$zhf000$additionalentityattributes$additionalEntityAttributes$modifyUpwardSwimming(original: number, fluid: Internal.TagKey_<any>): number;
        handler$nbm000$things$onShieldBlock(source: DamageSource_, cir: Internal.CallbackInfoReturnable_<any>): void;
        showVehicleHealth(): boolean;
        getDistance(pos: BlockPos_): number;
        isBlocking(): boolean;
        "getBreedOffspring(net.minecraft.server.level.ServerLevel,net.minecraft.world.entity.AgeableMob)"(arg0: Internal.ServerLevel_, arg1: Internal.AgeableMob_): Internal.AgeableMob;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number): void;
        removeAttribute(attribute: Internal.Attribute_, identifier: string): void;
        emf$getVelocity(): Vec3d;
        handler$lef000$puzzleslib$finalizeSpawn(level: Internal.ServerLevelAccessor_, difficulty: Internal.DifficultyInstance_, reason: Internal.MobSpawnType_, spawnData: Internal.SpawnGroupData_, dataTag: Internal.CompoundTag_, callback: Internal.CallbackInfoReturnable_<any>): void;
        etf$isBlockEntity(): boolean;
        getPlayerReputation($$0: Internal.Player_): number;
        shouldUpdateDynamicLight(): boolean;
        wantsMoreFood(): boolean;
        isPushedByFluid(): boolean;
        setOriginalFoodStack(original: Internal.ItemStack_): void;
        getArmorCoverPercentage(): number;
        handleRelativeFrictionAndCalculateMovement($$0: Vec3d_, $$1: number): Vec3d;
        turn($$0: number, $$1: number): void;
        getAirSupply(): number;
        isClientSide(): boolean;
        moveTo($$0: BlockPos_, $$1: number, $$2: number): void;
        isPlayer(): boolean;
        isAnimal(): boolean;
        "handler$fgd000$fabric-dimensions-v1$getTeleportTarget"(destination: Internal.ServerLevel_, cir: Internal.CallbackInfoReturnable_<any>): void;
        canBeCollidedWith(): boolean;
        getMotionDirection(): Internal.Direction;
        asComponentProvider(): Internal.ComponentProvider;
        lavaHurt(): void;
        handleDamageEvent($$0: DamageSource_): void;
        getFabricBalmData(): Internal.CompoundTag;
        canChangeDimensions(): boolean;
        static tickEntity(entity: Internal.Entity_): void;
        getCommandSenderWorld(): Internal.Level;
        getTotalMovementSpeed(): number;
        changeDimension($$0: Internal.ServerLevel_): Internal.Entity;
        localvar$zno000$apoli$modifyFallingVelocity(in_: number): number;
        handler$kom000$porting_lib_entity$afterLoad(nbt: Internal.CompoundTag_, ci: Internal.CallbackInfo_): void;
        pehkui_shouldIgnoreScaleNbt(): boolean;
        isMoving(): boolean;
        attack(hp: number): void;
        getAttributes(): Internal.AttributeMap;
        "hasPassenger(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.Entity>): boolean;
        botania_playHurtSound(arg0: DamageSource_): void;
        getDimensions($$0: Internal.Pose_): Internal.EntityDimensions;
        invokeGetLeashOffset(): Vec3d;
        isSwimming(): boolean;
        setSprinting($$0: boolean): void;
        mayInteract($$0: Internal.Level_, $$1: BlockPos_): boolean;
        handler$kpc000$porting_lib_entity$port_lib$attackEvent(source: DamageSource_, amount: number, cir: Internal.CallbackInfoReturnable_<any>): void;
        getDynamicLightLevel(): Internal.Level;
        setPortalCooldown(): void;
        getAttackAnim($$0: number): number;
        hex$setLastHurt(arg0: number): void;
        setX(x: number): void;
        getPortalWaitTime(): number;
        getBlockStateOn(): Internal.BlockState;
        wantsToPickUp($$0: Internal.ItemStack_): boolean;
        getItemBySlot($$0: Internal.EquipmentSlot_): Internal.ItemStack;
        getFluidHeightLoosely(tag: Internal.TagKey_<any>): number;
        getFluidJumpThreshold(): number;
        getCachedSouls(): number;
        "getVariant()"(): any;
        "setPositionAndRotation(double,double,double,float,float)"($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        isInvisibleTo($$0: Internal.Player_): boolean;
        stopSleeping(): void;
        setAirSupply($$0: number): void;
        getOnPos(): BlockPos;
        etf$getWorld(): Internal.Level;
        isUndead(): boolean;
        static createLivingAttributes(): Internal.AttributeSupplier$Builder;
        setUseItemRemaining(arg0: number): void;
        pehkui_getScales(): Internal.Map<any, any>;
        hasFarmSeeds(): boolean;
        getTargetSelector(): Internal.GoalSelector;
        setRegisteredToWorld(navigation: Internal.PathNavigation_): void;
        isSleeping(): boolean;
        stopUsingItem(): void;
        etf$getNbt(): Internal.CompoundTag;
        acceptsFailure(): boolean;
        etf$getBlockPos(): BlockPos;
        pehkui_setShouldIgnoreScaleNbt(ignore: boolean): void;
        setOnGroundWithKnownMovement($$0: boolean, $$1: Vec3d_): void;
        getFluidFallingAdjustedMovement($$0: number, $$1: boolean, $$2: Vec3d_): Vec3d;
        setOldPosAndRot(): void;
        localvar$cjk000$bettertridents$doHurtTarget$modifyVariable$store(damageAmount: number, entity: Internal.Entity_): number;
        isFree($$0: number, $$1: number, $$2: number): boolean;
        getDismountPoses(): Internal.ImmutableList<Internal.Pose>;
        getLastHurtMobTimestamp(): number;
        lithiumOnEquipmentChanged(): void;
        "moveTo(double,double,double)"($$0: number, $$1: number, $$2: number): void;
        setRemainingFireTicks($$0: number): void;
        emf$age(): number;
        etf$hasCustomName(): boolean;
        /**
         * @deprecated
        */
        getOnPosLegacy(): BlockPos;
        port_lib$isJumping(): boolean;
        setPos($$0: Vec3d_): void;
        localvar$leb000$puzzleslib$knockback$2(ratioX: number): number;
        static "tickEntity(net.minecraft.world.entity.LivingEntity)"(entity: Internal.LivingEntity_): void;
        updateCachedSouls(): void;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        setCanPickUpLoot($$0: boolean): void;
        getMainHandItem(): Internal.ItemStack;
        handler$kom000$porting_lib_entity$port_lib$removeRidingEntity(ci: Internal.CallbackInfo_): void;
        setSilent($$0: boolean): void;
        captureDrops(): Internal.Collection<Internal.ItemEntity>;
        hasExactlyOnePlayerPassenger(): boolean;
        canBeSeenAsEnemy(): boolean;
        setLeftHanded($$0: boolean): void;
        getActiveEffects(): Internal.Collection<Internal.MobEffectInstance>;
        isOnPortalCooldown(): boolean;
        hurtArmor($$0: DamageSource_, $$1: number): void;
        canAttack($$0: Internal.LivingEntity_, $$1: Internal.TargetingConditions_): boolean;
        getAttributeValue($$0: Internal.Holder_<Internal.Attribute>): number;
        lambdynlights$setTrackedLitChunkPos(trackedLitChunkPos: Internal.LongSet_): void;
        fzzy_core_setModifierContainer(container: Internal.ModifierContainer_): void;
        setPitch($$0: number): void;
        setPosRaw($$0: number, $$1: number, $$2: number): void;
        handleEntityEvent($$0: number): void;
        isUsingItem(): boolean;
        isAlwaysTicking(): boolean;
        interactAt($$0: Internal.Player_, $$1: Vec3d_, $$2: Internal.InteractionHand_): Internal.InteractionResult;
        emf$getX(): number;
        puzzleslib$acceptCapturedDrops(capturedDrops: Internal.Collection_<any>): Internal.Collection<any>;
        handler$hak000$gobber2$gobberIsFireImmune(cir: Internal.CallbackInfoReturnable_<any>): void;
        lerpTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: boolean): void;
        onPassengerTurned($$0: Internal.Entity_): void;
        modifyReturnValue$zhe000$additionalentityattributes$getMaxAir(original: number): number;
        spawnAtLocation($$0: Internal.ItemLike_): Internal.ItemEntity;
        emf$hasPassengers(): boolean;
        serializeNBT(): Internal.CompoundTag;
        setAttached(type: Internal.AttachmentType_<any>, value: any): any;
        port_lib$getEntityString(): string;
        markEffectsDirty(): void;
        lithiumOnBlockCacheDeleted(): void;
        "spawnAtLocation(net.minecraft.world.level.ItemLike,int)"($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        setInvulnerable($$0: boolean): void;
        push($$0: Internal.Entity_): void;
        emf$hasVehicle(): boolean;
        getGossips(): Internal.GossipContainer;
        method_5992($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        maxUpStep(): number;
        getDynamicLightPrevY(): number;
        localvar$leb000$puzzleslib$hurt$1(amount: number, source: DamageSource_): number;
        setGlowing($$0: boolean): void;
        load($$0: Internal.CompoundTag_): void;
        "getVariant()"(): Internal.VillagerType;
        "broadcastBreakEvent(net.minecraft.world.entity.EquipmentSlot)"($$0: Internal.EquipmentSlot_): void;
        setLeashedTo($$0: Internal.Entity_, $$1: boolean): void;
        isAlive(): boolean;
        startSleeping($$0: BlockPos_): void;
        getBbHeight(): number;
        getMeleeAttackRangeSqr($$0: Internal.LivingEntity_): number;
        handler$fed002$extraalchemy$readNbt(tag: Internal.CompoundTag_, cb: Internal.CallbackInfo_): void;
        bookshelf$getDrinkingSound(arg0: Internal.ItemStack_): Internal.SoundEvent;
        getTags(): Internal.Set<string>;
        getViewVector($$0: number): Vec3d;
        static setFoodPoints(map: Internal.Map_<Internal.Item, number>): void;
        getLastAttacker(): Internal.LivingEntity;
        hasControllingPassenger(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number, $$2: number): boolean;
        absMoveTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        getLastRollTicks(): number;
        getGoalSelector(): Internal.GoalSelector;
        localvar$leb000$puzzleslib$causeFallDamage$2(damageMultiplier: number): number;
        onPathfindingStart(): void;
        handler$zzb000$porting_lib_attributes$port_lib$entityGravity(travelVector: Vec3d_, ci: Internal.CallbackInfo_): void;
        getPercentFrozen(): number;
        setPortalCooldown($$0: number): void;
        hasGlowingTag(): boolean;
        shouldBlockExplode($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: number): boolean;
        emf$isInvisible(): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        isLeashed(): boolean;
        addEffect($$0: Internal.MobEffectInstance_): boolean;
        emf$isSprinting(): boolean;
        handler$leb000$puzzleslib$knockback$0(strength: number, ratioX: number, ratioZ: number, callback: Internal.CallbackInfo_): void;
        getVariant(): any;
        ageUp($$0: number, $$1: boolean): void;
        handler$egi000$collective$LivingEntity_tick(ci: Internal.CallbackInfo_): void;
        handler$gec000$faster_entity_animations$getLeaningPitch(f: number, info: Internal.CallbackInfoReturnable_<any>): void;
        canRiderInteract(): boolean;
        getViewXRot($$0: number): number;
        wantsToSpawnGolem($$0: number): boolean;
        handler$leb001$puzzleslib$die(damageSource: DamageSource_, callback: Internal.CallbackInfo_): void;
        fabric_getAttachments(): Internal.Map<any, any>;
        setPose($$0: Internal.Pose_): void;
        getReachDistance(): number;
        getEntityType(): Internal.EntityType<any>;
        isWaterCreature(): boolean;
        spawnGolemIfNeeded($$0: Internal.ServerLevel_, $$1: number, $$2: number): void;
        hex$playHurtSound(arg0: DamageSource_): void;
        pehkui_getScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        toString(): string;
        static fabric_setItemFoodValues(items: Internal.Map_<Internal.Item, number>): void;
        etf$getScoreboardTeam(): Internal.Team;
        getBreedOffspring(arg0: Internal.ServerLevel_, arg1: Internal.AgeableMob_): Internal.AgeableMob;
        setLastHurtByPlayer($$0: Internal.Player_): void;
        handler$ldh000$puzzleslib$removeVehicle(callback: Internal.CallbackInfo_): void;
        "getServer()"(): Internal.MinecraftServer;
        wasExperienceConsumed(): boolean;
        isPushable(): boolean;
        setYBodyRot($$0: number): void;
        foodEaten(is: Internal.ItemStack_): void;
        onClientRemoval(): void;
        writeInventoryToTag($$0: Internal.CompoundTag_): void;
        getDistance(x: number, y: number, z: number): number;
        setMotionY(y: number): void;
        static createAttributes(): Internal.AttributeSupplier$Builder;
        getAttached(type: Internal.AttachmentType_<any>): any;
        setRotation(yaw: number, pitch: number): void;
        isDynamicLightEnabled(): boolean;
        handler$ldh000$puzzleslib$startRiding(vehicle: Internal.Entity_, force: boolean, callback: Internal.CallbackInfoReturnable_<any>): void;
        calculateEntityAnimation($$0: boolean): void;
        forceAddEffect($$0: Internal.MobEffectInstance_, $$1: Internal.Entity_): void;
        setChestArmorItem(item: Internal.ItemStack_): void;
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        bookshelf$getHurtSound(arg0: DamageSource_): Internal.SoundEvent;
        onAboveBubbleCol($$0: boolean): void;
        archon$setOwner(uiud: string): void;
        "playSound(net.minecraft.sounds.SoundEvent,float,float)"($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        toComponentPacket(key: Internal.ComponentKey_<any>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        isPassenger(): boolean;
        getOffers(): Internal.MerchantOffers;
        hasPose($$0: Internal.Pose_): boolean;
        supp$setSlimedTicks(newSlimedTicks: number, sync: boolean): void;
        isInvulnerableTo(pSource: DamageSource_): boolean;
        isEyeInFluid($$0: Internal.TagKey_<Internal.Fluid>): boolean;
        makeStuckInBlock($$0: Internal.BlockState_, $$1: Vec3d_): void;
        getAttachedOrGet<A>(type: Internal.AttachmentType_<A>, defaultValue: Internal.Supplier_<A>): A;
        isSensitiveToWater(): boolean;
        skipAttackInteraction($$0: Internal.Entity_): boolean;
        lerpMotion($$0: number, $$1: number, $$2: number): void;
        "getAttributeValue(net.minecraft.core.Holder)"($$0: Internal.Holder_<Internal.Attribute>): number;
        shouldRender($$0: number, $$1: number, $$2: number): boolean;
        getJumpControl(): Internal.JumpControl;
        localvar$zcl000$porting_lib_base$port_lib$setSlipperiness(p: number): number;
        setOffers($$0: Internal.MerchantOffers_): void;
        getFeetArmorItem(): Internal.ItemStack;
        handler$bia000$axiom$onTurn(d: number, e: number, ci: Internal.CallbackInfo_): void;
        static getViewScale(): number;
        handler$mpg000$tcdcommons$onAddStatusEffect(effect: Internal.MobEffectInstance_, source: Internal.Entity_, ci: Internal.CallbackInfoReturnable_<any>): void;
        getVisualRotationYInDegrees(): number;
        setSpeed($$0: number): void;
        getNotifyTradeSound(): Internal.SoundEvent;
        requiresCustomPersistence(): boolean;
        handler$nbm000$things$onShieldHit(attacker: Internal.LivingEntity_, ci: Internal.CallbackInfo_): void;
        isDiscrete(): boolean;
        unRide(): void;
        getLevel(): Internal.Level;
        "spawnAtLocation(net.minecraft.world.item.ItemStack)"($$0: Internal.ItemStack_): Internal.ItemEntity;
        getCombatTracker(): Internal.CombatTracker;
        updateDynamicGameEventListener($$0: Internal.BiConsumer_<Internal.DynamicGameEventListener<any>, Internal.ServerLevel>): void;
        canBreed(): boolean;
        "onSyncedDataUpdated(net.minecraft.network.syncher.EntityDataAccessor)"($$0: Internal.EntityDataAccessor_<any>): void;
        emf$prevY(): number;
        isNoAi(): boolean;
        extinguishFire(): void;
        getChestArmorItem(): Internal.ItemStack;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number): void;
        port_lib$lastPos(): BlockPos;
        tell(message: net.minecraft.network.chat.Component_): void;
        closerThan($$0: Internal.Entity_, $$1: number): boolean;
        hex$getSoundVolume(): number;
        getDistanceSq(pos: BlockPos_): number;
        indicateDamage($$0: number, $$1: number): void;
        localvar$nbm000$things$waxGlandWater(j: number): number;
        canBeSeenByAnyone(): boolean;
        emf$getTypeString(): string;
        setVariant(arg0: any): void;
        isFullyFrozen(): boolean;
        static "fabric_getGatherableItems$fabric-content-registries-v0_$md$424943$3"(): Internal.Set<any>;
        litematica_setWorld(arg0: Internal.Level_): void;
        isInWall(): boolean;
        getAllSlots(): Internal.Iterable<Internal.ItemStack>;
        getInventory(): Internal.SimpleContainer;
        handler$bfg003$artifacts$tick(ci: Internal.CallbackInfo_): void;
        remove($$0: Internal.Entity$RemovalReason_): void;
        getScale(): number;
        isSuppressingSlidingDownLadder(): boolean;
        getBlockZ(): number;
        handler$egi000$collective$LivingEntity_die(damageSource: DamageSource_, ci: Internal.CallbackInfo_): void;
        dampensVibrations(): boolean;
        hasAttached(type: Internal.AttachmentType_<any>): boolean;
        isSilent(): boolean;
        setUseItem(arg0: Internal.ItemStack_): void;
        "playSound(net.minecraft.sounds.SoundEvent)"(id: Internal.SoundEvent_): void;
        getPitch(): number;
        getPathfindingMalus($$0: Internal.BlockPathTypes_): number;
        modify$nbm000$things$waxGlandLava(speed: number): number;
        getRandom(): Internal.RandomSource;
        canReplaceEqualItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        rotate($$0: Internal.Rotation_): number;
        handler$hcn000$hexcasting$onThunderHit(entityType: Internal.EntityType_<any>, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        getPassengersAndSelf(): Internal.Stream<any>;
        handler$leb000$puzzleslib$causeFallDamage$0(distance: number, damageMultiplier: number, damageSource: DamageSource_, callback: Internal.CallbackInfoReturnable_<any>): void;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        "getAttributeBaseValue(net.minecraft.core.Holder)"($$0: Internal.Holder_<Internal.Attribute>): number;
        method_5652($$0: Internal.CompoundTag_): void;
        clearRestriction(): void;
        redirect$jgg000$moonlight$fixSpawnAnimX(instance: Internal.Mob_, v: number): number;
        getOriginalFoodStack(): Internal.ItemStack;
        getAge(): number;
        rayTrace(): Internal.RayTraceResultJS;
        alwaysAccepts(): boolean;
        "isHolding(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.ItemStack>): boolean;
        getNoActionTime(): number;
        isVisuallyCrawling(): boolean;
        isAggressive(): boolean;
        setYya($$0: number): void;
        setDropChance($$0: Internal.EquipmentSlot_, $$1: number): void;
        handler$ieb000$lambdynlights$onRemove(ci: Internal.CallbackInfo_): void;
        "broadcastBreakEvent(net.minecraft.world.InteractionHand)"($$0: Internal.InteractionHand_): void;
        port_lib$setRemovalReason(arg0: Internal.Entity$RemovalReason_): void;
        teleportRelative($$0: number, $$1: number, $$2: number): void;
        setBaby($$0: boolean): void;
        getLastHurtByMob(): Internal.LivingEntity;
        isChasing(): boolean;
        pehkui_setScaleCache(scaleCache: Internal.ScaleData_[]): void;
        isInWaterOrBubble(): boolean;
        getPortalCooldown(): number;
        getItem(): Internal.ItemStack;
        causeFallDamage($$0: number, $$1: number, $$2: DamageSource_): boolean;
        getDynamicLightChunksToRebuild(forced: boolean): Internal.LongSet;
        releaseUsingItem(): void;
        bw_getNextAirOnLand(arg0: number): number;
        getPosition($$0: number): Vec3d;
        removeFreeWill(): void;
        handler$leb000$puzzleslib$removeAllEffects(callback: Internal.CallbackInfoReturnable_<any>): void;
        removeWhenFarAway($$0: number): boolean;
        wait(arg0: number): void;
        isIgnoringBlockTriggers(): boolean;
        setRecordPlayingNearby($$0: BlockPos_, $$1: boolean): void;
        etf$getItemsEquipped(): Internal.Iterable<any>;
        getHandHoldingItemAngle($$0: Internal.Item_): Vec3d;
        gossip($$0: Internal.ServerLevel_, $$1: Internal.Villager_, $$2: number): void;
        hasItemInSlot($$0: Internal.EquipmentSlot_): boolean;
        distanceToSqr($$0: Vec3d_): number;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        hasExcessFood(): boolean;
        modifyAttached<A>(type: Internal.AttachmentType_<A>, modifier: Internal.UnaryOperator_<A>): A;
        isSteppingCarefully(): boolean;
        handler$zno000$apoli$doSpiderClimbing(info: Internal.CallbackInfoReturnable_<any>): void;
        "spawnAtLocation(net.minecraft.world.item.ItemStack,float)"($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        getBlockX(): number;
        /**
         * @deprecated
        */
        getLightLevelDependentMagicValue(): number;
        isFallFlying(): boolean;
        getEncodeId(): string;
        puzzleslib$getSpawnType(): Internal.MobSpawnType;
        bettertrims$setAvoidedDamage(avoidDamage: boolean): void;
        getY($$0: number): number;
        emf$prevPitch(): number;
        getMaxHeadXRot(): number;
        getNbt(): Internal.CompoundTag;
        isTrading(): boolean;
        setInvisible($$0: boolean): void;
        etf$getArmorItems(): Internal.Iterable<any>;
        isSubmergedInLoosely(tag: Internal.TagKey_<any>): boolean;
        setChasing($$0: boolean): void;
        getEffect($$0: Internal.MobEffect_): Internal.MobEffectInstance;
        setTotalMovementSpeedMultiplier(speed: number): void;
        getDynamicLightY(): number;
        setHealth($$0: number): void;
        attack($$0: DamageSource_, $$1: number): boolean;
        onInsideBubbleColumn($$0: boolean): void;
        handler$cfa000$betterend$be_hurt(source: DamageSource_, amount: number, info: Internal.CallbackInfoReturnable_<any>): void;
        getEyePosition(): Vec3d;
        getEyeHeight(): number;
        setDiscardFriction($$0: boolean): void;
        hasPassenger($$0: Internal.Predicate_<Internal.Entity>): boolean;
        bettertridents$getLastDamageSource(): DamageSource;
        getYaw(): number;
        swing($$0: Internal.InteractionHand_, $$1: boolean): void;
        getUsedItemHand(): Internal.InteractionHand;
        setDefaultMovementSpeed(speed: number): void;
        canAttackType($$0: Internal.EntityType_<any>): boolean;
        hex$setLastDamageStamp(arg0: number): void;
        canEntityBeSeen(entity: Internal.LivingEntity_): boolean;
        modifyExpressionValue$zhf000$additionalentityattributes$additionalEntityAttributes$knockDownwards(original: number): number;
        getTradingPlayer(): Internal.Player;
        modify$bpk000$bclib$be_travel(moveDelta: Vec3d_): Vec3d;
        setCustomNameVisible($$0: boolean): void;
        isAlliedTo($$0: Internal.Team_): boolean;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>): A;
        canFireProjectileWeapon($$0: Internal.ProjectileWeaponItem_): boolean;
        getControllingPassenger(): Internal.LivingEntity;
        bw_getNextAirUnderwater(arg0: number): number;
        getScriptType(): Internal.ScriptType;
        handler$leb000$puzzleslib$releaseUsingItem(callback: Internal.CallbackInfo_): void;
        handler$cbm000$besmirchment$handleStatus(status: number, ci: Internal.CallbackInfo_): void;
        port_lib$getDeathSound(): Internal.SoundEvent;
        shouldDiscardFriction(): boolean;
        startRiding($$0: Internal.Entity_): boolean;
        saveWithoutId($$0: Internal.CompoundTag_): Internal.CompoundTag;
        getForward(): Vec3d;
        setFeetArmorItem(item: Internal.ItemStack_): void;
        getId(): number;
        pehkui_isFirstUpdate(): boolean;
        canBeHitByProjectile(): boolean;
        setUnhappyCounter($$0: number): void;
        getRecipientsForComponentSync(): Internal.Iterable<any>;
        handler$zcl000$porting_lib_base$port_lib$onUsingTick(ci: Internal.CallbackInfo_): void;
        getEyeY(): number;
        handler$ham000$gobber2$gobberClimbing(cir: Internal.CallbackInfoReturnable_<any>): void;
        hex$releaseAllPois(): void;
        skipDropExperience(): void;
        fabric_readAttachmentsFromNbt(nbt: Internal.CompoundTag_): void;
        localvar$leb000$puzzleslib$getVisibilityPercent(value: number, lookingEntity: Internal.Entity_): number;
        getBoundingBox(): Internal.AABB;
        isInWaterOrRain(): boolean;
        handler$leb000$puzzleslib$die$1(damageSource: DamageSource_, callback: Internal.CallbackInfo_): void;
        setItemSlot($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_): void;
        equals($$0: any): boolean;
        getViewYRot($$0: number): number;
        fabric_setCustomTeleportTarget(teleportTarget: Internal.PortalInfo_): void;
        dismountsUnderwater(): boolean;
        setTradingPlayer($$0: Internal.Player_): void;
        isAffectedByPotions(): boolean;
        playerTouch($$0: Internal.Player_): void;
        addTag($$0: string): boolean;
        getEyeHeight($$0: Internal.Pose_): number;
        getAddEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>;
        callIsBeingRainedOn(): boolean;
        static getEquipmentForSlot($$0: Internal.EquipmentSlot_, $$1: number): Internal.Item;
        isWithinRestriction($$0: BlockPos_): boolean;
        getTeam(): Internal.Team;
        static of(entity: Internal.LivingEntity_): Internal.EntityProperties;
        setTicksFrozen($$0: number): void;
        static fabric_setGatherableItems(items: Internal.Set_<Internal.Item>): void;
        getUseItem(): Internal.ItemStack;
        getMyRidingOffset(): number;
        handler$hal000$gobber2$gobberCanBreatheInWater(cir: Internal.CallbackInfoReturnable_<any>): void;
        dismountTo($$0: number, $$1: number, $$2: number): void;
        etf$getEntityKey(): string;
        etf$getPose(): Internal.Pose;
        hasCustomName(): boolean;
        getSwimAmount($$0: number): number;
        isLiving(): boolean;
        getX(): number;
        isVehicle(): boolean;
        static transfer(original: Internal.AttachmentTarget_, target: Internal.AttachmentTarget_, isDeath: boolean): void;
        overrideOffers($$0: Internal.MerchantOffers_): void;
        bettertrims$didAvoidDamage(): boolean;
        resetDynamicLight(): void;
        handler$han000$gobber2$gobberSetTarget(target: Internal.LivingEntity_, ci: Internal.CallbackInfo_): void;
        handler$kpc001$porting_lib_entity$onJump(ci: Internal.CallbackInfo_): void;
        setVariant($$0: Internal.VillagerType_): void;
        spawnAtLocation($$0: Internal.ItemStack_): Internal.ItemEntity;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        thunderHit($$0: Internal.ServerLevel_, $$1: Internal.LightningBolt_): void;
        handler$zcl000$porting_lib_base$port_lib$canBeAffected(effect: Internal.MobEffectInstance_, cir: Internal.CallbackInfoReturnable_<any>): void;
        setIsInPowderSnow($$0: boolean): void;
        etf$distanceTo(entity: Internal.Entity_): number;
        doEnchantDamageEffects($$0: Internal.LivingEntity_, $$1: Internal.Entity_): void;
        hex$tellWitnessesThatIWasMurdered(arg0: Internal.Entity_): void;
        setCustomName($$0: net.minecraft.network.chat.Component_): void;
        lambdynlights$scheduleTrackedChunksRebuild(renderer: Internal.LevelRenderer_): void;
        handler$hak000$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        getTeamId(): string;
        setStingerCount($$0: number): void;
        getMaxHeadYRot(): number;
        isCustomNameVisible(): boolean;
        isSupportedBy($$0: BlockPos_): boolean;
        getPistonPushReaction(): Internal.PushReaction;
        lookAt($$0: Internal.EntityAnchorArgument$Anchor_, $$1: Vec3d_): void;
        handler$kpc000$porting_lib_entity$port_lib$cancelFall(fallDistance: number, multiplier: number, source: DamageSource_, cir: Internal.CallbackInfoReturnable_<any>): void;
        hurtCurrentlyUsedShield($$0: number): void;
        getLootTableSeed(): number;
        collide($$0: Vec3d_): Vec3d;
        getMotionX(): number;
        "onSyncedDataUpdated(java.util.List)"($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        canBeLeashed($$0: Internal.Player_): boolean;
        hasIndirectPassenger($$0: Internal.Entity_): boolean;
        gear_core_setActiveSets(sets: Internal.HashMap_<any, any>): void;
        getEntityData(): Internal.SynchedEntityData;
        bookshelf$getFallDamageSound(arg0: number): Internal.SoundEvent;
        handleInsidePortal($$0: BlockPos_): void;
        getPotionEffects(): Internal.EntityPotionEffectsJS;
        getLastHurtByPlayerTime(): number;
        absMoveTo($$0: number, $$1: number, $$2: number): void;
        handler$cfa000$betterend$be_canBeAffected(mobEffectInstance: Internal.MobEffectInstance_, info: Internal.CallbackInfoReturnable_<any>): void;
        isOnRails(): boolean;
        getAttachedOrThrow<A>(type: Internal.AttachmentType_<A>): A;
        getStingerCount(): number;
        markFusionRecomputeModels(): void;
        getFallSounds(): Internal.LivingEntity$Fallsounds;
        getAttributeTotalValue(attribute: Internal.Attribute_): number;
        getDimensionChangingDelay(): number;
        handler$cbi000$besmirchment$getScoreboardTeam(cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDynamicLuminance(): number;
        setYaw($$0: number): void;
        getBreedOffspring($$0: Internal.ServerLevel_, $$1: Internal.AgeableMob_): this;
        getPickRadius(): number;
        isPathFinding(): boolean;
        supp$getSlimedTicks(): number;
        isRemoved(): boolean;
        emf$isSneaking(): boolean;
        teleportToWithTicket($$0: number, $$1: number, $$2: number): void;
        spawnAnim(): void;
        getJumpBoostPower(): number;
        fillCrashReportCategory($$0: Internal.CrashReportCategory_): void;
        self(): Internal.Entity;
        refreshDimensions(): void;
        pehkui_writeScaleNbt(nbt: Internal.CompoundTag_): Internal.CompoundTag;
        setStoredWerepyre(storedWerepyre: Internal.CompoundTag_): void;
        bookshelf$getAmbientSound(): Internal.SoundEvent;
        "spawnAtLocation(net.minecraft.world.level.ItemLike)"($$0: Internal.ItemLike_): Internal.ItemEntity;
        "getAttributeValue(net.minecraft.world.entity.ai.attributes.Attribute)"($$0: Internal.Attribute_): number;
        "isHolding(net.minecraft.world.item.Item)"($$0: Internal.Item_): boolean;
        setShiftKeyDown($$0: boolean): void;
        getEyePosition($$0: number): Vec3d;
        getPassengers(): Internal.EntityArrayList;
        handler$ldh000$puzzleslib$spawnAtLocation(stack: Internal.ItemStack_, offsetY: number, callback: Internal.CallbackInfoReturnable_<any>, itemEntity: Internal.ItemEntity_): void;
        getZ(): number;
        bettertrims$applyCelestialToAttackCooldown(original: number): number;
        teleportTo($$0: number, $$1: number, $$2: number): void;
        handler$zbk000$porting_lib_base$port_lib$spawnSprintParticle(ci: Internal.CallbackInfo_, pos: BlockPos_, state: Internal.BlockState_): void;
        getAttributeBaseValue($$0: Internal.Holder_<Internal.Attribute>): number;
        getServer(): Internal.MinecraftServer;
        getExperienceReward(): number;
        getFirstPassenger(): Internal.Entity;
        heal($$0: number): void;
        handler$leb01a$puzzleslib$tick(callback: Internal.CallbackInfo_): void;
        setLastHurtMob($$0: Internal.Entity_): void;
        setLastHurtByMob($$0: Internal.LivingEntity_): void;
        interact($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        getDismountLocationForPassenger($$0: Internal.LivingEntity_): Vec3d;
        checkSlowFallDistance(): void;
        getLeashingEntities(): Internal.Set<any>;
        canStandOnFluid($$0: Internal.FluidState_): boolean;
        setFabricBalmData(tag: Internal.CompoundTag_): void;
        touchingUnloadedChunk(): boolean;
        modifyAttribute(attribute: Internal.Attribute_, identifier: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getLookAngle(): Vec3d;
        modifyReturnValue$zhf000$additionalentityattributes$additionalEntityAttributes$modifyJumpVelocity(original: number): number;
        notifyTrade($$0: Internal.MerchantOffer_): void;
        getAmbientSoundInterval(): number;
        emf$isOnFire(): boolean;
        setArrowCount($$0: number): void;
        getMotionZ(): number;
        "getBreedOffspring(net.minecraft.server.level.ServerLevel,net.minecraft.world.entity.AgeableMob)"($$0: Internal.ServerLevel_, $$1: Internal.AgeableMob_): this;
        isPersistenceRequired(): boolean;
        isInvisible(): boolean;
        is($$0: Internal.Entity_): boolean;
        getBedOrientation(): Internal.Direction;
        ejectPassengers(): void;
        removeEffect($$0: Internal.MobEffect_): boolean;
        updateDynamicLightPreviousCoordinates(): void;
        getProfile(): Internal.GameProfile;
        isDeadOrDying(): boolean;
        setHeadArmorItem(item: Internal.ItemStack_): void;
        static setViewScale($$0: number): void;
        emf$isAlive(): boolean;
        take($$0: Internal.Entity_, $$1: number): void;
        setLevelCallback($$0: Internal.EntityInLevelCallback_): void;
        getLookControl(): Internal.LookControl;
        redirect$joh000$origins$method_26317Proxy(entity: Internal.LivingEntity_, d: number, bl: boolean, vec3d: Vec3d_): Vec3d;
        playSound($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        canAttack($$0: Internal.LivingEntity_): boolean;
        static getSpeedUpSecondsWhenFeeding($$0: number): number;
        getOffHandItem(): Internal.ItemStack;
        startSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isOnScoreboardTeam(teamId: string): boolean;
        startUsingItem($$0: Internal.InteractionHand_): void;
        invokePlayEquipmentBreakEffects(arg0: Internal.ItemStack_): void;
        localvar$bbb000$architectury$modifyLevelCallback_setLevelCallback(callback: Internal.EntityInLevelCallback_): Internal.EntityInLevelCallback;
        position(): Vec3d;
        setTimeout(): void;
        static getEquipmentSlotForItem($$0: Internal.ItemStack_): Internal.EquipmentSlot;
        getEquipment(slot: Internal.EquipmentSlot_): Internal.ItemStack;
        displayFireAnimation(): boolean;
        isOutOfCamera(): boolean;
        getRopeHoldPosition($$0: number): Vec3d;
        copyPosition($$0: Internal.Entity_): void;
        "hasPassenger(net.minecraft.world.entity.Entity)"($$0: Internal.Entity_): boolean;
        extraalchemy_spawnParticles(arg0: Internal.ItemStack_, arg1: number): void;
        etf$canBeBright(): boolean;
        isCrouching(): boolean;
        "getAttributeBaseValue(net.minecraft.world.entity.ai.attributes.Attribute)"($$0: Internal.Attribute_): number;
        onLeaveCombat(): void;
        wrapOperation$bgd000$artifacts$travel(block: Internal.Block_, original: Internal.Operation_<any>): number;
        setY(y: number): void;
        getAttributeValue($$0: Internal.Attribute_): number;
        getFeetBlockState(): Internal.BlockState;
        archon$isOwner(player: Internal.Player_): boolean;
        isWithinRestriction(): boolean;
        getChangeListener(): Internal.EntityInLevelCallback;
        positionRider($$0: Internal.Entity_): void;
        baseTick(): void;
        broadcastToPlayer($$0: Internal.ServerPlayer_): boolean;
        setSharedFlag($$0: number, $$1: boolean): void;
        getSleepingPos(): Optional<BlockPos>;
        damageHeldItem(): void;
        getCustomName(): net.minecraft.network.chat.Component;
        getClass(): typeof any;
        isVisuallySwimming(): boolean;
        getMaxAirSupply(): number;
        handler$zcl000$porting_lib_base$port_lib$addEffect(newEffect: Internal.MobEffectInstance_, source: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>, oldEffect: Internal.MobEffectInstance_): void;
        setItemInHand($$0: Internal.InteractionHand_, $$1: Internal.ItemStack_): void;
        dynamicLightTick(): void;
        setMaxHealth(hp: number): void;
        getFacing(): Internal.Direction;
        emf$isWet(): boolean;
        isPassengerOfSameVehicle($$0: Internal.Entity_): boolean;
        getBoundingBoxForCulling(): Internal.AABB;
        setAge($$0: number): void;
        getTarget(): Internal.LivingEntity;
        static collideBoundingBox(entity: Internal.Entity_, movement: Vec3d_, entityBoundingBox: Internal.AABB_, world: Internal.Level_, collisions: Internal.List_<any>): Vec3d;
        fzzy_core_getModifierContainer(): Internal.ModifierContainer;
        restrictTo($$0: BlockPos_, $$1: number): void;
        trackingPosition(): Vec3d;
        getNameTagOffsetY(): number;
        isInvulnerable(): boolean;
        isInLava(): boolean;
        isInWater(): boolean;
        awardKillScore($$0: Internal.Entity_, $$1: number, $$2: DamageSource_): void;
        finalizeSpawn($$0: Internal.ServerLevelAccessor_, $$1: Internal.DifficultyInstance_, $$2: Internal.MobSpawnType_, $$3: Internal.SpawnGroupData_, $$4: Internal.CompoundTag_): Internal.SpawnGroupData;
        localvar$leb000$puzzleslib$knockback$3(ratioZ: number): number;
        overrideXp($$0: number): void;
        unsetRemoved(): void;
        pehkui_getScaleCache(): Internal.ScaleData[];
        swing($$0: Internal.InteractionHand_): void;
        hasEffect($$0: Internal.MobEffect_): boolean;
        getHeldItem(hand: Internal.InteractionHand_): Internal.ItemStack;
        setFusionModel(layerIndex: number, model: Internal.Triple_<any, any, any>): void;
        getRootVehicle(): Internal.Entity;
        onPathfindingDone(): void;
        save($$0: Internal.CompoundTag_): boolean;
        archon$setLifetime(seconds: number): void;
        modify$zhf000$additionalentityattributes$additionalEntityAttributes$waterSpeed(original: number): number;
        getLocalBoundsForPose($$0: Internal.Pose_): Internal.AABB;
        isNoGravity(): boolean;
        dodge(chance: number): boolean;
        onItemPickup($$0: Internal.ItemEntity_): void;
        hex$setLastDamageSource(arg0: DamageSource_): void;
        emf$getY(): number;
        handler$kom000$porting_lib_entity$port_lib$entityInit(entityType: Internal.EntityType_<any>, world: Internal.Level_, ci: Internal.CallbackInfo_): void;
        bookshelf$createHoverEvent(): Internal.HoverEvent;
        updateSwimming(): void;
        isHolding($$0: Internal.Predicate_<Internal.ItemStack>): boolean;
        getSpeed(): number;
        abstract getCachedFeetBlockState(): Internal.BlockState;
        shouldInformAdmins(): boolean;
        rideTick(): void;
        port_lib$onEffectRemoved(arg0: Internal.MobEffectInstance_): void;
        handler$zll000$amethyst_imbuement$onAttackWhilstStunnedNoTarget(hand: Internal.InteractionHand_, ci: Internal.CallbackInfo_): void;
        wait(): void;
        getUuid(): Internal.UUID;
        playCelebrateSound(): void;
        setOffHandItem(item: Internal.ItemStack_): void;
        spawn(): void;
        setNoAi($$0: boolean): void;
        teleportTo($$0: Internal.ServerLevel_, $$1: number, $$2: number, $$3: number, $$4: Internal.Set_<Internal.RelativeMovement>, $$5: number, $$6: number): boolean;
        etf$getCustomName(): net.minecraft.network.chat.Component;
        fabric_writeAttachmentsToNbt(nbt: Internal.CompoundTag_): void;
        shouldShowName(): boolean;
        getArmorSlots(): Internal.Iterable<Internal.ItemStack>;
        canPickUpLoot(): boolean;
        kill(): void;
        onEnterCombat(): void;
        updateNavigationRegistration(): void;
        animateHurt($$0: number): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        handler$kom000$porting_lib_entity$port_lib$onEntityRemove(reason: Internal.Entity$RemovalReason_, ci: Internal.CallbackInfo_): void;
        static resetForwardDirectionOfRelativePortalPosition($$0: Vec3d_): Vec3d;
        callGetEyeHeight(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        onReputationEventFrom($$0: Internal.ReputationEventType_, $$1: Internal.Entity_): void;
        hasRestriction(): boolean;
        getHeadArmorItem(): Internal.ItemStack;
        deserializeNBT(arg0: Internal.Tag_): void;
        getCurrentModifyFoodPowers(): Internal.List<any>;
        getBbWidth(): number;
        splitIntoDynamicLightEntries(): Internal.Stream<Internal.SpatialLookupEntry>;
        addDeltaMovement($$0: Vec3d_): void;
        pehkui_setOnGround(onGround: boolean): void;
        localvar$leb000$puzzleslib$knockback$1(strength: number): number;
        bettertrims$addLateAttributes(adder: Internal.Consumer_<any>): void;
        static setFoodPoints$smarterfarmers_$md$424943$4(arg0: Internal.Map_<any, any>): void;
        handler$lef000$puzzleslib$readAdditionalSaveData(compound: Internal.CompoundTag_, callback: Internal.CallbackInfo_): void;
        sendLeashState(): void;
        "getName()"(): net.minecraft.network.chat.Component;
        mirror($$0: Internal.Mirror_): number;
        static port_lib$collideWithShapes(vec3: Vec3d_, aABB: Internal.AABB_, list: Internal.List_<Internal.VoxelShape>): Vec3d;
        knockback($$0: number, $$1: number, $$2: number): void;
        getTicksRequiredToFreeze(): number;
        getVisibilityPercent($$0: Internal.Entity_): number;
        getMaxSpawnClusterSize(): number;
        localvar$kpc000$porting_lib_entity$port_lib$modifyDistance(fallDistance: number): number;
        artifacts$getPocketPistonLength(): number;
        emf$prevZ(): number;
        getBrain(): Internal.Brain<Internal.Villager>;
        getUsername(): string;
        move($$0: Internal.MoverType_, $$1: Vec3d_): void;
        "setVariant(java.lang.Object)"(arg0: any): void;
        lithiumOnBlockCacheSet(newState: Internal.BlockState_): void;
        isPickable(): boolean;
        setYHeadRot($$0: number): void;
        setJumping($$0: boolean): void;
        getCustomData(): Internal.CompoundTag;
        handler$zno000$apoli$getGroup(info: Internal.CallbackInfoReturnable_<any>): void;
        getPickResult(): Internal.ItemStack;
        "getMainHandItem()"(): Internal.ItemStack;
        getAbsorptionAmount(): number;
        getRandomY(): number;
        onEffectRemoved($$0: Internal.MobEffectInstance_): void;
        getDisplayName(): net.minecraft.network.chat.Component;
        static "tickEntity(net.minecraft.world.entity.Entity)"(entity: Internal.Entity_): void;
        getMobType(): Internal.MobType;
        travel($$0: Vec3d_): void;
        getItemInHand($$0: Internal.InteractionHand_): Internal.ItemStack;
        localvar$leb000$puzzleslib$hurt$0(amount: number, source: DamageSource_): number;
        getDynamicLightPrevX(): number;
        shouldBeSaved(): boolean;
        fabric_hasPersistentAttachments(): boolean;
        method_5749($$0: Internal.CompoundTag_): void;
        hurtHelmet($$0: DamageSource_, $$1: number): void;
        removeTag($$0: string): boolean;
        static pickUpItem($$0: Internal.Mob_, $$1: Internal.InventoryCarrier_, $$2: Internal.ItemEntity_): void;
        isHoldingInAnyHand(i: Internal.Ingredient_): boolean;
        getFluidHeight($$0: Internal.TagKey_<Internal.Fluid>): number;
        canSpawnSoulSpeedParticle(): boolean;
        notifyAll(): void;
        aiStep(): void;
        handler$leb000$puzzleslib$removeEffect(effect: Internal.MobEffect_, callback: Internal.CallbackInfoReturnable_<any>): void;
        getPassengersRidingOffset(): number;
        setAttributeBaseValue(attribute: Internal.Attribute_, value: number): void;
        offerScale(gobberForce: number): number;
        distanceToEntitySqr($$0: Internal.Entity_): number;
        releasePoi($$0: Internal.MemoryModuleType_<Internal.GlobalPos>): void;
        isFrame(): boolean;
        broadcastBreakEvent($$0: Internal.InteractionHand_): void;
        setLegsArmorItem(item: Internal.ItemStack_): void;
        localvar$leb000$puzzleslib$causeFallDamage$1(fallDistance: number): number;
        discard(): void;
        "handler$mhe000$step-height-entity-attribute$getStepHeight"(cir: Internal.CallbackInfoReturnable_<any>): void;
        sendSystemMessage($$0: net.minecraft.network.chat.Component_): void;
        acceptsSuccess(): boolean;
        static tickEntity(entity: Internal.LivingEntity_): void;
        setNoGravity($$0: boolean): void;
        getUseItemRemainingTicks(): number;
        gear_core_getActiveSets(): Internal.HashMap<any, any>;
        setGossips($$0: Internal.Tag_): void;
        getIndirectPassengers(): Internal.Iterable<any>;
        attackable(): boolean;
        createCommandSourceStack(): Internal.CommandSourceStack;
        getNavigation(): Internal.PathNavigation;
        isControlledByLocalInstance(): boolean;
        isMonster(): boolean;
        pehkui_setShouldSyncScales(sync: boolean): void;
        handler$cbm000$besmirchment$canTarget(type: Internal.EntityType_<any>, cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastClimbablePos(): Optional<BlockPos>;
        getEatingSound($$0: Internal.ItemStack_): Internal.SoundEvent;
        setLastDynamicLuminance(luminance: number): void;
        getPerceivedTargetDistanceSquareForMeleeAttack($$0: Internal.LivingEntity_): number;
        setId($$0: number): void;
        onSyncedDataUpdated($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        getHorizontalFacing(): Internal.Direction;
        getType(): string;
        isDamageSourceBlocked($$0: DamageSource_): boolean;
        getLightProbePosition($$0: number): Vec3d;
        getActiveEffectsMap(): Internal.Map<Internal.MobEffect, Internal.MobEffectInstance>;
        wrapOperation$mac000$smarterfarmers$smarterFarmers$overrideMobGriefing(instance: Internal.GameRules_, key: Internal.GameRules$Key_<any>, original: Internal.Operation_<any>): boolean;
        emf$prevX(): number;
        onEquipItem($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_, $$2: Internal.ItemStack_): void;
        openTradingScreen($$0: Internal.Player_, $$1: net.minecraft.network.chat.Component_, $$2: number): void;
        checkDespawn(): void;
        pehkui_shouldSyncScales(): boolean;
        getWalkTargetValue($$0: BlockPos_, $$1: Internal.LevelReader_): number;
        lookAt($$0: Internal.Entity_, $$1: number, $$2: number): void;
        setHeldItem(hand: Internal.InteractionHand_, item: Internal.ItemStack_): void;
        port_lib$maybeDisableShield(arg0: Internal.Player_, arg1: Internal.ItemStack_, arg2: Internal.ItemStack_): void;
        equipItemIfPossible($$0: Internal.ItemStack_): Internal.ItemStack;
        onSyncedDataUpdated($$0: Internal.EntityDataAccessor_<any>): void;
        lerpHeadTo($$0: number, $$1: number): void;
        canDisableShield(): boolean;
        setMotionX(x: number): void;
        getHandSlots(): Internal.Iterable<Internal.ItemStack>;
        distanceToEntity($$0: Internal.Entity_): number;
        bookshelf$getDeathSound(): Internal.SoundEvent;
        "setVariant(net.minecraft.world.entity.npc.VillagerType)"($$0: Internal.VillagerType_): void;
        wait(arg0: number, arg1: number): void;
        getTeamColor(): number;
        lithiumSetClimbingMobCachingSectionUpdateBehavior(listenForCachedBlockChanges: boolean): void;
        setNbt(nbt: Internal.CompoundTag_): void;
        lambdynlights$getTrackedLitChunkPos(): Internal.LongSet;
        checkSpawnObstruction($$0: Internal.LevelReader_): boolean;
        getRecallPosition(): Internal.DimensionalPosition;
        extinguish(): void;
        setDynamicLightEnabled(enabled: boolean): void;
        getRestrictRadius(): number;
        moveTo($$0: Vec3d_): void;
        isColliding($$0: BlockPos_, $$1: Internal.BlockState_): boolean;
        "swing(net.minecraft.world.InteractionHand)"($$0: Internal.InteractionHand_): void;
        lambdynlights$updateDynamicLight(renderer: Internal.LevelRenderer_): boolean;
        canRestock(): boolean;
        getRegisteredNavigation(): Internal.PathNavigation;
        bettertrims$isWearing(effect: Internal.TrimEffect_): boolean;
        static port_lib$collideWithShapes$porting_lib_accessors_$md$424943$0(arg0: Vec3d_, arg1: Internal.AABB_, arg2: Internal.List_<any>): Vec3d;
        isForcedVisible(): boolean;
        isInvertedHealAndHarm(): boolean;
        handler$jon000$origins$doWaterBreathing(info: Internal.CallbackInfoReturnable_<any>): void;
        canHoldItem($$0: Internal.ItemStack_): boolean;
        killedEntity($$0: Internal.ServerLevel_, $$1: Internal.LivingEntity_): boolean;
        getAttachedOrElse<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        static "fabric_setGatherableItems$fabric-content-registries-v0_$md$424943$2"(arg0: Internal.Set_<any>): void;
        isFreezing(): boolean;
        runCommand(command: string): number;
        hex$getDeathSound(): Internal.SoundEvent;
        setGuaranteedDrop($$0: Internal.EquipmentSlot_): void;
        setSharedFlagOnFire($$0: boolean): void;
        get villagerData(): Internal.VillagerData
        set defaultMovementSpeedMultiplier(speed: number)
        get suppressingBounce(): boolean
        set target($$0: Internal.LivingEntity_)
        set culled(value: boolean)
        get onFire(): boolean
        get positionCodec(): Internal.VecDeltaCodec
        set maxUpStep($$0: number)
        get fallFlyingTicks(): number
        get variant(): Internal.VillagerType
        set xxa($$0: number)
        set delayedLeashHolderId($$0: number)
        get shiftKeyDown(): boolean
        set UUID($$0: Internal.UUID_)
        set motionZ(z: number)
        get blockY(): number
        get isInsideStructureTracker(): Internal.IsInsideStructureTracker
        set playerHitTimer(arg0: number)
        get spectator(): boolean
        get villagerXp(): number
        set mainHandItem(item: Internal.ItemStack_)
        get persistentData(): Internal.CompoundTag
        get health(): number
        get maxHealth(): number
        get registeredToWorld(): boolean
        set aggressive($$0: boolean)
        set removed($$0: Internal.Entity$RemovalReason_)
        get inWaterRainOrBubble(): boolean
        get removalReason(): Internal.Entity$RemovalReason
        set boundingBox($$0: Internal.AABB_)
        get ambientCreature(): boolean
        set zza($$0: number)
        get block(): Internal.BlockContainerJS
        get name(): net.minecraft.network.chat.Component
        get controlledVehicle(): Internal.Entity
        get armorValue(): number
        get killCredit(): Internal.LivingEntity
        get componentContainer(): Internal.ComponentContainer
        set villagerData($$0: Internal.VillagerData_)
        get dynamicLightPrevZ(): number
        get unhappyCounter(): number
        set villagerXp($$0: number)
        set outOfCamera(value: boolean)
        get autoSpinAttack(): boolean
        get remainingFireTicks(): number
        get maxFallDistance(): number
        get ticksFrozen(): number
        get dynamicLightZ(): number
        get voicePitch(): number
        set statusMessage(message: net.minecraft.network.chat.Component_)
        set sleepingPos($$0: BlockPos_)
        get descending(): boolean
        get headRotSpeed(): number
        get lastHurtByPlayer(): Internal.Player
        get YHeadRot(): number
        set absorptionAmount($$0: number)
        set recallData(pos: Internal.DimensionalPosition_)
        set deltaMovement($$0: Vec3d_)
        get baby(): boolean
        get culled(): boolean
        get glowing(): boolean
        get leashedByEntities(): Internal.Set<any>
        get leashOffset(): Vec3d
        get attackable(): boolean
        get underWater(): boolean
        get leashHolder(): Internal.Entity
        get sensing(): Internal.Sensing
        get legsArmorItem(): Internal.ItemStack
        get luminance(): number
        get selfAndPassengers(): Internal.Stream<any>
        get deltaMovement(): Vec3d
        get dynamicLightX(): number
        set secondsOnFire($$0: number)
        get "displayName()"(): net.minecraft.network.chat.Component
        get lootTable(): ResourceLocation
        get ticksUsingItem(): number
        get arrowCount(): number
        get moveControl(): Internal.MoveControl
        get defaultMovementSpeed(): number
        get peacefulCreature(): boolean
        set onGround($$0: boolean)
        get lastHurtByMobTimestamp(): number
        get vehicle(): Internal.Entity
        get effectiveAi(): boolean
        get stringUuid(): string
        set swimming($$0: boolean)
        get mainArm(): Internal.HumanoidArm
        get rotationVector(): Internal.Vec2
        get hurtDir(): number
        get sprinting(): boolean
        get motionY(): number
        get offhandItem(): Internal.ItemStack
        set luminance(luminance: number)
        set lootTable(arg0: ResourceLocation_)
        get lastHurtMob(): Internal.LivingEntity
        get lastDamageSource(): DamageSource
        get soundSource(): Internal.SoundSource
        set noActionTime($$0: number)
        set movementSpeedAddition(speed: number)
        get pose(): Internal.Pose
        get restrictCenter(): BlockPos
        get leftHanded(): boolean
        set z(z: number)
        get y(): number
        set currentModifyFoodPowers(powers: Internal.List_<any>)
        get blocking(): boolean
        get pushedByFluid(): boolean
        set originalFoodStack(original: Internal.ItemStack_)
        get armorCoverPercentage(): number
        get airSupply(): number
        get clientSide(): boolean
        get player(): boolean
        get animal(): boolean
        get motionDirection(): Internal.Direction
        get fabricBalmData(): Internal.CompoundTag
        get commandSenderWorld(): Internal.Level
        get totalMovementSpeed(): number
        get moving(): boolean
        get attributes(): Internal.AttributeMap
        get swimming(): boolean
        set sprinting($$0: boolean)
        get dynamicLightLevel(): Internal.Level
        set x(x: number)
        get portalWaitTime(): number
        get blockStateOn(): Internal.BlockState
        get fluidJumpThreshold(): number
        get cachedSouls(): number
        get "variant()"(): any
        set airSupply($$0: number)
        get onPos(): BlockPos
        get undead(): boolean
        set useItemRemaining(arg0: number)
        get targetSelector(): Internal.GoalSelector
        set registeredToWorld(navigation: Internal.PathNavigation_)
        get sleeping(): boolean
        get dismountPoses(): Internal.ImmutableList<Internal.Pose>
        get lastHurtMobTimestamp(): number
        set remainingFireTicks($$0: number)
        /**
         * @deprecated
        */
        get onPosLegacy(): BlockPos
        set pos($$0: Vec3d_)
        set canPickUpLoot($$0: boolean)
        get mainHandItem(): Internal.ItemStack
        set silent($$0: boolean)
        set leftHanded($$0: boolean)
        get activeEffects(): Internal.Collection<Internal.MobEffectInstance>
        get onPortalCooldown(): boolean
        set pitch($$0: number)
        get usingItem(): boolean
        get alwaysTicking(): boolean
        set invulnerable($$0: boolean)
        get gossips(): Internal.GossipContainer
        get dynamicLightPrevY(): number
        set glowing($$0: boolean)
        get "variant()"(): Internal.VillagerType
        get alive(): boolean
        get bbHeight(): number
        get tags(): Internal.Set<string>
        set foodPoints(map: Internal.Map_<Internal.Item, number>)
        get lastAttacker(): Internal.LivingEntity
        get lastRollTicks(): number
        get goalSelector(): Internal.GoalSelector
        get percentFrozen(): number
        set portalCooldown($$0: number)
        set position(block: Internal.BlockContainerJS_)
        get leashed(): boolean
        get variant(): any
        set pose($$0: Internal.Pose_)
        get reachDistance(): number
        get entityType(): Internal.EntityType<any>
        get waterCreature(): boolean
        set lastHurtByPlayer($$0: Internal.Player_)
        get "server()"(): Internal.MinecraftServer
        get pushable(): boolean
        set YBodyRot($$0: number)
        set motionY(y: number)
        get dynamicLightEnabled(): boolean
        set chestArmorItem(item: Internal.ItemStack_)
        get passenger(): boolean
        get offers(): Internal.MerchantOffers
        get sensitiveToWater(): boolean
        get jumpControl(): Internal.JumpControl
        set offers($$0: Internal.MerchantOffers_)
        get feetArmorItem(): Internal.ItemStack
        get viewScale(): number
        get visualRotationYInDegrees(): number
        set speed($$0: number)
        get notifyTradeSound(): Internal.SoundEvent
        get discrete(): boolean
        get level(): Internal.Level
        get combatTracker(): Internal.CombatTracker
        get noAi(): boolean
        get chestArmorItem(): Internal.ItemStack
        set variant(arg0: any)
        get fullyFrozen(): boolean
        get inWall(): boolean
        get allSlots(): Internal.Iterable<Internal.ItemStack>
        get inventory(): Internal.SimpleContainer
        get scale(): number
        get suppressingSlidingDownLadder(): boolean
        get blockZ(): number
        get silent(): boolean
        set useItem(arg0: Internal.ItemStack_)
        get pitch(): number
        get random(): Internal.RandomSource
        get passengersAndSelf(): Internal.Stream<any>
        get originalFoodStack(): Internal.ItemStack
        get age(): number
        get noActionTime(): number
        get visuallyCrawling(): boolean
        get aggressive(): boolean
        set yya($$0: number)
        set baby($$0: boolean)
        get lastHurtByMob(): Internal.LivingEntity
        get chasing(): boolean
        get inWaterOrBubble(): boolean
        get portalCooldown(): number
        get item(): Internal.ItemStack
        get ignoringBlockTriggers(): boolean
        get steppingCarefully(): boolean
        get blockX(): number
        /**
         * @deprecated
        */
        get lightLevelDependentMagicValue(): number
        get fallFlying(): boolean
        get encodeId(): string
        get maxHeadXRot(): number
        get nbt(): Internal.CompoundTag
        get trading(): boolean
        set invisible($$0: boolean)
        set chasing($$0: boolean)
        set totalMovementSpeedMultiplier(speed: number)
        get dynamicLightY(): number
        set health($$0: number)
        get eyePosition(): Vec3d
        get eyeHeight(): number
        set discardFriction($$0: boolean)
        get yaw(): number
        get usedItemHand(): Internal.InteractionHand
        set defaultMovementSpeed(speed: number)
        get tradingPlayer(): Internal.Player
        set customNameVisible($$0: boolean)
        get controllingPassenger(): Internal.LivingEntity
        get scriptType(): Internal.ScriptType
        get forward(): Vec3d
        set feetArmorItem(item: Internal.ItemStack_)
        get id(): number
        set unhappyCounter($$0: number)
        get recipientsForComponentSync(): Internal.Iterable<any>
        get eyeY(): number
        get boundingBox(): Internal.AABB
        get inWaterOrRain(): boolean
        set tradingPlayer($$0: Internal.Player_)
        get affectedByPotions(): boolean
        get addEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>
        get team(): Internal.Team
        set ticksFrozen($$0: number)
        get useItem(): Internal.ItemStack
        get myRidingOffset(): number
        get living(): boolean
        get x(): number
        get vehicle(): boolean
        set variant($$0: Internal.VillagerType_)
        set isInPowderSnow($$0: boolean)
        set customName($$0: net.minecraft.network.chat.Component_)
        get teamId(): string
        set stingerCount($$0: number)
        get maxHeadYRot(): number
        get customNameVisible(): boolean
        get pistonPushReaction(): Internal.PushReaction
        get lootTableSeed(): number
        get motionX(): number
        get entityData(): Internal.SynchedEntityData
        get potionEffects(): Internal.EntityPotionEffectsJS
        get lastHurtByPlayerTime(): number
        get onRails(): boolean
        get stingerCount(): number
        get fallSounds(): Internal.LivingEntity$Fallsounds
        get dimensionChangingDelay(): number
        get lastDynamicLuminance(): number
        set yaw($$0: number)
        get pickRadius(): number
        get pathFinding(): boolean
        get removed(): boolean
        get jumpBoostPower(): number
        set storedWerepyre(storedWerepyre: Internal.CompoundTag_)
        set shiftKeyDown($$0: boolean)
        get passengers(): Internal.EntityArrayList
        get z(): number
        get server(): Internal.MinecraftServer
        get experienceReward(): number
        get firstPassenger(): Internal.Entity
        set lastHurtMob($$0: Internal.Entity_)
        set lastHurtByMob($$0: Internal.LivingEntity_)
        get leashingEntities(): Internal.Set<any>
        set fabricBalmData(tag: Internal.CompoundTag_)
        get lookAngle(): Vec3d
        get ambientSoundInterval(): number
        set arrowCount($$0: number)
        get motionZ(): number
        get persistenceRequired(): boolean
        get invisible(): boolean
        get bedOrientation(): Internal.Direction
        get profile(): Internal.GameProfile
        get deadOrDying(): boolean
        set headArmorItem(item: Internal.ItemStack_)
        set viewScale($$0: number)
        set levelCallback($$0: Internal.EntityInLevelCallback_)
        get lookControl(): Internal.LookControl
        get offHandItem(): Internal.ItemStack
        get outOfCamera(): boolean
        get crouching(): boolean
        set y(y: number)
        get feetBlockState(): Internal.BlockState
        get withinRestriction(): boolean
        get changeListener(): Internal.EntityInLevelCallback
        get sleepingPos(): Optional<BlockPos>
        get customName(): net.minecraft.network.chat.Component
        get class(): typeof any
        get visuallySwimming(): boolean
        get maxAirSupply(): number
        set maxHealth(hp: number)
        get facing(): Internal.Direction
        get boundingBoxForCulling(): Internal.AABB
        set age($$0: number)
        get target(): Internal.LivingEntity
        get nameTagOffsetY(): number
        get invulnerable(): boolean
        get inLava(): boolean
        get inWater(): boolean
        get rootVehicle(): Internal.Entity
        get noGravity(): boolean
        get speed(): number
        get cachedFeetBlockState(): Internal.BlockState
        get uuid(): Internal.UUID
        set offHandItem(item: Internal.ItemStack_)
        set noAi($$0: boolean)
        get armorSlots(): Internal.Iterable<Internal.ItemStack>
        get headArmorItem(): Internal.ItemStack
        get currentModifyFoodPowers(): Internal.List<any>
        get bbWidth(): number
        set foodPoints$smarterfarmers_$md$424943$4(arg0: Internal.Map_<any, any>)
        get "name()"(): net.minecraft.network.chat.Component
        get ticksRequiredToFreeze(): number
        get maxSpawnClusterSize(): number
        get brain(): Internal.Brain<Internal.Villager>
        get username(): string
        set "variant(java.lang.Object)"(arg0: any)
        get pickable(): boolean
        set YHeadRot($$0: number)
        set jumping($$0: boolean)
        get customData(): Internal.CompoundTag
        get pickResult(): Internal.ItemStack
        get "mainHandItem()"(): Internal.ItemStack
        get absorptionAmount(): number
        get randomY(): number
        get displayName(): net.minecraft.network.chat.Component
        get mobType(): Internal.MobType
        get dynamicLightPrevX(): number
        get passengersRidingOffset(): number
        get frame(): boolean
        set legsArmorItem(item: Internal.ItemStack_)
        set noGravity($$0: boolean)
        get useItemRemainingTicks(): number
        set gossips($$0: Internal.Tag_)
        get indirectPassengers(): Internal.Iterable<any>
        get navigation(): Internal.PathNavigation
        get controlledByLocalInstance(): boolean
        get monster(): boolean
        get lastClimbablePos(): Optional<BlockPos>
        set lastDynamicLuminance(luminance: number)
        set id($$0: number)
        get horizontalFacing(): Internal.Direction
        get type(): string
        get activeEffectsMap(): Internal.Map<Internal.MobEffect, Internal.MobEffectInstance>
        set motionX(x: number)
        get handSlots(): Internal.Iterable<Internal.ItemStack>
        set "variant(net.minecraft.world.entity.npc.VillagerType)"($$0: Internal.VillagerType_)
        get teamColor(): number
        set nbt(nbt: Internal.CompoundTag_)
        get recallPosition(): Internal.DimensionalPosition
        set dynamicLightEnabled(enabled: boolean)
        get restrictRadius(): number
        get registeredNavigation(): Internal.PathNavigation
        get forcedVisible(): boolean
        get invertedHealAndHarm(): boolean
        get freezing(): boolean
        set guaranteedDrop($$0: Internal.EquipmentSlot_)
        set sharedFlagOnFire($$0: boolean)
        static FOOD_POINTS: ({[key: vectorwing.farmersdelight.common.item.ConsumableItem]: 4, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 9, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 9, [key: Internal.Item]: 1, [key: Internal.Item]: 4, [key: Internal.Item]: 3, [key: Internal.Item]: 1, [key: Internal.Item]: 1, [key: Internal.Item]: 2, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 2, [key: Internal.SpringRollsItem]: 4, [key: Internal.Item]: 2, [key: Internal.ItemBowlFood]: 4, [key: Internal.Item]: 4, [key: Internal.Item]: 5, [key: Internal.TooltippedItem]: 7, [key: Internal.ModelProviderItem]: 5, [key: Internal.ItemNameBlockItem]: 1, [key: Internal.Item]: 1, [key: Internal.Item]: 1, [key: Internal.Item]: 1, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 9, [key: Internal.Item]: 2, [key: Internal.FoodItemWithBlock]: 4, [key: Internal.Item]: 3, [key: Internal.Item]: 3, [key: Internal.Item]: 1, [key: Internal.Item]: 1, [key: Internal.Item]: 1, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 2, [key: Internal.Item]: 1, [key: Internal.Item]: 4, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 8, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 9, [key: Internal.Item]: 1, [key: Internal.ItemNameBlockItem]: 1, [key: Internal.Item]: 2, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 9, [key: Internal.GooeyBread]: 6, [key: Internal.Item]: 1, [key: Internal.Item]: 2, [key: Internal.Item]: 6, [key: Internal.ManaBerriesItem]: 1, [key: Internal.Item]: 1, [key: Internal.Item]: 2, [key: Internal.ModelProviderItem]: 5, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 4, [key: Internal.BaseDrinkItem]: 3, [key: Internal.Item]: 2, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 3, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 3, [key: Internal.Item]: 5, [key: Internal.Item]: 2, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 9, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 9, [key: Internal.ModelProviderItem]: 4, [key: Internal.ItemNameBlockItem]: 1, [key: Internal.Item]: 6, [key: Internal.Item]: 2, [key: Internal.Item]: 1, [key: Internal.ConsumableItem]: 5, [key: Internal.Item]: 2, [key: Internal.ItemNameBlockItem]: 1, [key: Internal.NetherItems$1]: 1, [key: Internal.ModelProviderItem]: 2, [key: Internal.Item]: 4, [key: Internal.Item]: 1, [key: Internal.ChorusFruitItem]: 2, [key: Internal.NetherItems$1]: 1, [key: Internal.Item]: 2, [key: Internal.MagmaGelatinItem]: 1, [key: Internal.PricklyPearItem]: 2, [key: Internal.Item]: 2, [key: Internal.GooeyBread]: 5, [key: Internal.GooeyApple]: 5, [key: Internal.Item]: 1, [key: Internal.KelpRollItem]: 8, [key: Internal.ModelProviderItem]: 4, [key: Internal.TooltippedItem]: 6, [key: Internal.Item]: 1, [key: Internal.Item]: 6, [key: Internal.ModelProviderItem]: 1, [key: Internal.Item]: 2, [key: Internal.Item]: 2, [key: Internal.Item]: 2, [key: Internal.Goo]: 4, [key: Internal.Item]: 1, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 2, [key: Internal.TooltippedItem]: 4, [key: Internal.Item]: 5, [key: Internal.GrotestqueStewItem]: 5, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 2, [key: Internal.Item]: 1, [key: Internal.Item]: 2, [key: Internal.ChristmasTeaItem]: 1, [key: Internal.Item]: 5, [key: Internal.Item]: 2, [key: Internal.Item]: 2, [key: Internal.Item]: 2, [key: Internal.Item]: 7, [key: Internal.Item]: 1, [key: Internal.Item]: 2, [key: Internal.Item]: 2, [key: Internal.Item]: 4, [key: Internal.TooltippedItem]: 4, [key: Internal.ItemNameBlockItem]: 1, [key: Internal.PropelpearlItem]: 1, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 1, [key: Internal.Item]: 3, [key: Internal.Item]: 2, [key: Internal.Item]: 5, [key: Internal.Item]: 1, [key: Internal.Item]: 4, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 2, [key: Internal.CoconutSliceItem]: 1, [key: Internal.ModelProviderItem]: 4, [key: Internal.ConsumableItem]: 6, [key: Internal.FestiveChikenItem]: 8, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 1, [key: Internal.Item]: 1, [key: Internal.Item]: 9, [key: Internal.Item]: 2, [key: Internal.Item]: 3, [key: Internal.Item]: 1, [key: Internal.Item]: 4, [key: Internal.Item]: 2, [key: Internal.Item]: 2, [key: Internal.Item]: 5, [key: Internal.Item]: 6, [key: Internal.Item]: 2, [key: Internal.Item]: 3, [key: Internal.Item]: 1, [key: Internal.SuspiciousStewItem]: 4, [key: Internal.Item]: 1, [key: Internal.Item]: 3, [key: Internal.Item]: 1, [key: Internal.ModelProviderItem]: 5, [key: Internal.GingerbreadManItem]: 3, [key: Internal.DrinkableItem]: 1, [key: Internal.Item]: 1, [key: Internal.Item]: 1, [key: Internal.ItemBowlFood]: 4, [key: Internal.ItemNameBlockItem]: 1, [key: Internal.Item]: 2, [key: Internal.Item]: 6, [key: Internal.Item]: 1, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 8, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 8, [key: Internal.Item]: 2, [key: Internal.Goo]: 5, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 9, [key: Internal.ItemNameBlockItem]: 2, [key: Internal.LongevityNoodleItem]: 4, [key: Internal.Item]: 3, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 4, [key: Internal.ItemBowlFood]: 2, [key: Internal.Item]: 4, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 2, [key: Internal.Item]: 6, [key: Internal.FoodItemWithBlock]: 1, [key: Internal.Item]: 1, [key: Internal.DrinkableItem]: 1, [key: Internal.Item]: 4, [key: Internal.ItemBlackApple]: 2, [key: Internal.Item]: 1, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 9, [key: Internal.Item]: 5, [key: Internal.Item]: 1, [key: Internal.Item]: 2, [key: Internal.Item]: 2, [key: Internal.Item]: 1, [key: Internal.Item]: 2, [key: Internal.Item]: 1, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 9, [key: Internal.Item]: 2, [key: Internal.Item]: 1, [key: Internal.Item]: 1, [key: Internal.Item]: 1, [key: Internal.SugarCaneItem]: 2, [key: Internal.PopsicleItem]: 2, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 6, [key: Internal.Item]: 1, [key: Internal.Item]: 2, [key: Internal.Item]: 4, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 4, [key: Internal.Item]: 3, [key: Internal.ConsumableItem]: 6, [key: Internal.FoodItemWithBlock]: 2, [key: Internal.CoconutSliceItem]: 6, [key: Internal.Item]: 2, [key: Internal.Item]: 3, [key: Internal.ModelProviderItem]: 4, [key: Internal.Item]: 4, [key: Internal.Item]: 2, [key: Internal.Item]: 1, [key: Internal.DrinkableItem]: 1, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 8, [key: Internal.Item]: 4, [key: Internal.Item]: 4, [key: Internal.ItemNameBlockItem]: 1, [key: Internal.Item]: 3, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 6, [key: Internal.CandyItem]: 1, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 8, [key: Internal.Item]: 4, [key: Internal.Item]: 2, [key: Internal.Item]: 2, [key: Internal.DogFoodItem]: 2, [key: Internal.Item]: 2, [key: Internal.Item]: 1, [key: Internal.Item]: 4, [key: Internal.ConsumableItem]: 9, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 9, [key: Internal.Item]: 4, [key: Internal.Item]: 2, [key: Internal.DrinkableItem]: 1, [key: Internal.TooltippedItem]: 5, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 1, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 8, [key: Internal.GooeyBeef]: 6, [key: Internal.TooltippedItem]: 5, [key: Internal.Item]: 1, [key: Internal.Item]: 1, [key: Internal.Item]: 1, [key: Internal.Item]: 1, [key: Internal.ConsumableItem]: 5, [key: Internal.Item]: 2, [key: Internal.ItemNameBlockItem]: 1, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 9, [key: Internal.Item]: 4, [key: Internal.Item]: 5, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 1, [key: Internal.Item]: 4, [key: Internal.Item]: 1, [key: Internal.LumiseneBottleItem]: 1, [key: Internal.Item]: 1, [key: Internal.Item]: 3, [key: Internal.Item]: 2, [key: Internal.GooeyApple]: 5, [key: Internal.Item]: 1, [key: Internal.Item]: 6, [key: Internal.SalmonVerrinesItem]: 4, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 3, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 8, [key: Internal.Item]: 6, [key: Internal.Item]: 1, [key: Internal.GingerbreadCookieStarItem]: 1, [key: Internal.GingerbreadCookieCreeperItem]: 1, [key: Internal.Item]: 2, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 9, [key: Internal.ModelProviderItem]: 4, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 4, [key: Internal.GingerbreadCookieBlockItem]: 1, [key: Internal.ModelProviderItem]: 1, [key: Internal.Item]: 2, [key: Internal.ModelProviderItem]: 2, [key: Internal.BottledManaItem]: 1, [key: Internal.Item]: 1, [key: Internal.SoapItem]: 1, [key: Internal.Item]: 1, [key: Internal.DrinkableItem]: 1, [key: Internal.Item]: 5, [key: Internal.ModelProviderItem]: 2, [key: Internal.Item]: 5, [key: Internal.Item]: 4, [key: Internal.Item]: 3, [key: Internal.Item]: 2, [key: Internal.Item]: 4, [key: Internal.Item]: 1, [key: Internal.Item]: 4, [key: Internal.Item]: 3, [key: Internal.Item]: 5, [key: Internal.GooeyBeef]: 6, [key: Internal.Item]: 3, [key: Internal.GingerbreadItem]: 2, [key: Internal.Item]: 6, [key: Internal.Item]: 2, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 2, [key: Internal.FoodItemWithBlock]: 3, [key: Internal.ItemNameBlockItem]: 1, [key: Internal.DrinkableItem]: 5, [key: Internal.ConsumableItem]: 6, [key: vectorwing.farmersdelight.common.item.ConsumableItem]: 1, [key: Internal.Item]: 4, [key: Internal.Item]: 1}) & (Internal.Map<Internal.Item, number>);
        static readonly SPEED_MODIFIER: (0.5) & (number);
        static readonly BREEDING_FOOD_THRESHOLD: (12) & (number);
        static MEMORY_TYPES: ([Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>, Internal.MemoryModuleType<any>]) & (Internal.ImmutableList<Internal.MemoryModuleType<any>>);
        static WANTED_ITEMS: Internal.Set<Internal.Item>;
        static readonly POI_MEMORIES: ({[key: Internal.MemoryModuleType<any>]: any, [key: Internal.MemoryModuleType<any>]: any, [key: Internal.MemoryModuleType<any>]: any, [key: Internal.MemoryModuleType<any>]: any}) & (Internal.Map<Internal.MemoryModuleType<Internal.GlobalPos>, Internal.BiPredicate<Internal.Villager, Internal.Holder<Internal.PoiType>>>);
    }
    type Villager_ = Villager;
    interface Float2IntFunction extends it.unimi.dsi.fastutil.Function<number, number>, Internal.DoubleToIntFunction {
        andThenShort(arg0: Internal.Int2ShortFunction_): Internal.Float2ShortFunction;
        defaultReturnValue(): number;
        /**
         * @deprecated
        */
        "put(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): any;
        /**
         * @deprecated
        */
        andThen<T>(arg0: Internal.Function_<number, T>): Internal.Function<number, T>;
        "containsKey(float)"(arg0: number): boolean;
        andThenLong(arg0: Internal.Int2LongFunction_): Internal.Float2LongFunction;
        andThenFloat(arg0: Internal.Int2FloatFunction_): Internal.Float2FloatFunction;
        "put(float,int)"(arg0: number, arg1: number): number;
        andThenObject<T>(arg0: Internal.Int2ObjectFunction_<T>): Internal.Float2ObjectFunction<T>;
        /**
         * @deprecated
        */
        put(arg0: any, arg1: any): any;
        getOrDefault(arg0: number, arg1: number): number;
        /**
         * @deprecated
        */
        "put(java.lang.Float,java.lang.Integer)"(arg0: number, arg1: number): number;
        "remove(float)"(arg0: number): number;
        /**
         * @deprecated
        */
        "get(java.lang.Object)"(arg0: any): number;
        andThenChar(arg0: Internal.Int2CharFunction_): Internal.Float2CharFunction;
        andThenInt(arg0: Internal.Int2IntFunction_): this;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: number): number;
        composeByte(arg0: Internal.Byte2FloatFunction_): Internal.Byte2IntFunction;
        "getOrDefault(float,int)"(arg0: number, arg1: number): number;
        apply(arg0: number): number;
        /**
         * @deprecated
        */
        "getOrDefault(java.lang.Object,java.lang.Integer)"(arg0: any, arg1: number): number;
        composeLong(arg0: Internal.Long2FloatFunction_): Internal.Long2IntFunction;
        /**
         * @deprecated
        */
        compose<T>(arg0: Internal.Function_<T, number>): Internal.Function<T, number>;
        composeDouble(arg0: Internal.Double2FloatFunction_): Internal.Double2IntFunction;
        andThenReference<T>(arg0: Internal.Int2ReferenceFunction_<T>): Internal.Float2ReferenceFunction<T>;
        abstract get(arg0: number): number;
        identity<T>(): Internal.Function<T, T>;
        /**
         * @deprecated
        */
        "containsKey(java.lang.Object)"(arg0: any): boolean;
        composeFloat(arg0: Internal.Float2FloatFunction_): this;
        abstract "get(float)"(arg0: number): number;
        /**
         * @deprecated
        */
        get(arg0: any): number;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: any): any;
        composeShort(arg0: Internal.Short2FloatFunction_): Internal.Short2IntFunction;
        composeInt(arg0: Internal.Int2FloatFunction_): Internal.Int2IntFunction;
        andThenByte(arg0: Internal.Int2ByteFunction_): Internal.Float2ByteFunction;
        put(arg0: number, arg1: number): number;
        composeChar(arg0: Internal.Char2FloatFunction_): Internal.Char2IntFunction;
        /**
         * @deprecated
        */
        containsKey(arg0: any): boolean;
        /**
         * @deprecated
        */
        "getOrDefault(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): any;
        containsKey(arg0: number): boolean;
        /**
         * @deprecated
        */
        remove(arg0: any): number;
        /**
         * @deprecated
        */
        put(arg0: number, arg1: number): number;
        andThenDouble(arg0: Internal.Int2DoubleFunction_): Internal.Float2DoubleFunction;
        composeObject<T>(arg0: Internal.Object2FloatFunction_<T>): Internal.Object2IntFunction<T>;
        composeReference<T>(arg0: Internal.Reference2FloatFunction_<T>): Internal.Reference2IntFunction<T>;
        size(): number;
        defaultReturnValue(arg0: number): void;
        clear(): void;
        /**
         * @deprecated
        */
        "remove(java.lang.Object)"(arg0: any): number;
        remove(arg0: number): number;
        /**
         * @deprecated
        */
        applyAsInt(arg0: number): number;
    }
    type Float2IntFunction_ = Float2IntFunction;
    class Bounds$Interpolate {
        constructor(tx: number, ty: number, tz: number)
        getClass(): typeof any;
        lerp(min: Internal.Float3_, max: Internal.Float3_): Internal.Float3;
        static "lerp(de.ambertation.wunderlib.math.Float3,de.ambertation.wunderlib.math.Float3,de.ambertation.wunderlib.math.Float3)"(t: Internal.Float3_, min: Internal.Float3_, max: Internal.Float3_): Internal.Float3;
        blockAlignedLerp(min: Internal.Float3_, max: Internal.Float3_): Internal.Float3;
        toString(): string;
        notifyAll(): void;
        oppositeY(): this;
        oppositeZ(): this;
        static "lerp(double,double,double)"(t: number, min: number, max: number): number;
        static "lerp(double,de.ambertation.wunderlib.math.Float3,de.ambertation.wunderlib.math.Float3)"(t: number, min: Internal.Float3_, max: Internal.Float3_): Internal.Float3;
        oppositeX(): this;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        static blockAlignedLerp(t: Internal.Float3_, min: Internal.Float3_, max: Internal.Float3_): Internal.Float3;
        static lerp(t: number, min: Internal.Float3_, max: Internal.Float3_): Internal.Float3;
        hashCode(): number;
        wait(): void;
        static lerp(t: Internal.Float3_, min: Internal.Float3_, max: Internal.Float3_): Internal.Float3;
        wait(arg0: number): void;
        opposite(): this;
        static lerp(t: number, min: number, max: number): number;
        equals(arg0: any): boolean;
        get class(): typeof any
        static readonly CORNERS: Internal.Bounds$Interpolate[];
        static readonly MIN_MAX_MIN: (Internal.Bounds$Interpolate) & (Internal.Bounds$Interpolate);
        static readonly MIN_MIN_MAX: (Internal.Bounds$Interpolate) & (Internal.Bounds$Interpolate);
        static readonly MAX_MAX_MAX: (Internal.Bounds$Interpolate) & (Internal.Bounds$Interpolate);
        static readonly CORNERS_AND_CENTER: Internal.Bounds$Interpolate[];
        readonly t: Internal.Float3;
        readonly idx: number;
        static readonly MAX_MIN_MIN: (Internal.Bounds$Interpolate) & (Internal.Bounds$Interpolate);
        static readonly MIN_MAX_MAX: (Internal.Bounds$Interpolate) & (Internal.Bounds$Interpolate);
        static readonly MIN_MIN_MIN: (Internal.Bounds$Interpolate) & (Internal.Bounds$Interpolate);
        static readonly CENTER: (Internal.Bounds$Interpolate) & (Internal.Bounds$Interpolate);
        static readonly MAX_MIN_MAX: (Internal.Bounds$Interpolate) & (Internal.Bounds$Interpolate);
        static readonly MAX_MAX_MIN: (Internal.Bounds$Interpolate) & (Internal.Bounds$Interpolate);
    }
    type Bounds$Interpolate_ = Bounds$Interpolate;
    class Window$Type extends Internal.Enum<Internal.Window$Type> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        compareTo(arg0: Internal.Window$Type_): number;
        toString(): string;
        "compareTo(java.awt.Window$Type)"(arg0: Internal.Window$Type_): number;
        notifyAll(): void;
        static values(): Internal.Window$Type[];
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.Window$Type>>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        name(): string;
        hashCode(): number;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        getDeclaringClass(): typeof Internal.Window$Type;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        static valueOf(arg0: string): Internal.Window$Type;
        get class(): typeof any
        get declaringClass(): typeof Internal.Window$Type
        static readonly NORMAL: (Internal.Window$Type) & (Internal.Window$Type);
        static readonly UTILITY: (Internal.Window$Type) & (Internal.Window$Type);
        static readonly POPUP: (Internal.Window$Type) & (Internal.Window$Type);
    }
    type Window$Type_ = "normal" | Window$Type | "popup" | "utility";
    interface Animatable <T extends Internal.Animatable<T>> {
        abstract interpolate(arg0: T, arg1: number): T;
        (arg0: T, arg1: number): T;
    }
    type Animatable_<T extends Internal.Animatable<T>> = Animatable<T> | ((arg0: T, arg1: number)=> T);
    class ConfigurableFreezeTopLayer extends Feature<Internal.ConfigurableFreezeTopLayer$Config> {
        constructor(codec: Internal.Codec_<Internal.ConfigurableFreezeTopLayer$Config>)
        getClass(): typeof any;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        place(context: Internal.FeaturePlaceContext_<Internal.ConfigurableFreezeTopLayer$Config>): boolean;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        place($$0: Internal.ConfigurableFreezeTopLayer$Config_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        wait(): void;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.ConfigurableFreezeTopLayer$Config, Feature<Internal.ConfigurableFreezeTopLayer$Config>>>;
        get class(): typeof any
    }
    type ConfigurableFreezeTopLayer_ = ConfigurableFreezeTopLayer;
    class StarcallerItem extends Internal.ManasteelSwordItem {
        constructor(props: Internal.Item$Properties_)
        onTick(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        onWearerUse(stack: Internal.ItemStack_, world: Internal.Level_, user: Internal.Player_, hand: Internal.InteractionHand_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        addModifierTooltip(stack: Internal.ItemStack_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_, type: Internal.ModifierHelperType_<any>): void;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        fzzy_core_correctSlot(slot: Internal.EquipmentSlot_): boolean;
        getCreativeTab(): string;
        postWearerHit(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        modifierObjectPredicate(livingEntity: Internal.LivingEntity_, stack: Internal.ItemStack_): ResourceLocation;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        kjs$getAttributeMap(): Internal.Multimap<any, any>;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        kjs$getMutableAttributeMap(): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        fzzy_core_getCorrectSlot(): Internal.EquipmentSlot;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        damageItem<T extends Internal.LivingEntity>(stack: Internal.ItemStack_, amount: number, entity: T, onBroken: Internal.Consumer_<T>): number;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        onWearerKilledOther(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, victim: Internal.LivingEntity_, world: Internal.ServerLevel_): void;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        getDamage(): number;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        canBeModifiedBy(type: Internal.ModifierHelperType_<any>): boolean;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        incrementKillCount(stack: Internal.ItemStack_): void;
        setDigSpeed(speed: number): void;
        getManaPerDamage(): number;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        defaultModifiers(type: Internal.ModifierHelperType_<any>): Internal.List<any>;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        port_lib$canPerformAction(stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): boolean;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        getTier(): Internal.Tier;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick(stack: Internal.ItemStack_, world: Internal.Level_, entity: Internal.Entity_, slot: number, selected: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getKillCount(stack: Internal.ItemStack_): number;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        postWearerMine(stack: Internal.ItemStack_, world: Internal.Level_, state: Internal.BlockState_, pos: BlockPos_, miner: Internal.Player_): void;
        kjs$setAttributeMap(arg0: Internal.Multimap_<any, any>): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get damage(): number
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        get manaPerDamage(): number
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        get tier(): Internal.Tier
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type StarcallerItem_ = StarcallerItem;
    class BushWithOuterFeatureConfig extends Internal.BushFeatureConfig {
        constructor(leaves: Internal.BlockStateProvider_, outer_leaves: Internal.BlockStateProvider_, stem: Internal.BlockStateProvider_)
        constructor(leaves: Internal.Block_, outer_leaves: Internal.Block_, stem: Internal.Block_)
        getClass(): typeof any;
        hashCode(): number;
        getFeatures(): Internal.Stream<Internal.ConfiguredFeature<any, any>>;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        get features(): Internal.Stream<Internal.ConfiguredFeature<any, any>>
        static readonly CODEC: Internal.Codec<Internal.BushWithOuterFeatureConfig>;
        readonly outer_leaves: Internal.BlockStateProvider;
    }
    type BushWithOuterFeatureConfig_ = BushWithOuterFeatureConfig;
    interface DSL$TypeReference {
        "in"(arg0: Internal.Schema_): Internal.TypeTemplate;
        abstract typeName(): string;
        (): string;
    }
    type DSL$TypeReference_ = DSL$TypeReference | (()=> string);
    class CandleCakeBlock extends Internal.AbstractCandleBlock {
        constructor($$0: Internal.Block_, $$1: Internal.BlockBehaviour$Properties_)
        /**
         * @deprecated
        */
        getOcclusionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        /**
         * @deprecated
        */
        getSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        axiom$customPickBlockStack(): Internal.ItemStack;
        getSoundType($$0: Internal.BlockState_): SoundType;
        /**
         * @deprecated
        */
        getVisualShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        handler$efo000$collective$Block_playerDestroy(level: Internal.Level_, player: Internal.Player_, blockPos: BlockPos_, blockState: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number, $$5: number): void;
        /**
         * @deprecated
        */
        randomTick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: Internal.BlockEntity_): void;
        static canSupportRigidBlock($$0: Internal.BlockGetter_, $$1: BlockPos_): boolean;
        static popResource($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.ItemStack_): void;
        setRandomTickCallback(callback: Internal.Consumer_<any>): void;
        getDescriptionId(): string;
        stepOn($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Entity_): void;
        fallOn($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: BlockPos_, $$3: Internal.Entity_, $$4: number): void;
        getSettings(): Internal.BlockBehaviour$Properties;
        getExplosionResistance(): number;
        asItem(): Internal.Item;
        /**
         * @deprecated
        */
        triggerEvent($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: number, $$4: number): boolean;
        getTypeData(): Internal.CompoundTag;
        setFriction(arg0: number): void;
        /**
         * @deprecated
        */
        getRenderShape($$0: Internal.BlockState_): Internal.RenderShape;
        canCull(): boolean;
        customShapeUpdate(blockState: Internal.CustomBlockState_, levelReader: Internal.LevelReader_, blockPos: BlockPos_): Internal.CustomBlockState;
        getJumpFactor(): number;
        getSpeedFactor(): number;
        static canSupportCenter($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        skipRendering($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getLightBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        playerDestroy($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.BlockEntity_, $$5: Internal.ItemStack_): void;
        shouldAttemptToCull(state: Internal.BlockState_): boolean;
        isPossibleToRespawnInThis($$0: Internal.BlockState_): boolean;
        getCustomStateForPlacement(blockPlaceContext: Internal.BlockPlaceContext_): Internal.CustomBlockState;
        /**
         * @deprecated
        */
        getDirectSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        getProperties(): Internal.BlockBehaviour$Properties;
        playerWillDestroy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Player_): void;
        getClass(): typeof any;
        getMaxVerticalOffset(): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.item.context.BlockPlaceContext)"($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        useShapeForLightOcclusion($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        getDrops($$0: Internal.BlockState_, $$1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getStateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>;
        /**
         * @deprecated
        */
        entityInside($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Entity_): void;
        setBlockBuilder(b: Internal.BlockBuilder_): void;
        handler$ldb000$puzzleslib$playerDestroy$0(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        setRequiresTool(v: boolean): void;
        setSpeedFactor(arg0: number): void;
        axiom$getPossibleCustomStates(): Internal.List<any>;
        setExplosionResistance(arg0: number): void;
        toString(): string;
        port_lib$popExperience(arg0: Internal.ServerLevel_, arg1: BlockPos_, arg2: number): void;
        notifyAll(): void;
        static isLit($$0: Internal.BlockState_): boolean;
        getToolModifiedState(state: Internal.BlockState_, world: Internal.Level_, pos: BlockPos_, player: Internal.Player_, stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): Internal.BlockState;
        getId(): string;
        getLootTable(): ResourceLocation;
        puzzleslib$setItem(arg0: Internal.Item_): void;
        axiom$translationKey(): string;
        /**
         * @deprecated
        */
        getInteractionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        propagatesSkylightDown($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        setPlacedBy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.LivingEntity_, $$4: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        onPlace($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Block>;
        static popResourceFromFace($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.ItemStack_): void;
        getFriction(): number;
        handlePrecipitation($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Biome$Precipitation_): void;
        hasAnalogOutputSignal($$0: Internal.BlockState_): boolean;
        wait(arg0: number): void;
        /**
         * @deprecated
        */
        getFluidState($$0: Internal.BlockState_): Internal.FluidState;
        handler$koh000$porting_lib_entity$getDestroySpeed(blockState: Internal.BlockState_, player: Internal.Player_, blockGetter: Internal.BlockGetter_, pos: BlockPos_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getAnalogOutputSignal($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): number;
        handler$efo000$collective$Block_setPlacedBy(level: Internal.Level_, blockPos: BlockPos_, blockState: Internal.BlockState_, livingEntity: Internal.LivingEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static byCandle($$0: Internal.Block_): Internal.BlockState;
        /**
         * @deprecated
        */
        tick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        supportsExternalFaceHiding(state: Internal.BlockState_): boolean;
        handler$ldb000$puzzleslib$playerDestroy$1(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        notify(): void;
        axiom$asItemStack(): Internal.ItemStack;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        neighborChanged($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Block_, $$4: BlockPos_, $$5: boolean): void;
        handler$zhd000$additionalentityattributes$additionalEntityAttributes$saveBreakingPlayer(world: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, stack: Internal.ItemStack_, callbackInfo: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        getBlockSupportShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        canSustainPlant(state: Internal.BlockState_, world: Internal.BlockGetter_, pos: BlockPos_, facing: Internal.Direction_, plantable: Internal.IPlantable_): boolean;
        /**
         * @deprecated
        */
        isCollisionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static isFaceFull($$0: Internal.VoxelShape_, $$1: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getMenuProvider($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): Internal.MenuProvider;
        static byItem($$0: Internal.Item_): Internal.Block;
        static updateFromNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        updateIndirectNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: number, $$4: number): void;
        destroy($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): void;
        handler$fdc000$everycomp$addSimpleFastECdrops(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, cir: Internal.CallbackInfoReturnable_<any>, resId: ResourceLocation_, lootParams: Internal.LootParams_, serverLevel: Internal.ServerLevel_, lootTable: Internal.LootTable_): void;
        getToolModifiedState(state: Internal.BlockState_, context: Internal.UseOnContext_, toolAction: Internal.ToolAction_, simulate: boolean): Internal.BlockState;
        use($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_, $$4: Internal.InteractionHand_, $$5: Internal.BlockHitResult_): Internal.InteractionResult;
        setLightEmission(v: number): void;
        doNormalInteractions(): boolean;
        setJumpFactor(arg0: number): void;
        canSurvive($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): void;
        /**
         * @deprecated
        */
        getShadeBrightness($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        getAppearance(state: Internal.BlockState_, renderView: Internal.BlockAndTintGetter_, pos: BlockPos_, side: Internal.Direction_, sourceState: Internal.BlockState_, sourcePos: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        getCollisionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        setDestroySpeed(v: number): void;
        defaultBlockState(): Internal.BlockState;
        usesCustomShouldDrawFace(state: Internal.BlockState_): boolean;
        getStateForPlacement($$0: Internal.BlockPlaceContext_): Internal.BlockState;
        cantCullAgainst(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        arch$holder(): Internal.Holder<Internal.Block>;
        wait(): void;
        static extinguish($$0: Internal.Player_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): void;
        getCloneItemStack($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        hasDynamicShape(): boolean;
        getMaxHorizontalOffset(): number;
        /**
         * @deprecated
        */
        getDestroyProgress($$0: Internal.BlockState_, $$1: Internal.Player_, $$2: Internal.BlockGetter_, $$3: BlockPos_): number;
        /**
         * @deprecated
        */
        getSeed($$0: Internal.BlockState_, $$1: BlockPos_): number;
        defaultDestroyTime(): number;
        updateShape($$0: Internal.BlockState_, $$1: Internal.Direction_, $$2: Internal.BlockState_, $$3: Internal.LevelAccessor_, $$4: BlockPos_, $$5: BlockPos_): Internal.BlockState;
        dropFromExplosion($$0: Internal.Explosion_): boolean;
        isRandomlyTicking($$0: Internal.BlockState_): boolean;
        static isShapeFullBlock(shape: Internal.VoxelShape_): boolean;
        withPropertiesOf($$0: Internal.BlockState_): Internal.BlockState;
        static isExceptionForConnection($$0: Internal.BlockState_): boolean;
        setIsRandomlyTicking(arg0: boolean): void;
        hidesNeighborFace(level: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, neighborState: Internal.BlockState_, dir: Internal.Direction_): boolean;
        onTreeGrow(state: Internal.BlockState_, level: Internal.LevelReader_, placeFunction: Internal.BiConsumer_<BlockPos, Internal.BlockState>, randomSource: Internal.RandomSource_, pos: BlockPos_, config: Internal.TreeConfiguration_): boolean;
        /**
         * @deprecated
        */
        rotate($$0: Internal.BlockState_, $$1: Internal.Rotation_): Internal.BlockState;
        defaultMapColor(): Internal.MapColor;
        getStateAtViewpoint(state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_, viewpoint: Vec3d_): Internal.BlockState;
        wait(arg0: number, arg1: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.BlockGetter_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        setNameKey(arg0: string): void;
        static box($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): Internal.VoxelShape;
        static canLight($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        mirror($$0: Internal.BlockState_, $$1: Internal.Mirror_): Internal.BlockState;
        wasExploded($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Explosion_): void;
        getName(): Internal.MutableComponent;
        updateEntityAfterFallOn($$0: Internal.BlockGetter_, $$1: Internal.Entity_): void;
        animateTick($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        customShouldDrawFace(view: Internal.BlockGetter_, thisState: Internal.BlockState_, sideState: Internal.BlockState_, thisPos: BlockPos_, sidePos: BlockPos_, side: Internal.Direction_): Optional<boolean>;
        axiom$getResourceLocation(): ResourceLocation;
        arch$registryName(): ResourceLocation;
        axiom$getProperties(): Internal.Collection<any>;
        getBlockBuilder(): Internal.BlockBuilder;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        isSignalSource($$0: Internal.BlockState_): boolean;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number): void;
        /**
         * @deprecated
        */
        attack($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): void;
        getShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        shouldAttemptToCull(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        onProjectileHit($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockHitResult_, $$3: Internal.Projectile_): void;
        static stateById($$0: number): Internal.BlockState;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): Internal.List<Internal.ItemStack>;
        requiredFeatures(): Internal.FeatureFlagSet;
        hashCode(): number;
        axiom$defaultCustomState(): Internal.CustomBlockState;
        setCanCull(canCull: boolean): void;
        /**
         * @deprecated
        */
        isOcclusionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static getId($$0: Internal.BlockState_): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.material.Fluid)"($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        static pushEntitiesUp($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): Internal.BlockState;
        isPathfindable($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.PathComputationType_): boolean;
        setSoundType(arg0: SoundType_): void;
        handler$cef000$betterend$be_getDroppedStacks(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, info: Internal.CallbackInfoReturnable_<any>): void;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_): Internal.List<Internal.ItemStack>;
        /**
         * @deprecated
        */
        onRemove($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        cantCullAgainst(state: Internal.BlockState_): boolean;
        setHasCollision(arg0: boolean): void;
        static shouldRenderFace($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_, $$4: BlockPos_): boolean;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        spawnAfterBreak($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.ItemStack_, $$4: boolean): void;
        set randomTickCallback(callback: Internal.Consumer_<any>)
        get descriptionId(): string
        get settings(): Internal.BlockBehaviour$Properties
        get explosionResistance(): number
        get typeData(): Internal.CompoundTag
        set friction(arg0: number)
        get jumpFactor(): number
        get speedFactor(): number
        get properties(): Internal.BlockBehaviour$Properties
        get class(): typeof any
        get maxVerticalOffset(): number
        get stateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>
        set blockBuilder(b: Internal.BlockBuilder_)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        set speedFactor(arg0: number)
        set explosionResistance(arg0: number)
        get id(): string
        get lootTable(): ResourceLocation
        get friction(): number
        set lightEmission(v: number)
        set jumpFactor(arg0: number)
        set destroySpeed(v: number)
        get maxHorizontalOffset(): number
        set isRandomlyTicking(arg0: boolean)
        set nameKey(arg0: string)
        get name(): Internal.MutableComponent
        get blockBuilder(): Internal.BlockBuilder
        get idLocation(): ResourceLocation
        get mod(): string
        set canCull(canCull: boolean)
        set soundType(arg0: SoundType_)
        set hasCollision(arg0: boolean)
        static readonly LIT: (Internal.BooleanProperty) & (Internal.BooleanProperty);
    }
    type CandleCakeBlock_ = CandleCakeBlock;
    class MarimorphosisRecipe extends Internal.OrechidRecipe {
        constructor(id: ResourceLocation_, input: Internal.StateIngredient_, output: Internal.StateIngredient_, weight: number, successFunction: Internal.CommandFunction$CacheableFunction_, weightBonus: number, biomes: Internal.TagKey_<Internal.Biome>)
        getClass(): typeof any;
        getGroup(): string;
        getToastSymbol(): Internal.ItemStack;
        getWeightBonus(): number;
        getSchema(): Internal.RecipeSchema;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getSerializer(): Internal.RecipeSerializer<any>;
        assemble(c: net.minecraft.world.Container_, registries: Internal.RegistryAccess_): Internal.ItemStack;
        getId(): ResourceLocation;
        getBiomes(): Internal.TagKey<Internal.Biome>;
        getSuccessFunction(): Internal.CommandFunction$CacheableFunction;
        matches(c: net.minecraft.world.Container_, l: Internal.Level_): boolean;
        getWeight(): number;
        getMod(): string;
        getOutput(): Internal.StateIngredient;
        isIn(tag: ResourceLocation_): boolean;
        getRemainingItems($$0: net.minecraft.world.Container_): Internal.NonNullList<Internal.ItemStack>;
        getIngredients(): Internal.NonNullList<Internal.Ingredient>;
        handler$bpa000$bclib$bcl_getRemainingItems(container: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>): void;
        isSpecial(): boolean;
        hasOutput(match: Internal.ReplacementMatch_): boolean;
        getResultItem(registries: Internal.RegistryAccess_): Internal.ItemStack;
        toString(): string;
        notifyAll(): void;
        canCraftInDimensions(width: number, height: number): boolean;
        showNotification(): boolean;
        replaceInput(match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): boolean;
        getType(): ResourceLocation;
        getInput(): Internal.StateIngredient;
        getOutput(level: Internal.Level_, pos: BlockPos_): Internal.StateIngredient;
        setGroup(group: string): void;
        hashCode(): number;
        "handler$fie000$fabric-item-api-v1$captureStack"(inventory: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>, defaultedList: Internal.NonNullList_<any>, i: number): void;
        getOrCreateId(): ResourceLocation;
        hasInput(match: Internal.ReplacementMatch_): boolean;
        wait(): void;
        isIncomplete(): boolean;
        wait(arg0: number): void;
        replaceOutput(match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): boolean;
        equals(arg0: any): boolean;
        getWeight(level: Internal.Level_, pos: BlockPos_): number;
        get class(): typeof any
        get group(): string
        get toastSymbol(): Internal.ItemStack
        get weightBonus(): number
        get schema(): Internal.RecipeSchema
        get serializer(): Internal.RecipeSerializer<any>
        get id(): ResourceLocation
        get biomes(): Internal.TagKey<Internal.Biome>
        get successFunction(): Internal.CommandFunction$CacheableFunction
        get weight(): number
        get mod(): string
        get output(): Internal.StateIngredient
        get ingredients(): Internal.NonNullList<Internal.Ingredient>
        get special(): boolean
        get type(): ResourceLocation
        get input(): Internal.StateIngredient
        set group(group: string)
        get orCreateId(): ResourceLocation
        get incomplete(): boolean
    }
    type MarimorphosisRecipe_ = MarimorphosisRecipe;
    interface SleepingBlockEntity {
        startSleeping(): boolean;
        abstract getSleepingTicker(): Internal.TickingBlockEntity;
        wakeUpNow(): void;
        isSleeping(): boolean;
        setTicker(delegate: Internal.TickingBlockEntity_): void;
        sleepOnlyCurrentTick(): void;
        abstract getTickWrapper(): Internal.WrappedBlockEntityTickInvokerAccessor;
        abstract setTickWrapper(arg0: Internal.WrappedBlockEntityTickInvokerAccessor_): void;
        abstract setSleepingTicker(arg0: Internal.TickingBlockEntity_): void;
        get sleepingTicker(): Internal.TickingBlockEntity
        get sleeping(): boolean
        set ticker(delegate: Internal.TickingBlockEntity_)
        get tickWrapper(): Internal.WrappedBlockEntityTickInvokerAccessor
        set tickWrapper(arg0: Internal.WrappedBlockEntityTickInvokerAccessor_)
        set sleepingTicker(arg0: Internal.TickingBlockEntity_)
        readonly SLEEPING_BLOCK_ENTITY_TICKER: Internal.TickingBlockEntity;
    }
    type SleepingBlockEntity_ = SleepingBlockEntity;
    class SpellcastersReagentFlavorItem extends Internal.CustomFlavorItem implements Internal.SpellcastersReagent {
        constructor(attribute: Internal.Attribute_, modifier: Internal.AttributeModifier_, settings: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        static access$withFlavor$jd($this: Internal.Flavorful_<any>, flavorPath: string): Internal.Flavorful<any>;
        static access$flavorDescText$jd($this: Internal.Flavorful_<any>): Internal.MutableComponent;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, world: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        withFlavorDefaultPath(id: ResourceLocation_): Internal.CustomFlavorItem;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        static access$flavorText$jd($this: Internal.Flavorful_<any>): Internal.MutableComponent;
        moonlight$getClientAnimationExtension(): any;
        flavorText(): Internal.MutableComponent;
        setGlint(<set-?>: boolean): void;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        static access$addFlavorText$jd($this: Internal.Flavorful_<any>, tooltip: Internal.List_<any>, context: Internal.TooltipFlag_): void;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        setFlavorDesc(<set-?>: string): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        withFlavorDesc(flavorPath: string): Internal.CustomFlavorItem;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        setFlavor(<set-?>: string): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        getFlavorItem(): Internal.CustomFlavorItem;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        getGlint(): boolean;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        static access$withFlavorDesc$jd($this: Internal.Flavorful_<any>, flavorPath: string): Internal.Flavorful<any>;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil(stack: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        addFlavorText(tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_): void;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        static access$withGlint$jd($this: Internal.Flavorful_<any>): Internal.Flavorful<any>;
        setDigSpeed(speed: number): void;
        static access$withFlavorDescDefaultPath$jd($this: Internal.Flavorful_<any>, id: ResourceLocation_): Internal.Flavorful<any>;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        getAttributeModifier(): kotlin.Pair<Internal.Attribute, Internal.AttributeModifier>;
        withFlavor(flavorPath: string): Internal.Flavorful<any>;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        getFlavor(): string;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        getFlavorDesc(): string;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        withGlint(): Internal.Flavorful<any>;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        withFlavorDescDefaultPath(id: ResourceLocation_): Internal.Flavorful<any>;
        getTypeItemStackKey(): Internal.ItemStackKey;
        static access$withFlavorDefaultPath$jd($this: Internal.Flavorful_<any>, id: ResourceLocation_): Internal.Flavorful<any>;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        static access$makeFlavorText($this: Internal.CustomFlavorItem_): Internal.MutableComponent;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        flavorDescText(): Internal.MutableComponent;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        static access$makeFlavorTextDesc($this: Internal.CustomFlavorItem_): Internal.MutableComponent;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        set glint(<set-?>: boolean)
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set flavorDesc(<set-?>: string)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        set flavor(<set-?>: string)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get flavorItem(): Internal.CustomFlavorItem
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get glint(): boolean
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        get attributeModifier(): kotlin.Pair<Internal.Attribute, Internal.AttributeModifier>
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        get flavor(): string
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        get flavorDesc(): string
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type SpellcastersReagentFlavorItem_ = SpellcastersReagentFlavorItem;
    interface HexBaubleItem {
        abstract getHexBaubleAttrs(arg0: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        (arg0: Internal.ItemStack): Internal.Multimap_<Internal.Attribute, Internal.AttributeModifier>;
    }
    type HexBaubleItem_ = HexBaubleItem | ((arg0: Internal.ItemStack)=> Internal.Multimap_<Internal.Attribute, Internal.AttributeModifier>);
    class SwampChurchFeature extends Internal.AbstractSwampFeature<Internal.ResourceLocationFeatureConfiguration> {
        constructor()
        getClass(): typeof any;
        place(context: Internal.FeaturePlaceContext_<Internal.ResourceLocationFeatureConfiguration>): boolean;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        place($$0: Internal.ResourceLocationFeatureConfiguration_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.ResourceLocationFeatureConfiguration, Feature<Internal.ResourceLocationFeatureConfiguration>>>;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        get class(): typeof any
    }
    type SwampChurchFeature_ = SwampChurchFeature;
    class CommandBuildContext$MissingTagAccessPolicy extends Internal.Enum<Internal.CommandBuildContext$MissingTagAccessPolicy> {
        static valueOf($$0: string): Internal.CommandBuildContext$MissingTagAccessPolicy;
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        compareTo(arg0: Internal.CommandBuildContext$MissingTagAccessPolicy_): number;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        getDeclaringClass(): typeof Internal.CommandBuildContext$MissingTagAccessPolicy;
        name(): string;
        hashCode(): number;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.CommandBuildContext$MissingTagAccessPolicy>>;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        "compareTo(net.minecraft.commands.CommandBuildContext$MissingTagAccessPolicy)"(arg0: Internal.CommandBuildContext$MissingTagAccessPolicy_): number;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        static values(): Internal.CommandBuildContext$MissingTagAccessPolicy[];
        get class(): typeof any
        get declaringClass(): typeof Internal.CommandBuildContext$MissingTagAccessPolicy
        static readonly CREATE_NEW: (Internal.CommandBuildContext$MissingTagAccessPolicy) & (Internal.CommandBuildContext$MissingTagAccessPolicy);
        static readonly FAIL: (Internal.CommandBuildContext$MissingTagAccessPolicy) & (Internal.CommandBuildContext$MissingTagAccessPolicy);
    }
    type CommandBuildContext$MissingTagAccessPolicy_ = CommandBuildContext$MissingTagAccessPolicy | "create_new" | "fail";
    class StyleConstants$CharacterConstants extends Internal.StyleConstants implements Internal.AttributeSet$CharacterAttribute {
        static setStrikeThrough(arg0: Internal.MutableAttributeSet_, arg1: boolean): void;
        static setSpaceBelow(arg0: Internal.MutableAttributeSet_, arg1: number): void;
        static getFontSize(arg0: Internal.AttributeSet_): number;
        static setSubscript(arg0: Internal.MutableAttributeSet_, arg1: boolean): void;
        notify(): void;
        static setAlignment(arg0: Internal.MutableAttributeSet_, arg1: number): void;
        static isSubscript(arg0: Internal.AttributeSet_): boolean;
        static getLeftIndent(arg0: Internal.AttributeSet_): number;
        static getAlignment(arg0: Internal.AttributeSet_): number;
        static setComponent(arg0: Internal.MutableAttributeSet_, arg1: Internal.Component_): void;
        static getTabSet(arg0: Internal.AttributeSet_): Internal.TabSet;
        static setLeftIndent(arg0: Internal.MutableAttributeSet_, arg1: number): void;
        static setTabSet(arg0: Internal.MutableAttributeSet_, arg1: Internal.TabSet_): void;
        static isBold(arg0: Internal.AttributeSet_): boolean;
        static setFirstLineIndent(arg0: Internal.MutableAttributeSet_, arg1: number): void;
        wait(): void;
        static setForeground(arg0: Internal.MutableAttributeSet_, arg1: Internal.Color_): void;
        static setRightIndent(arg0: Internal.MutableAttributeSet_, arg1: number): void;
        static getComponent(arg0: Internal.AttributeSet_): Internal.Component;
        static getIcon(arg0: Internal.AttributeSet_): javax.swing.Icon;
        getClass(): typeof any;
        static setLineSpacing(arg0: Internal.MutableAttributeSet_, arg1: number): void;
        static getForeground(arg0: Internal.AttributeSet_): Internal.Color;
        static getFontFamily(arg0: Internal.AttributeSet_): string;
        static isItalic(arg0: Internal.AttributeSet_): boolean;
        static setUnderline(arg0: Internal.MutableAttributeSet_, arg1: boolean): void;
        static setIcon(arg0: Internal.MutableAttributeSet_, arg1: javax.swing.Icon_): void;
        wait(arg0: number, arg1: number): void;
        static setFontSize(arg0: Internal.MutableAttributeSet_, arg1: number): void;
        static getSpaceBelow(arg0: Internal.AttributeSet_): number;
        static setBackground(arg0: Internal.MutableAttributeSet_, arg1: Internal.Color_): void;
        static getRightIndent(arg0: Internal.AttributeSet_): number;
        static isUnderline(arg0: Internal.AttributeSet_): boolean;
        static setSuperscript(arg0: Internal.MutableAttributeSet_, arg1: boolean): void;
        static getBidiLevel(arg0: Internal.AttributeSet_): number;
        toString(): string;
        static getBackground(arg0: Internal.AttributeSet_): Internal.Color;
        static setItalic(arg0: Internal.MutableAttributeSet_, arg1: boolean): void;
        notifyAll(): void;
        static setFontFamily(arg0: Internal.MutableAttributeSet_, arg1: string): void;
        static getFirstLineIndent(arg0: Internal.AttributeSet_): number;
        static isSuperscript(arg0: Internal.AttributeSet_): boolean;
        static getSpaceAbove(arg0: Internal.AttributeSet_): number;
        hashCode(): number;
        static getLineSpacing(arg0: Internal.AttributeSet_): number;
        static setBidiLevel(arg0: Internal.MutableAttributeSet_, arg1: number): void;
        static setBold(arg0: Internal.MutableAttributeSet_, arg1: boolean): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        static setSpaceAbove(arg0: Internal.MutableAttributeSet_, arg1: number): void;
        static isStrikeThrough(arg0: Internal.AttributeSet_): boolean;
        get class(): typeof any
    }
    type StyleConstants$CharacterConstants_ = StyleConstants$CharacterConstants;
    class Fox$Type extends Internal.Enum<Internal.Fox$Type> implements Internal.StringRepresentable {
        getClass(): typeof any;
        static fromEnumWithMapping<E extends Internal.Enum<E> & Internal.StringRepresentable>($$0: Internal.Supplier_<E[]>, $$1: Internal.Function_<string, string>): Internal.StringRepresentable$EnumCodec<E>;
        compareTo(arg0: Internal.Fox$Type_): number;
        getSerializedName(): string;
        static values(): Internal.Fox$Type[];
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        "compareTo(net.minecraft.world.entity.animal.Fox$Type)"(arg0: Internal.Fox$Type_): number;
        static fromEnum<E extends Internal.Enum<E> & Internal.StringRepresentable>($$0: Internal.Supplier_<E[]>): Internal.StringRepresentable$EnumCodec<E>;
        static byBiome($$0: Internal.Holder_<Internal.Biome>): Internal.Fox$Type;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.Fox$Type>>;
        getId(): number;
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        static byName($$0: string): Internal.Fox$Type;
        static byId($$0: number): Internal.Fox$Type;
        toString(): string;
        notifyAll(): void;
        getDeclaringClass(): typeof Internal.Fox$Type;
        name(): string;
        hashCode(): number;
        static keys($$0: Internal.StringRepresentable_[]): Internal.Keyable;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        "compareTo(java.lang.Object)"(arg0: any): number;
        static valueOf($$0: string): Internal.Fox$Type;
        equals(arg0: any): boolean;
        get class(): typeof any
        get serializedName(): string
        get id(): number
        get declaringClass(): typeof Internal.Fox$Type
        static readonly RED: (Internal.Fox$Type) & (Internal.Fox$Type);
        static readonly SNOW: (Internal.Fox$Type) & (Internal.Fox$Type);
        static readonly CODEC: Internal.StringRepresentable$EnumCodec<Internal.Fox$Type>;
    }
    type Fox$Type_ = "snow" | Fox$Type | "red";
    interface FloatPredicate extends Internal.DoublePredicate, Internal.Predicate<number> {
        /**
         * @deprecated
        */
        test(arg0: number): boolean;
        not<T>(arg0: Internal.Predicate_<T>): Internal.Predicate<T>;
        /**
         * @deprecated
        */
        "or(java.util.function.Predicate)"(arg0: Internal.Predicate_<number>): Internal.Predicate<number>;
        /**
         * @deprecated
        */
        or(arg0: Internal.Predicate_<number>): Internal.Predicate<number>;
        /**
         * @deprecated
        */
        "and(java.util.function.Predicate)"(arg0: Internal.Predicate_<number>): Internal.Predicate<number>;
        /**
         * @deprecated
        */
        test(arg0: number): boolean;
        /**
         * @deprecated
        */
        "test(java.lang.Float)"(arg0: number): boolean;
        /**
         * @deprecated
        */
        and(arg0: Internal.Predicate_<number>): Internal.Predicate<number>;
        /**
         * @deprecated
        */
        "test(double)"(arg0: number): boolean;
        "or(java.util.function.DoublePredicate)"(arg0: Internal.DoublePredicate_): this;
        and(arg0: Internal.FloatPredicate_): this;
        isEqual<T>(arg0: any): Internal.Predicate<T>;
        negate(): this;
        and(arg0: Internal.DoublePredicate_): this;
        /**
         * @deprecated
        */
        test(arg0: any): boolean;
        or(arg0: Internal.DoublePredicate_): this;
        "and(it.unimi.dsi.fastutil.floats.FloatPredicate)"(arg0: Internal.FloatPredicate_): this;
        abstract test(arg0: number): boolean;
        or(arg0: Internal.FloatPredicate_): this;
        "and(java.util.function.DoublePredicate)"(arg0: Internal.DoublePredicate_): this;
        /**
         * @deprecated
        */
        "test(java.lang.Object)"(arg0: any): boolean;
        abstract "test(float)"(arg0: number): boolean;
        "or(it.unimi.dsi.fastutil.floats.FloatPredicate)"(arg0: Internal.FloatPredicate_): this;
    }
    type FloatPredicate_ = FloatPredicate;
    interface ItemCaller {
        abstract cardinal_createComponents(arg0: Internal.ItemStack_): Internal.ComponentContainer;
        (arg0: Internal.ItemStack): Internal.ComponentContainer_;
    }
    type ItemCaller_ = ItemCaller | ((arg0: Internal.ItemStack)=> Internal.ComponentContainer_);
    interface RecipeManager$CachedCheck <C extends net.minecraft.world.Container, T extends Internal.Recipe<C>> {
        abstract getRecipeFor(arg0: C, arg1: Internal.Level_): Optional<T>;
        (arg0: C, arg1: Internal.Level): Optional_<T>;
    }
    type RecipeManager$CachedCheck_<C extends net.minecraft.world.Container, T extends Internal.Recipe<C>> = RecipeManager$CachedCheck<C, T> | ((arg0: C, arg1: Internal.Level)=> Optional_<T>);
    class JuicerRecipeSerializer implements Internal.RecipeSerializer<Internal.JuicerRecipe> {
        constructor()
        getClass(): typeof any;
        read(id: ResourceLocation_, buf: Internal.FriendlyByteBuf_): Internal.JuicerRecipe;
        toString(): string;
        "read(net.minecraft.resources.ResourceLocation,com.google.gson.JsonObject)"(id: ResourceLocation_, json: Internal.JsonObject_): Internal.JuicerRecipe;
        notifyAll(): void;
        "read(net.minecraft.resources.ResourceLocation,net.minecraft.network.FriendlyByteBuf)"(id: ResourceLocation_, buf: Internal.FriendlyByteBuf_): Internal.JuicerRecipe;
        toNetwork(arg0: Internal.FriendlyByteBuf_, arg1: Internal.Recipe_<any>): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        write(buf: Internal.FriendlyByteBuf_, recipe: Internal.JuicerRecipe_): void;
        static register<S extends Internal.RecipeSerializer<T>, T extends Internal.Recipe<any>>($$0: string, $$1: S): S;
        hashCode(): number;
        fromJson(arg0: ResourceLocation_, arg1: Internal.JsonObject_): Internal.Recipe<any>;
        wait(): void;
        wait(arg0: number): void;
        read(id: ResourceLocation_, json: Internal.JsonObject_): Internal.JuicerRecipe;
        equals(arg0: any): boolean;
        fromNetwork(arg0: ResourceLocation_, arg1: Internal.FriendlyByteBuf_): Internal.Recipe<any>;
        get class(): typeof any
    }
    type JuicerRecipeSerializer_ = JuicerRecipeSerializer;
    interface ManaCollector extends Internal.ManaReceiver {
        abstract getMaxMana(): number;
        abstract getManaYieldMultiplier(arg0: Internal.ManaBurst_): number;
        abstract receiveMana(arg0: number): void;
        abstract isFull(): boolean;
        abstract getManaReceiverPos(): BlockPos;
        abstract onClientDisplayTick(): void;
        abstract getCurrentMana(): number;
        abstract canReceiveManaFromBursts(): boolean;
        abstract getManaReceiverLevel(): Internal.Level;
        get maxMana(): number
        get full(): boolean
        get manaReceiverPos(): BlockPos
        get currentMana(): number
        get manaReceiverLevel(): Internal.Level
    }
    type ManaCollector_ = ManaCollector;
    class ModuleDescriptor$Exports implements Internal.Comparable<Internal.ModuleDescriptor$Exports> {
        getClass(): typeof any;
        isQualified(): boolean;
        toString(): string;
        targets(): Internal.Set<string>;
        notifyAll(): void;
        source(): string;
        compareTo(arg0: Internal.ModuleDescriptor$Exports_): number;
        modifiers(): Internal.Set<Internal.ModuleDescriptor$Exports$Modifier>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        "compareTo(java.lang.module.ModuleDescriptor$Exports)"(arg0: Internal.ModuleDescriptor$Exports_): number;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        get class(): typeof any
        get qualified(): boolean
    }
    type ModuleDescriptor$Exports_ = ModuleDescriptor$Exports;
    interface EquipmentEntity {
        lithiumOnEquipmentChanged(): void;
    }
    type EquipmentEntity_ = EquipmentEntity;
    abstract class InputEvent extends Internal.ComponentEvent {
        getClass(): typeof any;
        /**
         * @deprecated
        */
        getModifiers(): number;
        paramString(): string;
        notify(): void;
        getWhen(): number;
        wait(arg0: number, arg1: number): void;
        isAltDown(): boolean;
        setSource(arg0: any): void;
        getComponent(): Internal.Component;
        getSource(): any;
        isShiftDown(): boolean;
        static getModifiersExText(arg0: number): string;
        toString(): string;
        notifyAll(): void;
        isConsumed(): boolean;
        isControlDown(): boolean;
        static getMaskForButton(arg0: number): number;
        consume(): void;
        hashCode(): number;
        wait(): void;
        isMetaDown(): boolean;
        wait(arg0: number): void;
        isAltGraphDown(): boolean;
        equals(arg0: any): boolean;
        getModifiersEx(): number;
        getID(): number;
        get class(): typeof any
        /**
         * @deprecated
        */
        get modifiers(): number
        get when(): number
        get altDown(): boolean
        set source(arg0: any)
        get component(): Internal.Component
        get source(): any
        get shiftDown(): boolean
        get consumed(): boolean
        get controlDown(): boolean
        get metaDown(): boolean
        get altGraphDown(): boolean
        get modifiersEx(): number
        get ID(): number
        static readonly BUTTON3_DOWN_MASK: (4096) & (number);
        static readonly SHIFT_DOWN_MASK: (64) & (number);
        static readonly ALT_GRAPH_DOWN_MASK: (8192) & (number);
        static readonly META_DOWN_MASK: (256) & (number);
        static readonly BUTTON1_DOWN_MASK: (1024) & (number);
        /**
         * @deprecated
        */
        static readonly SHIFT_MASK: (1) & (number);
        /**
         * @deprecated
        */
        static readonly CTRL_MASK: (2) & (number);
        /**
         * @deprecated
        */
        static readonly BUTTON1_MASK: (16) & (number);
        /**
         * @deprecated
        */
        static readonly META_MASK: (4) & (number);
        /**
         * @deprecated
        */
        static readonly ALT_MASK: (8) & (number);
        /**
         * @deprecated
        */
        static readonly BUTTON2_MASK: (8) & (number);
        static readonly CTRL_DOWN_MASK: (128) & (number);
        static readonly BUTTON2_DOWN_MASK: (2048) & (number);
        /**
         * @deprecated
        */
        static readonly ALT_GRAPH_MASK: (32) & (number);
        static readonly ALT_DOWN_MASK: (512) & (number);
        /**
         * @deprecated
        */
        static readonly BUTTON3_MASK: (4) & (number);
    }
    type InputEvent_ = InputEvent;
    class UnitContext {
        constructor()
        getClass(): typeof any;
        pushDebug(): void;
        toString(): string;
        parse(input: string): Internal.Unit;
        notifyAll(): void;
        getFunctionFactory(name: string): Internal.FunctionFactory;
        debugInfo(s: string): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        debugInfo(s: string, values: Internal.Collection_<any>): void;
        hashCode(): number;
        sub(): this;
        popDebug(): void;
        addConstant(s: string, u: Internal.Unit_): void;
        wait(): void;
        wait(arg0: number): void;
        createStream(input: string): Internal.UnitTokenStream;
        equals(arg0: any): boolean;
        addFunction(factory: Internal.FunctionFactory_): void;
        isDebug(): boolean;
        get class(): typeof any
        get debug(): boolean
        static readonly DEFAULT: (Internal.UnitContext) & (Internal.UnitContext);
        readonly constants: Internal.Map<string, Internal.Unit>;
    }
    type UnitContext_ = UnitContext;
    class StringComponent extends Internal.Record implements Internal.RecipeComponent<string> {
        constructor(error: string, predicate: Internal.Predicate_<string>)
        predicate(): Internal.Predicate<string>;
        getClass(): typeof any;
        write(arg0: Internal.RecipeJS_, arg1: any): Internal.JsonElement;
        write(recipe: Internal.RecipeJS_, value: string): Internal.JsonPrimitive;
        checkEmpty(key: Internal.RecipeKey_<string>, value: string): string;
        asArray(): Internal.ArrayRecipeComponent<string>;
        and<O>(other: Internal.RecipeComponent_<O>): Internal.AndRecipeComponent<string, O>;
        checkValueHasChanged(oldValue: string, newValue: string): boolean;
        role(): Internal.ComponentRole;
        key(name: string): Internal.RecipeKey<string>;
        notify(): void;
        componentClass(): typeof any;
        wait(arg0: number, arg1: number): void;
        or<O>(other: Internal.RecipeComponent_<O>): Internal.OrRecipeComponent<string, O>;
        isInput(recipe: Internal.RecipeJS_, value: string, match: Internal.ReplacementMatch_): boolean;
        read(recipe: Internal.RecipeJS_, from: any): string;
        isOutput(recipe: Internal.RecipeJS_, value: string, match: Internal.ReplacementMatch_): boolean;
        constructorDescription(ctx: Internal.DescriptionContext_): Internal.TypeDescJS;
        replaceOutput(recipe: Internal.RecipeJS_, original: string, match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): string;
        componentType(): string;
        error(): string;
        "write(dev.latvian.mods.kubejs.recipe.RecipeJS,java.lang.String)"(recipe: Internal.RecipeJS_, value: string): Internal.JsonPrimitive;
        readFromMap(recipe: Internal.RecipeJS_, cv: Internal.RecipeComponentValue_<string>, map: Internal.Map_<any, any>): void;
        writeToJson(recipe: Internal.RecipeJS_, cv: Internal.RecipeComponentValue_<string>, json: Internal.JsonObject_): void;
        /**
         * Returns a new RecipeComponent that maps the keys in a JsonObject according to the provided map, both before the json gets passed to the component and after the component returns a written json object.
         * The mappings should be provided in the format `{recipe: "component"}` where recipe is the key as in the recipe, and component is the key as how the RecipeComponent expects it.
         * Any keys not included in the provided map will be ignored, and any keys in the provided map that are not in either the input object or output object will be ignored.
         * Note that if the input or output is not a JsonObject (ie its an ItemStack, or it is a JsonPrimitive) then that will pass through this without being modified.
         * If you wish to handle those situations use the actual map function
        */
        simpleMap(mappings: any): Internal.SimpleMappingRecipeComponent<string>;
        readFromJson(recipe: Internal.RecipeJS_, cv: Internal.RecipeComponentValue_<string>, json: Internal.JsonObject_): void;
        asPatternKey(): Internal.RecipeComponent<Internal.TinyMap<string, string>>;
        static builder(): Internal.RecipeComponentBuilder;
        toString(): string;
        hasPriority(recipe: Internal.RecipeJS_, from: any): boolean;
        notifyAll(): void;
        static builder(...key: Internal.RecipeKey_<any>[]): Internal.RecipeComponentBuilder;
        replaceInput(recipe: Internal.RecipeJS_, original: string, match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): string;
        asArrayOrSelf(): Internal.ArrayRecipeComponent<string>;
        asMap<K>(key: Internal.RecipeComponent_<K>): Internal.RecipeComponent<Internal.TinyMap<K, string>>;
        hashCode(): number;
        /**
         * Returns a new RecipeComponent that applies the mappingFrom function after the component writes to json, before that json is saved
        */
        mapOut(mappingFrom: Internal.UnaryOperator_<Internal.JsonElement>): Internal.MappingRecipeComponent<string>;
        orSelf(): Internal.RecipeComponent<string>;
        wait(): void;
        wait(arg0: number): void;
        "write(dev.latvian.mods.kubejs.recipe.RecipeJS,java.lang.Object)"(arg0: Internal.RecipeJS_, arg1: any): Internal.JsonElement;
        /**
         * Returns a new RecipeComponent that applies the mappingTo function to the input before it is passed to this component to be read
        */
        mapIn(mappingTo: Internal.UnaryOperator_<any>): Internal.MappingRecipeComponent<string>;
        equals(o: any): boolean;
        /**
         * Returns a new RecipeComponent that applies the mappingTo function to the input before it is passed to this component to be read, and the mappingFrom function after the component writes to json, before that json is saved
        */
        map(mappingTo: Internal.UnaryOperator_<any>, mappingFrom: Internal.UnaryOperator_<Internal.JsonElement>): Internal.MappingRecipeComponent<string>;
        get class(): typeof any
        static readonly CHARACTER: (Internal.StringComponent$1) & (Internal.RecipeComponent<string>);
        static readonly ANY: (Internal.StringComponent) & (Internal.RecipeComponent<string>);
        static readonly NON_BLANK: (Internal.StringComponent) & (Internal.RecipeComponent<string>);
        static readonly DYNAMIC: (Internal.DynamicRecipeComponent) & (Internal.DynamicRecipeComponent);
        static readonly ID: (Internal.StringComponent) & (Internal.RecipeComponent<string>);
        static readonly NON_EMPTY: (Internal.StringComponent) & (Internal.RecipeComponent<string>);
    }
    type StringComponent_ = StringComponent;
    class Llama extends Internal.AbstractChestedHorse implements Internal.RangedAttackMob, Internal.VariantHolder<Internal.Llama$Variant> {
        constructor($$0: Internal.EntityType_<Internal.Llama>, $$1: Internal.Level_)
        handler$hak000$gobber2$gobberOccludeVibrationSignals(cir: Internal.CallbackInfoReturnable_<any>): void;
        handler$fed001$extraalchemy$writeNbt(tag: Internal.CompoundTag_, cb: Internal.CallbackInfo_): void;
        etf$getType(): Internal.EntityType<any>;
        getUpVector($$0: number): Vec3d;
        gameEvent($$0: Internal.GameEvent_, $$1: Internal.Entity_): void;
        static checkMobSpawnRules($$0: Internal.EntityType_<Internal.Mob>, $$1: Internal.LevelAccessor_, $$2: Internal.MobSpawnType_, $$3: BlockPos_, $$4: Internal.RandomSource_): boolean;
        setDefaultMovementSpeedMultiplier(speed: number): void;
        handler$gdo000$faster_entity_animations$getEatingAnimationProgress(f: number, info: Internal.CallbackInfoReturnable_<any>): void;
        isSuppressingBounce(): boolean;
        setTarget($$0: Internal.LivingEntity_): void;
        handler$gdo000$faster_entity_animations$getAngryAnimationProgress(f: number, info: Internal.CallbackInfoReturnable_<any>): void;
        handler$han001$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        setCulled(value: boolean): void;
        handler$leb003$puzzleslib$hurt(source: DamageSource_, amount: number, callback: Internal.CallbackInfoReturnable_<any>): void;
        isOnFire(): boolean;
        getOwner(): Internal.LivingEntity;
        getPositionCodec(): Internal.VecDeltaCodec;
        setMaxUpStep($$0: number): void;
        updateFluidHeightAndDoFluidPushing($$0: Internal.TagKey_<Internal.Fluid>, $$1: number): boolean;
        convertTo<T extends Internal.Mob>($$0: Internal.EntityType_<T>, $$1: boolean): T;
        getFallFlyingTicks(): number;
        setPosition(x: number, y: number, z: number): void;
        runCommandSilent(command: string): number;
        chunkPosition(): Internal.ChunkPos;
        emf$isOnGround(): boolean;
        dropLeash($$0: boolean, $$1: boolean): void;
        gameEvent($$0: Internal.GameEvent_): void;
        setXxa($$0: number): void;
        setDelayedLeashHolderId($$0: number): void;
        isShiftKeyDown(): boolean;
        setUUID($$0: Internal.UUID_): void;
        checkBelowWorld(): void;
        handler$leb000$puzzleslib$startUsingItem(hand: Internal.InteractionHand_, callback: Internal.CallbackInfo_): void;
        setMotionZ(z: number): void;
        "deserializeNBT(net.minecraft.nbt.Tag)"(arg0: Internal.Tag_): void;
        canFreeze(): boolean;
        ignoreExplosion(): boolean;
        getBlockY(): number;
        getIsInsideStructureTracker(): Internal.IsInsideStructureTracker;
        setPlayerHitTimer(arg0: number): void;
        isSpectator(): boolean;
        setMainHandItem(item: Internal.ItemStack_): void;
        removeEffectNoUpdate($$0: Internal.MobEffect_): Internal.MobEffectInstance;
        spawnAtLocation($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        getPersistentData(): Internal.CompoundTag;
        getHealth(): number;
        getMaxHealth(): number;
        emf$isGlowing(): boolean;
        setPathfindingMalus($$0: Internal.BlockPathTypes_, $$1: number): void;
        isRegisteredToWorld(): boolean;
        getRandomZ($$0: number): number;
        pehkui_getOnGround(): boolean;
        setAggressive($$0: boolean): void;
        handler$lef000$puzzleslib$checkDespawn(callback: Internal.CallbackInfo_): void;
        getFusionModel(layerIndex: number): Internal.Triple<any, any, any>;
        setRemoved($$0: Internal.Entity$RemovalReason_): void;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>, initializer: Internal.Supplier_<A>): A;
        getDistanceSq($$0: number, $$1: number, $$2: number): number;
        isInWaterRainOrBubble(): boolean;
        getRemovalReason(): Internal.Entity$RemovalReason;
        etf$getVelocity(): Vec3d;
        handler$lcn000$puzzleslib$executeRidersJump(playerJumpPendingScale: number, travelVector: Vec3d_, callback: Internal.CallbackInfo_): void;
        hex$markHurt(): void;
        resetFallDistance(): void;
        canSprint(): boolean;
        blockPosition(): BlockPos;
        isEating(): boolean;
        setBoundingBox($$0: Internal.AABB_): void;
        isAmbientCreature(): boolean;
        setZza($$0: number): void;
        getBlock(): Internal.BlockContainerJS;
        setEquipment(slot: Internal.EquipmentSlot_, item: Internal.ItemStack_): void;
        etf$getHandItems(): Internal.Iterable<any>;
        randomTeleport($$0: number, $$1: number, $$2: number, $$3: boolean): boolean;
        getName(): net.minecraft.network.chat.Component;
        playAmbientSound(): void;
        onGround(): boolean;
        handler$leb000$puzzleslib$canBeAffected(effectInstance: Internal.MobEffectInstance_, callback: Internal.CallbackInfoReturnable_<any>): void;
        getControlledVehicle(): Internal.Entity;
        isOnSameTeam($$0: Internal.Entity_): boolean;
        getArmorValue(): number;
        tick(): void;
        localvar$lef000$puzzleslib$setTarget(entity: Internal.LivingEntity_): Internal.LivingEntity;
        getKillCredit(): Internal.LivingEntity;
        emf$isTouchingWater(): boolean;
        emf$getVariableMap(): Internal.Object2FloatOpenHashMap<any>;
        getComponentContainer(): Internal.ComponentContainer;
        hasPermissions($$0: number): boolean;
        getDynamicLightPrevZ(): number;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        pehkui_readScaleNbt(nbt: Internal.CompoundTag_): void;
        setOutOfCamera(value: boolean): void;
        static createMobAttributes(): Internal.AttributeSupplier$Builder;
        isAutoSpinAttack(): boolean;
        getRemainingFireTicks(): number;
        botania_getAmbientSound(): Internal.SoundEvent;
        onlyOpCanSetNbt(): boolean;
        tcdcommons_getCustomData(): Internal.GenericProperties<any>;
        fireImmune(): boolean;
        addMotion($$0: number, $$1: number, $$2: number): void;
        getMaxFallDistance(): number;
        isHolding($$0: Internal.Item_): boolean;
        getZ($$0: number): number;
        static areAllEffectsAmbient($$0: Internal.Collection_<Internal.MobEffectInstance>): boolean;
        doHurtTarget($$0: Internal.Entity_): boolean;
        hasCaravanTail(): boolean;
        getTicksFrozen(): number;
        wrapWithCondition$kom000$porting_lib_entity$port_lib$captureDrops(level: Internal.Level_, entity: Internal.Entity_): boolean;
        handler$lef000$puzzleslib$addAdditionalSaveData(compound: Internal.CompoundTag_, callback: Internal.CallbackInfo_): void;
        deflect(chance: number, source: Internal.Entity_): boolean;
        getRandomX($$0: number): number;
        getDynamicLightZ(): number;
        spawnAtLocation($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        pick($$0: number, $$1: number, $$2: boolean): Internal.HitResult;
        getVoicePitch(): number;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        setSleepingPos($$0: BlockPos_): void;
        changeDimension(p_20118_: Internal.ServerLevel_, teleporter: Internal.ITeleporter_): Internal.Entity;
        isDescending(): boolean;
        getAttributeBaseValue($$0: Internal.Attribute_): number;
        emf$getPitch(): number;
        sendEffectToPassengers($$0: Internal.MobEffectInstance_): void;
        getHeadRotSpeed(): number;
        getLastHurtByPlayer(): Internal.Player;
        getYHeadRot(): number;
        handler$cbi000$besmirchment$isTeammate(other: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>): void;
        localvar$leb000$puzzleslib$addEffect(oldEffectInstance: Internal.MobEffectInstance_, effectInstance: Internal.MobEffectInstance_, entity: Internal.Entity_): Internal.MobEffectInstance;
        getProjectile($$0: Internal.ItemStack_): Internal.ItemStack;
        static getAlpha(le: Internal.LivingEntity_, partialTicks: number): number;
        frameworkGetDataHolder(): com.mrcrayfish.framework.entity.sync.DataHolder;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        syncPacketPositionCodec($$0: number, $$1: number, $$2: number): void;
        setAbsorptionAmount($$0: number): void;
        setRecallData(pos: Internal.DimensionalPosition_): void;
        port_lib$spawnItemParticles(arg0: Internal.ItemStack_, arg1: number): void;
        shouldRenderAtSqrDistance($$0: number): boolean;
        getAttachedOrSet<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        damageSources(): Internal.DamageSources;
        removeAttached<A>(type: Internal.AttachmentType_<A>): A;
        removeAllGoals($$0: Internal.Predicate_<Internal.Goal>): void;
        swing(): void;
        recreateFromPacket($$0: Internal.ClientboundAddEntityPacket_): void;
        setDeltaMovement($$0: Vec3d_): void;
        getLeashOffset($$0: number): Vec3d;
        isBaby(): boolean;
        isCulled(): boolean;
        damageEquipment(slot: Internal.EquipmentSlot_): void;
        isGlowing(): boolean;
        getWalkTargetValue($$0: BlockPos_): number;
        canBreatheUnderwater(): boolean;
        getLeashedByEntities(): Internal.Set<any>;
        die($$0: DamageSource_): void;
        etf$getOptifineId(): number;
        getLeashOffset(): Vec3d;
        removeAllEffects(): boolean;
        dynamicLightWorld(): Internal.Level;
        fedFood($$0: Internal.Player_, $$1: Internal.ItemStack_): Internal.InteractionResult;
        hasLineOfSight($$0: Internal.Entity_): boolean;
        hex$getLastHurt(): number;
        onClimbable(): boolean;
        isAttackable(): boolean;
        getSaddleSoundEvent(): Internal.SoundEvent;
        getSlot($$0: number): Internal.SlotAccess;
        "deserializeNBT(net.minecraft.nbt.CompoundTag)"(nbt: Internal.CompoundTag_): void;
        emf$isInLava(): boolean;
        pehkui_constructScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        stopSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isUnderWater(): boolean;
        stopRiding(): void;
        getLeashHolder(): Internal.Entity;
        getX($$0: number): number;
        getSensing(): Internal.Sensing;
        localvar$kpc000$porting_lib_entity$port_lib$modifyMultiplier(multiplier: number): number;
        getLegsArmorItem(): Internal.ItemStack;
        getLuminance(): number;
        callUnsetRemoved(): void;
        captureDrops(value: Internal.Collection_<Internal.ItemEntity>): Internal.Collection<Internal.ItemEntity>;
        getSelfAndPassengers(): Internal.Stream<any>;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        handler$egi000$collective$LivingEntity_hurt(damageSource: DamageSource_, f: number, ci: Internal.CallbackInfoReturnable_<any>): void;
        getDeltaMovement(): Vec3d;
        canTakeItem($$0: Internal.ItemStack_): boolean;
        shouldDropExperience(): boolean;
        hasPassenger($$0: Internal.Entity_): boolean;
        be_getTravelerState(): Internal.TravelerState;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        getDynamicLightX(): number;
        setSecondsOnFire($$0: number): void;
        moveTo($$0: number, $$1: number, $$2: number): void;
        emf$getZ(): number;
        "getDisplayName()"(): net.minecraft.network.chat.Component;
        getLootTable(): ResourceLocation;
        getTicksUsingItem(): number;
        bettertrims$getWornMaterials(): Internal.List<any>;
        getArrowCount(): number;
        getMoveControl(): Internal.MoveControl;
        setMotion($$0: number, $$1: number, $$2: number): void;
        setStanding($$0: boolean): void;
        playSound($$0: Internal.SoundEvent_): void;
        handler$mjp000$supplementaries$eatSugarCube(player: Internal.Player_, stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getDefaultMovementSpeed(): number;
        handler$ikg000$lithium$tryShortcutFluidPushing(tag: Internal.TagKey_<any>, speed: number, cir: Internal.CallbackInfoReturnable_<any>, box: Internal.AABB_, x1: number, x2: number, y1: number, y2: number, z1: number, z2: number, zero: number): void;
        handler$hak000$gobber2$setFrozenTicks(frozenTicks: number, ci: Internal.CallbackInfo_): void;
        restoreFrom($$0: Internal.Entity_): void;
        method_6062(): boolean;
        isPeacefulCreature(): boolean;
        setOnGround($$0: boolean): void;
        addEffect($$0: Internal.MobEffectInstance_, $$1: Internal.Entity_): boolean;
        emf$getYaw(): number;
        ate(): void;
        setPos($$0: number, $$1: number, $$2: number): void;
        notify(): void;
        setPersistenceRequired(): void;
        getLastHurtByMobTimestamp(): number;
        getVehicle(): Internal.Entity;
        canFallInLove(): boolean;
        isEffectiveAi(): boolean;
        handler$kom000$porting_lib_entity$port_lib$startRiding(entity: Internal.Entity_, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        startRiding($$0: Internal.Entity_, $$1: boolean): boolean;
        leaveCaravan(): void;
        getStringUuid(): string;
        setSwimming($$0: boolean): void;
        getMainArm(): Internal.HumanoidArm;
        checkSpawnRules($$0: Internal.LevelAccessor_, $$1: Internal.MobSpawnType_): boolean;
        getRotationVector(): Internal.Vec2;
        getHurtDir(): number;
        etf$getBlockY(): number;
        isSprinting(): boolean;
        isMaxGroupSizeReached($$0: number): boolean;
        getMotionY(): number;
        getOffhandItem(): Internal.ItemStack;
        canCollideWith($$0: Internal.Entity_): boolean;
        setLuminance(luminance: number): void;
        getBlockExplosionResistance($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.FluidState_, $$5: number): number;
        setLootTable(arg0: ResourceLocation_): void;
        clearSleepingPos(): void;
        canSpawnSprintParticle(): boolean;
        "moveTo(net.minecraft.core.BlockPos,float,float)"($$0: BlockPos_, $$1: number, $$2: number): void;
        hex$checkTotemDeathProtection(arg0: DamageSource_): boolean;
        getLastHurtMob(): Internal.LivingEntity;
        moveRelative($$0: number, $$1: Vec3d_): void;
        saveAsPassenger($$0: Internal.CompoundTag_): boolean;
        static gatherClosestChunks(chunks: Internal.LongSet_, x: number, y: number, z: number): void;
        handler$kom000$porting_lib_entity$afterSave(nbt: Internal.CompoundTag_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDamageSource(): DamageSource;
        getSoundSource(): Internal.SoundSource;
        isJumping(): boolean;
        setNoActionTime($$0: number): void;
        setMovementSpeedAddition(speed: number): void;
        removeAfterChangingDimensions(): void;
        equipmentHasChanged($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        getPose(): Internal.Pose;
        getAttribute($$0: Internal.Attribute_): Internal.AttributeInstance;
        setPositionAndRotation($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        canBeAffected($$0: Internal.MobEffectInstance_): boolean;
        ageUp($$0: number): void;
        getRestrictCenter(): BlockPos;
        isLeftHanded(): boolean;
        invokeShouldDropLoot(): boolean;
        handler$kpc000$porting_lib_entity$port_lib$onFinishUsing(ci: Internal.CallbackInfo_, hand: Internal.InteractionHand_, result: Internal.ItemStack_): void;
        etf$getUuid(): Internal.UUID;
        removeVehicle(): void;
        shouldFusionRecomputeModel(layerIndex: number): boolean;
        modifyExpressionValue$zcl000$porting_lib_base$port_lib$canContinueUsing(original: boolean): boolean;
        setZ(z: number): void;
        getY(): number;
        deserializeNBT(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        finalizeSpawnChildFromBreeding($$0: Internal.ServerLevel_, $$1: Internal.Animal_, $$2: Internal.AgeableMob_): void;
        eat($$0: Internal.Level_, $$1: Internal.ItemStack_): Internal.ItemStack;
        setIsJumping($$0: boolean): void;
        bookshelf$makePoofParticles(): void;
        isWithinMeleeAttackRange($$0: Internal.LivingEntity_): boolean;
        setCurrentModifyFoodPowers(powers: Internal.List_<any>): void;
        broadcastBreakEvent($$0: Internal.EquipmentSlot_): void;
        modifyExpressionValue$zhf000$additionalentityattributes$additionalEntityAttributes$modifyUpwardSwimming(original: number, fluid: Internal.TagKey_<any>): number;
        handler$nbm000$things$onShieldBlock(source: DamageSource_, cir: Internal.CallbackInfoReturnable_<any>): void;
        showVehicleHealth(): boolean;
        getDistance(pos: BlockPos_): number;
        isBlocking(): boolean;
        "getBreedOffspring(net.minecraft.server.level.ServerLevel,net.minecraft.world.entity.AgeableMob)"(arg0: Internal.ServerLevel_, arg1: Internal.AgeableMob_): Internal.AgeableMob;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number): void;
        removeAttribute(attribute: Internal.Attribute_, identifier: string): void;
        emf$getVelocity(): Vec3d;
        handler$lef000$puzzleslib$finalizeSpawn(level: Internal.ServerLevelAccessor_, difficulty: Internal.DifficultyInstance_, reason: Internal.MobSpawnType_, spawnData: Internal.SpawnGroupData_, dataTag: Internal.CompoundTag_, callback: Internal.CallbackInfoReturnable_<any>): void;
        etf$isBlockEntity(): boolean;
        shouldUpdateDynamicLight(): boolean;
        isPushedByFluid(): boolean;
        setOriginalFoodStack(original: Internal.ItemStack_): void;
        getArmorCoverPercentage(): number;
        handleRelativeFrictionAndCalculateMovement($$0: Vec3d_, $$1: number): Vec3d;
        turn($$0: number, $$1: number): void;
        getAirSupply(): number;
        moveTo($$0: BlockPos_, $$1: number, $$2: number): void;
        isPlayer(): boolean;
        isAnimal(): boolean;
        "handler$fgd000$fabric-dimensions-v1$getTeleportTarget"(destination: Internal.ServerLevel_, cir: Internal.CallbackInfoReturnable_<any>): void;
        canBeCollidedWith(): boolean;
        getMotionDirection(): Internal.Direction;
        asComponentProvider(): Internal.ComponentProvider;
        lavaHurt(): void;
        handleDamageEvent($$0: DamageSource_): void;
        getFabricBalmData(): Internal.CompoundTag;
        canChangeDimensions(): boolean;
        static tickEntity(entity: Internal.Entity_): void;
        getCommandSenderWorld(): Internal.Level;
        getTotalMovementSpeed(): number;
        changeDimension($$0: Internal.ServerLevel_): Internal.Entity;
        localvar$zno000$apoli$modifyFallingVelocity(in_: number): number;
        handler$kom000$porting_lib_entity$afterLoad(nbt: Internal.CompoundTag_, ci: Internal.CallbackInfo_): void;
        pehkui_shouldIgnoreScaleNbt(): boolean;
        isMoving(): boolean;
        attack(hp: number): void;
        getAttributes(): Internal.AttributeMap;
        "hasPassenger(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.Entity>): boolean;
        botania_playHurtSound(arg0: DamageSource_): void;
        getDimensions($$0: Internal.Pose_): Internal.EntityDimensions;
        spawnChildFromBreeding($$0: Internal.ServerLevel_, $$1: Internal.Animal_): void;
        setInLoveTime($$0: number): void;
        invokeGetLeashOffset(): Vec3d;
        isSwimming(): boolean;
        setSprinting($$0: boolean): void;
        mayInteract($$0: Internal.Level_, $$1: BlockPos_): boolean;
        handler$kpc000$porting_lib_entity$port_lib$attackEvent(source: DamageSource_, amount: number, cir: Internal.CallbackInfoReturnable_<any>): void;
        getDynamicLightLevel(): Internal.Level;
        setPortalCooldown(): void;
        getAttackAnim($$0: number): number;
        hex$setLastHurt(arg0: number): void;
        setX(x: number): void;
        getPortalWaitTime(): number;
        getBlockStateOn(): Internal.BlockState;
        wantsToPickUp($$0: Internal.ItemStack_): boolean;
        getItemBySlot($$0: Internal.EquipmentSlot_): Internal.ItemStack;
        getFluidHeightLoosely(tag: Internal.TagKey_<any>): number;
        setOwnerUUID($$0: Internal.UUID_): void;
        getFluidJumpThreshold(): number;
        handler$elg000$crittersandcompanions$onRegisterGoals(callback: Internal.CallbackInfo_): void;
        getCachedSouls(): number;
        "getVariant()"(): any;
        "setPositionAndRotation(double,double,double,float,float)"($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        isInvisibleTo($$0: Internal.Player_): boolean;
        stopSleeping(): void;
        setAirSupply($$0: number): void;
        getOnPos(): BlockPos;
        etf$getWorld(): Internal.Level;
        isUndead(): boolean;
        static createBaseHorseAttributes(): Internal.AttributeSupplier$Builder;
        static createLivingAttributes(): Internal.AttributeSupplier$Builder;
        setUseItemRemaining(arg0: number): void;
        pehkui_getScales(): Internal.Map<any, any>;
        getTargetSelector(): Internal.GoalSelector;
        setRegisteredToWorld(navigation: Internal.PathNavigation_): void;
        isSleeping(): boolean;
        stopUsingItem(): void;
        etf$getNbt(): Internal.CompoundTag;
        acceptsFailure(): boolean;
        etf$getBlockPos(): BlockPos;
        pehkui_setShouldIgnoreScaleNbt(ignore: boolean): void;
        setOnGroundWithKnownMovement($$0: boolean, $$1: Vec3d_): void;
        getFluidFallingAdjustedMovement($$0: number, $$1: boolean, $$2: Vec3d_): Vec3d;
        setOldPosAndRot(): void;
        localvar$cjk000$bettertridents$doHurtTarget$modifyVariable$store(damageAmount: number, entity: Internal.Entity_): number;
        isFree($$0: number, $$1: number, $$2: number): boolean;
        getDismountPoses(): Internal.ImmutableList<Internal.Pose>;
        getLastHurtMobTimestamp(): number;
        lithiumOnEquipmentChanged(): void;
        "moveTo(double,double,double)"($$0: number, $$1: number, $$2: number): void;
        setRemainingFireTicks($$0: number): void;
        emf$age(): number;
        etf$hasCustomName(): boolean;
        /**
         * @deprecated
        */
        getOnPosLegacy(): BlockPos;
        port_lib$isJumping(): boolean;
        setPos($$0: Vec3d_): void;
        localvar$leb000$puzzleslib$knockback$2(ratioX: number): number;
        static "tickEntity(net.minecraft.world.entity.LivingEntity)"(entity: Internal.LivingEntity_): void;
        updateCachedSouls(): void;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        setCanPickUpLoot($$0: boolean): void;
        getMainHandItem(): Internal.ItemStack;
        canEatGrass(): boolean;
        handler$kom000$porting_lib_entity$port_lib$removeRidingEntity(ci: Internal.CallbackInfo_): void;
        setSilent($$0: boolean): void;
        openCustomInventoryScreen($$0: Internal.Player_): void;
        captureDrops(): Internal.Collection<Internal.ItemEntity>;
        hasExactlyOnePlayerPassenger(): boolean;
        canBeSeenAsEnemy(): boolean;
        setLeftHanded($$0: boolean): void;
        getActiveEffects(): Internal.Collection<Internal.MobEffectInstance>;
        isOnPortalCooldown(): boolean;
        hurtArmor($$0: DamageSource_, $$1: number): void;
        canAttack($$0: Internal.LivingEntity_, $$1: Internal.TargetingConditions_): boolean;
        performRangedAttack($$0: Internal.LivingEntity_, $$1: number): void;
        getAttributeValue($$0: Internal.Holder_<Internal.Attribute>): number;
        lambdynlights$setTrackedLitChunkPos(trackedLitChunkPos: Internal.LongSet_): void;
        fzzy_core_setModifierContainer(container: Internal.ModifierContainer_): void;
        setPitch($$0: number): void;
        setPosRaw($$0: number, $$1: number, $$2: number): void;
        handleEntityEvent($$0: number): void;
        isUsingItem(): boolean;
        isAlwaysTicking(): boolean;
        interactAt($$0: Internal.Player_, $$1: Vec3d_, $$2: Internal.InteractionHand_): Internal.InteractionResult;
        emf$getX(): number;
        puzzleslib$acceptCapturedDrops(capturedDrops: Internal.Collection_<any>): Internal.Collection<any>;
        getInventoryColumns(): number;
        handler$hak000$gobber2$gobberIsFireImmune(cir: Internal.CallbackInfoReturnable_<any>): void;
        onPlayerJump($$0: number): void;
        lerpTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: boolean): void;
        onPassengerTurned($$0: Internal.Entity_): void;
        modifyReturnValue$zhe000$additionalentityattributes$getMaxAir(original: number): number;
        spawnAtLocation($$0: Internal.ItemLike_): Internal.ItemEntity;
        emf$hasPassengers(): boolean;
        serializeNBT(): Internal.CompoundTag;
        setAttached(type: Internal.AttachmentType_<any>, value: any): any;
        port_lib$getEntityString(): string;
        markEffectsDirty(): void;
        "getVariant()"(): Internal.Llama$Variant;
        lithiumOnBlockCacheDeleted(): void;
        "spawnAtLocation(net.minecraft.world.level.ItemLike,int)"($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        setInvulnerable($$0: boolean): void;
        push($$0: Internal.Entity_): void;
        emf$hasVehicle(): boolean;
        canMate($$0: Internal.Animal_): boolean;
        method_5992($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        maxUpStep(): number;
        getDynamicLightPrevY(): number;
        localvar$leb000$puzzleslib$hurt$1(amount: number, source: DamageSource_): number;
        setGlowing($$0: boolean): void;
        load($$0: Internal.CompoundTag_): void;
        "broadcastBreakEvent(net.minecraft.world.entity.EquipmentSlot)"($$0: Internal.EquipmentSlot_): void;
        setLeashedTo($$0: Internal.Entity_, $$1: boolean): void;
        isAlive(): boolean;
        startSleeping($$0: BlockPos_): void;
        isTraderLlama(): boolean;
        getBbHeight(): number;
        getMeleeAttackRangeSqr($$0: Internal.LivingEntity_): number;
        handler$fed002$extraalchemy$readNbt(tag: Internal.CompoundTag_, cb: Internal.CallbackInfo_): void;
        bookshelf$getDrinkingSound(arg0: Internal.ItemStack_): Internal.SoundEvent;
        getTags(): Internal.Set<string>;
        getViewVector($$0: number): Vec3d;
        getLastAttacker(): Internal.LivingEntity;
        hasControllingPassenger(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number, $$2: number): boolean;
        absMoveTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        getLastRollTicks(): number;
        getGoalSelector(): Internal.GoalSelector;
        localvar$leb000$puzzleslib$causeFallDamage$2(damageMultiplier: number): number;
        onPathfindingStart(): void;
        handler$zzb000$porting_lib_attributes$port_lib$entityGravity(travelVector: Vec3d_, ci: Internal.CallbackInfo_): void;
        getPercentFrozen(): number;
        setPortalCooldown($$0: number): void;
        hasGlowingTag(): boolean;
        shouldBlockExplode($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: number): boolean;
        emf$isInvisible(): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        isLeashed(): boolean;
        addEffect($$0: Internal.MobEffectInstance_): boolean;
        emf$isSprinting(): boolean;
        handler$leb000$puzzleslib$knockback$0(strength: number, ratioX: number, ratioZ: number, callback: Internal.CallbackInfo_): void;
        getVariant(): any;
        ageUp($$0: number, $$1: boolean): void;
        handler$egi000$collective$LivingEntity_tick(ci: Internal.CallbackInfo_): void;
        handler$gec000$faster_entity_animations$getLeaningPitch(f: number, info: Internal.CallbackInfoReturnable_<any>): void;
        canRiderInteract(): boolean;
        getViewXRot($$0: number): number;
        handler$leb001$puzzleslib$die(damageSource: DamageSource_, callback: Internal.CallbackInfo_): void;
        fabric_getAttachments(): Internal.Map<any, any>;
        setPose($$0: Internal.Pose_): void;
        getReachDistance(): number;
        setChest($$0: boolean): void;
        getEntityType(): Internal.EntityType<any>;
        isWaterCreature(): boolean;
        hex$playHurtSound(arg0: DamageSource_): void;
        pehkui_getScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        toString(): string;
        canWearArmor(): boolean;
        etf$getScoreboardTeam(): Internal.Team;
        getBreedOffspring(arg0: Internal.ServerLevel_, arg1: Internal.AgeableMob_): Internal.AgeableMob;
        setLastHurtByPlayer($$0: Internal.Player_): void;
        handler$ldh000$puzzleslib$removeVehicle(callback: Internal.CallbackInfo_): void;
        "getServer()"(): Internal.MinecraftServer;
        getAmbientStandSound(): Internal.SoundEvent;
        wasExperienceConsumed(): boolean;
        isPushable(): boolean;
        setYBodyRot($$0: number): void;
        foodEaten(is: Internal.ItemStack_): void;
        onClientRemoval(): void;
        getDistance(x: number, y: number, z: number): number;
        setMotionY(y: number): void;
        static createAttributes(): Internal.AttributeSupplier$Builder;
        localvar$lcp000$puzzleslib$spawnChildFromBreeding(child: Internal.AgeableMob_, serverLevel: Internal.ServerLevel_, partner: Internal.Animal_): Internal.AgeableMob;
        getAttached(type: Internal.AttachmentType_<any>): any;
        setRotation(yaw: number, pitch: number): void;
        isDynamicLightEnabled(): boolean;
        handler$ldh000$puzzleslib$startRiding(vehicle: Internal.Entity_, force: boolean, callback: Internal.CallbackInfoReturnable_<any>): void;
        calculateEntityAnimation($$0: boolean): void;
        forceAddEffect($$0: Internal.MobEffectInstance_, $$1: Internal.Entity_): void;
        setBred($$0: boolean): void;
        setChestArmorItem(item: Internal.ItemStack_): void;
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        bookshelf$getHurtSound(arg0: DamageSource_): Internal.SoundEvent;
        onAboveBubbleCol($$0: boolean): void;
        archon$setOwner(uiud: string): void;
        "playSound(net.minecraft.sounds.SoundEvent,float,float)"(id: Internal.SoundEvent_, volume: number, pitch: number): void;
        toComponentPacket(key: Internal.ComponentKey_<any>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        isPassenger(): boolean;
        hasPose($$0: Internal.Pose_): boolean;
        supp$setSlimedTicks(newSlimedTicks: number, sync: boolean): void;
        isEyeInFluid($$0: Internal.TagKey_<Internal.Fluid>): boolean;
        isInvulnerableTo($$0: DamageSource_): boolean;
        makeStuckInBlock($$0: Internal.BlockState_, $$1: Vec3d_): void;
        getAttachedOrGet<A>(type: Internal.AttachmentType_<A>, defaultValue: Internal.Supplier_<A>): A;
        isSensitiveToWater(): boolean;
        skipAttackInteraction($$0: Internal.Entity_): boolean;
        lerpMotion($$0: number, $$1: number, $$2: number): void;
        "getAttributeValue(net.minecraft.core.Holder)"($$0: Internal.Holder_<Internal.Attribute>): number;
        shouldRender($$0: number, $$1: number, $$2: number): boolean;
        getJumpControl(): Internal.JumpControl;
        localvar$zcl000$porting_lib_base$port_lib$setSlipperiness(p: number): number;
        getFeetArmorItem(): Internal.ItemStack;
        isSaddleable(): boolean;
        handler$bia000$axiom$onTurn(d: number, e: number, ci: Internal.CallbackInfo_): void;
        getVariant(): Internal.Llama$Variant;
        static getViewScale(): number;
        handler$mpg000$tcdcommons$onAddStatusEffect(effect: Internal.MobEffectInstance_, source: Internal.Entity_, ci: Internal.CallbackInfoReturnable_<any>): void;
        getVisualRotationYInDegrees(): number;
        setSpeed($$0: number): void;
        getSwag(): Internal.DyeColor;
        requiresCustomPersistence(): boolean;
        handler$nbm000$things$onShieldHit(attacker: Internal.LivingEntity_, ci: Internal.CallbackInfo_): void;
        isDiscrete(): boolean;
        unRide(): void;
        getLevel(): Internal.Level;
        "spawnAtLocation(net.minecraft.world.item.ItemStack)"($$0: Internal.ItemStack_): Internal.ItemEntity;
        getBreedOffspring($$0: Internal.ServerLevel_, $$1: Internal.AgeableMob_): this;
        getCombatTracker(): Internal.CombatTracker;
        getCustomJump(): number;
        updateDynamicGameEventListener($$0: Internal.BiConsumer_<Internal.DynamicGameEventListener<any>, Internal.ServerLevel>): void;
        canBreed(): boolean;
        "onSyncedDataUpdated(net.minecraft.network.syncher.EntityDataAccessor)"($$0: Internal.EntityDataAccessor_<any>): void;
        emf$prevY(): number;
        isNoAi(): boolean;
        extinguishFire(): void;
        getChestArmorItem(): Internal.ItemStack;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number): void;
        port_lib$lastPos(): BlockPos;
        tell(message: net.minecraft.network.chat.Component_): void;
        closerThan($$0: Internal.Entity_, $$1: number): boolean;
        hex$getSoundVolume(): number;
        getDistanceSq(pos: BlockPos_): number;
        indicateDamage($$0: number, $$1: number): void;
        localvar$nbm000$things$waxGlandWater(j: number): number;
        canBeSeenByAnyone(): boolean;
        emf$getTypeString(): string;
        setVariant(arg0: any): void;
        isFullyFrozen(): boolean;
        litematica_setWorld(arg0: Internal.Level_): void;
        isInWall(): boolean;
        getAllSlots(): Internal.Iterable<Internal.ItemStack>;
        getInventory(): Internal.SimpleContainer;
        handler$bfg003$artifacts$tick(ci: Internal.CallbackInfo_): void;
        remove($$0: Internal.Entity$RemovalReason_): void;
        getScale(): number;
        isSuppressingSlidingDownLadder(): boolean;
        getBlockZ(): number;
        handler$egi000$collective$LivingEntity_die(damageSource: DamageSource_, ci: Internal.CallbackInfo_): void;
        dampensVibrations(): boolean;
        hasAttached(type: Internal.AttachmentType_<any>): boolean;
        isSilent(): boolean;
        setUseItem(arg0: Internal.ItemStack_): void;
        "playSound(net.minecraft.sounds.SoundEvent)"(id: Internal.SoundEvent_): void;
        getPitch(): number;
        getPathfindingMalus($$0: Internal.BlockPathTypes_): number;
        modify$nbm000$things$waxGlandLava(speed: number): number;
        getRandom(): Internal.RandomSource;
        canReplaceEqualItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        rotate($$0: Internal.Rotation_): number;
        handler$hcn000$hexcasting$onThunderHit(entityType: Internal.EntityType_<any>, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        getPassengersAndSelf(): Internal.Stream<any>;
        handler$leb000$puzzleslib$causeFallDamage$0(distance: number, damageMultiplier: number, damageSource: DamageSource_, callback: Internal.CallbackInfoReturnable_<any>): void;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        "getAttributeBaseValue(net.minecraft.core.Holder)"($$0: Internal.Holder_<Internal.Attribute>): number;
        getMaxTemper(): number;
        method_5652($$0: Internal.CompoundTag_): void;
        clearRestriction(): void;
        redirect$jgg000$moonlight$fixSpawnAnimX(instance: Internal.Mob_, v: number): number;
        getOriginalFoodStack(): Internal.ItemStack;
        "getBreedOffspring(net.minecraft.server.level.ServerLevel,net.minecraft.world.entity.AgeableMob)"($$0: Internal.ServerLevel_, $$1: Internal.AgeableMob_): this;
        getAge(): number;
        rayTrace(): Internal.RayTraceResultJS;
        alwaysAccepts(): boolean;
        "isHolding(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.ItemStack>): boolean;
        "setVariant(net.minecraft.world.entity.animal.horse.Llama$Variant)"($$0: Internal.Llama$Variant_): void;
        getNoActionTime(): number;
        isVisuallyCrawling(): boolean;
        isAggressive(): boolean;
        isWearingArmor(): boolean;
        setYya($$0: number): void;
        setDropChance($$0: Internal.EquipmentSlot_, $$1: number): void;
        handler$ieb000$lambdynlights$onRemove(ci: Internal.CallbackInfo_): void;
        "broadcastBreakEvent(net.minecraft.world.InteractionHand)"($$0: Internal.InteractionHand_): void;
        port_lib$setRemovalReason(arg0: Internal.Entity$RemovalReason_): void;
        teleportRelative($$0: number, $$1: number, $$2: number): void;
        isFood($$0: Internal.ItemStack_): boolean;
        setBaby($$0: boolean): void;
        getTemper(): number;
        getLastHurtByMob(): Internal.LivingEntity;
        pehkui_setScaleCache(scaleCache: Internal.ScaleData_[]): void;
        isInWaterOrBubble(): boolean;
        botania_setLoveCause(arg0: Internal.UUID_): void;
        tameWithName($$0: Internal.Player_): boolean;
        getPortalCooldown(): number;
        getItem(): Internal.ItemStack;
        causeFallDamage($$0: number, $$1: number, $$2: DamageSource_): boolean;
        getDynamicLightChunksToRebuild(forced: boolean): Internal.LongSet;
        getFlag($$0: number): boolean;
        releaseUsingItem(): void;
        bw_getNextAirOnLand(arg0: number): number;
        getPosition($$0: number): Vec3d;
        removeFreeWill(): void;
        handler$leb000$puzzleslib$removeAllEffects(callback: Internal.CallbackInfoReturnable_<any>): void;
        getStrength(): number;
        removeWhenFarAway($$0: number): boolean;
        wait(arg0: number): void;
        isIgnoringBlockTriggers(): boolean;
        setRecordPlayingNearby($$0: BlockPos_, $$1: boolean): void;
        etf$getItemsEquipped(): Internal.Iterable<any>;
        getHandHoldingItemAngle($$0: Internal.Item_): Vec3d;
        hasItemInSlot($$0: Internal.EquipmentSlot_): boolean;
        distanceToSqr($$0: Vec3d_): number;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        modifyAttached<A>(type: Internal.AttachmentType_<A>, modifier: Internal.UnaryOperator_<A>): A;
        isSteppingCarefully(): boolean;
        handler$zno000$apoli$doSpiderClimbing(info: Internal.CallbackInfoReturnable_<any>): void;
        "spawnAtLocation(net.minecraft.world.item.ItemStack,float)"($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        getBlockX(): number;
        /**
         * @deprecated
        */
        getLightLevelDependentMagicValue(): number;
        isFallFlying(): boolean;
        getEncodeId(): string;
        puzzleslib$getSpawnType(): Internal.MobSpawnType;
        makeMad(): void;
        bettertrims$setAvoidedDamage(avoidDamage: boolean): void;
        getY($$0: number): number;
        emf$prevPitch(): number;
        getMaxHeadXRot(): number;
        getNbt(): Internal.CompoundTag;
        setInvisible($$0: boolean): void;
        etf$getArmorItems(): Internal.Iterable<any>;
        isSaddled(): boolean;
        isSubmergedInLoosely(tag: Internal.TagKey_<any>): boolean;
        getEffect($$0: Internal.MobEffect_): Internal.MobEffectInstance;
        setTotalMovementSpeedMultiplier(speed: number): void;
        getDynamicLightY(): number;
        setHealth($$0: number): void;
        attack($$0: DamageSource_, $$1: number): boolean;
        onInsideBubbleColumn($$0: boolean): void;
        handler$cfa000$betterend$be_hurt(source: DamageSource_, amount: number, info: Internal.CallbackInfoReturnable_<any>): void;
        getAmbientStandInterval(): number;
        getEyePosition(): Vec3d;
        getEyeHeight(): number;
        setDiscardFriction($$0: boolean): void;
        hasPassenger($$0: Internal.Predicate_<Internal.Entity>): boolean;
        bettertridents$getLastDamageSource(): DamageSource;
        getYaw(): number;
        swing($$0: Internal.InteractionHand_, $$1: boolean): void;
        getUsedItemHand(): Internal.InteractionHand;
        setDefaultMovementSpeed(speed: number): void;
        canAttackType($$0: Internal.EntityType_<any>): boolean;
        hex$setLastDamageStamp(arg0: number): void;
        canEntityBeSeen(entity: Internal.LivingEntity_): boolean;
        modifyExpressionValue$zhf000$additionalentityattributes$additionalEntityAttributes$knockDownwards(original: number): number;
        getBrain(): Internal.Brain<any>;
        modify$bpk000$bclib$be_travel(moveDelta: Vec3d_): Vec3d;
        setCustomNameVisible($$0: boolean): void;
        isAlliedTo($$0: Internal.Team_): boolean;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>): A;
        getControllingPassenger(): Internal.LivingEntity;
        canFireProjectileWeapon($$0: Internal.ProjectileWeaponItem_): boolean;
        bw_getNextAirUnderwater(arg0: number): number;
        getScriptType(): Internal.ScriptType;
        handler$leb000$puzzleslib$releaseUsingItem(callback: Internal.CallbackInfo_): void;
        equipSaddle($$0: Internal.SoundSource_): void;
        handler$cbm000$besmirchment$handleStatus(status: number, ci: Internal.CallbackInfo_): void;
        port_lib$getDeathSound(): Internal.SoundEvent;
        shouldDiscardFriction(): boolean;
        startRiding($$0: Internal.Entity_): boolean;
        saveWithoutId($$0: Internal.CompoundTag_): Internal.CompoundTag;
        getForward(): Vec3d;
        setFeetArmorItem(item: Internal.ItemStack_): void;
        getId(): number;
        pehkui_isFirstUpdate(): boolean;
        canBeHitByProjectile(): boolean;
        getRecipientsForComponentSync(): Internal.Iterable<any>;
        handler$zcl000$porting_lib_base$port_lib$onUsingTick(ci: Internal.CallbackInfo_): void;
        getEyeY(): number;
        handler$ham000$gobber2$gobberClimbing(cir: Internal.CallbackInfoReturnable_<any>): void;
        skipDropExperience(): void;
        fabric_readAttachmentsFromNbt(nbt: Internal.CompoundTag_): void;
        localvar$leb000$puzzleslib$getVisibilityPercent(value: number, lookingEntity: Internal.Entity_): number;
        getBoundingBox(): Internal.AABB;
        isInWaterOrRain(): boolean;
        getStandAnim($$0: number): number;
        handler$leb000$puzzleslib$die$1(damageSource: DamageSource_, callback: Internal.CallbackInfo_): void;
        static createBaseChestedHorseAttributes(): Internal.AttributeSupplier$Builder;
        setItemSlot($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_): void;
        equals($$0: any): boolean;
        getViewYRot($$0: number): number;
        fabric_setCustomTeleportTarget(teleportTarget: Internal.PortalInfo_): void;
        dismountsUnderwater(): boolean;
        isAffectedByPotions(): boolean;
        playerTouch($$0: Internal.Player_): void;
        addTag($$0: string): boolean;
        getEyeHeight($$0: Internal.Pose_): number;
        getAddEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>;
        callIsBeingRainedOn(): boolean;
        static getEquipmentForSlot($$0: Internal.EquipmentSlot_, $$1: number): Internal.Item;
        isWithinRestriction($$0: BlockPos_): boolean;
        getTeam(): Internal.Team;
        handler$mjp000$supplementaries$addSugarCube(ci: Internal.CallbackInfo_): void;
        static of(entity: Internal.LivingEntity_): Internal.EntityProperties;
        setTicksFrozen($$0: number): void;
        isArmor($$0: Internal.ItemStack_): boolean;
        getUseItem(): Internal.ItemStack;
        getMyRidingOffset(): number;
        handler$hal000$gobber2$gobberCanBreatheInWater(cir: Internal.CallbackInfoReturnable_<any>): void;
        dismountTo($$0: number, $$1: number, $$2: number): void;
        etf$getEntityKey(): string;
        etf$getPose(): Internal.Pose;
        hasCustomName(): boolean;
        getSwimAmount($$0: number): number;
        isLiving(): boolean;
        getX(): number;
        isVehicle(): boolean;
        static transfer(original: Internal.AttachmentTarget_, target: Internal.AttachmentTarget_, isDeath: boolean): void;
        bettertrims$didAvoidDamage(): boolean;
        resetDynamicLight(): void;
        setTemper($$0: number): void;
        handler$han000$gobber2$gobberSetTarget(target: Internal.LivingEntity_, ci: Internal.CallbackInfo_): void;
        setVariant($$0: Internal.Llama$Variant_): void;
        handler$kpc001$porting_lib_entity$onJump(ci: Internal.CallbackInfo_): void;
        spawnAtLocation($$0: Internal.ItemStack_): Internal.ItemEntity;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        handler$zcl000$porting_lib_base$port_lib$canBeAffected(effect: Internal.MobEffectInstance_, cir: Internal.CallbackInfoReturnable_<any>): void;
        thunderHit($$0: Internal.ServerLevel_, $$1: Internal.LightningBolt_): void;
        setIsInPowderSnow($$0: boolean): void;
        etf$distanceTo(entity: Internal.Entity_): number;
        doEnchantDamageEffects($$0: Internal.LivingEntity_, $$1: Internal.Entity_): void;
        setCustomName($$0: net.minecraft.network.chat.Component_): void;
        lambdynlights$scheduleTrackedChunksRebuild(renderer: Internal.LevelRenderer_): void;
        handler$hak000$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        getTeamId(): string;
        setStingerCount($$0: number): void;
        getMaxHeadYRot(): number;
        isCustomNameVisible(): boolean;
        isSupportedBy($$0: BlockPos_): boolean;
        getPistonPushReaction(): Internal.PushReaction;
        lookAt($$0: Internal.EntityAnchorArgument$Anchor_, $$1: Vec3d_): void;
        handler$kpc000$porting_lib_entity$port_lib$cancelFall(fallDistance: number, multiplier: number, source: DamageSource_, cir: Internal.CallbackInfoReturnable_<any>): void;
        hurtCurrentlyUsedShield($$0: number): void;
        getLootTableSeed(): number;
        collide($$0: Vec3d_): Vec3d;
        getMotionX(): number;
        "onSyncedDataUpdated(java.util.List)"($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        canBeLeashed($$0: Internal.Player_): boolean;
        hasIndirectPassenger($$0: Internal.Entity_): boolean;
        gear_core_setActiveSets(sets: Internal.HashMap_<any, any>): void;
        getEntityData(): Internal.SynchedEntityData;
        bookshelf$getFallDamageSound(arg0: number): Internal.SoundEvent;
        handleInsidePortal($$0: BlockPos_): void;
        getPotionEffects(): Internal.EntityPotionEffectsJS;
        getLastHurtByPlayerTime(): number;
        absMoveTo($$0: number, $$1: number, $$2: number): void;
        handler$cfa000$betterend$be_canBeAffected(mobEffectInstance: Internal.MobEffectInstance_, info: Internal.CallbackInfoReturnable_<any>): void;
        isOnRails(): boolean;
        getAttachedOrThrow<A>(type: Internal.AttachmentType_<A>): A;
        handler$efj000$collective$AbstractHorse_travel(player: Internal.Player_, vec3: Vec3d_, ci: Internal.CallbackInfo_): void;
        getStingerCount(): number;
        markFusionRecomputeModels(): void;
        getFallSounds(): Internal.LivingEntity$Fallsounds;
        getAttributeTotalValue(attribute: Internal.Attribute_): number;
        getDimensionChangingDelay(): number;
        handler$cbi000$besmirchment$getScoreboardTeam(cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDynamicLuminance(): number;
        setYaw($$0: number): void;
        getPickRadius(): number;
        isPathFinding(): boolean;
        supp$getSlimedTicks(): number;
        isRemoved(): boolean;
        handleStopJump(): void;
        getEatAnim($$0: number): number;
        emf$isSneaking(): boolean;
        teleportToWithTicket($$0: number, $$1: number, $$2: number): void;
        spawnAnim(): void;
        getJumpBoostPower(): number;
        fillCrashReportCategory($$0: Internal.CrashReportCategory_): void;
        self(): Internal.Entity;
        refreshDimensions(): void;
        pehkui_writeScaleNbt(nbt: Internal.CompoundTag_): Internal.CompoundTag;
        bookshelf$getAmbientSound(): Internal.SoundEvent;
        "isHolding(net.minecraft.world.item.Item)"($$0: Internal.Item_): boolean;
        "getAttributeValue(net.minecraft.world.entity.ai.attributes.Attribute)"($$0: Internal.Attribute_): number;
        "spawnAtLocation(net.minecraft.world.level.ItemLike)"($$0: Internal.ItemLike_): Internal.ItemEntity;
        setShiftKeyDown($$0: boolean): void;
        getEyePosition($$0: number): Vec3d;
        getPassengers(): Internal.EntityArrayList;
        standIfPossible(): void;
        handler$ldh000$puzzleslib$spawnAtLocation(stack: Internal.ItemStack_, offsetY: number, callback: Internal.CallbackInfoReturnable_<any>, itemEntity: Internal.ItemEntity_): void;
        getZ(): number;
        bettertrims$applyCelestialToAttackCooldown(original: number): number;
        teleportTo($$0: number, $$1: number, $$2: number): void;
        handler$zbk000$porting_lib_base$port_lib$spawnSprintParticle(ci: Internal.CallbackInfo_, pos: BlockPos_, state: Internal.BlockState_): void;
        getAttributeBaseValue($$0: Internal.Holder_<Internal.Attribute>): number;
        getServer(): Internal.MinecraftServer;
        getExperienceReward(): number;
        getFirstPassenger(): Internal.Entity;
        heal($$0: number): void;
        handler$leb01a$puzzleslib$tick(callback: Internal.CallbackInfo_): void;
        setLastHurtMob($$0: Internal.Entity_): void;
        setLastHurtByMob($$0: Internal.LivingEntity_): void;
        interact($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        getDismountLocationForPassenger($$0: Internal.LivingEntity_): Vec3d;
        checkSlowFallDistance(): void;
        getLeashingEntities(): Internal.Set<any>;
        level(): Internal.EntityGetter;
        canStandOnFluid($$0: Internal.FluidState_): boolean;
        setFabricBalmData(tag: Internal.CompoundTag_): void;
        touchingUnloadedChunk(): boolean;
        modifyAttribute(attribute: Internal.Attribute_, identifier: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getLookAngle(): Vec3d;
        joinCaravan($$0: Internal.Llama_): void;
        modifyReturnValue$zhf000$additionalentityattributes$additionalEntityAttributes$modifyJumpVelocity(original: number): number;
        getAmbientSoundInterval(): number;
        emf$isOnFire(): boolean;
        setArrowCount($$0: number): void;
        getMotionZ(): number;
        isPersistenceRequired(): boolean;
        isInvisible(): boolean;
        is($$0: Internal.Entity_): boolean;
        isTamed(): boolean;
        getBedOrientation(): Internal.Direction;
        ejectPassengers(): void;
        removeEffect($$0: Internal.MobEffect_): boolean;
        updateDynamicLightPreviousCoordinates(): void;
        getProfile(): Internal.GameProfile;
        setInLove($$0: Internal.Player_): void;
        isDeadOrDying(): boolean;
        setHeadArmorItem(item: Internal.ItemStack_): void;
        static setViewScale($$0: number): void;
        emf$isAlive(): boolean;
        take($$0: Internal.Entity_, $$1: number): void;
        setLevelCallback($$0: Internal.EntityInLevelCallback_): void;
        getLookControl(): Internal.LookControl;
        handler$gdo000$faster_entity_animations$getEatingGrassAnimationProgress(f: number, info: Internal.CallbackInfoReturnable_<any>): void;
        isBred(): boolean;
        redirect$joh000$origins$method_26317Proxy(entity: Internal.LivingEntity_, d: number, bl: boolean, vec3d: Vec3d_): Vec3d;
        playSound($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        canAttack($$0: Internal.LivingEntity_): boolean;
        static getSpeedUpSecondsWhenFeeding($$0: number): number;
        getOffHandItem(): Internal.ItemStack;
        startSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isOnScoreboardTeam(teamId: string): boolean;
        startUsingItem($$0: Internal.InteractionHand_): void;
        invokePlayEquipmentBreakEffects(arg0: Internal.ItemStack_): void;
        localvar$bbb000$architectury$modifyLevelCallback_setLevelCallback(callback: Internal.EntityInLevelCallback_): Internal.EntityInLevelCallback;
        position(): Vec3d;
        setTimeout(): void;
        static getEquipmentSlotForItem($$0: Internal.ItemStack_): Internal.EquipmentSlot;
        getEquipment(slot: Internal.EquipmentSlot_): Internal.ItemStack;
        displayFireAnimation(): boolean;
        isOutOfCamera(): boolean;
        getRopeHoldPosition($$0: number): Vec3d;
        copyPosition($$0: Internal.Entity_): void;
        "hasPassenger(net.minecraft.world.entity.Entity)"($$0: Internal.Entity_): boolean;
        extraalchemy_spawnParticles(arg0: Internal.ItemStack_, arg1: number): void;
        etf$canBeBright(): boolean;
        isCrouching(): boolean;
        "getAttributeBaseValue(net.minecraft.world.entity.ai.attributes.Attribute)"($$0: Internal.Attribute_): number;
        onLeaveCombat(): void;
        wrapOperation$bgd000$artifacts$travel(block: Internal.Block_, original: Internal.Operation_<any>): number;
        setY(y: number): void;
        getAttributeValue($$0: Internal.Attribute_): number;
        getFeetBlockState(): Internal.BlockState;
        archon$isOwner(player: Internal.Player_): boolean;
        isWithinRestriction(): boolean;
        getChangeListener(): Internal.EntityInLevelCallback;
        positionRider($$0: Internal.Entity_): void;
        baseTick(): void;
        broadcastToPlayer($$0: Internal.ServerPlayer_): boolean;
        setSharedFlag($$0: number, $$1: boolean): void;
        getSleepingPos(): Optional<BlockPos>;
        damageHeldItem(): void;
        getCustomName(): net.minecraft.network.chat.Component;
        getClass(): typeof any;
        isVisuallySwimming(): boolean;
        getMaxAirSupply(): number;
        handler$zcl000$porting_lib_base$port_lib$addEffect(newEffect: Internal.MobEffectInstance_, source: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>, oldEffect: Internal.MobEffectInstance_): void;
        setItemInHand($$0: Internal.InteractionHand_, $$1: Internal.ItemStack_): void;
        dynamicLightTick(): void;
        setMaxHealth(hp: number): void;
        getFacing(): Internal.Direction;
        emf$isWet(): boolean;
        getJumpCooldown(): number;
        isPassengerOfSameVehicle($$0: Internal.Entity_): boolean;
        getBoundingBoxForCulling(): Internal.AABB;
        setAge($$0: number): void;
        getTarget(): Internal.LivingEntity;
        static collideBoundingBox(entity: Internal.Entity_, movement: Vec3d_, entityBoundingBox: Internal.AABB_, world: Internal.Level_, collisions: Internal.List_<any>): Vec3d;
        fzzy_core_getModifierContainer(): Internal.ModifierContainer;
        restrictTo($$0: BlockPos_, $$1: number): void;
        isInLove(): boolean;
        trackingPosition(): Vec3d;
        getNameTagOffsetY(): number;
        isInvulnerable(): boolean;
        isInLava(): boolean;
        isInWater(): boolean;
        awardKillScore($$0: Internal.Entity_, $$1: number, $$2: DamageSource_): void;
        finalizeSpawn($$0: Internal.ServerLevelAccessor_, $$1: Internal.DifficultyInstance_, $$2: Internal.MobSpawnType_, $$3: Internal.SpawnGroupData_, $$4: Internal.CompoundTag_): Internal.SpawnGroupData;
        localvar$leb000$puzzleslib$knockback$3(ratioZ: number): number;
        handleStartJump($$0: number): void;
        unsetRemoved(): void;
        pehkui_getScaleCache(): Internal.ScaleData[];
        swing($$0: Internal.InteractionHand_): void;
        hasEffect($$0: Internal.MobEffect_): boolean;
        getHeldItem(hand: Internal.InteractionHand_): Internal.ItemStack;
        setFusionModel(layerIndex: number, model: Internal.Triple_<any, any, any>): void;
        getRootVehicle(): Internal.Entity;
        getOwnerUUID(): Internal.UUID;
        onPathfindingDone(): void;
        save($$0: Internal.CompoundTag_): boolean;
        archon$setLifetime(seconds: number): void;
        modify$zhf000$additionalentityattributes$additionalEntityAttributes$waterSpeed(original: number): number;
        getLocalBoundsForPose($$0: Internal.Pose_): Internal.AABB;
        isNoGravity(): boolean;
        dodge(chance: number): boolean;
        onItemPickup($$0: Internal.ItemEntity_): void;
        getMouthAnim($$0: number): number;
        hex$setLastDamageSource(arg0: DamageSource_): void;
        emf$getY(): number;
        handler$kom000$porting_lib_entity$port_lib$entityInit(entityType: Internal.EntityType_<any>, world: Internal.Level_, ci: Internal.CallbackInfo_): void;
        resetLove(): void;
        bookshelf$createHoverEvent(): Internal.HoverEvent;
        updateSwimming(): void;
        isHolding($$0: Internal.Predicate_<Internal.ItemStack>): boolean;
        getSpeed(): number;
        abstract getCachedFeetBlockState(): Internal.BlockState;
        shouldInformAdmins(): boolean;
        rideTick(): void;
        port_lib$onEffectRemoved(arg0: Internal.MobEffectInstance_): void;
        handler$zll000$amethyst_imbuement$onAttackWhilstStunnedNoTarget(hand: Internal.InteractionHand_, ci: Internal.CallbackInfo_): void;
        wait(): void;
        getUuid(): Internal.UUID;
        setOffHandItem(item: Internal.ItemStack_): void;
        inCaravan(): boolean;
        spawn(): void;
        setNoAi($$0: boolean): void;
        teleportTo($$0: Internal.ServerLevel_, $$1: number, $$2: number, $$3: number, $$4: Internal.Set_<Internal.RelativeMovement>, $$5: number, $$6: number): boolean;
        etf$getCustomName(): net.minecraft.network.chat.Component;
        fabric_writeAttachmentsToNbt(nbt: Internal.CompoundTag_): void;
        shouldShowName(): boolean;
        getArmorSlots(): Internal.Iterable<Internal.ItemStack>;
        canPickUpLoot(): boolean;
        kill(): void;
        onEnterCombat(): void;
        hasChest(): boolean;
        updateNavigationRegistration(): void;
        animateHurt($$0: number): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        handler$kom000$porting_lib_entity$port_lib$onEntityRemove(reason: Internal.Entity$RemovalReason_, ci: Internal.CallbackInfo_): void;
        static resetForwardDirectionOfRelativePortalPosition($$0: Vec3d_): Vec3d;
        callGetEyeHeight(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        hasRestriction(): boolean;
        getHeadArmorItem(): Internal.ItemStack;
        botania_createInventory(): void;
        deserializeNBT(arg0: Internal.Tag_): void;
        setEating($$0: boolean): void;
        getCurrentModifyFoodPowers(): Internal.List<any>;
        getBbWidth(): number;
        splitIntoDynamicLightEntries(): Internal.Stream<Internal.SpatialLookupEntry>;
        addDeltaMovement($$0: Vec3d_): void;
        pehkui_setOnGround(onGround: boolean): void;
        localvar$leb000$puzzleslib$knockback$1(strength: number): number;
        setTamed($$0: boolean): void;
        bettertrims$addLateAttributes(adder: Internal.Consumer_<any>): void;
        handler$lef000$puzzleslib$readAdditionalSaveData(compound: Internal.CompoundTag_, callback: Internal.CallbackInfo_): void;
        sendLeashState(): void;
        "getName()"(): net.minecraft.network.chat.Component;
        mirror($$0: Internal.Mirror_): number;
        static port_lib$collideWithShapes(vec3: Vec3d_, aABB: Internal.AABB_, list: Internal.List_<Internal.VoxelShape>): Vec3d;
        knockback($$0: number, $$1: number, $$2: number): void;
        getTicksRequiredToFreeze(): number;
        getVisibilityPercent($$0: Internal.Entity_): number;
        getMaxSpawnClusterSize(): number;
        localvar$kpc000$porting_lib_entity$port_lib$modifyDistance(fallDistance: number): number;
        artifacts$getPocketPistonLength(): number;
        canJump(): boolean;
        emf$prevZ(): number;
        getUsername(): string;
        getInLoveTime(): number;
        move($$0: Internal.MoverType_, $$1: Vec3d_): void;
        "setVariant(java.lang.Object)"(arg0: any): void;
        lithiumOnBlockCacheSet(newState: Internal.BlockState_): void;
        isPickable(): boolean;
        setYHeadRot($$0: number): void;
        setJumping($$0: boolean): void;
        getCustomData(): Internal.CompoundTag;
        handler$zno000$apoli$getGroup(info: Internal.CallbackInfoReturnable_<any>): void;
        getPickResult(): Internal.ItemStack;
        "getMainHandItem()"(): Internal.ItemStack;
        getAbsorptionAmount(): number;
        getRandomY(): number;
        onEffectRemoved($$0: Internal.MobEffectInstance_): void;
        getDisplayName(): net.minecraft.network.chat.Component;
        static "tickEntity(net.minecraft.world.entity.Entity)"(entity: Internal.Entity_): void;
        getMobType(): Internal.MobType;
        travel($$0: Vec3d_): void;
        getItemInHand($$0: Internal.InteractionHand_): Internal.ItemStack;
        localvar$leb000$puzzleslib$hurt$0(amount: number, source: DamageSource_): number;
        getDynamicLightPrevX(): number;
        shouldBeSaved(): boolean;
        fabric_hasPersistentAttachments(): boolean;
        method_5749($$0: Internal.CompoundTag_): void;
        hurtHelmet($$0: DamageSource_, $$1: number): void;
        getCaravanHead(): this;
        removeTag($$0: string): boolean;
        isHoldingInAnyHand(i: Internal.Ingredient_): boolean;
        getFluidHeight($$0: Internal.TagKey_<Internal.Fluid>): number;
        canSpawnSoulSpeedParticle(): boolean;
        notifyAll(): void;
        hasInventoryChanged($$0: net.minecraft.world.Container_): boolean;
        aiStep(): void;
        getPassengersRidingOffset(): number;
        handler$leb000$puzzleslib$removeEffect(effect: Internal.MobEffect_, callback: Internal.CallbackInfoReturnable_<any>): void;
        setAttributeBaseValue(attribute: Internal.Attribute_, value: number): void;
        distanceToEntitySqr($$0: Internal.Entity_): number;
        isFrame(): boolean;
        broadcastBreakEvent($$0: Internal.InteractionHand_): void;
        setLegsArmorItem(item: Internal.ItemStack_): void;
        localvar$leb000$puzzleslib$causeFallDamage$1(fallDistance: number): number;
        discard(): void;
        "handler$mhe000$step-height-entity-attribute$getStepHeight"(cir: Internal.CallbackInfoReturnable_<any>): void;
        sendSystemMessage($$0: net.minecraft.network.chat.Component_): void;
        acceptsSuccess(): boolean;
        static tickEntity(entity: Internal.LivingEntity_): void;
        setNoGravity($$0: boolean): void;
        getUseItemRemainingTicks(): number;
        gear_core_getActiveSets(): Internal.HashMap<any, any>;
        getIndirectPassengers(): Internal.Iterable<any>;
        attackable(): boolean;
        createCommandSourceStack(): Internal.CommandSourceStack;
        getNavigation(): Internal.PathNavigation;
        isControlledByLocalInstance(): boolean;
        isMonster(): boolean;
        pehkui_setShouldSyncScales(sync: boolean): void;
        handler$cbm000$besmirchment$canTarget(type: Internal.EntityType_<any>, cir: Internal.CallbackInfoReturnable_<any>): void;
        getLoveCause(): Internal.ServerPlayer;
        getLastClimbablePos(): Optional<BlockPos>;
        getEatingSound($$0: Internal.ItemStack_): Internal.SoundEvent;
        setLastDynamicLuminance(luminance: number): void;
        getPerceivedTargetDistanceSquareForMeleeAttack($$0: Internal.LivingEntity_): number;
        setId($$0: number): void;
        onSyncedDataUpdated($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        getHorizontalFacing(): Internal.Direction;
        getType(): string;
        static checkAnimalSpawnRules($$0: Internal.EntityType_<Internal.Animal>, $$1: Internal.LevelAccessor_, $$2: Internal.MobSpawnType_, $$3: BlockPos_, $$4: Internal.RandomSource_): boolean;
        isDamageSourceBlocked($$0: DamageSource_): boolean;
        getLightProbePosition($$0: number): Vec3d;
        getActiveEffectsMap(): Internal.Map<Internal.MobEffect, Internal.MobEffectInstance>;
        wrapOperation$mac000$smarterfarmers$smarterFarmers$overrideMobGriefing(instance: Internal.GameRules_, key: Internal.GameRules$Key_<any>, original: Internal.Operation_<any>): boolean;
        emf$prevX(): number;
        onEquipItem($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_, $$2: Internal.ItemStack_): void;
        checkDespawn(): void;
        pehkui_shouldSyncScales(): boolean;
        getWalkTargetValue($$0: BlockPos_, $$1: Internal.LevelReader_): number;
        lookAt($$0: Internal.Entity_, $$1: number, $$2: number): void;
        setHeldItem(hand: Internal.InteractionHand_, item: Internal.ItemStack_): void;
        port_lib$maybeDisableShield(arg0: Internal.Player_, arg1: Internal.ItemStack_, arg2: Internal.ItemStack_): void;
        equipItemIfPossible($$0: Internal.ItemStack_): Internal.ItemStack;
        onSyncedDataUpdated($$0: Internal.EntityDataAccessor_<any>): void;
        lerpHeadTo($$0: number, $$1: number): void;
        canDisableShield(): boolean;
        setMotionX(x: number): void;
        getHandSlots(): Internal.Iterable<Internal.ItemStack>;
        distanceToEntity($$0: Internal.Entity_): number;
        bookshelf$getDeathSound(): Internal.SoundEvent;
        wait(arg0: number, arg1: number): void;
        getTeamColor(): number;
        lithiumSetClimbingMobCachingSectionUpdateBehavior(listenForCachedBlockChanges: boolean): void;
        setNbt(nbt: Internal.CompoundTag_): void;
        lambdynlights$getTrackedLitChunkPos(): Internal.LongSet;
        checkSpawnObstruction($$0: Internal.LevelReader_): boolean;
        getRecallPosition(): Internal.DimensionalPosition;
        extinguish(): void;
        setDynamicLightEnabled(enabled: boolean): void;
        equipArmor($$0: Internal.Player_, $$1: Internal.ItemStack_): void;
        getRestrictRadius(): number;
        moveTo($$0: Vec3d_): void;
        isColliding($$0: BlockPos_, $$1: Internal.BlockState_): boolean;
        "swing(net.minecraft.world.InteractionHand)"($$0: Internal.InteractionHand_): void;
        lambdynlights$updateDynamicLight(renderer: Internal.LevelRenderer_): boolean;
        getRegisteredNavigation(): Internal.PathNavigation;
        bettertrims$isWearing(effect: Internal.TrimEffect_): boolean;
        static port_lib$collideWithShapes$porting_lib_accessors_$md$424943$0(arg0: Vec3d_, arg1: Internal.AABB_, arg2: Internal.List_<any>): Vec3d;
        isForcedVisible(): boolean;
        modifyTemper($$0: number): number;
        isInvertedHealAndHarm(): boolean;
        handler$jon000$origins$doWaterBreathing(info: Internal.CallbackInfoReturnable_<any>): void;
        canHoldItem($$0: Internal.ItemStack_): boolean;
        killedEntity($$0: Internal.ServerLevel_, $$1: Internal.LivingEntity_): boolean;
        getAttachedOrElse<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        isFreezing(): boolean;
        containerChanged($$0: net.minecraft.world.Container_): void;
        runCommand(command: string): number;
        isStanding(): boolean;
        hex$getDeathSound(): Internal.SoundEvent;
        setGuaranteedDrop($$0: Internal.EquipmentSlot_): void;
        setSharedFlagOnFire($$0: boolean): void;
        set defaultMovementSpeedMultiplier(speed: number)
        get suppressingBounce(): boolean
        set target($$0: Internal.LivingEntity_)
        set culled(value: boolean)
        get onFire(): boolean
        get owner(): Internal.LivingEntity
        get positionCodec(): Internal.VecDeltaCodec
        set maxUpStep($$0: number)
        get fallFlyingTicks(): number
        set xxa($$0: number)
        set delayedLeashHolderId($$0: number)
        get shiftKeyDown(): boolean
        set UUID($$0: Internal.UUID_)
        set motionZ(z: number)
        get blockY(): number
        get isInsideStructureTracker(): Internal.IsInsideStructureTracker
        set playerHitTimer(arg0: number)
        get spectator(): boolean
        set mainHandItem(item: Internal.ItemStack_)
        get persistentData(): Internal.CompoundTag
        get health(): number
        get maxHealth(): number
        get registeredToWorld(): boolean
        set aggressive($$0: boolean)
        set removed($$0: Internal.Entity$RemovalReason_)
        get inWaterRainOrBubble(): boolean
        get removalReason(): Internal.Entity$RemovalReason
        get eating(): boolean
        set boundingBox($$0: Internal.AABB_)
        get ambientCreature(): boolean
        set zza($$0: number)
        get block(): Internal.BlockContainerJS
        get name(): net.minecraft.network.chat.Component
        get controlledVehicle(): Internal.Entity
        get armorValue(): number
        get killCredit(): Internal.LivingEntity
        get componentContainer(): Internal.ComponentContainer
        get dynamicLightPrevZ(): number
        set outOfCamera(value: boolean)
        get autoSpinAttack(): boolean
        get remainingFireTicks(): number
        get maxFallDistance(): number
        get ticksFrozen(): number
        get dynamicLightZ(): number
        get voicePitch(): number
        set statusMessage(message: net.minecraft.network.chat.Component_)
        set sleepingPos($$0: BlockPos_)
        get descending(): boolean
        get headRotSpeed(): number
        get lastHurtByPlayer(): Internal.Player
        get YHeadRot(): number
        set absorptionAmount($$0: number)
        set recallData(pos: Internal.DimensionalPosition_)
        set deltaMovement($$0: Vec3d_)
        get baby(): boolean
        get culled(): boolean
        get glowing(): boolean
        get leashedByEntities(): Internal.Set<any>
        get leashOffset(): Vec3d
        get attackable(): boolean
        get saddleSoundEvent(): Internal.SoundEvent
        get underWater(): boolean
        get leashHolder(): Internal.Entity
        get sensing(): Internal.Sensing
        get legsArmorItem(): Internal.ItemStack
        get luminance(): number
        get selfAndPassengers(): Internal.Stream<any>
        get deltaMovement(): Vec3d
        get dynamicLightX(): number
        set secondsOnFire($$0: number)
        get "displayName()"(): net.minecraft.network.chat.Component
        get lootTable(): ResourceLocation
        get ticksUsingItem(): number
        get arrowCount(): number
        get moveControl(): Internal.MoveControl
        set standing($$0: boolean)
        get defaultMovementSpeed(): number
        get peacefulCreature(): boolean
        set onGround($$0: boolean)
        get lastHurtByMobTimestamp(): number
        get vehicle(): Internal.Entity
        get effectiveAi(): boolean
        get stringUuid(): string
        set swimming($$0: boolean)
        get mainArm(): Internal.HumanoidArm
        get rotationVector(): Internal.Vec2
        get hurtDir(): number
        get sprinting(): boolean
        get motionY(): number
        get offhandItem(): Internal.ItemStack
        set luminance(luminance: number)
        set lootTable(arg0: ResourceLocation_)
        get lastHurtMob(): Internal.LivingEntity
        get lastDamageSource(): DamageSource
        get soundSource(): Internal.SoundSource
        get jumping(): boolean
        set noActionTime($$0: number)
        set movementSpeedAddition(speed: number)
        get pose(): Internal.Pose
        get restrictCenter(): BlockPos
        get leftHanded(): boolean
        set z(z: number)
        get y(): number
        set isJumping($$0: boolean)
        set currentModifyFoodPowers(powers: Internal.List_<any>)
        get blocking(): boolean
        get pushedByFluid(): boolean
        set originalFoodStack(original: Internal.ItemStack_)
        get armorCoverPercentage(): number
        get airSupply(): number
        get player(): boolean
        get animal(): boolean
        get motionDirection(): Internal.Direction
        get fabricBalmData(): Internal.CompoundTag
        get commandSenderWorld(): Internal.Level
        get totalMovementSpeed(): number
        get moving(): boolean
        get attributes(): Internal.AttributeMap
        set inLoveTime($$0: number)
        get swimming(): boolean
        set sprinting($$0: boolean)
        get dynamicLightLevel(): Internal.Level
        set x(x: number)
        get portalWaitTime(): number
        get blockStateOn(): Internal.BlockState
        set ownerUUID($$0: Internal.UUID_)
        get fluidJumpThreshold(): number
        get cachedSouls(): number
        get "variant()"(): any
        set airSupply($$0: number)
        get onPos(): BlockPos
        get undead(): boolean
        set useItemRemaining(arg0: number)
        get targetSelector(): Internal.GoalSelector
        set registeredToWorld(navigation: Internal.PathNavigation_)
        get sleeping(): boolean
        get dismountPoses(): Internal.ImmutableList<Internal.Pose>
        get lastHurtMobTimestamp(): number
        set remainingFireTicks($$0: number)
        /**
         * @deprecated
        */
        get onPosLegacy(): BlockPos
        set pos($$0: Vec3d_)
        set canPickUpLoot($$0: boolean)
        get mainHandItem(): Internal.ItemStack
        set silent($$0: boolean)
        set leftHanded($$0: boolean)
        get activeEffects(): Internal.Collection<Internal.MobEffectInstance>
        get onPortalCooldown(): boolean
        set pitch($$0: number)
        get usingItem(): boolean
        get alwaysTicking(): boolean
        get inventoryColumns(): number
        get "variant()"(): Internal.Llama$Variant
        set invulnerable($$0: boolean)
        get dynamicLightPrevY(): number
        set glowing($$0: boolean)
        get alive(): boolean
        get traderLlama(): boolean
        get bbHeight(): number
        get tags(): Internal.Set<string>
        get lastAttacker(): Internal.LivingEntity
        get lastRollTicks(): number
        get goalSelector(): Internal.GoalSelector
        get percentFrozen(): number
        set portalCooldown($$0: number)
        set position(block: Internal.BlockContainerJS_)
        get leashed(): boolean
        get variant(): any
        set pose($$0: Internal.Pose_)
        get reachDistance(): number
        set chest($$0: boolean)
        get entityType(): Internal.EntityType<any>
        get waterCreature(): boolean
        set lastHurtByPlayer($$0: Internal.Player_)
        get "server()"(): Internal.MinecraftServer
        get ambientStandSound(): Internal.SoundEvent
        get pushable(): boolean
        set YBodyRot($$0: number)
        set motionY(y: number)
        get dynamicLightEnabled(): boolean
        set bred($$0: boolean)
        set chestArmorItem(item: Internal.ItemStack_)
        get passenger(): boolean
        get sensitiveToWater(): boolean
        get jumpControl(): Internal.JumpControl
        get feetArmorItem(): Internal.ItemStack
        get saddleable(): boolean
        get variant(): Internal.Llama$Variant
        get viewScale(): number
        get visualRotationYInDegrees(): number
        set speed($$0: number)
        get swag(): Internal.DyeColor
        get discrete(): boolean
        get level(): Internal.Level
        get combatTracker(): Internal.CombatTracker
        get customJump(): number
        get noAi(): boolean
        get chestArmorItem(): Internal.ItemStack
        set variant(arg0: any)
        get fullyFrozen(): boolean
        get inWall(): boolean
        get allSlots(): Internal.Iterable<Internal.ItemStack>
        get inventory(): Internal.SimpleContainer
        get scale(): number
        get suppressingSlidingDownLadder(): boolean
        get blockZ(): number
        get silent(): boolean
        set useItem(arg0: Internal.ItemStack_)
        get pitch(): number
        get random(): Internal.RandomSource
        get passengersAndSelf(): Internal.Stream<any>
        get maxTemper(): number
        get originalFoodStack(): Internal.ItemStack
        get age(): number
        set "variant(net.minecraft.world.entity.animal.horse.Llama$Variant)"($$0: Internal.Llama$Variant_)
        get noActionTime(): number
        get visuallyCrawling(): boolean
        get aggressive(): boolean
        get wearingArmor(): boolean
        set yya($$0: number)
        set baby($$0: boolean)
        get temper(): number
        get lastHurtByMob(): Internal.LivingEntity
        get inWaterOrBubble(): boolean
        get portalCooldown(): number
        get item(): Internal.ItemStack
        get strength(): number
        get ignoringBlockTriggers(): boolean
        get steppingCarefully(): boolean
        get blockX(): number
        /**
         * @deprecated
        */
        get lightLevelDependentMagicValue(): number
        get fallFlying(): boolean
        get encodeId(): string
        get maxHeadXRot(): number
        get nbt(): Internal.CompoundTag
        set invisible($$0: boolean)
        get saddled(): boolean
        set totalMovementSpeedMultiplier(speed: number)
        get dynamicLightY(): number
        set health($$0: number)
        get ambientStandInterval(): number
        get eyePosition(): Vec3d
        get eyeHeight(): number
        set discardFriction($$0: boolean)
        get yaw(): number
        get usedItemHand(): Internal.InteractionHand
        set defaultMovementSpeed(speed: number)
        get brain(): Internal.Brain<any>
        set customNameVisible($$0: boolean)
        get controllingPassenger(): Internal.LivingEntity
        get scriptType(): Internal.ScriptType
        get forward(): Vec3d
        set feetArmorItem(item: Internal.ItemStack_)
        get id(): number
        get recipientsForComponentSync(): Internal.Iterable<any>
        get eyeY(): number
        get boundingBox(): Internal.AABB
        get inWaterOrRain(): boolean
        get affectedByPotions(): boolean
        get addEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>
        get team(): Internal.Team
        set ticksFrozen($$0: number)
        get useItem(): Internal.ItemStack
        get myRidingOffset(): number
        get living(): boolean
        get x(): number
        get vehicle(): boolean
        set temper($$0: number)
        set variant($$0: Internal.Llama$Variant_)
        set isInPowderSnow($$0: boolean)
        set customName($$0: net.minecraft.network.chat.Component_)
        get teamId(): string
        set stingerCount($$0: number)
        get maxHeadYRot(): number
        get customNameVisible(): boolean
        get pistonPushReaction(): Internal.PushReaction
        get lootTableSeed(): number
        get motionX(): number
        get entityData(): Internal.SynchedEntityData
        get potionEffects(): Internal.EntityPotionEffectsJS
        get lastHurtByPlayerTime(): number
        get onRails(): boolean
        get stingerCount(): number
        get fallSounds(): Internal.LivingEntity$Fallsounds
        get dimensionChangingDelay(): number
        get lastDynamicLuminance(): number
        set yaw($$0: number)
        get pickRadius(): number
        get pathFinding(): boolean
        get removed(): boolean
        get jumpBoostPower(): number
        set shiftKeyDown($$0: boolean)
        get passengers(): Internal.EntityArrayList
        get z(): number
        get server(): Internal.MinecraftServer
        get experienceReward(): number
        get firstPassenger(): Internal.Entity
        set lastHurtMob($$0: Internal.Entity_)
        set lastHurtByMob($$0: Internal.LivingEntity_)
        get leashingEntities(): Internal.Set<any>
        set fabricBalmData(tag: Internal.CompoundTag_)
        get lookAngle(): Vec3d
        get ambientSoundInterval(): number
        set arrowCount($$0: number)
        get motionZ(): number
        get persistenceRequired(): boolean
        get invisible(): boolean
        get tamed(): boolean
        get bedOrientation(): Internal.Direction
        get profile(): Internal.GameProfile
        set inLove($$0: Internal.Player_)
        get deadOrDying(): boolean
        set headArmorItem(item: Internal.ItemStack_)
        set viewScale($$0: number)
        set levelCallback($$0: Internal.EntityInLevelCallback_)
        get lookControl(): Internal.LookControl
        get bred(): boolean
        get offHandItem(): Internal.ItemStack
        get outOfCamera(): boolean
        get crouching(): boolean
        set y(y: number)
        get feetBlockState(): Internal.BlockState
        get withinRestriction(): boolean
        get changeListener(): Internal.EntityInLevelCallback
        get sleepingPos(): Optional<BlockPos>
        get customName(): net.minecraft.network.chat.Component
        get class(): typeof any
        get visuallySwimming(): boolean
        get maxAirSupply(): number
        set maxHealth(hp: number)
        get facing(): Internal.Direction
        get jumpCooldown(): number
        get boundingBoxForCulling(): Internal.AABB
        set age($$0: number)
        get target(): Internal.LivingEntity
        get inLove(): boolean
        get nameTagOffsetY(): number
        get invulnerable(): boolean
        get inLava(): boolean
        get inWater(): boolean
        get rootVehicle(): Internal.Entity
        get ownerUUID(): Internal.UUID
        get noGravity(): boolean
        get speed(): number
        get cachedFeetBlockState(): Internal.BlockState
        get uuid(): Internal.UUID
        set offHandItem(item: Internal.ItemStack_)
        set noAi($$0: boolean)
        get armorSlots(): Internal.Iterable<Internal.ItemStack>
        get headArmorItem(): Internal.ItemStack
        set eating($$0: boolean)
        get currentModifyFoodPowers(): Internal.List<any>
        get bbWidth(): number
        set tamed($$0: boolean)
        get "name()"(): net.minecraft.network.chat.Component
        get ticksRequiredToFreeze(): number
        get maxSpawnClusterSize(): number
        get username(): string
        get inLoveTime(): number
        set "variant(java.lang.Object)"(arg0: any)
        get pickable(): boolean
        set YHeadRot($$0: number)
        set jumping($$0: boolean)
        get customData(): Internal.CompoundTag
        get pickResult(): Internal.ItemStack
        get "mainHandItem()"(): Internal.ItemStack
        get absorptionAmount(): number
        get randomY(): number
        get displayName(): net.minecraft.network.chat.Component
        get mobType(): Internal.MobType
        get dynamicLightPrevX(): number
        get caravanHead(): Internal.Llama
        get passengersRidingOffset(): number
        get frame(): boolean
        set legsArmorItem(item: Internal.ItemStack_)
        set noGravity($$0: boolean)
        get useItemRemainingTicks(): number
        get indirectPassengers(): Internal.Iterable<any>
        get navigation(): Internal.PathNavigation
        get controlledByLocalInstance(): boolean
        get monster(): boolean
        get loveCause(): Internal.ServerPlayer
        get lastClimbablePos(): Optional<BlockPos>
        set lastDynamicLuminance(luminance: number)
        set id($$0: number)
        get horizontalFacing(): Internal.Direction
        get type(): string
        get activeEffectsMap(): Internal.Map<Internal.MobEffect, Internal.MobEffectInstance>
        set motionX(x: number)
        get handSlots(): Internal.Iterable<Internal.ItemStack>
        get teamColor(): number
        set nbt(nbt: Internal.CompoundTag_)
        get recallPosition(): Internal.DimensionalPosition
        set dynamicLightEnabled(enabled: boolean)
        get restrictRadius(): number
        get registeredNavigation(): Internal.PathNavigation
        get forcedVisible(): boolean
        get invertedHealAndHarm(): boolean
        get freezing(): boolean
        get standing(): boolean
        set guaranteedDrop($$0: Internal.EquipmentSlot_)
        set sharedFlagOnFire($$0: boolean)
    }
    type Llama_ = Llama;
    class AtomicBoolean implements Internal.Serializable {
        constructor()
        constructor(arg0: boolean)
        weakCompareAndSetPlain(arg0: boolean, arg1: boolean): boolean;
        getClass(): typeof any;
        set(arg0: boolean): void;
        weakCompareAndSetAcquire(arg0: boolean, arg1: boolean): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        setRelease(arg0: boolean): void;
        compareAndExchange(arg0: boolean, arg1: boolean): boolean;
        lazySet(arg0: boolean): void;
        /**
         * @deprecated
        */
        weakCompareAndSet(arg0: boolean, arg1: boolean): boolean;
        compareAndSet(arg0: boolean, arg1: boolean): boolean;
        compareAndExchangeAcquire(arg0: boolean, arg1: boolean): boolean;
        compareAndExchangeRelease(arg0: boolean, arg1: boolean): boolean;
        getOpaque(): boolean;
        setPlain(arg0: boolean): void;
        toString(): string;
        notifyAll(): void;
        getAcquire(): boolean;
        weakCompareAndSetRelease(arg0: boolean, arg1: boolean): boolean;
        get(): boolean;
        getAndSet(arg0: boolean): boolean;
        weakCompareAndSetVolatile(arg0: boolean, arg1: boolean): boolean;
        getPlain(): boolean;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        setOpaque(arg0: boolean): void;
        get class(): typeof any
        set release(arg0: boolean)
        get opaque(): boolean
        set plain(arg0: boolean)
        get acquire(): boolean
        get plain(): boolean
        set opaque(arg0: boolean)
    }
    type AtomicBoolean_ = AtomicBoolean;
    interface TickingBlockEntity {
        abstract getPos(): BlockPos;
        abstract isRemoved(): boolean;
        abstract getType(): string;
        abstract tick(): void;
        get pos(): BlockPos
        get removed(): boolean
        get type(): string
    }
    type TickingBlockEntity_ = TickingBlockEntity;
    interface SurfaceRules$ConditionSource extends Internal.Function<Internal.SurfaceRules$Context, Internal.SurfaceRules$Condition> {
        andThen<V>(arg0: Internal.Function_<Internal.SurfaceRules$Condition, V>): Internal.Function<Internal.SurfaceRules$Context, V>;
        bootstrap($$0: Internal.Registry_<Internal.Codec<Internal.SurfaceRules$ConditionSource>>): Internal.Codec<Internal.SurfaceRules$ConditionSource>;
        identity<T>(): Internal.Function<T, T>;
        abstract codec(): Internal.KeyDispatchDataCodec<Internal.SurfaceRules$ConditionSource>;
        abstract apply(arg0: Internal.SurfaceRules$Context_): Internal.SurfaceRules$Condition;
        compose<V>(arg0: Internal.Function_<V, Internal.SurfaceRules$Context>): Internal.Function<V, Internal.SurfaceRules$Condition>;
        readonly CODEC: Internal.Codec<Internal.SurfaceRules$ConditionSource>;
    }
    type SurfaceRules$ConditionSource_ = SurfaceRules$ConditionSource;
    class RingAscent extends Internal.BaseRing implements Internal.HandTickable, Internal.HandRemoveHandler {
        constructor(settings: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(itemStack: Internal.ItemStack_, world: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, tooltipContext: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(world: Internal.Level_, player: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil(stack: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        tickHand(stack: Internal.ItemStack_, player: Internal.Player_): void;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        onRemoved(player: Internal.Player_): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick(stack: Internal.ItemStack_, world: Internal.Level_, entity: Internal.Entity_, slot: number, selected: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type RingAscent_ = RingAscent;
    class CinnamonSticksItem extends Internal.Item {
        constructor()
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration(itemstack: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type CinnamonSticksItem_ = CinnamonSticksItem;
    interface Pointer {
        abstract address(): number;
        (): number;
        readonly CLONG_SIZE: (4) & (number);
        readonly POINTER_SHIFT: (3) & (number);
        readonly CLONG_SHIFT: (2) & (number);
        readonly BITS64: (true) & (boolean);
        readonly BITS32: (false) & (boolean);
        readonly POINTER_SIZE: (8) & (number);
    }
    type Pointer_ = Pointer | (()=> number);
    class OctahedralGroup extends Internal.Enum<Internal.OctahedralGroup> implements Internal.StringRepresentable {
        getClass(): typeof any;
        static fromEnumWithMapping<E extends Internal.Enum<E> & Internal.StringRepresentable>($$0: Internal.Supplier_<E[]>, $$1: Internal.Function_<string, string>): Internal.StringRepresentable$EnumCodec<E>;
        getSerializedName(): string;
        compareTo(arg0: Internal.OctahedralGroup_): number;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        static valueOf($$0: string): Internal.OctahedralGroup;
        inverse(): this;
        static fromEnum<E extends Internal.Enum<E> & Internal.StringRepresentable>($$0: Internal.Supplier_<E[]>): Internal.StringRepresentable$EnumCodec<E>;
        "rotate(net.minecraft.core.FrontAndTop)"($$0: Internal.FrontAndTop_): Internal.FrontAndTop;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.OctahedralGroup>>;
        static values(): Internal.OctahedralGroup[];
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        transformation(): Matrix3f;
        toString(): string;
        notifyAll(): void;
        "compareTo(com.mojang.math.OctahedralGroup)"(arg0: Internal.OctahedralGroup_): number;
        getDeclaringClass(): typeof Internal.OctahedralGroup;
        compose($$0: Internal.OctahedralGroup_): this;
        name(): string;
        rotate($$0: Internal.Direction_): Internal.Direction;
        hashCode(): number;
        static keys($$0: Internal.StringRepresentable_[]): Internal.Keyable;
        inverts($$0: Internal.Direction$Axis_): boolean;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        rotate($$0: Internal.FrontAndTop_): Internal.FrontAndTop;
        "rotate(net.minecraft.core.Direction)"($$0: Internal.Direction_): Internal.Direction;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        get class(): typeof any
        get serializedName(): string
        get declaringClass(): typeof Internal.OctahedralGroup
        static readonly ROT_180_EDGE_XY_NEG: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_180_EDGE_YZ_POS: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly SWAP_XZ: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_90_REF_Y_NEG: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly INVERT_Z: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly SWAP_YZ: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly INVERT_X: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_180_EDGE_XY_POS: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_180_EDGE_YZ_NEG: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_90_Z_POS: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly SWAP_NEG_YZ: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_180_FACE_XY: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly SWAP_NEG_XZ: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_90_Z_NEG: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_60_REF_PNN: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_60_REF_PPP: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_60_REF_PNP: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_60_REF_NNP: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_60_REF_NNN: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_60_REF_NPP: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_60_REF_PPN: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_90_REF_Y_POS: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_60_REF_NPN: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_90_X_NEG: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_120_PNP: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly INVERT_Y: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_180_EDGE_XZ_POS: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly SWAP_XY: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_120_NPN: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_90_REF_Z_POS: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_120_NNP: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_90_REF_X_POS: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_120_PPN: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_120_NNN: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_120_NPP: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_90_X_POS: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_120_PNN: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_120_PPP: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_90_REF_X_NEG: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly IDENTITY: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly SWAP_NEG_XY: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_180_FACE_YZ: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_180_FACE_XZ: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_180_EDGE_XZ_NEG: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_90_REF_Z_NEG: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_90_Y_NEG: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly ROT_90_Y_POS: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
        static readonly INVERSION: (Internal.OctahedralGroup) & (Internal.OctahedralGroup);
    }
    type OctahedralGroup_ = "inversion" | "rot_180_face_xz" | "invert_z" | "rot_180_edge_xy_pos" | "rot_120_pnp" | "rot_120_ppp" | "rot_120_nnn" | "rot_120_npn" | "rot_90_ref_z_neg" | "rot_180_edge_xz_pos" | "swap_xy" | "rot_90_x_neg" | "swap_neg_yz" | "identity" | "rot_90_z_neg" | "rot_90_ref_z_pos" | "rot_60_ref_ppn" | "rot_60_ref_npp" | "rot_60_ref_pnn" | "rot_60_ref_nnp" | "rot_180_edge_yz_pos" | "swap_yz" | "rot_90_y_pos" | "rot_90_ref_y_neg" | "rot_90_ref_y_pos" | "rot_90_x_pos" | "rot_180_face_yz" | "rot_180_edge_xy_neg" | "rot_120_nnp" | "rot_120_pnn" | "rot_120_npp" | "rot_120_ppn" | "swap_neg_xz" | "rot_90_ref_x_pos" | "invert_x" | OctahedralGroup | "rot_180_edge_xz_neg" | "rot_90_ref_x_neg" | "rot_180_face_xy" | "rot_90_z_pos" | "rot_60_ref_nnn" | "rot_60_ref_ppp" | "rot_90_y_neg" | "rot_180_edge_yz_neg" | "swap_xz" | "rot_60_ref_npn" | "invert_y" | "rot_60_ref_pnp" | "swap_neg_xy";
    interface ProgramTypeAccessor {
        createProgramType(name: string, ordinal: number, typeName: string, extension: string, glId: number): Internal.Program$Type;
    }
    type ProgramTypeAccessor_ = ProgramTypeAccessor;
    class FloatTag extends Internal.NumericTag {
        getClass(): typeof any;
        static checkSpecialEquality(o: any, o1: any, shallow: boolean): boolean;
        "accept(net.minecraft.nbt.StreamTagVisitor)"($$0: Internal.StreamTagVisitor_): Internal.StreamTagVisitor$ValueResult;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        "accept(net.minecraft.nbt.TagVisitor)"($$0: Internal.TagVisitor_): void;
        sizeInBytes(): number;
        getAsFloat(): number;
        getAsLong(): number;
        acceptAsRoot($$0: Internal.StreamTagVisitor_): void;
        write($$0: Internal.DataOutput_): void;
        getId(): number;
        toString(): string;
        notifyAll(): void;
        specialEquals(o: any, shallow: boolean): boolean;
        getAsDouble(): number;
        accept($$0: Internal.TagVisitor_): void;
        "copy()"(): Internal.Tag;
        getAsInt(): number;
        hashCode(): number;
        getAsString(): string;
        getAsByte(): number;
        getAsNumber(): number;
        copy(): Internal.Tag;
        wait(): void;
        wait(arg0: number): void;
        copy(): this;
        getAsShort(): number;
        "copy()"(): this;
        getType(): Internal.TagType<Internal.FloatTag>;
        equals($$0: any): boolean;
        static valueOf($$0: number): Internal.FloatTag;
        accept($$0: Internal.StreamTagVisitor_): Internal.StreamTagVisitor$ValueResult;
        get class(): typeof any
        get asFloat(): number
        get asLong(): number
        get id(): number
        get asDouble(): number
        get asInt(): number
        get asString(): string
        get asByte(): number
        get asNumber(): number
        get asShort(): number
        get type(): Internal.TagType<Internal.FloatTag>
        static readonly TYPE: Internal.TagType<Internal.FloatTag>;
        static readonly ZERO: (Internal.FloatTag) & (Internal.FloatTag);
    }
    type FloatTag_ = FloatTag;
    class Program {
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        attachToShader($$0: Internal.Shader_): void;
        static compileShader($$0: Internal.Program$Type_, $$1: string, $$2: Internal.InputStream_, $$3: string, $$4: Internal.GlslPreprocessor_): Internal.Program;
        wait(): void;
        close(): void;
        getName(): string;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        getId(): number;
        get class(): typeof any
        get name(): string
        get id(): number
    }
    type Program_ = Program;
    abstract class AbstractStringBuilder implements Internal.CharSequence, Internal.Appendable {
        reverse(): this;
        "append(int)"(arg0: number): this;
        append(arg0: string): this;
        codePointAt(arg0: number): number;
        insert(arg0: number, arg1: string): this;
        append(arg0: number): this;
        append(arg0: boolean): this;
        append(arg0: number): this;
        lastIndexOf(arg0: string): number;
        notify(): void;
        "append(java.lang.Object)"(arg0: any): this;
        insert(arg0: number, arg1: number): this;
        getChars(arg0: number, arg1: number, arg2: string[], arg3: number): void;
        indexOf(arg0: string): number;
        append(arg0: number): this;
        lastIndexOf(arg0: string, arg1: number): number;
        "append(java.lang.CharSequence)"(arg0: Internal.CharSequence_): this;
        insert(arg0: number, arg1: boolean): this;
        charAt(arg0: number): string;
        "insert(int,int)"(arg0: number, arg1: number): this;
        length(): number;
        "insert(int,char[],int,int)"(arg0: number, arg1: string[], arg2: number, arg3: number): this;
        replace(arg0: number, arg1: number, arg2: string): this;
        trimToSize(): void;
        insert(arg0: number, arg1: number): this;
        "insert(int,boolean)"(arg0: number, arg1: boolean): this;
        append(arg0: string): this;
        "delete"(arg0: number, arg1: number): this;
        static compare(arg0: Internal.CharSequence_, arg1: Internal.CharSequence_): number;
        indexOf(arg0: string, arg1: number): number;
        chars(): Internal.IntStream;
        ensureCapacity(arg0: number): void;
        wait(): void;
        insert(arg0: number, arg1: Internal.CharSequence_): this;
        insert(arg0: number, arg1: string): this;
        insert(arg0: number, arg1: any): this;
        append(arg0: number): this;
        "insert(int,java.lang.CharSequence)"(arg0: number, arg1: Internal.CharSequence_): this;
        getClass(): typeof any;
        "insert(int,char[])"(arg0: number, arg1: string[]): this;
        "append(char)"(arg0: string): this;
        capacity(): number;
        append(arg0: string[]): this;
        codePointCount(arg0: number, arg1: number): number;
        substring(arg0: number): string;
        setCharAt(arg0: number, arg1: string): void;
        "insert(int,java.lang.CharSequence,int,int)"(arg0: number, arg1: Internal.CharSequence_, arg2: number, arg3: number): this;
        setLength(arg0: number): void;
        "insert(int,double)"(arg0: number, arg1: number): this;
        isEmpty(): boolean;
        wait(arg0: number, arg1: number): void;
        codePointBefore(arg0: number): number;
        append(arg0: string[], arg1: number, arg2: number): this;
        "append(java.lang.CharSequence,int,int)"(arg0: Internal.CharSequence_, arg1: number, arg2: number): this;
        deleteCharAt(arg0: number): this;
        append(arg0: Internal.StringBuffer_): this;
        subSequence(arg0: number, arg1: number): Internal.CharSequence;
        append(arg0: Internal.CharSequence_, arg1: number, arg2: number): this;
        "append(boolean)"(arg0: boolean): this;
        appendCodePoint(arg0: number): this;
        "append(char[])"(arg0: string[]): this;
        "append(double)"(arg0: number): this;
        substring(arg0: number, arg1: number): string;
        "insert(int,java.lang.Object)"(arg0: number, arg1: any): this;
        "append(float)"(arg0: number): this;
        "append(char[],int,int)"(arg0: string[], arg1: number, arg2: number): this;
        abstract toString(): string;
        insert(arg0: number, arg1: number): this;
        "append(java.lang.StringBuffer)"(arg0: Internal.StringBuffer_): this;
        notifyAll(): void;
        insert(arg0: number, arg1: Internal.CharSequence_, arg2: number, arg3: number): this;
        "insert(int,char)"(arg0: number, arg1: string): this;
        "append(java.lang.String)"(arg0: string): this;
        "insert(int,float)"(arg0: number, arg1: number): this;
        hashCode(): number;
        insert(arg0: number, arg1: number): this;
        wait(arg0: number): void;
        insert(arg0: number, arg1: string[], arg2: number, arg3: number): this;
        offsetByCodePoints(arg0: number, arg1: number): number;
        "append(long)"(arg0: number): this;
        append(arg0: any): this;
        insert(arg0: number, arg1: string[]): this;
        equals(arg0: any): boolean;
        "insert(int,long)"(arg0: number, arg1: number): this;
        append(arg0: Internal.CharSequence_): this;
        "insert(int,java.lang.String)"(arg0: number, arg1: string): this;
        codePoints(): Internal.IntStream;
        get class(): typeof any
        set length(arg0: number)
        get empty(): boolean
    }
    type AbstractStringBuilder_ = AbstractStringBuilder;
    class FilterableWeightedList <U> extends Internal.ShufflingList<U> {
        constructor()
        getClass(): typeof any;
        entryStream(): Internal.Stream<Internal.ShufflingList$WeightedEntry<U>>;
        hasFilter(): boolean;
        stream(): Internal.Stream<U>;
        static codec<U>($$0: Internal.Codec_<U>): Internal.Codec<Internal.ShufflingList<U>>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        static cast<T>(list: Internal.ShufflingList_<T>): Internal.Iterable<T>;
        forEach(arg0: Internal.Consumer_<U>): void;
        getEntries(): Internal.List<any>;
        pickRandom(random: Internal.Random_): U;
        toString(): string;
        iterator(): Internal.Iterator<any>;
        add($$0: U, $$1: number): Internal.ShufflingList<U>;
        notifyAll(): void;
        shuffle(): Internal.ShufflingList<any>;
        spliterator(): Internal.Spliterator<U>;
        addFilter(filter: Internal.Predicate_<U>): void;
        size(): number;
        hashCode(): number;
        addAll(other: Internal.FilterableWeightedList_<U>): void;
        shuffleVanilla(): Internal.ShufflingList<any>;
        wait(): void;
        pickRandom(): U;
        wait(arg0: number): void;
        setFilter(filter: Internal.Predicate_<U>): void;
        equals(arg0: any): boolean;
        copy(): this;
        removeFilter(): void;
        get class(): typeof any
        get entries(): Internal.List<any>
        set filter(filter: Internal.Predicate_<U>)
    }
    type FilterableWeightedList_<U> = FilterableWeightedList<U>;
    class StructureMode extends Internal.Enum<Internal.StructureMode> implements Internal.StringRepresentable {
        getDisplayName(): net.minecraft.network.chat.Component;
        static values(): Internal.StructureMode[];
        getClass(): typeof any;
        static fromEnumWithMapping<E extends Internal.Enum<E> & Internal.StringRepresentable>($$0: Internal.Supplier_<E[]>, $$1: Internal.Function_<string, string>): Internal.StringRepresentable$EnumCodec<E>;
        getSerializedName(): string;
        compareTo(arg0: Internal.StructureMode_): number;
        notify(): void;
        "compareTo(net.minecraft.world.level.block.state.properties.StructureMode)"(arg0: Internal.StructureMode_): number;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        static fromEnum<E extends Internal.Enum<E> & Internal.StringRepresentable>($$0: Internal.Supplier_<E[]>): Internal.StringRepresentable$EnumCodec<E>;
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getDeclaringClass(): typeof Internal.StructureMode;
        toString(): string;
        notifyAll(): void;
        static valueOf($$0: string): Internal.StructureMode;
        name(): string;
        hashCode(): number;
        static keys($$0: Internal.StringRepresentable_[]): Internal.Keyable;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.StructureMode>>;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        get displayName(): net.minecraft.network.chat.Component
        get class(): typeof any
        get serializedName(): string
        get declaringClass(): typeof Internal.StructureMode
        static readonly SAVE: (Internal.StructureMode) & (Internal.StructureMode);
        static readonly CORNER: (Internal.StructureMode) & (Internal.StructureMode);
        static readonly LOAD: (Internal.StructureMode) & (Internal.StructureMode);
        static readonly DATA: (Internal.StructureMode) & (Internal.StructureMode);
    }
    type StructureMode_ = "load" | StructureMode | "save" | "data" | "corner";
    class SparkAugmentItem extends Internal.Item implements Internal.ItemWithBannerPattern {
        constructor(builder: Internal.Item$Properties_, type: Internal.SparkUpgradeType_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        getBannerPattern(): Internal.TagKey<Internal.BannerPattern>;
        static getByType(type: Internal.SparkUpgradeType_): Internal.ItemStack;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get bannerPattern(): Internal.TagKey<Internal.BannerPattern>
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
        readonly type: Internal.SparkUpgradeType;
    }
    type SparkAugmentItem_ = SparkAugmentItem;
    interface SignedMessageValidator {
        abstract updateAndValidate(arg0: Internal.PlayerChatMessage_): boolean;
        (arg0: Internal.PlayerChatMessage): boolean;
        readonly ACCEPT_UNSIGNED: Internal.SignedMessageValidator;
        readonly REJECT_ALL: Internal.SignedMessageValidator;
    }
    type SignedMessageValidator_ = SignedMessageValidator | ((arg0: Internal.PlayerChatMessage)=> boolean);
    interface RenderContext$QuadTransform {
        abstract transform(arg0: Internal.MutableQuadView_): boolean;
        (arg0: Internal.MutableQuadView): boolean;
    }
    type RenderContext$QuadTransform_ = ((arg0: Internal.MutableQuadView)=> boolean) | RenderContext$QuadTransform;
    class CommandBlock extends Internal.BaseEntityBlock implements Internal.GameMasterBlock {
        constructor($$0: Internal.BlockBehaviour$Properties_, $$1: boolean)
        /**
         * @deprecated
        */
        getOcclusionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        /**
         * @deprecated
        */
        getSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        axiom$customPickBlockStack(): Internal.ItemStack;
        getSoundType($$0: Internal.BlockState_): SoundType;
        /**
         * @deprecated
        */
        getVisualShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        handler$efo000$collective$Block_playerDestroy(level: Internal.Level_, player: Internal.Player_, blockPos: BlockPos_, blockState: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number, $$5: number): void;
        /**
         * @deprecated
        */
        randomTick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: Internal.BlockEntity_): void;
        static canSupportRigidBlock($$0: Internal.BlockGetter_, $$1: BlockPos_): boolean;
        static popResource($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.ItemStack_): void;
        setRandomTickCallback(callback: Internal.Consumer_<any>): void;
        getDescriptionId(): string;
        stepOn($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Entity_): void;
        fallOn($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: BlockPos_, $$3: Internal.Entity_, $$4: number): void;
        getSettings(): Internal.BlockBehaviour$Properties;
        triggerEvent($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: number, $$4: number): boolean;
        getExplosionResistance(): number;
        asItem(): Internal.Item;
        getTypeData(): Internal.CompoundTag;
        setFriction(arg0: number): void;
        getRenderShape($$0: Internal.BlockState_): Internal.RenderShape;
        canCull(): boolean;
        customShapeUpdate(blockState: Internal.CustomBlockState_, levelReader: Internal.LevelReader_, blockPos: BlockPos_): Internal.CustomBlockState;
        getJumpFactor(): number;
        getSpeedFactor(): number;
        static canSupportCenter($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        skipRendering($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getLightBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        playerDestroy($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.BlockEntity_, $$5: Internal.ItemStack_): void;
        shouldAttemptToCull(state: Internal.BlockState_): boolean;
        isPossibleToRespawnInThis($$0: Internal.BlockState_): boolean;
        getCustomStateForPlacement(blockPlaceContext: Internal.BlockPlaceContext_): Internal.CustomBlockState;
        /**
         * @deprecated
        */
        getDirectSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        getProperties(): Internal.BlockBehaviour$Properties;
        playerWillDestroy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Player_): void;
        getClass(): typeof any;
        getMaxVerticalOffset(): number;
        newBlockEntity($$0: BlockPos_, $$1: Internal.BlockState_): Internal.BlockEntity;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.item.context.BlockPlaceContext)"($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        useShapeForLightOcclusion($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        getDrops($$0: Internal.BlockState_, $$1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getStateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>;
        /**
         * @deprecated
        */
        entityInside($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Entity_): void;
        setBlockBuilder(b: Internal.BlockBuilder_): void;
        handler$ldb000$puzzleslib$playerDestroy$0(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        setRequiresTool(v: boolean): void;
        setSpeedFactor(arg0: number): void;
        axiom$getPossibleCustomStates(): Internal.List<any>;
        setExplosionResistance(arg0: number): void;
        toString(): string;
        port_lib$popExperience(arg0: Internal.ServerLevel_, arg1: BlockPos_, arg2: number): void;
        notifyAll(): void;
        getToolModifiedState(state: Internal.BlockState_, world: Internal.Level_, pos: BlockPos_, player: Internal.Player_, stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): Internal.BlockState;
        getId(): string;
        getLootTable(): ResourceLocation;
        puzzleslib$setItem(arg0: Internal.Item_): void;
        axiom$translationKey(): string;
        /**
         * @deprecated
        */
        getInteractionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        setPlacedBy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.LivingEntity_, $$4: Internal.ItemStack_): void;
        propagatesSkylightDown($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        /**
         * @deprecated
        */
        onPlace($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Block>;
        static popResourceFromFace($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.ItemStack_): void;
        getFriction(): number;
        handlePrecipitation($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Biome$Precipitation_): void;
        hasAnalogOutputSignal($$0: Internal.BlockState_): boolean;
        wait(arg0: number): void;
        /**
         * @deprecated
        */
        getFluidState($$0: Internal.BlockState_): Internal.FluidState;
        handler$koh000$porting_lib_entity$getDestroySpeed(blockState: Internal.BlockState_, player: Internal.Player_, blockGetter: Internal.BlockGetter_, pos: BlockPos_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getAnalogOutputSignal($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): number;
        handler$efo000$collective$Block_setPlacedBy(level: Internal.Level_, blockPos: BlockPos_, blockState: Internal.BlockState_, livingEntity: Internal.LivingEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        tick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        supportsExternalFaceHiding(state: Internal.BlockState_): boolean;
        handler$ldb000$puzzleslib$playerDestroy$1(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        notify(): void;
        axiom$asItemStack(): Internal.ItemStack;
        neighborChanged($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Block_, $$4: BlockPos_, $$5: boolean): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): void;
        handler$zhd000$additionalentityattributes$additionalEntityAttributes$saveBreakingPlayer(world: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, stack: Internal.ItemStack_, callbackInfo: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        getBlockSupportShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        canSustainPlant(state: Internal.BlockState_, world: Internal.BlockGetter_, pos: BlockPos_, facing: Internal.Direction_, plantable: Internal.IPlantable_): boolean;
        /**
         * @deprecated
        */
        isCollisionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static isFaceFull($$0: Internal.VoxelShape_, $$1: Internal.Direction_): boolean;
        getMenuProvider($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): Internal.MenuProvider;
        getTicker<T extends Internal.BlockEntity>($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockEntityType_<T>): Internal.BlockEntityTicker<T>;
        static byItem($$0: Internal.Item_): Internal.Block;
        static updateFromNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        updateIndirectNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: number, $$4: number): void;
        destroy($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): void;
        handler$fdc000$everycomp$addSimpleFastECdrops(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, cir: Internal.CallbackInfoReturnable_<any>, resId: ResourceLocation_, lootParams: Internal.LootParams_, serverLevel: Internal.ServerLevel_, lootTable: Internal.LootTable_): void;
        getToolModifiedState(state: Internal.BlockState_, context: Internal.UseOnContext_, toolAction: Internal.ToolAction_, simulate: boolean): Internal.BlockState;
        use($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_, $$4: Internal.InteractionHand_, $$5: Internal.BlockHitResult_): Internal.InteractionResult;
        setLightEmission(v: number): void;
        doNormalInteractions(): boolean;
        setJumpFactor(arg0: number): void;
        /**
         * @deprecated
        */
        canSurvive($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): void;
        /**
         * @deprecated
        */
        getShadeBrightness($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        getAppearance(state: Internal.BlockState_, renderView: Internal.BlockAndTintGetter_, pos: BlockPos_, side: Internal.Direction_, sourceState: Internal.BlockState_, sourcePos: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        getCollisionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        setDestroySpeed(v: number): void;
        defaultBlockState(): Internal.BlockState;
        usesCustomShouldDrawFace(state: Internal.BlockState_): boolean;
        getStateForPlacement($$0: Internal.BlockPlaceContext_): Internal.BlockState;
        cantCullAgainst(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>($$0: Internal.ServerLevel_, $$1: T): Internal.GameEventListener;
        arch$holder(): Internal.Holder<Internal.Block>;
        wait(): void;
        getCloneItemStack($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        hasDynamicShape(): boolean;
        getMaxHorizontalOffset(): number;
        /**
         * @deprecated
        */
        getDestroyProgress($$0: Internal.BlockState_, $$1: Internal.Player_, $$2: Internal.BlockGetter_, $$3: BlockPos_): number;
        /**
         * @deprecated
        */
        getSeed($$0: Internal.BlockState_, $$1: BlockPos_): number;
        defaultDestroyTime(): number;
        dropFromExplosion($$0: Internal.Explosion_): boolean;
        /**
         * @deprecated
        */
        updateShape($$0: Internal.BlockState_, $$1: Internal.Direction_, $$2: Internal.BlockState_, $$3: Internal.LevelAccessor_, $$4: BlockPos_, $$5: BlockPos_): Internal.BlockState;
        isRandomlyTicking($$0: Internal.BlockState_): boolean;
        static isShapeFullBlock(shape: Internal.VoxelShape_): boolean;
        withPropertiesOf($$0: Internal.BlockState_): Internal.BlockState;
        static isExceptionForConnection($$0: Internal.BlockState_): boolean;
        setIsRandomlyTicking(arg0: boolean): void;
        rotate($$0: Internal.BlockState_, $$1: Internal.Rotation_): Internal.BlockState;
        hidesNeighborFace(level: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, neighborState: Internal.BlockState_, dir: Internal.Direction_): boolean;
        onTreeGrow(state: Internal.BlockState_, level: Internal.LevelReader_, placeFunction: Internal.BiConsumer_<BlockPos, Internal.BlockState>, randomSource: Internal.RandomSource_, pos: BlockPos_, config: Internal.TreeConfiguration_): boolean;
        defaultMapColor(): Internal.MapColor;
        getStateAtViewpoint(state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_, viewpoint: Vec3d_): Internal.BlockState;
        wait(arg0: number, arg1: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.BlockGetter_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        setNameKey(arg0: string): void;
        static box($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): Internal.VoxelShape;
        mirror($$0: Internal.BlockState_, $$1: Internal.Mirror_): Internal.BlockState;
        wasExploded($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Explosion_): void;
        getName(): Internal.MutableComponent;
        updateEntityAfterFallOn($$0: Internal.BlockGetter_, $$1: Internal.Entity_): void;
        animateTick($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        customShouldDrawFace(view: Internal.BlockGetter_, thisState: Internal.BlockState_, sideState: Internal.BlockState_, thisPos: BlockPos_, sidePos: BlockPos_, side: Internal.Direction_): Optional<boolean>;
        axiom$getResourceLocation(): ResourceLocation;
        arch$registryName(): ResourceLocation;
        axiom$getProperties(): Internal.Collection<any>;
        getBlockBuilder(): Internal.BlockBuilder;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        isSignalSource($$0: Internal.BlockState_): boolean;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number): void;
        /**
         * @deprecated
        */
        attack($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): void;
        /**
         * @deprecated
        */
        getShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        shouldAttemptToCull(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        onProjectileHit($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockHitResult_, $$3: Internal.Projectile_): void;
        static stateById($$0: number): Internal.BlockState;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): Internal.List<Internal.ItemStack>;
        requiredFeatures(): Internal.FeatureFlagSet;
        hashCode(): number;
        axiom$defaultCustomState(): Internal.CustomBlockState;
        setCanCull(canCull: boolean): void;
        /**
         * @deprecated
        */
        isOcclusionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static getId($$0: Internal.BlockState_): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.material.Fluid)"($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        static pushEntitiesUp($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        isPathfindable($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.PathComputationType_): boolean;
        setSoundType(arg0: SoundType_): void;
        handler$cef000$betterend$be_getDroppedStacks(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, info: Internal.CallbackInfoReturnable_<any>): void;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_): Internal.List<Internal.ItemStack>;
        /**
         * @deprecated
        */
        onRemove($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        cantCullAgainst(state: Internal.BlockState_): boolean;
        setHasCollision(arg0: boolean): void;
        static shouldRenderFace($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_, $$4: BlockPos_): boolean;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        spawnAfterBreak($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.ItemStack_, $$4: boolean): void;
        set randomTickCallback(callback: Internal.Consumer_<any>)
        get descriptionId(): string
        get settings(): Internal.BlockBehaviour$Properties
        get explosionResistance(): number
        get typeData(): Internal.CompoundTag
        set friction(arg0: number)
        get jumpFactor(): number
        get speedFactor(): number
        get properties(): Internal.BlockBehaviour$Properties
        get class(): typeof any
        get maxVerticalOffset(): number
        get stateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>
        set blockBuilder(b: Internal.BlockBuilder_)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        set speedFactor(arg0: number)
        set explosionResistance(arg0: number)
        get id(): string
        get lootTable(): ResourceLocation
        get friction(): number
        set lightEmission(v: number)
        set jumpFactor(arg0: number)
        set destroySpeed(v: number)
        get maxHorizontalOffset(): number
        set isRandomlyTicking(arg0: boolean)
        set nameKey(arg0: string)
        get name(): Internal.MutableComponent
        get blockBuilder(): Internal.BlockBuilder
        get idLocation(): ResourceLocation
        get mod(): string
        set canCull(canCull: boolean)
        set soundType(arg0: SoundType_)
        set hasCollision(arg0: boolean)
        static readonly CONDITIONAL: (Internal.BooleanProperty) & (Internal.BooleanProperty);
        static readonly FACING: (Internal.DirectionProperty) & (Internal.DirectionProperty);
    }
    type CommandBlock_ = CommandBlock;
    class ClientboundContainerSetDataPacket implements Internal.Packet<Internal.ClientGamePacketListener> {
        constructor($$0: number, $$1: number, $$2: number)
        constructor($$0: Internal.FriendlyByteBuf_)
        handle(arg0: Internal.PacketListener_): void;
        getClass(): typeof any;
        write($$0: Internal.FriendlyByteBuf_): void;
        toString(): string;
        notifyAll(): void;
        getContainerId(): number;
        notify(): void;
        isSkippable(): boolean;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        wait(): void;
        handle($$0: Internal.ClientGamePacketListener_): void;
        wait(arg0: number): void;
        "handle(net.minecraft.network.protocol.game.ClientGamePacketListener)"($$0: Internal.ClientGamePacketListener_): void;
        getValue(): number;
        equals(arg0: any): boolean;
        "handle(net.minecraft.network.PacketListener)"(arg0: Internal.PacketListener_): void;
        getId(): number;
        get class(): typeof any
        get containerId(): number
        get skippable(): boolean
        get value(): number
        get id(): number
    }
    type ClientboundContainerSetDataPacket_ = ClientboundContainerSetDataPacket;
    class BitSet implements Internal.Cloneable, Internal.Serializable {
        constructor()
        constructor(arg0: number)
        clone(): any;
        getClass(): typeof any;
        set(arg0: number): void;
        cardinality(): number;
        xor(arg0: Internal.BitSet_): void;
        isEmpty(): boolean;
        set(arg0: number, arg1: number, arg2: boolean): void;
        "set(int,int)"(arg0: number, arg1: number): void;
        intersects(arg0: Internal.BitSet_): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get(arg0: number, arg1: number): this;
        set(arg0: number, arg1: boolean): void;
        static valueOf(arg0: number[]): Internal.BitSet;
        previousSetBit(arg0: number): number;
        or(arg0: Internal.BitSet_): void;
        static "valueOf(java.nio.ByteBuffer)"(arg0: Internal.ByteBuffer_): Internal.BitSet;
        get(arg0: number): boolean;
        set(arg0: number, arg1: number): void;
        andNot(arg0: Internal.BitSet_): void;
        and(arg0: Internal.BitSet_): void;
        stream(): Internal.IntStream;
        length(): number;
        toString(): string;
        notifyAll(): void;
        static valueOf(arg0: Internal.LongBuffer_): Internal.BitSet;
        clear(arg0: number): void;
        clear(arg0: number, arg1: number): void;
        flip(arg0: number, arg1: number): void;
        flip(arg0: number): void;
        static "valueOf(java.nio.LongBuffer)"(arg0: Internal.LongBuffer_): Internal.BitSet;
        nextClearBit(arg0: number): number;
        "set(int,boolean)"(arg0: number, arg1: boolean): void;
        static valueOf(arg0: number[]): Internal.BitSet;
        static valueOf(arg0: Internal.ByteBuffer_): Internal.BitSet;
        previousClearBit(arg0: number): number;
        static "valueOf(byte[])"(arg0: number[]): Internal.BitSet;
        nextSetBit(arg0: number): number;
        toByteArray(): number[];
        toLongArray(): number[];
        hashCode(): number;
        size(): number;
        wait(): void;
        static "valueOf(long[])"(arg0: number[]): Internal.BitSet;
        clear(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        get class(): typeof any
        get empty(): boolean
    }
    type BitSet_ = BitSet;
    class ChunkRenderDispatcher {
        constructor($$0: Internal.ClientLevel_, $$1: Internal.LevelRenderer_, $$2: Internal.Executor_, $$3: boolean, $$4: Internal.ChunkBufferBuilderPack_)
        getClass(): typeof any;
        getFreeBufferCount(): number;
        toString(): string;
        setCamera($$0: Vec3d_): void;
        rebuildChunkSync($$0: Internal.ChunkRenderDispatcher$RenderChunk_, $$1: Internal.RenderRegionCache_): void;
        notifyAll(): void;
        notify(): void;
        getCameraPosition(): Vec3d;
        wait(arg0: number, arg1: number): void;
        schedule($$0: Internal.ChunkRenderDispatcher$RenderChunk$ChunkCompileTask_): void;
        uploadAllPendingUploads(): void;
        hashCode(): number;
        wait(): void;
        getToBatchCount(): number;
        getToUpload(): number;
        wait(arg0: number): void;
        isQueueEmpty(): boolean;
        blockUntilClear(): void;
        dispose(): void;
        getStats(): string;
        equals(arg0: any): boolean;
        setLevel($$0: Internal.ClientLevel_): void;
        uploadChunkLayer($$0: Internal.BufferBuilder$RenderedBuffer_, $$1: Internal.VertexBuffer_): Internal.CompletableFuture<void>;
        get class(): typeof any
        get freeBufferCount(): number
        set camera($$0: Vec3d_)
        get cameraPosition(): Vec3d
        get toBatchCount(): number
        get toUpload(): number
        get queueEmpty(): boolean
        get stats(): string
        set level($$0: Internal.ClientLevel_)
    }
    type ChunkRenderDispatcher_ = ChunkRenderDispatcher;
    interface IngredientDeserializer {
        abstract fromNetwork(arg0: Internal.FriendlyByteBuf_): Internal.Ingredient;
        init(): void;
        tryDeserializeJson(object: Internal.JsonObject_): Internal.Ingredient;
        abstract fromJson(arg0: Internal.JsonObject_): Internal.Ingredient;
        tryDeserializeNetwork(buf: Internal.FriendlyByteBuf_): Internal.Ingredient;
        readonly KNOWN_MISSING: ([ResourceLocation, ResourceLocation]) & (Internal.List<ResourceLocation>);
        readonly REGISTRY: Internal.Registry<Internal.IngredientDeserializer>;
    }
    type IngredientDeserializer_ = IngredientDeserializer | Special.IngredientDeserializers;
    interface FlowMessage extends Internal.Message {
        abstract getFormattedMessage(): string;
        abstract getParameters(): any[];
        abstract getFormat(): string;
        abstract getMessage(): Internal.Message;
        abstract getText(): string;
        abstract getThrowable(): Internal.Throwable;
        get formattedMessage(): string
        get parameters(): any[]
        get format(): string
        get message(): Internal.Message
        get text(): string
        get throwable(): Internal.Throwable
    }
    type FlowMessage_ = FlowMessage;
    abstract class ThrowableItemProjectile extends Internal.ThrowableProjectile implements Internal.ItemSupplier {
        constructor($$0: Internal.EntityType_<Internal.ThrowableItemProjectile>, $$1: Internal.LivingEntity_, $$2: Internal.Level_)
        constructor($$0: Internal.EntityType_<Internal.ThrowableItemProjectile>, $$1: Internal.Level_)
        constructor($$0: Internal.EntityType_<Internal.ThrowableItemProjectile>, $$1: number, $$2: number, $$3: number, $$4: Internal.Level_)
        litematica_setWorld(arg0: Internal.Level_): void;
        handler$hak000$gobber2$gobberOccludeVibrationSignals(cir: Internal.CallbackInfoReturnable_<any>): void;
        isInWall(): boolean;
        etf$getType(): Internal.EntityType<any>;
        getAllSlots(): Internal.Iterable<Internal.ItemStack>;
        getUpVector($$0: number): Vec3d;
        gameEvent($$0: Internal.GameEvent_, $$1: Internal.Entity_): void;
        remove($$0: Internal.Entity$RemovalReason_): void;
        getBlockZ(): number;
        isSuppressingBounce(): boolean;
        dampensVibrations(): boolean;
        hasAttached(type: Internal.AttachmentType_<any>): boolean;
        isSilent(): boolean;
        "playSound(net.minecraft.sounds.SoundEvent)"($$0: Internal.SoundEvent_): void;
        setCulled(value: boolean): void;
        getPitch(): number;
        isOnFire(): boolean;
        rotate($$0: Internal.Rotation_): number;
        getPositionCodec(): Internal.VecDeltaCodec;
        getPassengersAndSelf(): Internal.Stream<any>;
        setMaxUpStep($$0: number): void;
        updateFluidHeightAndDoFluidPushing($$0: Internal.TagKey_<Internal.Fluid>, $$1: number): boolean;
        setPosition(x: number, y: number, z: number): void;
        runCommandSilent(command: string): number;
        chunkPosition(): Internal.ChunkPos;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        emf$isOnGround(): boolean;
        method_5652($$0: Internal.CompoundTag_): void;
        gameEvent($$0: Internal.GameEvent_): void;
        alwaysAccepts(): boolean;
        isShiftKeyDown(): boolean;
        setUUID($$0: Internal.UUID_): void;
        checkBelowWorld(): void;
        isVisuallyCrawling(): boolean;
        setMotionZ(z: number): void;
        handler$ieb000$lambdynlights$onRemove(ci: Internal.CallbackInfo_): void;
        "deserializeNBT(net.minecraft.nbt.Tag)"(arg0: Internal.Tag_): void;
        canFreeze(): boolean;
        ignoreExplosion(): boolean;
        port_lib$setRemovalReason(arg0: Internal.Entity$RemovalReason_): void;
        teleportRelative($$0: number, $$1: number, $$2: number): void;
        getBlockY(): number;
        getIsInsideStructureTracker(): Internal.IsInsideStructureTracker;
        isSpectator(): boolean;
        pehkui_setScaleCache(scaleCache: Internal.ScaleData_[]): void;
        isInWaterOrBubble(): boolean;
        spawnAtLocation($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        getPersistentData(): Internal.CompoundTag;
        getPortalCooldown(): number;
        emf$isGlowing(): boolean;
        getItem(): Internal.ItemStack;
        getRandomZ($$0: number): number;
        pehkui_getOnGround(): boolean;
        causeFallDamage($$0: number, $$1: number, $$2: DamageSource_): boolean;
        getFusionModel(layerIndex: number): Internal.Triple<any, any, any>;
        getDynamicLightChunksToRebuild(forced: boolean): Internal.LongSet;
        getPosition($$0: number): Vec3d;
        setRemoved($$0: Internal.Entity$RemovalReason_): void;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>, initializer: Internal.Supplier_<A>): A;
        getDistanceSq($$0: number, $$1: number, $$2: number): number;
        isInWaterRainOrBubble(): boolean;
        getRemovalReason(): Internal.Entity$RemovalReason;
        wait(arg0: number): void;
        isIgnoringBlockTriggers(): boolean;
        etf$getItemsEquipped(): Internal.Iterable<any>;
        getHandHoldingItemAngle($$0: Internal.Item_): Vec3d;
        etf$getVelocity(): Vec3d;
        hex$markHurt(): void;
        distanceToSqr($$0: Vec3d_): number;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        resetFallDistance(): void;
        "getItem()"(): Internal.ItemStack;
        canSprint(): boolean;
        modifyAttached<A>(type: Internal.AttachmentType_<A>, modifier: Internal.UnaryOperator_<A>): A;
        blockPosition(): BlockPos;
        isSteppingCarefully(): boolean;
        setBoundingBox($$0: Internal.AABB_): void;
        isAmbientCreature(): boolean;
        "spawnAtLocation(net.minecraft.world.item.ItemStack,float)"($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        getBlockX(): number;
        /**
         * @deprecated
        */
        getLightLevelDependentMagicValue(): number;
        getEncodeId(): string;
        getY($$0: number): number;
        emf$prevPitch(): number;
        getBlock(): Internal.BlockContainerJS;
        getNbt(): Internal.CompoundTag;
        etf$getHandItems(): Internal.Iterable<any>;
        setInvisible($$0: boolean): void;
        etf$getArmorItems(): Internal.Iterable<any>;
        getName(): net.minecraft.network.chat.Component;
        isSubmergedInLoosely(tag: Internal.TagKey_<any>): boolean;
        onGround(): boolean;
        getDynamicLightY(): number;
        getControlledVehicle(): Internal.Entity;
        isOnSameTeam($$0: Internal.Entity_): boolean;
        onInsideBubbleColumn($$0: boolean): void;
        attack($$0: DamageSource_, $$1: number): boolean;
        tick(): void;
        getEyePosition(): Vec3d;
        getEyeHeight(): number;
        hasPassenger($$0: Internal.Predicate_<Internal.Entity>): boolean;
        getYaw(): number;
        emf$isTouchingWater(): boolean;
        emf$getVariableMap(): Internal.Object2FloatOpenHashMap<any>;
        getComponentContainer(): Internal.ComponentContainer;
        hasPermissions($$0: number): boolean;
        getDynamicLightPrevZ(): number;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        pehkui_readScaleNbt(nbt: Internal.CompoundTag_): void;
        setCustomNameVisible($$0: boolean): void;
        isAlliedTo($$0: Internal.Team_): boolean;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>): A;
        setOutOfCamera(value: boolean): void;
        getControllingPassenger(): Internal.LivingEntity;
        getRemainingFireTicks(): number;
        getScriptType(): Internal.ScriptType;
        onlyOpCanSetNbt(): boolean;
        startRiding($$0: Internal.Entity_): boolean;
        saveWithoutId($$0: Internal.CompoundTag_): Internal.CompoundTag;
        getForward(): Vec3d;
        tcdcommons_getCustomData(): Internal.GenericProperties<any>;
        fireImmune(): boolean;
        addMotion($$0: number, $$1: number, $$2: number): void;
        getMaxFallDistance(): number;
        getZ($$0: number): number;
        getId(): number;
        pehkui_isFirstUpdate(): boolean;
        canBeHitByProjectile(): boolean;
        getTicksFrozen(): number;
        wrapWithCondition$kom000$porting_lib_entity$port_lib$captureDrops(level: Internal.Level_, entity: Internal.Entity_): boolean;
        getRecipientsForComponentSync(): Internal.Iterable<any>;
        getRandomX($$0: number): number;
        getDynamicLightZ(): number;
        getEyeY(): number;
        spawnAtLocation($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        pick($$0: number, $$1: number, $$2: boolean): Internal.HitResult;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        fabric_readAttachmentsFromNbt(nbt: Internal.CompoundTag_): void;
        getBoundingBox(): Internal.AABB;
        changeDimension(p_20118_: Internal.ServerLevel_, teleporter: Internal.ITeleporter_): Internal.Entity;
        isInWaterOrRain(): boolean;
        isDescending(): boolean;
        emf$getPitch(): number;
        setItemSlot($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_): void;
        getYHeadRot(): number;
        handler$cbi000$besmirchment$isTeammate(other: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>): void;
        equals($$0: any): boolean;
        getViewYRot($$0: number): number;
        fabric_setCustomTeleportTarget(teleportTarget: Internal.PortalInfo_): void;
        dismountsUnderwater(): boolean;
        frameworkGetDataHolder(): com.mrcrayfish.framework.entity.sync.DataHolder;
        playerTouch($$0: Internal.Player_): void;
        addTag($$0: string): boolean;
        getAddEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>;
        getEyeHeight($$0: Internal.Pose_): number;
        syncPacketPositionCodec($$0: number, $$1: number, $$2: number): void;
        setOwner($$0: Internal.Entity_): void;
        callIsBeingRainedOn(): boolean;
        getTeam(): Internal.Team;
        shouldRenderAtSqrDistance($$0: number): boolean;
        getAttachedOrSet<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        damageSources(): Internal.DamageSources;
        removeAttached<A>(type: Internal.AttachmentType_<A>): A;
        setTicksFrozen($$0: number): void;
        recreateFromPacket($$0: Internal.ClientboundAddEntityPacket_): void;
        getMyRidingOffset(): number;
        dismountTo($$0: number, $$1: number, $$2: number): void;
        bettertrims$getDeflected(): boolean;
        setDeltaMovement($$0: Vec3d_): void;
        getLeashOffset($$0: number): Vec3d;
        etf$getEntityKey(): string;
        etf$getPose(): Internal.Pose;
        hasCustomName(): boolean;
        captureDrops(): Internal.Collection<any>;
        isCulled(): boolean;
        isLiving(): boolean;
        isGlowing(): boolean;
        getX(): number;
        isVehicle(): boolean;
        static transfer(original: Internal.AttachmentTarget_, target: Internal.AttachmentTarget_, isDeath: boolean): void;
        etf$getOptifineId(): number;
        dynamicLightWorld(): Internal.Level;
        getLeashOffset(): Vec3d;
        resetDynamicLight(): void;
        isShot(): boolean;
        isAttackable(): boolean;
        spawnAtLocation($$0: Internal.ItemStack_): Internal.ItemEntity;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        thunderHit($$0: Internal.ServerLevel_, $$1: Internal.LightningBolt_): void;
        setIsInPowderSnow($$0: boolean): void;
        etf$distanceTo(entity: Internal.Entity_): number;
        doEnchantDamageEffects($$0: Internal.LivingEntity_, $$1: Internal.Entity_): void;
        setCustomName($$0: net.minecraft.network.chat.Component_): void;
        getSlot($$0: number): Internal.SlotAccess;
        lambdynlights$scheduleTrackedChunksRebuild(renderer: Internal.LevelRenderer_): void;
        "deserializeNBT(net.minecraft.nbt.CompoundTag)"(nbt: Internal.CompoundTag_): void;
        emf$isInLava(): boolean;
        pehkui_constructScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        handler$hak000$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        getTeamId(): string;
        localvar$lfb002$puzzleslib$tick$0(hitResult: Internal.HitResult_): Internal.HitResult;
        stopSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isUnderWater(): boolean;
        stopRiding(): void;
        isCustomNameVisible(): boolean;
        isSupportedBy($$0: BlockPos_): boolean;
        getPistonPushReaction(): Internal.PushReaction;
        getX($$0: number): number;
        lookAt($$0: Internal.EntityAnchorArgument$Anchor_, $$1: Vec3d_): void;
        getLuminance(): number;
        callUnsetRemoved(): void;
        getSelfAndPassengers(): Internal.Stream<any>;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        getDeltaMovement(): Vec3d;
        collide($$0: Vec3d_): Vec3d;
        getMotionX(): number;
        "onSyncedDataUpdated(java.util.List)"($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        shoot($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        hasPassenger($$0: Internal.Entity_): boolean;
        be_getTravelerState(): Internal.TravelerState;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        hasIndirectPassenger($$0: Internal.Entity_): boolean;
        getDynamicLightX(): number;
        getEntityData(): Internal.SynchedEntityData;
        setSecondsOnFire($$0: number): void;
        moveTo($$0: number, $$1: number, $$2: number): void;
        emf$getZ(): number;
        "getDisplayName()"(): net.minecraft.network.chat.Component;
        handleInsidePortal($$0: BlockPos_): void;
        setMotion($$0: number, $$1: number, $$2: number): void;
        playSound($$0: Internal.SoundEvent_): void;
        absMoveTo($$0: number, $$1: number, $$2: number): void;
        isOnRails(): boolean;
        getAttachedOrThrow<A>(type: Internal.AttachmentType_<A>): A;
        handler$ikg000$lithium$tryShortcutFluidPushing(tag: Internal.TagKey_<any>, speed: number, cir: Internal.CallbackInfoReturnable_<any>, box: Internal.AABB_, x1: number, x2: number, y1: number, y2: number, z1: number, z2: number, zero: number): void;
        handler$hak000$gobber2$setFrozenTicks(frozenTicks: number, ci: Internal.CallbackInfo_): void;
        restoreFrom($$0: Internal.Entity_): void;
        markFusionRecomputeModels(): void;
        getDimensionChangingDelay(): number;
        isPeacefulCreature(): boolean;
        setOnGround($$0: boolean): void;
        emf$getYaw(): number;
        handler$cbi000$besmirchment$getScoreboardTeam(cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDynamicLuminance(): number;
        setPos($$0: number, $$1: number, $$2: number): void;
        setYaw($$0: number): void;
        getPickRadius(): number;
        notify(): void;
        getVehicle(): Internal.Entity;
        isEffectiveAi(): boolean;
        handler$kom000$porting_lib_entity$port_lib$startRiding(entity: Internal.Entity_, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        startRiding($$0: Internal.Entity_, $$1: boolean): boolean;
        getStringUuid(): string;
        isRemoved(): boolean;
        emf$isSneaking(): boolean;
        setSwimming($$0: boolean): void;
        teleportToWithTicket($$0: number, $$1: number, $$2: number): void;
        fillCrashReportCategory($$0: Internal.CrashReportCategory_): void;
        getRotationVector(): Internal.Vec2;
        refreshDimensions(): void;
        pehkui_writeScaleNbt(nbt: Internal.CompoundTag_): Internal.CompoundTag;
        self(): Internal.Entity;
        etf$getBlockY(): number;
        isSprinting(): boolean;
        "spawnAtLocation(net.minecraft.world.level.ItemLike)"($$0: Internal.ItemLike_): Internal.ItemEntity;
        getMotionY(): number;
        canCollideWith($$0: Internal.Entity_): boolean;
        setLuminance(luminance: number): void;
        setShiftKeyDown($$0: boolean): void;
        getEyePosition($$0: number): Vec3d;
        getPassengers(): Internal.EntityArrayList;
        getBlockExplosionResistance($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.FluidState_, $$5: number): number;
        handler$ldh000$puzzleslib$spawnAtLocation(stack: Internal.ItemStack_, offsetY: number, callback: Internal.CallbackInfoReturnable_<any>, itemEntity: Internal.ItemEntity_): void;
        getZ(): number;
        canSpawnSprintParticle(): boolean;
        "moveTo(net.minecraft.core.BlockPos,float,float)"($$0: BlockPos_, $$1: number, $$2: number): void;
        teleportTo($$0: number, $$1: number, $$2: number): void;
        shootFromRotation($$0: Internal.Entity_, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): void;
        handler$zbk000$porting_lib_base$port_lib$spawnSprintParticle(ci: Internal.CallbackInfo_, pos: BlockPos_, state: Internal.BlockState_): void;
        getServer(): Internal.MinecraftServer;
        moveRelative($$0: number, $$1: Vec3d_): void;
        getFirstPassenger(): Internal.Entity;
        saveAsPassenger($$0: Internal.CompoundTag_): boolean;
        static gatherClosestChunks(chunks: Internal.LongSet_, x: number, y: number, z: number): void;
        handler$kom000$porting_lib_entity$afterSave(nbt: Internal.CompoundTag_, cir: Internal.CallbackInfoReturnable_<any>): void;
        interact($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        getDismountLocationForPassenger($$0: Internal.LivingEntity_): Vec3d;
        checkLeftOwner(): boolean;
        checkSlowFallDistance(): void;
        getSoundSource(): Internal.SoundSource;
        setFabricBalmData(tag: Internal.CompoundTag_): void;
        removeAfterChangingDimensions(): void;
        getPose(): Internal.Pose;
        touchingUnloadedChunk(): boolean;
        getLookAngle(): Vec3d;
        setPositionAndRotation($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        emf$isOnFire(): boolean;
        getMotionZ(): number;
        etf$getUuid(): Internal.UUID;
        removeVehicle(): void;
        isInvisible(): boolean;
        shouldFusionRecomputeModel(layerIndex: number): boolean;
        is($$0: Internal.Entity_): boolean;
        setZ(z: number): void;
        ejectPassengers(): void;
        getY(): number;
        deserializeNBT(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        updateDynamicLightPreviousCoordinates(): void;
        getProfile(): Internal.GameProfile;
        static setViewScale($$0: number): void;
        emf$isAlive(): boolean;
        setLevelCallback($$0: Internal.EntityInLevelCallback_): void;
        showVehicleHealth(): boolean;
        getDistance(pos: BlockPos_): number;
        playSound($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        emf$getVelocity(): Vec3d;
        etf$isBlockEntity(): boolean;
        shouldUpdateDynamicLight(): boolean;
        startSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isOnScoreboardTeam(teamId: string): boolean;
        setItem($$0: Internal.ItemStack_): void;
        isPushedByFluid(): boolean;
        localvar$bbb000$architectury$modifyLevelCallback_setLevelCallback(callback: Internal.EntityInLevelCallback_): Internal.EntityInLevelCallback;
        position(): Vec3d;
        setTimeout(): void;
        displayFireAnimation(): boolean;
        turn($$0: number, $$1: number): void;
        isOutOfCamera(): boolean;
        getAirSupply(): number;
        getRopeHoldPosition($$0: number): Vec3d;
        copyPosition($$0: Internal.Entity_): void;
        "hasPassenger(net.minecraft.world.entity.Entity)"($$0: Internal.Entity_): boolean;
        etf$canBeBright(): boolean;
        isCrouching(): boolean;
        moveTo($$0: BlockPos_, $$1: number, $$2: number): void;
        isPlayer(): boolean;
        isAnimal(): boolean;
        "handler$fgd000$fabric-dimensions-v1$getTeleportTarget"(destination: Internal.ServerLevel_, cir: Internal.CallbackInfoReturnable_<any>): void;
        canBeCollidedWith(): boolean;
        getMotionDirection(): Internal.Direction;
        asComponentProvider(): Internal.ComponentProvider;
        setY(y: number): void;
        getFeetBlockState(): Internal.BlockState;
        lavaHurt(): void;
        handleDamageEvent($$0: DamageSource_): void;
        getFabricBalmData(): Internal.CompoundTag;
        canChangeDimensions(): boolean;
        getChangeListener(): Internal.EntityInLevelCallback;
        static tickEntity(entity: Internal.Entity_): void;
        getCommandSenderWorld(): Internal.Level;
        positionRider($$0: Internal.Entity_): void;
        baseTick(): void;
        broadcastToPlayer($$0: Internal.ServerPlayer_): boolean;
        changeDimension($$0: Internal.ServerLevel_): Internal.Entity;
        setSharedFlag($$0: number, $$1: boolean): void;
        getOwner(): Internal.Entity;
        handler$kom000$porting_lib_entity$afterLoad(nbt: Internal.CompoundTag_, ci: Internal.CallbackInfo_): void;
        getCustomName(): net.minecraft.network.chat.Component;
        getClass(): typeof any;
        pehkui_shouldIgnoreScaleNbt(): boolean;
        isMoving(): boolean;
        isVisuallySwimming(): boolean;
        getMaxAirSupply(): number;
        attack(hp: number): void;
        dynamicLightTick(): void;
        getFacing(): Internal.Direction;
        emf$isWet(): boolean;
        "hasPassenger(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.Entity>): boolean;
        getDimensions($$0: Internal.Pose_): Internal.EntityDimensions;
        isPassengerOfSameVehicle($$0: Internal.Entity_): boolean;
        invokeGetLeashOffset(): Vec3d;
        isSwimming(): boolean;
        getBoundingBoxForCulling(): Internal.AABB;
        mayInteract($$0: Internal.Level_, $$1: BlockPos_): boolean;
        static collideBoundingBox(entity: Internal.Entity_, movement: Vec3d_, entityBoundingBox: Internal.AABB_, world: Internal.Level_, collisions: Internal.List_<any>): Vec3d;
        setSprinting($$0: boolean): void;
        getDynamicLightLevel(): Internal.Level;
        setPortalCooldown(): void;
        setX(x: number): void;
        trackingPosition(): Vec3d;
        getNameTagOffsetY(): number;
        isInvulnerable(): boolean;
        isInLava(): boolean;
        isInWater(): boolean;
        getPortalWaitTime(): number;
        awardKillScore($$0: Internal.Entity_, $$1: number, $$2: DamageSource_): void;
        getBlockStateOn(): Internal.BlockState;
        getFluidHeightLoosely(tag: Internal.TagKey_<any>): number;
        getFluidJumpThreshold(): number;
        unsetRemoved(): void;
        "setPositionAndRotation(double,double,double,float,float)"($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        isInvisibleTo($$0: Internal.Player_): boolean;
        pehkui_getScaleCache(): Internal.ScaleData[];
        setFusionModel(layerIndex: number, model: Internal.Triple_<any, any, any>): void;
        setAirSupply($$0: number): void;
        getOnPos(): BlockPos;
        getRootVehicle(): Internal.Entity;
        getOwnerUUID(): Internal.UUID;
        etf$getWorld(): Internal.Level;
        save($$0: Internal.CompoundTag_): boolean;
        pehkui_getScales(): Internal.Map<any, any>;
        isNoGravity(): boolean;
        etf$getNbt(): Internal.CompoundTag;
        acceptsFailure(): boolean;
        etf$getBlockPos(): BlockPos;
        pehkui_setShouldIgnoreScaleNbt(ignore: boolean): void;
        setOnGroundWithKnownMovement($$0: boolean, $$1: Vec3d_): void;
        setOldPosAndRot(): void;
        bettertrims$setDeflected(deflected: boolean): void;
        emf$getY(): number;
        handler$kom000$porting_lib_entity$port_lib$entityInit(entityType: Internal.EntityType_<any>, world: Internal.Level_, ci: Internal.CallbackInfo_): void;
        bookshelf$createHoverEvent(): Internal.HoverEvent;
        isFree($$0: number, $$1: number, $$2: number): boolean;
        updateSwimming(): void;
        "moveTo(double,double,double)"($$0: number, $$1: number, $$2: number): void;
        setRemainingFireTicks($$0: number): void;
        getCachedFeetBlockState(): Internal.BlockState;
        shouldInformAdmins(): boolean;
        rideTick(): void;
        emf$age(): number;
        etf$hasCustomName(): boolean;
        /**
         * @deprecated
        */
        getOnPosLegacy(): BlockPos;
        setPos($$0: Vec3d_): void;
        wait(): void;
        getUuid(): Internal.UUID;
        spawn(): void;
        teleportTo($$0: Internal.ServerLevel_, $$1: number, $$2: number, $$3: number, $$4: Internal.Set_<Internal.RelativeMovement>, $$5: number, $$6: number): boolean;
        handler$kom000$porting_lib_entity$port_lib$removeRidingEntity(ci: Internal.CallbackInfo_): void;
        etf$getCustomName(): net.minecraft.network.chat.Component;
        captureDrops(value: Internal.Collection_<any>): Internal.Collection<any>;
        fabric_writeAttachmentsToNbt(nbt: Internal.CompoundTag_): void;
        shouldShowName(): boolean;
        setSilent($$0: boolean): void;
        getArmorSlots(): Internal.Iterable<Internal.ItemStack>;
        hasExactlyOnePlayerPassenger(): boolean;
        kill(): void;
        isOnPortalCooldown(): boolean;
        animateHurt($$0: number): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        handler$kom000$porting_lib_entity$port_lib$onEntityRemove(reason: Internal.Entity$RemovalReason_, ci: Internal.CallbackInfo_): void;
        lambdynlights$setTrackedLitChunkPos(trackedLitChunkPos: Internal.LongSet_): void;
        callGetEyeHeight(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        setPitch($$0: number): void;
        setPosRaw($$0: number, $$1: number, $$2: number): void;
        handleEntityEvent($$0: number): void;
        isAlwaysTicking(): boolean;
        interactAt($$0: Internal.Player_, $$1: Vec3d_, $$2: Internal.InteractionHand_): Internal.InteractionResult;
        emf$getX(): number;
        deserializeNBT(arg0: Internal.Tag_): void;
        puzzleslib$acceptCapturedDrops(capturedDrops: Internal.Collection_<any>): Internal.Collection<any>;
        handler$hak000$gobber2$gobberIsFireImmune(cir: Internal.CallbackInfoReturnable_<any>): void;
        lerpTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: boolean): void;
        onPassengerTurned($$0: Internal.Entity_): void;
        modifyReturnValue$zhe000$additionalentityattributes$getMaxAir(original: number): number;
        spawnAtLocation($$0: Internal.ItemLike_): Internal.ItemEntity;
        emf$hasPassengers(): boolean;
        serializeNBT(): Internal.CompoundTag;
        setAttached(type: Internal.AttachmentType_<any>, value: any): any;
        getBbWidth(): number;
        splitIntoDynamicLightEntries(): Internal.Stream<Internal.SpatialLookupEntry>;
        port_lib$getEntityString(): string;
        addDeltaMovement($$0: Vec3d_): void;
        pehkui_setOnGround(onGround: boolean): void;
        lithiumOnBlockCacheDeleted(): void;
        "spawnAtLocation(net.minecraft.world.level.ItemLike,int)"($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        setInvulnerable($$0: boolean): void;
        "getName()"(): net.minecraft.network.chat.Component;
        push($$0: Internal.Entity_): void;
        emf$hasVehicle(): boolean;
        mirror($$0: Internal.Mirror_): number;
        static port_lib$collideWithShapes(vec3: Vec3d_, aABB: Internal.AABB_, list: Internal.List_<Internal.VoxelShape>): Vec3d;
        getTicksRequiredToFreeze(): number;
        getDynamicLightPrevY(): number;
        maxUpStep(): number;
        setGlowing($$0: boolean): void;
        load($$0: Internal.CompoundTag_): void;
        isAlive(): boolean;
        emf$prevZ(): number;
        getBbHeight(): number;
        getUsername(): string;
        move($$0: Internal.MoverType_, $$1: Vec3d_): void;
        getTags(): Internal.Set<string>;
        getViewVector($$0: number): Vec3d;
        lithiumOnBlockCacheSet(newState: Internal.BlockState_): void;
        isPickable(): boolean;
        setYHeadRot($$0: number): void;
        hasControllingPassenger(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number, $$2: number): boolean;
        absMoveTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        getCustomData(): Internal.CompoundTag;
        getPickResult(): Internal.ItemStack;
        getPercentFrozen(): number;
        getRandomY(): number;
        setPortalCooldown($$0: number): void;
        getDisplayName(): net.minecraft.network.chat.Component;
        hasGlowingTag(): boolean;
        shouldBlockExplode($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: number): boolean;
        emf$isInvisible(): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        emf$isSprinting(): boolean;
        getDynamicLightPrevX(): number;
        shouldBeSaved(): boolean;
        fabric_hasPersistentAttachments(): boolean;
        getViewXRot($$0: number): number;
        canRiderInteract(): boolean;
        method_5749($$0: Internal.CompoundTag_): void;
        fabric_getAttachments(): Internal.Map<any, any>;
        removeTag($$0: string): boolean;
        setPose($$0: Internal.Pose_): void;
        getFluidHeight($$0: Internal.TagKey_<Internal.Fluid>): number;
        getEntityType(): Internal.EntityType<any>;
        isWaterCreature(): boolean;
        pehkui_getScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        toString(): string;
        notifyAll(): void;
        getPassengersRidingOffset(): number;
        etf$getScoreboardTeam(): Internal.Team;
        distanceToEntitySqr($$0: Internal.Entity_): number;
        handler$ldh000$puzzleslib$removeVehicle(callback: Internal.CallbackInfo_): void;
        "getServer()"(): Internal.MinecraftServer;
        isFrame(): boolean;
        setLeftOwner(arg0: boolean): void;
        isPushable(): boolean;
        setYBodyRot($$0: number): void;
        discard(): void;
        onClientRemoval(): void;
        "handler$mhe000$step-height-entity-attribute$getStepHeight"(cir: Internal.CallbackInfoReturnable_<any>): void;
        sendSystemMessage($$0: net.minecraft.network.chat.Component_): void;
        acceptsSuccess(): boolean;
        getDistance(x: number, y: number, z: number): number;
        setMotionY(y: number): void;
        setNoGravity($$0: boolean): void;
        getEffectSource(): Internal.Entity;
        getAttached(type: Internal.AttachmentType_<any>): any;
        getIndirectPassengers(): Internal.Iterable<any>;
        setRotation(yaw: number, pitch: number): void;
        isDynamicLightEnabled(): boolean;
        handler$ldh000$puzzleslib$startRiding(vehicle: Internal.Entity_, force: boolean, callback: Internal.CallbackInfoReturnable_<any>): void;
        createCommandSourceStack(): Internal.CommandSourceStack;
        isControlledByLocalInstance(): boolean;
        isMonster(): boolean;
        localvar$lfb001$puzzleslib$tick$1(hitResult: Internal.HitResult_): Internal.HitResult;
        pehkui_setShouldSyncScales(sync: boolean): void;
        setLastDynamicLuminance(luminance: number): void;
        setId($$0: number): void;
        onSyncedDataUpdated($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        getHorizontalFacing(): Internal.Direction;
        getType(): string;
        getLightProbePosition($$0: number): Vec3d;
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        onAboveBubbleCol($$0: boolean): void;
        emf$prevX(): number;
        "playSound(net.minecraft.sounds.SoundEvent,float,float)"(id: Internal.SoundEvent_, volume: number, pitch: number): void;
        toComponentPacket(key: Internal.ComponentKey_<any>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        isPassenger(): boolean;
        hasPose($$0: Internal.Pose_): boolean;
        checkDespawn(): void;
        pehkui_shouldSyncScales(): boolean;
        isEyeInFluid($$0: Internal.TagKey_<Internal.Fluid>): boolean;
        isInvulnerableTo($$0: DamageSource_): boolean;
        makeStuckInBlock($$0: Internal.BlockState_, $$1: Vec3d_): void;
        getAttachedOrGet<A>(type: Internal.AttachmentType_<A>, defaultValue: Internal.Supplier_<A>): A;
        skipAttackInteraction($$0: Internal.Entity_): boolean;
        lerpMotion($$0: number, $$1: number, $$2: number): void;
        shouldRender($$0: number, $$1: number, $$2: number): boolean;
        onSyncedDataUpdated($$0: Internal.EntityDataAccessor_<any>): void;
        lerpHeadTo($$0: number, $$1: number): void;
        handler$bia000$axiom$onTurn(d: number, e: number, ci: Internal.CallbackInfo_): void;
        static getViewScale(): number;
        setMotionX(x: number): void;
        getHandSlots(): Internal.Iterable<Internal.ItemStack>;
        distanceToEntity($$0: Internal.Entity_): number;
        getVisualRotationYInDegrees(): number;
        isLeftOwner(): boolean;
        wait(arg0: number, arg1: number): void;
        isDiscrete(): boolean;
        getTeamColor(): number;
        setNbt(nbt: Internal.CompoundTag_): void;
        lithiumSetClimbingMobCachingSectionUpdateBehavior(listening: boolean): void;
        unRide(): void;
        getLevel(): Internal.Level;
        "spawnAtLocation(net.minecraft.world.item.ItemStack)"($$0: Internal.ItemStack_): Internal.ItemEntity;
        lambdynlights$getTrackedLitChunkPos(): Internal.LongSet;
        extinguish(): void;
        setDynamicLightEnabled(enabled: boolean): void;
        updateDynamicGameEventListener($$0: Internal.BiConsumer_<Internal.DynamicGameEventListener<any>, Internal.ServerLevel>): void;
        moveTo($$0: Vec3d_): void;
        isColliding($$0: BlockPos_, $$1: Internal.BlockState_): boolean;
        "onSyncedDataUpdated(net.minecraft.network.syncher.EntityDataAccessor)"($$0: Internal.EntityDataAccessor_<any>): void;
        emf$prevY(): number;
        extinguishFire(): void;
        lambdynlights$updateDynamicLight(renderer: Internal.LevelRenderer_): boolean;
        setShot(arg0: boolean): void;
        tell(message: net.minecraft.network.chat.Component_): void;
        static port_lib$collideWithShapes$porting_lib_accessors_$md$424943$0(arg0: Vec3d_, arg1: Internal.AABB_, arg2: Internal.List_<any>): Vec3d;
        isForcedVisible(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number): boolean;
        getDistanceSq(pos: BlockPos_): number;
        emf$getTypeString(): string;
        killedEntity($$0: Internal.ServerLevel_, $$1: Internal.LivingEntity_): boolean;
        getAttachedOrElse<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        isFreezing(): boolean;
        isFullyFrozen(): boolean;
        runCommand(command: string): number;
        setSharedFlagOnFire($$0: boolean): void;
        get inWall(): boolean
        get allSlots(): Internal.Iterable<Internal.ItemStack>
        get blockZ(): number
        get suppressingBounce(): boolean
        get silent(): boolean
        set culled(value: boolean)
        get pitch(): number
        get onFire(): boolean
        get positionCodec(): Internal.VecDeltaCodec
        get passengersAndSelf(): Internal.Stream<any>
        set maxUpStep($$0: number)
        get shiftKeyDown(): boolean
        set UUID($$0: Internal.UUID_)
        get visuallyCrawling(): boolean
        set motionZ(z: number)
        get blockY(): number
        get isInsideStructureTracker(): Internal.IsInsideStructureTracker
        get spectator(): boolean
        get inWaterOrBubble(): boolean
        get persistentData(): Internal.CompoundTag
        get portalCooldown(): number
        get item(): Internal.ItemStack
        set removed($$0: Internal.Entity$RemovalReason_)
        get inWaterRainOrBubble(): boolean
        get removalReason(): Internal.Entity$RemovalReason
        get ignoringBlockTriggers(): boolean
        get "item()"(): Internal.ItemStack
        get steppingCarefully(): boolean
        set boundingBox($$0: Internal.AABB_)
        get ambientCreature(): boolean
        get blockX(): number
        /**
         * @deprecated
        */
        get lightLevelDependentMagicValue(): number
        get encodeId(): string
        get block(): Internal.BlockContainerJS
        get nbt(): Internal.CompoundTag
        set invisible($$0: boolean)
        get name(): net.minecraft.network.chat.Component
        get dynamicLightY(): number
        get controlledVehicle(): Internal.Entity
        get eyePosition(): Vec3d
        get eyeHeight(): number
        get yaw(): number
        get componentContainer(): Internal.ComponentContainer
        get dynamicLightPrevZ(): number
        set customNameVisible($$0: boolean)
        set outOfCamera(value: boolean)
        get controllingPassenger(): Internal.LivingEntity
        get remainingFireTicks(): number
        get scriptType(): Internal.ScriptType
        get forward(): Vec3d
        get maxFallDistance(): number
        get id(): number
        get ticksFrozen(): number
        get recipientsForComponentSync(): Internal.Iterable<any>
        get dynamicLightZ(): number
        get eyeY(): number
        set statusMessage(message: net.minecraft.network.chat.Component_)
        get boundingBox(): Internal.AABB
        get inWaterOrRain(): boolean
        get descending(): boolean
        get YHeadRot(): number
        get addEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>
        set owner($$0: Internal.Entity_)
        get team(): Internal.Team
        set ticksFrozen($$0: number)
        get myRidingOffset(): number
        set deltaMovement($$0: Vec3d_)
        get culled(): boolean
        get living(): boolean
        get glowing(): boolean
        get x(): number
        get vehicle(): boolean
        get leashOffset(): Vec3d
        get shot(): boolean
        get attackable(): boolean
        set isInPowderSnow($$0: boolean)
        set customName($$0: net.minecraft.network.chat.Component_)
        get teamId(): string
        get underWater(): boolean
        get customNameVisible(): boolean
        get pistonPushReaction(): Internal.PushReaction
        get luminance(): number
        get selfAndPassengers(): Internal.Stream<any>
        get deltaMovement(): Vec3d
        get motionX(): number
        get dynamicLightX(): number
        get entityData(): Internal.SynchedEntityData
        set secondsOnFire($$0: number)
        get "displayName()"(): net.minecraft.network.chat.Component
        get onRails(): boolean
        get dimensionChangingDelay(): number
        get peacefulCreature(): boolean
        set onGround($$0: boolean)
        get lastDynamicLuminance(): number
        set yaw($$0: number)
        get pickRadius(): number
        get vehicle(): Internal.Entity
        get effectiveAi(): boolean
        get stringUuid(): string
        get removed(): boolean
        set swimming($$0: boolean)
        get rotationVector(): Internal.Vec2
        get sprinting(): boolean
        get motionY(): number
        set luminance(luminance: number)
        set shiftKeyDown($$0: boolean)
        get passengers(): Internal.EntityArrayList
        get z(): number
        get server(): Internal.MinecraftServer
        get firstPassenger(): Internal.Entity
        get soundSource(): Internal.SoundSource
        set fabricBalmData(tag: Internal.CompoundTag_)
        get pose(): Internal.Pose
        get lookAngle(): Vec3d
        get motionZ(): number
        get invisible(): boolean
        set z(z: number)
        get y(): number
        get profile(): Internal.GameProfile
        set viewScale($$0: number)
        set levelCallback($$0: Internal.EntityInLevelCallback_)
        set item($$0: Internal.ItemStack_)
        get pushedByFluid(): boolean
        get outOfCamera(): boolean
        get airSupply(): number
        get crouching(): boolean
        get player(): boolean
        get animal(): boolean
        get motionDirection(): Internal.Direction
        set y(y: number)
        get feetBlockState(): Internal.BlockState
        get fabricBalmData(): Internal.CompoundTag
        get changeListener(): Internal.EntityInLevelCallback
        get commandSenderWorld(): Internal.Level
        get owner(): Internal.Entity
        get customName(): net.minecraft.network.chat.Component
        get class(): typeof any
        get moving(): boolean
        get visuallySwimming(): boolean
        get maxAirSupply(): number
        get facing(): Internal.Direction
        get swimming(): boolean
        get boundingBoxForCulling(): Internal.AABB
        set sprinting($$0: boolean)
        get dynamicLightLevel(): Internal.Level
        set x(x: number)
        get nameTagOffsetY(): number
        get invulnerable(): boolean
        get inLava(): boolean
        get inWater(): boolean
        get portalWaitTime(): number
        get blockStateOn(): Internal.BlockState
        get fluidJumpThreshold(): number
        set airSupply($$0: number)
        get onPos(): BlockPos
        get rootVehicle(): Internal.Entity
        get ownerUUID(): Internal.UUID
        get noGravity(): boolean
        set remainingFireTicks($$0: number)
        get cachedFeetBlockState(): Internal.BlockState
        /**
         * @deprecated
        */
        get onPosLegacy(): BlockPos
        set pos($$0: Vec3d_)
        get uuid(): Internal.UUID
        set silent($$0: boolean)
        get armorSlots(): Internal.Iterable<Internal.ItemStack>
        get onPortalCooldown(): boolean
        set pitch($$0: number)
        get alwaysTicking(): boolean
        get bbWidth(): number
        set invulnerable($$0: boolean)
        get "name()"(): net.minecraft.network.chat.Component
        get ticksRequiredToFreeze(): number
        get dynamicLightPrevY(): number
        set glowing($$0: boolean)
        get alive(): boolean
        get bbHeight(): number
        get username(): string
        get tags(): Internal.Set<string>
        get pickable(): boolean
        set YHeadRot($$0: number)
        get customData(): Internal.CompoundTag
        get pickResult(): Internal.ItemStack
        get percentFrozen(): number
        get randomY(): number
        set portalCooldown($$0: number)
        get displayName(): net.minecraft.network.chat.Component
        set position(block: Internal.BlockContainerJS_)
        get dynamicLightPrevX(): number
        set pose($$0: Internal.Pose_)
        get entityType(): Internal.EntityType<any>
        get waterCreature(): boolean
        get passengersRidingOffset(): number
        get "server()"(): Internal.MinecraftServer
        get frame(): boolean
        set leftOwner(arg0: boolean)
        get pushable(): boolean
        set YBodyRot($$0: number)
        set motionY(y: number)
        set noGravity($$0: boolean)
        get effectSource(): Internal.Entity
        get indirectPassengers(): Internal.Iterable<any>
        get dynamicLightEnabled(): boolean
        get controlledByLocalInstance(): boolean
        get monster(): boolean
        set lastDynamicLuminance(luminance: number)
        set id($$0: number)
        get horizontalFacing(): Internal.Direction
        get type(): string
        get passenger(): boolean
        get viewScale(): number
        set motionX(x: number)
        get handSlots(): Internal.Iterable<Internal.ItemStack>
        get visualRotationYInDegrees(): number
        get leftOwner(): boolean
        get discrete(): boolean
        get teamColor(): number
        set nbt(nbt: Internal.CompoundTag_)
        get level(): Internal.Level
        set dynamicLightEnabled(enabled: boolean)
        set shot(arg0: boolean)
        get forcedVisible(): boolean
        get freezing(): boolean
        get fullyFrozen(): boolean
        set sharedFlagOnFire($$0: boolean)
    }
    type ThrowableItemProjectile_ = ThrowableItemProjectile;
    class TeamArgument implements Internal.ArgumentType<any> {
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        listSuggestions<S>(commandContext: Internal.CommandContext_<S>, builder: Internal.SuggestionsBuilder_): Internal.CompletableFuture<Internal.Suggestions>;
        static create(): Internal.TeamArgument;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getExamples(): Internal.Collection<string>;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        static get(context: Internal.CommandContext_<Internal.CommandSourceStack>, name: string): dev.ftb.mods.ftbteams.api.Team;
        equals(arg0: any): boolean;
        parse(arg0: Internal.StringReader_): any;
        get class(): typeof any
        get examples(): Internal.Collection<string>
        static readonly CANT_KICK_OWNER: (Internal.SimpleCommandExceptionType) & (Internal.SimpleCommandExceptionType);
        static readonly API_OVERRIDE: (Internal.SimpleCommandExceptionType) & (Internal.SimpleCommandExceptionType);
        static readonly OWNER_CANT_LEAVE: (Internal.SimpleCommandExceptionType) & (Internal.SimpleCommandExceptionType);
        static readonly CANT_EDIT: (Internal.DynamicCommandExceptionType) & (Internal.DynamicCommandExceptionType);
        static readonly NAME_TOO_SHORT: (Internal.SimpleCommandExceptionType) & (Internal.SimpleCommandExceptionType);
        static readonly PLAYER_IN_PARTY: (Internal.DynamicCommandExceptionType) & (Internal.DynamicCommandExceptionType);
        static readonly NOT_IN_PARTY: (Internal.SimpleCommandExceptionType) & (Internal.SimpleCommandExceptionType);
        static readonly NOT_INVITED: (Internal.DynamicCommandExceptionType) & (Internal.DynamicCommandExceptionType);
        static readonly TEAM_NOT_FOUND: (Internal.DynamicCommandExceptionType) & (Internal.DynamicCommandExceptionType);
        static readonly NO_PERMISSION: (Internal.SimpleCommandExceptionType) & (Internal.SimpleCommandExceptionType);
        static readonly NOT_MEMBER: (Internal.Dynamic2CommandExceptionType) & (Internal.Dynamic2CommandExceptionType);
        static readonly NOT_OFFICER: (Internal.Dynamic2CommandExceptionType) & (Internal.Dynamic2CommandExceptionType);
        static readonly ALREADY_IN_PARTY: (Internal.SimpleCommandExceptionType) & (Internal.SimpleCommandExceptionType);
    }
    type TeamArgument_ = TeamArgument;
    interface AccessorVillager {
        abstract hex$tellWitnessesThatIWasMurdered(arg0: Internal.Entity_): void;
        abstract hex$releaseAllPois(): void;
    }
    type AccessorVillager_ = AccessorVillager;
    interface BlockEntityCallback {
        abstract accept(arg0: Internal.BlockEntityJS_): void;
        (arg0: Internal.BlockEntityJS): void;
    }
    type BlockEntityCallback_ = BlockEntityCallback | ((arg0: Internal.BlockEntityJS)=> void);
    class ServerboundResourcePackPacket$Action extends Internal.Enum<Internal.ServerboundResourcePackPacket$Action> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        toString(): string;
        static valueOf($$0: string): Internal.ServerboundResourcePackPacket$Action;
        notifyAll(): void;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.ServerboundResourcePackPacket$Action>>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        name(): string;
        hashCode(): number;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        getDeclaringClass(): typeof Internal.ServerboundResourcePackPacket$Action;
        "compareTo(java.lang.Object)"(arg0: any): number;
        static values(): Internal.ServerboundResourcePackPacket$Action[];
        equals(arg0: any): boolean;
        compareTo(arg0: Internal.ServerboundResourcePackPacket$Action_): number;
        "compareTo(net.minecraft.network.protocol.game.ServerboundResourcePackPacket$Action)"(arg0: Internal.ServerboundResourcePackPacket$Action_): number;
        get class(): typeof any
        get declaringClass(): typeof Internal.ServerboundResourcePackPacket$Action
        static readonly SUCCESSFULLY_LOADED: (Internal.ServerboundResourcePackPacket$Action) & (Internal.ServerboundResourcePackPacket$Action);
        static readonly FAILED_DOWNLOAD: (Internal.ServerboundResourcePackPacket$Action) & (Internal.ServerboundResourcePackPacket$Action);
        static readonly ACCEPTED: (Internal.ServerboundResourcePackPacket$Action) & (Internal.ServerboundResourcePackPacket$Action);
        static readonly DECLINED: (Internal.ServerboundResourcePackPacket$Action) & (Internal.ServerboundResourcePackPacket$Action);
    }
    type ServerboundResourcePackPacket$Action_ = "declined" | "failed_download" | "successfully_loaded" | ServerboundResourcePackPacket$Action | "accepted";
    class RunicAltarRecipe$Serializer implements Internal.RecipeSerializer<Internal.RunicAltarRecipe> {
        constructor()
        getClass(): typeof any;
        "toNetwork(net.minecraft.network.FriendlyByteBuf,vazkii.botania.common.crafting.RunicAltarRecipe)"(buf: Internal.FriendlyByteBuf_, recipe: Internal.RunicAltarRecipe_): void;
        "fromNetwork(net.minecraft.resources.ResourceLocation,net.minecraft.network.FriendlyByteBuf)"(arg0: ResourceLocation_, arg1: Internal.FriendlyByteBuf_): Internal.Recipe<any>;
        toString(): string;
        "toNetwork(net.minecraft.network.FriendlyByteBuf,net.minecraft.world.item.crafting.Recipe)"(arg0: Internal.FriendlyByteBuf_, arg1: Internal.Recipe_<any>): void;
        notifyAll(): void;
        toNetwork(arg0: Internal.FriendlyByteBuf_, arg1: Internal.Recipe_<any>): void;
        notify(): void;
        "fromJson(net.minecraft.resources.ResourceLocation,com.google.gson.JsonObject)"(arg0: ResourceLocation_, arg1: Internal.JsonObject_): Internal.Recipe<any>;
        toNetwork(buf: Internal.FriendlyByteBuf_, recipe: Internal.RunicAltarRecipe_): void;
        wait(arg0: number, arg1: number): void;
        "fromNetwork(net.minecraft.resources.ResourceLocation,net.minecraft.network.FriendlyByteBuf)"(id: ResourceLocation_, buf: Internal.FriendlyByteBuf_): Internal.RunicAltarRecipe;
        static register<S extends Internal.RecipeSerializer<T>, T extends Internal.Recipe<any>>($$0: string, $$1: S): S;
        hashCode(): number;
        fromJson(arg0: ResourceLocation_, arg1: Internal.JsonObject_): Internal.Recipe<any>;
        fromNetwork(id: ResourceLocation_, buf: Internal.FriendlyByteBuf_): Internal.RunicAltarRecipe;
        wait(): void;
        "fromJson(net.minecraft.resources.ResourceLocation,com.google.gson.JsonObject)"(id: ResourceLocation_, json: Internal.JsonObject_): Internal.RunicAltarRecipe;
        wait(arg0: number): void;
        fromJson(id: ResourceLocation_, json: Internal.JsonObject_): Internal.RunicAltarRecipe;
        equals(arg0: any): boolean;
        fromNetwork(arg0: ResourceLocation_, arg1: Internal.FriendlyByteBuf_): Internal.Recipe<any>;
        get class(): typeof any
    }
    type RunicAltarRecipe$Serializer_ = RunicAltarRecipe$Serializer;
    class SearchRegistry$Key <T> {
        constructor()
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
    }
    type SearchRegistry$Key_<T> = SearchRegistry$Key<T>;
    class SteelJewelryItem extends Internal.TrinketItem {
        constructor(settings: Internal.Item$Properties_)
        onTick(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        addModifierTooltip(stack: Internal.ItemStack_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_, type: Internal.ModifierHelperType_<any>): void;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        static "equipItem(net.minecraft.world.entity.LivingEntity,net.minecraft.world.item.ItemStack)"(user: Internal.LivingEntity_, stack: Internal.ItemStack_): boolean;
        appendHoverText(stack: Internal.ItemStack_, world: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        fzzy_core_correctSlot(slot: Internal.EquipmentSlot_): boolean;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        postWearerHit(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        static equipItem(user: Internal.Player_, stack: Internal.ItemStack_): boolean;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        static equipItem(user: Internal.LivingEntity_, stack: Internal.ItemStack_): boolean;
        modifierObjectPredicate(livingEntity: Internal.LivingEntity_, stack: Internal.ItemStack_): ResourceLocation;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        onBreak(stack: Internal.ItemStack_, slot: dev.emi.trinkets.api.SlotReference_, entity: Internal.LivingEntity_): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        defaultModifiers(type: Internal.ModifierHelperType_<any>): Internal.List<ResourceLocation>;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        onEquip(stack: Internal.ItemStack_, slot: dev.emi.trinkets.api.SlotReference_, entity: Internal.LivingEntity_): void;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        getDropRule(stack: Internal.ItemStack_, slot: dev.emi.trinkets.api.SlotReference_, entity: Internal.LivingEntity_): Internal.TrinketEnums$DropRule;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        fzzy_core_getCorrectSlot(): Internal.EquipmentSlot;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        getModifiers(stack: Internal.ItemStack_, slot: dev.emi.trinkets.api.SlotReference_, entity: Internal.LivingEntity_, uuid: Internal.UUID_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(world: Internal.Level_, user: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        onWearerKilledOther(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, victim: Internal.LivingEntity_, world: Internal.ServerLevel_): void;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        tick(stack: Internal.ItemStack_, slot: dev.emi.trinkets.api.SlotReference_, entity: Internal.LivingEntity_): void;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        canBeModifiedBy(type: Internal.ModifierHelperType_<any>): boolean;
        static "equipItem(net.minecraft.world.entity.player.Player,net.minecraft.world.item.ItemStack)"(user: Internal.Player_, stack: Internal.ItemStack_): boolean;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        incrementKillCount(stack: Internal.ItemStack_): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        canEquip(stack: Internal.ItemStack_, slot: dev.emi.trinkets.api.SlotReference_, entity: Internal.LivingEntity_): boolean;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canUnequip(stack: Internal.ItemStack_, slot: dev.emi.trinkets.api.SlotReference_, entity: Internal.LivingEntity_): boolean;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        onAttack(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, attacker: Internal.LivingEntity_, source: DamageSource_, amount: number): number;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        onUnequip(stack: Internal.ItemStack_, slot: dev.emi.trinkets.api.SlotReference_, entity: Internal.LivingEntity_): void;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        getKillCount(stack: Internal.ItemStack_): number;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        onWearerDamaged(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, attacker: Internal.LivingEntity_, source: DamageSource_, amount: number): number;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type SteelJewelryItem_ = SteelJewelryItem;
    interface PhasedParticleEngine {
        abstract setParticleRenderingPhase(arg0: Internal.ParticleRenderingPhase_): void;
        set particleRenderingPhase(arg0: Internal.ParticleRenderingPhase_)
        (arg0: Internal.ParticleRenderingPhase): void;
    }
    type PhasedParticleEngine_ = PhasedParticleEngine | ((arg0: Internal.ParticleRenderingPhase)=> void);
    abstract class PathNavigation {
        constructor($$0: Internal.Mob_, $$1: Internal.Level_)
        getClass(): typeof any;
        "createPath(net.minecraft.world.entity.Entity,int)"($$0: Internal.Entity_, $$1: number): net.minecraft.world.level.pathfinder.Path;
        createPath($$0: Internal.Stream_<BlockPos>, $$1: number): net.minecraft.world.level.pathfinder.Path;
        moveTo($$0: Internal.Entity_, $$1: number): boolean;
        canFloat(): boolean;
        createPath($$0: Internal.Entity_, $$1: number): net.minecraft.world.level.pathfinder.Path;
        recomputePath(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        "createPath(java.util.Set,int)"($$0: Internal.Set_<BlockPos>, $$1: number): net.minecraft.world.level.pathfinder.Path;
        createPath($$0: number, $$1: number, $$2: number, $$3: number): net.minecraft.world.level.pathfinder.Path;
        setCanFloat($$0: boolean): void;
        createPath($$0: BlockPos_, $$1: number, $$2: number): net.minecraft.world.level.pathfinder.Path;
        isInProgress(): boolean;
        getTargetPos(): BlockPos;
        isStuck(): boolean;
        getPath(): net.minecraft.world.level.pathfinder.Path;
        resetMaxVisitedNodesMultiplier(): void;
        getNodeEvaluator(): Internal.NodeEvaluator;
        moveTo($$0: number, $$1: number, $$2: number, $$3: number): boolean;
        moveTo($$0: net.minecraft.world.level.pathfinder.Path_, $$1: number): boolean;
        toString(): string;
        "createPath(java.util.stream.Stream,int)"($$0: Internal.Stream_<BlockPos>, $$1: number): net.minecraft.world.level.pathfinder.Path;
        "moveTo(net.minecraft.world.entity.Entity,double)"($$0: Internal.Entity_, $$1: number): boolean;
        notifyAll(): void;
        setSpeedModifier($$0: number): void;
        isDone(): boolean;
        shouldRecomputePath($$0: BlockPos_): boolean;
        tick(): void;
        getMaxDistanceToWaypoint(): number;
        setMaxVisitedNodesMultiplier($$0: number): void;
        hashCode(): number;
        createPath($$0: BlockPos_, $$1: number): net.minecraft.world.level.pathfinder.Path;
        wait(): void;
        stop(): void;
        wait(arg0: number): void;
        canCutCorner($$0: Internal.BlockPathTypes_): boolean;
        equals(arg0: any): boolean;
        createPath($$0: Internal.Set_<BlockPos>, $$1: number): net.minecraft.world.level.pathfinder.Path;
        "createPath(net.minecraft.core.BlockPos,int)"($$0: BlockPos_, $$1: number): net.minecraft.world.level.pathfinder.Path;
        isStableDestination($$0: BlockPos_): boolean;
        "moveTo(net.minecraft.world.level.pathfinder.Path,double)"($$0: net.minecraft.world.level.pathfinder.Path_, $$1: number): boolean;
        get class(): typeof any
        set canFloat($$0: boolean)
        get inProgress(): boolean
        get targetPos(): BlockPos
        get stuck(): boolean
        get path(): net.minecraft.world.level.pathfinder.Path
        get nodeEvaluator(): Internal.NodeEvaluator
        set speedModifier($$0: number)
        get done(): boolean
        get maxDistanceToWaypoint(): number
        set maxVisitedNodesMultiplier($$0: number)
    }
    type PathNavigation_ = PathNavigation;
    class LightLayer extends Internal.Enum<Internal.LightLayer> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        compareTo(arg0: Internal.LightLayer_): number;
        toString(): string;
        notifyAll(): void;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.LightLayer>>;
        "compareTo(net.minecraft.world.level.LightLayer)"(arg0: Internal.LightLayer_): number;
        notify(): void;
        static values(): Internal.LightLayer[];
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        name(): string;
        hashCode(): number;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        getDeclaringClass(): typeof Internal.LightLayer;
        "compareTo(java.lang.Object)"(arg0: any): number;
        static valueOf($$0: string): Internal.LightLayer;
        equals(arg0: any): boolean;
        get class(): typeof any
        get declaringClass(): typeof Internal.LightLayer
        static readonly BLOCK: (Internal.LightLayer) & (Internal.LightLayer);
        static readonly SKY: (Internal.LightLayer) & (Internal.LightLayer);
    }
    type LightLayer_ = "block" | LightLayer | "sky";
    class FireworkRocketRecipe extends Internal.CustomRecipe {
        constructor($$0: ResourceLocation_, $$1: Internal.CraftingBookCategory_)
        getClass(): typeof any;
        getGroup(): string;
        getToastSymbol(): Internal.ItemStack;
        matches($$0: Internal.CraftingContainer_, $$1: Internal.Level_): boolean;
        getSchema(): Internal.RecipeSchema;
        "matches(net.minecraft.world.inventory.CraftingContainer,net.minecraft.world.level.Level)"($$0: Internal.CraftingContainer_, $$1: Internal.Level_): boolean;
        "assemble(net.minecraft.world.Container,net.minecraft.core.RegistryAccess)"(arg0: net.minecraft.world.Container_, arg1: Internal.RegistryAccess_): Internal.ItemStack;
        notify(): void;
        getRemainingItems($$0: Internal.CraftingContainer_): Internal.NonNullList<Internal.ItemStack>;
        wait(arg0: number, arg1: number): void;
        assemble($$0: Internal.CraftingContainer_, $$1: Internal.RegistryAccess_): Internal.ItemStack;
        category(): Internal.CraftingBookCategory;
        getSerializer(): Internal.RecipeSerializer<any>;
        assemble(arg0: net.minecraft.world.Container_, arg1: Internal.RegistryAccess_): Internal.ItemStack;
        getId(): ResourceLocation;
        matches(arg0: net.minecraft.world.Container_, arg1: Internal.Level_): boolean;
        getMod(): string;
        isIn(tag: ResourceLocation_): boolean;
        getIngredients(): Internal.NonNullList<Internal.Ingredient>;
        handler$bpa000$bclib$bcl_getRemainingItems(container: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>): void;
        isSpecial(): boolean;
        hasOutput(match: Internal.ReplacementMatch_): boolean;
        getResultItem($$0: Internal.RegistryAccess_): Internal.ItemStack;
        toString(): string;
        "assemble(net.minecraft.world.inventory.CraftingContainer,net.minecraft.core.RegistryAccess)"($$0: Internal.CraftingContainer_, $$1: Internal.RegistryAccess_): Internal.ItemStack;
        notifyAll(): void;
        canCraftInDimensions($$0: number, $$1: number): boolean;
        "matches(net.minecraft.world.Container,net.minecraft.world.level.Level)"(arg0: net.minecraft.world.Container_, arg1: Internal.Level_): boolean;
        showNotification(): boolean;
        replaceInput(match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): boolean;
        getType(): ResourceLocation;
        setGroup(group: string): void;
        hashCode(): number;
        "handler$fie000$fabric-item-api-v1$captureStack"(inventory: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>, defaultedList: Internal.NonNullList_<any>, i: number): void;
        getOrCreateId(): ResourceLocation;
        hasInput(match: Internal.ReplacementMatch_): boolean;
        wait(): void;
        isIncomplete(): boolean;
        wait(arg0: number): void;
        replaceOutput(match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): boolean;
        equals(arg0: any): boolean;
        get class(): typeof any
        get group(): string
        get toastSymbol(): Internal.ItemStack
        get schema(): Internal.RecipeSchema
        get serializer(): Internal.RecipeSerializer<any>
        get id(): ResourceLocation
        get mod(): string
        get ingredients(): Internal.NonNullList<Internal.Ingredient>
        get special(): boolean
        get type(): ResourceLocation
        set group(group: string)
        get orCreateId(): ResourceLocation
        get incomplete(): boolean
    }
    type FireworkRocketRecipe_ = FireworkRocketRecipe;
    class TickTask implements Internal.Runnable {
        constructor($$0: number, $$1: Internal.Runnable_)
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        run(): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getTick(): number;
        get class(): typeof any
        get tick(): number
    }
    type TickTask_ = TickTask;
    class RandomSpreadStructurePlacement extends Internal.StructurePlacement implements Internal.StructurifyRandomSpreadStructurePlacement {
        constructor($$0: number, $$1: number, $$2: Internal.RandomSpreadType_, $$3: number)
        constructor($$0: Vec3i_, $$1: any_, $$2: number, $$3: number, $$4: Optional_<any>, $$5: number, $$6: number, $$7: Internal.RandomSpreadType_)
        getClass(): typeof any;
        structurify$getStructureSetIdentifier(): ResourceLocation;
        toString(): string;
        spacing(): number;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        spreadType(): Internal.RandomSpreadType;
        structurify$setStructureSetIdentifier(structureSetIdentifier: ResourceLocation_): void;
        structurify$getOriginalSpacing(): number;
        isStructureChunk($$0: Internal.ChunkGeneratorStructureState_, $$1: number, $$2: number): boolean;
        hashCode(): number;
        getPotentialStructureChunk($$0: number, $$1: number, $$2: number): Internal.ChunkPos;
        getLocatePos($$0: Internal.ChunkPos_): BlockPos;
        wait(): void;
        structurify$getOriginalSeparation(): number;
        wait(arg0: number): void;
        separation(): number;
        equals(arg0: any): boolean;
        type(): Internal.StructurePlacementType<any>;
        get class(): typeof any
        static readonly CODEC: Internal.Codec<Internal.RandomSpreadStructurePlacement>;
        structureSetIdentifier: ResourceLocation;
    }
    type RandomSpreadStructurePlacement_ = RandomSpreadStructurePlacement;
    class Horse extends Internal.AbstractHorse implements Internal.VariantHolder<Internal.Variant> {
        constructor($$0: Internal.EntityType_<Internal.Horse>, $$1: Internal.Level_)
        handler$hak000$gobber2$gobberOccludeVibrationSignals(cir: Internal.CallbackInfoReturnable_<any>): void;
        handler$fed001$extraalchemy$writeNbt(tag: Internal.CompoundTag_, cb: Internal.CallbackInfo_): void;
        etf$getType(): Internal.EntityType<any>;
        getUpVector($$0: number): Vec3d;
        gameEvent($$0: Internal.GameEvent_, $$1: Internal.Entity_): void;
        static checkMobSpawnRules($$0: Internal.EntityType_<Internal.Mob>, $$1: Internal.LevelAccessor_, $$2: Internal.MobSpawnType_, $$3: BlockPos_, $$4: Internal.RandomSource_): boolean;
        setDefaultMovementSpeedMultiplier(speed: number): void;
        handler$gdo000$faster_entity_animations$getEatingAnimationProgress(f: number, info: Internal.CallbackInfoReturnable_<any>): void;
        isSuppressingBounce(): boolean;
        setTarget($$0: Internal.LivingEntity_): void;
        handler$gdo000$faster_entity_animations$getAngryAnimationProgress(f: number, info: Internal.CallbackInfoReturnable_<any>): void;
        handler$han001$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        setCulled(value: boolean): void;
        handler$leb003$puzzleslib$hurt(source: DamageSource_, amount: number, callback: Internal.CallbackInfoReturnable_<any>): void;
        isOnFire(): boolean;
        getOwner(): Internal.LivingEntity;
        getPositionCodec(): Internal.VecDeltaCodec;
        setMaxUpStep($$0: number): void;
        updateFluidHeightAndDoFluidPushing($$0: Internal.TagKey_<Internal.Fluid>, $$1: number): boolean;
        convertTo<T extends Internal.Mob>($$0: Internal.EntityType_<T>, $$1: boolean): T;
        getFallFlyingTicks(): number;
        setPosition(x: number, y: number, z: number): void;
        runCommandSilent(command: string): number;
        chunkPosition(): Internal.ChunkPos;
        emf$isOnGround(): boolean;
        dropLeash($$0: boolean, $$1: boolean): void;
        gameEvent($$0: Internal.GameEvent_): void;
        setXxa($$0: number): void;
        setDelayedLeashHolderId($$0: number): void;
        isShiftKeyDown(): boolean;
        setUUID($$0: Internal.UUID_): void;
        checkBelowWorld(): void;
        handler$leb000$puzzleslib$startUsingItem(hand: Internal.InteractionHand_, callback: Internal.CallbackInfo_): void;
        setMotionZ(z: number): void;
        "deserializeNBT(net.minecraft.nbt.Tag)"(arg0: Internal.Tag_): void;
        canFreeze(): boolean;
        ignoreExplosion(): boolean;
        getBlockY(): number;
        getIsInsideStructureTracker(): Internal.IsInsideStructureTracker;
        setPlayerHitTimer(arg0: number): void;
        isSpectator(): boolean;
        setMainHandItem(item: Internal.ItemStack_): void;
        removeEffectNoUpdate($$0: Internal.MobEffect_): Internal.MobEffectInstance;
        spawnAtLocation($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        getPersistentData(): Internal.CompoundTag;
        getHealth(): number;
        getMaxHealth(): number;
        emf$isGlowing(): boolean;
        setPathfindingMalus($$0: Internal.BlockPathTypes_, $$1: number): void;
        isRegisteredToWorld(): boolean;
        getRandomZ($$0: number): number;
        pehkui_getOnGround(): boolean;
        setAggressive($$0: boolean): void;
        handler$lef000$puzzleslib$checkDespawn(callback: Internal.CallbackInfo_): void;
        getFusionModel(layerIndex: number): Internal.Triple<any, any, any>;
        setRemoved($$0: Internal.Entity$RemovalReason_): void;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>, initializer: Internal.Supplier_<A>): A;
        getDistanceSq($$0: number, $$1: number, $$2: number): number;
        isInWaterRainOrBubble(): boolean;
        getRemovalReason(): Internal.Entity$RemovalReason;
        etf$getVelocity(): Vec3d;
        handler$lcn000$puzzleslib$executeRidersJump(playerJumpPendingScale: number, travelVector: Vec3d_, callback: Internal.CallbackInfo_): void;
        hex$markHurt(): void;
        resetFallDistance(): void;
        canSprint(): boolean;
        blockPosition(): BlockPos;
        isEating(): boolean;
        setBoundingBox($$0: Internal.AABB_): void;
        isAmbientCreature(): boolean;
        setZza($$0: number): void;
        getBlock(): Internal.BlockContainerJS;
        setEquipment(slot: Internal.EquipmentSlot_, item: Internal.ItemStack_): void;
        etf$getHandItems(): Internal.Iterable<any>;
        randomTeleport($$0: number, $$1: number, $$2: number, $$3: boolean): boolean;
        getName(): net.minecraft.network.chat.Component;
        playAmbientSound(): void;
        onGround(): boolean;
        handler$leb000$puzzleslib$canBeAffected(effectInstance: Internal.MobEffectInstance_, callback: Internal.CallbackInfoReturnable_<any>): void;
        getControlledVehicle(): Internal.Entity;
        isOnSameTeam($$0: Internal.Entity_): boolean;
        getArmorValue(): number;
        tick(): void;
        localvar$lef000$puzzleslib$setTarget(entity: Internal.LivingEntity_): Internal.LivingEntity;
        getKillCredit(): Internal.LivingEntity;
        emf$isTouchingWater(): boolean;
        emf$getVariableMap(): Internal.Object2FloatOpenHashMap<any>;
        getComponentContainer(): Internal.ComponentContainer;
        hasPermissions($$0: number): boolean;
        getDynamicLightPrevZ(): number;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        pehkui_readScaleNbt(nbt: Internal.CompoundTag_): void;
        setOutOfCamera(value: boolean): void;
        static createMobAttributes(): Internal.AttributeSupplier$Builder;
        isAutoSpinAttack(): boolean;
        getRemainingFireTicks(): number;
        botania_getAmbientSound(): Internal.SoundEvent;
        onlyOpCanSetNbt(): boolean;
        tcdcommons_getCustomData(): Internal.GenericProperties<any>;
        fireImmune(): boolean;
        addMotion($$0: number, $$1: number, $$2: number): void;
        getMaxFallDistance(): number;
        isHolding($$0: Internal.Item_): boolean;
        getZ($$0: number): number;
        static areAllEffectsAmbient($$0: Internal.Collection_<Internal.MobEffectInstance>): boolean;
        doHurtTarget($$0: Internal.Entity_): boolean;
        getTicksFrozen(): number;
        wrapWithCondition$kom000$porting_lib_entity$port_lib$captureDrops(level: Internal.Level_, entity: Internal.Entity_): boolean;
        handler$lef000$puzzleslib$addAdditionalSaveData(compound: Internal.CompoundTag_, callback: Internal.CallbackInfo_): void;
        deflect(chance: number, source: Internal.Entity_): boolean;
        getRandomX($$0: number): number;
        getDynamicLightZ(): number;
        spawnAtLocation($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        pick($$0: number, $$1: number, $$2: boolean): Internal.HitResult;
        getVoicePitch(): number;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        setSleepingPos($$0: BlockPos_): void;
        changeDimension(p_20118_: Internal.ServerLevel_, teleporter: Internal.ITeleporter_): Internal.Entity;
        isDescending(): boolean;
        getAttributeBaseValue($$0: Internal.Attribute_): number;
        emf$getPitch(): number;
        sendEffectToPassengers($$0: Internal.MobEffectInstance_): void;
        getHeadRotSpeed(): number;
        getLastHurtByPlayer(): Internal.Player;
        getYHeadRot(): number;
        handler$cbi000$besmirchment$isTeammate(other: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>): void;
        localvar$leb000$puzzleslib$addEffect(oldEffectInstance: Internal.MobEffectInstance_, effectInstance: Internal.MobEffectInstance_, entity: Internal.Entity_): Internal.MobEffectInstance;
        getProjectile($$0: Internal.ItemStack_): Internal.ItemStack;
        static getAlpha(le: Internal.LivingEntity_, partialTicks: number): number;
        frameworkGetDataHolder(): com.mrcrayfish.framework.entity.sync.DataHolder;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        syncPacketPositionCodec($$0: number, $$1: number, $$2: number): void;
        setAbsorptionAmount($$0: number): void;
        setRecallData(pos: Internal.DimensionalPosition_): void;
        port_lib$spawnItemParticles(arg0: Internal.ItemStack_, arg1: number): void;
        shouldRenderAtSqrDistance($$0: number): boolean;
        getAttachedOrSet<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        damageSources(): Internal.DamageSources;
        removeAttached<A>(type: Internal.AttachmentType_<A>): A;
        removeAllGoals($$0: Internal.Predicate_<Internal.Goal>): void;
        swing(): void;
        recreateFromPacket($$0: Internal.ClientboundAddEntityPacket_): void;
        setDeltaMovement($$0: Vec3d_): void;
        getLeashOffset($$0: number): Vec3d;
        isBaby(): boolean;
        isCulled(): boolean;
        damageEquipment(slot: Internal.EquipmentSlot_): void;
        isGlowing(): boolean;
        getWalkTargetValue($$0: BlockPos_): number;
        canBreatheUnderwater(): boolean;
        getLeashedByEntities(): Internal.Set<any>;
        die($$0: DamageSource_): void;
        etf$getOptifineId(): number;
        removeAllEffects(): boolean;
        dynamicLightWorld(): Internal.Level;
        getLeashOffset(): Vec3d;
        fedFood($$0: Internal.Player_, $$1: Internal.ItemStack_): Internal.InteractionResult;
        hasLineOfSight($$0: Internal.Entity_): boolean;
        hex$getLastHurt(): number;
        onClimbable(): boolean;
        isAttackable(): boolean;
        getSaddleSoundEvent(): Internal.SoundEvent;
        getSlot($$0: number): Internal.SlotAccess;
        "deserializeNBT(net.minecraft.nbt.CompoundTag)"(nbt: Internal.CompoundTag_): void;
        emf$isInLava(): boolean;
        pehkui_constructScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        stopSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isUnderWater(): boolean;
        stopRiding(): void;
        getLeashHolder(): Internal.Entity;
        getX($$0: number): number;
        getSensing(): Internal.Sensing;
        localvar$kpc000$porting_lib_entity$port_lib$modifyMultiplier(multiplier: number): number;
        getLegsArmorItem(): Internal.ItemStack;
        getLuminance(): number;
        callUnsetRemoved(): void;
        captureDrops(value: Internal.Collection_<Internal.ItemEntity>): Internal.Collection<Internal.ItemEntity>;
        getSelfAndPassengers(): Internal.Stream<any>;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        handler$egi000$collective$LivingEntity_hurt(damageSource: DamageSource_, f: number, ci: Internal.CallbackInfoReturnable_<any>): void;
        getDeltaMovement(): Vec3d;
        canTakeItem($$0: Internal.ItemStack_): boolean;
        shouldDropExperience(): boolean;
        hasPassenger($$0: Internal.Entity_): boolean;
        be_getTravelerState(): Internal.TravelerState;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        getDynamicLightX(): number;
        setSecondsOnFire($$0: number): void;
        moveTo($$0: number, $$1: number, $$2: number): void;
        emf$getZ(): number;
        "getDisplayName()"(): net.minecraft.network.chat.Component;
        getLootTable(): ResourceLocation;
        getTicksUsingItem(): number;
        bettertrims$getWornMaterials(): Internal.List<any>;
        getArrowCount(): number;
        getMoveControl(): Internal.MoveControl;
        setMotion($$0: number, $$1: number, $$2: number): void;
        setStanding($$0: boolean): void;
        playSound($$0: Internal.SoundEvent_): void;
        handler$mjp000$supplementaries$eatSugarCube(player: Internal.Player_, stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getDefaultMovementSpeed(): number;
        handler$ikg000$lithium$tryShortcutFluidPushing(tag: Internal.TagKey_<any>, speed: number, cir: Internal.CallbackInfoReturnable_<any>, box: Internal.AABB_, x1: number, x2: number, y1: number, y2: number, z1: number, z2: number, zero: number): void;
        handler$hak000$gobber2$setFrozenTicks(frozenTicks: number, ci: Internal.CallbackInfo_): void;
        restoreFrom($$0: Internal.Entity_): void;
        method_6062(): boolean;
        isPeacefulCreature(): boolean;
        setOnGround($$0: boolean): void;
        addEffect($$0: Internal.MobEffectInstance_, $$1: Internal.Entity_): boolean;
        emf$getYaw(): number;
        ate(): void;
        setPos($$0: number, $$1: number, $$2: number): void;
        notify(): void;
        setPersistenceRequired(): void;
        getLastHurtByMobTimestamp(): number;
        getVehicle(): Internal.Entity;
        canFallInLove(): boolean;
        isEffectiveAi(): boolean;
        handler$kom000$porting_lib_entity$port_lib$startRiding(entity: Internal.Entity_, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        startRiding($$0: Internal.Entity_, $$1: boolean): boolean;
        getStringUuid(): string;
        setSwimming($$0: boolean): void;
        getMainArm(): Internal.HumanoidArm;
        checkSpawnRules($$0: Internal.LevelAccessor_, $$1: Internal.MobSpawnType_): boolean;
        getRotationVector(): Internal.Vec2;
        getHurtDir(): number;
        etf$getBlockY(): number;
        isSprinting(): boolean;
        isMaxGroupSizeReached($$0: number): boolean;
        getMotionY(): number;
        getOffhandItem(): Internal.ItemStack;
        canCollideWith($$0: Internal.Entity_): boolean;
        setLuminance(luminance: number): void;
        getBlockExplosionResistance($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.FluidState_, $$5: number): number;
        setLootTable(arg0: ResourceLocation_): void;
        clearSleepingPos(): void;
        canSpawnSprintParticle(): boolean;
        "moveTo(net.minecraft.core.BlockPos,float,float)"($$0: BlockPos_, $$1: number, $$2: number): void;
        hex$checkTotemDeathProtection(arg0: DamageSource_): boolean;
        getLastHurtMob(): Internal.LivingEntity;
        moveRelative($$0: number, $$1: Vec3d_): void;
        saveAsPassenger($$0: Internal.CompoundTag_): boolean;
        static gatherClosestChunks(chunks: Internal.LongSet_, x: number, y: number, z: number): void;
        handler$kom000$porting_lib_entity$afterSave(nbt: Internal.CompoundTag_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDamageSource(): DamageSource;
        getSoundSource(): Internal.SoundSource;
        isJumping(): boolean;
        setNoActionTime($$0: number): void;
        setMovementSpeedAddition(speed: number): void;
        removeAfterChangingDimensions(): void;
        equipmentHasChanged($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        getPose(): Internal.Pose;
        getAttribute($$0: Internal.Attribute_): Internal.AttributeInstance;
        setPositionAndRotation($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        canBeAffected($$0: Internal.MobEffectInstance_): boolean;
        ageUp($$0: number): void;
        getRestrictCenter(): BlockPos;
        isLeftHanded(): boolean;
        invokeShouldDropLoot(): boolean;
        handler$kpc000$porting_lib_entity$port_lib$onFinishUsing(ci: Internal.CallbackInfo_, hand: Internal.InteractionHand_, result: Internal.ItemStack_): void;
        etf$getUuid(): Internal.UUID;
        removeVehicle(): void;
        shouldFusionRecomputeModel(layerIndex: number): boolean;
        modifyExpressionValue$zcl000$porting_lib_base$port_lib$canContinueUsing(original: boolean): boolean;
        setZ(z: number): void;
        getY(): number;
        deserializeNBT(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        finalizeSpawnChildFromBreeding($$0: Internal.ServerLevel_, $$1: Internal.Animal_, $$2: Internal.AgeableMob_): void;
        eat($$0: Internal.Level_, $$1: Internal.ItemStack_): Internal.ItemStack;
        setIsJumping($$0: boolean): void;
        bookshelf$makePoofParticles(): void;
        isWithinMeleeAttackRange($$0: Internal.LivingEntity_): boolean;
        setCurrentModifyFoodPowers(powers: Internal.List_<any>): void;
        broadcastBreakEvent($$0: Internal.EquipmentSlot_): void;
        modifyExpressionValue$zhf000$additionalentityattributes$additionalEntityAttributes$modifyUpwardSwimming(original: number, fluid: Internal.TagKey_<any>): number;
        handler$nbm000$things$onShieldBlock(source: DamageSource_, cir: Internal.CallbackInfoReturnable_<any>): void;
        showVehicleHealth(): boolean;
        getDistance(pos: BlockPos_): number;
        isBlocking(): boolean;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number): void;
        removeAttribute(attribute: Internal.Attribute_, identifier: string): void;
        emf$getVelocity(): Vec3d;
        handler$lef000$puzzleslib$finalizeSpawn(level: Internal.ServerLevelAccessor_, difficulty: Internal.DifficultyInstance_, reason: Internal.MobSpawnType_, spawnData: Internal.SpawnGroupData_, dataTag: Internal.CompoundTag_, callback: Internal.CallbackInfoReturnable_<any>): void;
        etf$isBlockEntity(): boolean;
        shouldUpdateDynamicLight(): boolean;
        isPushedByFluid(): boolean;
        setOriginalFoodStack(original: Internal.ItemStack_): void;
        getArmorCoverPercentage(): number;
        handleRelativeFrictionAndCalculateMovement($$0: Vec3d_, $$1: number): Vec3d;
        turn($$0: number, $$1: number): void;
        getAirSupply(): number;
        getVariant(): Internal.Variant;
        moveTo($$0: BlockPos_, $$1: number, $$2: number): void;
        isPlayer(): boolean;
        isAnimal(): boolean;
        "handler$fgd000$fabric-dimensions-v1$getTeleportTarget"(destination: Internal.ServerLevel_, cir: Internal.CallbackInfoReturnable_<any>): void;
        canBeCollidedWith(): boolean;
        getMotionDirection(): Internal.Direction;
        asComponentProvider(): Internal.ComponentProvider;
        lavaHurt(): void;
        handleDamageEvent($$0: DamageSource_): void;
        getFabricBalmData(): Internal.CompoundTag;
        canChangeDimensions(): boolean;
        static tickEntity(entity: Internal.Entity_): void;
        getCommandSenderWorld(): Internal.Level;
        getTotalMovementSpeed(): number;
        changeDimension($$0: Internal.ServerLevel_): Internal.Entity;
        localvar$zno000$apoli$modifyFallingVelocity(in_: number): number;
        handler$kom000$porting_lib_entity$afterLoad(nbt: Internal.CompoundTag_, ci: Internal.CallbackInfo_): void;
        pehkui_shouldIgnoreScaleNbt(): boolean;
        isMoving(): boolean;
        attack(hp: number): void;
        getAttributes(): Internal.AttributeMap;
        "hasPassenger(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.Entity>): boolean;
        botania_playHurtSound(arg0: DamageSource_): void;
        getDimensions($$0: Internal.Pose_): Internal.EntityDimensions;
        spawnChildFromBreeding($$0: Internal.ServerLevel_, $$1: Internal.Animal_): void;
        setInLoveTime($$0: number): void;
        invokeGetLeashOffset(): Vec3d;
        isSwimming(): boolean;
        setSprinting($$0: boolean): void;
        mayInteract($$0: Internal.Level_, $$1: BlockPos_): boolean;
        handler$kpc000$porting_lib_entity$port_lib$attackEvent(source: DamageSource_, amount: number, cir: Internal.CallbackInfoReturnable_<any>): void;
        getDynamicLightLevel(): Internal.Level;
        setPortalCooldown(): void;
        getAttackAnim($$0: number): number;
        hex$setLastHurt(arg0: number): void;
        setX(x: number): void;
        getPortalWaitTime(): number;
        getBlockStateOn(): Internal.BlockState;
        wantsToPickUp($$0: Internal.ItemStack_): boolean;
        getItemBySlot($$0: Internal.EquipmentSlot_): Internal.ItemStack;
        getFluidHeightLoosely(tag: Internal.TagKey_<any>): number;
        setOwnerUUID($$0: Internal.UUID_): void;
        getFluidJumpThreshold(): number;
        getCachedSouls(): number;
        "getVariant()"(): any;
        "setPositionAndRotation(double,double,double,float,float)"(x: number, y: number, z: number, yaw: number, pitch: number): void;
        isInvisibleTo($$0: Internal.Player_): boolean;
        stopSleeping(): void;
        setAirSupply($$0: number): void;
        getOnPos(): BlockPos;
        etf$getWorld(): Internal.Level;
        isUndead(): boolean;
        static createBaseHorseAttributes(): Internal.AttributeSupplier$Builder;
        static createLivingAttributes(): Internal.AttributeSupplier$Builder;
        setUseItemRemaining(arg0: number): void;
        pehkui_getScales(): Internal.Map<any, any>;
        getTargetSelector(): Internal.GoalSelector;
        setRegisteredToWorld(navigation: Internal.PathNavigation_): void;
        isSleeping(): boolean;
        stopUsingItem(): void;
        etf$getNbt(): Internal.CompoundTag;
        acceptsFailure(): boolean;
        etf$getBlockPos(): BlockPos;
        pehkui_setShouldIgnoreScaleNbt(ignore: boolean): void;
        setOnGroundWithKnownMovement($$0: boolean, $$1: Vec3d_): void;
        getFluidFallingAdjustedMovement($$0: number, $$1: boolean, $$2: Vec3d_): Vec3d;
        setOldPosAndRot(): void;
        localvar$cjk000$bettertridents$doHurtTarget$modifyVariable$store(damageAmount: number, entity: Internal.Entity_): number;
        isFree($$0: number, $$1: number, $$2: number): boolean;
        getDismountPoses(): Internal.ImmutableList<Internal.Pose>;
        getLastHurtMobTimestamp(): number;
        lithiumOnEquipmentChanged(): void;
        "moveTo(double,double,double)"($$0: number, $$1: number, $$2: number): void;
        setRemainingFireTicks($$0: number): void;
        emf$age(): number;
        etf$hasCustomName(): boolean;
        /**
         * @deprecated
        */
        getOnPosLegacy(): BlockPos;
        port_lib$isJumping(): boolean;
        setPos($$0: Vec3d_): void;
        localvar$leb000$puzzleslib$knockback$2(ratioX: number): number;
        static "tickEntity(net.minecraft.world.entity.LivingEntity)"(entity: Internal.LivingEntity_): void;
        updateCachedSouls(): void;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        setCanPickUpLoot($$0: boolean): void;
        getMainHandItem(): Internal.ItemStack;
        canEatGrass(): boolean;
        handler$kom000$porting_lib_entity$port_lib$removeRidingEntity(ci: Internal.CallbackInfo_): void;
        setSilent($$0: boolean): void;
        openCustomInventoryScreen($$0: Internal.Player_): void;
        captureDrops(): Internal.Collection<Internal.ItemEntity>;
        hasExactlyOnePlayerPassenger(): boolean;
        canBeSeenAsEnemy(): boolean;
        setLeftHanded($$0: boolean): void;
        getActiveEffects(): Internal.Collection<Internal.MobEffectInstance>;
        isOnPortalCooldown(): boolean;
        hurtArmor($$0: DamageSource_, $$1: number): void;
        canAttack($$0: Internal.LivingEntity_, $$1: Internal.TargetingConditions_): boolean;
        getAttributeValue($$0: Internal.Holder_<Internal.Attribute>): number;
        lambdynlights$setTrackedLitChunkPos(trackedLitChunkPos: Internal.LongSet_): void;
        fzzy_core_setModifierContainer(container: Internal.ModifierContainer_): void;
        setPitch($$0: number): void;
        setPosRaw($$0: number, $$1: number, $$2: number): void;
        handleEntityEvent($$0: number): void;
        isUsingItem(): boolean;
        isAlwaysTicking(): boolean;
        interactAt($$0: Internal.Player_, $$1: Vec3d_, $$2: Internal.InteractionHand_): Internal.InteractionResult;
        emf$getX(): number;
        puzzleslib$acceptCapturedDrops(capturedDrops: Internal.Collection_<any>): Internal.Collection<any>;
        handler$hak000$gobber2$gobberIsFireImmune(cir: Internal.CallbackInfoReturnable_<any>): void;
        onPlayerJump($$0: number): void;
        lerpTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: boolean): void;
        onPassengerTurned($$0: Internal.Entity_): void;
        modifyReturnValue$zhe000$additionalentityattributes$getMaxAir(original: number): number;
        spawnAtLocation($$0: Internal.ItemLike_): Internal.ItemEntity;
        emf$hasPassengers(): boolean;
        serializeNBT(): Internal.CompoundTag;
        setAttached(type: Internal.AttachmentType_<any>, value: any): any;
        port_lib$getEntityString(): string;
        markEffectsDirty(): void;
        lithiumOnBlockCacheDeleted(): void;
        "spawnAtLocation(net.minecraft.world.level.ItemLike,int)"($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        setInvulnerable($$0: boolean): void;
        push($$0: Internal.Entity_): void;
        emf$hasVehicle(): boolean;
        canMate($$0: Internal.Animal_): boolean;
        method_5992($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        maxUpStep(): number;
        getDynamicLightPrevY(): number;
        localvar$leb000$puzzleslib$hurt$1(amount: number, source: DamageSource_): number;
        setGlowing($$0: boolean): void;
        load($$0: Internal.CompoundTag_): void;
        "broadcastBreakEvent(net.minecraft.world.entity.EquipmentSlot)"($$0: Internal.EquipmentSlot_): void;
        setLeashedTo($$0: Internal.Entity_, $$1: boolean): void;
        isAlive(): boolean;
        startSleeping($$0: BlockPos_): void;
        getBbHeight(): number;
        getMeleeAttackRangeSqr($$0: Internal.LivingEntity_): number;
        handler$fed002$extraalchemy$readNbt(tag: Internal.CompoundTag_, cb: Internal.CallbackInfo_): void;
        bookshelf$getDrinkingSound(arg0: Internal.ItemStack_): Internal.SoundEvent;
        getTags(): Internal.Set<string>;
        getViewVector($$0: number): Vec3d;
        getLastAttacker(): Internal.LivingEntity;
        hasControllingPassenger(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number, $$2: number): boolean;
        absMoveTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        getLastRollTicks(): number;
        getGoalSelector(): Internal.GoalSelector;
        localvar$leb000$puzzleslib$causeFallDamage$2(damageMultiplier: number): number;
        onPathfindingStart(): void;
        handler$zzb000$porting_lib_attributes$port_lib$entityGravity(travelVector: Vec3d_, ci: Internal.CallbackInfo_): void;
        getPercentFrozen(): number;
        setPortalCooldown($$0: number): void;
        hasGlowingTag(): boolean;
        shouldBlockExplode($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: number): boolean;
        emf$isInvisible(): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        isLeashed(): boolean;
        addEffect($$0: Internal.MobEffectInstance_): boolean;
        emf$isSprinting(): boolean;
        handler$leb000$puzzleslib$knockback$0(strength: number, ratioX: number, ratioZ: number, callback: Internal.CallbackInfo_): void;
        getVariant(): any;
        ageUp($$0: number, $$1: boolean): void;
        handler$egi000$collective$LivingEntity_tick(ci: Internal.CallbackInfo_): void;
        handler$gec000$faster_entity_animations$getLeaningPitch(f: number, info: Internal.CallbackInfoReturnable_<any>): void;
        canRiderInteract(): boolean;
        getViewXRot($$0: number): number;
        handler$leb001$puzzleslib$die(damageSource: DamageSource_, callback: Internal.CallbackInfo_): void;
        fabric_getAttachments(): Internal.Map<any, any>;
        setPose($$0: Internal.Pose_): void;
        getReachDistance(): number;
        getEntityType(): Internal.EntityType<any>;
        isWaterCreature(): boolean;
        hex$playHurtSound(arg0: DamageSource_): void;
        pehkui_getScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        toString(): string;
        canWearArmor(): boolean;
        etf$getScoreboardTeam(): Internal.Team;
        getBreedOffspring($$0: Internal.ServerLevel_, $$1: Internal.AgeableMob_): Internal.AgeableMob;
        setLastHurtByPlayer($$0: Internal.Player_): void;
        handler$ldh000$puzzleslib$removeVehicle(callback: Internal.CallbackInfo_): void;
        "getServer()"(): Internal.MinecraftServer;
        getAmbientStandSound(): Internal.SoundEvent;
        wasExperienceConsumed(): boolean;
        isPushable(): boolean;
        setYBodyRot($$0: number): void;
        foodEaten(is: Internal.ItemStack_): void;
        onClientRemoval(): void;
        getDistance(x: number, y: number, z: number): number;
        setMotionY(y: number): void;
        localvar$lcp000$puzzleslib$spawnChildFromBreeding(child: Internal.AgeableMob_, serverLevel: Internal.ServerLevel_, partner: Internal.Animal_): Internal.AgeableMob;
        getAttached(type: Internal.AttachmentType_<any>): any;
        setRotation(yaw: number, pitch: number): void;
        isDynamicLightEnabled(): boolean;
        handler$ldh000$puzzleslib$startRiding(vehicle: Internal.Entity_, force: boolean, callback: Internal.CallbackInfoReturnable_<any>): void;
        calculateEntityAnimation($$0: boolean): void;
        forceAddEffect($$0: Internal.MobEffectInstance_, $$1: Internal.Entity_): void;
        setBred($$0: boolean): void;
        setChestArmorItem(item: Internal.ItemStack_): void;
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        bookshelf$getHurtSound(arg0: DamageSource_): Internal.SoundEvent;
        onAboveBubbleCol($$0: boolean): void;
        archon$setOwner(uiud: string): void;
        "playSound(net.minecraft.sounds.SoundEvent,float,float)"(id: Internal.SoundEvent_, volume: number, pitch: number): void;
        toComponentPacket(key: Internal.ComponentKey_<any>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        isPassenger(): boolean;
        hasPose($$0: Internal.Pose_): boolean;
        supp$setSlimedTicks(newSlimedTicks: number, sync: boolean): void;
        isEyeInFluid($$0: Internal.TagKey_<Internal.Fluid>): boolean;
        isInvulnerableTo($$0: DamageSource_): boolean;
        makeStuckInBlock($$0: Internal.BlockState_, $$1: Vec3d_): void;
        getAttachedOrGet<A>(type: Internal.AttachmentType_<A>, defaultValue: Internal.Supplier_<A>): A;
        isSensitiveToWater(): boolean;
        skipAttackInteraction($$0: Internal.Entity_): boolean;
        lerpMotion($$0: number, $$1: number, $$2: number): void;
        "getAttributeValue(net.minecraft.core.Holder)"($$0: Internal.Holder_<Internal.Attribute>): number;
        shouldRender($$0: number, $$1: number, $$2: number): boolean;
        getJumpControl(): Internal.JumpControl;
        localvar$zcl000$porting_lib_base$port_lib$setSlipperiness(p: number): number;
        getFeetArmorItem(): Internal.ItemStack;
        isSaddleable(): boolean;
        handler$bia000$axiom$onTurn(d: number, e: number, ci: Internal.CallbackInfo_): void;
        static getViewScale(): number;
        handler$mpg000$tcdcommons$onAddStatusEffect(effect: Internal.MobEffectInstance_, source: Internal.Entity_, ci: Internal.CallbackInfoReturnable_<any>): void;
        getVisualRotationYInDegrees(): number;
        setSpeed($$0: number): void;
        requiresCustomPersistence(): boolean;
        handler$nbm000$things$onShieldHit(attacker: Internal.LivingEntity_, ci: Internal.CallbackInfo_): void;
        isDiscrete(): boolean;
        unRide(): void;
        getLevel(): Internal.Level;
        "spawnAtLocation(net.minecraft.world.item.ItemStack)"($$0: Internal.ItemStack_): Internal.ItemEntity;
        getCombatTracker(): Internal.CombatTracker;
        getCustomJump(): number;
        updateDynamicGameEventListener($$0: Internal.BiConsumer_<Internal.DynamicGameEventListener<any>, Internal.ServerLevel>): void;
        canBreed(): boolean;
        "onSyncedDataUpdated(net.minecraft.network.syncher.EntityDataAccessor)"($$0: Internal.EntityDataAccessor_<any>): void;
        emf$prevY(): number;
        isNoAi(): boolean;
        extinguishFire(): void;
        getChestArmorItem(): Internal.ItemStack;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number): void;
        port_lib$lastPos(): BlockPos;
        tell(message: net.minecraft.network.chat.Component_): void;
        closerThan($$0: Internal.Entity_, $$1: number): boolean;
        hex$getSoundVolume(): number;
        getDistanceSq(pos: BlockPos_): number;
        indicateDamage($$0: number, $$1: number): void;
        localvar$nbm000$things$waxGlandWater(j: number): number;
        canBeSeenByAnyone(): boolean;
        emf$getTypeString(): string;
        setVariant(arg0: any): void;
        isFullyFrozen(): boolean;
        litematica_setWorld(arg0: Internal.Level_): void;
        isInWall(): boolean;
        getAllSlots(): Internal.Iterable<Internal.ItemStack>;
        getInventory(): Internal.SimpleContainer;
        handler$bfg003$artifacts$tick(ci: Internal.CallbackInfo_): void;
        remove($$0: Internal.Entity$RemovalReason_): void;
        getScale(): number;
        isSuppressingSlidingDownLadder(): boolean;
        getBlockZ(): number;
        handler$egi000$collective$LivingEntity_die(damageSource: DamageSource_, ci: Internal.CallbackInfo_): void;
        dampensVibrations(): boolean;
        hasAttached(type: Internal.AttachmentType_<any>): boolean;
        isSilent(): boolean;
        setUseItem(arg0: Internal.ItemStack_): void;
        "playSound(net.minecraft.sounds.SoundEvent)"($$0: Internal.SoundEvent_): void;
        getPitch(): number;
        getPathfindingMalus($$0: Internal.BlockPathTypes_): number;
        modify$nbm000$things$waxGlandLava(speed: number): number;
        getRandom(): Internal.RandomSource;
        canReplaceEqualItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        rotate($$0: Internal.Rotation_): number;
        handler$hcn000$hexcasting$onThunderHit(entityType: Internal.EntityType_<any>, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        getPassengersAndSelf(): Internal.Stream<any>;
        handler$leb000$puzzleslib$causeFallDamage$0(distance: number, damageMultiplier: number, damageSource: DamageSource_, callback: Internal.CallbackInfoReturnable_<any>): void;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        "getAttributeBaseValue(net.minecraft.core.Holder)"($$0: Internal.Holder_<Internal.Attribute>): number;
        getMaxTemper(): number;
        method_5652($$0: Internal.CompoundTag_): void;
        clearRestriction(): void;
        redirect$jgg000$moonlight$fixSpawnAnimX(instance: Internal.Mob_, v: number): number;
        getOriginalFoodStack(): Internal.ItemStack;
        getAge(): number;
        rayTrace(): Internal.RayTraceResultJS;
        alwaysAccepts(): boolean;
        "isHolding(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.ItemStack>): boolean;
        getNoActionTime(): number;
        isVisuallyCrawling(): boolean;
        isAggressive(): boolean;
        isWearingArmor(): boolean;
        setYya($$0: number): void;
        setDropChance($$0: Internal.EquipmentSlot_, $$1: number): void;
        handler$ieb000$lambdynlights$onRemove(ci: Internal.CallbackInfo_): void;
        "broadcastBreakEvent(net.minecraft.world.InteractionHand)"($$0: Internal.InteractionHand_): void;
        port_lib$setRemovalReason(arg0: Internal.Entity$RemovalReason_): void;
        teleportRelative($$0: number, $$1: number, $$2: number): void;
        isFood($$0: Internal.ItemStack_): boolean;
        setBaby($$0: boolean): void;
        getTemper(): number;
        getLastHurtByMob(): Internal.LivingEntity;
        pehkui_setScaleCache(scaleCache: Internal.ScaleData_[]): void;
        isInWaterOrBubble(): boolean;
        botania_setLoveCause(arg0: Internal.UUID_): void;
        tameWithName($$0: Internal.Player_): boolean;
        getPortalCooldown(): number;
        getItem(): Internal.ItemStack;
        causeFallDamage($$0: number, $$1: number, $$2: DamageSource_): boolean;
        getDynamicLightChunksToRebuild(forced: boolean): Internal.LongSet;
        getFlag($$0: number): boolean;
        releaseUsingItem(): void;
        bw_getNextAirOnLand(arg0: number): number;
        getPosition($$0: number): Vec3d;
        removeFreeWill(): void;
        handler$leb000$puzzleslib$removeAllEffects(callback: Internal.CallbackInfoReturnable_<any>): void;
        removeWhenFarAway($$0: number): boolean;
        wait(arg0: number): void;
        isIgnoringBlockTriggers(): boolean;
        setRecordPlayingNearby($$0: BlockPos_, $$1: boolean): void;
        etf$getItemsEquipped(): Internal.Iterable<any>;
        getHandHoldingItemAngle($$0: Internal.Item_): Vec3d;
        hasItemInSlot($$0: Internal.EquipmentSlot_): boolean;
        distanceToSqr($$0: Vec3d_): number;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        modifyAttached<A>(type: Internal.AttachmentType_<A>, modifier: Internal.UnaryOperator_<A>): A;
        isSteppingCarefully(): boolean;
        handler$zno000$apoli$doSpiderClimbing(info: Internal.CallbackInfoReturnable_<any>): void;
        "spawnAtLocation(net.minecraft.world.item.ItemStack,float)"($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        getBlockX(): number;
        /**
         * @deprecated
        */
        getLightLevelDependentMagicValue(): number;
        isFallFlying(): boolean;
        getEncodeId(): string;
        puzzleslib$getSpawnType(): Internal.MobSpawnType;
        makeMad(): void;
        bettertrims$setAvoidedDamage(avoidDamage: boolean): void;
        getY($$0: number): number;
        emf$prevPitch(): number;
        getMaxHeadXRot(): number;
        getNbt(): Internal.CompoundTag;
        setInvisible($$0: boolean): void;
        etf$getArmorItems(): Internal.Iterable<any>;
        isSaddled(): boolean;
        isSubmergedInLoosely(tag: Internal.TagKey_<any>): boolean;
        getEffect($$0: Internal.MobEffect_): Internal.MobEffectInstance;
        setTotalMovementSpeedMultiplier(speed: number): void;
        getDynamicLightY(): number;
        setHealth($$0: number): void;
        attack($$0: DamageSource_, $$1: number): boolean;
        onInsideBubbleColumn($$0: boolean): void;
        handler$cfa000$betterend$be_hurt(source: DamageSource_, amount: number, info: Internal.CallbackInfoReturnable_<any>): void;
        getAmbientStandInterval(): number;
        getEyePosition(): Vec3d;
        getEyeHeight(): number;
        setDiscardFriction($$0: boolean): void;
        hasPassenger($$0: Internal.Predicate_<Internal.Entity>): boolean;
        bettertridents$getLastDamageSource(): DamageSource;
        getYaw(): number;
        swing($$0: Internal.InteractionHand_, $$1: boolean): void;
        getUsedItemHand(): Internal.InteractionHand;
        setDefaultMovementSpeed(speed: number): void;
        canAttackType($$0: Internal.EntityType_<any>): boolean;
        hex$setLastDamageStamp(arg0: number): void;
        canEntityBeSeen(entity: Internal.LivingEntity_): boolean;
        modifyExpressionValue$zhf000$additionalentityattributes$additionalEntityAttributes$knockDownwards(original: number): number;
        getBrain(): Internal.Brain<any>;
        modify$bpk000$bclib$be_travel(moveDelta: Vec3d_): Vec3d;
        setCustomNameVisible($$0: boolean): void;
        isAlliedTo($$0: Internal.Team_): boolean;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>): A;
        getControllingPassenger(): Internal.LivingEntity;
        canFireProjectileWeapon($$0: Internal.ProjectileWeaponItem_): boolean;
        bw_getNextAirUnderwater(arg0: number): number;
        getScriptType(): Internal.ScriptType;
        handler$leb000$puzzleslib$releaseUsingItem(callback: Internal.CallbackInfo_): void;
        equipSaddle($$0: Internal.SoundSource_): void;
        handler$cbm000$besmirchment$handleStatus(status: number, ci: Internal.CallbackInfo_): void;
        port_lib$getDeathSound(): Internal.SoundEvent;
        shouldDiscardFriction(): boolean;
        startRiding($$0: Internal.Entity_): boolean;
        saveWithoutId($$0: Internal.CompoundTag_): Internal.CompoundTag;
        getForward(): Vec3d;
        setFeetArmorItem(item: Internal.ItemStack_): void;
        getId(): number;
        pehkui_isFirstUpdate(): boolean;
        canBeHitByProjectile(): boolean;
        getRecipientsForComponentSync(): Internal.Iterable<any>;
        handler$zcl000$porting_lib_base$port_lib$onUsingTick(ci: Internal.CallbackInfo_): void;
        getEyeY(): number;
        handler$ham000$gobber2$gobberClimbing(cir: Internal.CallbackInfoReturnable_<any>): void;
        skipDropExperience(): void;
        fabric_readAttachmentsFromNbt(nbt: Internal.CompoundTag_): void;
        localvar$leb000$puzzleslib$getVisibilityPercent(value: number, lookingEntity: Internal.Entity_): number;
        getBoundingBox(): Internal.AABB;
        isInWaterOrRain(): boolean;
        getStandAnim($$0: number): number;
        handler$leb000$puzzleslib$die$1(damageSource: DamageSource_, callback: Internal.CallbackInfo_): void;
        setItemSlot($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_): void;
        "getVariant()"(): Internal.Variant;
        equals($$0: any): boolean;
        getViewYRot($$0: number): number;
        fabric_setCustomTeleportTarget(teleportTarget: Internal.PortalInfo_): void;
        dismountsUnderwater(): boolean;
        isAffectedByPotions(): boolean;
        playerTouch($$0: Internal.Player_): void;
        addTag($$0: string): boolean;
        getEyeHeight($$0: Internal.Pose_): number;
        getAddEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>;
        callIsBeingRainedOn(): boolean;
        static getEquipmentForSlot($$0: Internal.EquipmentSlot_, $$1: number): Internal.Item;
        isWithinRestriction($$0: BlockPos_): boolean;
        getTeam(): Internal.Team;
        handler$mjp000$supplementaries$addSugarCube(ci: Internal.CallbackInfo_): void;
        static of(entity: Internal.LivingEntity_): Internal.EntityProperties;
        setTicksFrozen($$0: number): void;
        isArmor($$0: Internal.ItemStack_): boolean;
        getUseItem(): Internal.ItemStack;
        getMyRidingOffset(): number;
        handler$hal000$gobber2$gobberCanBreatheInWater(cir: Internal.CallbackInfoReturnable_<any>): void;
        dismountTo($$0: number, $$1: number, $$2: number): void;
        etf$getEntityKey(): string;
        etf$getPose(): Internal.Pose;
        hasCustomName(): boolean;
        getSwimAmount($$0: number): number;
        isLiving(): boolean;
        getX(): number;
        isVehicle(): boolean;
        static transfer(original: Internal.AttachmentTarget_, target: Internal.AttachmentTarget_, isDeath: boolean): void;
        bettertrims$didAvoidDamage(): boolean;
        resetDynamicLight(): void;
        setTemper($$0: number): void;
        handler$han000$gobber2$gobberSetTarget(target: Internal.LivingEntity_, ci: Internal.CallbackInfo_): void;
        handler$kpc001$porting_lib_entity$onJump(ci: Internal.CallbackInfo_): void;
        spawnAtLocation($$0: Internal.ItemStack_): Internal.ItemEntity;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        handler$zcl000$porting_lib_base$port_lib$canBeAffected(effect: Internal.MobEffectInstance_, cir: Internal.CallbackInfoReturnable_<any>): void;
        thunderHit($$0: Internal.ServerLevel_, $$1: Internal.LightningBolt_): void;
        setIsInPowderSnow($$0: boolean): void;
        etf$distanceTo(entity: Internal.Entity_): number;
        doEnchantDamageEffects($$0: Internal.LivingEntity_, $$1: Internal.Entity_): void;
        setCustomName($$0: net.minecraft.network.chat.Component_): void;
        lambdynlights$scheduleTrackedChunksRebuild(renderer: Internal.LevelRenderer_): void;
        handler$hak000$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        getTeamId(): string;
        setStingerCount($$0: number): void;
        getMaxHeadYRot(): number;
        getArmor(): Internal.ItemStack;
        isCustomNameVisible(): boolean;
        isSupportedBy($$0: BlockPos_): boolean;
        getPistonPushReaction(): Internal.PushReaction;
        lookAt($$0: Internal.EntityAnchorArgument$Anchor_, $$1: Vec3d_): void;
        handler$kpc000$porting_lib_entity$port_lib$cancelFall(fallDistance: number, multiplier: number, source: DamageSource_, cir: Internal.CallbackInfoReturnable_<any>): void;
        hurtCurrentlyUsedShield($$0: number): void;
        getLootTableSeed(): number;
        collide($$0: Vec3d_): Vec3d;
        getMotionX(): number;
        "onSyncedDataUpdated(java.util.List)"($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        canBeLeashed($$0: Internal.Player_): boolean;
        hasIndirectPassenger($$0: Internal.Entity_): boolean;
        gear_core_setActiveSets(sets: Internal.HashMap_<any, any>): void;
        getEntityData(): Internal.SynchedEntityData;
        bookshelf$getFallDamageSound(arg0: number): Internal.SoundEvent;
        handleInsidePortal($$0: BlockPos_): void;
        getPotionEffects(): Internal.EntityPotionEffectsJS;
        getLastHurtByPlayerTime(): number;
        absMoveTo($$0: number, $$1: number, $$2: number): void;
        handler$cfa000$betterend$be_canBeAffected(mobEffectInstance: Internal.MobEffectInstance_, info: Internal.CallbackInfoReturnable_<any>): void;
        isOnRails(): boolean;
        getAttachedOrThrow<A>(type: Internal.AttachmentType_<A>): A;
        handler$efj000$collective$AbstractHorse_travel(player: Internal.Player_, vec3: Vec3d_, ci: Internal.CallbackInfo_): void;
        getStingerCount(): number;
        markFusionRecomputeModels(): void;
        getFallSounds(): Internal.LivingEntity$Fallsounds;
        getAttributeTotalValue(attribute: Internal.Attribute_): number;
        getDimensionChangingDelay(): number;
        handler$cbi000$besmirchment$getScoreboardTeam(cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDynamicLuminance(): number;
        setYaw($$0: number): void;
        getPickRadius(): number;
        isPathFinding(): boolean;
        getMarkings(): Internal.Markings;
        supp$getSlimedTicks(): number;
        isRemoved(): boolean;
        handleStopJump(): void;
        getEatAnim($$0: number): number;
        emf$isSneaking(): boolean;
        teleportToWithTicket($$0: number, $$1: number, $$2: number): void;
        spawnAnim(): void;
        getJumpBoostPower(): number;
        fillCrashReportCategory($$0: Internal.CrashReportCategory_): void;
        self(): Internal.Entity;
        refreshDimensions(): void;
        pehkui_writeScaleNbt(nbt: Internal.CompoundTag_): Internal.CompoundTag;
        bookshelf$getAmbientSound(): Internal.SoundEvent;
        "spawnAtLocation(net.minecraft.world.level.ItemLike)"($$0: Internal.ItemLike_): Internal.ItemEntity;
        "getAttributeValue(net.minecraft.world.entity.ai.attributes.Attribute)"($$0: Internal.Attribute_): number;
        "isHolding(net.minecraft.world.item.Item)"($$0: Internal.Item_): boolean;
        setShiftKeyDown($$0: boolean): void;
        getEyePosition($$0: number): Vec3d;
        getPassengers(): Internal.EntityArrayList;
        standIfPossible(): void;
        handler$ldh000$puzzleslib$spawnAtLocation(stack: Internal.ItemStack_, offsetY: number, callback: Internal.CallbackInfoReturnable_<any>, itemEntity: Internal.ItemEntity_): void;
        getZ(): number;
        bettertrims$applyCelestialToAttackCooldown(original: number): number;
        teleportTo($$0: number, $$1: number, $$2: number): void;
        handler$zbk000$porting_lib_base$port_lib$spawnSprintParticle(ci: Internal.CallbackInfo_, pos: BlockPos_, state: Internal.BlockState_): void;
        getAttributeBaseValue($$0: Internal.Holder_<Internal.Attribute>): number;
        getServer(): Internal.MinecraftServer;
        getExperienceReward(): number;
        getFirstPassenger(): Internal.Entity;
        heal($$0: number): void;
        handler$leb01a$puzzleslib$tick(callback: Internal.CallbackInfo_): void;
        setLastHurtMob($$0: Internal.Entity_): void;
        setLastHurtByMob($$0: Internal.LivingEntity_): void;
        interact($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        getDismountLocationForPassenger($$0: Internal.LivingEntity_): Vec3d;
        checkSlowFallDistance(): void;
        getLeashingEntities(): Internal.Set<any>;
        level(): Internal.EntityGetter;
        canStandOnFluid($$0: Internal.FluidState_): boolean;
        setFabricBalmData(tag: Internal.CompoundTag_): void;
        touchingUnloadedChunk(): boolean;
        modifyAttribute(attribute: Internal.Attribute_, identifier: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getLookAngle(): Vec3d;
        modifyReturnValue$zhf000$additionalentityattributes$additionalEntityAttributes$modifyJumpVelocity(original: number): number;
        getAmbientSoundInterval(): number;
        emf$isOnFire(): boolean;
        setArrowCount($$0: number): void;
        getMotionZ(): number;
        isPersistenceRequired(): boolean;
        isInvisible(): boolean;
        is($$0: Internal.Entity_): boolean;
        isTamed(): boolean;
        getBedOrientation(): Internal.Direction;
        ejectPassengers(): void;
        removeEffect($$0: Internal.MobEffect_): boolean;
        updateDynamicLightPreviousCoordinates(): void;
        getProfile(): Internal.GameProfile;
        setInLove($$0: Internal.Player_): void;
        isDeadOrDying(): boolean;
        setHeadArmorItem(item: Internal.ItemStack_): void;
        static setViewScale($$0: number): void;
        emf$isAlive(): boolean;
        take($$0: Internal.Entity_, $$1: number): void;
        setLevelCallback($$0: Internal.EntityInLevelCallback_): void;
        getLookControl(): Internal.LookControl;
        handler$gdo000$faster_entity_animations$getEatingGrassAnimationProgress(f: number, info: Internal.CallbackInfoReturnable_<any>): void;
        isBred(): boolean;
        redirect$joh000$origins$method_26317Proxy(entity: Internal.LivingEntity_, d: number, bl: boolean, vec3d: Vec3d_): Vec3d;
        playSound($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        canAttack($$0: Internal.LivingEntity_): boolean;
        static getSpeedUpSecondsWhenFeeding($$0: number): number;
        getOffHandItem(): Internal.ItemStack;
        startSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isOnScoreboardTeam(teamId: string): boolean;
        startUsingItem($$0: Internal.InteractionHand_): void;
        invokePlayEquipmentBreakEffects(arg0: Internal.ItemStack_): void;
        localvar$bbb000$architectury$modifyLevelCallback_setLevelCallback(callback: Internal.EntityInLevelCallback_): Internal.EntityInLevelCallback;
        position(): Vec3d;
        setTimeout(): void;
        static getEquipmentSlotForItem($$0: Internal.ItemStack_): Internal.EquipmentSlot;
        getEquipment(slot: Internal.EquipmentSlot_): Internal.ItemStack;
        displayFireAnimation(): boolean;
        isOutOfCamera(): boolean;
        getRopeHoldPosition($$0: number): Vec3d;
        copyPosition($$0: Internal.Entity_): void;
        "hasPassenger(net.minecraft.world.entity.Entity)"($$0: Internal.Entity_): boolean;
        extraalchemy_spawnParticles(arg0: Internal.ItemStack_, arg1: number): void;
        etf$canBeBright(): boolean;
        isCrouching(): boolean;
        "getAttributeBaseValue(net.minecraft.world.entity.ai.attributes.Attribute)"(attribute: Internal.Attribute_): number;
        onLeaveCombat(): void;
        wrapOperation$bgd000$artifacts$travel(block: Internal.Block_, original: Internal.Operation_<any>): number;
        setY(y: number): void;
        getAttributeValue($$0: Internal.Attribute_): number;
        getFeetBlockState(): Internal.BlockState;
        archon$isOwner(player: Internal.Player_): boolean;
        isWithinRestriction(): boolean;
        getChangeListener(): Internal.EntityInLevelCallback;
        positionRider($$0: Internal.Entity_): void;
        baseTick(): void;
        broadcastToPlayer($$0: Internal.ServerPlayer_): boolean;
        setSharedFlag($$0: number, $$1: boolean): void;
        getSleepingPos(): Optional<BlockPos>;
        damageHeldItem(): void;
        getCustomName(): net.minecraft.network.chat.Component;
        getClass(): typeof any;
        isVisuallySwimming(): boolean;
        getMaxAirSupply(): number;
        handler$zcl000$porting_lib_base$port_lib$addEffect(newEffect: Internal.MobEffectInstance_, source: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>, oldEffect: Internal.MobEffectInstance_): void;
        setItemInHand($$0: Internal.InteractionHand_, $$1: Internal.ItemStack_): void;
        dynamicLightTick(): void;
        setMaxHealth(hp: number): void;
        getFacing(): Internal.Direction;
        emf$isWet(): boolean;
        getJumpCooldown(): number;
        isPassengerOfSameVehicle($$0: Internal.Entity_): boolean;
        getBoundingBoxForCulling(): Internal.AABB;
        setAge($$0: number): void;
        getTarget(): Internal.LivingEntity;
        static collideBoundingBox(entity: Internal.Entity_, movement: Vec3d_, entityBoundingBox: Internal.AABB_, world: Internal.Level_, collisions: Internal.List_<any>): Vec3d;
        fzzy_core_getModifierContainer(): Internal.ModifierContainer;
        restrictTo($$0: BlockPos_, $$1: number): void;
        isInLove(): boolean;
        trackingPosition(): Vec3d;
        getNameTagOffsetY(): number;
        isInvulnerable(): boolean;
        isInLava(): boolean;
        isInWater(): boolean;
        awardKillScore($$0: Internal.Entity_, $$1: number, $$2: DamageSource_): void;
        finalizeSpawn($$0: Internal.ServerLevelAccessor_, $$1: Internal.DifficultyInstance_, $$2: Internal.MobSpawnType_, $$3: Internal.SpawnGroupData_, $$4: Internal.CompoundTag_): Internal.SpawnGroupData;
        localvar$leb000$puzzleslib$knockback$3(ratioZ: number): number;
        handleStartJump($$0: number): void;
        unsetRemoved(): void;
        pehkui_getScaleCache(): Internal.ScaleData[];
        swing($$0: Internal.InteractionHand_): void;
        hasEffect($$0: Internal.MobEffect_): boolean;
        getHeldItem(hand: Internal.InteractionHand_): Internal.ItemStack;
        setFusionModel(layerIndex: number, model: Internal.Triple_<any, any, any>): void;
        getRootVehicle(): Internal.Entity;
        getOwnerUUID(): Internal.UUID;
        onPathfindingDone(): void;
        save($$0: Internal.CompoundTag_): boolean;
        archon$setLifetime(seconds: number): void;
        modify$zhf000$additionalentityattributes$additionalEntityAttributes$waterSpeed(original: number): number;
        getLocalBoundsForPose($$0: Internal.Pose_): Internal.AABB;
        isNoGravity(): boolean;
        dodge(chance: number): boolean;
        onItemPickup($$0: Internal.ItemEntity_): void;
        getMouthAnim($$0: number): number;
        hex$setLastDamageSource(arg0: DamageSource_): void;
        emf$getY(): number;
        handler$kom000$porting_lib_entity$port_lib$entityInit(entityType: Internal.EntityType_<any>, world: Internal.Level_, ci: Internal.CallbackInfo_): void;
        resetLove(): void;
        bookshelf$createHoverEvent(): Internal.HoverEvent;
        updateSwimming(): void;
        isHolding($$0: Internal.Predicate_<Internal.ItemStack>): boolean;
        getSpeed(): number;
        abstract getCachedFeetBlockState(): Internal.BlockState;
        shouldInformAdmins(): boolean;
        rideTick(): void;
        port_lib$onEffectRemoved(arg0: Internal.MobEffectInstance_): void;
        handler$zll000$amethyst_imbuement$onAttackWhilstStunnedNoTarget(hand: Internal.InteractionHand_, ci: Internal.CallbackInfo_): void;
        wait(): void;
        getUuid(): Internal.UUID;
        setOffHandItem(item: Internal.ItemStack_): void;
        spawn(): void;
        setNoAi($$0: boolean): void;
        teleportTo($$0: Internal.ServerLevel_, $$1: number, $$2: number, $$3: number, $$4: Internal.Set_<Internal.RelativeMovement>, $$5: number, $$6: number): boolean;
        etf$getCustomName(): net.minecraft.network.chat.Component;
        fabric_writeAttachmentsToNbt(nbt: Internal.CompoundTag_): void;
        shouldShowName(): boolean;
        getArmorSlots(): Internal.Iterable<Internal.ItemStack>;
        canPickUpLoot(): boolean;
        kill(): void;
        onEnterCombat(): void;
        updateNavigationRegistration(): void;
        animateHurt($$0: number): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        handler$kom000$porting_lib_entity$port_lib$onEntityRemove(reason: Internal.Entity$RemovalReason_, ci: Internal.CallbackInfo_): void;
        static resetForwardDirectionOfRelativePortalPosition($$0: Vec3d_): Vec3d;
        callGetEyeHeight(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        hasRestriction(): boolean;
        getHeadArmorItem(): Internal.ItemStack;
        botania_createInventory(): void;
        deserializeNBT(arg0: Internal.Tag_): void;
        setEating($$0: boolean): void;
        getCurrentModifyFoodPowers(): Internal.List<any>;
        getBbWidth(): number;
        splitIntoDynamicLightEntries(): Internal.Stream<Internal.SpatialLookupEntry>;
        addDeltaMovement($$0: Vec3d_): void;
        pehkui_setOnGround(onGround: boolean): void;
        localvar$leb000$puzzleslib$knockback$1(strength: number): number;
        setTamed($$0: boolean): void;
        bettertrims$addLateAttributes(adder: Internal.Consumer_<any>): void;
        handler$lef000$puzzleslib$readAdditionalSaveData(compound: Internal.CompoundTag_, callback: Internal.CallbackInfo_): void;
        sendLeashState(): void;
        "getName()"(): net.minecraft.network.chat.Component;
        mirror($$0: Internal.Mirror_): number;
        static port_lib$collideWithShapes(vec3: Vec3d_, aABB: Internal.AABB_, list: Internal.List_<Internal.VoxelShape>): Vec3d;
        knockback($$0: number, $$1: number, $$2: number): void;
        getTicksRequiredToFreeze(): number;
        getVisibilityPercent($$0: Internal.Entity_): number;
        getMaxSpawnClusterSize(): number;
        localvar$kpc000$porting_lib_entity$port_lib$modifyDistance(fallDistance: number): number;
        artifacts$getPocketPistonLength(): number;
        canJump(): boolean;
        emf$prevZ(): number;
        getUsername(): string;
        getInLoveTime(): number;
        move($$0: Internal.MoverType_, $$1: Vec3d_): void;
        "setVariant(java.lang.Object)"(arg0: any): void;
        lithiumOnBlockCacheSet(newState: Internal.BlockState_): void;
        isPickable(): boolean;
        setYHeadRot($$0: number): void;
        setJumping($$0: boolean): void;
        getCustomData(): Internal.CompoundTag;
        handler$zno000$apoli$getGroup(info: Internal.CallbackInfoReturnable_<any>): void;
        getPickResult(): Internal.ItemStack;
        "getMainHandItem()"(): Internal.ItemStack;
        getAbsorptionAmount(): number;
        getRandomY(): number;
        onEffectRemoved($$0: Internal.MobEffectInstance_): void;
        getDisplayName(): net.minecraft.network.chat.Component;
        static "tickEntity(net.minecraft.world.entity.Entity)"(entity: Internal.Entity_): void;
        getMobType(): Internal.MobType;
        travel($$0: Vec3d_): void;
        getItemInHand($$0: Internal.InteractionHand_): Internal.ItemStack;
        localvar$leb000$puzzleslib$hurt$0(amount: number, source: DamageSource_): number;
        getDynamicLightPrevX(): number;
        shouldBeSaved(): boolean;
        fabric_hasPersistentAttachments(): boolean;
        method_5749($$0: Internal.CompoundTag_): void;
        hurtHelmet($$0: DamageSource_, $$1: number): void;
        removeTag($$0: string): boolean;
        isHoldingInAnyHand(i: Internal.Ingredient_): boolean;
        getFluidHeight($$0: Internal.TagKey_<Internal.Fluid>): number;
        canSpawnSoulSpeedParticle(): boolean;
        notifyAll(): void;
        hasInventoryChanged($$0: net.minecraft.world.Container_): boolean;
        aiStep(): void;
        handler$leb000$puzzleslib$removeEffect(effect: Internal.MobEffect_, callback: Internal.CallbackInfoReturnable_<any>): void;
        getPassengersRidingOffset(): number;
        setAttributeBaseValue(attribute: Internal.Attribute_, value: number): void;
        distanceToEntitySqr($$0: Internal.Entity_): number;
        isFrame(): boolean;
        broadcastBreakEvent($$0: Internal.InteractionHand_): void;
        setLegsArmorItem(item: Internal.ItemStack_): void;
        localvar$leb000$puzzleslib$causeFallDamage$1(fallDistance: number): number;
        discard(): void;
        setVariant($$0: Internal.Variant_): void;
        "handler$mhe000$step-height-entity-attribute$getStepHeight"(cir: Internal.CallbackInfoReturnable_<any>): void;
        sendSystemMessage($$0: net.minecraft.network.chat.Component_): void;
        acceptsSuccess(): boolean;
        static tickEntity(entity: Internal.LivingEntity_): void;
        setNoGravity($$0: boolean): void;
        getUseItemRemainingTicks(): number;
        gear_core_getActiveSets(): Internal.HashMap<any, any>;
        getIndirectPassengers(): Internal.Iterable<any>;
        attackable(): boolean;
        createCommandSourceStack(): Internal.CommandSourceStack;
        getNavigation(): Internal.PathNavigation;
        isControlledByLocalInstance(): boolean;
        "setVariant(net.minecraft.world.entity.animal.horse.Variant)"($$0: Internal.Variant_): void;
        isMonster(): boolean;
        pehkui_setShouldSyncScales(sync: boolean): void;
        handler$cbm000$besmirchment$canTarget(type: Internal.EntityType_<any>, cir: Internal.CallbackInfoReturnable_<any>): void;
        getLoveCause(): Internal.ServerPlayer;
        getLastClimbablePos(): Optional<BlockPos>;
        getEatingSound($$0: Internal.ItemStack_): Internal.SoundEvent;
        setLastDynamicLuminance(luminance: number): void;
        getPerceivedTargetDistanceSquareForMeleeAttack($$0: Internal.LivingEntity_): number;
        setId($$0: number): void;
        onSyncedDataUpdated($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        getHorizontalFacing(): Internal.Direction;
        getType(): string;
        static checkAnimalSpawnRules($$0: Internal.EntityType_<Internal.Animal>, $$1: Internal.LevelAccessor_, $$2: Internal.MobSpawnType_, $$3: BlockPos_, $$4: Internal.RandomSource_): boolean;
        isDamageSourceBlocked($$0: DamageSource_): boolean;
        getLightProbePosition($$0: number): Vec3d;
        getActiveEffectsMap(): Internal.Map<Internal.MobEffect, Internal.MobEffectInstance>;
        wrapOperation$mac000$smarterfarmers$smarterFarmers$overrideMobGriefing(instance: Internal.GameRules_, key: Internal.GameRules$Key_<any>, original: Internal.Operation_<any>): boolean;
        emf$prevX(): number;
        onEquipItem($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_, $$2: Internal.ItemStack_): void;
        checkDespawn(): void;
        pehkui_shouldSyncScales(): boolean;
        getWalkTargetValue($$0: BlockPos_, $$1: Internal.LevelReader_): number;
        lookAt($$0: Internal.Entity_, $$1: number, $$2: number): void;
        setHeldItem(hand: Internal.InteractionHand_, item: Internal.ItemStack_): void;
        port_lib$maybeDisableShield(arg0: Internal.Player_, arg1: Internal.ItemStack_, arg2: Internal.ItemStack_): void;
        equipItemIfPossible($$0: Internal.ItemStack_): Internal.ItemStack;
        onSyncedDataUpdated($$0: Internal.EntityDataAccessor_<any>): void;
        lerpHeadTo($$0: number, $$1: number): void;
        canDisableShield(): boolean;
        setMotionX(x: number): void;
        getHandSlots(): Internal.Iterable<Internal.ItemStack>;
        distanceToEntity($$0: Internal.Entity_): number;
        bookshelf$getDeathSound(): Internal.SoundEvent;
        wait(arg0: number, arg1: number): void;
        getTeamColor(): number;
        lithiumSetClimbingMobCachingSectionUpdateBehavior(listenForCachedBlockChanges: boolean): void;
        setNbt(nbt: Internal.CompoundTag_): void;
        lambdynlights$getTrackedLitChunkPos(): Internal.LongSet;
        checkSpawnObstruction($$0: Internal.LevelReader_): boolean;
        getRecallPosition(): Internal.DimensionalPosition;
        extinguish(): void;
        setDynamicLightEnabled(enabled: boolean): void;
        equipArmor($$0: Internal.Player_, $$1: Internal.ItemStack_): void;
        getRestrictRadius(): number;
        moveTo($$0: Vec3d_): void;
        isColliding($$0: BlockPos_, $$1: Internal.BlockState_): boolean;
        "swing(net.minecraft.world.InteractionHand)"(hand: Internal.InteractionHand_): void;
        lambdynlights$updateDynamicLight(renderer: Internal.LevelRenderer_): boolean;
        getRegisteredNavigation(): Internal.PathNavigation;
        bettertrims$isWearing(effect: Internal.TrimEffect_): boolean;
        static port_lib$collideWithShapes$porting_lib_accessors_$md$424943$0(arg0: Vec3d_, arg1: Internal.AABB_, arg2: Internal.List_<any>): Vec3d;
        isForcedVisible(): boolean;
        modifyTemper($$0: number): number;
        isInvertedHealAndHarm(): boolean;
        handler$jon000$origins$doWaterBreathing(info: Internal.CallbackInfoReturnable_<any>): void;
        canHoldItem($$0: Internal.ItemStack_): boolean;
        killedEntity($$0: Internal.ServerLevel_, $$1: Internal.LivingEntity_): boolean;
        getAttachedOrElse<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        isFreezing(): boolean;
        containerChanged($$0: net.minecraft.world.Container_): void;
        runCommand(command: string): number;
        isStanding(): boolean;
        hex$getDeathSound(): Internal.SoundEvent;
        setGuaranteedDrop($$0: Internal.EquipmentSlot_): void;
        setSharedFlagOnFire($$0: boolean): void;
        set defaultMovementSpeedMultiplier(speed: number)
        get suppressingBounce(): boolean
        set target($$0: Internal.LivingEntity_)
        set culled(value: boolean)
        get onFire(): boolean
        get owner(): Internal.LivingEntity
        get positionCodec(): Internal.VecDeltaCodec
        set maxUpStep($$0: number)
        get fallFlyingTicks(): number
        set xxa($$0: number)
        set delayedLeashHolderId($$0: number)
        get shiftKeyDown(): boolean
        set UUID($$0: Internal.UUID_)
        set motionZ(z: number)
        get blockY(): number
        get isInsideStructureTracker(): Internal.IsInsideStructureTracker
        set playerHitTimer(arg0: number)
        get spectator(): boolean
        set mainHandItem(item: Internal.ItemStack_)
        get persistentData(): Internal.CompoundTag
        get health(): number
        get maxHealth(): number
        get registeredToWorld(): boolean
        set aggressive($$0: boolean)
        set removed($$0: Internal.Entity$RemovalReason_)
        get inWaterRainOrBubble(): boolean
        get removalReason(): Internal.Entity$RemovalReason
        get eating(): boolean
        set boundingBox($$0: Internal.AABB_)
        get ambientCreature(): boolean
        set zza($$0: number)
        get block(): Internal.BlockContainerJS
        get name(): net.minecraft.network.chat.Component
        get controlledVehicle(): Internal.Entity
        get armorValue(): number
        get killCredit(): Internal.LivingEntity
        get componentContainer(): Internal.ComponentContainer
        get dynamicLightPrevZ(): number
        set outOfCamera(value: boolean)
        get autoSpinAttack(): boolean
        get remainingFireTicks(): number
        get maxFallDistance(): number
        get ticksFrozen(): number
        get dynamicLightZ(): number
        get voicePitch(): number
        set statusMessage(message: net.minecraft.network.chat.Component_)
        set sleepingPos($$0: BlockPos_)
        get descending(): boolean
        get headRotSpeed(): number
        get lastHurtByPlayer(): Internal.Player
        get YHeadRot(): number
        set absorptionAmount($$0: number)
        set recallData(pos: Internal.DimensionalPosition_)
        set deltaMovement($$0: Vec3d_)
        get baby(): boolean
        get culled(): boolean
        get glowing(): boolean
        get leashedByEntities(): Internal.Set<any>
        get leashOffset(): Vec3d
        get attackable(): boolean
        get saddleSoundEvent(): Internal.SoundEvent
        get underWater(): boolean
        get leashHolder(): Internal.Entity
        get sensing(): Internal.Sensing
        get legsArmorItem(): Internal.ItemStack
        get luminance(): number
        get selfAndPassengers(): Internal.Stream<any>
        get deltaMovement(): Vec3d
        get dynamicLightX(): number
        set secondsOnFire($$0: number)
        get "displayName()"(): net.minecraft.network.chat.Component
        get lootTable(): ResourceLocation
        get ticksUsingItem(): number
        get arrowCount(): number
        get moveControl(): Internal.MoveControl
        set standing($$0: boolean)
        get defaultMovementSpeed(): number
        get peacefulCreature(): boolean
        set onGround($$0: boolean)
        get lastHurtByMobTimestamp(): number
        get vehicle(): Internal.Entity
        get effectiveAi(): boolean
        get stringUuid(): string
        set swimming($$0: boolean)
        get mainArm(): Internal.HumanoidArm
        get rotationVector(): Internal.Vec2
        get hurtDir(): number
        get sprinting(): boolean
        get motionY(): number
        get offhandItem(): Internal.ItemStack
        set luminance(luminance: number)
        set lootTable(arg0: ResourceLocation_)
        get lastHurtMob(): Internal.LivingEntity
        get lastDamageSource(): DamageSource
        get soundSource(): Internal.SoundSource
        get jumping(): boolean
        set noActionTime($$0: number)
        set movementSpeedAddition(speed: number)
        get pose(): Internal.Pose
        get restrictCenter(): BlockPos
        get leftHanded(): boolean
        set z(z: number)
        get y(): number
        set isJumping($$0: boolean)
        set currentModifyFoodPowers(powers: Internal.List_<any>)
        get blocking(): boolean
        get pushedByFluid(): boolean
        set originalFoodStack(original: Internal.ItemStack_)
        get armorCoverPercentage(): number
        get airSupply(): number
        get variant(): Internal.Variant
        get player(): boolean
        get animal(): boolean
        get motionDirection(): Internal.Direction
        get fabricBalmData(): Internal.CompoundTag
        get commandSenderWorld(): Internal.Level
        get totalMovementSpeed(): number
        get moving(): boolean
        get attributes(): Internal.AttributeMap
        set inLoveTime($$0: number)
        get swimming(): boolean
        set sprinting($$0: boolean)
        get dynamicLightLevel(): Internal.Level
        set x(x: number)
        get portalWaitTime(): number
        get blockStateOn(): Internal.BlockState
        set ownerUUID($$0: Internal.UUID_)
        get fluidJumpThreshold(): number
        get cachedSouls(): number
        get "variant()"(): any
        set airSupply($$0: number)
        get onPos(): BlockPos
        get undead(): boolean
        set useItemRemaining(arg0: number)
        get targetSelector(): Internal.GoalSelector
        set registeredToWorld(navigation: Internal.PathNavigation_)
        get sleeping(): boolean
        get dismountPoses(): Internal.ImmutableList<Internal.Pose>
        get lastHurtMobTimestamp(): number
        set remainingFireTicks($$0: number)
        /**
         * @deprecated
        */
        get onPosLegacy(): BlockPos
        set pos($$0: Vec3d_)
        set canPickUpLoot($$0: boolean)
        get mainHandItem(): Internal.ItemStack
        set silent($$0: boolean)
        set leftHanded($$0: boolean)
        get activeEffects(): Internal.Collection<Internal.MobEffectInstance>
        get onPortalCooldown(): boolean
        set pitch($$0: number)
        get usingItem(): boolean
        get alwaysTicking(): boolean
        set invulnerable($$0: boolean)
        get dynamicLightPrevY(): number
        set glowing($$0: boolean)
        get alive(): boolean
        get bbHeight(): number
        get tags(): Internal.Set<string>
        get lastAttacker(): Internal.LivingEntity
        get lastRollTicks(): number
        get goalSelector(): Internal.GoalSelector
        get percentFrozen(): number
        set portalCooldown($$0: number)
        set position(block: Internal.BlockContainerJS_)
        get leashed(): boolean
        get variant(): any
        set pose($$0: Internal.Pose_)
        get reachDistance(): number
        get entityType(): Internal.EntityType<any>
        get waterCreature(): boolean
        set lastHurtByPlayer($$0: Internal.Player_)
        get "server()"(): Internal.MinecraftServer
        get ambientStandSound(): Internal.SoundEvent
        get pushable(): boolean
        set YBodyRot($$0: number)
        set motionY(y: number)
        get dynamicLightEnabled(): boolean
        set bred($$0: boolean)
        set chestArmorItem(item: Internal.ItemStack_)
        get passenger(): boolean
        get sensitiveToWater(): boolean
        get jumpControl(): Internal.JumpControl
        get feetArmorItem(): Internal.ItemStack
        get saddleable(): boolean
        get viewScale(): number
        get visualRotationYInDegrees(): number
        set speed($$0: number)
        get discrete(): boolean
        get level(): Internal.Level
        get combatTracker(): Internal.CombatTracker
        get customJump(): number
        get noAi(): boolean
        get chestArmorItem(): Internal.ItemStack
        set variant(arg0: any)
        get fullyFrozen(): boolean
        get inWall(): boolean
        get allSlots(): Internal.Iterable<Internal.ItemStack>
        get inventory(): Internal.SimpleContainer
        get scale(): number
        get suppressingSlidingDownLadder(): boolean
        get blockZ(): number
        get silent(): boolean
        set useItem(arg0: Internal.ItemStack_)
        get pitch(): number
        get random(): Internal.RandomSource
        get passengersAndSelf(): Internal.Stream<any>
        get maxTemper(): number
        get originalFoodStack(): Internal.ItemStack
        get age(): number
        get noActionTime(): number
        get visuallyCrawling(): boolean
        get aggressive(): boolean
        get wearingArmor(): boolean
        set yya($$0: number)
        set baby($$0: boolean)
        get temper(): number
        get lastHurtByMob(): Internal.LivingEntity
        get inWaterOrBubble(): boolean
        get portalCooldown(): number
        get item(): Internal.ItemStack
        get ignoringBlockTriggers(): boolean
        get steppingCarefully(): boolean
        get blockX(): number
        /**
         * @deprecated
        */
        get lightLevelDependentMagicValue(): number
        get fallFlying(): boolean
        get encodeId(): string
        get maxHeadXRot(): number
        get nbt(): Internal.CompoundTag
        set invisible($$0: boolean)
        get saddled(): boolean
        set totalMovementSpeedMultiplier(speed: number)
        get dynamicLightY(): number
        set health($$0: number)
        get ambientStandInterval(): number
        get eyePosition(): Vec3d
        get eyeHeight(): number
        set discardFriction($$0: boolean)
        get yaw(): number
        get usedItemHand(): Internal.InteractionHand
        set defaultMovementSpeed(speed: number)
        get brain(): Internal.Brain<any>
        set customNameVisible($$0: boolean)
        get controllingPassenger(): Internal.LivingEntity
        get scriptType(): Internal.ScriptType
        get forward(): Vec3d
        set feetArmorItem(item: Internal.ItemStack_)
        get id(): number
        get recipientsForComponentSync(): Internal.Iterable<any>
        get eyeY(): number
        get boundingBox(): Internal.AABB
        get inWaterOrRain(): boolean
        get "variant()"(): Internal.Variant
        get affectedByPotions(): boolean
        get addEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>
        get team(): Internal.Team
        set ticksFrozen($$0: number)
        get useItem(): Internal.ItemStack
        get myRidingOffset(): number
        get living(): boolean
        get x(): number
        get vehicle(): boolean
        set temper($$0: number)
        set isInPowderSnow($$0: boolean)
        set customName($$0: net.minecraft.network.chat.Component_)
        get teamId(): string
        set stingerCount($$0: number)
        get maxHeadYRot(): number
        get armor(): Internal.ItemStack
        get customNameVisible(): boolean
        get pistonPushReaction(): Internal.PushReaction
        get lootTableSeed(): number
        get motionX(): number
        get entityData(): Internal.SynchedEntityData
        get potionEffects(): Internal.EntityPotionEffectsJS
        get lastHurtByPlayerTime(): number
        get onRails(): boolean
        get stingerCount(): number
        get fallSounds(): Internal.LivingEntity$Fallsounds
        get dimensionChangingDelay(): number
        get lastDynamicLuminance(): number
        set yaw($$0: number)
        get pickRadius(): number
        get pathFinding(): boolean
        get markings(): Internal.Markings
        get removed(): boolean
        get jumpBoostPower(): number
        set shiftKeyDown($$0: boolean)
        get passengers(): Internal.EntityArrayList
        get z(): number
        get server(): Internal.MinecraftServer
        get experienceReward(): number
        get firstPassenger(): Internal.Entity
        set lastHurtMob($$0: Internal.Entity_)
        set lastHurtByMob($$0: Internal.LivingEntity_)
        get leashingEntities(): Internal.Set<any>
        set fabricBalmData(tag: Internal.CompoundTag_)
        get lookAngle(): Vec3d
        get ambientSoundInterval(): number
        set arrowCount($$0: number)
        get motionZ(): number
        get persistenceRequired(): boolean
        get invisible(): boolean
        get tamed(): boolean
        get bedOrientation(): Internal.Direction
        get profile(): Internal.GameProfile
        set inLove($$0: Internal.Player_)
        get deadOrDying(): boolean
        set headArmorItem(item: Internal.ItemStack_)
        set viewScale($$0: number)
        set levelCallback($$0: Internal.EntityInLevelCallback_)
        get lookControl(): Internal.LookControl
        get bred(): boolean
        get offHandItem(): Internal.ItemStack
        get outOfCamera(): boolean
        get crouching(): boolean
        set y(y: number)
        get feetBlockState(): Internal.BlockState
        get withinRestriction(): boolean
        get changeListener(): Internal.EntityInLevelCallback
        get sleepingPos(): Optional<BlockPos>
        get customName(): net.minecraft.network.chat.Component
        get class(): typeof any
        get visuallySwimming(): boolean
        get maxAirSupply(): number
        set maxHealth(hp: number)
        get facing(): Internal.Direction
        get jumpCooldown(): number
        get boundingBoxForCulling(): Internal.AABB
        set age($$0: number)
        get target(): Internal.LivingEntity
        get inLove(): boolean
        get nameTagOffsetY(): number
        get invulnerable(): boolean
        get inLava(): boolean
        get inWater(): boolean
        get rootVehicle(): Internal.Entity
        get ownerUUID(): Internal.UUID
        get noGravity(): boolean
        get speed(): number
        get cachedFeetBlockState(): Internal.BlockState
        get uuid(): Internal.UUID
        set offHandItem(item: Internal.ItemStack_)
        set noAi($$0: boolean)
        get armorSlots(): Internal.Iterable<Internal.ItemStack>
        get headArmorItem(): Internal.ItemStack
        set eating($$0: boolean)
        get currentModifyFoodPowers(): Internal.List<any>
        get bbWidth(): number
        set tamed($$0: boolean)
        get "name()"(): net.minecraft.network.chat.Component
        get ticksRequiredToFreeze(): number
        get maxSpawnClusterSize(): number
        get username(): string
        get inLoveTime(): number
        set "variant(java.lang.Object)"(arg0: any)
        get pickable(): boolean
        set YHeadRot($$0: number)
        set jumping($$0: boolean)
        get customData(): Internal.CompoundTag
        get pickResult(): Internal.ItemStack
        get "mainHandItem()"(): Internal.ItemStack
        get absorptionAmount(): number
        get randomY(): number
        get displayName(): net.minecraft.network.chat.Component
        get mobType(): Internal.MobType
        get dynamicLightPrevX(): number
        get passengersRidingOffset(): number
        get frame(): boolean
        set legsArmorItem(item: Internal.ItemStack_)
        set variant($$0: Internal.Variant_)
        set noGravity($$0: boolean)
        get useItemRemainingTicks(): number
        get indirectPassengers(): Internal.Iterable<any>
        get navigation(): Internal.PathNavigation
        get controlledByLocalInstance(): boolean
        set "variant(net.minecraft.world.entity.animal.horse.Variant)"($$0: Internal.Variant_)
        get monster(): boolean
        get loveCause(): Internal.ServerPlayer
        get lastClimbablePos(): Optional<BlockPos>
        set lastDynamicLuminance(luminance: number)
        set id($$0: number)
        get horizontalFacing(): Internal.Direction
        get type(): string
        get activeEffectsMap(): Internal.Map<Internal.MobEffect, Internal.MobEffectInstance>
        set motionX(x: number)
        get handSlots(): Internal.Iterable<Internal.ItemStack>
        get teamColor(): number
        set nbt(nbt: Internal.CompoundTag_)
        get recallPosition(): Internal.DimensionalPosition
        set dynamicLightEnabled(enabled: boolean)
        get restrictRadius(): number
        get registeredNavigation(): Internal.PathNavigation
        get forcedVisible(): boolean
        get invertedHealAndHarm(): boolean
        get freezing(): boolean
        get standing(): boolean
        set guaranteedDrop($$0: Internal.EquipmentSlot_)
        set sharedFlagOnFire($$0: boolean)
    }
    type Horse_ = Horse;
    class SpellSchool$Apply extends Internal.Enum<Internal.SpellSchool$Apply> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        compareTo(arg0: Internal.SpellSchool$Apply_): number;
        toString(): string;
        getDeclaringClass(): typeof Internal.SpellSchool$Apply;
        static values(): Internal.SpellSchool$Apply[];
        notifyAll(): void;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.SpellSchool$Apply>>;
        notify(): void;
        static valueOf(name: string): Internal.SpellSchool$Apply;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        name(): string;
        hashCode(): number;
        "compareTo(net.spell_power.api.SpellSchool$Apply)"(arg0: Internal.SpellSchool$Apply_): number;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        get class(): typeof any
        get declaringClass(): typeof Internal.SpellSchool$Apply
        static readonly ADD: (Internal.SpellSchool$Apply) & (Internal.SpellSchool$Apply);
        static readonly MULTIPLY: (Internal.SpellSchool$Apply) & (Internal.SpellSchool$Apply);
    }
    type SpellSchool$Apply_ = "multiply" | SpellSchool$Apply | "add";
    class SpriteContents implements Internal.Stitcher$Entry, Internal.SpriteContentsExt, me.jellysquid.mods.sodium.mixin.features.textures.animations.upload.SpriteContentsAccessor, Internal.SpriteContentsAccessor, Internal.SpriteContentsExtension, Internal.SpriteContentsExtensions, Internal.SpriteContentsExtended, Internal.AutoCloseable, Internal.SpriteContentsInvoker, ca.fxco.moreculling.mixin.accessors.SpriteContentsAccessor, net.irisshaders.iris.texture.SpriteContentsExtension {
        constructor($$0: ResourceLocation_, $$1: Internal.FrameSize_, $$2: Internal.NativeImage_, $$3: Internal.AnimationMetadataSection_)
        getClass(): typeof any;
        getOrCreatePBRHolder(): Internal.PBRSpriteHolder;
        getImage(): Internal.NativeImage;
        getPixelRGBA(frameIndex: number, x: number, y: number): number;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        upload($$0: number, $$1: number, $$2: number, $$3: number, $$4: Internal.NativeImage_[]): void;
        getImages(): Internal.NativeImage[];
        getFrameCount(): number;
        sodium$hasAnimation(): boolean;
        getUniqueFrames(): Internal.IntStream;
        name(): ResourceLocation;
        getAnimatedTexture(): Internal.SpriteContents$AnimatedTexture;
        isTransparent($$0: number, $$1: number, $$2: number): boolean;
        invokeMethod_45811(arg0: number, arg1: number, arg2: number, arg3: number, arg4: Internal.NativeImage_[]): void;
        toString(): string;
        getCreatedTicker(): Internal.SpriteContents$Ticker;
        uploadFirstFrame($$0: number, $$1: number): void;
        notifyAll(): void;
        height(): number;
        sodium$isActive(): boolean;
        increaseMipLevel($$0: number): void;
        hashCode(): number;
        wait(): void;
        axiom$setOpacity(opacity: number, x: number, y: number): void;
        close(): void;
        wait(arg0: number): void;
        width(): number;
        getPBRHolder(): Internal.PBRSpriteHolder;
        sodium$setActive(value: boolean): void;
        equals(arg0: any): boolean;
        createTicker(): Internal.SpriteTicker;
        get class(): typeof any
        get orCreatePBRHolder(): Internal.PBRSpriteHolder
        get image(): Internal.NativeImage
        get images(): Internal.NativeImage[]
        get frameCount(): number
        get uniqueFrames(): Internal.IntStream
        get animatedTexture(): Internal.SpriteContents$AnimatedTexture
        get createdTicker(): Internal.SpriteContents$Ticker
        get PBRHolder(): Internal.PBRSpriteHolder
        originalImage: Internal.NativeImage;
        byMipLevel: Internal.NativeImage[];
        animatedTexture: Internal.SpriteContents$AnimatedTexture;
    }
    type SpriteContents_ = SpriteContents;
    interface BiomeSourceAccessor {
        abstract bclRebuildFeatures(): void;
        (): void;
    }
    type BiomeSourceAccessor_ = BiomeSourceAccessor | (()=> void);
    interface CustomJavaToJsWrapper {
        abstract convertJavaToJs(arg0: Internal.Context_, arg1: Internal.Scriptable_, arg2: typeof any): Internal.Scriptable;
        (arg0: Internal.Context, arg1: Internal.Scriptable, arg2: typeof any): Internal.Scriptable_;
    }
    type CustomJavaToJsWrapper_ = ((arg0: Internal.Context, arg1: Internal.Scriptable, arg2: typeof any)=> Internal.Scriptable_) | CustomJavaToJsWrapper;
    class LegacyRandomSource implements Internal.BitRandomSource {
        constructor($$0: number)
        getClass(): typeof any;
        static create($$0: number): Internal.RandomSource;
        static create(): Internal.RandomSource;
        nextLong(): number;
        nextDouble(): number;
        notify(): void;
        nextGaussian(): number;
        wait(arg0: number, arg1: number): void;
        static createNewThreadLocalInstance(): Internal.RandomSource;
        forkPositional(): Internal.PositionalRandomFactory;
        consumeCount($$0: number): void;
        nextInt($$0: number): number;
        nextFloat(): number;
        nextInt(): number;
        next($$0: number): number;
        toString(): string;
        fork(): Internal.RandomSource;
        nextBoolean(): boolean;
        notifyAll(): void;
        setSeed($$0: number): void;
        nextInt($$0: number, $$1: number): number;
        hashCode(): number;
        triangle($$0: number, $$1: number): number;
        wait(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        static createThreadSafe(): Internal.RandomSource;
        nextIntBetweenInclusive($$0: number, $$1: number): number;
        get class(): typeof any
        set seed($$0: number)
    }
    type LegacyRandomSource_ = LegacyRandomSource;
    class EMFPartData {
        constructor()
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        getAttachments(): Internal.List<Internal.Consumer<Internal.PoseStack>>;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(o: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getCustomTexture(): ResourceLocation;
        prepare(textureSize: number[], jem: Internal.EMFJemData_): void;
        get class(): typeof any
        get attachments(): Internal.List<Internal.Consumer<Internal.PoseStack>>
        get customTexture(): ResourceLocation
        translate: number[];
        textureSize: number[];
        part: string;
        attachments: Internal.Object2ObjectOpenHashMap<string, number[]>;
        animations: Internal.LinkedList<Internal.LinkedHashMap<string, string>>;
        submodels: Internal.LinkedList<Internal.EMFPartData>;
        invertAxis: string;
        mirrorTexture: string;
        boxes: any[];
        rotate: number[];
        texture: string;
        baseId: string;
        model: string;
        id: string;
        attach: boolean;
        scale: number;
        submodel: Internal.EMFPartData;
    }
    type EMFPartData_ = EMFPartData;
    class CookingPotRecipeBookTab extends Internal.Enum<Internal.CookingPotRecipeBookTab> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        toString(): string;
        compareTo(arg0: Internal.CookingPotRecipeBookTab_): number;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        static values(): Internal.CookingPotRecipeBookTab[];
        compareTo(arg0: any): number;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.CookingPotRecipeBookTab>>;
        name(): string;
        hashCode(): number;
        static valueOf(name: string): Internal.CookingPotRecipeBookTab;
        getDeclaringClass(): typeof Internal.CookingPotRecipeBookTab;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        "compareTo(vectorwing.farmersdelight.client.recipebook.CookingPotRecipeBookTab)"(arg0: Internal.CookingPotRecipeBookTab_): number;
        static findByName(name: string): Internal.CookingPotRecipeBookTab;
        get class(): typeof any
        get declaringClass(): typeof Internal.CookingPotRecipeBookTab
        static readonly MEALS: (Internal.CookingPotRecipeBookTab) & (Internal.CookingPotRecipeBookTab);
        readonly name: string;
        static readonly MISC: (Internal.CookingPotRecipeBookTab) & (Internal.CookingPotRecipeBookTab);
        static readonly DRINKS: (Internal.CookingPotRecipeBookTab) & (Internal.CookingPotRecipeBookTab);
    }
    type CookingPotRecipeBookTab_ = "misc" | "meals" | CookingPotRecipeBookTab | "drinks";
    abstract class Display extends Internal.Entity implements Internal.DisplayAccessor {
        constructor($$0: Internal.EntityType_<any>, $$1: Internal.Level_)
        litematica_setWorld(arg0: Internal.Level_): void;
        handler$hak000$gobber2$gobberOccludeVibrationSignals(cir: Internal.CallbackInfoReturnable_<any>): void;
        isInWall(): boolean;
        etf$getType(): Internal.EntityType<any>;
        getAllSlots(): Internal.Iterable<Internal.ItemStack>;
        getUpVector($$0: number): Vec3d;
        gameEvent($$0: Internal.GameEvent_, $$1: Internal.Entity_): void;
        remove($$0: Internal.Entity$RemovalReason_): void;
        getBlockZ(): number;
        isSuppressingBounce(): boolean;
        dampensVibrations(): boolean;
        hasAttached(type: Internal.AttachmentType_<any>): boolean;
        isSilent(): boolean;
        "playSound(net.minecraft.sounds.SoundEvent)"($$0: Internal.SoundEvent_): void;
        setCulled(value: boolean): void;
        getPitch(): number;
        isOnFire(): boolean;
        rotate($$0: Internal.Rotation_): number;
        getPositionCodec(): Internal.VecDeltaCodec;
        getPassengersAndSelf(): Internal.Stream<any>;
        setMaxUpStep($$0: number): void;
        updateFluidHeightAndDoFluidPushing($$0: Internal.TagKey_<Internal.Fluid>, $$1: number): boolean;
        setPosition(x: number, y: number, z: number): void;
        runCommandSilent(command: string): number;
        chunkPosition(): Internal.ChunkPos;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        emf$isOnGround(): boolean;
        gameEvent($$0: Internal.GameEvent_): void;
        alwaysAccepts(): boolean;
        isShiftKeyDown(): boolean;
        setUUID($$0: Internal.UUID_): void;
        checkBelowWorld(): void;
        isVisuallyCrawling(): boolean;
        setMotionZ(z: number): void;
        handler$ieb000$lambdynlights$onRemove(ci: Internal.CallbackInfo_): void;
        "deserializeNBT(net.minecraft.nbt.Tag)"(arg0: Internal.Tag_): void;
        canFreeze(): boolean;
        ignoreExplosion(): boolean;
        port_lib$setRemovalReason(arg0: Internal.Entity$RemovalReason_): void;
        teleportRelative($$0: number, $$1: number, $$2: number): void;
        getBlockY(): number;
        getIsInsideStructureTracker(): Internal.IsInsideStructureTracker;
        isSpectator(): boolean;
        pehkui_setScaleCache(scaleCache: Internal.ScaleData_[]): void;
        isInWaterOrBubble(): boolean;
        spawnAtLocation($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        getPersistentData(): Internal.CompoundTag;
        getPortalCooldown(): number;
        emf$isGlowing(): boolean;
        getItem(): Internal.ItemStack;
        getRandomZ($$0: number): number;
        pehkui_getOnGround(): boolean;
        causeFallDamage($$0: number, $$1: number, $$2: DamageSource_): boolean;
        getFusionModel(layerIndex: number): Internal.Triple<any, any, any>;
        getDynamicLightChunksToRebuild(forced: boolean): Internal.LongSet;
        getPosition($$0: number): Vec3d;
        setRemoved($$0: Internal.Entity$RemovalReason_): void;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>, initializer: Internal.Supplier_<A>): A;
        getDistanceSq($$0: number, $$1: number, $$2: number): number;
        isInWaterRainOrBubble(): boolean;
        getRemovalReason(): Internal.Entity$RemovalReason;
        wait(arg0: number): void;
        isIgnoringBlockTriggers(): boolean;
        etf$getItemsEquipped(): Internal.Iterable<any>;
        getHandHoldingItemAngle($$0: Internal.Item_): Vec3d;
        etf$getVelocity(): Vec3d;
        hex$markHurt(): void;
        distanceToSqr($$0: Vec3d_): number;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        resetFallDistance(): void;
        canSprint(): boolean;
        modifyAttached<A>(type: Internal.AttachmentType_<A>, modifier: Internal.UnaryOperator_<A>): A;
        blockPosition(): BlockPos;
        isSteppingCarefully(): boolean;
        setBoundingBox($$0: Internal.AABB_): void;
        isAmbientCreature(): boolean;
        "spawnAtLocation(net.minecraft.world.item.ItemStack,float)"($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        getBlockX(): number;
        /**
         * @deprecated
        */
        getLightLevelDependentMagicValue(): number;
        getEncodeId(): string;
        getY($$0: number): number;
        emf$prevPitch(): number;
        getBlock(): Internal.BlockContainerJS;
        getNbt(): Internal.CompoundTag;
        etf$getHandItems(): Internal.Iterable<any>;
        setInvisible($$0: boolean): void;
        etf$getArmorItems(): Internal.Iterable<any>;
        getName(): net.minecraft.network.chat.Component;
        isSubmergedInLoosely(tag: Internal.TagKey_<any>): boolean;
        onGround(): boolean;
        getDynamicLightY(): number;
        getControlledVehicle(): Internal.Entity;
        isOnSameTeam($$0: Internal.Entity_): boolean;
        onInsideBubbleColumn($$0: boolean): void;
        attack($$0: DamageSource_, $$1: number): boolean;
        tick(): void;
        getEyePosition(): Vec3d;
        getEyeHeight(): number;
        hasPassenger($$0: Internal.Predicate_<Internal.Entity>): boolean;
        getYaw(): number;
        emf$isTouchingWater(): boolean;
        emf$getVariableMap(): Internal.Object2FloatOpenHashMap<any>;
        getComponentContainer(): Internal.ComponentContainer;
        hasPermissions($$0: number): boolean;
        getDynamicLightPrevZ(): number;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        pehkui_readScaleNbt(nbt: Internal.CompoundTag_): void;
        setCustomNameVisible($$0: boolean): void;
        isAlliedTo($$0: Internal.Team_): boolean;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>): A;
        setOutOfCamera(value: boolean): void;
        getControllingPassenger(): Internal.LivingEntity;
        getRemainingFireTicks(): number;
        getScriptType(): Internal.ScriptType;
        onlyOpCanSetNbt(): boolean;
        startRiding($$0: Internal.Entity_): boolean;
        saveWithoutId($$0: Internal.CompoundTag_): Internal.CompoundTag;
        getForward(): Vec3d;
        tcdcommons_getCustomData(): Internal.GenericProperties<any>;
        fireImmune(): boolean;
        addMotion($$0: number, $$1: number, $$2: number): void;
        getMaxFallDistance(): number;
        getZ($$0: number): number;
        getId(): number;
        pehkui_isFirstUpdate(): boolean;
        canBeHitByProjectile(): boolean;
        getTicksFrozen(): number;
        wrapWithCondition$kom000$porting_lib_entity$port_lib$captureDrops(level: Internal.Level_, entity: Internal.Entity_): boolean;
        getRecipientsForComponentSync(): Internal.Iterable<any>;
        getRandomX($$0: number): number;
        getDynamicLightZ(): number;
        getEyeY(): number;
        spawnAtLocation($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        pick($$0: number, $$1: number, $$2: boolean): Internal.HitResult;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        fabric_readAttachmentsFromNbt(nbt: Internal.CompoundTag_): void;
        getBoundingBox(): Internal.AABB;
        changeDimension(p_20118_: Internal.ServerLevel_, teleporter: Internal.ITeleporter_): Internal.Entity;
        isInWaterOrRain(): boolean;
        isDescending(): boolean;
        emf$getPitch(): number;
        setItemSlot($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_): void;
        getYHeadRot(): number;
        handler$cbi000$besmirchment$isTeammate(other: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>): void;
        equals($$0: any): boolean;
        getViewYRot($$0: number): number;
        fabric_setCustomTeleportTarget(teleportTarget: Internal.PortalInfo_): void;
        dismountsUnderwater(): boolean;
        frameworkGetDataHolder(): com.mrcrayfish.framework.entity.sync.DataHolder;
        playerTouch($$0: Internal.Player_): void;
        addTag($$0: string): boolean;
        getAddEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>;
        getEyeHeight($$0: Internal.Pose_): number;
        syncPacketPositionCodec($$0: number, $$1: number, $$2: number): void;
        callIsBeingRainedOn(): boolean;
        getTeam(): Internal.Team;
        setTransformation($$0: Internal.Transformation_): void;
        shouldRenderAtSqrDistance($$0: number): boolean;
        getAttachedOrSet<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        damageSources(): Internal.DamageSources;
        removeAttached<A>(type: Internal.AttachmentType_<A>): A;
        setTicksFrozen($$0: number): void;
        recreateFromPacket($$0: Internal.ClientboundAddEntityPacket_): void;
        getMyRidingOffset(): number;
        dismountTo($$0: number, $$1: number, $$2: number): void;
        setDeltaMovement($$0: Vec3d_): void;
        getLeashOffset($$0: number): Vec3d;
        etf$getEntityKey(): string;
        etf$getPose(): Internal.Pose;
        hasCustomName(): boolean;
        captureDrops(): Internal.Collection<any>;
        isCulled(): boolean;
        isLiving(): boolean;
        isGlowing(): boolean;
        getX(): number;
        isVehicle(): boolean;
        static transfer(original: Internal.AttachmentTarget_, target: Internal.AttachmentTarget_, isDeath: boolean): void;
        etf$getOptifineId(): number;
        dynamicLightWorld(): Internal.Level;
        getLeashOffset(): Vec3d;
        resetDynamicLight(): void;
        isAttackable(): boolean;
        spawnAtLocation($$0: Internal.ItemStack_): Internal.ItemEntity;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        thunderHit($$0: Internal.ServerLevel_, $$1: Internal.LightningBolt_): void;
        setIsInPowderSnow($$0: boolean): void;
        etf$distanceTo(entity: Internal.Entity_): number;
        doEnchantDamageEffects($$0: Internal.LivingEntity_, $$1: Internal.Entity_): void;
        setCustomName($$0: net.minecraft.network.chat.Component_): void;
        getSlot($$0: number): Internal.SlotAccess;
        lambdynlights$scheduleTrackedChunksRebuild(renderer: Internal.LevelRenderer_): void;
        "deserializeNBT(net.minecraft.nbt.CompoundTag)"(nbt: Internal.CompoundTag_): void;
        emf$isInLava(): boolean;
        pehkui_constructScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        handler$hak000$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        getTeamId(): string;
        stopSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isUnderWater(): boolean;
        stopRiding(): void;
        isCustomNameVisible(): boolean;
        isSupportedBy($$0: BlockPos_): boolean;
        getPistonPushReaction(): Internal.PushReaction;
        getX($$0: number): number;
        lookAt($$0: Internal.EntityAnchorArgument$Anchor_, $$1: Vec3d_): void;
        getLuminance(): number;
        callUnsetRemoved(): void;
        getSelfAndPassengers(): Internal.Stream<any>;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        getDeltaMovement(): Vec3d;
        collide($$0: Vec3d_): Vec3d;
        getMotionX(): number;
        "onSyncedDataUpdated(java.util.List)"($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        hasPassenger($$0: Internal.Entity_): boolean;
        be_getTravelerState(): Internal.TravelerState;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        hasIndirectPassenger($$0: Internal.Entity_): boolean;
        getDynamicLightX(): number;
        getEntityData(): Internal.SynchedEntityData;
        setSecondsOnFire($$0: number): void;
        moveTo($$0: number, $$1: number, $$2: number): void;
        emf$getZ(): number;
        "getDisplayName()"(): net.minecraft.network.chat.Component;
        handleInsidePortal($$0: BlockPos_): void;
        setMotion($$0: number, $$1: number, $$2: number): void;
        playSound($$0: Internal.SoundEvent_): void;
        absMoveTo($$0: number, $$1: number, $$2: number): void;
        isOnRails(): boolean;
        getAttachedOrThrow<A>(type: Internal.AttachmentType_<A>): A;
        handler$ikg000$lithium$tryShortcutFluidPushing(tag: Internal.TagKey_<any>, speed: number, cir: Internal.CallbackInfoReturnable_<any>, box: Internal.AABB_, x1: number, x2: number, y1: number, y2: number, z1: number, z2: number, zero: number): void;
        handler$hak000$gobber2$setFrozenTicks(frozenTicks: number, ci: Internal.CallbackInfo_): void;
        restoreFrom($$0: Internal.Entity_): void;
        markFusionRecomputeModels(): void;
        getDimensionChangingDelay(): number;
        isPeacefulCreature(): boolean;
        setOnGround($$0: boolean): void;
        emf$getYaw(): number;
        handler$cbi000$besmirchment$getScoreboardTeam(cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDynamicLuminance(): number;
        setPos($$0: number, $$1: number, $$2: number): void;
        setYaw($$0: number): void;
        getPickRadius(): number;
        notify(): void;
        getVehicle(): Internal.Entity;
        isEffectiveAi(): boolean;
        handler$kom000$porting_lib_entity$port_lib$startRiding(entity: Internal.Entity_, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        startRiding($$0: Internal.Entity_, $$1: boolean): boolean;
        setBillboardConstraints($$0: Internal.Display$BillboardConstraints_): void;
        getStringUuid(): string;
        isRemoved(): boolean;
        emf$isSneaking(): boolean;
        setSwimming($$0: boolean): void;
        teleportToWithTicket($$0: number, $$1: number, $$2: number): void;
        fillCrashReportCategory($$0: Internal.CrashReportCategory_): void;
        getRotationVector(): Internal.Vec2;
        refreshDimensions(): void;
        pehkui_writeScaleNbt(nbt: Internal.CompoundTag_): Internal.CompoundTag;
        self(): Internal.Entity;
        etf$getBlockY(): number;
        isSprinting(): boolean;
        "spawnAtLocation(net.minecraft.world.level.ItemLike)"($$0: Internal.ItemLike_): Internal.ItemEntity;
        getMotionY(): number;
        canCollideWith($$0: Internal.Entity_): boolean;
        setLuminance(luminance: number): void;
        setShiftKeyDown($$0: boolean): void;
        getEyePosition($$0: number): Vec3d;
        getPassengers(): Internal.EntityArrayList;
        getBlockExplosionResistance($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.FluidState_, $$5: number): number;
        handler$ldh000$puzzleslib$spawnAtLocation(stack: Internal.ItemStack_, offsetY: number, callback: Internal.CallbackInfoReturnable_<any>, itemEntity: Internal.ItemEntity_): void;
        getZ(): number;
        canSpawnSprintParticle(): boolean;
        "moveTo(net.minecraft.core.BlockPos,float,float)"($$0: BlockPos_, $$1: number, $$2: number): void;
        teleportTo($$0: number, $$1: number, $$2: number): void;
        handler$zbk000$porting_lib_base$port_lib$spawnSprintParticle(ci: Internal.CallbackInfo_, pos: BlockPos_, state: Internal.BlockState_): void;
        getServer(): Internal.MinecraftServer;
        moveRelative($$0: number, $$1: Vec3d_): void;
        getFirstPassenger(): Internal.Entity;
        saveAsPassenger($$0: Internal.CompoundTag_): boolean;
        static gatherClosestChunks(chunks: Internal.LongSet_, x: number, y: number, z: number): void;
        handler$kom000$porting_lib_entity$afterSave(nbt: Internal.CompoundTag_, cir: Internal.CallbackInfoReturnable_<any>): void;
        interact($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        getDismountLocationForPassenger($$0: Internal.LivingEntity_): Vec3d;
        checkSlowFallDistance(): void;
        getSoundSource(): Internal.SoundSource;
        setFabricBalmData(tag: Internal.CompoundTag_): void;
        removeAfterChangingDimensions(): void;
        getPose(): Internal.Pose;
        touchingUnloadedChunk(): boolean;
        getLookAngle(): Vec3d;
        setPositionAndRotation($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        emf$isOnFire(): boolean;
        getMotionZ(): number;
        etf$getUuid(): Internal.UUID;
        removeVehicle(): void;
        isInvisible(): boolean;
        shouldFusionRecomputeModel(layerIndex: number): boolean;
        is($$0: Internal.Entity_): boolean;
        orientation(): Quaternionf;
        setZ(z: number): void;
        ejectPassengers(): void;
        getY(): number;
        deserializeNBT(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        updateDynamicLightPreviousCoordinates(): void;
        getProfile(): Internal.GameProfile;
        static setViewScale($$0: number): void;
        emf$isAlive(): boolean;
        setLevelCallback($$0: Internal.EntityInLevelCallback_): void;
        showVehicleHealth(): boolean;
        getDistance(pos: BlockPos_): number;
        playSound($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        emf$getVelocity(): Vec3d;
        etf$isBlockEntity(): boolean;
        shouldUpdateDynamicLight(): boolean;
        static getDataTransformationInterpolationDurationId(): Internal.EntityDataAccessor<number>;
        startSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isOnScoreboardTeam(teamId: string): boolean;
        isPushedByFluid(): boolean;
        localvar$bbb000$architectury$modifyLevelCallback_setLevelCallback(callback: Internal.EntityInLevelCallback_): Internal.EntityInLevelCallback;
        position(): Vec3d;
        setTimeout(): void;
        displayFireAnimation(): boolean;
        turn($$0: number, $$1: number): void;
        isOutOfCamera(): boolean;
        getAirSupply(): number;
        getRopeHoldPosition($$0: number): Vec3d;
        copyPosition($$0: Internal.Entity_): void;
        "hasPassenger(net.minecraft.world.entity.Entity)"($$0: Internal.Entity_): boolean;
        etf$canBeBright(): boolean;
        isCrouching(): boolean;
        moveTo($$0: BlockPos_, $$1: number, $$2: number): void;
        isPlayer(): boolean;
        isAnimal(): boolean;
        "handler$fgd000$fabric-dimensions-v1$getTeleportTarget"(destination: Internal.ServerLevel_, cir: Internal.CallbackInfoReturnable_<any>): void;
        canBeCollidedWith(): boolean;
        getMotionDirection(): Internal.Direction;
        asComponentProvider(): Internal.ComponentProvider;
        setY(y: number): void;
        getFeetBlockState(): Internal.BlockState;
        lavaHurt(): void;
        handleDamageEvent($$0: DamageSource_): void;
        setViewRange($$0: number): void;
        getFabricBalmData(): Internal.CompoundTag;
        canChangeDimensions(): boolean;
        getChangeListener(): Internal.EntityInLevelCallback;
        static tickEntity(entity: Internal.Entity_): void;
        getCommandSenderWorld(): Internal.Level;
        positionRider($$0: Internal.Entity_): void;
        baseTick(): void;
        broadcastToPlayer($$0: Internal.ServerPlayer_): boolean;
        changeDimension($$0: Internal.ServerLevel_): Internal.Entity;
        setSharedFlag($$0: number, $$1: boolean): void;
        handler$kom000$porting_lib_entity$afterLoad(nbt: Internal.CompoundTag_, ci: Internal.CallbackInfo_): void;
        getCustomName(): net.minecraft.network.chat.Component;
        getClass(): typeof any;
        pehkui_shouldIgnoreScaleNbt(): boolean;
        isMoving(): boolean;
        isVisuallySwimming(): boolean;
        getMaxAirSupply(): number;
        attack(hp: number): void;
        dynamicLightTick(): void;
        getFacing(): Internal.Direction;
        emf$isWet(): boolean;
        "hasPassenger(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.Entity>): boolean;
        getDimensions($$0: Internal.Pose_): Internal.EntityDimensions;
        isPassengerOfSameVehicle($$0: Internal.Entity_): boolean;
        invokeGetLeashOffset(): Vec3d;
        getBoundingBoxForCulling(): Internal.AABB;
        isSwimming(): boolean;
        mayInteract($$0: Internal.Level_, $$1: BlockPos_): boolean;
        static collideBoundingBox(entity: Internal.Entity_, movement: Vec3d_, entityBoundingBox: Internal.AABB_, world: Internal.Level_, collisions: Internal.List_<any>): Vec3d;
        setSprinting($$0: boolean): void;
        getDynamicLightLevel(): Internal.Level;
        setPortalCooldown(): void;
        setX(x: number): void;
        trackingPosition(): Vec3d;
        getNameTagOffsetY(): number;
        isInvulnerable(): boolean;
        isInLava(): boolean;
        isInWater(): boolean;
        getPortalWaitTime(): number;
        awardKillScore($$0: Internal.Entity_, $$1: number, $$2: DamageSource_): void;
        getBlockStateOn(): Internal.BlockState;
        getFluidHeightLoosely(tag: Internal.TagKey_<any>): number;
        getFluidJumpThreshold(): number;
        unsetRemoved(): void;
        "setPositionAndRotation(double,double,double,float,float)"(x: number, y: number, z: number, yaw: number, pitch: number): void;
        isInvisibleTo($$0: Internal.Player_): boolean;
        pehkui_getScaleCache(): Internal.ScaleData[];
        setFusionModel(layerIndex: number, model: Internal.Triple_<any, any, any>): void;
        setAirSupply($$0: number): void;
        renderState(): Internal.Display$RenderState;
        getOnPos(): BlockPos;
        getRootVehicle(): Internal.Entity;
        etf$getWorld(): Internal.Level;
        save($$0: Internal.CompoundTag_): boolean;
        pehkui_getScales(): Internal.Map<any, any>;
        isNoGravity(): boolean;
        etf$getNbt(): Internal.CompoundTag;
        acceptsFailure(): boolean;
        etf$getBlockPos(): BlockPos;
        pehkui_setShouldIgnoreScaleNbt(ignore: boolean): void;
        setOnGroundWithKnownMovement($$0: boolean, $$1: Vec3d_): void;
        setOldPosAndRot(): void;
        emf$getY(): number;
        handler$kom000$porting_lib_entity$port_lib$entityInit(entityType: Internal.EntityType_<any>, world: Internal.Level_, ci: Internal.CallbackInfo_): void;
        bookshelf$createHoverEvent(): Internal.HoverEvent;
        isFree($$0: number, $$1: number, $$2: number): boolean;
        updateSwimming(): void;
        "moveTo(double,double,double)"($$0: number, $$1: number, $$2: number): void;
        setRemainingFireTicks($$0: number): void;
        getCachedFeetBlockState(): Internal.BlockState;
        shouldInformAdmins(): boolean;
        rideTick(): void;
        emf$age(): number;
        etf$hasCustomName(): boolean;
        /**
         * @deprecated
        */
        getOnPosLegacy(): BlockPos;
        setPos($$0: Vec3d_): void;
        wait(): void;
        getUuid(): Internal.UUID;
        spawn(): void;
        teleportTo($$0: Internal.ServerLevel_, $$1: number, $$2: number, $$3: number, $$4: Internal.Set_<Internal.RelativeMovement>, $$5: number, $$6: number): boolean;
        handler$kom000$porting_lib_entity$port_lib$removeRidingEntity(ci: Internal.CallbackInfo_): void;
        etf$getCustomName(): net.minecraft.network.chat.Component;
        captureDrops(value: Internal.Collection_<any>): Internal.Collection<any>;
        fabric_writeAttachmentsToNbt(nbt: Internal.CompoundTag_): void;
        shouldShowName(): boolean;
        setSilent($$0: boolean): void;
        getArmorSlots(): Internal.Iterable<Internal.ItemStack>;
        hasExactlyOnePlayerPassenger(): boolean;
        kill(): void;
        isOnPortalCooldown(): boolean;
        animateHurt($$0: number): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        handler$kom000$porting_lib_entity$port_lib$onEntityRemove(reason: Internal.Entity$RemovalReason_, ci: Internal.CallbackInfo_): void;
        lambdynlights$setTrackedLitChunkPos(trackedLitChunkPos: Internal.LongSet_): void;
        setPitch($$0: number): void;
        callGetEyeHeight(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        setPosRaw($$0: number, $$1: number, $$2: number): void;
        handleEntityEvent($$0: number): void;
        isAlwaysTicking(): boolean;
        interactAt($$0: Internal.Player_, $$1: Vec3d_, $$2: Internal.InteractionHand_): Internal.InteractionResult;
        emf$getX(): number;
        deserializeNBT(arg0: Internal.Tag_): void;
        puzzleslib$acceptCapturedDrops(capturedDrops: Internal.Collection_<any>): Internal.Collection<any>;
        handler$hak000$gobber2$gobberIsFireImmune(cir: Internal.CallbackInfoReturnable_<any>): void;
        lerpTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: boolean): void;
        onPassengerTurned($$0: Internal.Entity_): void;
        modifyReturnValue$zhe000$additionalentityattributes$getMaxAir(original: number): number;
        spawnAtLocation($$0: Internal.ItemLike_): Internal.ItemEntity;
        emf$hasPassengers(): boolean;
        serializeNBT(): Internal.CompoundTag;
        setAttached(type: Internal.AttachmentType_<any>, value: any): any;
        getBbWidth(): number;
        splitIntoDynamicLightEntries(): Internal.Stream<Internal.SpatialLookupEntry>;
        port_lib$getEntityString(): string;
        addDeltaMovement($$0: Vec3d_): void;
        pehkui_setOnGround(onGround: boolean): void;
        lithiumOnBlockCacheDeleted(): void;
        static getDataTransformationInterpolationDurationId$axiom_$md$424943$0(): Internal.EntityDataAccessor<any>;
        "spawnAtLocation(net.minecraft.world.level.ItemLike,int)"($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        setInvulnerable($$0: boolean): void;
        "getName()"(): net.minecraft.network.chat.Component;
        push($$0: Internal.Entity_): void;
        emf$hasVehicle(): boolean;
        mirror($$0: Internal.Mirror_): number;
        static port_lib$collideWithShapes(vec3: Vec3d_, aABB: Internal.AABB_, list: Internal.List_<Internal.VoxelShape>): Vec3d;
        getTicksRequiredToFreeze(): number;
        getDynamicLightPrevY(): number;
        maxUpStep(): number;
        setGlowing($$0: boolean): void;
        load($$0: Internal.CompoundTag_): void;
        isAlive(): boolean;
        emf$prevZ(): number;
        getBbHeight(): number;
        getUsername(): string;
        calculateInterpolationProgress($$0: number): number;
        move($$0: Internal.MoverType_, $$1: Vec3d_): void;
        getTags(): Internal.Set<string>;
        getViewVector($$0: number): Vec3d;
        lithiumOnBlockCacheSet(newState: Internal.BlockState_): void;
        isPickable(): boolean;
        setYHeadRot($$0: number): void;
        hasControllingPassenger(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number, $$2: number): boolean;
        absMoveTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        getCustomData(): Internal.CompoundTag;
        getPickResult(): Internal.ItemStack;
        getPercentFrozen(): number;
        getRandomY(): number;
        setPortalCooldown($$0: number): void;
        getDisplayName(): net.minecraft.network.chat.Component;
        hasGlowingTag(): boolean;
        shouldBlockExplode($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: number): boolean;
        emf$isInvisible(): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        emf$isSprinting(): boolean;
        getDynamicLightPrevX(): number;
        shouldBeSaved(): boolean;
        fabric_hasPersistentAttachments(): boolean;
        getViewXRot($$0: number): number;
        canRiderInteract(): boolean;
        fabric_getAttachments(): Internal.Map<any, any>;
        removeTag($$0: string): boolean;
        setPose($$0: Internal.Pose_): void;
        getFluidHeight($$0: Internal.TagKey_<Internal.Fluid>): number;
        getPackedBrightnessOverride(): number;
        getEntityType(): Internal.EntityType<any>;
        isWaterCreature(): boolean;
        pehkui_getScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        toString(): string;
        notifyAll(): void;
        getPassengersRidingOffset(): number;
        etf$getScoreboardTeam(): Internal.Team;
        distanceToEntitySqr($$0: Internal.Entity_): number;
        handler$ldh000$puzzleslib$removeVehicle(callback: Internal.CallbackInfo_): void;
        "getServer()"(): Internal.MinecraftServer;
        isFrame(): boolean;
        isPushable(): boolean;
        setYBodyRot($$0: number): void;
        discard(): void;
        onClientRemoval(): void;
        "handler$mhe000$step-height-entity-attribute$getStepHeight"(cir: Internal.CallbackInfoReturnable_<any>): void;
        sendSystemMessage($$0: net.minecraft.network.chat.Component_): void;
        acceptsSuccess(): boolean;
        getDistance(x: number, y: number, z: number): number;
        setMotionY(y: number): void;
        setNoGravity($$0: boolean): void;
        getAttached(type: Internal.AttachmentType_<any>): any;
        getIndirectPassengers(): Internal.Iterable<any>;
        setRotation(yaw: number, pitch: number): void;
        isDynamicLightEnabled(): boolean;
        handler$ldh000$puzzleslib$startRiding(vehicle: Internal.Entity_, force: boolean, callback: Internal.CallbackInfoReturnable_<any>): void;
        createCommandSourceStack(): Internal.CommandSourceStack;
        isControlledByLocalInstance(): boolean;
        isMonster(): boolean;
        pehkui_setShouldSyncScales(sync: boolean): void;
        setLastDynamicLuminance(luminance: number): void;
        setId($$0: number): void;
        onSyncedDataUpdated($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        getHorizontalFacing(): Internal.Direction;
        getType(): string;
        getLightProbePosition($$0: number): Vec3d;
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        onAboveBubbleCol($$0: boolean): void;
        emf$prevX(): number;
        "playSound(net.minecraft.sounds.SoundEvent,float,float)"($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        toComponentPacket(key: Internal.ComponentKey_<any>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        isPassenger(): boolean;
        hasPose($$0: Internal.Pose_): boolean;
        checkDespawn(): void;
        pehkui_shouldSyncScales(): boolean;
        isEyeInFluid($$0: Internal.TagKey_<Internal.Fluid>): boolean;
        isInvulnerableTo($$0: DamageSource_): boolean;
        makeStuckInBlock($$0: Internal.BlockState_, $$1: Vec3d_): void;
        getAttachedOrGet<A>(type: Internal.AttachmentType_<A>, defaultValue: Internal.Supplier_<A>): A;
        skipAttackInteraction($$0: Internal.Entity_): boolean;
        lerpMotion($$0: number, $$1: number, $$2: number): void;
        shouldRender($$0: number, $$1: number, $$2: number): boolean;
        onSyncedDataUpdated($$0: Internal.EntityDataAccessor_<any>): void;
        lerpHeadTo($$0: number, $$1: number): void;
        handler$bia000$axiom$onTurn(d: number, e: number, ci: Internal.CallbackInfo_): void;
        static getViewScale(): number;
        setMotionX(x: number): void;
        getHandSlots(): Internal.Iterable<Internal.ItemStack>;
        distanceToEntity($$0: Internal.Entity_): number;
        getVisualRotationYInDegrees(): number;
        wait(arg0: number, arg1: number): void;
        getTeamColor(): number;
        isDiscrete(): boolean;
        setNbt(nbt: Internal.CompoundTag_): void;
        lithiumSetClimbingMobCachingSectionUpdateBehavior(listening: boolean): void;
        unRide(): void;
        getLevel(): Internal.Level;
        "spawnAtLocation(net.minecraft.world.item.ItemStack)"($$0: Internal.ItemStack_): Internal.ItemEntity;
        lambdynlights$getTrackedLitChunkPos(): Internal.LongSet;
        extinguish(): void;
        setDynamicLightEnabled(enabled: boolean): void;
        updateDynamicGameEventListener($$0: Internal.BiConsumer_<Internal.DynamicGameEventListener<any>, Internal.ServerLevel>): void;
        moveTo($$0: Vec3d_): void;
        isColliding($$0: BlockPos_, $$1: Internal.BlockState_): boolean;
        "onSyncedDataUpdated(net.minecraft.network.syncher.EntityDataAccessor)"($$0: Internal.EntityDataAccessor_<any>): void;
        emf$prevY(): number;
        extinguishFire(): void;
        lambdynlights$updateDynamicLight(renderer: Internal.LevelRenderer_): boolean;
        tell(message: net.minecraft.network.chat.Component_): void;
        static port_lib$collideWithShapes$porting_lib_accessors_$md$424943$0(arg0: Vec3d_, arg1: Internal.AABB_, arg2: Internal.List_<any>): Vec3d;
        isForcedVisible(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number): boolean;
        getDistanceSq(pos: BlockPos_): number;
        emf$getTypeString(): string;
        killedEntity($$0: Internal.ServerLevel_, $$1: Internal.LivingEntity_): boolean;
        getAttachedOrElse<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        isFreezing(): boolean;
        isFullyFrozen(): boolean;
        runCommand(command: string): number;
        setSharedFlagOnFire($$0: boolean): void;
        get inWall(): boolean
        get allSlots(): Internal.Iterable<Internal.ItemStack>
        get blockZ(): number
        get suppressingBounce(): boolean
        get silent(): boolean
        set culled(value: boolean)
        get pitch(): number
        get onFire(): boolean
        get positionCodec(): Internal.VecDeltaCodec
        get passengersAndSelf(): Internal.Stream<any>
        set maxUpStep($$0: number)
        get shiftKeyDown(): boolean
        set UUID($$0: Internal.UUID_)
        get visuallyCrawling(): boolean
        set motionZ(z: number)
        get blockY(): number
        get isInsideStructureTracker(): Internal.IsInsideStructureTracker
        get spectator(): boolean
        get inWaterOrBubble(): boolean
        get persistentData(): Internal.CompoundTag
        get portalCooldown(): number
        get item(): Internal.ItemStack
        set removed($$0: Internal.Entity$RemovalReason_)
        get inWaterRainOrBubble(): boolean
        get removalReason(): Internal.Entity$RemovalReason
        get ignoringBlockTriggers(): boolean
        get steppingCarefully(): boolean
        set boundingBox($$0: Internal.AABB_)
        get ambientCreature(): boolean
        get blockX(): number
        /**
         * @deprecated
        */
        get lightLevelDependentMagicValue(): number
        get encodeId(): string
        get block(): Internal.BlockContainerJS
        get nbt(): Internal.CompoundTag
        set invisible($$0: boolean)
        get name(): net.minecraft.network.chat.Component
        get dynamicLightY(): number
        get controlledVehicle(): Internal.Entity
        get eyePosition(): Vec3d
        get eyeHeight(): number
        get yaw(): number
        get componentContainer(): Internal.ComponentContainer
        get dynamicLightPrevZ(): number
        set customNameVisible($$0: boolean)
        set outOfCamera(value: boolean)
        get controllingPassenger(): Internal.LivingEntity
        get remainingFireTicks(): number
        get scriptType(): Internal.ScriptType
        get forward(): Vec3d
        get maxFallDistance(): number
        get id(): number
        get ticksFrozen(): number
        get recipientsForComponentSync(): Internal.Iterable<any>
        get dynamicLightZ(): number
        get eyeY(): number
        set statusMessage(message: net.minecraft.network.chat.Component_)
        get boundingBox(): Internal.AABB
        get inWaterOrRain(): boolean
        get descending(): boolean
        get YHeadRot(): number
        get addEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>
        get team(): Internal.Team
        set transformation($$0: Internal.Transformation_)
        set ticksFrozen($$0: number)
        get myRidingOffset(): number
        set deltaMovement($$0: Vec3d_)
        get culled(): boolean
        get living(): boolean
        get glowing(): boolean
        get x(): number
        get vehicle(): boolean
        get leashOffset(): Vec3d
        get attackable(): boolean
        set isInPowderSnow($$0: boolean)
        set customName($$0: net.minecraft.network.chat.Component_)
        get teamId(): string
        get underWater(): boolean
        get customNameVisible(): boolean
        get pistonPushReaction(): Internal.PushReaction
        get luminance(): number
        get selfAndPassengers(): Internal.Stream<any>
        get deltaMovement(): Vec3d
        get motionX(): number
        get dynamicLightX(): number
        get entityData(): Internal.SynchedEntityData
        set secondsOnFire($$0: number)
        get "displayName()"(): net.minecraft.network.chat.Component
        get onRails(): boolean
        get dimensionChangingDelay(): number
        get peacefulCreature(): boolean
        set onGround($$0: boolean)
        get lastDynamicLuminance(): number
        set yaw($$0: number)
        get pickRadius(): number
        get vehicle(): Internal.Entity
        get effectiveAi(): boolean
        set billboardConstraints($$0: Internal.Display$BillboardConstraints_)
        get stringUuid(): string
        get removed(): boolean
        set swimming($$0: boolean)
        get rotationVector(): Internal.Vec2
        get sprinting(): boolean
        get motionY(): number
        set luminance(luminance: number)
        set shiftKeyDown($$0: boolean)
        get passengers(): Internal.EntityArrayList
        get z(): number
        get server(): Internal.MinecraftServer
        get firstPassenger(): Internal.Entity
        get soundSource(): Internal.SoundSource
        set fabricBalmData(tag: Internal.CompoundTag_)
        get pose(): Internal.Pose
        get lookAngle(): Vec3d
        get motionZ(): number
        get invisible(): boolean
        set z(z: number)
        get y(): number
        get profile(): Internal.GameProfile
        set viewScale($$0: number)
        set levelCallback($$0: Internal.EntityInLevelCallback_)
        get dataTransformationInterpolationDurationId(): Internal.EntityDataAccessor<number>
        get pushedByFluid(): boolean
        get outOfCamera(): boolean
        get airSupply(): number
        get crouching(): boolean
        get player(): boolean
        get animal(): boolean
        get motionDirection(): Internal.Direction
        set y(y: number)
        get feetBlockState(): Internal.BlockState
        set viewRange($$0: number)
        get fabricBalmData(): Internal.CompoundTag
        get changeListener(): Internal.EntityInLevelCallback
        get commandSenderWorld(): Internal.Level
        get customName(): net.minecraft.network.chat.Component
        get class(): typeof any
        get moving(): boolean
        get visuallySwimming(): boolean
        get maxAirSupply(): number
        get facing(): Internal.Direction
        get boundingBoxForCulling(): Internal.AABB
        get swimming(): boolean
        set sprinting($$0: boolean)
        get dynamicLightLevel(): Internal.Level
        set x(x: number)
        get nameTagOffsetY(): number
        get invulnerable(): boolean
        get inLava(): boolean
        get inWater(): boolean
        get portalWaitTime(): number
        get blockStateOn(): Internal.BlockState
        get fluidJumpThreshold(): number
        set airSupply($$0: number)
        get onPos(): BlockPos
        get rootVehicle(): Internal.Entity
        get noGravity(): boolean
        set remainingFireTicks($$0: number)
        get cachedFeetBlockState(): Internal.BlockState
        /**
         * @deprecated
        */
        get onPosLegacy(): BlockPos
        set pos($$0: Vec3d_)
        get uuid(): Internal.UUID
        set silent($$0: boolean)
        get armorSlots(): Internal.Iterable<Internal.ItemStack>
        get onPortalCooldown(): boolean
        set pitch($$0: number)
        get alwaysTicking(): boolean
        get bbWidth(): number
        get dataTransformationInterpolationDurationId$axiom_$md$424943$0(): Internal.EntityDataAccessor<any>
        set invulnerable($$0: boolean)
        get "name()"(): net.minecraft.network.chat.Component
        get ticksRequiredToFreeze(): number
        get dynamicLightPrevY(): number
        set glowing($$0: boolean)
        get alive(): boolean
        get bbHeight(): number
        get username(): string
        get tags(): Internal.Set<string>
        get pickable(): boolean
        set YHeadRot($$0: number)
        get customData(): Internal.CompoundTag
        get pickResult(): Internal.ItemStack
        get percentFrozen(): number
        get randomY(): number
        set portalCooldown($$0: number)
        get displayName(): net.minecraft.network.chat.Component
        set position(block: Internal.BlockContainerJS_)
        get dynamicLightPrevX(): number
        set pose($$0: Internal.Pose_)
        get packedBrightnessOverride(): number
        get entityType(): Internal.EntityType<any>
        get waterCreature(): boolean
        get passengersRidingOffset(): number
        get "server()"(): Internal.MinecraftServer
        get frame(): boolean
        get pushable(): boolean
        set YBodyRot($$0: number)
        set motionY(y: number)
        set noGravity($$0: boolean)
        get indirectPassengers(): Internal.Iterable<any>
        get dynamicLightEnabled(): boolean
        get controlledByLocalInstance(): boolean
        get monster(): boolean
        set lastDynamicLuminance(luminance: number)
        set id($$0: number)
        get horizontalFacing(): Internal.Direction
        get type(): string
        get passenger(): boolean
        get viewScale(): number
        set motionX(x: number)
        get handSlots(): Internal.Iterable<Internal.ItemStack>
        get visualRotationYInDegrees(): number
        get teamColor(): number
        get discrete(): boolean
        set nbt(nbt: Internal.CompoundTag_)
        get level(): Internal.Level
        set dynamicLightEnabled(enabled: boolean)
        get forcedVisible(): boolean
        get freezing(): boolean
        get fullyFrozen(): boolean
        set sharedFlagOnFire($$0: boolean)
        static readonly DATA_SHADOW_RADIUS_ID: Internal.EntityDataAccessor<number>;
        static readonly TAG_BILLBOARD: ("billboard") & (string);
        static readonly DATA_LEFT_ROTATION_ID: Internal.EntityDataAccessor<Quaternionf>;
        static readonly NO_BRIGHTNESS_OVERRIDE: (-1) & (number);
        static readonly DATA_RIGHT_ROTATION_ID: Internal.EntityDataAccessor<Quaternionf>;
        static readonly DATA_HEIGHT_ID: Internal.EntityDataAccessor<number>;
        static readonly TAG_HEIGHT: ("height") & (string);
        static readonly TAG_BRIGHTNESS: ("brightness") & (string);
        static readonly TAG_SHADOW_STRENGTH: ("shadow_strength") & (string);
        static readonly TAG_WIDTH: ("width") & (string);
        static readonly DATA_SCALE_ID: Internal.EntityDataAccessor<Vec3f>;
        static readonly DATA_TRANSLATION_ID: Internal.EntityDataAccessor<Vec3f>;
        static readonly DATA_GLOW_COLOR_OVERRIDE_ID: Internal.EntityDataAccessor<number>;
        static readonly TAG_TRANSFORMATION: ("transformation") & (string);
        static readonly DATA_VIEW_RANGE_ID: Internal.EntityDataAccessor<number>;
        static readonly TAG_START_INTERPOLATION: ("start_interpolation") & (string);
        static readonly TAG_GLOW_COLOR_OVERRIDE: ("glow_color_override") & (string);
        static readonly TAG_SHADOW_RADIUS: ("shadow_radius") & (string);
        static readonly DATA_BRIGHTNESS_OVERRIDE_ID: Internal.EntityDataAccessor<number>;
        static readonly TAG_INTERPOLATION_DURATION: ("interpolation_duration") & (string);
        static readonly DATA_SHADOW_STRENGTH_ID: Internal.EntityDataAccessor<number>;
        static readonly DATA_WIDTH_ID: Internal.EntityDataAccessor<number>;
        static readonly TAG_VIEW_RANGE: ("view_range") & (string);
        static readonly DATA_BILLBOARD_RENDER_CONSTRAINTS_ID: Internal.EntityDataAccessor<number>;
    }
    type Display_ = Display;
    interface SignalGetter extends Internal.BlockGetter {
        getControlInputSignal($$0: BlockPos_, $$1: Internal.Direction_, $$2: boolean): number;
        getMinSection(): number;
        getSignal($$0: BlockPos_, $$1: Internal.Direction_): number;
        abstract getBlockState(arg0: BlockPos_): Internal.BlockState;
        getBestNeighborSignal($$0: BlockPos_): number;
        clipWithInteractionOverride($$0: Vec3d_, $$1: Vec3d_, $$2: BlockPos_, $$3: Internal.VoxelShape_, $$4: Internal.BlockState_): Internal.BlockHitResult;
        getSectionIndex($$0: number): number;
        getDirectSignalTo($$0: BlockPos_): number;
        getMaxSection(): number;
        getMaxBuildHeight(): number;
        getBlockEntityRenderData(pos: BlockPos_): any;
        hasNeighborSignal($$0: BlockPos_): boolean;
        getBiomeFabric(pos: BlockPos_): Internal.Holder<Internal.Biome>;
        getLightEmission($$0: BlockPos_): number;
        getBlockFloorHeight($$0: BlockPos_): number;
        getSectionYFromSectionIndex($$0: number): number;
        create($$0: number, $$1: number): Internal.LevelHeightAccessor;
        hasSignal($$0: BlockPos_, $$1: Internal.Direction_): boolean;
        "isOutsideBuildHeight(int)"($$0: number): boolean;
        getDirectSignal($$0: BlockPos_, $$1: Internal.Direction_): number;
        clip($$0: Internal.ClipContext_): Internal.BlockHitResult;
        getBlockFloorHeight($$0: Internal.VoxelShape_, $$1: Internal.Supplier_<Internal.VoxelShape>): number;
        abstract getBlockEntity(arg0: BlockPos_): Internal.BlockEntity;
        abstract getHeight(): number;
        getBlockEntity<T extends Internal.BlockEntity>($$0: BlockPos_, $$1: Internal.BlockEntityType_<T>): Optional<T>;
        isOutsideBuildHeight($$0: BlockPos_): boolean;
        isOutsideBuildHeight($$0: number): boolean;
        isBlockInLine($$0: Internal.ClipBlockStateContext_): Internal.BlockHitResult;
        abstract getFluidState(arg0: BlockPos_): Internal.FluidState;
        "isOutsideBuildHeight(net.minecraft.core.BlockPos)"($$0: BlockPos_): boolean;
        getBlockStates($$0: Internal.AABB_): Internal.Stream<Internal.BlockState>;
        getSectionsCount(): number;
        abstract getMinBuildHeight(): number;
        hasBiomes(): boolean;
        getMaxLightLevel(): number;
        getSectionIndexFromSectionY($$0: number): number;
        traverseBlocks<T, C>($$0: Vec3d_, $$1: Vec3d_, $$2: C, $$3: Internal.BiFunction_<C, BlockPos, T>, $$4: Internal.Function_<C, T>): T;
        get minSection(): number
        get maxSection(): number
        get maxBuildHeight(): number
        get height(): number
        get sectionsCount(): number
        get minBuildHeight(): number
        get maxLightLevel(): number
        readonly DIRECTIONS: Internal.Direction[];
    }
    type SignalGetter_ = SignalGetter;
    class FoodBuilder {
        constructor()
        constructor(properties: Internal.FoodProperties_)
        getClass(): typeof any;
        /**
         * Sets the hunger restored.
        */
        hunger(h: number): this;
        toString(): string;
        /**
         * Sets the saturation modifier. Note that the saturation restored is hunger * saturation.
        */
        saturation(s: number): this;
        notifyAll(): void;
        build(): Internal.FoodProperties;
        effect(mobEffectId: Special.MobEffect, duration: number, amplifier: number, probability: number): this;
        /**
         * Sets whether the food is meat.
        */
        meat(flag: boolean): this;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        /**
         * Sets whether the food is fast to eat (having half of the eating time).
        */
        fastToEat(flag: boolean): this;
        hashCode(): number;
        /**
         * Sets whether the food is always edible.
        */
        alwaysEdible(flag: boolean): this;
        wait(): void;
        wait(arg0: number): void;
        /**
         * Sets the food is always edible.
        */
        alwaysEdible(): this;
        equals(arg0: any): boolean;
        /**
         * Sets the food is meat.
        */
        meat(): this;
        /**
         * Sets a callback that is called when the food is eaten.
         * 
         * Note: This is currently not having effect in `ItemEvents.modification`,
         * as firing this callback requires an `ItemBuilder` instance in the `Item`.
        */
        eaten(e: Internal.Consumer_<Internal.FoodEatenEventJS>): this;
        /**
         * Sets the food is fast to eat (having half of the eating time).
        */
        fastToEat(): this;
        /**
         * Removes an effect from the food.
        */
        removeEffect(mobEffect: Internal.MobEffect_): this;
        get class(): typeof any
        eaten: Internal.Consumer<Internal.FoodEatenEventJS>;
    }
    type FoodBuilder_ = FoodBuilder;
    interface LootTableBuilderAccessor {
        abstract getPools(): Internal.List<Internal.LootPool>;
        abstract getFunctions(): Internal.List<Internal.LootItemFunction>;
        get pools(): Internal.List<Internal.LootPool>
        get functions(): Internal.List<Internal.LootItemFunction>
    }
    type LootTableBuilderAccessor_ = LootTableBuilderAccessor;
    interface FishingBobberEntityAccessor {
        abstract getLuckOfTheSeaLevel(): number;
        abstract getLureLevel(): number;
        abstract setLuckOfTheSeaLevel(arg0: number): void;
        abstract setLureLevel(arg0: number): void;
        get luckOfTheSeaLevel(): number
        get lureLevel(): number
        set luckOfTheSeaLevel(arg0: number)
        set lureLevel(arg0: number)
    }
    type FishingBobberEntityAccessor_ = FishingBobberEntityAccessor;
    class CrimsonPendantItem extends Internal.BaubleItem {
        constructor(props: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        hasRender(stack: Internal.ItemStack_, living: Internal.LivingEntity_): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, world: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, flags: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        hasPhantomInk(stack: Internal.ItemStack_): boolean;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static onDamage(entity: Internal.LivingEntity_, source: DamageSource_): boolean;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        canEquip(stack: Internal.ItemStack_, entity: Internal.LivingEntity_): boolean;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        getEquippedAttributeModifiers(stack: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        onWornTick(stack: Internal.ItemStack_, living: Internal.LivingEntity_): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setCosmeticItem(stack: Internal.ItemStack_, cosmetic: Internal.ItemStack_): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        onEquipped(stack: Internal.ItemStack_, entity: Internal.LivingEntity_): void;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        setPhantomInk(stack: Internal.ItemStack_, ink: boolean): void;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        onUnequipped(stack: Internal.ItemStack_, entity: Internal.LivingEntity_): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        static getBaubleUUID(stack: Internal.ItemStack_): Internal.UUID;
        getCosmeticItem(stack: Internal.ItemStack_): Internal.ItemStack;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type CrimsonPendantItem_ = CrimsonPendantItem;
    class IntegerArgumentType implements Internal.ArgumentType<number> {
        getClass(): typeof any;
        static integer(arg0: number, arg1: number): Internal.IntegerArgumentType;
        getMaximum(): number;
        toString(): string;
        notifyAll(): void;
        listSuggestions<S>(arg0: Internal.CommandContext_<S>, arg1: Internal.SuggestionsBuilder_): Internal.CompletableFuture<Internal.Suggestions>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        static integer(arg0: number): Internal.IntegerArgumentType;
        static integer(): Internal.IntegerArgumentType;
        getExamples(): Internal.Collection<string>;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        getMinimum(): number;
        equals(arg0: any): boolean;
        static getInteger(arg0: Internal.CommandContext_<any>, arg1: string): number;
        parse(arg0: Internal.StringReader_): any;
        get class(): typeof any
        get maximum(): number
        get examples(): Internal.Collection<string>
        get minimum(): number
    }
    type IntegerArgumentType_ = IntegerArgumentType;
    interface FabricLootTableBuilder {
        pools(pools: Internal.Collection_<Internal.LootPool>): Internal.LootTable$Builder;
        modifyPools(modifier: Internal.Consumer_<Internal.LootPool$Builder>): Internal.LootTable$Builder;
        apply(function_: Internal.LootItemFunction_): Internal.LootTable$Builder;
        "apply(net.minecraft.world.level.storage.loot.functions.LootItemFunction)"(function_: Internal.LootItemFunction_): Internal.LootTable$Builder;
        pool(pool: Internal.LootPool_): Internal.LootTable$Builder;
        apply(functions: Internal.Collection_<Internal.LootItemFunction>): Internal.LootTable$Builder;
        "apply(java.util.Collection)"(functions: Internal.Collection_<Internal.LootItemFunction>): Internal.LootTable$Builder;
        copyOf(table: Internal.LootTable_): Internal.LootTable$Builder;
    }
    type FabricLootTableBuilder_ = FabricLootTableBuilder;
    class Climate$ParameterList <T> implements Internal.IExtendedParameterList<any> {
        constructor($$0: Internal.List_<com.mojang.datafixers.util.Pair<Internal.Climate$ParameterPoint, T>>)
        findValuePositional(target: Internal.Climate$TargetPoint_, x: number, y: number, z: number): any;
        getUniqueness(x: number, y: number, z: number): number;
        getClass(): typeof any;
        toString(): string;
        values(): Internal.List<com.mojang.datafixers.util.Pair<Internal.Climate$ParameterPoint, T>>;
        notifyAll(): void;
        findValueIndex($$0: Internal.Climate$TargetPoint_): T;
        notify(): void;
        findValueBruteForce($$0: Internal.Climate$TargetPoint_): T;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        getTreeCount(): number;
        isInitialized(): boolean;
        static codec<T>($$0: Internal.MapCodec_<T>): Internal.Codec<Internal.Climate$ParameterList<T>>;
        initializeForTerraBlender(registryAccess: Internal.RegistryAccess_, regionType: Internal.RegionType_, seed: number): void;
        wait(): void;
        wait(arg0: number): void;
        getTree(uniqueness: number): Internal.Climate$RTree<any>;
        equals(arg0: any): boolean;
        findValue($$0: Internal.Climate$TargetPoint_): T;
        get class(): typeof any
        get treeCount(): number
        get initialized(): boolean
    }
    type Climate$ParameterList_<T> = Climate$ParameterList<T>;
    class Rarity extends Internal.Enum<Internal.Rarity> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.Rarity>>;
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        "compareTo(net.minecraft.world.item.Rarity)"(arg0: Internal.Rarity_): number;
        notify(): void;
        static values(): Internal.Rarity[];
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        name(): string;
        hashCode(): number;
        static valueOf($$0: string): Internal.Rarity;
        ordinal(): number;
        wait(): void;
        getDeclaringClass(): typeof Internal.Rarity;
        wait(arg0: number): void;
        compareTo(arg0: Internal.Rarity_): number;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        get class(): typeof any
        get declaringClass(): typeof Internal.Rarity
        static readonly COMMON: (Internal.Rarity) & (Internal.Rarity);
        readonly color: Internal.ChatFormatting;
        static readonly UNCOMMON: (Internal.Rarity) & (Internal.Rarity);
        static readonly EPIC: (Internal.Rarity) & (Internal.Rarity);
        static readonly RARE: (Internal.Rarity) & (Internal.Rarity);
    }
    type Rarity_ = Rarity | "uncommon" | "epic" | "rare" | "common";
    interface ChatEvent$ChatComponent {
        abstract get(): net.minecraft.network.chat.Component;
        abstract set(arg0: net.minecraft.network.chat.Component_): void;
    }
    type ChatEvent$ChatComponent_ = ChatEvent$ChatComponent;
    interface ProfileResults {
        abstract saveResults(arg0: Internal.Path_): boolean;
        abstract getTimes(arg0: string): Internal.List<Internal.ResultField>;
        getNanoDuration(): number;
        abstract getStartTimeTicks(): number;
        getTickDuration(): number;
        abstract getEndTimeNano(): number;
        abstract getStartTimeNano(): number;
        abstract getEndTimeTicks(): number;
        abstract getProfilerResults(): string;
        demanglePath($$0: string): string;
        get nanoDuration(): number
        get startTimeTicks(): number
        get tickDuration(): number
        get endTimeNano(): number
        get startTimeNano(): number
        get endTimeTicks(): number
        get profilerResults(): string
        readonly PATH_SEPARATOR: ("\u001e") & (string);
    }
    type ProfileResults_ = ProfileResults;
    class CarvingContext extends Internal.WorldGenerationContext {
        constructor($$0: any_, $$1: Internal.RegistryAccess_, $$2: Internal.LevelHeightAccessor_, $$3: Internal.NoiseChunk_, $$4: Internal.RandomState_, $$5: Internal.SurfaceRules$RuleSource_)
        getClass(): typeof any;
        toString(): string;
        /**
         * @deprecated
        */
        topMaterial($$0: Internal.Function_<BlockPos, Internal.Holder<Internal.Biome>>, $$1: Internal.ChunkAccess_, $$2: BlockPos_, $$3: boolean): Optional<Internal.BlockState>;
        getGenDepth(): number;
        notifyAll(): void;
        /**
         * @deprecated
        */
        registryAccess(): Internal.RegistryAccess;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        randomState(): Internal.RandomState;
        hashCode(): number;
        wait(): void;
        getMinGenY(): number;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        get class(): typeof any
        get genDepth(): number
        get minGenY(): number
    }
    type CarvingContext_ = CarvingContext;
    class StructureTemplateFeature extends Feature<Internal.StructureTemplateConfig> {
        constructor()
        getClass(): typeof any;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.StructureTemplateConfig, Feature<Internal.StructureTemplateConfig>>>;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        place($$0: Internal.StructureTemplateConfig_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        place(context: Internal.FeaturePlaceContext_<Internal.StructureTemplateConfig>): boolean;
        get class(): typeof any
        static readonly FEATURE: (Internal.StructureTemplateFeature) & (Internal.StructureTemplateFeature);
    }
    type StructureTemplateFeature_ = StructureTemplateFeature;
    class SpellbladesArmorItem extends Internal.ModifiableArmorItem {
        constructor(fzzyMaterial: Internal.ArmorMaterial_, type: Internal.ArmorItem$Type_, settings: Internal.Item$Properties_)
        onTick(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        getType(): Internal.ArmorItem$Type;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        addModifierTooltip(stack: Internal.ItemStack_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_, type: Internal.ModifierHelperType_<any>): void;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        setAttributeModifiers(arg0: Internal.Multimap_<any, any>): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        fzzy_core_correctSlot(slot: Internal.EquipmentSlot_): boolean;
        getCreativeTab(): string;
        postWearerHit(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        modifierObjectPredicate(livingEntity: Internal.LivingEntity_, stack: Internal.ItemStack_): ResourceLocation;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        defaultModifiers(type: Internal.ModifierHelperType_<any>): Internal.List<ResourceLocation>;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        static get($$0: Internal.ItemStack_): Internal.Equipable;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        kjs$getAttributeMap(): Internal.Multimap<any, any>;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getDefense(): number;
        kjs$getMutableAttributeMap(): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        getModifiers(stack: Internal.ItemStack_, type: Internal.ModifierHelperType_<any>): Internal.List<ResourceLocation>;
        fzzy_core_getCorrectSlot(): Internal.EquipmentSlot;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        getEquipmentSlot(): Internal.EquipmentSlot;
        onWearerKilledOther(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, victim: Internal.LivingEntity_, world: Internal.ServerLevel_): void;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        canBeModifiedBy(type: Internal.ModifierHelperType_<any>): boolean;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        static dispenseArmor($$0: Internal.BlockSource_, $$1: Internal.ItemStack_): boolean;
        getMaterial(): Internal.ArmorMaterial;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        incrementKillCount(stack: Internal.ItemStack_): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        getEquipSound(): Internal.SoundEvent;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        static access$getAttributeModifiers$s1152367662($this: Internal.SpellbladesArmorItem_, slot: Internal.EquipmentSlot_): Internal.Multimap<any, any>;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        onAttack(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, attacker: Internal.LivingEntity_, source: DamageSource_, amount: number): number;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers(slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        getToughness(): number;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getKillCount(stack: Internal.ItemStack_): number;
        getTypeItemStackKey(): Internal.ItemStackKey;
        onWearerDamaged(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, attacker: Internal.LivingEntity_, source: DamageSource_, amount: number): number;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        postWearerMine(stack: Internal.ItemStack_, world: Internal.Level_, state: Internal.BlockState_, pos: BlockPos_, miner: Internal.Player_): void;
        kjs$setAttributeMap(arg0: Internal.Multimap_<any, any>): void;
        swapWithEquipmentSlot($$0: Internal.Item_, $$1: Internal.Level_, $$2: Internal.Player_, $$3: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get type(): Internal.ArmorItem$Type
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        set attributeModifiers(arg0: Internal.Multimap_<any, any>)
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        get defense(): number
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get equipmentSlot(): Internal.EquipmentSlot
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        get material(): Internal.ArmorMaterial
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get equipSound(): Internal.SoundEvent
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get toughness(): number
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type SpellbladesArmorItem_ = SpellbladesArmorItem;
    interface ListBuilder <T> {
        build(arg0: Internal.DataResult_<T>): Internal.DataResult<T>;
        abstract "build(java.lang.Object)"(arg0: T): Internal.DataResult<T>;
        abstract "add(com.mojang.serialization.DataResult)"(arg0: Internal.DataResult_<T>): this;
        abstract add(arg0: Internal.DataResult_<T>): this;
        abstract build(arg0: T): Internal.DataResult<T>;
        abstract mapError(arg0: Internal.UnaryOperator_<string>): this;
        "build(com.mojang.serialization.DataResult)"(arg0: Internal.DataResult_<T>): Internal.DataResult<T>;
        abstract withErrorsFrom(arg0: Internal.DataResult_<any>): this;
        abstract add(arg0: T): this;
        abstract ops(): Internal.DynamicOps<T>;
        abstract "add(java.lang.Object)"(arg0: T): this;
        add<E>(arg0: E, arg1: Internal.Encoder_<E>): this;
        addAll<E>(arg0: Internal.Iterable_<E>, arg1: Internal.Encoder_<E>): this;
    }
    type ListBuilder_<T> = ListBuilder<T>;
    class CandleBlock extends Internal.AbstractCandleBlock implements Internal.SimpleWaterloggedBlock {
        constructor($$0: Internal.BlockBehaviour$Properties_)
        /**
         * @deprecated
        */
        getOcclusionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        /**
         * @deprecated
        */
        getSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getPickupSound(): Optional<Internal.SoundEvent>;
        axiom$customPickBlockStack(): Internal.ItemStack;
        getSoundType($$0: Internal.BlockState_): SoundType;
        /**
         * @deprecated
        */
        getVisualShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        handler$efo000$collective$Block_playerDestroy(level: Internal.Level_, player: Internal.Player_, blockPos: BlockPos_, blockState: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number, $$5: number): void;
        /**
         * @deprecated
        */
        randomTick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: Internal.BlockEntity_): void;
        static canSupportRigidBlock($$0: Internal.BlockGetter_, $$1: BlockPos_): boolean;
        static popResource($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.ItemStack_): void;
        setRandomTickCallback(callback: Internal.Consumer_<any>): void;
        getDescriptionId(): string;
        stepOn($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Entity_): void;
        fallOn($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: BlockPos_, $$3: Internal.Entity_, $$4: number): void;
        getSettings(): Internal.BlockBehaviour$Properties;
        getExplosionResistance(): number;
        asItem(): Internal.Item;
        /**
         * @deprecated
        */
        triggerEvent($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: number, $$4: number): boolean;
        getTypeData(): Internal.CompoundTag;
        setFriction(arg0: number): void;
        /**
         * @deprecated
        */
        getRenderShape($$0: Internal.BlockState_): Internal.RenderShape;
        canCull(): boolean;
        customShapeUpdate(blockState: Internal.CustomBlockState_, levelReader: Internal.LevelReader_, blockPos: BlockPos_): Internal.CustomBlockState;
        getJumpFactor(): number;
        getSpeedFactor(): number;
        static canSupportCenter($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        skipRendering($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getLightBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        playerDestroy($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.BlockEntity_, $$5: Internal.ItemStack_): void;
        shouldAttemptToCull(state: Internal.BlockState_): boolean;
        isPossibleToRespawnInThis($$0: Internal.BlockState_): boolean;
        getCustomStateForPlacement(blockPlaceContext: Internal.BlockPlaceContext_): Internal.CustomBlockState;
        /**
         * @deprecated
        */
        getDirectSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        getProperties(): Internal.BlockBehaviour$Properties;
        playerWillDestroy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Player_): void;
        getClass(): typeof any;
        getMaxVerticalOffset(): number;
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.item.context.BlockPlaceContext)"($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        useShapeForLightOcclusion($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        getDrops($$0: Internal.BlockState_, $$1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getStateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>;
        pickupBlock($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        /**
         * @deprecated
        */
        entityInside($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Entity_): void;
        setBlockBuilder(b: Internal.BlockBuilder_): void;
        handler$ldb000$puzzleslib$playerDestroy$0(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        setRequiresTool(v: boolean): void;
        setSpeedFactor(arg0: number): void;
        axiom$getPossibleCustomStates(): Internal.List<any>;
        setExplosionResistance(arg0: number): void;
        toString(): string;
        port_lib$popExperience(arg0: Internal.ServerLevel_, arg1: BlockPos_, arg2: number): void;
        notifyAll(): void;
        static isLit($$0: Internal.BlockState_): boolean;
        getToolModifiedState(state: Internal.BlockState_, world: Internal.Level_, pos: BlockPos_, player: Internal.Player_, stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): Internal.BlockState;
        getId(): string;
        getLootTable(): ResourceLocation;
        puzzleslib$setItem(arg0: Internal.Item_): void;
        axiom$translationKey(): string;
        /**
         * @deprecated
        */
        getInteractionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        propagatesSkylightDown($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        setPlacedBy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.LivingEntity_, $$4: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        onPlace($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Block>;
        static popResourceFromFace($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.ItemStack_): void;
        getFriction(): number;
        handlePrecipitation($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Biome$Precipitation_): void;
        /**
         * @deprecated
        */
        hasAnalogOutputSignal($$0: Internal.BlockState_): boolean;
        wait(arg0: number): void;
        getFluidState($$0: Internal.BlockState_): Internal.FluidState;
        handler$koh000$porting_lib_entity$getDestroySpeed(blockState: Internal.BlockState_, player: Internal.Player_, blockGetter: Internal.BlockGetter_, pos: BlockPos_, cir: Internal.CallbackInfoReturnable_<any>): void;
        /**
         * @deprecated
        */
        getAnalogOutputSignal($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): number;
        handler$efo000$collective$Block_setPlacedBy(level: Internal.Level_, blockPos: BlockPos_, blockState: Internal.BlockState_, livingEntity: Internal.LivingEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        tick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        supportsExternalFaceHiding(state: Internal.BlockState_): boolean;
        handler$ldb000$puzzleslib$playerDestroy$1(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        notify(): void;
        axiom$asItemStack(): Internal.ItemStack;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        neighborChanged($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Block_, $$4: BlockPos_, $$5: boolean): void;
        handler$zhd000$additionalentityattributes$additionalEntityAttributes$saveBreakingPlayer(world: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, stack: Internal.ItemStack_, callbackInfo: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        getBlockSupportShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        canSustainPlant(state: Internal.BlockState_, world: Internal.BlockGetter_, pos: BlockPos_, facing: Internal.Direction_, plantable: Internal.IPlantable_): boolean;
        /**
         * @deprecated
        */
        isCollisionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static isFaceFull($$0: Internal.VoxelShape_, $$1: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getMenuProvider($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): Internal.MenuProvider;
        static byItem($$0: Internal.Item_): Internal.Block;
        static updateFromNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        updateIndirectNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: number, $$4: number): void;
        destroy($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): void;
        handler$fdc000$everycomp$addSimpleFastECdrops(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, cir: Internal.CallbackInfoReturnable_<any>, resId: ResourceLocation_, lootParams: Internal.LootParams_, serverLevel: Internal.ServerLevel_, lootTable: Internal.LootTable_): void;
        getToolModifiedState(state: Internal.BlockState_, context: Internal.UseOnContext_, toolAction: Internal.ToolAction_, simulate: boolean): Internal.BlockState;
        use($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_, $$4: Internal.InteractionHand_, $$5: Internal.BlockHitResult_): Internal.InteractionResult;
        setLightEmission(v: number): void;
        doNormalInteractions(): boolean;
        setJumpFactor(arg0: number): void;
        canSurvive($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): void;
        /**
         * @deprecated
        */
        getShadeBrightness($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        getAppearance(state: Internal.BlockState_, renderView: Internal.BlockAndTintGetter_, pos: BlockPos_, side: Internal.Direction_, sourceState: Internal.BlockState_, sourcePos: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        getCollisionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        setDestroySpeed(v: number): void;
        defaultBlockState(): Internal.BlockState;
        usesCustomShouldDrawFace(state: Internal.BlockState_): boolean;
        getStateForPlacement($$0: Internal.BlockPlaceContext_): Internal.BlockState;
        cantCullAgainst(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        placeLiquid($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.FluidState_): boolean;
        arch$holder(): Internal.Holder<Internal.Block>;
        wait(): void;
        static extinguish($$0: Internal.Player_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): void;
        getCloneItemStack($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        hasDynamicShape(): boolean;
        getMaxHorizontalOffset(): number;
        /**
         * @deprecated
        */
        getDestroyProgress($$0: Internal.BlockState_, $$1: Internal.Player_, $$2: Internal.BlockGetter_, $$3: BlockPos_): number;
        /**
         * @deprecated
        */
        getSeed($$0: Internal.BlockState_, $$1: BlockPos_): number;
        defaultDestroyTime(): number;
        updateShape($$0: Internal.BlockState_, $$1: Internal.Direction_, $$2: Internal.BlockState_, $$3: Internal.LevelAccessor_, $$4: BlockPos_, $$5: BlockPos_): Internal.BlockState;
        dropFromExplosion($$0: Internal.Explosion_): boolean;
        isRandomlyTicking($$0: Internal.BlockState_): boolean;
        static isShapeFullBlock(shape: Internal.VoxelShape_): boolean;
        withPropertiesOf($$0: Internal.BlockState_): Internal.BlockState;
        static isExceptionForConnection($$0: Internal.BlockState_): boolean;
        setIsRandomlyTicking(arg0: boolean): void;
        canPlaceLiquid($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Fluid_): boolean;
        hidesNeighborFace(level: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, neighborState: Internal.BlockState_, dir: Internal.Direction_): boolean;
        onTreeGrow(state: Internal.BlockState_, level: Internal.LevelReader_, placeFunction: Internal.BiConsumer_<BlockPos, Internal.BlockState>, randomSource: Internal.RandomSource_, pos: BlockPos_, config: Internal.TreeConfiguration_): boolean;
        /**
         * @deprecated
        */
        rotate($$0: Internal.BlockState_, $$1: Internal.Rotation_): Internal.BlockState;
        defaultMapColor(): Internal.MapColor;
        getStateAtViewpoint(state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_, viewpoint: Vec3d_): Internal.BlockState;
        wait(arg0: number, arg1: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.BlockGetter_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        setNameKey(arg0: string): void;
        static box($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): Internal.VoxelShape;
        static canLight($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        mirror($$0: Internal.BlockState_, $$1: Internal.Mirror_): Internal.BlockState;
        wasExploded($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Explosion_): void;
        getName(): Internal.MutableComponent;
        updateEntityAfterFallOn($$0: Internal.BlockGetter_, $$1: Internal.Entity_): void;
        animateTick($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        customShouldDrawFace(view: Internal.BlockGetter_, thisState: Internal.BlockState_, sideState: Internal.BlockState_, thisPos: BlockPos_, sidePos: BlockPos_, side: Internal.Direction_): Optional<boolean>;
        axiom$getResourceLocation(): ResourceLocation;
        arch$registryName(): ResourceLocation;
        axiom$getProperties(): Internal.Collection<any>;
        getBlockBuilder(): Internal.BlockBuilder;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        isSignalSource($$0: Internal.BlockState_): boolean;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number): void;
        /**
         * @deprecated
        */
        attack($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): void;
        getShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        shouldAttemptToCull(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        onProjectileHit($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockHitResult_, $$3: Internal.Projectile_): void;
        static stateById($$0: number): Internal.BlockState;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): Internal.List<Internal.ItemStack>;
        requiredFeatures(): Internal.FeatureFlagSet;
        hashCode(): number;
        axiom$defaultCustomState(): Internal.CustomBlockState;
        setCanCull(canCull: boolean): void;
        /**
         * @deprecated
        */
        isOcclusionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static getId($$0: Internal.BlockState_): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.material.Fluid)"($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        static pushEntitiesUp($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        isPathfindable($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.PathComputationType_): boolean;
        setSoundType(arg0: SoundType_): void;
        handler$cef000$betterend$be_getDroppedStacks(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, info: Internal.CallbackInfoReturnable_<any>): void;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_): Internal.List<Internal.ItemStack>;
        /**
         * @deprecated
        */
        onRemove($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        cantCullAgainst(state: Internal.BlockState_): boolean;
        setHasCollision(arg0: boolean): void;
        static shouldRenderFace($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_, $$4: BlockPos_): boolean;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        spawnAfterBreak($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.ItemStack_, $$4: boolean): void;
        get pickupSound(): Optional<Internal.SoundEvent>
        set randomTickCallback(callback: Internal.Consumer_<any>)
        get descriptionId(): string
        get settings(): Internal.BlockBehaviour$Properties
        get explosionResistance(): number
        get typeData(): Internal.CompoundTag
        set friction(arg0: number)
        get jumpFactor(): number
        get speedFactor(): number
        get properties(): Internal.BlockBehaviour$Properties
        get class(): typeof any
        get maxVerticalOffset(): number
        get stateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>
        set blockBuilder(b: Internal.BlockBuilder_)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        set speedFactor(arg0: number)
        set explosionResistance(arg0: number)
        get id(): string
        get lootTable(): ResourceLocation
        get friction(): number
        set lightEmission(v: number)
        set jumpFactor(arg0: number)
        set destroySpeed(v: number)
        get maxHorizontalOffset(): number
        set isRandomlyTicking(arg0: boolean)
        set nameKey(arg0: string)
        get name(): Internal.MutableComponent
        get blockBuilder(): Internal.BlockBuilder
        get idLocation(): ResourceLocation
        get mod(): string
        set canCull(canCull: boolean)
        set soundType(arg0: SoundType_)
        set hasCollision(arg0: boolean)
        static readonly MAX_CANDLES: (4) & (number);
        static readonly CANDLES: (Internal.IntegerProperty) & (Internal.IntegerProperty);
        static readonly WATERLOGGED: (Internal.BooleanProperty) & (Internal.BooleanProperty);
        static readonly MIN_CANDLES: (1) & (number);
        static readonly LIT: (Internal.BooleanProperty) & (Internal.BooleanProperty);
        static readonly LIGHT_EMISSION: Internal.ToIntFunction<Internal.BlockState>;
    }
    type CandleBlock_ = CandleBlock;
}
declare namespace io.github.fabricators_of_create.porting_lib.extensions.extensions {
    interface BlockExtensions {
        canSustainPlant(state: Internal.BlockState_, world: Internal.BlockGetter_, pos: BlockPos_, facing: Internal.Direction_, plantable: Internal.IPlantable_): boolean;
        supportsExternalFaceHiding(state: Internal.BlockState_): boolean;
        hidesNeighborFace(level: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, neighborState: Internal.BlockState_, dir: Internal.Direction_): boolean;
        onTreeGrow(state: Internal.BlockState_, level: Internal.LevelReader_, placeFunction: Internal.BiConsumer_<BlockPos, Internal.BlockState>, randomSource: Internal.RandomSource_, pos: BlockPos_, config: Internal.TreeConfiguration_): boolean;
        getStateAtViewpoint(state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_, viewpoint: Vec3d_): Internal.BlockState;
    }
    type BlockExtensions_ = BlockExtensions;
}
declare namespace io.github.fabricators_of_create.porting_lib.entity.mixin.common {
    interface EntityAccessor {
        abstract callGetEyeHeight(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        (arg0: Internal.Pose, arg1: Internal.EntityDimensions): number;
    }
    type EntityAccessor_ = EntityAccessor | ((arg0: Internal.Pose, arg1: Internal.EntityDimensions)=> number);
}
declare namespace com.supermartijn642.fusion.api.util {
    class Pair <X, Y> {
        getClass(): typeof any;
        right(): Y;
        toString(): string;
        static of<X, Y>(left: X, right: Y): com.supermartijn642.fusion.api.util.Pair<X, Y>;
        notifyAll(): void;
        flatMap<S>(mapper: Internal.BiFunction_<X, Y, S>): S;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        apply(consumer: Internal.BiConsumer_<X, Y>): void;
        wait(): void;
        mapRight<S>(mapper: Internal.Function_<Y, S>): com.supermartijn642.fusion.api.util.Pair<X, S>;
        left(): X;
        wait(arg0: number): void;
        map<R, S>(mapLeft: Internal.Function_<X, R>, mapRight: Internal.Function_<Y, S>): com.supermartijn642.fusion.api.util.Pair<R, S>;
        equals(o: any): boolean;
        mapLeft<S>(mapper: Internal.Function_<X, S>): com.supermartijn642.fusion.api.util.Pair<S, Y>;
        get class(): typeof any
    }
    type Pair_<X, Y> = Pair<X, Y>;
}
declare namespace com.yungnickyoung.minecraft.yungsextras.world.feature.desert {
    class DesertWellFeature extends Internal.AbstractNbtFeature<Internal.DesertWellFeatureConfiguration> {
        constructor()
        getClass(): typeof any;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.DesertWellFeatureConfiguration, Feature<Internal.DesertWellFeatureConfiguration>>>;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        place(context: Internal.FeaturePlaceContext_<Internal.DesertWellFeatureConfiguration>): boolean;
        place($$0: Internal.DesertWellFeatureConfiguration_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        wait(): void;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        get class(): typeof any
    }
    type DesertWellFeature_ = DesertWellFeature;
}
declare namespace io.github.fabricators_of_create.porting_lib.tool.mixin {
    interface BuilderAccessor {
        abstract getPools(): Internal.List<Internal.LootPool>;
        get pools(): Internal.List<Internal.LootPool>
        (): Internal.List_<Internal.LootPool>;
    }
    type BuilderAccessor_ = BuilderAccessor | (()=> Internal.List_<Internal.LootPool>);
}
declare namespace it.unimi.dsi.fastutil.doubles {
    interface DoublePredicate extends Internal.DoublePredicate, Internal.Predicate<number> {
        /**
         * @deprecated
        */
        or(arg0: Internal.Predicate_<number>): Internal.Predicate<number>;
        /**
         * @deprecated
        */
        "or(java.util.function.Predicate)"(arg0: Internal.Predicate_<number>): Internal.Predicate<number>;
        /**
         * @deprecated
        */
        "and(java.util.function.Predicate)"(arg0: Internal.Predicate_<number>): Internal.Predicate<number>;
        not<T>(arg0: Internal.Predicate_<T>): Internal.Predicate<T>;
        abstract test(arg0: number): boolean;
        "and(it.unimi.dsi.fastutil.doubles.DoublePredicate)"(arg0: it.unimi.dsi.fastutil.doubles.DoublePredicate_): this;
        /**
         * @deprecated
        */
        and(arg0: Internal.Predicate_<number>): Internal.Predicate<number>;
        abstract "test(double)"(arg0: number): boolean;
        "and(java.util.function.DoublePredicate)"(arg0: Internal.DoublePredicate_): this;
        /**
         * @deprecated
        */
        test(arg0: number): boolean;
        isEqual<T>(arg0: any): Internal.Predicate<T>;
        or(arg0: Internal.DoublePredicate_): this;
        /**
         * @deprecated
        */
        test(arg0: any): boolean;
        "or(it.unimi.dsi.fastutil.doubles.DoublePredicate)"(arg0: it.unimi.dsi.fastutil.doubles.DoublePredicate_): this;
        or(arg0: it.unimi.dsi.fastutil.doubles.DoublePredicate_): this;
        and(arg0: Internal.DoublePredicate_): this;
        /**
         * @deprecated
        */
        "test(java.lang.Object)"(arg0: any): boolean;
        "or(java.util.function.DoublePredicate)"(arg0: Internal.DoublePredicate_): this;
        negate(): Internal.DoublePredicate;
        /**
         * @deprecated
        */
        "test(java.lang.Double)"(arg0: number): boolean;
        and(arg0: it.unimi.dsi.fastutil.doubles.DoublePredicate_): this;
    }
    type DoublePredicate_ = DoublePredicate;
}
