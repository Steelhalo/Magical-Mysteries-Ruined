/// <reference path="./internal_*.d.ts" />
declare namespace Internal {
    class IsInsideStructureTracker$IsInside {
        constructor(insideStructure: boolean, insideStructurePiece: boolean)
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        setInsideStructurePiece(insideStructurePiece: boolean): this;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        isInsideStructurePiece(): boolean;
        isInsideStructure(): boolean;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        setInsideStructure(insideStructure: boolean): this;
        get class(): typeof any
        set insideStructurePiece(insideStructurePiece: boolean)
        get insideStructurePiece(): boolean
        get insideStructure(): boolean
        set insideStructure(insideStructure: boolean)
        static readonly CODEC: Internal.Codec<Internal.IsInsideStructureTracker$IsInside>;
    }
    type IsInsideStructureTracker$IsInside_ = IsInsideStructureTracker$IsInside;
    class VerticalAnchor$AboveBottom extends Internal.Record implements Internal.VerticalAnchor {
        constructor($$0: number)
        getClass(): typeof any;
        static aboveBottom($$0: number): Internal.VerticalAnchor;
        toString(): string;
        static belowTop($$0: number): Internal.VerticalAnchor;
        static bottom(): Internal.VerticalAnchor;
        notifyAll(): void;
        resolveY($$0: Internal.WorldGenerationContext_): number;
        notify(): void;
        offset(): number;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        static absolute($$0: number): Internal.VerticalAnchor;
        wait(): void;
        static top(): Internal.VerticalAnchor;
        wait(arg0: number): void;
        equals($$0: any): boolean;
        get class(): typeof any
        static readonly CODEC: Internal.Codec<Internal.VerticalAnchor$AboveBottom>;
    }
    type VerticalAnchor$AboveBottom_ = VerticalAnchor$AboveBottom;
    class EndCityStructure extends Internal.Structure {
        constructor($$0: Internal.Structure$StructureSettings_)
        static simpleCodec<S extends Internal.Structure>($$0: Internal.Function_<Internal.Structure$StructureSettings, S>): Internal.Codec<S>;
        getClass(): typeof any;
        generate($$0: Internal.RegistryAccess_, $$1: Internal.ChunkGenerator_, $$2: Internal.BiomeSource_, $$3: Internal.RandomState_, $$4: Internal.StructureTemplateManager_, $$5: number, $$6: Internal.ChunkPos_, $$7: number, $$8: Internal.LevelHeightAccessor_, $$9: Internal.Predicate_<Internal.Holder<Internal.Biome>>): Internal.StructureStart;
        toString(): string;
        biomes(): Internal.HolderSet<Internal.Biome>;
        findValidGenerationPoint($$0: Internal.Structure$GenerationContext_): Optional<Internal.Structure$GenerationStub>;
        spawnOverrides(): Internal.Map<Internal.MobCategory, Internal.StructureSpawnOverride>;
        step(): Internal.GenerationStep$Decoration;
        notifyAll(): void;
        notify(): void;
        terrainAdaptation(): Internal.TerrainAdjustment;
        wait(arg0: number, arg1: number): void;
        adjustBoundingBox($$0: Internal.BoundingBox_): Internal.BoundingBox;
        hashCode(): number;
        type(): Internal.StructureType<any>;
        static settingsCodec<S extends Internal.Structure>($$0: Internal.RecordCodecBuilder$Instance_<S>): Internal.RecordCodecBuilder<S, Internal.Structure$StructureSettings>;
        method_38676($$0: Internal.Structure$GenerationContext_): Optional<Internal.Structure$GenerationStub>;
        structurify$setStructureIdentifier(structureSetIdentifier: ResourceLocation_): void;
        wait(): void;
        structurify$getStructureIdentifier(): ResourceLocation;
        wait(arg0: number): void;
        afterPlace($$0: Internal.WorldGenLevel_, $$1: Internal.StructureManager_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: Internal.BoundingBox_, $$5: Internal.ChunkPos_, $$6: Internal.PiecesContainer_): void;
        equals(arg0: any): boolean;
        setStructureBiomes(newBiomes: Internal.HolderSet_<any>): void;
        get class(): typeof any
        set tingsCodec($$0: Internal.RecordCodecBuilder$Instance_<S>)
        set structureBiomes(newBiomes: Internal.HolderSet_<any>)
        static readonly CODEC: Internal.Codec<Internal.EndCityStructure>;
    }
    type EndCityStructure_ = EndCityStructure;
    class MediumJoshuaTreeFeature extends Feature<Internal.NoneFeatureConfiguration> {
        constructor(codec: Internal.Codec_<Internal.NoneFeatureConfiguration>)
        placeLeaves(level: Internal.LevelAccessor_, pos: BlockPos_): boolean;
        getClass(): typeof any;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        place($$0: Internal.NoneFeatureConfiguration_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        place(context: Internal.FeaturePlaceContext_<Internal.NoneFeatureConfiguration>): boolean;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        wait(): void;
        placeBranch(level: Internal.LevelAccessor_, pos: BlockPos_): boolean;
        placeBranch2(level: Internal.LevelAccessor_, pos: BlockPos_): boolean;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.NoneFeatureConfiguration, Feature<Internal.NoneFeatureConfiguration>>>;
        get class(): typeof any
    }
    type MediumJoshuaTreeFeature_ = MediumJoshuaTreeFeature;
    abstract class SingleItemRecipe implements Internal.Recipe<net.minecraft.world.Container> {
        constructor($$0: Internal.RecipeType_<any>, $$1: Internal.RecipeSerializer_<any>, $$2: ResourceLocation_, $$3: string, $$4: Internal.Ingredient_, $$5: Internal.ItemStack_)
        getClass(): typeof any;
        getGroup(): string;
        getToastSymbol(): Internal.ItemStack;
        getSchema(): Internal.RecipeSchema;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getSerializer(): Internal.RecipeSerializer<any>;
        assemble($$0: net.minecraft.world.Container_, $$1: Internal.RegistryAccess_): Internal.ItemStack;
        getId(): ResourceLocation;
        abstract matches(arg0: net.minecraft.world.Container_, arg1: Internal.Level_): boolean;
        getMod(): string;
        isIn(tag: ResourceLocation_): boolean;
        getRemainingItems($$0: net.minecraft.world.Container_): Internal.NonNullList<Internal.ItemStack>;
        getIngredients(): Internal.NonNullList<Internal.Ingredient>;
        handler$bpa000$bclib$bcl_getRemainingItems(container: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>): void;
        isSpecial(): boolean;
        hasOutput(match: Internal.ReplacementMatch_): boolean;
        getResultItem($$0: Internal.RegistryAccess_): Internal.ItemStack;
        toString(): string;
        notifyAll(): void;
        canCraftInDimensions($$0: number, $$1: number): boolean;
        showNotification(): boolean;
        replaceInput(match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): boolean;
        getType(): ResourceLocation;
        setGroup(group: string): void;
        "handler$fie000$fabric-item-api-v1$captureStack"(inventory: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>, defaultedList: Internal.NonNullList_<any>, i: number): void;
        hashCode(): number;
        getOrCreateId(): ResourceLocation;
        hasInput(match: Internal.ReplacementMatch_): boolean;
        wait(): void;
        isIncomplete(): boolean;
        wait(arg0: number): void;
        replaceOutput(match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): boolean;
        equals(arg0: any): boolean;
        get class(): typeof any
        get group(): string
        get toastSymbol(): Internal.ItemStack
        get schema(): Internal.RecipeSchema
        get serializer(): Internal.RecipeSerializer<any>
        get id(): ResourceLocation
        get mod(): string
        get ingredients(): Internal.NonNullList<Internal.Ingredient>
        get special(): boolean
        get type(): ResourceLocation
        set group(group: string)
        get orCreateId(): ResourceLocation
        get incomplete(): boolean
    }
    type SingleItemRecipe_ = SingleItemRecipe;
    class SniperBowItem$Companion {
        constructor($constructor_marker: any_)
        getClass(): typeof any;
        getSNIPER_BOW_SCOPE(): ResourceLocation;
        toString(): string;
        setSNIPER_BOW_SCOPE(<set-?>: ResourceLocation_): void;
        notifyAll(): void;
        changeScope(up: boolean): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        set_hand(<set-?>: Internal.InteractionHand_): void;
        hashCode(): number;
        wait(): void;
        set_world(<set-?>: Internal.Level_): void;
        get_hand(): Internal.InteractionHand;
        wait(arg0: number): void;
        get_world(): Internal.Level;
        equals(arg0: any): boolean;
        get class(): typeof any
        get SNIPER_BOW_SCOPE(): ResourceLocation
        set SNIPER_BOW_SCOPE(<set-?>: ResourceLocation_)
        set _hand(<set-?>: Internal.InteractionHand_)
        set _world(<set-?>: Internal.Level_)
        get _hand(): Internal.InteractionHand
        get _world(): Internal.Level
    }
    type SniperBowItem$Companion_ = SniperBowItem$Companion;
    interface Factory {
        abstract getSerializableData(): Internal.SerializableData;
        abstract getSerializerId(): ResourceLocation;
        get serializableData(): Internal.SerializableData
        get serializerId(): ResourceLocation
    }
    type Factory_ = Factory;
    interface ClaimResult {
        isSuccess(): boolean;
        abstract getResultId(): string;
        abstract getMessage(): Internal.MutableComponent;
        customProblem(translationKey: string): this;
        success(): this;
        get success(): boolean
        get resultId(): string
        get message(): Internal.MutableComponent
    }
    type ClaimResult_ = ClaimResult;
    interface TerraformBoatType {
        abstract isRaft(): boolean;
        abstract getChestItem(): Internal.Item;
        abstract getItem(): Internal.Item;
        abstract getPlanks(): Internal.Item;
        get raft(): boolean
        get chestItem(): Internal.Item
        get item(): Internal.Item
        get planks(): Internal.Item
    }
    type TerraformBoatType_ = TerraformBoatType;
    abstract class PointFree <T> {
        constructor()
        getClass(): typeof any;
        static indent(arg0: number): string;
        toString(): string;
        evalCached(): Internal.Function<Internal.DynamicOps<any>, T>;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        abstract "eval"(): Internal.Function<Internal.DynamicOps<any>, T>;
        hashCode(): number;
        abstract type(): com.mojang.datafixers.types.Type<T>;
        wait(): void;
        abstract toString(arg0: number): string;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        get class(): typeof any
    }
    type PointFree_<T> = PointFree<T>;
    abstract class BaseQuestFile extends Internal.QuestObject implements Internal.QuestFile {
        constructor()
        getMutableTitle(): Internal.MutableComponent;
        writeDataFull(folder: Internal.Path_): void;
        readData(nbt: Internal.CompoundTag_): void;
        "getID(java.lang.Object)"(obj: any): number;
        clearCachedData(): void;
        getCraftingTasks(): Internal.List<Internal.Task>;
        create(id: number, type: Internal.QuestObjectType_, parent: number, extra: Internal.CompoundTag_): Internal.QuestObjectBase;
        getQuest(id: number): Internal.Quest;
        getLootCrate(id: string): Internal.LootCrate;
        readID(tag: Internal.Tag_): number;
        getRawTitle(): string;
        getDefaultQuestShape(): string;
        forAllChapterGroups(consumer: Internal.Consumer_<Internal.ChapterGroup>): void;
        getProgressColor(data: Internal.TeamData_): Internal.Color4I;
        getEmergencyItems(): Internal.List<Internal.ItemStack>;
        cacheProgress(): boolean;
        deleteSelf(): void;
        removeEmptyRewardTables(source: Internal.CommandSourceStack_): number;
        getProgressionMode(): Internal.ProgressionMode;
        isDefaultPerTeamReward(): boolean;
        hasUnclaimedRewardsRaw(teamData: Internal.TeamData_, player: Internal.UUID_): boolean;
        markDirty(): void;
        isValid(): boolean;
        onCompleted(data: Internal.QuestProgressEventData_<any>): void;
        static parseCodeString(id: string): number;
        readDataFull(folder: Internal.Path_): void;
        deleteChildren(): void;
        getReward(id: number): Internal.Reward;
        getTags(): Internal.Set<string>;
        dropBookOnDeath(): boolean;
        getChildren(): Internal.Collection<Internal.QuestObject>;
        collect<T extends Internal.QuestObjectBase>(clazz: T): Internal.List<T>;
        isDropLootCrates(): boolean;
        getAllObjects(): Internal.Collection<Internal.QuestObjectBase>;
        setRawIcon(rawIcon: Internal.ItemStack_): void;
        static shouldSendNotifications(): boolean;
        getOrCreateTeamData(teamId: Internal.UUID_): Internal.TeamData;
        "compareTo(java.lang.Object)"(arg0: any): number;
        canEdit(): boolean;
        newID(): number;
        getAltIcon(): Internal.Icon;
        getClass(): typeof any;
        getProgressColor(data: Internal.TeamData_, dim: boolean): Internal.Color4I;
        "getOrCreateTeamData(java.util.UUID)"(teamId: Internal.UUID_): Internal.TeamData;
        static copy<T extends Internal.QuestObjectBase>(orig: T, factory: Internal.Supplier_<T>): T;
        getFirstVisibleChapter(data: Internal.TeamData_): Internal.Chapter;
        isOptionalForProgression(): boolean;
        fillConfigGroup(config: Internal.ConfigGroup_): void;
        getSubmitTasks(): Internal.List<Internal.Task>;
        getTask(id: number): Internal.Task;
        remove(id: number): Internal.QuestObjectBase;
        forAllChapters(consumer: Internal.Consumer_<Internal.Chapter>): void;
        get(id: number): Internal.QuestObject;
        "compareTo(dev.ftb.mods.ftbquests.quest.QuestObjectBase)"(other: Internal.QuestObjectBase_): number;
        setRawTitle(rawTitle: string): void;
        toString(): string;
        onStarted(data: Internal.QuestProgressEventData_<any>): void;
        notifyAll(): void;
        getAllTeamData(): Internal.Collection<Internal.TeamData>;
        getObjectType(): Internal.QuestObjectType;
        removeRewardTable(rewardTable: Internal.RewardTable_): void;
        forceProgressRaw(teamData: Internal.TeamData_, progressChange: Internal.ProgressChange_): void;
        refreshIDMap(): void;
        getGridScale(): number;
        isServerSide(): boolean;
        "collect(java.util.function.Predicate)"<T extends Internal.QuestObjectBase>(filter: Internal.Predicate_<Internal.QuestObjectBase>): Internal.List<T>;
        isDefaultQuestDisableJEI(): boolean;
        editedFromGUIOnServer(): void;
        addRewardTable(rewardTable: Internal.RewardTable_): void;
        getVisibleChapters(data: Internal.TeamData_): Internal.List<Internal.Chapter>;
        wait(arg0: number): void;
        readNetDataFull(buffer: Internal.FriendlyByteBuf_): void;
        getRelativeProgressFromChildren(data: Internal.TeamData_): number;
        isLoading(): boolean;
        isCompletedRaw(data: Internal.TeamData_): boolean;
        getRewardType(typeId: number): Internal.RewardType;
        writeData(nbt: Internal.CompoundTag_): void;
        forAllQuests(consumer: Internal.Consumer_<Internal.Quest>): void;
        abstract getSide(): Internal.Env;
        editedFromGUI(): void;
        notify(): void;
        compareTo(arg0: any): number;
        static isNull(object: Internal.QuestObjectBase_): boolean;
        getDetectionDelay(): number;
        componentsToRefresh(): Internal.Set<Internal.RecipeModHelper$Components>;
        static getID(object: Internal.QuestObjectBase_): number;
        getChapterGroup(id: number): Internal.ChapterGroup;
        updateLootCrates(): void;
        static getRelativeProgressFromChildren(progressSum: number, count: number): number;
        getEmergencyItemsCooldown(): number;
        getDefaultChapterGroup(): Internal.DefaultChapterGroup;
        generateRewardTableName(basename: string): string;
        forceProgress(teamData: Internal.TeamData_, progressChange: Internal.ProgressChange_): void;
        getBase(id: number): Internal.QuestObjectBase;
        readID(id: number): number;
        static "getCodeString(dev.ftb.mods.ftbquests.quest.QuestObjectBase)"(object: Internal.QuestObjectBase_): string;
        getDefaultRewardAutoClaim(): Internal.RewardAutoClaim;
        refreshGui(): void;
        wait(): void;
        static "getID(dev.ftb.mods.ftbquests.quest.QuestObjectBase)"(object: Internal.QuestObjectBase_): number;
        getOrCreateTeamData(team: dev.ftb.mods.ftbteams.api.Team_): Internal.TeamData;
        getTitle(): net.minecraft.network.chat.Component;
        "readID(long)"(id: number): number;
        static titleToID(s: string): Optional<string>;
        onEditButtonClicked(gui: Internal.Runnable_): void;
        getRewardTables(): Internal.List<Internal.RewardTable>;
        addData(data: Internal.TeamData_, override: boolean): void;
        static getCodeString(object: Internal.QuestObjectBase_): string;
        getID(obj: any): number;
        getCodeString(): string;
        static getCodeString(id: number): string;
        forAllQuestLinks(consumer: Internal.Consumer_<Internal.QuestLink>): void;
        abstract deleteObject(arg0: number): void;
        getChapterOrThrow(id: number): Internal.Chapter;
        clearCachedProgress(): void;
        createSubGroup(group: Internal.ConfigGroup_): Internal.ConfigGroup;
        getParentID(): number;
        getOrCreateTeamData(player: Internal.Entity_): Internal.TeamData;
        wait(arg0: number, arg1: number): void;
        "readID(net.minecraft.nbt.Tag)"(tag: Internal.Tag_): number;
        abstract isPlayerOnTeam(arg0: Internal.Player_, arg1: Internal.TeamData_): boolean;
        getIcon(): Internal.Icon;
        getChapter(id: number): Internal.Chapter;
        getChapterGroups(): Internal.List<Internal.ChapterGroup>;
        isDefaultTeamConsumeItems(): boolean;
        "getOrCreateTeamData(net.minecraft.world.entity.Entity)"(player: Internal.Entity_): Internal.TeamData;
        getAltTitle(): net.minecraft.network.chat.Component;
        static "getCodeString(long)"(id: number): string;
        readNetData(buffer: Internal.FriendlyByteBuf_): void;
        hasTag(tag: string): boolean;
        writeNetDataFull(buffer: Internal.FriendlyByteBuf_): void;
        collect<T extends Internal.QuestObjectBase>(filter: Internal.Predicate_<Internal.QuestObjectBase>): Internal.List<T>;
        compareTo(other: Internal.QuestObjectBase_): number;
        getRewardTable(id: number): Internal.RewardTable;
        getTaskType(typeId: number): Internal.TaskType;
        isPauseGame(): boolean;
        isDisableGui(): boolean;
        getQuestChapter(): Internal.Chapter;
        getQuestFile(): this;
        getAllTasks(): Internal.List<Internal.Task>;
        makeRandomLootCrate(entity: Internal.Entity_, random: Internal.RandomSource_): Optional<Internal.LootCrate>;
        static parseHexId(id: string): Optional<number>;
        hashCode(): number;
        "getOrCreateTeamData(dev.ftb.mods.ftbteams.api.Team)"(team: dev.ftb.mods.ftbteams.api.Team_): Internal.TeamData;
        getPath(): Optional<string>;
        isVisible(data: Internal.TeamData_): boolean;
        writeNetData(buffer: Internal.FriendlyByteBuf_): void;
        getAllChapters(): Internal.List<Internal.Chapter>;
        onCreated(): void;
        "collect(java.lang.Class)"<T extends Internal.QuestObjectBase>(clazz: T): Internal.List<T>;
        getLootCrateNoDrop(): Internal.EntityWeight;
        getFolder(): Internal.Path;
        equals(object: any): boolean;
        getNullableTeamData(id: Internal.UUID_): Internal.TeamData;
        moveChapterGroup(id: number, movingUp: boolean): boolean;
        get mutableTitle(): Internal.MutableComponent
        get craftingTasks(): Internal.List<Internal.Task>
        get rawTitle(): string
        get defaultQuestShape(): string
        get emergencyItems(): Internal.List<Internal.ItemStack>
        get progressionMode(): Internal.ProgressionMode
        get defaultPerTeamReward(): boolean
        get valid(): boolean
        get tags(): Internal.Set<string>
        get children(): Internal.Collection<Internal.QuestObject>
        get dropLootCrates(): boolean
        get allObjects(): Internal.Collection<Internal.QuestObjectBase>
        set rawIcon(rawIcon: Internal.ItemStack_)
        get altIcon(): Internal.Icon
        get class(): typeof any
        get optionalForProgression(): boolean
        get submitTasks(): Internal.List<Internal.Task>
        set rawTitle(rawTitle: string)
        get allTeamData(): Internal.Collection<Internal.TeamData>
        get objectType(): Internal.QuestObjectType
        get gridScale(): number
        get serverSide(): boolean
        get defaultQuestDisableJEI(): boolean
        get loading(): boolean
        get side(): Internal.Env
        get detectionDelay(): number
        get emergencyItemsCooldown(): number
        get defaultChapterGroup(): Internal.DefaultChapterGroup
        get defaultRewardAutoClaim(): Internal.RewardAutoClaim
        get title(): net.minecraft.network.chat.Component
        get rewardTables(): Internal.List<Internal.RewardTable>
        get codeString(): string
        get parentID(): number
        get icon(): Internal.Icon
        get chapterGroups(): Internal.List<Internal.ChapterGroup>
        get defaultTeamConsumeItems(): boolean
        get altTitle(): net.minecraft.network.chat.Component
        get pauseGame(): boolean
        get disableGui(): boolean
        get questChapter(): Internal.Chapter
        get questFile(): Internal.BaseQuestFile
        get allTasks(): Internal.List<Internal.Task>
        get path(): Optional<string>
        get allChapters(): Internal.List<Internal.Chapter>
        get lootCrateNoDrop(): Internal.EntityWeight
        get folder(): Internal.Path
        static VERSION: (13) & (number);
    }
    type BaseQuestFile_ = BaseQuestFile;
    interface FileNameMap {
        abstract getContentTypeFor(arg0: string): string;
        (arg0: string): string;
    }
    type FileNameMap_ = ((arg0: string)=> string) | FileNameMap;
    class StructureTemplatePool implements Internal.StructurePoolAccess, Internal.StructurePoolAccessor, safro.archon.mixin.StructurePoolAccessor, com.yungnickyoung.minecraft.yungsapi.mixin.accessor.StructureTemplatePoolAccessor, com.jtorleonstudios.bettervillage.mixin.StructurePoolAccessor, Internal.AccessorStructureTemplatePool, Internal.StructureTemplatePoolAccessor, net.redstonegames.chefsdelight.mixin.StructurePoolAccessor, com.samebutdifferent.morevillagers.mixin.StructureTemplatePoolAccessor, net.blay09.mods.waystones.mixin.StructureTemplatePoolAccessor {
        constructor($$0: Internal.Holder_<Internal.StructureTemplatePool>, $$1: Internal.List_<com.mojang.datafixers.util.Pair<Internal.StructurePoolElement, number>>)
        constructor($$0: Internal.Holder_<Internal.StructureTemplatePool>, $$1: Internal.List_<com.mojang.datafixers.util.Pair<Internal.Function<Internal.StructureTemplatePool$Projection, Internal.StructurePoolElement>, number>>, $$2: Internal.StructureTemplatePool$Projection_)
        getClass(): typeof any;
        bookshelf$setTemplates(arg0: Internal.ObjectArrayList_<any>): void;
        getFallback(): Internal.Holder<Internal.StructureTemplatePool>;
        bookshelf$getRawTemplates(): Internal.List<any>;
        getMaxSize($$0: Internal.StructureTemplateManager_): number;
        getElements(): Internal.ObjectArrayList<any>;
        setElements(arg0: Internal.ObjectArrayList_<any>): void;
        setTemplates(arg0: Internal.ObjectArrayList_<any>): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getTemplates(): Internal.ObjectArrayList<any>;
        getRawTemplates(): Internal.List<any>;
        bookshelf$getTemplates(): Internal.ObjectArrayList<any>;
        setVanillaTemplates(arg0: Internal.ObjectArrayList_<any>): void;
        bookshelf$setRawTemplates(arg0: Internal.List_<any>): void;
        setRawTemplates(arg0: Internal.List_<any>): void;
        getShuffledTemplates($$0: Internal.RandomSource_): Internal.List<Internal.StructurePoolElement>;
        toString(): string;
        notifyAll(): void;
        getVanillaTemplates(): Internal.ObjectArrayList<any>;
        compileRawTemplates(): void;
        getRandomTemplate($$0: Internal.RandomSource_): Internal.StructurePoolElement;
        getElementCounts(): Internal.List<any>;
        size(): number;
        hashCode(): number;
        wait(): void;
        setElementCounts(arg0: Internal.List_<any>): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        getLithostitchedTemplates(): Internal.LithostitchedTemplates;
        get class(): typeof any
        get fallback(): Internal.Holder<Internal.StructureTemplatePool>
        get elements(): Internal.ObjectArrayList<any>
        set elements(arg0: Internal.ObjectArrayList_<any>)
        set templates(arg0: Internal.ObjectArrayList_<any>)
        get templates(): Internal.ObjectArrayList<any>
        get rawTemplates(): Internal.List<any>
        set vanillaTemplates(arg0: Internal.ObjectArrayList_<any>)
        set rawTemplates(arg0: Internal.List_<any>)
        get vanillaTemplates(): Internal.ObjectArrayList<any>
        get elementCounts(): Internal.List<any>
        set elementCounts(arg0: Internal.List_<any>)
        get lithostitchedTemplates(): Internal.LithostitchedTemplates
        static readonly DIRECT_CODEC: Internal.Codec<Internal.StructureTemplatePool>;
        rawTemplates: Internal.List<com.mojang.datafixers.util.Pair<Internal.StructurePoolElement, number>>;
        templates: Internal.ObjectArrayList<Internal.StructurePoolElement>;
        static readonly CODEC: Internal.Codec<Internal.Holder<Internal.StructureTemplatePool>>;
    }
    type StructureTemplatePool_ = StructureTemplatePool | Special.TemplatePool;
    class LexicaBotaniaItem extends Internal.Item implements Internal.ItemWithBannerPattern, Internal.CustomCreativeTabContents {
        constructor(settings: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        static getEdition(): net.minecraft.network.chat.Component;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, worldIn: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, flagIn: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(worldIn: Internal.Level_, playerIn: Internal.Player_, handIn: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        getBannerPattern(): Internal.TagKey<Internal.BannerPattern>;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        static isOpen(): boolean;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        static isElven(stack: Internal.ItemStack_): boolean;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        addToCreativeTab(me: Internal.Item_, output: Internal.CreativeModeTab$Output_): void;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        static getTitle(stack: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static doRayTrace(world: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get edition(): net.minecraft.network.chat.Component
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get bannerPattern(): Internal.TagKey<Internal.BannerPattern>
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        get open(): boolean
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
        static readonly TAG_ELVEN_UNLOCK: ("botania:elven_unlock") & (string);
    }
    type LexicaBotaniaItem_ = LexicaBotaniaItem;
    interface IServerChunkManager {
        abstract getMainThreadExecutor(): Internal.ServerChunkCache$MainThreadExecutor;
        abstract getTicketManager(): Internal.DistanceManager;
        abstract invokeTick(): boolean;
        get mainThreadExecutor(): Internal.ServerChunkCache$MainThreadExecutor
        get ticketManager(): Internal.DistanceManager
    }
    type IServerChunkManager_ = IServerChunkManager;
    interface TransferHandler$Result {
        abstract tooltip(arg0: net.minecraft.network.chat.Component_): this;
        abstract "tooltip(net.minecraft.network.chat.Component)"(arg0: net.minecraft.network.chat.Component_): this;
        abstract getRenderer(arg0: Internal.TransferHandler_, arg1: Internal.TransferHandler$Context_): Internal.TransferHandlerRenderer;
        abstract overrideTooltipRenderer(arg0: Internal.BiConsumer_<me.shedaniel.math.Point, Internal.TransferHandler$Result$TooltipSink>): this;
        abstract isBlocking(): boolean;
        abstract tooltipMissing(arg0: Internal.List_<Internal.EntryIngredient>): this;
        abstract isSuccessful(): boolean;
        abstract blocksFurtherHandling(arg0: boolean): this;
        abstract isReturningToScreen(): boolean;
        abstract getError(): net.minecraft.network.chat.Component;
        blocksFurtherHandling(): this;
        abstract getColor(): number;
        abstract color(arg0: number): this;
        abstract isApplicable(): boolean;
        createNotApplicable(): this;
        abstract tooltip(arg0: Internal.TooltipComponent_): this;
        abstract getTooltipRenderer(): Internal.BiConsumer<me.shedaniel.math.Point, Internal.TransferHandler$Result$TooltipSink>;
        abstract renderer(arg0: Internal.TransferHandlerRenderer_): this;
        abstract fillTooltip(arg0: Internal.List_<Internal.Tooltip$Entry>): void;
        createSuccessful(): this;
        createFailedCustomButtonColor(error: net.minecraft.network.chat.Component_, color: number): this;
        abstract "tooltip(net.minecraft.world.inventory.tooltip.TooltipComponent)"(arg0: Internal.TooltipComponent_): this;
        createFailed(error: net.minecraft.network.chat.Component_): this;
        get blocking(): boolean
        get successful(): boolean
        get returningToScreen(): boolean
        get error(): net.minecraft.network.chat.Component
        get color(): number
        get applicable(): boolean
        get tooltipRenderer(): Internal.BiConsumer<me.shedaniel.math.Point, Internal.TransferHandler$Result$TooltipSink>
    }
    type TransferHandler$Result_ = TransferHandler$Result;
    interface AccessibleText {
        abstract getBeforeIndex(arg0: number, arg1: number): string;
        abstract getSelectionStart(): number;
        abstract getSelectedText(): string;
        abstract getAtIndex(arg0: number, arg1: number): string;
        abstract getAfterIndex(arg0: number, arg1: number): string;
        abstract getSelectionEnd(): number;
        abstract getCharacterBounds(arg0: number): Internal.Rectangle;
        abstract getCaretPosition(): number;
        abstract getIndexAtPoint(arg0: Internal.Point_): number;
        abstract getCharCount(): number;
        abstract getCharacterAttribute(arg0: number): Internal.AttributeSet;
        get selectionStart(): number
        get selectedText(): string
        get selectionEnd(): number
        get caretPosition(): number
        get charCount(): number
        readonly CHARACTER: (1) & (number);
        readonly WORD: (2) & (number);
        readonly SENTENCE: (3) & (number);
    }
    type AccessibleText_ = AccessibleText;
    interface RecipeTagHelper {
        isIn(tag: ResourceLocation_): boolean;
    }
    type RecipeTagHelper_ = RecipeTagHelper;
    interface ScriptTypePredicate extends Internal.Predicate<Internal.ScriptType> {
        getValidTypes(): Internal.List<Internal.ScriptType>;
        test(arg0: any): boolean;
        negate(): Internal.Predicate<Internal.ScriptType>;
        and(arg0: Internal.Predicate_<Internal.ScriptType>): Internal.Predicate<Internal.ScriptType>;
        not<T>(arg0: Internal.Predicate_<T>): Internal.Predicate<T>;
        abstract test(arg0: Internal.ScriptType_): boolean;
        or(arg0: Internal.Predicate_<Internal.ScriptType>): Internal.Predicate<Internal.ScriptType>;
        "test(java.lang.Object)"(arg0: any): boolean;
        abstract "test(dev.latvian.mods.kubejs.script.ScriptType)"(arg0: Internal.ScriptType_): boolean;
        isEqual<T>(arg0: any): Internal.Predicate<T>;
        get validTypes(): Internal.List<Internal.ScriptType>
        readonly COMMON: Internal.ScriptTypePredicate;
        readonly STARTUP_OR_CLIENT: Internal.ScriptTypePredicate;
        readonly STARTUP_OR_SERVER: Internal.ScriptTypePredicate;
        readonly ALL: Internal.ScriptTypePredicate;
    }
    type ScriptTypePredicate_ = ScriptTypePredicate;
    class BWGBoatItem extends Internal.Item {
        constructor(hasChest: boolean, type: any_, properties: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(level: Internal.Level_, player: Internal.Player_, usedHand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        hasChest(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type BWGBoatItem_ = BWGBoatItem;
    interface FilteringRule <Cache> {
        prepareCache(async: boolean): Cache;
        abstract processFilteredStacks(arg0: Internal.FilteringContext_, arg1: Internal.FilteringResultFactory_, arg2: Cache, arg3: boolean): Internal.FilteringResult;
        markDirty(stacks: Internal.Collection_<Internal.EntryStack<any>>, hashes: Internal.LongCollection_): void;
        isReloading(): boolean;
        abstract getType(): Internal.FilteringRuleType<Internal.FilteringRule<Cache>>;
        get reloading(): boolean
        get type(): Internal.FilteringRuleType<Internal.FilteringRule<Cache>>
    }
    type FilteringRule_<Cache> = FilteringRule<Cache>;
    class RealmsClient {
        constructor($$0: string, $$1: string, $$2: Internal.Minecraft_)
        requestDownloadInfo($$0: number, $$1: number): Internal.WorldDownload;
        restoreWorld($$0: number, $$1: string): void;
        backupsFor($$0: number): Internal.BackupList;
        notify(): void;
        open($$0: number): boolean;
        mcoEnabled(): boolean;
        subscriptionFor($$0: number): Internal.Subscription;
        pendingInvites(): Internal.PendingInvitesList;
        getNews(): Internal.RealmsNews;
        clientCompatible(): Internal.RealmsClient$CompatibleVersionResponse;
        getNotifications(): Internal.List<Internal.RealmsNotification>;
        listWorlds(): Internal.RealmsServerList;
        op($$0: number, $$1: string): Internal.Ops;
        static create($$0: Internal.Minecraft_): Internal.RealmsClient;
        getActivity($$0: number): Internal.ServerActivityList;
        putIntoMinigameMode($$0: number, $$1: string): boolean;
        join($$0: number): Internal.RealmsServerAddress;
        acceptInvitation($$0: string): void;
        resetWorldWithSeed($$0: number, $$1: Internal.WorldGenerationInfo_): boolean;
        requestUploadInfo($$0: number, $$1: string): Internal.UploadInfo;
        wait(): void;
        resetWorldWithTemplate($$0: number, $$1: string): boolean;
        uninvite($$0: number, $$1: string): void;
        fetchWorldTemplates($$0: number, $$1: number, $$2: Internal.RealmsServer$WorldType_): Internal.WorldTemplatePaginatedList;
        getLiveStats(): Internal.RealmsServerPlayerLists;
        getClass(): typeof any;
        switchSlot($$0: number, $$1: number): boolean;
        rejectInvitation($$0: string): void;
        initializeWorld($$0: number, $$1: string, $$2: string): void;
        close($$0: number): boolean;
        wait(arg0: number, arg1: number): void;
        static switchToProd(): void;
        update($$0: number, $$1: string, $$2: string): void;
        deop($$0: number, $$1: string): Internal.Ops;
        notificationsSeen($$0: Internal.List_<Internal.UUID>): void;
        deleteWorld($$0: number): void;
        getOwnWorld($$0: number): Internal.RealmsServer;
        stageAvailable(): boolean;
        trialAvailable(): boolean;
        agreeToTos(): void;
        sendPingResults($$0: Internal.PingResult_): void;
        toString(): string;
        notificationsDismiss($$0: Internal.List_<Internal.UUID>): void;
        notifyAll(): void;
        uninviteMyselfFrom($$0: number): void;
        updateSlot($$0: number, $$1: number, $$2: Internal.RealmsWorldOptions_): void;
        static switchToLocal(): void;
        invite($$0: number, $$1: string): Internal.RealmsServer;
        hashCode(): number;
        static create(): Internal.RealmsClient;
        wait(arg0: number): void;
        static switchToStage(): void;
        pendingInvitesCount(): number;
        equals(arg0: any): boolean;
        get news(): Internal.RealmsNews
        get notifications(): Internal.List<Internal.RealmsNotification>
        get liveStats(): Internal.RealmsServerPlayerLists
        get class(): typeof any
        static currentEnvironment: (Internal.RealmsClient$Environment) & (Internal.RealmsClient$Environment);
    }
    type RealmsClient_ = RealmsClient;
    class CustomMapDecoration {
        constructor(type: Internal.MapDecorationType_<any, any>, buffer: Internal.FriendlyByteBuf_)
        constructor(type: Internal.MapDecorationType_<any, any>, x: number, y: number, rot: number, displayName: net.minecraft.network.chat.Component_)
        getDisplayName(): net.minecraft.network.chat.Component;
        getClass(): typeof any;
        getRot(): number;
        getType(): Internal.MapDecorationType<any, any>;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getX(): number;
        setDisplayName(displayName: net.minecraft.network.chat.Component_): void;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        setRot(rot: number): void;
        setX(x: number): void;
        setY(y: number): void;
        saveToBuffer(buffer: Internal.FriendlyByteBuf_): void;
        equals(obj: any): boolean;
        getY(): number;
        get displayName(): net.minecraft.network.chat.Component
        get class(): typeof any
        get rot(): number
        get type(): Internal.MapDecorationType<any, any>
        get x(): number
        set displayName(displayName: net.minecraft.network.chat.Component_)
        set rot(rot: number)
        set x(x: number)
        set y(y: number)
        get y(): number
    }
    type CustomMapDecoration_ = CustomMapDecoration;
    interface LevelTickAccess <T> extends Internal.TickAccess<T> {
        abstract count(): number;
        abstract schedule(arg0: Internal.ScheduledTick_<T>): void;
        abstract willTickThisTick(arg0: BlockPos_, arg1: T): boolean;
        abstract hasScheduledTick(arg0: BlockPos_, arg1: T): boolean;
    }
    type LevelTickAccess_<T> = LevelTickAccess<T>;
    class RenderStateShard$LightmapStateShard extends Internal.RenderStateShard$BooleanStateShard {
        constructor($$0: boolean)
        getClass(): typeof any;
        toString(): string;
        static getTranslucentTransparency(): Internal.RenderStateShard$TransparencyStateShard;
        notifyAll(): void;
        static getGLINT_TRANSPARENCY(): Internal.RenderStateShard$TransparencyStateShard;
        port_lib$setupState(arg0: Internal.Runnable_): void;
        static getNO_TRANSPARENCY$iris_$md$424943$1(): Internal.RenderStateShard$TransparencyStateShard;
        notify(): void;
        static getNO_TRANSPARENCY(): Internal.RenderStateShard$TransparencyStateShard;
        wait(arg0: number, arg1: number): void;
        clearRenderState(): void;
        static getGLINT_TRANSPARENCY$iris_$md$424943$2(): Internal.RenderStateShard$TransparencyStateShard;
        hashCode(): number;
        static getCRUMBLING_TRANSPARENCY$iris_$md$424943$3(): Internal.RenderStateShard$TransparencyStateShard;
        setupRenderState(): void;
        hex$name(): string;
        wait(): void;
        getName(): string;
        static getTranslucentTransparency$iris_$md$424943$0(): Internal.RenderStateShard$TransparencyStateShard;
        wait(arg0: number): void;
        port_lib$clearState(arg0: Internal.Runnable_): void;
        static getCRUMBLING_TRANSPARENCY(): Internal.RenderStateShard$TransparencyStateShard;
        equals(arg0: any): boolean;
        get class(): typeof any
        get translucentTransparency(): Internal.RenderStateShard$TransparencyStateShard
        get GLINT_TRANSPARENCY(): Internal.RenderStateShard$TransparencyStateShard
        get NO_TRANSPARENCY$iris_$md$424943$1(): Internal.RenderStateShard$TransparencyStateShard
        get NO_TRANSPARENCY(): Internal.RenderStateShard$TransparencyStateShard
        get GLINT_TRANSPARENCY$iris_$md$424943$2(): Internal.RenderStateShard$TransparencyStateShard
        get CRUMBLING_TRANSPARENCY$iris_$md$424943$3(): Internal.RenderStateShard$TransparencyStateShard
        get name(): string
        get translucentTransparency$iris_$md$424943$0(): Internal.RenderStateShard$TransparencyStateShard
        get CRUMBLING_TRANSPARENCY(): Internal.RenderStateShard$TransparencyStateShard
    }
    type RenderStateShard$LightmapStateShard_ = RenderStateShard$LightmapStateShard;
    class PointerBuffer extends Internal.CustomBuffer<Internal.PointerBuffer> implements Internal.Comparable<Internal.PointerBuffer> {
        put(arg0: number, arg1: number): this;
        position(arg0: number): this;
        "put(long[],int,int)"(arg0: number[], arg1: number, arg2: number): this;
        limit(): number;
        getPointerBuffer(arg0: number): this;
        put(arg0: number, arg1: Internal.DoubleBuffer_): this;
        getByteBuffer(arg0: number, arg1: number): Internal.ByteBuffer;
        getShortBuffer(arg0: number, arg1: number): Internal.ShortBuffer;
        "compareTo(org.lwjgl.PointerBuffer)"(arg0: Internal.PointerBuffer_): number;
        static "put(java.nio.ByteBuffer,int,long)"(arg0: Internal.ByteBuffer_, arg1: number, arg2: number): void;
        duplicate(): this;
        "put(int,java.nio.ShortBuffer)"(arg0: number, arg1: Internal.ShortBuffer_): this;
        "get(long[])"(arg0: number[]): this;
        putAddressOf(arg0: number, arg1: Internal.CustomBuffer_<any>): this;
        static put(arg0: Internal.ByteBuffer_, arg1: number): void;
        static get(arg0: Internal.ByteBuffer_, arg1: number): number;
        put(arg0: number, arg1: Internal.FloatBuffer_): this;
        limit(arg0: number): this;
        compact(): this;
        static get(arg0: Internal.ByteBuffer_): number;
        "put(int,org.lwjgl.system.Pointer)"(arg0: number, arg1: Internal.Pointer_): this;
        free(): void;
        position(): number;
        "put(java.nio.FloatBuffer)"(arg0: Internal.FloatBuffer_): this;
        slice(): this;
        put(arg0: number, arg1: Internal.LongBuffer_): this;
        getStringASCII(arg0: number): string;
        compareTo(arg0: Internal.PointerBuffer_): number;
        put(arg0: Internal.PointerBuffer_): this;
        put(arg0: number[]): this;
        static allocateDirect(arg0: number): Internal.PointerBuffer;
        get(arg0: number): number;
        static create(arg0: number, arg1: number): Internal.PointerBuffer;
        "compareTo(java.lang.Object)"(arg0: any): number;
        "put(org.lwjgl.PointerBuffer)"(arg0: Internal.PointerBuffer_): this;
        "put(java.nio.IntBuffer)"(arg0: Internal.IntBuffer_): this;
        getClass(): typeof any;
        put(arg0: Internal.IntBuffer_): this;
        put(arg0: number, arg1: Internal.Pointer_): this;
        "put(long[])"(arg0: number[]): this;
        "put(int,java.nio.IntBuffer)"(arg0: number, arg1: Internal.IntBuffer_): this;
        put(arg0: Internal.ByteBuffer_): this;
        put(arg0: Internal.ShortBuffer_): this;
        slice(arg0: number, arg1: number): this;
        address(): number;
        "put(java.nio.LongBuffer)"(arg0: Internal.LongBuffer_): this;
        putAddressOf(arg0: Internal.CustomBuffer_<any>): this;
        toString(): string;
        remaining(): number;
        "put(org.lwjgl.system.Pointer)"(arg0: Internal.Pointer_): this;
        notifyAll(): void;
        "put(java.nio.DoubleBuffer)"(arg0: Internal.DoubleBuffer_): this;
        getIntBuffer(arg0: number): Internal.IntBuffer;
        static put(arg0: Internal.ByteBuffer_, arg1: number, arg2: number): void;
        static "put(java.nio.ByteBuffer,long)"(arg0: Internal.ByteBuffer_, arg1: number): void;
        getFloatBuffer(arg0: number, arg1: number): Internal.FloatBuffer;
        hasRemaining(): boolean;
        getDoubleBuffer(arg0: number, arg1: number): Internal.DoubleBuffer;
        wait(arg0: number): void;
        getByteBuffer(arg0: number): Internal.ByteBuffer;
        getLongBuffer(arg0: number, arg1: number): Internal.LongBuffer;
        "put(int,java.nio.FloatBuffer)"(arg0: number, arg1: Internal.FloatBuffer_): this;
        mark(): this;
        flip(): this;
        clear(): this;
        put(arg0: Internal.DoubleBuffer_): this;
        put(arg0: Internal.LongBuffer_): this;
        getPointerBuffer(arg0: number, arg1: number): this;
        put(arg0: number[], arg1: number, arg2: number): this;
        notify(): void;
        static "get(java.nio.ByteBuffer)"(arg0: Internal.ByteBuffer_): number;
        getStringUTF8(): string;
        compareTo(arg0: any): number;
        getShortBuffer(arg0: number): Internal.ShortBuffer;
        address(arg0: number): number;
        "put(int,java.nio.LongBuffer)"(arg0: number, arg1: Internal.LongBuffer_): this;
        get(arg0: number[], arg1: number, arg2: number): this;
        getStringUTF16(): string;
        sizeof(): number;
        rewind(): this;
        "put(int,long)"(arg0: number, arg1: number): this;
        put(arg0: Internal.FloatBuffer_): this;
        wait(): void;
        "put(int,java.nio.DoubleBuffer)"(arg0: number, arg1: Internal.DoubleBuffer_): this;
        "get(int)"(arg0: number): number;
        "put(java.nio.ByteBuffer)"(arg0: Internal.ByteBuffer_): this;
        getStringUTF16(arg0: number): string;
        put(arg0: number, arg1: Internal.ByteBuffer_): this;
        static create(arg0: Internal.ByteBuffer_): Internal.PointerBuffer;
        put(arg0: number, arg1: Internal.ShortBuffer_): this;
        capacity(): number;
        "put(java.nio.ShortBuffer)"(arg0: Internal.ShortBuffer_): this;
        get(arg0: number[]): this;
        "put(long)"(arg0: number): this;
        wait(arg0: number, arg1: number): void;
        put(arg0: Internal.Pointer_): this;
        put(arg0: number, arg1: Internal.IntBuffer_): this;
        getStringASCII(): string;
        get(): number;
        getFloatBuffer(arg0: number): Internal.FloatBuffer;
        "put(int,java.nio.ByteBuffer)"(arg0: number, arg1: Internal.ByteBuffer_): this;
        getStringUTF8(arg0: number): string;
        put(arg0: number): this;
        hashCode(): number;
        address0(): number;
        getLongBuffer(arg0: number): Internal.LongBuffer;
        getDoubleBuffer(arg0: number): Internal.DoubleBuffer;
        equals(arg0: any): boolean;
        reset(): this;
        getIntBuffer(arg0: number, arg1: number): Internal.IntBuffer;
        get class(): typeof any
        get stringUTF8(): string
        get stringUTF16(): string
        get stringASCII(): string
    }
    type PointerBuffer_ = PointerBuffer;
    class GameEventListenerRenderer implements Internal.DebugRenderer$SimpleDebugRenderer {
        constructor($$0: Internal.Minecraft_)
        getClass(): typeof any;
        trackGameEvent($$0: Internal.GameEvent_, $$1: Vec3d_): void;
        toString(): string;
        notifyAll(): void;
        trackListener($$0: Internal.PositionSource_, $$1: number): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        render($$0: Internal.PoseStack_, $$1: Internal.MultiBufferSource_, $$2: number, $$3: number, $$4: number): void;
        wait(): void;
        clear(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        get class(): typeof any
    }
    type GameEventListenerRenderer_ = GameEventListenerRenderer;
    interface SpruceElement extends Internal.GuiEventListener {
        charTyped($$0: string, $$1: number): boolean;
        abstract isFocused(): boolean;
        requiresCursor(): boolean;
        abstract setFocused(arg0: boolean): void;
        mouseReleased($$0: number, $$1: number, $$2: number): boolean;
        getTabOrderGroup(): number;
        mouseScrolled($$0: number, $$1: number, $$2: number): boolean;
        keyReleased($$0: number, $$1: number, $$2: number): boolean;
        mouseClicked($$0: number, $$1: number, $$2: number): boolean;
        keyPressed($$0: number, $$1: number, $$2: number): boolean;
        getCurrentFocusPath(): Internal.ComponentPath;
        mouseDragged($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): boolean;
        mouseMoved($$0: number, $$1: number): void;
        onNavigation(direction: Internal.NavigationDirection_, tab: boolean): boolean;
        getRectangle(): Internal.ScreenRectangle;
        isMouseOver($$0: number, $$1: number): boolean;
        nextFocusPath($$0: Internal.FocusNavigationEvent_): Internal.ComponentPath;
        get focused(): boolean
        set focused(arg0: boolean)
        get tabOrderGroup(): number
        get currentFocusPath(): Internal.ComponentPath
        get rectangle(): Internal.ScreenRectangle
    }
    type SpruceElement_ = SpruceElement;
    class DesertWellFeature extends Feature<Internal.NoneFeatureConfiguration> {
        constructor($$0: Internal.Codec_<Internal.NoneFeatureConfiguration>)
        getClass(): typeof any;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        place($$0: Internal.NoneFeatureConfiguration_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        place($$0: Internal.FeaturePlaceContext_<Internal.NoneFeatureConfiguration>): boolean;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.NoneFeatureConfiguration, Feature<Internal.NoneFeatureConfiguration>>>;
        get class(): typeof any
    }
    type DesertWellFeature_ = DesertWellFeature;
    interface PersistentEffectHelper$PersistentEffectData {
    }
    type PersistentEffectHelper$PersistentEffectData_ = PersistentEffectHelper$PersistentEffectData;
    class YungJigsawStructure extends Internal.Structure {
        constructor(structureSettings: Internal.Structure$StructureSettings_, startPool: Internal.Holder_<Internal.StructureTemplatePool>, startJigsawName: Optional_<ResourceLocation>, maxDepth: number, startHeight: Internal.HeightProvider_, xOffsetInChunk: Internal.IntProvider_, zOffsetInChunk: Internal.IntProvider_, useExpansionHack: boolean, projectStartToHeightmap: Optional_<Internal.Heightmap$Types>, maxBlockDistanceFromCenter: number, maxY: Optional_<number>, minY: Optional_<number>, enhancedTerrainAdaptation: Internal.EnhancedTerrainAdaptation_)
        static simpleCodec<S extends Internal.Structure>($$0: Internal.Function_<Internal.Structure$StructureSettings, S>): Internal.Codec<S>;
        getClass(): typeof any;
        generate($$0: Internal.RegistryAccess_, $$1: Internal.ChunkGenerator_, $$2: Internal.BiomeSource_, $$3: Internal.RandomState_, $$4: Internal.StructureTemplateManager_, $$5: number, $$6: Internal.ChunkPos_, $$7: number, $$8: Internal.LevelHeightAccessor_, $$9: Internal.Predicate_<Internal.Holder<Internal.Biome>>): Internal.StructureStart;
        toString(): string;
        biomes(): Internal.HolderSet<Internal.Biome>;
        findValidGenerationPoint($$0: Internal.Structure$GenerationContext_): Optional<Internal.Structure$GenerationStub>;
        spawnOverrides(): Internal.Map<Internal.MobCategory, Internal.StructureSpawnOverride>;
        step(): Internal.GenerationStep$Decoration;
        notifyAll(): void;
        notify(): void;
        terrainAdaptation(): Internal.TerrainAdjustment;
        wait(arg0: number, arg1: number): void;
        adjustBoundingBox(boundingBox: Internal.BoundingBox_): Internal.BoundingBox;
        hashCode(): number;
        type(): Internal.StructureType<any>;
        static settingsCodec<S extends Internal.Structure>($$0: Internal.RecordCodecBuilder$Instance_<S>): Internal.RecordCodecBuilder<S, Internal.Structure$StructureSettings>;
        method_38676(context: Internal.Structure$GenerationContext_): Optional<Internal.Structure$GenerationStub>;
        structurify$setStructureIdentifier(structureSetIdentifier: ResourceLocation_): void;
        wait(): void;
        structurify$getStructureIdentifier(): ResourceLocation;
        wait(arg0: number): void;
        afterPlace($$0: Internal.WorldGenLevel_, $$1: Internal.StructureManager_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: Internal.BoundingBox_, $$5: Internal.ChunkPos_, $$6: Internal.PiecesContainer_): void;
        equals(arg0: any): boolean;
        setStructureBiomes(newBiomes: Internal.HolderSet_<any>): void;
        get class(): typeof any
        set tingsCodec($$0: Internal.RecordCodecBuilder$Instance_<S>)
        set structureBiomes(newBiomes: Internal.HolderSet_<any>)
        readonly maxDepth: number;
        readonly minY: Optional<number>;
        readonly zOffsetInChunk: Internal.IntProvider;
        static readonly MAX_TOTAL_STRUCTURE_RADIUS: (128) & (number);
        readonly startPool: Internal.Holder<Internal.StructureTemplatePool>;
        readonly maxDistanceFromCenter: number;
        readonly maxY: Optional<number>;
        readonly projectStartToHeightmap: Optional<Internal.Heightmap$Types>;
        readonly startHeight: Internal.HeightProvider;
        readonly xOffsetInChunk: Internal.IntProvider;
        readonly useExpansionHack: boolean;
        static readonly CODEC: Internal.Codec<Internal.YungJigsawStructure>;
        readonly enhancedTerrainAdaptation: Internal.EnhancedTerrainAdaptation;
    }
    type YungJigsawStructure_ = YungJigsawStructure;
    class PistonMovingBlockEntity extends Internal.BlockEntity implements Internal.IExtendedPistonTile, Internal.IBlockHolder {
        constructor($$0: BlockPos_, $$1: Internal.BlockState_, $$2: Internal.BlockState_, $$3: Internal.Direction_, $$4: boolean, $$5: boolean)
        constructor($$0: BlockPos_, $$1: Internal.BlockState_)
        handler$efn000$collective$setLevel(level: Internal.Level_, ci: Internal.CallbackInfo_): void;
        emf$hasVehicle(): boolean;
        isSourcePiston(): boolean;
        etf$getType(): Internal.EntityType<any>;
        emf$getVelocity(): Vec3d;
        etf$isBlockEntity(): boolean;
        /**
         * @deprecated
        */
        setBlockState($$0: Internal.BlockState_): void;
        hasAttached(type: Internal.AttachmentType_<any>): boolean;
        load($$0: Internal.CompoundTag_): void;
        setChanged(): void;
        tickMovedBlock(level: Internal.Level_, pos: BlockPos_): void;
        setCulled(value: boolean): void;
        saveWithoutMetadata(): Internal.CompoundTag;
        setTimeout(): void;
        getAttachedOrSet<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        isExtending(): boolean;
        removeAttached<A>(type: Internal.AttachmentType_<A>): A;
        isOutOfCamera(): boolean;
        emf$prevZ(): number;
        static tick($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.PistonMovingBlockEntity_): void;
        getXOff($$0: number): number;
        etf$canBeBright(): boolean;
        setRemoved(): void;
        asComponentProvider(): Internal.ComponentProvider;
        emf$isOnGround(): boolean;
        handler$efn000$collective$setRemoved(ci: Internal.CallbackInfo_): void;
        etf$getEntityKey(): string;
        etf$getPose(): Internal.Pose;
        isCulled(): boolean;
        getType(): Internal.BlockEntityType<any>;
        static transfer(original: Internal.AttachmentTarget_, target: Internal.AttachmentTarget_, isDeath: boolean): void;
        etf$getOptifineId(): number;
        getCustomData(): Internal.CompoundTag;
        static moveCollidedEntities($$0: Internal.Level_, $$1: BlockPos_, $$2: number, $$3: Internal.PistonMovingBlockEntity_): void;
        finalTick(): void;
        getClass(): typeof any;
        emf$isInvisible(): boolean;
        static getPosFromTag($$0: Internal.CompoundTag_): BlockPos;
        etf$distanceTo(entity: Internal.Entity_): number;
        emf$isSprinting(): boolean;
        hasAnyComparatorNearby(): boolean;
        saveToItem($$0: Internal.ItemStack_): void;
        invokeWriteNbt(arg0: Internal.CompoundTag_): void;
        "deserializeNBT(net.minecraft.nbt.CompoundTag)"(nbt: Internal.CompoundTag_): void;
        static addEntityType($$0: Internal.CompoundTag_, $$1: Internal.BlockEntityType_<any>): void;
        emf$isInLava(): boolean;
        "deserializeNBT(net.minecraft.nbt.Tag)"(arg0: Internal.Tag_): void;
        getMovedState(): Internal.BlockState;
        onComparatorAdded(direction: Internal.Direction_, offset: number): void;
        getUpdatePacket(): Internal.Packet<Internal.ClientGamePacketListener>;
        getLastTicked(): number;
        fabric_hasPersistentAttachments(): boolean;
        clearRemoved(): void;
        emf$isWet(): boolean;
        getProgress($$0: number): number;
        getZOff($$0: number): number;
        owo$setCachedState(arg0: Internal.BlockState_): void;
        fabric_getAttachments(): Internal.Map<any, any>;
        toString(): string;
        triggerEvent($$0: number, $$1: number): boolean;
        emf$isGlowing(): boolean;
        hasLevel(): boolean;
        notifyAll(): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        etf$getScoreboardTeam(): Internal.Team;
        emf$getZ(): number;
        getCollisionShape($$0: Internal.BlockGetter_, $$1: BlockPos_): Internal.VoxelShape;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>, initializer: Internal.Supplier_<A>): A;
        abstract setHeldBlock(arg0: Internal.BlockState_, arg1: number): boolean;
        wait(arg0: number): void;
        etf$getItemsEquipped(): Internal.Iterable<any>;
        getAttachedOrThrow<A>(type: Internal.AttachmentType_<A>): A;
        etf$getVelocity(): Vec3d;
        handler$jhd000$moonlight$onFinishedShortPulse(ci: Internal.CallbackInfo_): void;
        getAttached(type: Internal.AttachmentType_<any>): any;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        etf$getWorld(): Internal.Level;
        getUpdateTag(): Internal.CompoundTag;
        getRenderAttachmentData(): any;
        emf$getYaw(): number;
        getHeldBlock(): Internal.BlockState;
        modifyAttached<A>(type: Internal.AttachmentType_<A>, modifier: Internal.UnaryOperator_<A>): A;
        setLevel($$0: Internal.Level_): void;
        notify(): void;
        getBlockPos(): BlockPos;
        isRemoved(): boolean;
        etf$getNbt(): Internal.CompoundTag;
        emf$isSneaking(): boolean;
        etf$getBlockPos(): BlockPos;
        onLoad(): void;
        fillCrashReportCategory($$0: Internal.CrashReportCategory_): void;
        emf$prevPitch(): number;
        etf$getBlockY(): number;
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        etf$getHandItems(): Internal.Iterable<any>;
        etf$getArmorItems(): Internal.Iterable<any>;
        emf$getY(): number;
        invalidateCaps(): void;
        emf$prevX(): number;
        getBlockState(): Internal.BlockState;
        handler$zzl000$porting_lib_base$port_lib$invalidate(ci: Internal.CallbackInfo_): void;
        toComponentPacket(key: Internal.ComponentKey_<any>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        setHeldBlock(state: Internal.BlockState_): boolean;
        abstract getHeldBlock(arg0: number): Internal.BlockState;
        getAttachedOrGet<A>(type: Internal.AttachmentType_<A>, defaultValue: Internal.Supplier_<A>): A;
        emf$age(): number;
        etf$hasCustomName(): boolean;
        static loadStatic($$0: BlockPos_, $$1: Internal.BlockState_, $$2: Internal.CompoundTag_): Internal.BlockEntity;
        wait(): void;
        emf$isTouchingWater(): boolean;
        emf$getVariableMap(): Internal.Object2FloatOpenHashMap<any>;
        getComponentContainer(): Internal.ComponentContainer;
        etf$getCustomName(): net.minecraft.network.chat.Component;
        getMovementDirection(): Internal.Direction;
        fabric_writeAttachmentsToNbt(nbt: Internal.CompoundTag_): void;
        saveWithId(): Internal.CompoundTag;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>): A;
        setOutOfCamera(value: boolean): void;
        wait(arg0: number, arg1: number): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        getLevel(): Internal.Level;
        onlyOpCanSetNbt(): boolean;
        port_lib$saveMetadata(arg0: Internal.CompoundTag_): void;
        serializeNBT(): Internal.Tag;
        saveWithFullMetadata(): Internal.CompoundTag;
        emf$prevY(): number;
        emf$getX(): number;
        deserializeNBT(arg0: Internal.Tag_): void;
        emf$isOnFire(): boolean;
        static moveStuckEntities($$0: Internal.Level_, $$1: BlockPos_, $$2: number, $$3: Internal.PistonMovingBlockEntity_): void;
        etf$getUuid(): Internal.UUID;
        getRecipientsForComponentSync(): Internal.Iterable<any>;
        deserializeNBT(state: Internal.BlockState_, nbt: Internal.CompoundTag_): void;
        isForcedVisible(): boolean;
        emf$hasPassengers(): boolean;
        setAttached(type: Internal.AttachmentType_<any>, value: any): any;
        getYOff($$0: number): number;
        deserializeNBT(nbt: Internal.CompoundTag_): void;
        fabric_readAttachmentsFromNbt(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        emf$getTypeString(): string;
        getAttachedOrElse<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        getRenderData(): any;
        emf$getPitch(): number;
        emf$isAlive(): boolean;
        equals(arg0: any): boolean;
        getDirection(): Internal.Direction;
        get sourcePiston(): boolean
        /**
         * @deprecated
        */
        set blockState($$0: Internal.BlockState_)
        set culled(value: boolean)
        get extending(): boolean
        get outOfCamera(): boolean
        get culled(): boolean
        get type(): Internal.BlockEntityType<any>
        get customData(): Internal.CompoundTag
        get class(): typeof any
        get movedState(): Internal.BlockState
        get updatePacket(): Internal.Packet<Internal.ClientGamePacketListener>
        get lastTicked(): number
        get updateTag(): Internal.CompoundTag
        get renderAttachmentData(): any
        get heldBlock(): Internal.BlockState
        set level($$0: Internal.Level_)
        get blockPos(): BlockPos
        get removed(): boolean
        get blockState(): Internal.BlockState
        set heldBlock(state: Internal.BlockState_)
        get componentContainer(): Internal.ComponentContainer
        get movementDirection(): Internal.Direction
        set outOfCamera(value: boolean)
        get level(): Internal.Level
        get recipientsForComponentSync(): Internal.Iterable<any>
        get forcedVisible(): boolean
        get renderData(): any
        get direction(): Internal.Direction
        static readonly TICK_MOVEMENT: (0.51) & (number);
        deathTicks: number;
        progressO: number;
        progress: number;
        lastTicked: number;
    }
    type PistonMovingBlockEntity_ = PistonMovingBlockEntity;
    class BufferedReader extends Internal.Reader {
        constructor(arg0: Internal.Reader_, arg1: number)
        constructor(arg0: Internal.Reader_)
        getClass(): typeof any;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        read(arg0: Internal.CharBuffer_): number;
        read(arg0: string[]): number;
        reset(): void;
        toString(): string;
        read(): number;
        markSupported(): boolean;
        mark(arg0: number): void;
        notifyAll(): void;
        "read(char[])"(arg0: string[]): number;
        read(arg0: string[], arg1: number, arg2: number): number;
        ready(): boolean;
        skip(arg0: number): number;
        static nullReader(): Internal.Reader;
        "read(java.nio.CharBuffer)"(arg0: Internal.CharBuffer_): number;
        transferTo(arg0: Internal.Writer_): number;
        hashCode(): number;
        readLine(): string;
        wait(): void;
        close(): void;
        wait(arg0: number): void;
        lines(): Internal.Stream<string>;
        equals(arg0: any): boolean;
        get class(): typeof any
    }
    type BufferedReader_ = BufferedReader;
    class BookItem extends Internal.Item {
        constructor($$0: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type BookItem_ = BookItem;
    interface FoliagePlacerTypeInvoker {
        callRegister<P extends Internal.FoliagePlacer>(id: string, codec: Internal.Codec_<P>): Internal.FoliagePlacerType<P>;
    }
    type FoliagePlacerTypeInvoker_ = FoliagePlacerTypeInvoker;
    class UnderwaterMagmaFeature extends Feature<Internal.UnderwaterMagmaConfiguration> {
        constructor($$0: Internal.Codec_<Internal.UnderwaterMagmaConfiguration>)
        getClass(): typeof any;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        wait(): void;
        place($$0: Internal.UnderwaterMagmaConfiguration_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        wait(arg0: number): void;
        place($$0: Internal.FeaturePlaceContext_<Internal.UnderwaterMagmaConfiguration>): boolean;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.UnderwaterMagmaConfiguration, Feature<Internal.UnderwaterMagmaConfiguration>>>;
        get class(): typeof any
    }
    type UnderwaterMagmaFeature_ = UnderwaterMagmaFeature;
    interface ScreenMouseEvents$BeforeMouseRelease {
        abstract beforeMouseRelease(arg0: Internal.Screen_, arg1: number, arg2: number, arg3: number): void;
        (arg0: Internal.Screen, arg1: number, arg2: number, arg3: number): void;
    }
    type ScreenMouseEvents$BeforeMouseRelease_ = ScreenMouseEvents$BeforeMouseRelease | ((arg0: Internal.Screen, arg1: number, arg2: number, arg3: number)=> void);
    class ItemDyePigment extends Internal.Item implements Internal.PigmentItem {
        constructor(dyeColor: Internal.DyeColor_, pProperties: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        getDyeColor(): Internal.DyeColor;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        provideColor(stack: Internal.ItemStack_, owner: Internal.UUID_): Internal.ColorProvider;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get dyeColor(): Internal.DyeColor
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type ItemDyePigment_ = ItemDyePigment;
    class TeamPropertyValue <T> {
        constructor(property: Internal.TeamProperty_<T>, value: T)
        constructor(k: Internal.TeamProperty_<T>)
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        copy(): this;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        setValue(value: T): void;
        wait(): void;
        getValue(): T;
        wait(arg0: number): void;
        getProperty(): Internal.TeamProperty<T>;
        equals(arg0: any): boolean;
        get class(): typeof any
        set value(value: T)
        get value(): T
        get property(): Internal.TeamProperty<T>
    }
    type TeamPropertyValue_<T> = TeamPropertyValue<T>;
    interface SwitchablePlayerEntity {
        abstract cca$isSwitchingCharacter(): boolean;
        abstract cca$markAsSwitchingCharacter(): void;
    }
    type SwitchablePlayerEntity_ = SwitchablePlayerEntity;
    interface NeutralMob {
        abstract getTarget(): Internal.LivingEntity;
        playerDied($$0: Internal.Player_): void;
        abstract getPersistentAngerTarget(): Internal.UUID;
        isAngry(): boolean;
        abstract setLastHurtByMob(arg0: Internal.LivingEntity_): void;
        forgetCurrentTargetAndRefreshUniversalAnger(): void;
        abstract startPersistentAngerTimer(): void;
        readPersistentAngerSaveData($$0: Internal.Level_, $$1: Internal.CompoundTag_): void;
        abstract canAttack(arg0: Internal.LivingEntity_): boolean;
        stopBeingAngry(): void;
        abstract setLastHurtByPlayer(arg0: Internal.Player_): void;
        abstract setTarget(arg0: Internal.LivingEntity_): void;
        abstract setPersistentAngerTarget(arg0: Internal.UUID_): void;
        addPersistentAngerSaveData($$0: Internal.CompoundTag_): void;
        abstract setRemainingPersistentAngerTime(arg0: number): void;
        abstract getLastHurtByMob(): Internal.LivingEntity;
        updatePersistentAnger($$0: Internal.ServerLevel_, $$1: boolean): void;
        isAngryAtAllPlayers($$0: Internal.Level_): boolean;
        isAngryAt($$0: Internal.LivingEntity_): boolean;
        abstract getRemainingPersistentAngerTime(): number;
        get target(): Internal.LivingEntity
        get persistentAngerTarget(): Internal.UUID
        get angry(): boolean
        set lastHurtByMob(arg0: Internal.LivingEntity_)
        set lastHurtByPlayer(arg0: Internal.Player_)
        set target(arg0: Internal.LivingEntity_)
        set persistentAngerTarget(arg0: Internal.UUID_)
        set remainingPersistentAngerTime(arg0: number)
        get lastHurtByMob(): Internal.LivingEntity
        get remainingPersistentAngerTime(): number
        readonly TAG_ANGER_TIME: ("AngerTime") & (string);
        readonly TAG_ANGRY_AT: ("AngryAt") & (string);
    }
    type NeutralMob_ = NeutralMob;
    interface ChunkRegionAccessor {
        abstract getStructureAccessor(): Internal.StructureManager;
        get structureAccessor(): Internal.StructureManager
        (): Internal.StructureManager_;
    }
    type ChunkRegionAccessor_ = ChunkRegionAccessor | (()=> Internal.StructureManager_);
    interface UnmodifiableConfig {
        "getLongOrElse(java.util.List,long)"(path: Internal.List_<string>, defaultValue: number): number;
        "get(java.util.List)"<T>(path: Internal.List_<string>): T;
        getEnum<T extends Internal.Enum<T>>(path: Internal.List_<string>, enumType: T): T;
        "getByteOrElse(java.util.List,byte)"(path: Internal.List_<string>, defaultValue: number): number;
        getByteOrElse(path: string, defaultValue: number): number;
        getShortOrElse(path: string, defaultValue: number): number;
        getInt(path: Internal.List_<string>): number;
        abstract configFormat(): Internal.ConfigFormat<any>;
        "getChar(java.lang.String)"(path: string): string;
        "getOptional(java.lang.String)"<T>(path: string): Optional<T>;
        getEnum<T extends Internal.Enum<T>>(path: Internal.List_<string>, enumType: T, method: Internal.EnumGetMethod_): T;
        "apply(java.lang.String)"<T>(path: string): T;
        getShortOrElse(path: Internal.List_<string>, defaultValue: number): number;
        "getEnumOrElse(java.util.List,java.lang.Class,java.util.function.Supplier)"<T extends Internal.Enum<T>>(path: Internal.List_<string>, enumType: T, defaultValueSupplier: Internal.Supplier_<T>): T;
        "getRaw(java.lang.String)"<T>(path: string): T;
        getIntOrElse(path: Internal.List_<string>, defaultValue: number): number;
        abstract getRaw<T>(arg0: Internal.List_<string>): T;
        "getEnumOrElse(java.lang.String,java.lang.Enum)"<T extends Internal.Enum<T>>(path: string, defaultValue: T): T;
        "getOptionalInt(java.util.List)"(path: Internal.List_<string>): Internal.OptionalInt;
        "getOptionalLong(java.util.List)"(path: Internal.List_<string>): Internal.OptionalLong;
        abstract entrySet(): Internal.Set<Internal.UnmodifiableConfig$Entry>;
        "getCharOrElse(java.util.List,char)"(path: Internal.List_<string>, defaultValue: string): string;
        getOptionalLong(path: string): Internal.OptionalLong;
        "getIntOrElse(java.lang.String,java.util.function.IntSupplier)"(path: string, defaultValueSupplier: Internal.IntSupplier_): number;
        abstract "getRaw(java.util.List)"<T>(arg0: Internal.List_<string>): T;
        "getEnumOrElse(java.lang.String,java.lang.Class,dev.lambdaurora.lambdynlights.shadow.nightconfig.core.EnumGetMethod,java.util.function.Supplier)"<T extends Internal.Enum<T>>(path: string, enumType: T, method: Internal.EnumGetMethod_, defaultValueSupplier: Internal.Supplier_<T>): T;
        getEnum<T extends Internal.Enum<T>>(path: string, enumType: T): T;
        "getIntOrElse(java.util.List,java.util.function.IntSupplier)"(path: Internal.List_<string>, defaultValueSupplier: Internal.IntSupplier_): number;
        "getOptionalEnum(java.util.List,java.lang.Class)"<T extends Internal.Enum<T>>(path: Internal.List_<string>, enumType: T): Optional<T>;
        getEnumOrElse<T extends Internal.Enum<T>>(path: string, defaultValue: T, method: Internal.EnumGetMethod_): T;
        "getShort(java.lang.String)"(path: string): number;
        "getOptionalEnum(java.lang.String,java.lang.Class,dev.lambdaurora.lambdynlights.shadow.nightconfig.core.EnumGetMethod)"<T extends Internal.Enum<T>>(path: string, enumType: T, method: Internal.EnumGetMethod_): Optional<T>;
        "contains(java.lang.String)"(path: string): boolean;
        "getLongOrElse(java.util.List,java.util.function.LongSupplier)"(path: Internal.List_<string>, defaultValueSupplier: Internal.LongSupplier_): number;
        getOptionalLong(path: Internal.List_<string>): Internal.OptionalLong;
        "getEnum(java.lang.String,java.lang.Class,dev.lambdaurora.lambdynlights.shadow.nightconfig.core.EnumGetMethod)"<T extends Internal.Enum<T>>(path: string, enumType: T, method: Internal.EnumGetMethod_): T;
        get<T>(path: string): T;
        abstract contains(arg0: Internal.List_<string>): boolean;
        getLong(path: Internal.List_<string>): number;
        getOptionalEnum<T extends Internal.Enum<T>>(path: Internal.List_<string>, enumType: T, method: Internal.EnumGetMethod_): Optional<T>;
        apply<T>(path: Internal.List_<string>): T;
        getLongOrElse(path: Internal.List_<string>, defaultValueSupplier: Internal.LongSupplier_): number;
        getInt(path: string): number;
        "getOptional(java.util.List)"<T>(path: Internal.List_<string>): Optional<T>;
        getRaw<T>(path: string): T;
        getIntOrElse(path: string, defaultValueSupplier: Internal.IntSupplier_): number;
        "getOrElse(java.util.List,java.util.function.Supplier)"<T>(path: Internal.List_<string>, defaultValueSupplier: Internal.Supplier_<T>): T;
        isNull(path: string): boolean;
        getOptionalEnum<T extends Internal.Enum<T>>(path: Internal.List_<string>, enumType: T): Optional<T>;
        "getLong(java.lang.String)"(path: string): number;
        "getEnum(java.util.List,java.lang.Class,dev.lambdaurora.lambdynlights.shadow.nightconfig.core.EnumGetMethod)"<T extends Internal.Enum<T>>(path: Internal.List_<string>, enumType: T, method: Internal.EnumGetMethod_): T;
        getEnumOrElse<T extends Internal.Enum<T>>(path: string, defaultValue: T): T;
        getByteOrElse(path: Internal.List_<string>, defaultValue: number): number;
        getLongOrElse(path: string, defaultValue: number): number;
        getOptionalInt(path: string): Internal.OptionalInt;
        getEnumOrElse<T extends Internal.Enum<T>>(path: Internal.List_<string>, enumType: T, defaultValueSupplier: Internal.Supplier_<T>): T;
        getOptionalEnum<T extends Internal.Enum<T>>(path: string, enumType: T, method: Internal.EnumGetMethod_): Optional<T>;
        getIntOrElse(path: string, defaultValue: number): number;
        getOptionalInt(path: Internal.List_<string>): Internal.OptionalInt;
        abstract size(): number;
        "getShortOrElse(java.util.List,short)"(path: Internal.List_<string>, defaultValue: number): number;
        /**
         * @deprecated
        */
        abstract valueMap(): Internal.Map<string, any>;
        "get(java.lang.String)"<T>(path: string): T;
        getEnumOrElse<T extends Internal.Enum<T>>(path: string, enumType: T, defaultValueSupplier: Internal.Supplier_<T>): T;
        "getByte(java.lang.String)"(path: string): number;
        "getOptionalEnum(java.util.List,java.lang.Class,dev.lambdaurora.lambdynlights.shadow.nightconfig.core.EnumGetMethod)"<T extends Internal.Enum<T>>(path: Internal.List_<string>, enumType: T, method: Internal.EnumGetMethod_): Optional<T>;
        apply<T>(path: string): T;
        getOrElse<T>(path: string, defaultValue: T): T;
        "getLongOrElse(java.lang.String,long)"(path: string, defaultValue: number): number;
        "getLong(java.util.List)"(path: Internal.List_<string>): number;
        "getChar(java.util.List)"(path: Internal.List_<string>): string;
        "getEnum(java.lang.String,java.lang.Class)"<T extends Internal.Enum<T>>(path: string, enumType: T): T;
        getLong(path: string): number;
        "getOptionalLong(java.lang.String)"(path: string): Internal.OptionalLong;
        "getEnumOrElse(java.util.List,java.lang.Enum,dev.lambdaurora.lambdynlights.shadow.nightconfig.core.EnumGetMethod)"<T extends Internal.Enum<T>>(path: Internal.List_<string>, defaultValue: T, method: Internal.EnumGetMethod_): T;
        getCharOrElse(path: string, defaultValue: string): string;
        get<T>(path: Internal.List_<string>): T;
        getEnumOrElse<T extends Internal.Enum<T>>(path: string, enumType: T, method: Internal.EnumGetMethod_, defaultValueSupplier: Internal.Supplier_<T>): T;
        contains(path: string): boolean;
        "getShort(java.util.List)"(path: Internal.List_<string>): number;
        getShort(path: Internal.List_<string>): number;
        isNull(path: Internal.List_<string>): boolean;
        abstract "contains(java.util.List)"(arg0: Internal.List_<string>): boolean;
        getOrElse<T>(path: Internal.List_<string>, defaultValueSupplier: Internal.Supplier_<T>): T;
        "getOptionalEnum(java.lang.String,java.lang.Class)"<T extends Internal.Enum<T>>(path: string, enumType: T): Optional<T>;
        "getOrElse(java.util.List,java.lang.Object)"<T>(path: Internal.List_<string>, defaultValue: T): T;
        getOptional<T>(path: Internal.List_<string>): Optional<T>;
        "getLongOrElse(java.lang.String,java.util.function.LongSupplier)"(path: string, defaultValueSupplier: Internal.LongSupplier_): number;
        getOptional<T>(path: string): Optional<T>;
        "getByte(java.util.List)"(path: Internal.List_<string>): number;
        getOrElse<T>(path: string, defaultValueSupplier: Internal.Supplier_<T>): T;
        getShort(path: string): number;
        "getEnum(java.util.List,java.lang.Class)"<T extends Internal.Enum<T>>(path: Internal.List_<string>, enumType: T): T;
        "getInt(java.util.List)"(path: Internal.List_<string>): number;
        "getByteOrElse(java.lang.String,byte)"(path: string, defaultValue: number): number;
        getOrElse<T>(path: Internal.List_<string>, defaultValue: T): T;
        getChar(path: string): string;
        getEnumOrElse<T extends Internal.Enum<T>>(path: Internal.List_<string>, defaultValue: T, method: Internal.EnumGetMethod_): T;
        getChar(path: Internal.List_<string>): string;
        "getEnumOrElse(java.lang.String,java.lang.Class,java.util.function.Supplier)"<T extends Internal.Enum<T>>(path: string, enumType: T, defaultValueSupplier: Internal.Supplier_<T>): T;
        "getIntOrElse(java.util.List,int)"(path: Internal.List_<string>, defaultValue: number): number;
        getLongOrElse(path: Internal.List_<string>, defaultValue: number): number;
        "getOrElse(java.lang.String,java.lang.Object)"<T>(path: string, defaultValue: T): T;
        isEmpty(): boolean;
        "getOptionalInt(java.lang.String)"(path: string): Internal.OptionalInt;
        getIntOrElse(path: Internal.List_<string>, defaultValueSupplier: Internal.IntSupplier_): number;
        "getInt(java.lang.String)"(path: string): number;
        "getEnumOrElse(java.util.List,java.lang.Enum)"<T extends Internal.Enum<T>>(path: Internal.List_<string>, defaultValue: T): T;
        "getEnumOrElse(java.lang.String,java.lang.Enum,dev.lambdaurora.lambdynlights.shadow.nightconfig.core.EnumGetMethod)"<T extends Internal.Enum<T>>(path: string, defaultValue: T, method: Internal.EnumGetMethod_): T;
        getEnum<T extends Internal.Enum<T>>(path: string, enumType: T, method: Internal.EnumGetMethod_): T;
        "getOrElse(java.lang.String,java.util.function.Supplier)"<T>(path: string, defaultValueSupplier: Internal.Supplier_<T>): T;
        getEnumOrElse<T extends Internal.Enum<T>>(path: Internal.List_<string>, defaultValue: T): T;
        getCharOrElse(path: Internal.List_<string>, defaultValue: string): string;
        getByte(path: Internal.List_<string>): number;
        getOptionalEnum<T extends Internal.Enum<T>>(path: string, enumType: T): Optional<T>;
        getLongOrElse(path: string, defaultValueSupplier: Internal.LongSupplier_): number;
        "isNull(java.lang.String)"(path: string): boolean;
        "getIntOrElse(java.lang.String,int)"(path: string, defaultValue: number): number;
        getByte(path: string): number;
        "getEnumOrElse(java.util.List,java.lang.Class,dev.lambdaurora.lambdynlights.shadow.nightconfig.core.EnumGetMethod,java.util.function.Supplier)"<T extends Internal.Enum<T>>(path: Internal.List_<string>, enumType: T, method: Internal.EnumGetMethod_, defaultValueSupplier: Internal.Supplier_<T>): T;
        "getCharOrElse(java.lang.String,char)"(path: string, defaultValue: string): string;
        "apply(java.util.List)"<T>(path: Internal.List_<string>): T;
        "getShortOrElse(java.lang.String,short)"(path: string, defaultValue: number): number;
        "isNull(java.util.List)"(path: Internal.List_<string>): boolean;
        getEnumOrElse<T extends Internal.Enum<T>>(path: Internal.List_<string>, enumType: T, method: Internal.EnumGetMethod_, defaultValueSupplier: Internal.Supplier_<T>): T;
        get empty(): boolean
    }
    type UnmodifiableConfig_ = UnmodifiableConfig;
    class BlockstateCopyItem extends Internal.Item {
        constructor(properties: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, worldIn: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, flagIn: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn(context: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        static addProperties(block: Internal.Block_, ...properties: Internal.Property_<any>[]): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
        static allowedProperties: ({[key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: any, [key: any]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.HugeMushroomBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.HugeMushroomBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StainedGlassPaneBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.StainedGlassPaneBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.HugeMushroomBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StainedGlassPaneBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StainedGlassPaneBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.HayBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RepeaterBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.StainedGlassPaneBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.StainedGlassPaneBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.HugeMushroomBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.HayBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StainedGlassPaneBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RedStoneWireBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.HugeMushroomBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.HugeMushroomBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.HugeMushroomBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StainedGlassPaneBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WeatheringCopperStairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.HugeMushroomBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.HayBlock]: any, [key: any]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.HayBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.DispenserBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.HayBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.DropperBlock]: any, [key: any]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.ObserverBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StainedGlassPaneBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.HayBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StainedGlassPaneBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.PoweredRailBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StainedGlassPaneBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.ChainBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.DetectorRailBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.HayBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.WeatheringCopperStairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.ComparatorBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WeatheringCopperStairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WeatheringCopperStairBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.HayBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: any]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.HayBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.StainedGlassPaneBlock]: Internal.RegularImmutableSet<any>, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StainedGlassPaneBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StainedGlassPaneBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.HayBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RailBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.StainedGlassPaneBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StainedGlassPaneBlock]: Internal.RegularImmutableSet<any>, [key: Internal.WallBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.GlazedTerracottaBlock]: any, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.FenceBlock]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: any]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.GlazedTerracottaBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.StairBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: any]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>, [key: Internal.RotatedPillarBlock]: any, [key: Internal.PoweredRailBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.IronBarsBlock]: Internal.RegularImmutableSet<any>, [key: any]: any, [key: Internal.RotatedPillarBlock]: any, [key: Internal.TrapDoorBlock]: Internal.RegularImmutableSet<any>}) & (Internal.Map<Internal.Block, Internal.Set<Internal.Property<any>>>);
    }
    type BlockstateCopyItem_ = BlockstateCopyItem;
    interface ArgumentTypeInfo <A extends Internal.ArgumentType<any>, T extends Internal.ArgumentTypeInfo$Template<A>> {
        abstract serializeToJson(arg0: T, arg1: Internal.JsonObject_): void;
        abstract deserializeFromNetwork(arg0: Internal.FriendlyByteBuf_): T;
        abstract serializeToNetwork(arg0: T, arg1: Internal.FriendlyByteBuf_): void;
        abstract unpack(arg0: A): T;
    }
    type ArgumentTypeInfo_<A extends Internal.ArgumentType<any>, T extends Internal.ArgumentTypeInfo$Template<A>> = ArgumentTypeInfo<A, T> | Special.CommandArgumentType;
    interface Matrix3fc {
        abstract mapYnZX(arg0: Matrix3f_): Matrix3f;
        abstract m00(): number;
        abstract rotateLocalY(arg0: number, arg1: Matrix3f_): Matrix3f;
        abstract get3x4(arg0: number, arg1: Internal.FloatBuffer_): Internal.FloatBuffer;
        abstract rotate(arg0: Internal.Quaternionfc_, arg1: Matrix3f_): Matrix3f;
        abstract getEulerAnglesXYZ(arg0: Vec3f_): Vec3f;
        abstract get(arg0: number, arg1: Internal.ByteBuffer_): Internal.ByteBuffer;
        abstract mapYXnZ(arg0: Matrix3f_): Matrix3f;
        abstract get(arg0: Internal.FloatBuffer_): Internal.FloatBuffer;
        abstract "getUnnormalizedRotation(org.joml.Quaterniond)"(arg0: Internal.Quaterniond_): Internal.Quaterniond;
        abstract mapnYnXZ(arg0: Matrix3f_): Matrix3f;
        abstract mulLocal(arg0: Internal.Matrix3fc_, arg1: Matrix3f_): Matrix3f;
        abstract "get3x4(int,java.nio.FloatBuffer)"(arg0: number, arg1: Internal.FloatBuffer_): Internal.FloatBuffer;
        abstract "getTransposed(java.nio.ByteBuffer)"(arg0: Internal.ByteBuffer_): Internal.ByteBuffer;
        abstract lookAlong(arg0: Internal.Vector3fc_, arg1: Internal.Vector3fc_, arg2: Matrix3f_): Matrix3f;
        abstract mapYnXnZ(arg0: Matrix3f_): Matrix3f;
        abstract "getNormalizedRotation(org.joml.Quaternionf)"(arg0: Quaternionf_): Quaternionf;
        abstract getUnnormalizedRotation(arg0: Quaternionf_): Quaternionf;
        abstract negateZ(arg0: Matrix3f_): Matrix3f;
        abstract "getNormalizedRotation(org.joml.Quaterniond)"(arg0: Internal.Quaterniond_): Internal.Quaterniond;
        abstract "get(int,int)"(arg0: number, arg1: number): number;
        abstract m12(): number;
        abstract mapnZYnX(arg0: Matrix3f_): Matrix3f;
        abstract get3x4(arg0: Internal.ByteBuffer_): Internal.ByteBuffer;
        abstract mapZYnX(arg0: Matrix3f_): Matrix3f;
        abstract mapnYnXnZ(arg0: Matrix3f_): Matrix3f;
        abstract "get(int,java.nio.FloatBuffer)"(arg0: number, arg1: Internal.FloatBuffer_): Internal.FloatBuffer;
        abstract normalizedPositiveX(arg0: Vec3f_): Vec3f;
        abstract "rotate(org.joml.Quaternionfc,org.joml.Matrix3f)"(arg0: Internal.Quaternionfc_, arg1: Matrix3f_): Matrix3f;
        abstract transformTranspose(arg0: number, arg1: number, arg2: number, arg3: Vec3f_): Vec3f;
        abstract get(arg0: number[]): number[];
        abstract getColumn(arg0: number, arg1: Vec3f_): Vec3f;
        abstract getNormalizedRotation(arg0: Internal.Quaterniond_): Internal.Quaterniond;
        abstract "get(java.nio.ByteBuffer)"(arg0: Internal.ByteBuffer_): Internal.ByteBuffer;
        abstract "get(int,java.nio.ByteBuffer)"(arg0: number, arg1: Internal.ByteBuffer_): Internal.ByteBuffer;
        abstract mapnXYnZ(arg0: Matrix3f_): Matrix3f;
        abstract get(arg0: number[], arg1: number): number[];
        abstract getRowColumn(arg0: number, arg1: number): number;
        abstract rotateLocal(arg0: number, arg1: number, arg2: number, arg3: number, arg4: Matrix3f_): Matrix3f;
        abstract positiveZ(arg0: Vec3f_): Vec3f;
        abstract mapnYZX(arg0: Matrix3f_): Matrix3f;
        abstract mapnXnZY(arg0: Matrix3f_): Matrix3f;
        abstract mapXZY(arg0: Matrix3f_): Matrix3f;
        abstract rotateZ(arg0: number, arg1: Matrix3f_): Matrix3f;
        abstract mapnZnYX(arg0: Matrix3f_): Matrix3f;
        abstract mapnXnYnZ(arg0: Matrix3f_): Matrix3f;
        abstract mapZYX(arg0: Matrix3f_): Matrix3f;
        abstract rotateYXZ(arg0: number, arg1: number, arg2: number, arg3: Matrix3f_): Matrix3f;
        abstract mapnYnZX(arg0: Matrix3f_): Matrix3f;
        abstract m01(): number;
        abstract rotateLocalZ(arg0: number, arg1: Matrix3f_): Matrix3f;
        abstract quadraticFormProduct(arg0: Internal.Vector3fc_): number;
        abstract rotateLocal(arg0: Internal.Quaternionfc_, arg1: Matrix3f_): Matrix3f;
        abstract getRotation(arg0: Internal.AxisAngle4f_): Internal.AxisAngle4f;
        abstract "get(java.nio.FloatBuffer)"(arg0: Internal.FloatBuffer_): Internal.FloatBuffer;
        abstract mapnYnZnX(arg0: Matrix3f_): Matrix3f;
        abstract obliqueZ(arg0: number, arg1: number, arg2: Matrix3f_): Matrix3f;
        abstract transformTranspose(arg0: Internal.Vector3fc_, arg1: Vec3f_): Vec3f;
        abstract m20(): number;
        abstract reflect(arg0: number, arg1: number, arg2: number, arg3: Matrix3f_): Matrix3f;
        abstract "rotate(org.joml.AxisAngle4f,org.joml.Matrix3f)"(arg0: Internal.AxisAngle4f_, arg1: Matrix3f_): Matrix3f;
        abstract getTransposed(arg0: Internal.FloatBuffer_): Internal.FloatBuffer;
        abstract transform(arg0: number, arg1: number, arg2: number, arg3: Vec3f_): Vec3f;
        abstract mapnZnXY(arg0: Matrix3f_): Matrix3f;
        abstract get(arg0: Matrix4f_): Matrix4f;
        abstract scale(arg0: Internal.Vector3fc_, arg1: Matrix3f_): Matrix3f;
        abstract "get3x4(java.nio.FloatBuffer)"(arg0: Internal.FloatBuffer_): Internal.FloatBuffer;
        abstract mul(arg0: Internal.Matrix3fc_, arg1: Matrix3f_): Matrix3f;
        abstract mulComponentWise(arg0: Internal.Matrix3fc_, arg1: Matrix3f_): Matrix3f;
        abstract mapZXnY(arg0: Matrix3f_): Matrix3f;
        abstract rotateXYZ(arg0: number, arg1: number, arg2: number, arg3: Matrix3f_): Matrix3f;
        abstract "get3x4(int,java.nio.ByteBuffer)"(arg0: number, arg1: Internal.ByteBuffer_): Internal.ByteBuffer;
        abstract mapnZYX(arg0: Matrix3f_): Matrix3f;
        abstract normalizedPositiveY(arg0: Vec3f_): Vec3f;
        abstract mapYZnX(arg0: Matrix3f_): Matrix3f;
        abstract getTransposed(arg0: number, arg1: Internal.ByteBuffer_): Internal.ByteBuffer;
        abstract mapnYZnX(arg0: Matrix3f_): Matrix3f;
        abstract cofactor(arg0: Matrix3f_): Matrix3f;
        abstract getRow(arg0: number, arg1: Vec3f_): Vec3f;
        abstract mapXnZY(arg0: Matrix3f_): Matrix3f;
        abstract getScale(arg0: Vec3f_): Vec3f;
        abstract mapnZXnY(arg0: Matrix3f_): Matrix3f;
        abstract rotate(arg0: number, arg1: number, arg2: number, arg3: number, arg4: Matrix3f_): Matrix3f;
        abstract rotateY(arg0: number, arg1: Matrix3f_): Matrix3f;
        abstract transform(arg0: Vec3f_): Vec3f;
        abstract "scale(org.joml.Vector3fc,org.joml.Matrix3f)"(arg0: Internal.Vector3fc_, arg1: Matrix3f_): Matrix3f;
        abstract mapZnXY(arg0: Matrix3f_): Matrix3f;
        abstract mapnXZY(arg0: Matrix3f_): Matrix3f;
        abstract "scale(float,org.joml.Matrix3f)"(arg0: number, arg1: Matrix3f_): Matrix3f;
        abstract "reflect(org.joml.Vector3fc,org.joml.Matrix3f)"(arg0: Internal.Vector3fc_, arg1: Matrix3f_): Matrix3f;
        abstract normal(arg0: Matrix3f_): Matrix3f;
        abstract rotateTowards(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: Matrix3f_): Matrix3f;
        abstract mapnXZnY(arg0: Matrix3f_): Matrix3f;
        abstract "get(org.joml.Matrix3f)"(arg0: Matrix3f_): Matrix3f;
        abstract m21(): number;
        abstract m02(): number;
        abstract sub(arg0: Internal.Matrix3fc_, arg1: Matrix3f_): Matrix3f;
        abstract get3x4(arg0: number, arg1: Internal.ByteBuffer_): Internal.ByteBuffer;
        abstract isFinite(): boolean;
        abstract negateX(arg0: Matrix3f_): Matrix3f;
        abstract mapZnYX(arg0: Matrix3f_): Matrix3f;
        abstract transpose(arg0: Matrix3f_): Matrix3f;
        abstract mapnXnYZ(arg0: Matrix3f_): Matrix3f;
        abstract m10(): number;
        abstract mapZXY(arg0: Matrix3f_): Matrix3f;
        abstract normalizedPositiveZ(arg0: Vec3f_): Vec3f;
        abstract invert(arg0: Matrix3f_): Matrix3f;
        abstract reflect(arg0: Internal.Quaternionfc_, arg1: Matrix3f_): Matrix3f;
        abstract rotate(arg0: Internal.AxisAngle4f_, arg1: Matrix3f_): Matrix3f;
        abstract "getTransposed(int,java.nio.FloatBuffer)"(arg0: number, arg1: Internal.FloatBuffer_): Internal.FloatBuffer;
        abstract scaleLocal(arg0: number, arg1: number, arg2: number, arg3: Matrix3f_): Matrix3f;
        abstract getEulerAnglesZYX(arg0: Vec3f_): Vec3f;
        abstract reflect(arg0: Internal.Vector3fc_, arg1: Matrix3f_): Matrix3f;
        abstract get(arg0: Matrix3f_): Matrix3f;
        abstract getToAddress(arg0: number): this;
        abstract "get(float[],int)"(arg0: number[], arg1: number): number[];
        abstract rotateX(arg0: number, arg1: Matrix3f_): Matrix3f;
        abstract positiveX(arg0: Vec3f_): Vec3f;
        abstract get(arg0: number, arg1: Internal.FloatBuffer_): Internal.FloatBuffer;
        abstract "getTransposed(int,java.nio.ByteBuffer)"(arg0: number, arg1: Internal.ByteBuffer_): Internal.ByteBuffer;
        abstract get(arg0: number, arg1: number): number;
        abstract get(arg0: Internal.ByteBuffer_): Internal.ByteBuffer;
        abstract determinant(): number;
        abstract add(arg0: Internal.Matrix3fc_, arg1: Matrix3f_): Matrix3f;
        abstract mapYnZnX(arg0: Matrix3f_): Matrix3f;
        abstract get3x4(arg0: Internal.FloatBuffer_): Internal.FloatBuffer;
        abstract "reflect(org.joml.Quaternionfc,org.joml.Matrix3f)"(arg0: Internal.Quaternionfc_, arg1: Matrix3f_): Matrix3f;
        abstract mapnZnXnY(arg0: Matrix3f_): Matrix3f;
        abstract mapXZnY(arg0: Matrix3f_): Matrix3f;
        abstract scale(arg0: number, arg1: Matrix3f_): Matrix3f;
        abstract rotateLocalX(arg0: number, arg1: Matrix3f_): Matrix3f;
        abstract mapYnXZ(arg0: Matrix3f_): Matrix3f;
        abstract rotateZYX(arg0: number, arg1: number, arg2: number, arg3: Matrix3f_): Matrix3f;
        abstract mapnZXY(arg0: Matrix3f_): Matrix3f;
        abstract transform(arg0: Internal.Vector3fc_, arg1: Vec3f_): Vec3f;
        abstract mapnYXnZ(arg0: Matrix3f_): Matrix3f;
        abstract transformTranspose(arg0: Vec3f_): Vec3f;
        abstract "get3x4(java.nio.ByteBuffer)"(arg0: Internal.ByteBuffer_): Internal.ByteBuffer;
        abstract scale(arg0: number, arg1: number, arg2: number, arg3: Matrix3f_): Matrix3f;
        abstract lerp(arg0: Internal.Matrix3fc_, arg1: number, arg2: Matrix3f_): Matrix3f;
        abstract m22(): number;
        abstract quadraticFormProduct(arg0: number, arg1: number, arg2: number): number;
        abstract "get(float[])"(arg0: number[]): number[];
        abstract mapZnYnX(arg0: Matrix3f_): Matrix3f;
        abstract mapYXZ(arg0: Matrix3f_): Matrix3f;
        abstract lookAlong(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number, arg6: Matrix3f_): Matrix3f;
        abstract mapXnZnY(arg0: Matrix3f_): Matrix3f;
        abstract negateY(arg0: Matrix3f_): Matrix3f;
        abstract getUnnormalizedRotation(arg0: Internal.Quaterniond_): Internal.Quaterniond;
        abstract rotate(arg0: number, arg1: Internal.Vector3fc_, arg2: Matrix3f_): Matrix3f;
        abstract "getTransposed(java.nio.FloatBuffer)"(arg0: Internal.FloatBuffer_): Internal.FloatBuffer;
        abstract getTransposed(arg0: number, arg1: Internal.FloatBuffer_): Internal.FloatBuffer;
        abstract mapXnYnZ(arg0: Matrix3f_): Matrix3f;
        abstract m11(): number;
        abstract getTransposed(arg0: Internal.ByteBuffer_): Internal.ByteBuffer;
        abstract mapZnXnY(arg0: Matrix3f_): Matrix3f;
        abstract "get(org.joml.Matrix4f)"(arg0: Matrix4f_): Matrix4f;
        abstract mapYZX(arg0: Matrix3f_): Matrix3f;
        abstract equals(arg0: Internal.Matrix3fc_, arg1: number): boolean;
        abstract getNormalizedRotation(arg0: Quaternionf_): Quaternionf;
        abstract mapnXnZnY(arg0: Matrix3f_): Matrix3f;
        abstract mapnZnYnX(arg0: Matrix3f_): Matrix3f;
        abstract "getUnnormalizedRotation(org.joml.Quaternionf)"(arg0: Quaternionf_): Quaternionf;
        abstract positiveY(arg0: Vec3f_): Vec3f;
        abstract mapnYXZ(arg0: Matrix3f_): Matrix3f;
        abstract rotateTowards(arg0: Internal.Vector3fc_, arg1: Internal.Vector3fc_, arg2: Matrix3f_): Matrix3f;
        get finite(): boolean
    }
    type Matrix3fc_ = Matrix3fc;
    class DragonLandingApproachPhase extends Internal.AbstractDragonPhaseInstance {
        constructor($$0: Internal.EnderDragon_)
        doClientTick(): void;
        getClass(): typeof any;
        onHurt($$0: DamageSource_, $$1: number): number;
        toString(): string;
        getFlyTargetLocation(): Vec3d;
        getFlySpeed(): number;
        notifyAll(): void;
        begin(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        isSitting(): boolean;
        end(): void;
        wait(): void;
        getTurnSpeed(): number;
        wait(arg0: number): void;
        onCrystalDestroyed($$0: Internal.EndCrystal_, $$1: BlockPos_, $$2: DamageSource_, $$3: Internal.Player_): void;
        doServerTick(): void;
        getPhase(): Internal.EnderDragonPhase<Internal.DragonLandingApproachPhase>;
        equals(arg0: any): boolean;
        get class(): typeof any
        get flyTargetLocation(): Vec3d
        get flySpeed(): number
        get sitting(): boolean
        get turnSpeed(): number
        get phase(): Internal.EnderDragonPhase<Internal.DragonLandingApproachPhase>
    }
    type DragonLandingApproachPhase_ = DragonLandingApproachPhase;
    class PropertyMap extends Internal.ForwardingMultimap<string, com.mojang.authlib.properties.Property> {
        constructor()
        getClass(): typeof any;
        entries(): Internal.Collection<Internal.Map$Entry<string, com.mojang.authlib.properties.Property>>;
        keySet(): Internal.Set<string>;
        containsValue(arg0: any): boolean;
        putAll(arg0: string, arg1: Internal.Iterable_<com.mojang.authlib.properties.Property>): boolean;
        replaceValues(arg0: string, arg1: Internal.Iterable_<com.mojang.authlib.properties.Property>): Internal.Collection<com.mojang.authlib.properties.Property>;
        isEmpty(): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        containsKey(arg0: any): boolean;
        get(arg0: string): Internal.Collection<com.mojang.authlib.properties.Property>;
        asMap(): Internal.Map<string, Internal.Collection<com.mojang.authlib.properties.Property>>;
        keys(): Internal.Multiset<string>;
        toString(): string;
        notifyAll(): void;
        remove(arg0: any, arg1: any): boolean;
        containsEntry(arg0: any, arg1: any): boolean;
        values(): Internal.Collection<com.mojang.authlib.properties.Property>;
        forEach(arg0: Internal.BiConsumer_<string, com.mojang.authlib.properties.Property>): void;
        put(arg0: string, arg1: com.mojang.authlib.properties.Property_): boolean;
        hashCode(): number;
        size(): number;
        removeAll(arg0: any): Internal.Collection<com.mojang.authlib.properties.Property>;
        putAll(arg0: Internal.Multimap_<string, com.mojang.authlib.properties.Property>): boolean;
        wait(): void;
        clear(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        get class(): typeof any
        get empty(): boolean
    }
    type PropertyMap_ = PropertyMap;
    class TeamData {
        constructor(teamId: Internal.UUID_, file: Internal.BaseQuestFile_, name: string)
        constructor(teamId: Internal.UUID_, file: Internal.BaseQuestFile_)
        getOnlineMembers(): Internal.Collection<Internal.ServerPlayer>;
        setCompleted(id: number, time: Internal.Date_): boolean;
        getRelativeProgress(object: Internal.QuestObject_): number;
        "getProgress(long)"(taskId: number): number;
        setProgress(task: Internal.Task_, progress: number): void;
        deleteReward(reward: Internal.Reward_): void;
        isRewardClaimed(player: Internal.UUID_, reward: Internal.Reward_): boolean;
        isCompleted(object: Internal.QuestObject_): boolean;
        notify(): void;
        markTaskCompleted(task: Internal.Task_): void;
        mergeData(from: Internal.TeamData_): void;
        setStarted(questId: number, time: Internal.Date_): boolean;
        "claimReward(java.util.UUID,dev.ftb.mods.ftbquests.quest.reward.Reward,long)"(player: Internal.UUID_, reward: Internal.Reward_, date: number): boolean;
        canStartTasks(quest: Internal.Quest_): boolean;
        claimReward(player: Internal.UUID_, reward: Internal.Reward_, date: number): boolean;
        setName(name: string): void;
        getTeamId(): Internal.UUID;
        setCanEdit(player: Internal.Player_, newCanEdit: boolean): boolean;
        setLocked(newLocked: boolean): boolean;
        setRewardsBlocked(rewardsBlocked: boolean): boolean;
        getCompletedTime(questId: number): Optional<Internal.Date>;
        resetProgress(task: Internal.Task_): void;
        markDirty(): void;
        getStartedTime(questId: number): Optional<Internal.Date>;
        setQuestPinned(player: Internal.Player_, id: number, pinned: boolean): void;
        getRewardClaimTime(player: Internal.UUID_, reward: Internal.Reward_): Optional<Internal.Date>;
        areRewardsBlocked(): boolean;
        wait(): void;
        getCanEdit(player: Internal.Player_): boolean;
        getClass(): typeof any;
        isQuestPinned(player: Internal.Player_, id: number): boolean;
        areDependenciesComplete(quest: Internal.Quest_): boolean;
        isRewardBlocked(reward: Internal.Reward_): boolean;
        claimReward(player: Internal.ServerPlayer_, reward: Internal.Reward_, notify: boolean): void;
        clearCachedProgress(): void;
        copyData(from: Internal.TeamData_): void;
        getClaimType(player: Internal.UUID_, reward: Internal.Reward_): Internal.RewardClaimType;
        wait(arg0: number, arg1: number): void;
        isStarted(object: Internal.QuestObject_): boolean;
        resetReward(player: Internal.UUID_, reward: Internal.Reward_): boolean;
        setChapterPinned(player: Internal.Player_, pinned: boolean): void;
        write(buffer: Internal.FriendlyByteBuf_, self: boolean): void;
        getName(): string;
        hasUnclaimedRewards(player: Internal.UUID_, object: Internal.QuestObject_): boolean;
        serializeNBT(): Internal.SNBTCompoundTag;
        mergeClaimedRewards(from: Internal.TeamData_): void;
        checkAutoCompletion(quest: Internal.Quest_): void;
        getProgress(taskId: number): number;
        toString(): string;
        getFile(): Internal.BaseQuestFile;
        notifyAll(): void;
        "getProgress(dev.ftb.mods.ftbquests.quest.task.Task)"(task: Internal.Task_): number;
        isChapterPinned(player: Internal.Player_): boolean;
        static get(player: Internal.Player_): Internal.TeamData;
        "claimReward(net.minecraft.server.level.ServerPlayer,dev.ftb.mods.ftbquests.quest.reward.Reward,boolean)"(player: Internal.ServerPlayer_, reward: Internal.Reward_, notify: boolean): void;
        isLocked(): boolean;
        read(buffer: Internal.FriendlyByteBuf_, self: boolean): void;
        hashCode(): number;
        getProgress(task: Internal.Task_): number;
        addProgress(task: Internal.Task_, progress: number): void;
        areDependenciesVisible(quest: Internal.Quest_): boolean;
        wait(arg0: number): void;
        getPinnedQuestIds(player: Internal.Player_): Internal.LongSet;
        equals(arg0: any): boolean;
        saveIfChanged(): void;
        deserializeNBT(nbt: Internal.SNBTCompoundTag_): void;
        get onlineMembers(): Internal.Collection<Internal.ServerPlayer>
        set name(name: string)
        get teamId(): Internal.UUID
        set locked(newLocked: boolean)
        set rewardsBlocked(rewardsBlocked: boolean)
        get class(): typeof any
        get name(): string
        get file(): Internal.BaseQuestFile
        get locked(): boolean
        static readonly VERSION: (1) & (number);
        static readonly AUTO_PIN_ID: (1) & (number);
    }
    type TeamData_ = TeamData;
    interface TravelingEntity {
        abstract be_getTravelerState(): Internal.TravelerState;
        (): Internal.TravelerState_;
    }
    type TravelingEntity_ = (()=> Internal.TravelerState_) | TravelingEntity;
    interface RenderLayerMixin {
        callCreate(string: string, vertexFormat: Internal.VertexFormat_, drawMode: Internal.VertexFormat$Mode_, i: number, bl: boolean, bl2: boolean, multiPhaseParameters: Internal.RenderType$CompositeState_): Internal.RenderType$CompositeRenderType;
    }
    type RenderLayerMixin_ = RenderLayerMixin;
    class SpellContinuation$Companion {
        getClass(): typeof any;
        hashCode(): number;
        fromNBT(nbt: Internal.CompoundTag_, world: Internal.ServerLevel_): Internal.SpellContinuation;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        static readonly TAG_FRAME: ("frame") & (string);
    }
    type SpellContinuation$Companion_ = SpellContinuation$Companion;
    class AbstractModifierHelper$Companion$EmptyModifier extends Internal.AbstractModifier<Internal.AbstractModifierHelper$Companion$EmptyModifier> {
        constructor()
        getClass(): typeof any;
        addDescendant(modifier: Internal.AbstractModifier_<Internal.AbstractModifierHelper$Companion$EmptyModifier>): void;
        compiler(): Internal.AbstractModifier$Compiler<>;
        hasDescendant(): boolean;
        getModifierId(): ResourceLocation;
        plus(other: any): any;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        addDescendant(modifier: ResourceLocation_): void;
        checkObjectsToAffect(id: ResourceLocation_): boolean;
        "addDescendant(net.minecraft.resources.ResourceLocation)"(modifier: ResourceLocation_): void;
        getDescTranslation(): Internal.MutableComponent;
        acceptableItemStacks(): Internal.List<Internal.ItemStack>;
        onRemove(stack: Internal.ItemStack_): void;
        isAcceptableItem(stack: Internal.ItemStack_): boolean;
        getDescendant(): this;
        getName(): net.minecraft.network.chat.Component;
        toString(): string;
        plus(other: Internal.AbstractModifierHelper$Companion$EmptyModifier_): this;
        getDescTranslationKey(): string;
        notifyAll(): void;
        getTranslationKey(): string;
        "addDescendant(me.fzzyhmstrs.fzzy_core.modifier_util.AbstractModifier)"(modifier: Internal.AbstractModifier_<Internal.AbstractModifierHelper$Companion$EmptyModifier>): void;
        "plus(java.lang.Object)"(other: any): any;
        "plus(me.fzzyhmstrs.fzzy_core.modifier_util.AbstractModifierHelper$Companion$EmptyModifier)"(other: Internal.AbstractModifierHelper$Companion$EmptyModifier_): this;
        hasObjectToAffect(): boolean;
        getAncestor(): this;
        hashCode(): number;
        addObjectToAffect(predicate: Internal.Predicate_<ResourceLocation>): void;
        wait(): void;
        getModifierHelper(): Internal.AbstractModifierHelper<Internal.AbstractModifierHelper$Companion$EmptyModifier>;
        wait(arg0: number): void;
        onAdd(stack: Internal.ItemStack_): void;
        equals(other: any): boolean;
        getTranslation(): Internal.MutableComponent;
        hasAncestor(): boolean;
        get class(): typeof any
        get modifierId(): ResourceLocation
        get descTranslation(): Internal.MutableComponent
        get descendant(): Internal.AbstractModifierHelper$Companion$EmptyModifier
        get name(): net.minecraft.network.chat.Component
        get descTranslationKey(): string
        get translationKey(): string
        get ancestor(): Internal.AbstractModifierHelper$Companion$EmptyModifier
        get modifierHelper(): Internal.AbstractModifierHelper<Internal.AbstractModifierHelper$Companion$EmptyModifier>
        get translation(): Internal.MutableComponent
    }
    type AbstractModifierHelper$Companion$EmptyModifier_ = AbstractModifierHelper$Companion$EmptyModifier;
    class SurfaceVentFeature extends Internal.DefaultFeature {
        constructor()
        static getPosOnSurfaceWG(world: Internal.WorldGenLevel_, pos: BlockPos_): BlockPos;
        getClass(): typeof any;
        static getPosOnSurface(world: Internal.WorldGenLevel_, pos: BlockPos_): BlockPos;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        place($$0: Internal.NoneFeatureConfiguration_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        static getPosOnSurfaceRaycast(world: Internal.WorldGenLevel_, pos: BlockPos_): BlockPos;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        place(featureConfig: Internal.FeaturePlaceContext_<Internal.NoneFeatureConfiguration>): boolean;
        static getYOnSurfaceWG(world: Internal.WorldGenLevel_, x: number, z: number): number;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        static getPosOnSurfaceRaycast(world: Internal.WorldGenLevel_, pos: BlockPos_, dist: number): BlockPos;
        wait(): void;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.NoneFeatureConfiguration, Feature<Internal.NoneFeatureConfiguration>>>;
        static getYOnSurface(world: Internal.WorldGenLevel_, x: number, z: number): number;
        get class(): typeof any
    }
    type SurfaceVentFeature_ = SurfaceVentFeature;
    class WeightedListHeight extends Internal.HeightProvider {
        constructor($$0: Internal.SimpleWeightedRandomList_<Internal.HeightProvider>)
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        sample($$0: Internal.RandomSource_, $$1: Internal.WorldGenerationContext_): number;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getType(): Internal.HeightProviderType<any>;
        get class(): typeof any
        get type(): Internal.HeightProviderType<any>
        static readonly CODEC: Internal.Codec<Internal.WeightedListHeight>;
    }
    type WeightedListHeight_ = WeightedListHeight;
    class CaveWorldCarver extends Internal.WorldCarver<Internal.CaveCarverConfiguration> {
        constructor($$0: Internal.Codec_<Internal.CaveCarverConfiguration>)
        getClass(): typeof any;
        "isStartChunk(net.minecraft.world.level.levelgen.carver.CaveCarverConfiguration,net.minecraft.util.RandomSource)"($$0: Internal.CaveCarverConfiguration_, $$1: Internal.RandomSource_): boolean;
        toString(): string;
        carve($$0: Internal.CarvingContext_, $$1: Internal.CaveCarverConfiguration_, $$2: Internal.ChunkAccess_, $$3: Internal.Function_<BlockPos, Internal.Holder<Internal.Biome>>, $$4: Internal.RandomSource_, $$5: Internal.Aquifer_, $$6: Internal.ChunkPos_, $$7: Internal.CarvingMask_): boolean;
        notifyAll(): void;
        "isStartChunk(net.minecraft.world.level.levelgen.carver.CarverConfiguration,net.minecraft.util.RandomSource)"(arg0: Internal.CarverConfiguration_, arg1: Internal.RandomSource_): boolean;
        isStartChunk(arg0: Internal.CarverConfiguration_, arg1: Internal.RandomSource_): boolean;
        getRange(): number;
        "carve(net.minecraft.world.level.levelgen.carver.CarvingContext,net.minecraft.world.level.levelgen.carver.CarverConfiguration,net.minecraft.world.level.chunk.ChunkAccess,java.util.function.Function,net.minecraft.util.RandomSource,net.minecraft.world.level.levelgen.Aquifer,net.minecraft.world.level.ChunkPos,net.minecraft.world.level.chunk.CarvingMask)"(arg0: Internal.CarvingContext_, arg1: Internal.CarverConfiguration_, arg2: Internal.ChunkAccess_, arg3: Internal.Function_<any, any>, arg4: Internal.RandomSource_, arg5: Internal.Aquifer_, arg6: Internal.ChunkPos_, arg7: Internal.CarvingMask_): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        isStartChunk($$0: Internal.CaveCarverConfiguration_, $$1: Internal.RandomSource_): boolean;
        configuredCodec(): Internal.Codec<Internal.ConfiguredWorldCarver<Internal.CaveCarverConfiguration>>;
        hashCode(): number;
        "carve(net.minecraft.world.level.levelgen.carver.CarvingContext,net.minecraft.world.level.levelgen.carver.CaveCarverConfiguration,net.minecraft.world.level.chunk.ChunkAccess,java.util.function.Function,net.minecraft.util.RandomSource,net.minecraft.world.level.levelgen.Aquifer,net.minecraft.world.level.ChunkPos,net.minecraft.world.level.chunk.CarvingMask)"($$0: Internal.CarvingContext_, $$1: Internal.CaveCarverConfiguration_, $$2: Internal.ChunkAccess_, $$3: Internal.Function_<BlockPos, Internal.Holder<Internal.Biome>>, $$4: Internal.RandomSource_, $$5: Internal.Aquifer_, $$6: Internal.ChunkPos_, $$7: Internal.CarvingMask_): boolean;
        wait(): void;
        carve(arg0: Internal.CarvingContext_, arg1: Internal.CarverConfiguration_, arg2: Internal.ChunkAccess_, arg3: Internal.Function_<any, any>, arg4: Internal.RandomSource_, arg5: Internal.Aquifer_, arg6: Internal.ChunkPos_, arg7: Internal.CarvingMask_): boolean;
        wait(arg0: number): void;
        configured($$0: Internal.CaveCarverConfiguration_): Internal.ConfiguredWorldCarver<Internal.CaveCarverConfiguration>;
        equals(arg0: any): boolean;
        get class(): typeof any
        get range(): number
    }
    type CaveWorldCarver_ = CaveWorldCarver;
    abstract class AbstractFurnaceBlock extends Internal.BaseEntityBlock {
        /**
         * @deprecated
        */
        getOcclusionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        /**
         * @deprecated
        */
        getSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        axiom$customPickBlockStack(): Internal.ItemStack;
        getSoundType($$0: Internal.BlockState_): SoundType;
        /**
         * @deprecated
        */
        getVisualShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        handler$efo000$collective$Block_playerDestroy(level: Internal.Level_, player: Internal.Player_, blockPos: BlockPos_, blockState: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number, $$5: number): void;
        /**
         * @deprecated
        */
        randomTick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: Internal.BlockEntity_): void;
        static canSupportRigidBlock($$0: Internal.BlockGetter_, $$1: BlockPos_): boolean;
        static popResource($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.ItemStack_): void;
        setRandomTickCallback(callback: Internal.Consumer_<any>): void;
        getDescriptionId(): string;
        stepOn($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Entity_): void;
        fallOn($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: BlockPos_, $$3: Internal.Entity_, $$4: number): void;
        getSettings(): Internal.BlockBehaviour$Properties;
        triggerEvent($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: number, $$4: number): boolean;
        getExplosionResistance(): number;
        asItem(): Internal.Item;
        getTypeData(): Internal.CompoundTag;
        setFriction(arg0: number): void;
        getRenderShape($$0: Internal.BlockState_): Internal.RenderShape;
        canCull(): boolean;
        customShapeUpdate(blockState: Internal.CustomBlockState_, levelReader: Internal.LevelReader_, blockPos: BlockPos_): Internal.CustomBlockState;
        getJumpFactor(): number;
        getSpeedFactor(): number;
        static canSupportCenter($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        skipRendering($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getLightBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        playerDestroy($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.BlockEntity_, $$5: Internal.ItemStack_): void;
        shouldAttemptToCull(state: Internal.BlockState_): boolean;
        isPossibleToRespawnInThis($$0: Internal.BlockState_): boolean;
        getCustomStateForPlacement(blockPlaceContext: Internal.BlockPlaceContext_): Internal.CustomBlockState;
        /**
         * @deprecated
        */
        getDirectSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        getProperties(): Internal.BlockBehaviour$Properties;
        playerWillDestroy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Player_): void;
        getClass(): typeof any;
        getMaxVerticalOffset(): number;
        abstract newBlockEntity(arg0: BlockPos_, arg1: Internal.BlockState_): Internal.BlockEntity;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.item.context.BlockPlaceContext)"($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        useShapeForLightOcclusion($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        getDrops($$0: Internal.BlockState_, $$1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getStateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>;
        /**
         * @deprecated
        */
        entityInside($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Entity_): void;
        setBlockBuilder(b: Internal.BlockBuilder_): void;
        handler$ldb000$puzzleslib$playerDestroy$0(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        setRequiresTool(v: boolean): void;
        setSpeedFactor(arg0: number): void;
        axiom$getPossibleCustomStates(): Internal.List<any>;
        setExplosionResistance(arg0: number): void;
        toString(): string;
        port_lib$popExperience(arg0: Internal.ServerLevel_, arg1: BlockPos_, arg2: number): void;
        notifyAll(): void;
        getToolModifiedState(state: Internal.BlockState_, world: Internal.Level_, pos: BlockPos_, player: Internal.Player_, stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): Internal.BlockState;
        getId(): string;
        getLootTable(): ResourceLocation;
        puzzleslib$setItem(arg0: Internal.Item_): void;
        axiom$translationKey(): string;
        /**
         * @deprecated
        */
        getInteractionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        setPlacedBy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.LivingEntity_, $$4: Internal.ItemStack_): void;
        propagatesSkylightDown($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        /**
         * @deprecated
        */
        onPlace($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Block>;
        static popResourceFromFace($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.ItemStack_): void;
        getFriction(): number;
        handlePrecipitation($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Biome$Precipitation_): void;
        hasAnalogOutputSignal($$0: Internal.BlockState_): boolean;
        wait(arg0: number): void;
        /**
         * @deprecated
        */
        getFluidState($$0: Internal.BlockState_): Internal.FluidState;
        handler$koh000$porting_lib_entity$getDestroySpeed(blockState: Internal.BlockState_, player: Internal.Player_, blockGetter: Internal.BlockGetter_, pos: BlockPos_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getAnalogOutputSignal($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): number;
        handler$efo000$collective$Block_setPlacedBy(level: Internal.Level_, blockPos: BlockPos_, blockState: Internal.BlockState_, livingEntity: Internal.LivingEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        tick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        supportsExternalFaceHiding(state: Internal.BlockState_): boolean;
        handler$ldb000$puzzleslib$playerDestroy$1(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        notify(): void;
        axiom$asItemStack(): Internal.ItemStack;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        neighborChanged($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Block_, $$4: BlockPos_, $$5: boolean): void;
        handler$zhd000$additionalentityattributes$additionalEntityAttributes$saveBreakingPlayer(world: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, stack: Internal.ItemStack_, callbackInfo: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        getBlockSupportShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        canSustainPlant(state: Internal.BlockState_, world: Internal.BlockGetter_, pos: BlockPos_, facing: Internal.Direction_, plantable: Internal.IPlantable_): boolean;
        /**
         * @deprecated
        */
        isCollisionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static isFaceFull($$0: Internal.VoxelShape_, $$1: Internal.Direction_): boolean;
        getMenuProvider($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): Internal.MenuProvider;
        getTicker<T extends Internal.BlockEntity>($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockEntityType_<T>): Internal.BlockEntityTicker<T>;
        static byItem($$0: Internal.Item_): Internal.Block;
        static updateFromNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        updateIndirectNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: number, $$4: number): void;
        destroy($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): void;
        handler$fdc000$everycomp$addSimpleFastECdrops(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, cir: Internal.CallbackInfoReturnable_<any>, resId: ResourceLocation_, lootParams: Internal.LootParams_, serverLevel: Internal.ServerLevel_, lootTable: Internal.LootTable_): void;
        getToolModifiedState(state: Internal.BlockState_, context: Internal.UseOnContext_, toolAction: Internal.ToolAction_, simulate: boolean): Internal.BlockState;
        use($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_, $$4: Internal.InteractionHand_, $$5: Internal.BlockHitResult_): Internal.InteractionResult;
        setLightEmission(v: number): void;
        doNormalInteractions(): boolean;
        setJumpFactor(arg0: number): void;
        /**
         * @deprecated
        */
        canSurvive($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): void;
        /**
         * @deprecated
        */
        getShadeBrightness($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        getAppearance(state: Internal.BlockState_, renderView: Internal.BlockAndTintGetter_, pos: BlockPos_, side: Internal.Direction_, sourceState: Internal.BlockState_, sourcePos: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        getCollisionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        setDestroySpeed(v: number): void;
        defaultBlockState(): Internal.BlockState;
        usesCustomShouldDrawFace(state: Internal.BlockState_): boolean;
        getStateForPlacement($$0: Internal.BlockPlaceContext_): Internal.BlockState;
        cantCullAgainst(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>($$0: Internal.ServerLevel_, $$1: T): Internal.GameEventListener;
        arch$holder(): Internal.Holder<Internal.Block>;
        wait(): void;
        getCloneItemStack($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        hasDynamicShape(): boolean;
        getMaxHorizontalOffset(): number;
        /**
         * @deprecated
        */
        getDestroyProgress($$0: Internal.BlockState_, $$1: Internal.Player_, $$2: Internal.BlockGetter_, $$3: BlockPos_): number;
        /**
         * @deprecated
        */
        getSeed($$0: Internal.BlockState_, $$1: BlockPos_): number;
        defaultDestroyTime(): number;
        dropFromExplosion($$0: Internal.Explosion_): boolean;
        /**
         * @deprecated
        */
        updateShape($$0: Internal.BlockState_, $$1: Internal.Direction_, $$2: Internal.BlockState_, $$3: Internal.LevelAccessor_, $$4: BlockPos_, $$5: BlockPos_): Internal.BlockState;
        isRandomlyTicking($$0: Internal.BlockState_): boolean;
        static isShapeFullBlock(shape: Internal.VoxelShape_): boolean;
        withPropertiesOf($$0: Internal.BlockState_): Internal.BlockState;
        static isExceptionForConnection($$0: Internal.BlockState_): boolean;
        setIsRandomlyTicking(arg0: boolean): void;
        rotate($$0: Internal.BlockState_, $$1: Internal.Rotation_): Internal.BlockState;
        hidesNeighborFace(level: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, neighborState: Internal.BlockState_, dir: Internal.Direction_): boolean;
        onTreeGrow(state: Internal.BlockState_, level: Internal.LevelReader_, placeFunction: Internal.BiConsumer_<BlockPos, Internal.BlockState>, randomSource: Internal.RandomSource_, pos: BlockPos_, config: Internal.TreeConfiguration_): boolean;
        defaultMapColor(): Internal.MapColor;
        getStateAtViewpoint(state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_, viewpoint: Vec3d_): Internal.BlockState;
        wait(arg0: number, arg1: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.BlockGetter_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        setNameKey(arg0: string): void;
        static box($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): Internal.VoxelShape;
        mirror($$0: Internal.BlockState_, $$1: Internal.Mirror_): Internal.BlockState;
        wasExploded($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Explosion_): void;
        getName(): Internal.MutableComponent;
        updateEntityAfterFallOn($$0: Internal.BlockGetter_, $$1: Internal.Entity_): void;
        animateTick($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        customShouldDrawFace(view: Internal.BlockGetter_, thisState: Internal.BlockState_, sideState: Internal.BlockState_, thisPos: BlockPos_, sidePos: BlockPos_, side: Internal.Direction_): Optional<boolean>;
        axiom$getResourceLocation(): ResourceLocation;
        arch$registryName(): ResourceLocation;
        axiom$getProperties(): Internal.Collection<any>;
        getBlockBuilder(): Internal.BlockBuilder;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        isSignalSource($$0: Internal.BlockState_): boolean;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number): void;
        /**
         * @deprecated
        */
        attack($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): void;
        /**
         * @deprecated
        */
        getShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        shouldAttemptToCull(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        onProjectileHit($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockHitResult_, $$3: Internal.Projectile_): void;
        static stateById($$0: number): Internal.BlockState;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): Internal.List<Internal.ItemStack>;
        requiredFeatures(): Internal.FeatureFlagSet;
        hashCode(): number;
        axiom$defaultCustomState(): Internal.CustomBlockState;
        setCanCull(canCull: boolean): void;
        /**
         * @deprecated
        */
        isOcclusionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static getId($$0: Internal.BlockState_): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.material.Fluid)"($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        static pushEntitiesUp($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        isPathfindable($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.PathComputationType_): boolean;
        setSoundType(arg0: SoundType_): void;
        handler$cef000$betterend$be_getDroppedStacks(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, info: Internal.CallbackInfoReturnable_<any>): void;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_): Internal.List<Internal.ItemStack>;
        onRemove($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        cantCullAgainst(state: Internal.BlockState_): boolean;
        setHasCollision(arg0: boolean): void;
        static shouldRenderFace($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_, $$4: BlockPos_): boolean;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        spawnAfterBreak($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.ItemStack_, $$4: boolean): void;
        set randomTickCallback(callback: Internal.Consumer_<any>)
        get descriptionId(): string
        get settings(): Internal.BlockBehaviour$Properties
        get explosionResistance(): number
        get typeData(): Internal.CompoundTag
        set friction(arg0: number)
        get jumpFactor(): number
        get speedFactor(): number
        get properties(): Internal.BlockBehaviour$Properties
        get class(): typeof any
        get maxVerticalOffset(): number
        get stateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>
        set blockBuilder(b: Internal.BlockBuilder_)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        set speedFactor(arg0: number)
        set explosionResistance(arg0: number)
        get id(): string
        get lootTable(): ResourceLocation
        get friction(): number
        set lightEmission(v: number)
        set jumpFactor(arg0: number)
        set destroySpeed(v: number)
        get maxHorizontalOffset(): number
        set isRandomlyTicking(arg0: boolean)
        set nameKey(arg0: string)
        get name(): Internal.MutableComponent
        get blockBuilder(): Internal.BlockBuilder
        get idLocation(): ResourceLocation
        get mod(): string
        set canCull(canCull: boolean)
        set soundType(arg0: SoundType_)
        set hasCollision(arg0: boolean)
        static readonly FACING: (Internal.DirectionProperty) & (Internal.DirectionProperty);
        static readonly LIT: (Internal.BooleanProperty) & (Internal.BooleanProperty);
    }
    type AbstractFurnaceBlock_ = AbstractFurnaceBlock;
    interface IModelPartExtension {
        abstract supp$setDimensions(arg0: number, arg1: number): void;
        abstract supp$getTextWidth(): number;
        abstract supp$getTextHeight(): number;
    }
    type IModelPartExtension_ = IModelPartExtension;
    class ETFTexture$TextureReturnState extends Internal.Enum<Internal.ETFTexture$TextureReturnState> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        toString(): string;
        static valueOf(name: string): Internal.ETFTexture$TextureReturnState;
        notifyAll(): void;
        static values(): Internal.ETFTexture$TextureReturnState[];
        compareTo(arg0: Internal.ETFTexture$TextureReturnState_): number;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        name(): string;
        hashCode(): number;
        getDeclaringClass(): typeof Internal.ETFTexture$TextureReturnState;
        ordinal(): number;
        wait(): void;
        "compareTo(traben.entity_texture_features.features.texture_handlers.ETFTexture$TextureReturnState)"(arg0: Internal.ETFTexture$TextureReturnState_): number;
        wait(arg0: number): void;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.ETFTexture$TextureReturnState>>;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        get class(): typeof any
        get declaringClass(): typeof Internal.ETFTexture$TextureReturnState
        static readonly BLINK2_PATCHED: (Internal.ETFTexture$TextureReturnState) & (Internal.ETFTexture$TextureReturnState);
        static readonly BLINK: (Internal.ETFTexture$TextureReturnState) & (Internal.ETFTexture$TextureReturnState);
        static readonly NORMAL_PATCHED: (Internal.ETFTexture$TextureReturnState) & (Internal.ETFTexture$TextureReturnState);
        static readonly NORMAL: (Internal.ETFTexture$TextureReturnState) & (Internal.ETFTexture$TextureReturnState);
        static readonly APPLY_BLINK: (Internal.ETFTexture$TextureReturnState) & (Internal.ETFTexture$TextureReturnState);
        static readonly APPLY_BLINK2: (Internal.ETFTexture$TextureReturnState) & (Internal.ETFTexture$TextureReturnState);
        static readonly APPLY_PATCH: (Internal.ETFTexture$TextureReturnState) & (Internal.ETFTexture$TextureReturnState);
        static readonly BLINK_PATCHED: (Internal.ETFTexture$TextureReturnState) & (Internal.ETFTexture$TextureReturnState);
        static readonly BLINK2: (Internal.ETFTexture$TextureReturnState) & (Internal.ETFTexture$TextureReturnState);
    }
    type ETFTexture$TextureReturnState_ = "normal" | "blink_patched" | "apply_patch" | "apply_blink2" | "apply_blink" | "blink" | "blink2" | ETFTexture$TextureReturnState | "normal_patched" | "blink2_patched";
    class SteadfastSpikesItem extends Internal.WearableArtifactItem {
        constructor()
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        static setActivated(stack: Internal.ItemStack_, active: boolean): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        static isActivated(stack: Internal.ItemStack_): boolean;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, world: Internal.Level_, tooltipList: Internal.List_<net.minecraft.network.chat.Component>, flags: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        isOnCooldown(entity: Internal.LivingEntity_): boolean;
        addCooldown(entity: Internal.LivingEntity_, ticks: number): void;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        getFortuneLevel(): number;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        wornTick(entity: Internal.LivingEntity_, stack: Internal.ItemStack_): void;
        getLootingLevel(): number;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        makesPiglinsNeutral(): boolean;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        onUnequip(entity: Internal.LivingEntity_, stack: Internal.ItemStack_): void;
        isEquippedBy(entity: Internal.LivingEntity_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        toggleItem(player: Internal.ServerPlayer_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        addAttributeModifier(attributeModifier: Internal.ArtifactAttributeModifier_): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        getEquipSound(): Internal.SoundEvent;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canWalkOnPowderedSnow(): boolean;
        use(level: Internal.Level_, user: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<any>;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        getAttributeModifiers(): Internal.List<Internal.ArtifactAttributeModifier>;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        findAllEquippedBy(entity: Internal.LivingEntity_): Internal.Stream<Internal.ItemStack>;
        isCosmetic(): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        onEquip(entity: Internal.LivingEntity_, stack: Internal.ItemStack_): void;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe(slotStack: Internal.ItemStack_, holdingStack: Internal.ItemStack_, slot: Internal.Slot_, clickAction: Internal.ClickAction_, player: Internal.Player_, slotAccess: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        get fortuneLevel(): number
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        get lootingLevel(): number
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get equipSound(): Internal.SoundEvent
        get maxStackSize(): number
        get attributeModifiers(): Internal.List<Internal.ArtifactAttributeModifier>
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get cosmetic(): boolean
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type SteadfastSpikesItem_ = SteadfastSpikesItem;
    class RealmsServerPlayerLists extends Internal.ValueObject {
        constructor()
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        static parse($$0: string): Internal.RealmsServerPlayerLists;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        servers: Internal.List<Internal.RealmsServerPlayerList>;
    }
    type RealmsServerPlayerLists_ = RealmsServerPlayerLists;
    class RespawnPoints extends Internal.TemplateStructureHelper {
        constructor(structureSettings: Internal.Structure$StructureSettings_)
        static simpleCodec<S extends Internal.Structure>($$0: Internal.Function_<Internal.Structure$StructureSettings, S>): Internal.Codec<S>;
        getClass(): typeof any;
        generate($$0: Internal.RegistryAccess_, $$1: Internal.ChunkGenerator_, $$2: Internal.BiomeSource_, $$3: Internal.RandomState_, $$4: Internal.StructureTemplateManager_, $$5: number, $$6: Internal.ChunkPos_, $$7: number, $$8: Internal.LevelHeightAccessor_, $$9: Internal.Predicate_<Internal.Holder<Internal.Biome>>): Internal.StructureStart;
        biomes(): Internal.HolderSet<Internal.Biome>;
        static cfg(name: string, offsetY: number, type: org.betterx.bclib.api.v2.levelgen.structures.StructurePlacementType_, chance: number): Internal.TemplateStructure$Config;
        findValidGenerationPoint($$0: Internal.Structure$GenerationContext_): Optional<Internal.Structure$GenerationStub>;
        step(): Internal.GenerationStep$Decoration;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        type(): Internal.StructureType<any>;
        method_38676(ctx: Internal.Structure$GenerationContext_): Optional<Internal.Structure$GenerationStub>;
        structurify$setStructureIdentifier(structureSetIdentifier: ResourceLocation_): void;
        structurify$getStructureIdentifier(): ResourceLocation;
        toString(): string;
        spawnOverrides(): Internal.Map<Internal.MobCategory, Internal.StructureSpawnOverride>;
        notifyAll(): void;
        terrainAdaptation(): Internal.TerrainAdjustment;
        adjustBoundingBox($$0: Internal.BoundingBox_): Internal.BoundingBox;
        static simpleTemplateCodec<T extends Internal.TemplateStructure>(instancer: Internal.BiFunction_<Internal.Structure$StructureSettings, Internal.List<Internal.TemplateStructure$Config>, T>): Internal.Codec<T>;
        hashCode(): number;
        static settingsCodec<S extends Internal.Structure>($$0: Internal.RecordCodecBuilder$Instance_<S>): Internal.RecordCodecBuilder<S, Internal.Structure$StructureSettings>;
        wait(): void;
        wait(arg0: number): void;
        afterPlace($$0: Internal.WorldGenLevel_, $$1: Internal.StructureManager_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: Internal.BoundingBox_, $$5: Internal.ChunkPos_, $$6: Internal.PiecesContainer_): void;
        equals(arg0: any): boolean;
        setStructureBiomes(newBiomes: Internal.HolderSet_<any>): void;
        get class(): typeof any
        set tingsCodec($$0: Internal.RecordCodecBuilder$Instance_<S>)
        set structureBiomes(newBiomes: Internal.HolderSet_<any>)
        static readonly CODEC: Internal.Codec<Internal.RespawnPoints>;
    }
    type RespawnPoints_ = RespawnPoints;
    class Thread$State extends Internal.Enum<Internal.Thread$State> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        static values(): Internal.Thread$State[];
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.Thread$State>>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        name(): string;
        hashCode(): number;
        "compareTo(java.lang.Thread$State)"(arg0: Internal.Thread$State_): number;
        ordinal(): number;
        wait(): void;
        compareTo(arg0: Internal.Thread$State_): number;
        wait(arg0: number): void;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        static valueOf(arg0: string): Internal.Thread$State;
        getDeclaringClass(): typeof Internal.Thread$State;
        get class(): typeof any
        get declaringClass(): typeof Internal.Thread$State
        static readonly WAITING: (Internal.Thread$State) & (Internal.Thread$State);
        static readonly BLOCKED: (Internal.Thread$State) & (Internal.Thread$State);
        static readonly NEW: (Internal.Thread$State) & (Internal.Thread$State);
        static readonly TIMED_WAITING: (Internal.Thread$State) & (Internal.Thread$State);
        static readonly RUNNABLE: (Internal.Thread$State) & (Internal.Thread$State);
        static readonly TERMINATED: (Internal.Thread$State) & (Internal.Thread$State);
    }
    type Thread$State_ = "terminated" | "blocked" | "timed_waiting" | "new" | "runnable" | "waiting" | Thread$State;
    class RoadSignFeature$RandomState extends Internal.Record {
        getClass(): typeof any;
        toString(): string;
        stoneLanternChance(): number;
        notifyAll(): void;
        doubleSignChance(): number;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        stoneChance(): number;
        wallLanternChance(): number;
        doubleLanternChance(): number;
        hashCode(): number;
        wait(): void;
        logChance(): number;
        candleHolderChance(): number;
        wait(arg0: number): void;
        trapdoorChance(): number;
        equals(o: any): boolean;
        get class(): typeof any
        static readonly CODEC: Internal.Codec<Internal.RoadSignFeature$RandomState>;
    }
    type RoadSignFeature$RandomState_ = RoadSignFeature$RandomState;
    class RewriteResult <A, B> extends Internal.Record {
        constructor(view: Internal.View_<A, B>, recData: Internal.BitSet_)
        getClass(): typeof any;
        static nop<A>(arg0: com.mojang.datafixers.types.Type_<A>): Internal.RewriteResult<A, A>;
        toString(): string;
        static create<A, B>(arg0: Internal.View_<A, B>, arg1: Internal.BitSet_): Internal.RewriteResult<A, B>;
        notifyAll(): void;
        compose<C>(arg0: Internal.RewriteResult_<C, A>): Internal.RewriteResult<C, B>;
        view(): Internal.View<A, B>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        recData(): Internal.BitSet;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        get class(): typeof any
    }
    type RewriteResult_<A, B> = RewriteResult<A, B>;
    interface Multiset$Entry <E> {
        abstract hashCode(): number;
        abstract getCount(): number;
        abstract toString(): string;
        abstract equals(arg0: any): boolean;
        abstract getElement(): E;
        get count(): number
        get element(): E
    }
    type Multiset$Entry_<E> = Multiset$Entry<E>;
    class Format$Field extends Internal.AttributedCharacterIterator$Attribute {
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
    }
    type Format$Field_ = Format$Field;
    interface Comment extends Internal.CharacterData {
        abstract getFirstChild(): org.w3c.dom.Node;
        abstract getPrefix(): string;
        abstract setData(arg0: string): void;
        abstract getLastChild(): org.w3c.dom.Node;
        abstract compareDocumentPosition(arg0: org.w3c.dom.Node_): number;
        abstract cloneNode(arg0: boolean): org.w3c.dom.Node;
        abstract normalize(): void;
        abstract getOwnerDocument(): Internal.Document;
        abstract getFeature(arg0: string, arg1: string): any;
        abstract hasChildNodes(): boolean;
        abstract substringData(arg0: number, arg1: number): string;
        abstract getNodeName(): string;
        abstract isDefaultNamespace(arg0: string): boolean;
        abstract hasAttributes(): boolean;
        abstract setTextContent(arg0: string): void;
        abstract removeChild(arg0: org.w3c.dom.Node_): org.w3c.dom.Node;
        abstract replaceData(arg0: number, arg1: number, arg2: string): void;
        abstract getNodeValue(): string;
        abstract appendChild(arg0: org.w3c.dom.Node_): org.w3c.dom.Node;
        abstract isEqualNode(arg0: org.w3c.dom.Node_): boolean;
        abstract getLocalName(): string;
        abstract getNamespaceURI(): string;
        abstract insertData(arg0: number, arg1: string): void;
        abstract insertBefore(arg0: org.w3c.dom.Node_, arg1: org.w3c.dom.Node_): org.w3c.dom.Node;
        abstract getPreviousSibling(): org.w3c.dom.Node;
        abstract isSupported(arg0: string, arg1: string): boolean;
        abstract lookupPrefix(arg0: string): string;
        abstract setPrefix(arg0: string): void;
        abstract isSameNode(arg0: org.w3c.dom.Node_): boolean;
        abstract getChildNodes(): Internal.NodeList;
        abstract getTextContent(): string;
        abstract getData(): string;
        abstract getAttributes(): Internal.NamedNodeMap;
        abstract lookupNamespaceURI(arg0: string): string;
        abstract getNodeType(): number;
        abstract setNodeValue(arg0: string): void;
        abstract getBaseURI(): string;
        abstract setUserData(arg0: string, arg1: any, arg2: Internal.UserDataHandler_): any;
        abstract getNextSibling(): org.w3c.dom.Node;
        abstract getLength(): number;
        abstract getUserData(arg0: string): any;
        abstract appendData(arg0: string): void;
        abstract deleteData(arg0: number, arg1: number): void;
        abstract getParentNode(): org.w3c.dom.Node;
        abstract replaceChild(arg0: org.w3c.dom.Node_, arg1: org.w3c.dom.Node_): org.w3c.dom.Node;
        get firstChild(): org.w3c.dom.Node
        get prefix(): string
        set data(arg0: string)
        get lastChild(): org.w3c.dom.Node
        get ownerDocument(): Internal.Document
        get nodeName(): string
        set textContent(arg0: string)
        get nodeValue(): string
        get localName(): string
        get namespaceURI(): string
        get previousSibling(): org.w3c.dom.Node
        set prefix(arg0: string)
        get childNodes(): Internal.NodeList
        get textContent(): string
        get data(): string
        get attributes(): Internal.NamedNodeMap
        get nodeType(): number
        set nodeValue(arg0: string)
        get baseURI(): string
        get nextSibling(): org.w3c.dom.Node
        get length(): number
        get parentNode(): org.w3c.dom.Node
    }
    type Comment_ = Comment;
    interface LootPoolAccessor {
        abstract fabric_getFunctions(): Internal.LootItemFunction[];
        abstract fabric_getEntries(): Internal.LootPoolEntryContainer[];
        abstract fabric_getBonusRolls(): Internal.NumberProvider;
        abstract fabric_getConditions(): Internal.LootItemCondition[];
        abstract fabric_getRolls(): Internal.NumberProvider;
    }
    type LootPoolAccessor_ = LootPoolAccessor;
    class AugmentConsumer {
        constructor(consumer: Internal.Consumer_<Internal.List<Internal.LivingEntity>>, type: Internal.AugmentConsumer$Type_)
        getClass(): typeof any;
        component2(): Internal.AugmentConsumer$Type;
        toString(): string;
        component1(): Internal.Consumer<Internal.List<Internal.LivingEntity>>;
        getConsumer(): Internal.Consumer<Internal.List<Internal.LivingEntity>>;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        copy(consumer: Internal.Consumer_<Internal.List<Internal.LivingEntity>>, type: Internal.AugmentConsumer$Type_): this;
        getType(): Internal.AugmentConsumer$Type;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        static copy$default(arg0: Internal.AugmentConsumer_, arg1: Internal.Consumer_<any>, arg2: Internal.AugmentConsumer$Type_, arg3: number, arg4: any): Internal.AugmentConsumer;
        equals(other: any): boolean;
        get class(): typeof any
        get consumer(): Internal.Consumer<Internal.List<Internal.LivingEntity>>
        get type(): Internal.AugmentConsumer$Type
        static readonly Companion: (Internal.AugmentConsumer$Companion) & (Internal.AugmentConsumer$Companion);
    }
    type AugmentConsumer_ = AugmentConsumer;
    class Display$TextDisplay$CachedInfo extends Internal.Record {
        constructor($$0: Internal.List_<Internal.Display$TextDisplay$CachedLine>, $$1: number)
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        lines(): Internal.List<Internal.Display$TextDisplay$CachedLine>;
        wait(arg0: number): void;
        width(): number;
        equals($$0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
    }
    type Display$TextDisplay$CachedInfo_ = Display$TextDisplay$CachedInfo;
    interface Display$IntInterpolator {
        abstract get(arg0: number): number;
        constant($$0: number): this;
        (arg0: number): number;
    }
    type Display$IntInterpolator_ = Display$IntInterpolator | ((arg0: number)=> number);
    interface Advertiser {
        abstract unadvertise(advertisedObject: any): void;
        abstract advertise(properties: Internal.Map_<string, string>): any;
    }
    type Advertiser_ = Advertiser;
    interface WidgetHeightAccessor {
        abstract setHeight(arg0: number): void;
        set height(arg0: number)
        (arg0: number): void;
    }
    type WidgetHeightAccessor_ = ((arg0: number)=> void) | WidgetHeightAccessor;
    interface List <E> extends Internal.Collection<E> {
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E): this;
        copyOf<E>(arg0: Internal.Collection_<E>): this;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E, arg8: E): this;
        sort(arg0: Comparator_<E>): void;
        of<E>(arg0: E): this;
        of<E>(): this;
        abstract retainAll(arg0: Internal.Collection_<any>): boolean;
        abstract "remove(int)"(arg0: number): E;
        toArray<T>(arg0: Internal.IntFunction_<T[]>): T[];
        abstract addAll(arg0: number, arg1: Internal.Collection_<E>): boolean;
        abstract addAll(arg0: Internal.Collection_<E>): boolean;
        of<E>(arg0: E, arg1: E, arg2: E): this;
        abstract subList(arg0: number, arg1: number): this;
        abstract indexOf(arg0: any): number;
        abstract add(arg0: number, arg1: E): void;
        forEach(arg0: Internal.Consumer_<E>): void;
        abstract toArray<T>(arg0: T[]): T[];
        abstract remove(arg0: any): boolean;
        [Symbol.iterator](): IterableIterator<E>;
        abstract "remove(java.lang.Object)"(arg0: any): boolean;
        abstract listIterator(arg0: number): Internal.ListIterator<E>;
        abstract iterator(): Internal.Iterator<E>;
        of<E>(arg0: E, arg1: E): this;
        stream(): Internal.Stream<E>;
        abstract removeAll(arg0: Internal.Collection_<any>): boolean;
        removeIf(arg0: Internal.Predicate_<E>): boolean;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E): this;
        "of(java.lang.Object[])"<E>(...arg0: E[]): this;
        abstract lastIndexOf(arg0: any): number;
        abstract get(arg0: number): E;
        abstract add(arg0: E): boolean;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E): this;
        abstract listIterator(): Internal.ListIterator<E>;
        parallelStream(): Internal.Stream<E>;
        abstract isEmpty(): boolean;
        abstract set(arg0: number, arg1: E): E;
        of<E>(...arg0: E[]): this;
        abstract containsAll(arg0: Internal.Collection_<any>): boolean;
        abstract remove(arg0: number): E;
        abstract contains(arg0: any): boolean;
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E): this;
        "of(java.lang.Object)"<E>(arg0: E): this;
        replaceAll(arg0: Internal.UnaryOperator_<E>): void;
        abstract "toArray(java.lang.Object[])"<T>(arg0: T[]): T[];
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E): this;
        "toArray(java.util.function.IntFunction)"<T>(arg0: Internal.IntFunction_<T[]>): T[];
        of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E, arg8: E, arg9: E): this;
        abstract toArray(): any[];
        abstract hashCode(): number;
        abstract size(): number;
        abstract clear(): void;
        spliterator(): Internal.Spliterator<E>;
        abstract equals(arg0: any): boolean;
        get empty(): boolean
        [key: number]: E;
    }
    type List_<E> = List<E>;
    class StewTrade extends Internal.TransformableTrade<Internal.StewTrade> {
        constructor(inputs: TradeItem_[], effects: Internal.MobEffect_[], duration: number)
        getClass(): typeof any;
        priceMultiplier(priceMultiplier: number): this;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getOffer(entity: Internal.Entity_, random: Internal.RandomSource_): Internal.MerchantOffer;
        hashCode(): number;
        maxUses(maxUses: number): this;
        wait(): void;
        wait(arg0: number): void;
        createOffer(entity: Internal.Entity_, random: Internal.RandomSource_): Internal.MerchantOffer;
        transform(offerModification: Internal.TransformableTrade$Transformer_): this;
        equals(arg0: any): boolean;
        villagerExperience(villagerExperience: number): this;
        get class(): typeof any
    }
    type StewTrade_ = StewTrade;
    class CommandStorage {
        constructor($$0: Internal.DimensionDataStorage_)
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        get($$0: ResourceLocation_): Internal.CompoundTag;
        keys(): Internal.Stream<ResourceLocation>;
        set($$0: ResourceLocation_, $$1: Internal.CompoundTag_): void;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
    }
    type CommandStorage_ = CommandStorage;
    class InfusionRecipe implements Internal.UnknownReceipBookCategory, Internal.Recipe<Internal.InfusionRitual> {
        assemble(ritual: Internal.InfusionRitual_, acc: Internal.RegistryAccess_): Internal.ItemStack;
        getGroup(): string;
        getToastSymbol(): Internal.ItemStack;
        notify(): void;
        static "create(net.minecraft.resources.ResourceLocation,net.minecraft.world.level.ItemLike)"(id: ResourceLocation_, output: Internal.ItemLike_): Internal.InfusionRecipe$Builder;
        static "create(java.lang.String,net.minecraft.world.item.enchantment.Enchantment,int)"(id: string, enchantment: Internal.Enchantment_, level: number): Internal.InfusionRecipe$Builder;
        getId(): ResourceLocation;
        isIn(tag: ResourceLocation_): boolean;
        handler$bpa000$bclib$bcl_getRemainingItems(container: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>): void;
        isSpecial(): boolean;
        static create(id: string, enchantment: Internal.Enchantment_, level: number): Internal.InfusionRecipe$Builder;
        canCraftInDimensions(width: number, height: number): boolean;
        showNotification(): boolean;
        replaceInput(match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): boolean;
        static "create(java.lang.String,net.minecraft.world.level.ItemLike)"(id: string, output: Internal.ItemLike_): Internal.InfusionRecipe$Builder;
        getType(): ResourceLocation;
        static create(id: ResourceLocation_, output: Internal.ItemLike_): Internal.InfusionRecipe$Builder;
        "assemble(org.betterx.betterend.rituals.InfusionRitual,net.minecraft.core.RegistryAccess)"(ritual: Internal.InfusionRitual_, acc: Internal.RegistryAccess_): Internal.ItemStack;
        "handler$fie000$fabric-item-api-v1$captureStack"(inventory: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>, defaultedList: Internal.NonNullList_<any>, i: number): void;
        wait(): void;
        isIncomplete(): boolean;
        static "create(net.minecraft.resources.ResourceLocation,net.minecraft.world.item.ItemStack)"(id: ResourceLocation_, output: Internal.ItemStack_): Internal.InfusionRecipe$Builder;
        static create(id: string, output: Internal.ItemStack_): Internal.InfusionRecipe$Builder;
        getClass(): typeof any;
        getInfusionTime(): number;
        getSchema(): Internal.RecipeSchema;
        static create(id: ResourceLocation_, output: Internal.ItemStack_): Internal.InfusionRecipe$Builder;
        "assemble(net.minecraft.world.Container,net.minecraft.core.RegistryAccess)"(arg0: net.minecraft.world.Container_, arg1: Internal.RegistryAccess_): Internal.ItemStack;
        wait(arg0: number, arg1: number): void;
        static "create(net.minecraft.resources.ResourceLocation,net.minecraft.world.item.enchantment.Enchantment,int)"(id: ResourceLocation_, enchantment: Internal.Enchantment_, level: number): Internal.InfusionRecipe$Builder;
        getSerializer(): Internal.RecipeSerializer<any>;
        assemble(arg0: net.minecraft.world.Container_, arg1: Internal.RegistryAccess_): Internal.ItemStack;
        matches(inv: Internal.InfusionRitual_, world: Internal.Level_): boolean;
        static register(): void;
        static create(id: ResourceLocation_, enchantment: Internal.Enchantment_, level: number): Internal.InfusionRecipe$Builder;
        matches(arg0: net.minecraft.world.Container_, arg1: Internal.Level_): boolean;
        getMod(): string;
        getIngredients(): Internal.NonNullList<Internal.Ingredient>;
        "matches(org.betterx.betterend.rituals.InfusionRitual,net.minecraft.world.level.Level)"(inv: Internal.InfusionRitual_, world: Internal.Level_): boolean;
        getRemainingItems($$0: Internal.InfusionRitual_): Internal.NonNullList<Internal.ItemStack>;
        hasOutput(match: Internal.ReplacementMatch_): boolean;
        getResultItem(acc: Internal.RegistryAccess_): Internal.ItemStack;
        toString(): string;
        static "create(java.lang.String,net.minecraft.world.item.ItemStack)"(id: string, output: Internal.ItemStack_): Internal.InfusionRecipe$Builder;
        static createEnchantedBook(enchantment: Internal.Enchantment_, level: number): Internal.ItemStack;
        notifyAll(): void;
        static create(id: string, output: Internal.ItemLike_): Internal.InfusionRecipe$Builder;
        "matches(net.minecraft.world.Container,net.minecraft.world.level.Level)"(arg0: net.minecraft.world.Container_, arg1: Internal.Level_): boolean;
        setGroup(group: string): void;
        hashCode(): number;
        getOrCreateId(): ResourceLocation;
        hasInput(match: Internal.ReplacementMatch_): boolean;
        wait(arg0: number): void;
        replaceOutput(match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): boolean;
        equals(arg0: any): boolean;
        get group(): string
        get toastSymbol(): Internal.ItemStack
        get id(): ResourceLocation
        get special(): boolean
        get type(): ResourceLocation
        get incomplete(): boolean
        get class(): typeof any
        get infusionTime(): number
        get schema(): Internal.RecipeSchema
        get serializer(): Internal.RecipeSerializer<any>
        get mod(): string
        get ingredients(): Internal.NonNullList<Internal.Ingredient>
        set group(group: string)
        get orCreateId(): ResourceLocation
        static readonly TYPE: Internal.RecipeType<Internal.InfusionRecipe>;
        static readonly GROUP: ("infusion") & (string);
        static readonly SERIALIZER: (Internal.InfusionRecipe$Serializer) & (Internal.InfusionRecipe$Serializer);
    }
    type InfusionRecipe_ = InfusionRecipe;
    class BotanicalBreweryRecipe implements vazkii.botania.api.recipe.BotanicalBreweryRecipe {
        constructor(id: ResourceLocation_, brew: Internal.Brew_, ...inputs: Internal.Ingredient_[])
        getClass(): typeof any;
        getGroup(): string;
        getToastSymbol(): Internal.ItemStack;
        getSchema(): Internal.RecipeSchema;
        getManaUsage(): number;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getSerializer(): Internal.RecipeSerializer<any>;
        assemble(inv: net.minecraft.world.Container_, registries: Internal.RegistryAccess_): Internal.ItemStack;
        getId(): ResourceLocation;
        getOutput(stack: Internal.ItemStack_): Internal.ItemStack;
        matches(inv: net.minecraft.world.Container_, world: Internal.Level_): boolean;
        getMod(): string;
        isIn(tag: ResourceLocation_): boolean;
        getRemainingItems($$0: net.minecraft.world.Container_): Internal.NonNullList<Internal.ItemStack>;
        getIngredients(): Internal.NonNullList<Internal.Ingredient>;
        handler$bpa000$bclib$bcl_getRemainingItems(container: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>): void;
        isSpecial(): boolean;
        hasOutput(match: Internal.ReplacementMatch_): boolean;
        getResultItem(registries: Internal.RegistryAccess_): Internal.ItemStack;
        toString(): string;
        notifyAll(): void;
        canCraftInDimensions(width: number, height: number): boolean;
        showNotification(): boolean;
        replaceInput(match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): boolean;
        getType(): ResourceLocation;
        setGroup(group: string): void;
        hashCode(): number;
        "handler$fie000$fabric-item-api-v1$captureStack"(inventory: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>, defaultedList: Internal.NonNullList_<any>, i: number): void;
        getOrCreateId(): ResourceLocation;
        hasInput(match: Internal.ReplacementMatch_): boolean;
        wait(): void;
        isIncomplete(): boolean;
        wait(arg0: number): void;
        replaceOutput(match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): boolean;
        equals(o: any): boolean;
        getBrew(): Internal.Brew;
        get class(): typeof any
        get group(): string
        get toastSymbol(): Internal.ItemStack
        get schema(): Internal.RecipeSchema
        get manaUsage(): number
        get serializer(): Internal.RecipeSerializer<any>
        get id(): ResourceLocation
        get mod(): string
        get ingredients(): Internal.NonNullList<Internal.Ingredient>
        get special(): boolean
        get type(): ResourceLocation
        set group(group: string)
        get orCreateId(): ResourceLocation
        get incomplete(): boolean
        get brew(): Internal.Brew
    }
    type BotanicalBreweryRecipe_ = BotanicalBreweryRecipe;
    interface DoubleBlockCombiner$Combiner <S, T> {
        abstract acceptDouble(arg0: S, arg1: S): T;
        abstract acceptNone(): T;
        abstract acceptSingle(arg0: S): T;
    }
    type DoubleBlockCombiner$Combiner_<S, T> = DoubleBlockCombiner$Combiner<S, T>;
    interface BlockApiCache <A, C> {
        abstract getPos(): BlockPos;
        find(context: C): A;
        abstract getBlockEntity(): Internal.BlockEntity;
        abstract find(arg0: Internal.BlockState_, arg1: C): A;
        abstract getLookup(): Internal.BlockApiLookup<A, C>;
        abstract getWorld(): Internal.ServerLevel;
        create<A, C>(lookup: Internal.BlockApiLookup_<A, C>, world: Internal.ServerLevel_, pos: BlockPos_): this;
        get pos(): BlockPos
        get blockEntity(): Internal.BlockEntity
        get lookup(): Internal.BlockApiLookup<A, C>
        get world(): Internal.ServerLevel
    }
    type BlockApiCache_<A, C> = BlockApiCache<A, C>;
    class CavePumpkinFeature extends Internal.DefaultFeature {
        constructor()
        static getPosOnSurfaceWG(world: Internal.WorldGenLevel_, pos: BlockPos_): BlockPos;
        getClass(): typeof any;
        static getPosOnSurface(world: Internal.WorldGenLevel_, pos: BlockPos_): BlockPos;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        place($$0: Internal.NoneFeatureConfiguration_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        static getPosOnSurfaceRaycast(world: Internal.WorldGenLevel_, pos: BlockPos_): BlockPos;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        place(featureConfig: Internal.FeaturePlaceContext_<Internal.NoneFeatureConfiguration>): boolean;
        static getYOnSurfaceWG(world: Internal.WorldGenLevel_, x: number, z: number): number;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        static getPosOnSurfaceRaycast(world: Internal.WorldGenLevel_, pos: BlockPos_, dist: number): BlockPos;
        wait(): void;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.NoneFeatureConfiguration, Feature<Internal.NoneFeatureConfiguration>>>;
        static getYOnSurface(world: Internal.WorldGenLevel_, x: number, z: number): number;
        get class(): typeof any
    }
    type CavePumpkinFeature_ = CavePumpkinFeature;
    class LookControl implements Internal.Control {
        constructor($$0: Internal.Mob_)
        getClass(): typeof any;
        "setLookAt(net.minecraft.world.phys.Vec3)"($$0: Vec3d_): void;
        "setLookAt(net.minecraft.world.entity.Entity,float,float)"($$0: Internal.Entity_, $$1: number, $$2: number): void;
        setLookAt($$0: Internal.Entity_, $$1: number, $$2: number): void;
        toString(): string;
        getWantedX(): number;
        getWantedY(): number;
        setLookAt($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        getWantedZ(): number;
        notifyAll(): void;
        setLookAt($$0: Vec3d_): void;
        isLookingAtTarget(): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        tick(): void;
        setLookAt($$0: Internal.Entity_): void;
        hashCode(): number;
        "setLookAt(net.minecraft.world.entity.Entity)"($$0: Internal.Entity_): void;
        wait(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        setLookAt($$0: number, $$1: number, $$2: number): void;
        "setLookAt(double,double,double)"($$0: number, $$1: number, $$2: number): void;
        get class(): typeof any
        set "lookAt(net.minecraft.world.phys.Vec3)"($$0: Vec3d_)
        get wantedX(): number
        get wantedY(): number
        get wantedZ(): number
        set lookAt($$0: Vec3d_)
        get lookingAtTarget(): boolean
        set lookAt($$0: Internal.Entity_)
        set "lookAt(net.minecraft.world.entity.Entity)"($$0: Internal.Entity_)
    }
    type LookControl_ = LookControl;
    class LayeredCauldronBlock extends Internal.AbstractCauldronBlock {
        constructor($$0: Internal.BlockBehaviour$Properties_, $$1: Internal.Predicate_<Internal.Biome$Precipitation>, $$2: Internal.Map_<Internal.Item, Internal.CauldronInteraction>)
        /**
         * @deprecated
        */
        getOcclusionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        /**
         * @deprecated
        */
        getSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        axiom$customPickBlockStack(): Internal.ItemStack;
        getSoundType($$0: Internal.BlockState_): SoundType;
        /**
         * @deprecated
        */
        getVisualShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        handler$efo000$collective$Block_playerDestroy(level: Internal.Level_, player: Internal.Player_, blockPos: BlockPos_, blockState: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number, $$5: number): void;
        /**
         * @deprecated
        */
        randomTick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: Internal.BlockEntity_): void;
        static canSupportRigidBlock($$0: Internal.BlockGetter_, $$1: BlockPos_): boolean;
        static popResource($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.ItemStack_): void;
        setRandomTickCallback(callback: Internal.Consumer_<any>): void;
        getDescriptionId(): string;
        stepOn($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Entity_): void;
        fallOn($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: BlockPos_, $$3: Internal.Entity_, $$4: number): void;
        getSettings(): Internal.BlockBehaviour$Properties;
        getExplosionResistance(): number;
        asItem(): Internal.Item;
        /**
         * @deprecated
        */
        triggerEvent($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: number, $$4: number): boolean;
        getTypeData(): Internal.CompoundTag;
        setFriction(arg0: number): void;
        /**
         * @deprecated
        */
        getRenderShape($$0: Internal.BlockState_): Internal.RenderShape;
        canCull(): boolean;
        customShapeUpdate(blockState: Internal.CustomBlockState_, levelReader: Internal.LevelReader_, blockPos: BlockPos_): Internal.CustomBlockState;
        getJumpFactor(): number;
        getSpeedFactor(): number;
        static canSupportCenter($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        skipRendering($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getLightBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        playerDestroy($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.BlockEntity_, $$5: Internal.ItemStack_): void;
        shouldAttemptToCull(state: Internal.BlockState_): boolean;
        isPossibleToRespawnInThis($$0: Internal.BlockState_): boolean;
        getCustomStateForPlacement(blockPlaceContext: Internal.BlockPlaceContext_): Internal.CustomBlockState;
        /**
         * @deprecated
        */
        getDirectSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        getProperties(): Internal.BlockBehaviour$Properties;
        playerWillDestroy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Player_): void;
        getClass(): typeof any;
        getMaxVerticalOffset(): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.item.context.BlockPlaceContext)"($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        useShapeForLightOcclusion($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        getDrops($$0: Internal.BlockState_, $$1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getStateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>;
        entityInside($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Entity_): void;
        setBlockBuilder(b: Internal.BlockBuilder_): void;
        handler$ldb000$puzzleslib$playerDestroy$0(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        static lowerFillLevel($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): void;
        getBlockStates(): Internal.List<Internal.BlockState>;
        setRequiresTool(v: boolean): void;
        setSpeedFactor(arg0: number): void;
        axiom$getPossibleCustomStates(): Internal.List<any>;
        setExplosionResistance(arg0: number): void;
        toString(): string;
        port_lib$popExperience(arg0: Internal.ServerLevel_, arg1: BlockPos_, arg2: number): void;
        notifyAll(): void;
        getToolModifiedState(state: Internal.BlockState_, world: Internal.Level_, pos: BlockPos_, player: Internal.Player_, stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): Internal.BlockState;
        getId(): string;
        getLootTable(): ResourceLocation;
        puzzleslib$setItem(arg0: Internal.Item_): void;
        getInteractionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        axiom$translationKey(): string;
        propagatesSkylightDown($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        setPlacedBy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.LivingEntity_, $$4: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        onPlace($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Block>;
        static popResourceFromFace($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.ItemStack_): void;
        getFriction(): number;
        handlePrecipitation($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Biome$Precipitation_): void;
        hasAnalogOutputSignal($$0: Internal.BlockState_): boolean;
        wait(arg0: number): void;
        /**
         * @deprecated
        */
        getFluidState($$0: Internal.BlockState_): Internal.FluidState;
        handler$koh000$porting_lib_entity$getDestroySpeed(blockState: Internal.BlockState_, player: Internal.Player_, blockGetter: Internal.BlockGetter_, pos: BlockPos_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getAnalogOutputSignal($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): number;
        handler$efo000$collective$Block_setPlacedBy(level: Internal.Level_, blockPos: BlockPos_, blockState: Internal.BlockState_, livingEntity: Internal.LivingEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        tick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        supportsExternalFaceHiding(state: Internal.BlockState_): boolean;
        handler$ldb000$puzzleslib$playerDestroy$1(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        notify(): void;
        axiom$asItemStack(): Internal.ItemStack;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        neighborChanged($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Block_, $$4: BlockPos_, $$5: boolean): void;
        handler$zhd000$additionalentityattributes$additionalEntityAttributes$saveBreakingPlayer(world: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, stack: Internal.ItemStack_, callbackInfo: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        getBlockSupportShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        canSustainPlant(state: Internal.BlockState_, world: Internal.BlockGetter_, pos: BlockPos_, facing: Internal.Direction_, plantable: Internal.IPlantable_): boolean;
        /**
         * @deprecated
        */
        isCollisionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static isFaceFull($$0: Internal.VoxelShape_, $$1: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getMenuProvider($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): Internal.MenuProvider;
        static byItem($$0: Internal.Item_): Internal.Block;
        static updateFromNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        updateIndirectNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: number, $$4: number): void;
        destroy($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): void;
        handler$fdc000$everycomp$addSimpleFastECdrops(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, cir: Internal.CallbackInfoReturnable_<any>, resId: ResourceLocation_, lootParams: Internal.LootParams_, serverLevel: Internal.ServerLevel_, lootTable: Internal.LootTable_): void;
        getToolModifiedState(state: Internal.BlockState_, context: Internal.UseOnContext_, toolAction: Internal.ToolAction_, simulate: boolean): Internal.BlockState;
        use($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_, $$4: Internal.InteractionHand_, $$5: Internal.BlockHitResult_): Internal.InteractionResult;
        setLightEmission(v: number): void;
        doNormalInteractions(): boolean;
        setJumpFactor(arg0: number): void;
        /**
         * @deprecated
        */
        canSurvive($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        isFull($$0: Internal.BlockState_): boolean;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): void;
        /**
         * @deprecated
        */
        getShadeBrightness($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        getAppearance(state: Internal.BlockState_, renderView: Internal.BlockAndTintGetter_, pos: BlockPos_, side: Internal.Direction_, sourceState: Internal.BlockState_, sourcePos: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        getCollisionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        setDestroySpeed(v: number): void;
        defaultBlockState(): Internal.BlockState;
        usesCustomShouldDrawFace(state: Internal.BlockState_): boolean;
        getStateForPlacement($$0: Internal.BlockPlaceContext_): Internal.BlockState;
        cantCullAgainst(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        arch$holder(): Internal.Holder<Internal.Block>;
        wait(): void;
        getCloneItemStack($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        hasDynamicShape(): boolean;
        getMaxHorizontalOffset(): number;
        /**
         * @deprecated
        */
        getDestroyProgress($$0: Internal.BlockState_, $$1: Internal.Player_, $$2: Internal.BlockGetter_, $$3: BlockPos_): number;
        /**
         * @deprecated
        */
        getSeed($$0: Internal.BlockState_, $$1: BlockPos_): number;
        defaultDestroyTime(): number;
        dropFromExplosion($$0: Internal.Explosion_): boolean;
        /**
         * @deprecated
        */
        updateShape($$0: Internal.BlockState_, $$1: Internal.Direction_, $$2: Internal.BlockState_, $$3: Internal.LevelAccessor_, $$4: BlockPos_, $$5: BlockPos_): Internal.BlockState;
        isRandomlyTicking($$0: Internal.BlockState_): boolean;
        static isShapeFullBlock(shape: Internal.VoxelShape_): boolean;
        withPropertiesOf($$0: Internal.BlockState_): Internal.BlockState;
        static isExceptionForConnection($$0: Internal.BlockState_): boolean;
        setIsRandomlyTicking(arg0: boolean): void;
        hidesNeighborFace(level: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, neighborState: Internal.BlockState_, dir: Internal.Direction_): boolean;
        onTreeGrow(state: Internal.BlockState_, level: Internal.LevelReader_, placeFunction: Internal.BiConsumer_<BlockPos, Internal.BlockState>, randomSource: Internal.RandomSource_, pos: BlockPos_, config: Internal.TreeConfiguration_): boolean;
        /**
         * @deprecated
        */
        rotate($$0: Internal.BlockState_, $$1: Internal.Rotation_): Internal.BlockState;
        defaultMapColor(): Internal.MapColor;
        getStateAtViewpoint(state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_, viewpoint: Vec3d_): Internal.BlockState;
        wait(arg0: number, arg1: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.BlockGetter_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        setNameKey(arg0: string): void;
        static box($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): Internal.VoxelShape;
        /**
         * @deprecated
        */
        mirror($$0: Internal.BlockState_, $$1: Internal.Mirror_): Internal.BlockState;
        wasExploded($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Explosion_): void;
        getName(): Internal.MutableComponent;
        updateEntityAfterFallOn($$0: Internal.BlockGetter_, $$1: Internal.Entity_): void;
        animateTick($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        customShouldDrawFace(view: Internal.BlockGetter_, thisState: Internal.BlockState_, sideState: Internal.BlockState_, thisPos: BlockPos_, sidePos: BlockPos_, side: Internal.Direction_): Optional<boolean>;
        axiom$getResourceLocation(): ResourceLocation;
        arch$registryName(): ResourceLocation;
        axiom$getProperties(): Internal.Collection<any>;
        getBlockBuilder(): Internal.BlockBuilder;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        isSignalSource($$0: Internal.BlockState_): boolean;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number): void;
        /**
         * @deprecated
        */
        attack($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): void;
        getShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        shouldAttemptToCull(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        onProjectileHit($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockHitResult_, $$3: Internal.Projectile_): void;
        static stateById($$0: number): Internal.BlockState;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): Internal.List<Internal.ItemStack>;
        requiredFeatures(): Internal.FeatureFlagSet;
        hashCode(): number;
        axiom$defaultCustomState(): Internal.CustomBlockState;
        setCanCull(canCull: boolean): void;
        /**
         * @deprecated
        */
        isOcclusionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static getId($$0: Internal.BlockState_): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.material.Fluid)"($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        static pushEntitiesUp($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): Internal.BlockState;
        isPathfindable($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.PathComputationType_): boolean;
        setSoundType(arg0: SoundType_): void;
        handler$cef000$betterend$be_getDroppedStacks(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, info: Internal.CallbackInfoReturnable_<any>): void;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_): Internal.List<Internal.ItemStack>;
        /**
         * @deprecated
        */
        onRemove($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        cantCullAgainst(state: Internal.BlockState_): boolean;
        setHasCollision(arg0: boolean): void;
        static shouldRenderFace($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_, $$4: BlockPos_): boolean;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        spawnAfterBreak($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.ItemStack_, $$4: boolean): void;
        set randomTickCallback(callback: Internal.Consumer_<any>)
        get descriptionId(): string
        get settings(): Internal.BlockBehaviour$Properties
        get explosionResistance(): number
        get typeData(): Internal.CompoundTag
        set friction(arg0: number)
        get jumpFactor(): number
        get speedFactor(): number
        get properties(): Internal.BlockBehaviour$Properties
        get class(): typeof any
        get maxVerticalOffset(): number
        get stateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>
        set blockBuilder(b: Internal.BlockBuilder_)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        set speedFactor(arg0: number)
        set explosionResistance(arg0: number)
        get id(): string
        get lootTable(): ResourceLocation
        get friction(): number
        set lightEmission(v: number)
        set jumpFactor(arg0: number)
        set destroySpeed(v: number)
        get maxHorizontalOffset(): number
        set isRandomlyTicking(arg0: boolean)
        set nameKey(arg0: string)
        get name(): Internal.MutableComponent
        get blockBuilder(): Internal.BlockBuilder
        get idLocation(): ResourceLocation
        get mod(): string
        set canCull(canCull: boolean)
        set soundType(arg0: SoundType_)
        set hasCollision(arg0: boolean)
        static readonly SNOW: Internal.Predicate<Internal.Biome$Precipitation>;
        static readonly RAIN: Internal.Predicate<Internal.Biome$Precipitation>;
        static readonly MIN_FILL_LEVEL: (1) & (number);
        static readonly MAX_FILL_LEVEL: (3) & (number);
        static readonly LEVEL: (Internal.IntegerProperty) & (Internal.IntegerProperty);
    }
    type LayeredCauldronBlock_ = LayeredCauldronBlock;
    interface FoliagePlacer$FoliageSetter {
        abstract isSet(arg0: BlockPos_): boolean;
        abstract set(arg0: BlockPos_, arg1: Internal.BlockState_): void;
    }
    type FoliagePlacer$FoliageSetter_ = FoliagePlacer$FoliageSetter;
    class ElementiumAxeItem extends Internal.ManasteelAxeItem {
        constructor(props: Internal.Item$Properties_)
        onTick(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        bclib_getBlockTag(): Internal.TagKey<any>;
        onWearerUse(stack: Internal.ItemStack_, world: Internal.Level_, user: Internal.Player_, hand: Internal.InteractionHand_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        static "setStrippedBlocks$fabric-content-registries-v0_$md$424943$2"(arg0: Internal.Map_<any, any>): void;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        addModifierTooltip(stack: Internal.ItemStack_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_, type: Internal.ModifierHelperType_<any>): void;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        static setStrippedBlocks(strippedBlocks: Internal.Map_<Internal.Block, Internal.Block>): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        canApplyAtEnchantingTable(stack: Internal.ItemStack_, enchantment: Internal.Enchantment_): boolean;
        porting_lib$getStripped(arg0: Internal.BlockState_): Optional<any>;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        fzzy_core_correctSlot(slot: Internal.EquipmentSlot_): boolean;
        getCreativeTab(): string;
        postWearerHit(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        modifierObjectPredicate(livingEntity: Internal.LivingEntity_, stack: Internal.ItemStack_): ResourceLocation;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        static getStrippedBlocks(): Internal.Map<Internal.Block, Internal.Block>;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        kjs$getAttributeMap(): Internal.Multimap<any, any>;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        kjs$getMutableAttributeMap(): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        useOn(ctx: Internal.UseOnContext_): Internal.InteractionResult;
        fzzy_core_getCorrectSlot(): Internal.EquipmentSlot;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        damageItem<T extends Internal.LivingEntity>(stack: Internal.ItemStack_, amount: number, entity: T, onBroken: Internal.Consumer_<T>): number;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        static onEntityDrops(hitRecently: boolean, source: DamageSource_, target: Internal.LivingEntity_, consumer: Internal.Consumer_<Internal.ItemStack>): void;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        onWearerKilledOther(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, victim: Internal.LivingEntity_, world: Internal.ServerLevel_): void;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        static "getStrippedBlocks$fabric-content-registries-v0_$md$424943$1"(): Internal.Map<any, any>;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        invokeGetStrippedState(arg0: Internal.BlockState_): Optional<any>;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        canBeModifiedBy(type: Internal.ModifierHelperType_<any>): boolean;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        getAttackDamage(): number;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        incrementKillCount(stack: Internal.ItemStack_): void;
        setDigSpeed(speed: number): void;
        getManaPerDamage(): number;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        defaultModifiers(type: Internal.ModifierHelperType_<any>): Internal.List<any>;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        port_lib$canPerformAction(stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): boolean;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        getSortingPriority(stack: Internal.ItemStack_, state: Internal.BlockState_): number;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        getTier(): Internal.Tier;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        static getStrippedBlocks$amethyst_imbuement_$md$424943$0(): Internal.Map<any, any>;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick(stack: Internal.ItemStack_, world: Internal.Level_, entity: Internal.Entity_, slot: number, selected: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy(stack: Internal.ItemStack_, target: Internal.LivingEntity_, attacker: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getKillCount(stack: Internal.ItemStack_): number;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        postWearerMine(stack: Internal.ItemStack_, world: Internal.Level_, state: Internal.BlockState_, pos: BlockPos_, miner: Internal.Player_): void;
        kjs$setAttributeMap(arg0: Internal.Multimap_<any, any>): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        set "strippedBlocks$fabric-content-registries-v0_$md$424943$2"(arg0: Internal.Map_<any, any>)
        get fireResistant(): boolean
        get complex(): boolean
        set strippedBlocks(strippedBlocks: Internal.Map_<Internal.Block, Internal.Block>)
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get strippedBlocks(): Internal.Map<Internal.Block, Internal.Block>
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get "strippedBlocks$fabric-content-registries-v0_$md$424943$1"(): Internal.Map<any, any>
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        get attackDamage(): number
        set digSpeed(speed: number)
        get manaPerDamage(): number
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        get tier(): Internal.Tier
        set nameKey(arg0: string)
        get strippedBlocks$amethyst_imbuement_$md$424943$0(): Internal.Map<any, any>
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type ElementiumAxeItem_ = ElementiumAxeItem;
    class DoubleArgumentInfo$Template implements Internal.ArgumentTypeInfo$Template<Internal.DoubleArgumentType> {
        getClass(): typeof any;
        instantiate(arg0: Internal.CommandBuildContext_): Internal.ArgumentType<any>;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        "instantiate(net.minecraft.commands.CommandBuildContext)"($$0: Internal.CommandBuildContext_): Internal.DoubleArgumentType;
        wait(arg0: number, arg1: number): void;
        instantiate($$0: Internal.CommandBuildContext_): Internal.DoubleArgumentType;
        hashCode(): number;
        wait(): void;
        type(): Internal.ArgumentTypeInfo<Internal.DoubleArgumentType, any>;
        wait(arg0: number): void;
        "instantiate(net.minecraft.commands.CommandBuildContext)"(arg0: Internal.CommandBuildContext_): Internal.ArgumentType<any>;
        equals(arg0: any): boolean;
        get class(): typeof any
    }
    type DoubleArgumentInfo$Template_ = DoubleArgumentInfo$Template;
    class SkiesRodItem extends Internal.Item {
        constructor(props: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        static doAvatarJump(p: Internal.Player_, world: Internal.Level_): void;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth(stack: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor(stack: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(world: Internal.Level_, player: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        static isFlying(stack: Internal.ItemStack_): boolean;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible(stack: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        static doAvatarElytraBoost(p: Internal.Player_, world: Internal.Level_): void;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick(stack: Internal.ItemStack_, world: Internal.Level_, ent: Internal.Entity_, slot: number, active: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        shouldCauseReequipAnimation(oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_, slotChanged: boolean): boolean;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type SkiesRodItem_ = SkiesRodItem;
    class StyleConstants {
        static setStrikeThrough(arg0: Internal.MutableAttributeSet_, arg1: boolean): void;
        static setSpaceBelow(arg0: Internal.MutableAttributeSet_, arg1: number): void;
        static getFontSize(arg0: Internal.AttributeSet_): number;
        static setSubscript(arg0: Internal.MutableAttributeSet_, arg1: boolean): void;
        notify(): void;
        static setAlignment(arg0: Internal.MutableAttributeSet_, arg1: number): void;
        static isSubscript(arg0: Internal.AttributeSet_): boolean;
        static getLeftIndent(arg0: Internal.AttributeSet_): number;
        static getAlignment(arg0: Internal.AttributeSet_): number;
        static setComponent(arg0: Internal.MutableAttributeSet_, arg1: Internal.Component_): void;
        static getTabSet(arg0: Internal.AttributeSet_): Internal.TabSet;
        static setLeftIndent(arg0: Internal.MutableAttributeSet_, arg1: number): void;
        static setTabSet(arg0: Internal.MutableAttributeSet_, arg1: Internal.TabSet_): void;
        static isBold(arg0: Internal.AttributeSet_): boolean;
        static setFirstLineIndent(arg0: Internal.MutableAttributeSet_, arg1: number): void;
        wait(): void;
        static setForeground(arg0: Internal.MutableAttributeSet_, arg1: Internal.Color_): void;
        static setRightIndent(arg0: Internal.MutableAttributeSet_, arg1: number): void;
        static getComponent(arg0: Internal.AttributeSet_): Internal.Component;
        static getIcon(arg0: Internal.AttributeSet_): javax.swing.Icon;
        getClass(): typeof any;
        static setLineSpacing(arg0: Internal.MutableAttributeSet_, arg1: number): void;
        static getForeground(arg0: Internal.AttributeSet_): Internal.Color;
        static getFontFamily(arg0: Internal.AttributeSet_): string;
        static isItalic(arg0: Internal.AttributeSet_): boolean;
        static setUnderline(arg0: Internal.MutableAttributeSet_, arg1: boolean): void;
        static setIcon(arg0: Internal.MutableAttributeSet_, arg1: javax.swing.Icon_): void;
        wait(arg0: number, arg1: number): void;
        static setFontSize(arg0: Internal.MutableAttributeSet_, arg1: number): void;
        static getSpaceBelow(arg0: Internal.AttributeSet_): number;
        static setBackground(arg0: Internal.MutableAttributeSet_, arg1: Internal.Color_): void;
        static getRightIndent(arg0: Internal.AttributeSet_): number;
        static isUnderline(arg0: Internal.AttributeSet_): boolean;
        static setSuperscript(arg0: Internal.MutableAttributeSet_, arg1: boolean): void;
        static getBidiLevel(arg0: Internal.AttributeSet_): number;
        toString(): string;
        static getBackground(arg0: Internal.AttributeSet_): Internal.Color;
        static setItalic(arg0: Internal.MutableAttributeSet_, arg1: boolean): void;
        notifyAll(): void;
        static setFontFamily(arg0: Internal.MutableAttributeSet_, arg1: string): void;
        static getFirstLineIndent(arg0: Internal.AttributeSet_): number;
        static isSuperscript(arg0: Internal.AttributeSet_): boolean;
        static getSpaceAbove(arg0: Internal.AttributeSet_): number;
        hashCode(): number;
        static getLineSpacing(arg0: Internal.AttributeSet_): number;
        static setBidiLevel(arg0: Internal.MutableAttributeSet_, arg1: number): void;
        static setBold(arg0: Internal.MutableAttributeSet_, arg1: boolean): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        static setSpaceAbove(arg0: Internal.MutableAttributeSet_, arg1: number): void;
        static isStrikeThrough(arg0: Internal.AttributeSet_): boolean;
        get class(): typeof any
        static readonly LeftIndent: (Internal.StyleConstants$ParagraphConstants) & (any);
        static readonly SpaceBelow: (Internal.StyleConstants$ParagraphConstants) & (any);
        static readonly FontFamily: (Internal.StyleConstants$FontConstants) & (any);
        static readonly FontSize: (Internal.StyleConstants$FontConstants) & (any);
        static readonly Superscript: (Internal.StyleConstants$CharacterConstants) & (any);
        static readonly IconAttribute: (Internal.StyleConstants$CharacterConstants) & (any);
        static readonly Bold: (Internal.StyleConstants$FontConstants) & (any);
        static readonly ModelAttribute: (Internal.StyleConstants) & (any);
        static readonly StrikeThrough: (Internal.StyleConstants$CharacterConstants) & (any);
        static readonly ALIGN_JUSTIFIED: (3) & (number);
        static readonly NameAttribute: (Internal.StyleConstants) & (any);
        static readonly Size: (Internal.StyleConstants$FontConstants) & (any);
        static readonly Alignment: (Internal.StyleConstants$ParagraphConstants) & (any);
        static readonly Background: (Internal.StyleConstants$ColorConstants) & (any);
        static readonly TabSet: (Internal.StyleConstants$ParagraphConstants) & (any);
        static readonly ALIGN_RIGHT: (2) & (number);
        static readonly Orientation: (Internal.StyleConstants$ParagraphConstants) & (any);
        static readonly IconElementName: ("icon") & (string);
        static readonly Foreground: (Internal.StyleConstants$ColorConstants) & (any);
        static readonly RightIndent: (Internal.StyleConstants$ParagraphConstants) & (any);
        static readonly ALIGN_LEFT: (0) & (number);
        static readonly ComposedTextAttribute: (Internal.StyleConstants) & (any);
        static readonly ComponentAttribute: (Internal.StyleConstants$CharacterConstants) & (any);
        static readonly LineSpacing: (Internal.StyleConstants$ParagraphConstants) & (any);
        static readonly Underline: (Internal.StyleConstants$CharacterConstants) & (any);
        static readonly Italic: (Internal.StyleConstants$FontConstants) & (any);
        static readonly Subscript: (Internal.StyleConstants$CharacterConstants) & (any);
        static readonly ComponentElementName: ("component") & (string);
        static readonly SpaceAbove: (Internal.StyleConstants$ParagraphConstants) & (any);
        static readonly ALIGN_CENTER: (1) & (number);
        static readonly Family: (Internal.StyleConstants$FontConstants) & (any);
        static readonly FirstLineIndent: (Internal.StyleConstants$ParagraphConstants) & (any);
        static readonly ResolveAttribute: (Internal.StyleConstants) & (any);
        static readonly BidiLevel: (Internal.StyleConstants$CharacterConstants) & (any);
    }
    type StyleConstants_ = StyleConstants;
    class DispenserMenu extends Internal.AbstractContainerMenu {
        constructor($$0: number, $$1: Internal.Inventory_, $$2: net.minecraft.world.Container_)
        constructor($$0: number, $$1: Internal.Inventory_)
        findSlot($$0: net.minecraft.world.Container_, $$1: number): Internal.OptionalInt;
        getItems(): Internal.NonNullList<Internal.ItemStack>;
        addSlot($$0: Internal.Slot_): Internal.Slot;
        owo$handlePacket(buf: Internal.FriendlyByteBuf_, clientbound: boolean): void;
        quickMoveStack($$0: Internal.Player_, $$1: number): Internal.ItemStack;
        gettype(): Internal.MenuType<any>;
        getTrackedStacks(): Internal.NonNullList<any>;
        setRemoteCarried($$0: Internal.ItemStack_): void;
        broadcastFullState(): void;
        notify(): void;
        player(): Internal.Player;
        incrementStateId(): number;
        isValidSlotIndex($$0: number): boolean;
        broadcastChanges(): void;
        sendMessage(message: Internal.Record_): void;
        setData($$0: number, $$1: number): void;
        getSlot($$0: number): Internal.Slot;
        owo$attachToPlayer(player: Internal.Player_): void;
        owo$readPropertySync(buf: Internal.FriendlyByteBuf_): void;
        slotsChanged($$0: net.minecraft.world.Container_): void;
        removeSlotListener($$0: net.minecraft.world.inventory.ContainerListener_): void;
        getPreviousTrackedStacks(): Internal.NonNullList<any>;
        setRemoteSlot($$0: number, $$1: Internal.ItemStack_): void;
        createProperty(klass: typeof any, initial: any): Internal.SyncedProperty<any>;
        getCarried(): Internal.ItemStack;
        wait(): void;
        getType(): Internal.MenuType<any>;
        setSynchronizer($$0: Internal.ContainerSynchronizer_): void;
        static isValidQuickcraftType($$0: number, $$1: Internal.Player_): boolean;
        getClass(): typeof any;
        static getRedstoneSignalFromBlockEntity($$0: Internal.BlockEntity_): number;
        canTakeItemForPickAll($$0: Internal.ItemStack_, $$1: Internal.Slot_): boolean;
        setItem($$0: number, $$1: number, $$2: Internal.ItemStack_): void;
        hasSlots(): boolean;
        static getRedstoneSignalFromContainer($$0: net.minecraft.world.Container_): number;
        setCarried($$0: Internal.ItemStack_): void;
        sendAllDataToRemote(): void;
        static getQuickCraftPlaceCount($$0: Internal.Set_<Internal.Slot>, $$1: number, $$2: Internal.ItemStack_): number;
        wait(arg0: number, arg1: number): void;
        getInventory(): net.minecraft.world.Container;
        addServerboundMessage(messageClass: typeof any, handler: Internal.Consumer_<any>): void;
        resumeRemoteUpdates(): void;
        static getQuickcraftHeader($$0: number): number;
        owo$insertItem(arg0: Internal.ItemStack_, arg1: number, arg2: number, arg3: boolean): boolean;
        static canItemQuickReplace($$0: Internal.Slot_, $$1: Internal.ItemStack_, $$2: boolean): boolean;
        addSlotListener($$0: net.minecraft.world.inventory.ContainerListener_): void;
        addClientboundMessage(messageClass: typeof any, handler: Internal.Consumer_<any>): void;
        toString(): string;
        clickMenuButton($$0: Internal.Player_, $$1: number): boolean;
        static getQuickcraftMask($$0: number, $$1: number): number;
        notifyAll(): void;
        static getQuickcraftType($$0: number): number;
        handler$hhd000$inventorysorter$sortOnDoubleClickEmpty(slotIndex: number, button: number, actionType: Internal.ClickType_, player: Internal.Player_, ci: Internal.CallbackInfo_): void;
        setRemoteSlotNoCopy($$0: number, $$1: Internal.ItemStack_): void;
        clicked($$0: number, $$1: number, $$2: Internal.ClickType_, $$3: Internal.Player_): void;
        stillValid($$0: Internal.Player_): boolean;
        suppressRemoteUpdates(): void;
        hashCode(): number;
        initializeContents($$0: number, $$1: Internal.List_<Internal.ItemStack>, $$2: Internal.ItemStack_): void;
        getStateId(): number;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        transferState($$0: Internal.AbstractContainerMenu_): void;
        canDragTo($$0: Internal.Slot_): boolean;
        removed($$0: Internal.Player_): void;
        get items(): Internal.NonNullList<Internal.ItemStack>
        get type(): Internal.MenuType<any>
        get trackedStacks(): Internal.NonNullList<any>
        set remoteCarried($$0: Internal.ItemStack_)
        get previousTrackedStacks(): Internal.NonNullList<any>
        get carried(): Internal.ItemStack
        get type(): Internal.MenuType<any>
        set synchronizer($$0: Internal.ContainerSynchronizer_)
        get class(): typeof any
        set carried($$0: Internal.ItemStack_)
        get inventory(): net.minecraft.world.Container
        get stateId(): number
    }
    type DispenserMenu_ = DispenserMenu;
    class GameEvent implements Internal.InjectedGameEventExtension {
        constructor($$0: string, $$1: number)
        getClass(): typeof any;
        toString(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.GameEvent>;
        notifyAll(): void;
        notify(): void;
        getNotificationRadius(): number;
        wait(arg0: number, arg1: number): void;
        arch$holder(): Internal.Holder<Internal.GameEvent>;
        hashCode(): number;
        is($$0: Internal.TagKey_<Internal.GameEvent>): boolean;
        wait(): void;
        getName(): string;
        wait(arg0: number): void;
        arch$registryName(): ResourceLocation;
        equals(arg0: any): boolean;
        get class(): typeof any
        get notificationRadius(): number
        get name(): string
        static readonly RESONATE_14: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly ITEM_INTERACT_START: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly RESONATE_10: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly LIGHTNING_STRIKE: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly JUKEBOX_PLAY: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly RESONATE_4: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly DEFAULT_NOTIFICATION_RADIUS: (16) & (number);
        static readonly PROJECTILE_LAND: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly BLOCK_OPEN: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly ENTITY_PLACE: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly TELEPORT: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly RESONATE_9: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly BLOCK_DEACTIVATE: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly SWIM: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly INSTRUMENT_PLAY: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly BLOCK_ACTIVATE: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly DRINK: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly FLUID_PICKUP: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly CONTAINER_CLOSE: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly RESONATE_15: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly EXPLODE: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly HIT_GROUND: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly RESONATE_11: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly ENTITY_DAMAGE: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly ENTITY_DISMOUNT: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly RESONATE_5: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly FLAP: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly ENTITY_MOUNT: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly RESONATE_1: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly SHEAR: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly BLOCK_CLOSE: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly ENTITY_SHAKE: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly BLOCK_DETACH: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly FLUID_PLACE: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly ELYTRA_GLIDE: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly PROJECTILE_SHOOT: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly CONTAINER_OPEN: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly ENTITY_INTERACT: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly ENTITY_ROAR: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly EQUIP: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly NOTE_BLOCK_PLAY: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly SCULK_SENSOR_TENDRILS_CLICKING: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly BLOCK_ATTACH: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly RESONATE_12: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly BLOCK_PLACE: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly RESONATE_6: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly RESONATE_2: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly SHRIEK: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly BLOCK_DESTROY: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly EAT: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly ENTITY_DIE: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly RESONATE_7: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly SPLASH: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly ITEM_INTERACT_FINISH: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly PRIME_FUSE: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly RESONATE_13: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly STEP: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly RESONATE_3: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly JUKEBOX_STOP_PLAY: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly BLOCK_CHANGE: (Internal.GameEvent) & (Internal.GameEvent);
        static readonly RESONATE_8: (Internal.GameEvent) & (Internal.GameEvent);
    }
    type GameEvent_ = Special.GameEvent | GameEvent;
    interface EquipmentModifier$DamageFunction {
        abstract test(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: Internal.LivingEntity_, arg3: DamageSource_, arg4: number): number;
        (arg0: Internal.ItemStack, arg1: Internal.LivingEntity, arg2: Internal.LivingEntity, arg3: DamageSource, arg4: number): number;
    }
    type EquipmentModifier$DamageFunction_ = EquipmentModifier$DamageFunction | ((arg0: Internal.ItemStack, arg1: Internal.LivingEntity, arg2: Internal.LivingEntity, arg3: DamageSource, arg4: number)=> number);
    class RenderStateShard$ShaderStateShard extends Internal.RenderStateShard {
        constructor()
        constructor($$0: Internal.Supplier_<Internal.ShaderInstance>)
        getClass(): typeof any;
        toString(): string;
        static getTranslucentTransparency(): Internal.RenderStateShard$TransparencyStateShard;
        notifyAll(): void;
        static getGLINT_TRANSPARENCY(): Internal.RenderStateShard$TransparencyStateShard;
        port_lib$setupState(arg0: Internal.Runnable_): void;
        static getNO_TRANSPARENCY$iris_$md$424943$1(): Internal.RenderStateShard$TransparencyStateShard;
        notify(): void;
        static getNO_TRANSPARENCY(): Internal.RenderStateShard$TransparencyStateShard;
        wait(arg0: number, arg1: number): void;
        clearRenderState(): void;
        static getGLINT_TRANSPARENCY$iris_$md$424943$2(): Internal.RenderStateShard$TransparencyStateShard;
        hashCode(): number;
        static getCRUMBLING_TRANSPARENCY$iris_$md$424943$3(): Internal.RenderStateShard$TransparencyStateShard;
        setupRenderState(): void;
        hex$name(): string;
        wait(): void;
        getName(): string;
        static getTranslucentTransparency$iris_$md$424943$0(): Internal.RenderStateShard$TransparencyStateShard;
        wait(arg0: number): void;
        port_lib$clearState(arg0: Internal.Runnable_): void;
        static getCRUMBLING_TRANSPARENCY(): Internal.RenderStateShard$TransparencyStateShard;
        equals(arg0: any): boolean;
        get class(): typeof any
        get translucentTransparency(): Internal.RenderStateShard$TransparencyStateShard
        get GLINT_TRANSPARENCY(): Internal.RenderStateShard$TransparencyStateShard
        get NO_TRANSPARENCY$iris_$md$424943$1(): Internal.RenderStateShard$TransparencyStateShard
        get NO_TRANSPARENCY(): Internal.RenderStateShard$TransparencyStateShard
        get GLINT_TRANSPARENCY$iris_$md$424943$2(): Internal.RenderStateShard$TransparencyStateShard
        get CRUMBLING_TRANSPARENCY$iris_$md$424943$3(): Internal.RenderStateShard$TransparencyStateShard
        get name(): string
        get translucentTransparency$iris_$md$424943$0(): Internal.RenderStateShard$TransparencyStateShard
        get CRUMBLING_TRANSPARENCY(): Internal.RenderStateShard$TransparencyStateShard
    }
    type RenderStateShard$ShaderStateShard_ = RenderStateShard$ShaderStateShard;
    interface BetterEndElytra extends Internal.BCLElytraItem {
        vanillaElytraTick(entity: Internal.LivingEntity_, chestStack: Internal.ItemStack_): void;
        doVanillaElytraTick(entity: Internal.LivingEntity_, chestStack: Internal.ItemStack_): void;
        useCustomElytra(entity: Internal.LivingEntity_, chestStack: Internal.ItemStack_, tickElytra: boolean): boolean;
        abstract getModelTexture(): ResourceLocation;
        abstract getMovementFactor(): number;
        get modelTexture(): ResourceLocation
        get movementFactor(): number
    }
    type BetterEndElytra_ = BetterEndElytra;
    interface Iterable <T> extends Array<T> {
        forEach(arg0: Internal.Consumer_<T>): void;
        spliterator(): Internal.Spliterator<T>;
        abstract iterator(): Internal.Iterator<T>;
        (): Internal.Iterator_<T>;
    }
    type Iterable_<T> = (()=> Internal.Iterator_<T>) | Iterable<T>;
    interface SlotExtensions {
        getSlotIndex(): number;
        setBackground(atlas: ResourceLocation_, sprite: ResourceLocation_): Internal.Slot;
        get slotIndex(): number
    }
    type SlotExtensions_ = SlotExtensions;
    class LongArgumentInfo implements Internal.ArgumentTypeInfo<Internal.LongArgumentType, Internal.LongArgumentInfo$Template> {
        constructor()
        getClass(): typeof any;
        "serializeToJson(net.minecraft.commands.synchronization.brigadier.LongArgumentInfo$Template,com.google.gson.JsonObject)"($$0: Internal.LongArgumentInfo$Template_, $$1: Internal.JsonObject_): void;
        "unpack(com.mojang.brigadier.arguments.LongArgumentType)"($$0: Internal.LongArgumentType_): Internal.LongArgumentInfo$Template;
        "deserializeFromNetwork(net.minecraft.network.FriendlyByteBuf)"($$0: Internal.FriendlyByteBuf_): Internal.LongArgumentInfo$Template;
        unpack($$0: Internal.LongArgumentType_): Internal.LongArgumentInfo$Template;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        serializeToJson(arg0: Internal.ArgumentTypeInfo$Template_<any>, arg1: Internal.JsonObject_): void;
        serializeToNetwork($$0: Internal.LongArgumentInfo$Template_, $$1: Internal.FriendlyByteBuf_): void;
        deserializeFromNetwork(arg0: Internal.FriendlyByteBuf_): Internal.ArgumentTypeInfo$Template<any>;
        toString(): string;
        notifyAll(): void;
        "deserializeFromNetwork(net.minecraft.network.FriendlyByteBuf)"(arg0: Internal.FriendlyByteBuf_): Internal.ArgumentTypeInfo$Template<any>;
        "serializeToNetwork(net.minecraft.commands.synchronization.brigadier.LongArgumentInfo$Template,net.minecraft.network.FriendlyByteBuf)"($$0: Internal.LongArgumentInfo$Template_, $$1: Internal.FriendlyByteBuf_): void;
        "unpack(com.mojang.brigadier.arguments.ArgumentType)"(arg0: Internal.ArgumentType_<any>): Internal.ArgumentTypeInfo$Template<any>;
        unpack(arg0: Internal.ArgumentType_<any>): Internal.ArgumentTypeInfo$Template<any>;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        serializeToNetwork(arg0: Internal.ArgumentTypeInfo$Template_<any>, arg1: Internal.FriendlyByteBuf_): void;
        "serializeToNetwork(net.minecraft.commands.synchronization.ArgumentTypeInfo$Template,net.minecraft.network.FriendlyByteBuf)"(arg0: Internal.ArgumentTypeInfo$Template_<any>, arg1: Internal.FriendlyByteBuf_): void;
        serializeToJson($$0: Internal.LongArgumentInfo$Template_, $$1: Internal.JsonObject_): void;
        equals(arg0: any): boolean;
        "serializeToJson(net.minecraft.commands.synchronization.ArgumentTypeInfo$Template,com.google.gson.JsonObject)"(arg0: Internal.ArgumentTypeInfo$Template_<any>, arg1: Internal.JsonObject_): void;
        deserializeFromNetwork($$0: Internal.FriendlyByteBuf_): Internal.LongArgumentInfo$Template;
        get class(): typeof any
    }
    type LongArgumentInfo_ = LongArgumentInfo;
    class ChestMenuClickEvent {
        constructor(slot: Internal.ChestMenuSlot_, type: Internal.ClickType_, button: number)
        setHandled(): void;
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        readonly slot: Internal.ChestMenuSlot;
        readonly button: number;
        readonly type: Internal.ClickType;
    }
    type ChestMenuClickEvent_ = ChestMenuClickEvent;
    class StructureTemplate$StructureBlockInfo extends Internal.Record implements Internal.StructureBlockInfoModification {
        constructor($$0: BlockPos_, $$1: Internal.BlockState_, $$2: Internal.CompoundTag_)
        getNbt(): Internal.CompoundTag;
        getClass(): typeof any;
        hasNbt(): boolean;
        getPosition(): BlockPos;
        toString(): string;
        pos(): BlockPos;
        notifyAll(): void;
        setBlock(id: ResourceLocation_, properties: Internal.Map_<any, any>): void;
        getId(): string;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        setNbt(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        nbt(): Internal.CompoundTag;
        setBlock(id: ResourceLocation_): void;
        wait(): void;
        getProperties(): Internal.Map<any, any>;
        state(): Internal.BlockState;
        wait(arg0: number): void;
        equals($$0: any): boolean;
        getBlock(): Internal.Block;
        get nbt(): Internal.CompoundTag
        get class(): typeof any
        get position(): BlockPos
        get id(): string
        set nbt(nbt: Internal.CompoundTag_)
        set block(id: ResourceLocation_)
        get properties(): Internal.Map<any, any>
        get block(): Internal.Block
        readonly pos: BlockPos;
    }
    type StructureTemplate$StructureBlockInfo_ = StructureTemplate$StructureBlockInfo;
    class ServerData$ServerPackStatus extends Internal.Enum<Internal.ServerData$ServerPackStatus> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        getName(): net.minecraft.network.chat.Component;
        toString(): string;
        "compareTo(net.minecraft.client.multiplayer.ServerData$ServerPackStatus)"(arg0: Internal.ServerData$ServerPackStatus_): number;
        notifyAll(): void;
        compareTo(arg0: Internal.ServerData$ServerPackStatus_): number;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.ServerData$ServerPackStatus>>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        name(): string;
        hashCode(): number;
        static values(): Internal.ServerData$ServerPackStatus[];
        ordinal(): number;
        wait(): void;
        getDeclaringClass(): typeof Internal.ServerData$ServerPackStatus;
        wait(arg0: number): void;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        static valueOf($$0: string): Internal.ServerData$ServerPackStatus;
        get class(): typeof any
        get name(): net.minecraft.network.chat.Component
        get declaringClass(): typeof Internal.ServerData$ServerPackStatus
        static readonly ENABLED: (Internal.ServerData$ServerPackStatus) & (Internal.ServerData$ServerPackStatus);
        static readonly DISABLED: (Internal.ServerData$ServerPackStatus) & (Internal.ServerData$ServerPackStatus);
        static readonly PROMPT: (Internal.ServerData$ServerPackStatus) & (Internal.ServerData$ServerPackStatus);
    }
    type ServerData$ServerPackStatus_ = ServerData$ServerPackStatus | "prompt" | "disabled" | "enabled";
    class MythicBlocks$1 extends Internal.BlockItem {
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        static setBlockEntityData($$0: Internal.ItemStack_, $$1: Internal.BlockEntityType_<any>, $$2: Internal.CompoundTag_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        abstract moonlight$addAdditionalBehavior(arg0: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        modifyReturnValue$bkb000$axiom$canPlace(canPlace: boolean, blockPlaceContext: Internal.BlockPlaceContext_): boolean;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        abstract moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        handler$mpi000$tcdcommons$onPlace(context: Internal.BlockPlaceContext_, ci: Internal.CallbackInfoReturnable_<any>): void;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        abstract moonlight$setClientAnimationExtension(arg0: any): void;
        abstract moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        wrapOperation$bkb000$axiom$place$getPlacementState(instance: Internal.BlockItem_, blockPlaceContext: Internal.BlockPlaceContext_, original: Internal.Operation_<any>): Internal.BlockState;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        static getBlockEntityData($$0: Internal.ItemStack_): Internal.CompoundTag;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        removeFromBlockToItemMap(blockToItemMap: Internal.Map_<Internal.Block, Internal.Item>, itemIn: Internal.Item_): void;
        isFoil(stack: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        static updateCustomBlockEntityTag($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.ItemStack_): boolean;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        place($$0: Internal.BlockPlaceContext_): Internal.InteractionResult;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        getBlock(): Internal.Block;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        updatePlacementContext($$0: Internal.BlockPlaceContext_): Internal.BlockPlaceContext;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        registerBlocks($$0: Internal.Map_<Internal.Block, Internal.Item>, $$1: Internal.Item_): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        puzzleslib$setBlock(arg0: Internal.Block_): void;
        wrapOperation$bkb000$axiom$place$updatePlacementContext(instance: Internal.BlockItem_, blockPlaceContext: Internal.BlockPlaceContext_, original: Internal.Operation_<any>): Internal.BlockPlaceContext;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        get block(): Internal.Block
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type MythicBlocks$1_ = MythicBlocks$1;
    class EquipmentSlot$Type extends Internal.Enum<Internal.EquipmentSlot$Type> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        static values(): Internal.EquipmentSlot$Type[];
        toString(): string;
        compareTo(arg0: Internal.EquipmentSlot$Type_): number;
        notifyAll(): void;
        static valueOf($$0: string): Internal.EquipmentSlot$Type;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        "compareTo(net.minecraft.world.entity.EquipmentSlot$Type)"(arg0: Internal.EquipmentSlot$Type_): number;
        name(): string;
        hashCode(): number;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        getDeclaringClass(): typeof Internal.EquipmentSlot$Type;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.EquipmentSlot$Type>>;
        get class(): typeof any
        get declaringClass(): typeof Internal.EquipmentSlot$Type
        static readonly ARMOR: (Internal.EquipmentSlot$Type) & (Internal.EquipmentSlot$Type);
        static readonly HAND: (Internal.EquipmentSlot$Type) & (Internal.EquipmentSlot$Type);
    }
    type EquipmentSlot$Type_ = EquipmentSlot$Type | "armor" | "hand";
    class SackItem extends Internal.BlockItem {
        constructor(blockIn: Internal.Block_, builder: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        static setBlockEntityData($$0: Internal.ItemStack_, $$1: Internal.BlockEntityType_<any>, $$2: Internal.CompoundTag_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        abstract moonlight$addAdditionalBehavior(arg0: Internal.AdditionalItemPlacement_): void;
        onDestroyed(pItemEntity: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        modifyReturnValue$bkb000$axiom$canPlace(canPlace: boolean, blockPlaceContext: Internal.BlockPlaceContext_): boolean;
        appendHoverText(stack: Internal.ItemStack_, worldIn: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, flagIn: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        abstract moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        handler$mpi000$tcdcommons$onPlace(context: Internal.BlockPlaceContext_, ci: Internal.CallbackInfoReturnable_<any>): void;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        abstract moonlight$setClientAnimationExtension(arg0: any): void;
        abstract moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage(pStack: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        wrapOperation$bkb000$axiom$place$getPlacementState(instance: Internal.BlockItem_, blockPlaceContext: Internal.BlockPlaceContext_, original: Internal.Operation_<any>): Internal.BlockState;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        static getBlockEntityData($$0: Internal.ItemStack_): Internal.CompoundTag;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther(stack: Internal.ItemStack_, slot: Internal.Slot_, action: Internal.ClickAction_, player: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        removeFromBlockToItemMap(blockToItemMap: Internal.Map_<Internal.Block, Internal.Item>, itemIn: Internal.Item_): void;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        static updateCustomBlockEntityTag($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.ItemStack_): boolean;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        place($$0: Internal.BlockPlaceContext_): Internal.InteractionResult;
        static getEncumber(slotItem: Internal.ItemStack_): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        getBlock(): Internal.Block;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        updatePlacementContext($$0: Internal.BlockPlaceContext_): Internal.BlockPlaceContext;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        registerBlocks($$0: Internal.Map_<Internal.Block, Internal.Item>, $$1: Internal.Item_): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick(stack: Internal.ItemStack_, worldIn: Internal.Level_, entityIn: Internal.Entity_, itemSlot: number, isSelected: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe(stack: Internal.ItemStack_, incoming: Internal.ItemStack_, slot: Internal.Slot_, action: Internal.ClickAction_, player: Internal.Player_, accessor: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        puzzleslib$setBlock(arg0: Internal.Block_): void;
        wrapOperation$bkb000$axiom$place$updatePlacementContext(instance: Internal.BlockItem_, blockPlaceContext: Internal.BlockPlaceContext_, original: Internal.Operation_<any>): Internal.BlockPlaceContext;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        get block(): Internal.Block
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type SackItem_ = SackItem;
    class ItemModelGenerator {
        constructor()
        getClass(): typeof any;
        handler$jbn000$modelfix$increaseSide(spriteContents: Internal.SpriteContents_, string: string, tintIndex: number, cir: Internal.CallbackInfoReturnable_<any>): void;
        hashCode(): number;
        toString(): string;
        processFrames($$0: number, $$1: string, $$2: Internal.SpriteContents_): Internal.List<Internal.BlockElement>;
        wait(): void;
        generateBlockModel($$0: Internal.Function_<Internal.Material, Internal.TextureAtlasSprite>, $$1: Internal.BlockModel_): Internal.BlockModel;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        static readonly LAYERS: (["layer0", "layer1", "layer2", "layer3", "layer4"]) & (Internal.List<string>);
    }
    type ItemModelGenerator_ = ItemModelGenerator;
    class SyncBookUnlockStatesMessage implements com.klikli_dev.modonomicon.networking.Message {
        constructor(buf: Internal.FriendlyByteBuf_)
        constructor(states: Internal.BookUnlockStates_)
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        encode(buf: Internal.FriendlyByteBuf_): void;
        decode(buf: Internal.FriendlyByteBuf_): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        onServerReceived(minecraftServer: Internal.MinecraftServer_, player: Internal.ServerPlayer_): void;
        hashCode(): number;
        getId(): ResourceLocation;
        wait(): void;
        onClientReceived(minecraft: Internal.Minecraft_, player: Internal.Player_): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        get class(): typeof any
        get id(): ResourceLocation
        states: Internal.BookUnlockStates;
        static readonly ID: (ResourceLocation) & (ResourceLocation);
    }
    type SyncBookUnlockStatesMessage_ = SyncBookUnlockStatesMessage;
    class JigsawBlockEntity$JointType extends Internal.Enum<Internal.JigsawBlockEntity$JointType> implements Internal.StringRepresentable {
        getClass(): typeof any;
        static fromEnumWithMapping<E extends Internal.Enum<E> & Internal.StringRepresentable>($$0: Internal.Supplier_<E[]>, $$1: Internal.Function_<string, string>): Internal.StringRepresentable$EnumCodec<E>;
        getSerializedName(): string;
        compareTo(arg0: Internal.JigsawBlockEntity$JointType_): number;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        static values(): Internal.JigsawBlockEntity$JointType[];
        compareTo(arg0: any): number;
        "compareTo(net.minecraft.world.level.block.entity.JigsawBlockEntity$JointType)"(arg0: Internal.JigsawBlockEntity$JointType_): number;
        static fromEnum<E extends Internal.Enum<E> & Internal.StringRepresentable>($$0: Internal.Supplier_<E[]>): Internal.StringRepresentable$EnumCodec<E>;
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.JigsawBlockEntity$JointType>>;
        static valueOf($$0: string): Internal.JigsawBlockEntity$JointType;
        toString(): string;
        notifyAll(): void;
        getTranslatedName(): net.minecraft.network.chat.Component;
        name(): string;
        hashCode(): number;
        static keys($$0: Internal.StringRepresentable_[]): Internal.Keyable;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        getDeclaringClass(): typeof Internal.JigsawBlockEntity$JointType;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        static byName(string: string): Optional<any>;
        get class(): typeof any
        get serializedName(): string
        get translatedName(): net.minecraft.network.chat.Component
        get declaringClass(): typeof Internal.JigsawBlockEntity$JointType
        static readonly ROLLABLE: (Internal.JigsawBlockEntity$JointType) & (Internal.JigsawBlockEntity$JointType);
        static readonly ALIGNED: (Internal.JigsawBlockEntity$JointType) & (Internal.JigsawBlockEntity$JointType);
    }
    type JigsawBlockEntity$JointType_ = "aligned" | "rollable" | JigsawBlockEntity$JointType;
    class FabricEventRegisterEventJS extends Internal.EventJS {
        constructor()
        getClass(): typeof any;
        /**
         * Stops the event with default exit value. Execution will be stopped **immediately**.
         * 
         * `exit` denotes a `default` outcome.
        */
        exit(): any;
        register(name: string, eventProvider: typeof any, fieldName: string): string;
        /**
         * Cancels the event with the given exit value. Execution will be stopped **immediately**.
         * 
         * `cancel` denotes a `false` outcome.
        */
        cancel(value: any): any;
        toString(): string;
        notifyAll(): void;
        /**
         * Stops the event with the given exit value. Execution will be stopped **immediately**.
         * 
         * `exit` denotes a `default` outcome.
        */
        exit(value: any): any;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        /**
         * Stops the event with the given exit value. Execution will be stopped **immediately**.
         * 
         * `success` denotes a `true` outcome.
        */
        success(value: any): any;
        hashCode(): number;
        wait(): void;
        /**
         * Cancels the event with default exit value. Execution will be stopped **immediately**.
         * 
         * `cancel` denotes a `false` outcome.
        */
        cancel(): any;
        wait(arg0: number): void;
        /**
         * Stops the event with default exit value. Execution will be stopped **immediately**.
         * 
         * `success` denotes a `true` outcome.
        */
        success(): any;
        equals(arg0: any): boolean;
        get class(): typeof any
        static readonly LOG: (Internal.Logger) & (org.apache.logging.log4j.Logger);
    }
    type FabricEventRegisterEventJS_ = FabricEventRegisterEventJS;
    class OreConfiguration$TargetBlockState {
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        static readonly CODEC: Internal.Codec<Internal.OreConfiguration$TargetBlockState>;
        readonly state: Internal.BlockState;
        readonly target: Internal.RuleTest;
    }
    type OreConfiguration$TargetBlockState_ = OreConfiguration$TargetBlockState;
    interface OpenOption {
    }
    type OpenOption_ = OpenOption;
    class VertexFormatElement$Usage extends Internal.Enum<Internal.VertexFormatElement$Usage> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        compareTo(arg0: Internal.VertexFormatElement$Usage_): number;
        toString(): string;
        clearBufferState($$0: number, $$1: number): void;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        "compareTo(com.mojang.blaze3d.vertex.VertexFormatElement$Usage)"(arg0: Internal.VertexFormatElement$Usage_): number;
        name(): string;
        hashCode(): number;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.VertexFormatElement$Usage>>;
        ordinal(): number;
        wait(): void;
        getName(): string;
        static values(): Internal.VertexFormatElement$Usage[];
        static valueOf($$0: string): Internal.VertexFormatElement$Usage;
        getDeclaringClass(): typeof Internal.VertexFormatElement$Usage;
        wait(arg0: number): void;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        get class(): typeof any
        get name(): string
        get declaringClass(): typeof Internal.VertexFormatElement$Usage
        static readonly GENERIC: (Internal.VertexFormatElement$Usage) & (Internal.VertexFormatElement$Usage);
        static readonly COLOR: (Internal.VertexFormatElement$Usage) & (Internal.VertexFormatElement$Usage);
        static readonly NORMAL: (Internal.VertexFormatElement$Usage) & (Internal.VertexFormatElement$Usage);
        static readonly UV: (Internal.VertexFormatElement$Usage) & (Internal.VertexFormatElement$Usage);
        static readonly POSITION: (Internal.VertexFormatElement$Usage) & (Internal.VertexFormatElement$Usage);
        static readonly PADDING: (Internal.VertexFormatElement$Usage) & (Internal.VertexFormatElement$Usage);
    }
    type VertexFormatElement$Usage_ = VertexFormatElement$Usage | "normal" | "color" | "generic" | "position" | "padding" | "uv";
    abstract class IotaType <T extends Internal.Iota> {
        constructor()
        getClass(): typeof any;
        typeName(): net.minecraft.network.chat.Component;
        static isTooLargeToSerialize(examinee: Internal.Iterable_<Internal.Iota>): boolean;
        toString(): string;
        notifyAll(): void;
        static getDisplayWithMaxWidth(tag: Internal.CompoundTag_, maxWidth: number, font: net.minecraft.client.gui.Font_): Internal.FormattedCharSequence;
        notify(): void;
        static serialize(iota: Internal.Iota_): Internal.CompoundTag;
        abstract display(arg0: Internal.Tag_): net.minecraft.network.chat.Component;
        wait(arg0: number, arg1: number): void;
        static getDisplay(tag: Internal.CompoundTag_): net.minecraft.network.chat.Component;
        abstract deserialize(arg0: Internal.Tag_, arg1: Internal.ServerLevel_): T;
        hashCode(): number;
        abstract color(): number;
        wait(): void;
        static "deserialize(net.minecraft.nbt.CompoundTag,net.minecraft.server.level.ServerLevel)"(tag: Internal.CompoundTag_, world: Internal.ServerLevel_): Internal.Iota;
        static deserialize(tag: Internal.CompoundTag_, world: Internal.ServerLevel_): Internal.Iota;
        wait(arg0: number): void;
        static getTypeFromTag(tag: Internal.CompoundTag_): Internal.IotaType<any>;
        abstract "deserialize(net.minecraft.nbt.Tag,net.minecraft.server.level.ServerLevel)"(arg0: Internal.Tag_, arg1: Internal.ServerLevel_): T;
        equals(arg0: any): boolean;
        static getColor(tag: Internal.CompoundTag_): number;
        get class(): typeof any
    }
    type IotaType_<T extends Internal.Iota> = IotaType<T> | Special.IotaType;
    class Collections$UnmodifiableMap <K, V> implements Internal.Map<K, V>, Internal.Serializable {
        computeIfAbsent(arg0: K, arg1: Internal.Function_<K, V>): V;
        getClass(): typeof any;
        replace(arg0: K, arg1: V): V;
        containsValue(arg0: any): boolean;
        computeIfPresent(arg0: K, arg1: Internal.BiFunction_<K, V, V>): V;
        static of<K, V>(): Internal.Map<K, V>;
        getOrDefault(arg0: any, arg1: V): V;
        isEmpty(): boolean;
        static entry<K, V>(arg0: K, arg1: V): Internal.Map$Entry<K, V>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        containsKey(arg0: any): boolean;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V): Internal.Map<K, V>;
        put(arg0: K, arg1: V): V;
        get(arg0: any): V;
        remove(arg0: any): V;
        static copyOf<K, V>(arg0: Internal.Map_<K, V>): Internal.Map<K, V>;
        merge(arg0: K, arg1: V, arg2: Internal.BiFunction_<V, V, V>): V;
        putIfAbsent(arg0: K, arg1: V): V;
        keySet(): Internal.Set<K>;
        forEach(arg0: Internal.BiConsumer_<K, V>): void;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V): Internal.Map<K, V>;
        toString(): string;
        values(): Internal.Collection<V>;
        entrySet(): Internal.Set<Internal.Map$Entry<K, V>>;
        compute(arg0: K, arg1: Internal.BiFunction_<K, V, V>): V;
        notifyAll(): void;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V): Internal.Map<K, V>;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V): Internal.Map<K, V>;
        remove(arg0: any, arg1: any): boolean;
        putAll(arg0: Internal.Map_<K, V>): void;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V): Internal.Map<K, V>;
        hashCode(): number;
        size(): number;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V): Internal.Map<K, V>;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V, arg16: K, arg17: V, arg18: K, arg19: V): Internal.Map<K, V>;
        static ofEntries<K, V>(...arg0: Internal.Map$Entry_<K, V>[]): Internal.Map<K, V>;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V, arg16: K, arg17: V): Internal.Map<K, V>;
        wait(): void;
        clear(): void;
        replace(arg0: K, arg1: V, arg2: V): boolean;
        wait(arg0: number): void;
        replaceAll(arg0: Internal.BiFunction_<K, V, V>): void;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V): Internal.Map<K, V>;
        equals(arg0: any): boolean;
        static of<K, V>(arg0: K, arg1: V): Internal.Map<K, V>;
        get class(): typeof any
        get empty(): boolean
    }
    type Collections$UnmodifiableMap_<K, V> = Collections$UnmodifiableMap<K, V>;
    class PancakeItem extends Internal.RecordItem {
        constructor(i: number, soundEvent: Internal.SoundEvent_, properties: Internal.Item$Properties_, seconds: number)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, level: Internal.Level_, tooltipComponents: Internal.List_<net.minecraft.network.chat.Component>, isAdvanced: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        static invokeConstructor$ecologics_$md$424943$0(arg0: number, arg1: Internal.SoundEvent_, arg2: Internal.Item$Properties_, arg3: number): Internal.RecordItem;
        getSound(): Internal.SoundEvent;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn(context: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getDisplayName(): Internal.MutableComponent;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        getLengthInTicks(): number;
        getAnalogOutput(): number;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        static invokeConstructor(analogOutput: number, soundEvent: Internal.SoundEvent_, properties: Internal.Item$Properties_, lengthInSeconds: number): Internal.RecordItem;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        static getBySound($$0: Internal.SoundEvent_): Internal.RecordItem;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        get sound(): Internal.SoundEvent
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get displayName(): Internal.MutableComponent
        get id(): string
        get lengthInTicks(): number
        get analogOutput(): number
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type PancakeItem_ = PancakeItem;
    class AnvilMenu extends Internal.ItemCombinerMenu implements Internal.AnvilScreenHandlerExtended {
        constructor($$0: number, $$1: Internal.Inventory_, $$2: Internal.ContainerLevelAccess_)
        constructor($$0: number, $$1: Internal.Inventory_)
        findSlot($$0: net.minecraft.world.Container_, $$1: number): Internal.OptionalInt;
        handler$boc000$bclib$bcl_updateOutput(info: Internal.CallbackInfo_): void;
        getItems(): Internal.NonNullList<Internal.ItemStack>;
        addSlot($$0: Internal.Slot_): Internal.Slot;
        owo$handlePacket(buf: Internal.FriendlyByteBuf_, clientbound: boolean): void;
        setItemName($$0: string): boolean;
        quickMoveStack($$0: Internal.Player_, $$1: number): Internal.ItemStack;
        gettype(): Internal.MenuType<any>;
        getTrackedStacks(): Internal.NonNullList<any>;
        setRemoteCarried($$0: Internal.ItemStack_): void;
        broadcastFullState(): void;
        notify(): void;
        player(): Internal.Player;
        incrementStateId(): number;
        isValidSlotIndex($$0: number): boolean;
        handler$hae000$gobber2$gobberCanTakeOutput(player: Internal.Player_, present: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        broadcastChanges(): void;
        sendMessage(message: Internal.Record_): void;
        createResult(): void;
        setData($$0: number, $$1: number): void;
        getSlot($$0: number): Internal.Slot;
        bcl_updateCurrentRecipe(recipe: Internal.AnvilRecipe_): void;
        owo$attachToPlayer(player: Internal.Player_): void;
        handler$nbd000$things$outputCheckOverride(player: Internal.Player_, present: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        slotsChanged($$0: net.minecraft.world.Container_): void;
        owo$readPropertySync(buf: Internal.FriendlyByteBuf_): void;
        handler$efl000$collective$onCreateAnvilResult(info: Internal.CallbackInfo_): void;
        things$getOutput(): Internal.ResultContainer;
        handler$hae000$gobber2$emeraldUpdateResult(ci: Internal.CallbackInfo_): void;
        bcl_getCurrentRecipe(): Internal.AnvilRecipe;
        removeSlotListener($$0: net.minecraft.world.inventory.ContainerListener_): void;
        getPreviousTrackedStacks(): Internal.NonNullList<any>;
        setRemoteSlot($$0: number, $$1: Internal.ItemStack_): void;
        createProperty(klass: typeof any, initial: any): Internal.SyncedProperty<any>;
        getCarried(): Internal.ItemStack;
        wait(): void;
        getType(): Internal.MenuType<any>;
        setSynchronizer($$0: Internal.ContainerSynchronizer_): void;
        static isValidQuickcraftType($$0: number, $$1: Internal.Player_): boolean;
        getClass(): typeof any;
        static getRedstoneSignalFromBlockEntity($$0: Internal.BlockEntity_): number;
        handler$lda000$puzzleslib$createResult(callback: Internal.CallbackInfo_): void;
        canTakeItemForPickAll($$0: Internal.ItemStack_, $$1: Internal.Slot_): boolean;
        static calculateIncreasedRepairCost($$0: number): number;
        things$getInput(): net.minecraft.world.Container;
        getOutput(): Internal.ResultContainer;
        setItem($$0: number, $$1: number, $$2: Internal.ItemStack_): void;
        hasSlots(): boolean;
        static getRedstoneSignalFromContainer($$0: net.minecraft.world.Container_): number;
        setCarried($$0: Internal.ItemStack_): void;
        sendAllDataToRemote(): void;
        static getQuickCraftPlaceCount($$0: Internal.Set_<Internal.Slot>, $$1: number, $$2: Internal.ItemStack_): number;
        wait(arg0: number, arg1: number): void;
        handler$boc000$bclib$bcl_setNewItemName(string: string, cir: Internal.CallbackInfoReturnable_<any>): void;
        bcl_getRecipes(): Internal.List<any>;
        getInventory(): net.minecraft.world.Container;
        addServerboundMessage(messageClass: typeof any, handler: Internal.Consumer_<any>): void;
        getCost(): number;
        getResultSlot(): number;
        resumeRemoteUpdates(): void;
        getInput(): net.minecraft.world.Container;
        handler$boc000$bclib$be_initAnvilLevel(syncId: number, inventory: Internal.Inventory_, context: Internal.ContainerLevelAccess_, info: Internal.CallbackInfo_): void;
        static getQuickcraftHeader($$0: number): number;
        owo$insertItem(arg0: Internal.ItemStack_, arg1: number, arg2: number, arg3: boolean): boolean;
        handler$nbd000$things$setOutput(ci: Internal.CallbackInfo_): void;
        static canItemQuickReplace($$0: Internal.Slot_, $$1: Internal.ItemStack_, $$2: boolean): boolean;
        addSlotListener($$0: net.minecraft.world.inventory.ContainerListener_): void;
        addClientboundMessage(messageClass: typeof any, handler: Internal.Consumer_<any>): void;
        getSlotToQuickMoveTo($$0: Internal.ItemStack_): number;
        toString(): string;
        clickMenuButton(player: Internal.Player_, id: number): boolean;
        static getQuickcraftMask($$0: number, $$1: number): number;
        notifyAll(): void;
        static getQuickcraftType($$0: number): number;
        handler$hhd000$inventorysorter$sortOnDoubleClickEmpty(slotIndex: number, button: number, actionType: Internal.ClickType_, player: Internal.Player_, ci: Internal.CallbackInfo_): void;
        setRemoteSlotNoCopy($$0: number, $$1: Internal.ItemStack_): void;
        clicked($$0: number, $$1: number, $$2: Internal.ClickType_, $$3: Internal.Player_): void;
        stillValid($$0: Internal.Player_): boolean;
        suppressRemoteUpdates(): void;
        hashCode(): number;
        initializeContents($$0: number, $$1: Internal.List_<Internal.ItemStack>, $$2: Internal.ItemStack_): void;
        getStateId(): number;
        be_nextRecipe(): void;
        wait(arg0: number): void;
        be_previousRecipe(): void;
        equals(arg0: any): boolean;
        transferState($$0: Internal.AbstractContainerMenu_): void;
        canDragTo($$0: Internal.Slot_): boolean;
        removed($$0: Internal.Player_): void;
        get items(): Internal.NonNullList<Internal.ItemStack>
        set itemName($$0: string)
        get type(): Internal.MenuType<any>
        get trackedStacks(): Internal.NonNullList<any>
        set remoteCarried($$0: Internal.ItemStack_)
        get previousTrackedStacks(): Internal.NonNullList<any>
        get carried(): Internal.ItemStack
        get type(): Internal.MenuType<any>
        set synchronizer($$0: Internal.ContainerSynchronizer_)
        get class(): typeof any
        get output(): Internal.ResultContainer
        set carried($$0: Internal.ItemStack_)
        get inventory(): net.minecraft.world.Container
        get cost(): number
        get resultSlot(): number
        get input(): net.minecraft.world.Container
        get stateId(): number
        static readonly INPUT_SLOT: (0) & (number);
        static readonly MAX_NAME_LENGTH: (50) & (number);
        static readonly RESULT_SLOT: (2) & (number);
        static readonly ADDITIONAL_SLOT: (1) & (number);
    }
    type AnvilMenu_ = AnvilMenu;
    class HexPattern {
        constructor(arg0: Internal.HexDir_, arg1: Internal.List_<any>, arg2: number, arg3: any_)
        constructor(startDir: Internal.HexDir_, angles: Internal.List_<Internal.HexAngle>)
        static fromNBT(tag: Internal.CompoundTag_): Internal.HexPattern;
        positions(start: Internal.HexCoord_): Internal.List<Internal.HexCoord>;
        getClass(): typeof any;
        component2(): Internal.List<Internal.HexAngle>;
        getCenter(hexRadius: number): Internal.Vec2;
        directions(): Internal.List<Internal.HexDir>;
        tryAppendDir(newDir: Internal.HexDir_): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        anglesSignature(): string;
        serializeToNBT(): Internal.CompoundTag;
        getAngles(): Internal.List<Internal.HexAngle>;
        toString(): string;
        positions(): Internal.List<Internal.HexCoord>;
        static positions$default(arg0: Internal.HexPattern_, arg1: Internal.HexCoord_, arg2: number, arg3: any): Internal.List<any>;
        notifyAll(): void;
        static copy$default(arg0: Internal.HexPattern_, arg1: Internal.HexDir_, arg2: Internal.List_<any>, arg3: number, arg4: any): Internal.HexPattern;
        component1(): Internal.HexDir;
        static isPattern(tag: Internal.CompoundTag_): boolean;
        getCenter(hexRadius: number, origin: Internal.HexCoord_): Internal.Vec2;
        hashCode(): number;
        getStartDir(): Internal.HexDir;
        static getCenter$default(arg0: Internal.HexPattern_, arg1: number, arg2: Internal.HexCoord_, arg3: number, arg4: any): Internal.Vec2;
        wait(): void;
        wait(arg0: number): void;
        toLines(hexSize: number, origin: Internal.Vec2_): Internal.List<Internal.Vec2>;
        sigsEqual(that: Internal.HexPattern_): boolean;
        equals(other: any): boolean;
        copy(startDir: Internal.HexDir_, angles: Internal.List_<Internal.HexAngle>): this;
        static fromAngles(signature: string, startDir: Internal.HexDir_): Internal.HexPattern;
        finalDir(): Internal.HexDir;
        get class(): typeof any
        get angles(): Internal.List<Internal.HexAngle>
        get startDir(): Internal.HexDir
        static readonly TAG_ANGLES: ("angles") & (string);
        static readonly TAG_START_DIR: ("start_dir") & (string);
        static readonly Companion: (Internal.HexPattern$Companion) & (Internal.HexPattern$Companion);
        static readonly CODEC: Internal.Codec<Internal.HexPattern>;
    }
    type HexPattern_ = HexPattern;
    abstract class PrintJob {
        getClass(): typeof any;
        toString(): string;
        abstract getGraphics(): Internal.Graphics;
        notifyAll(): void;
        abstract lastPageFirst(): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        abstract getPageResolution(): number;
        hashCode(): number;
        abstract end(): void;
        wait(): void;
        abstract getPageDimension(): Internal.Dimension;
        wait(arg0: number): void;
        /**
         * @deprecated
        */
        finalize(): void;
        equals(arg0: any): boolean;
        get class(): typeof any
        get graphics(): Internal.Graphics
        get pageResolution(): number
        get pageDimension(): Internal.Dimension
    }
    type PrintJob_ = PrintJob;
    /**
     * @deprecated
    */
    interface FabricLootSupplier {
        asVanilla(): Internal.LootTable;
        abstract getPools(): Internal.List<Internal.LootPool>;
        abstract getFunctions(): Internal.List<Internal.LootItemFunction>;
        getType(): Internal.LootContextParamSet;
        get pools(): Internal.List<Internal.LootPool>
        get functions(): Internal.List<Internal.LootItemFunction>
        get type(): Internal.LootContextParamSet
    }
    type FabricLootSupplier_ = FabricLootSupplier;
    abstract class AbstractInt2ObjectFunction <V> implements Internal.Int2ObjectFunction<V>, Internal.Serializable {
        composeLong(arg0: Internal.Long2IntFunction_): Internal.Long2ObjectFunction<V>;
        abstract "get(int)"(arg0: number): V;
        put(arg0: number, arg1: V): V;
        containsKey(arg0: number): boolean;
        notify(): void;
        /**
         * @deprecated
        */
        "put(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): any;
        andThenByte(arg0: Internal.Object2ByteFunction_<V>): Internal.Int2ByteFunction;
        /**
         * @deprecated
        */
        get(arg0: any): V;
        apply(arg0: number): V;
        /**
         * @deprecated
        */
        put(arg0: any, arg1: any): any;
        apply(arg0: number): V;
        composeByte(arg0: Internal.Byte2IntFunction_): Internal.Byte2ObjectFunction<V>;
        andThenDouble(arg0: Internal.Object2DoubleFunction_<V>): Internal.Int2DoubleFunction;
        andThenInt(arg0: Internal.Object2IntFunction_<V>): Internal.Int2IntFunction;
        composeObject<T>(arg0: Internal.Object2IntFunction_<T>): Internal.Object2ObjectFunction<T, V>;
        remove(arg0: number): V;
        "getOrDefault(int,java.lang.Object)"(arg0: number, arg1: V): V;
        getOrDefault(arg0: number, arg1: V): V;
        andThenFloat(arg0: Internal.Object2FloatFunction_<V>): Internal.Int2FloatFunction;
        andThenObject<T>(arg0: Internal.Object2ObjectFunction_<V, T>): Internal.Int2ObjectFunction<T>;
        "containsKey(int)"(arg0: number): boolean;
        composeDouble(arg0: Internal.Double2IntFunction_): Internal.Double2ObjectFunction<V>;
        composeChar(arg0: Internal.Char2IntFunction_): Internal.Char2ObjectFunction<V>;
        wait(): void;
        defaultReturnValue(): V;
        static identity<T>(): Internal.Function<T, T>;
        defaultReturnValue(arg0: V): void;
        composeFloat(arg0: Internal.Float2IntFunction_): Internal.Float2ObjectFunction<V>;
        "put(int,java.lang.Object)"(arg0: number, arg1: V): V;
        /**
         * @deprecated
        */
        "containsKey(java.lang.Object)"(arg0: any): boolean;
        getClass(): typeof any;
        andThen<V>(arg0: Internal.Function_<V, V>): Internal.Function<number, V>;
        andThenChar(arg0: Internal.Object2CharFunction_<V>): Internal.Int2CharFunction;
        /**
         * @deprecated
        */
        "getOrDefault(java.lang.Object,java.lang.Object)"(arg0: any, arg1: V): V;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: V): V;
        wait(arg0: number, arg1: number): void;
        composeReference<T>(arg0: Internal.Reference2IntFunction_<T>): Internal.Reference2ObjectFunction<T, V>;
        abstract get(arg0: number): V;
        /**
         * @deprecated
        */
        containsKey(arg0: any): boolean;
        /**
         * @deprecated
        */
        put(arg0: number, arg1: V): V;
        andThenReference<T>(arg0: Internal.Object2ReferenceFunction_<V, T>): Internal.Int2ReferenceFunction<T>;
        /**
         * @deprecated
        */
        "get(java.lang.Object)"(arg0: any): V;
        /**
         * @deprecated
        */
        "put(java.lang.Integer,java.lang.Object)"(arg0: number, arg1: V): V;
        /**
         * @deprecated
        */
        remove(arg0: any): V;
        "remove(int)"(arg0: number): V;
        toString(): string;
        composeInt(arg0: Internal.Int2IntFunction_): Internal.Int2ObjectFunction<V>;
        notifyAll(): void;
        andThenShort(arg0: Internal.Object2ShortFunction_<V>): Internal.Int2ShortFunction;
        composeShort(arg0: Internal.Short2IntFunction_): Internal.Short2ObjectFunction<V>;
        andThenLong(arg0: Internal.Object2LongFunction_<V>): Internal.Int2LongFunction;
        hashCode(): number;
        size(): number;
        clear(): void;
        "apply(java.lang.Integer)"(arg0: number): V;
        wait(arg0: number): void;
        "apply(int)"(arg0: number): V;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        compose<T>(arg0: Internal.Function_<T, number>): Internal.Function<T, V>;
        /**
         * @deprecated
        */
        "remove(java.lang.Object)"(arg0: any): V;
        get class(): typeof any
    }
    type AbstractInt2ObjectFunction_<V> = AbstractInt2ObjectFunction<V>;
    class LavaDeltaFeature extends Internal.VegetationPatchFeature {
        constructor(p_160635_: Internal.Codec_<Internal.VegetationPatchConfiguration>)
        getClass(): typeof any;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        place($$0: Internal.VegetationPatchConfiguration_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        place($$0: Internal.FeaturePlaceContext_<Internal.VegetationPatchConfiguration>): boolean;
        wait(): void;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.VegetationPatchConfiguration, Feature<Internal.VegetationPatchConfiguration>>>;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        get class(): typeof any
    }
    type LavaDeltaFeature_ = LavaDeltaFeature;
    class LunchBoxItem extends Internal.SelectableContainerItem<Internal.LunchBoxItem$Data> implements Internal.ILeftClickReact, Internal.ICustomItemRendererProvider {
        constructor(properties: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed(pItemEntity: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(pStack: Internal.ItemStack_, level: Internal.Level_, list: Internal.List_<net.minecraft.network.chat.Component>, pIsAdvanced: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        static findActiveLunchBox(entity: Internal.LivingEntity_): Internal.ItemStack;
        getUseAnimation(stack: Internal.ItemStack_): Internal.UseAnim;
        getDescriptionId(): string;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        abstract asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getFoodProperties(stack: Internal.ItemStack_, entity: Internal.LivingEntity_): Internal.FoodProperties;
        getMaxSlots(): number;
        getBarWidth(pStack: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor(pStack: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        getData(arg0: Internal.ItemStack_): Internal.SelectableContainerItem$AbstractData;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage(pStack: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(pLevel: Internal.Level_, player: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther(quiver: Internal.ItemStack_, pSlot: Internal.Slot_, pAction: Internal.ClickAction_, pPlayer: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock(state: Internal.BlockState_, level: Internal.Level_, pos: BlockPos_, player: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing(stack: Internal.ItemStack_, level: Internal.Level_, livingEntity: Internal.LivingEntity_, timeCharged: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible(pStack: Internal.ItemStack_): boolean;
        getUseDuration(stack: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem(stack: Internal.ItemStack_, level: Internal.Level_, livingEntity: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        registerFabricRenderer(): void;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        static getLunchBoxData(stack: Internal.ItemStack_): Internal.LunchBoxItem$Data;
        onLeftClick(stack: Internal.ItemStack_, player: Internal.Player_, hand: Internal.InteractionHand_): boolean;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getRendererFactory(): Internal.Supplier<Internal.ItemStackRenderer>;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        static canAcceptItem(toInsert: Internal.ItemStack_): boolean;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick(stack: Internal.ItemStack_, level: Internal.Level_, entity: Internal.Entity_, slotId: number, isSelected: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        static findActiveLunchBoxSlot(entity: Internal.LivingEntity_): Internal.SlotReference;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe(quiver: Internal.ItemStack_, pOther: Internal.ItemStack_, pSlot: Internal.Slot_, pAction: Internal.ClickAction_, pPlayer: Internal.Player_, pAccess: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        get maxSlots(): number
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get rendererFactory(): Internal.Supplier<Internal.ItemStackRenderer>
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type LunchBoxItem_ = LunchBoxItem;
    class BlockPattern {
        constructor($$0: Internal.Predicate_<Internal.BlockInWorld>[][][])
        getClass(): typeof any;
        getDepth(): number;
        toString(): string;
        getWidth(): number;
        matches($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.Direction_): Internal.BlockPattern$BlockPatternMatch;
        notifyAll(): void;
        static createLevelCache($$0: Internal.LevelReader_, $$1: boolean): Internal.LoadingCache<BlockPos, Internal.BlockInWorld>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        getPattern(): Internal.Predicate<Internal.BlockInWorld>[][][];
        wait(): void;
        wait(arg0: number): void;
        getHeight(): number;
        equals(arg0: any): boolean;
        find($$0: Internal.LevelReader_, $$1: BlockPos_): Internal.BlockPattern$BlockPatternMatch;
        get class(): typeof any
        get depth(): number
        get width(): number
        get pattern(): Internal.Predicate<Internal.BlockInWorld>[][][]
        get height(): number
    }
    type BlockPattern_ = BlockPattern;
    class GrotestqueStewItem extends Internal.Item {
        constructor(settings: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem(stack: Internal.ItemStack_, world: Internal.Level_, user: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type GrotestqueStewItem_ = GrotestqueStewItem;
    class EnsouledGemItem extends Internal.IgnitedGemItem {
        constructor(settings: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        giveTooltipHint(nbt: Internal.CompoundTag_, stack: Internal.ItemStack_, tooltip: Internal.List_<net.minecraft.network.chat.Component>): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        getModifier(): ResourceLocation;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        ensouledGemCheck(stack: Internal.ItemStack_, inventory: Internal.Inventory_, player: Internal.LivingEntity_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        get modifier(): ResourceLocation
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type EnsouledGemItem_ = EnsouledGemItem;
    interface CollisionGetter extends Internal.BlockGetter {
        noCollision($$0: Internal.Entity_): boolean;
        getMinSection(): number;
        findFreePosition($$0: Internal.Entity_, $$1: Internal.VoxelShape_, $$2: Vec3d_, $$3: number, $$4: number, $$5: number): Optional<Vec3d>;
        abstract getBlockState(arg0: BlockPos_): Internal.BlockState;
        isUnobstructed($$0: Internal.Entity_, $$1: Internal.VoxelShape_): boolean;
        clipWithInteractionOverride($$0: Vec3d_, $$1: Vec3d_, $$2: BlockPos_, $$3: Internal.VoxelShape_, $$4: Internal.BlockState_): Internal.BlockHitResult;
        getSectionIndex($$0: number): number;
        getMaxSection(): number;
        getMaxBuildHeight(): number;
        getBlockEntityRenderData(pos: BlockPos_): any;
        getBiomeFabric(pos: BlockPos_): Internal.Holder<Internal.Biome>;
        getLightEmission($$0: BlockPos_): number;
        getBlockFloorHeight($$0: BlockPos_): number;
        getSectionYFromSectionIndex($$0: number): number;
        noCollision($$0: Internal.AABB_): boolean;
        create($$0: number, $$1: number): Internal.LevelHeightAccessor;
        "isOutsideBuildHeight(int)"($$0: number): boolean;
        getCollisions($$0: Internal.Entity_, $$1: Internal.AABB_): Internal.Iterable<Internal.VoxelShape>;
        clip($$0: Internal.ClipContext_): Internal.BlockHitResult;
        abstract getEntityCollisions(arg0: Internal.Entity_, arg1: Internal.AABB_): Internal.List<Internal.VoxelShape>;
        getBlockFloorHeight($$0: Internal.VoxelShape_, $$1: Internal.Supplier_<Internal.VoxelShape>): number;
        collidesWithSuffocatingBlock($$0: Internal.Entity_, $$1: Internal.AABB_): boolean;
        getBlockCollisions($$0: Internal.Entity_, $$1: Internal.AABB_): Internal.Iterable<Internal.VoxelShape>;
        abstract getBlockEntity(arg0: BlockPos_): Internal.BlockEntity;
        abstract getHeight(): number;
        getBlockEntity<T extends Internal.BlockEntity>($$0: BlockPos_, $$1: Internal.BlockEntityType_<T>): Optional<T>;
        isOutsideBuildHeight($$0: BlockPos_): boolean;
        noCollision($$0: Internal.Entity_, $$1: Internal.AABB_): boolean;
        abstract getWorldBorder(): Internal.WorldBorder;
        isOutsideBuildHeight($$0: number): boolean;
        isUnobstructed($$0: Internal.BlockState_, $$1: BlockPos_, $$2: Internal.CollisionContext_): boolean;
        isUnobstructed($$0: Internal.Entity_): boolean;
        isBlockInLine($$0: Internal.ClipBlockStateContext_): Internal.BlockHitResult;
        abstract getFluidState(arg0: BlockPos_): Internal.FluidState;
        "isOutsideBuildHeight(net.minecraft.core.BlockPos)"($$0: BlockPos_): boolean;
        findSupportingBlock($$0: Internal.Entity_, $$1: Internal.AABB_): Optional<BlockPos>;
        getBlockStates($$0: Internal.AABB_): Internal.Stream<Internal.BlockState>;
        getSectionsCount(): number;
        abstract getMinBuildHeight(): number;
        "noCollision(net.minecraft.world.phys.AABB)"($$0: Internal.AABB_): boolean;
        abstract getChunkForCollisions(arg0: number, arg1: number): Internal.BlockGetter;
        "noCollision(net.minecraft.world.entity.Entity)"($$0: Internal.Entity_): boolean;
        hasBiomes(): boolean;
        getMaxLightLevel(): number;
        getSectionIndexFromSectionY($$0: number): number;
        traverseBlocks<T, C>($$0: Vec3d_, $$1: Vec3d_, $$2: C, $$3: Internal.BiFunction_<C, BlockPos, T>, $$4: Internal.Function_<C, T>): T;
        get minSection(): number
        get maxSection(): number
        get maxBuildHeight(): number
        get height(): number
        get worldBorder(): Internal.WorldBorder
        get sectionsCount(): number
        get minBuildHeight(): number
        get maxLightLevel(): number
    }
    type CollisionGetter_ = CollisionGetter;
}
declare namespace vazkii.botania.common.crafting {
    class ElvenTradeRecipe implements Internal.ElvenTradeRecipe {
        constructor(id: ResourceLocation_, outputs: Internal.ItemStack_[], ...inputs: Internal.Ingredient_[])
        getClass(): typeof any;
        getGroup(): string;
        getToastSymbol(): Internal.ItemStack;
        getSchema(): Internal.RecipeSchema;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getSerializer(): Internal.RecipeSerializer<any>;
        assemble(inv: net.minecraft.world.Container_, registries: Internal.RegistryAccess_): Internal.ItemStack;
        isReturnRecipe(): boolean;
        getId(): ResourceLocation;
        match(stacks: Internal.List_<Internal.ItemStack>): Optional<Internal.List<Internal.ItemStack>>;
        matches(inv: net.minecraft.world.Container_, world: Internal.Level_): boolean;
        getMod(): string;
        isIn(tag: ResourceLocation_): boolean;
        getRemainingItems($$0: net.minecraft.world.Container_): Internal.NonNullList<Internal.ItemStack>;
        getIngredients(): Internal.NonNullList<Internal.Ingredient>;
        handler$bpa000$bclib$bcl_getRemainingItems(container: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>): void;
        isSpecial(): boolean;
        hasOutput(match: Internal.ReplacementMatch_): boolean;
        getResultItem(registries: Internal.RegistryAccess_): Internal.ItemStack;
        toString(): string;
        notifyAll(): void;
        getOutputs(): Internal.List<Internal.ItemStack>;
        getOutputs(inputs: Internal.List_<Internal.ItemStack>): Internal.List<Internal.ItemStack>;
        canCraftInDimensions(width: number, height: number): boolean;
        showNotification(): boolean;
        replaceInput(match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): boolean;
        getType(): ResourceLocation;
        setGroup(group: string): void;
        hashCode(): number;
        "handler$fie000$fabric-item-api-v1$captureStack"(inventory: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>, defaultedList: Internal.NonNullList_<any>, i: number): void;
        getOrCreateId(): ResourceLocation;
        hasInput(match: Internal.ReplacementMatch_): boolean;
        wait(): void;
        isIncomplete(): boolean;
        wait(arg0: number): void;
        replaceOutput(match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): boolean;
        containsItem(stack: Internal.ItemStack_): boolean;
        equals(arg0: any): boolean;
        get class(): typeof any
        get group(): string
        get toastSymbol(): Internal.ItemStack
        get schema(): Internal.RecipeSchema
        get serializer(): Internal.RecipeSerializer<any>
        get returnRecipe(): boolean
        get id(): ResourceLocation
        get mod(): string
        get ingredients(): Internal.NonNullList<Internal.Ingredient>
        get special(): boolean
        get outputs(): Internal.List<Internal.ItemStack>
        get type(): ResourceLocation
        set group(group: string)
        get orCreateId(): ResourceLocation
        get incomplete(): boolean
    }
    type ElvenTradeRecipe_ = ElvenTradeRecipe;
}
declare namespace io.github.thecsdev.tcdcommons.client.mixin.hooks {
    interface AccessorScreen {
        abstract tcdcommons_addDrawableChild<T extends Internal.GuiEventListener & Internal.Renderable & Internal.NarratableEntry>(arg0: T): T;
        abstract tcdcommons_addSelectableChild<T extends Internal.GuiEventListener & Internal.NarratableEntry>(arg0: T): T;
        abstract tcdcommons_remove(arg0: Internal.GuiEventListener_): void;
        abstract tcdcommons_children(): Internal.List<Internal.GuiEventListener>;
        abstract tcdcommons_addDrawable<T extends Internal.Renderable>(arg0: T): T;
        abstract tcdcommons_clearChildren(): void;
    }
    type AccessorScreen_ = AccessorScreen;
}
declare namespace snownee.jade.api {
    interface BlockAccessor extends Internal.Accessor<Internal.BlockHitResult> {
        abstract getPosition(): BlockPos;
        abstract getBlockState(): Internal.BlockState;
        abstract getServerData(): Internal.CompoundTag;
        getAccessorType(): Internal.Accessor<any>;
        abstract toNetwork(arg0: Internal.FriendlyByteBuf_): void;
        abstract showDetails(): boolean;
        abstract getLevel(): Internal.Level;
        abstract getBlockEntity(): Internal.BlockEntity;
        abstract isFakeBlock(): boolean;
        abstract verifyData(arg0: Internal.CompoundTag_): boolean;
        abstract isServerConnected(): boolean;
        abstract getFakeBlock(): Internal.ItemStack;
        abstract getHitResult(): Internal.BlockHitResult;
        abstract getPlayer(): Internal.Player;
        abstract getTarget(): any;
        abstract getSide(): Internal.Direction;
        abstract getBlock(): Internal.Block;
        abstract getPickedResult(): Internal.ItemStack;
        get position(): BlockPos
        get blockState(): Internal.BlockState
        get serverData(): Internal.CompoundTag
        get accessorType(): Internal.Accessor<any>
        get level(): Internal.Level
        get blockEntity(): Internal.BlockEntity
        get fakeBlock(): boolean
        get serverConnected(): boolean
        get fakeBlock(): Internal.ItemStack
        get hitResult(): Internal.BlockHitResult
        get player(): Internal.Player
        get target(): any
        get side(): Internal.Direction
        get block(): Internal.Block
        get pickedResult(): Internal.ItemStack
    }
    type BlockAccessor_ = BlockAccessor;
}
declare namespace com.yungnickyoung.minecraft.betterwitchhuts.mixin.accessor {
    interface StructureProcessorAccessor {
        abstract callGetType(): Internal.StructureProcessorType<any>;
        (): Internal.StructureProcessorType_<any>;
    }
    type StructureProcessorAccessor_ = (()=> Internal.StructureProcessorType_<any>) | StructureProcessorAccessor;
}
