/// <reference path="./internal_*.d.ts" />
declare namespace dev.architectury.event {
    class EventResult {
        getClass(): typeof any;
        toString(): string;
        isTrue(): boolean;
        static interruptDefault(): dev.architectury.event.EventResult;
        asMinecraft(): Internal.InteractionResult;
        notifyAll(): void;
        static interruptTrue(): dev.architectury.event.EventResult;
        interruptsFurtherEvaluation(): boolean;
        isFalse(): boolean;
        static interruptFalse(): dev.architectury.event.EventResult;
        isEmpty(): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        static interrupt(value: boolean): dev.architectury.event.EventResult;
        hashCode(): number;
        isPresent(): boolean;
        wait(): void;
        wait(arg0: number): void;
        value(): boolean;
        static pass(): dev.architectury.event.EventResult;
        equals(arg0: any): boolean;
        get class(): typeof any
        get "true"(): boolean
        get "false"(): boolean
        get empty(): boolean
        get present(): boolean
    }
    type EventResult_ = EventResult;
}
declare namespace com.illusivesoulworks.polymorph.mixin.core {
    interface AccessorSmithingTrimRecipe {
        abstract getTemplate(): Internal.Ingredient;
        abstract getBase(): Internal.Ingredient;
        abstract getAddition(): Internal.Ingredient;
        get template(): Internal.Ingredient
        get base(): Internal.Ingredient
        get addition(): Internal.Ingredient
    }
    type AccessorSmithingTrimRecipe_ = AccessorSmithingTrimRecipe;
}
declare namespace com.google.common.base {
    interface Supplier <T> extends Internal.Supplier<T> {
        abstract get(): T;
        (): T;
    }
    type Supplier_<T> = Supplier<T> | (()=> T);
}
declare namespace Internal {
    class SimpleFoiledItem extends Internal.Item {
        constructor($$0: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type SimpleFoiledItem_ = SimpleFoiledItem;
    class TabStop implements Internal.Serializable {
        constructor(arg0: number)
        constructor(arg0: number, arg1: number, arg2: number)
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        getPosition(): number;
        equals(arg0: any): boolean;
        getLeader(): number;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getAlignment(): number;
        get class(): typeof any
        get position(): number
        get leader(): number
        get alignment(): number
        static readonly ALIGN_RIGHT: (1) & (number);
        static readonly ALIGN_CENTER: (2) & (number);
        static readonly LEAD_NONE: (0) & (number);
        static readonly LEAD_EQUALS: (5) & (number);
        static readonly ALIGN_DECIMAL: (4) & (number);
        static readonly ALIGN_LEFT: (0) & (number);
        static readonly LEAD_DOTS: (1) & (number);
        static readonly ALIGN_BAR: (5) & (number);
        static readonly LEAD_HYPHENS: (2) & (number);
        static readonly LEAD_THICKLINE: (4) & (number);
        static readonly LEAD_UNDERLINE: (3) & (number);
    }
    type TabStop_ = TabStop;
    interface CloseableScissors extends Internal.Closeable {
        abstract close(): void;
        (): void;
    }
    type CloseableScissors_ = CloseableScissors | (()=> void);
    class ClientboundSetScorePacket implements Internal.Packet<Internal.ClientGamePacketListener> {
        constructor($$0: Internal.ServerScoreboard$Method_, $$1: string, $$2: string, $$3: number)
        constructor($$0: Internal.FriendlyByteBuf_)
        handle(arg0: Internal.PacketListener_): void;
        getClass(): typeof any;
        write($$0: Internal.FriendlyByteBuf_): void;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        isSkippable(): boolean;
        wait(arg0: number, arg1: number): void;
        getOwner(): string;
        hashCode(): number;
        getScore(): number;
        wait(): void;
        handle($$0: Internal.ClientGamePacketListener_): void;
        wait(arg0: number): void;
        "handle(net.minecraft.network.protocol.game.ClientGamePacketListener)"($$0: Internal.ClientGamePacketListener_): void;
        equals(arg0: any): boolean;
        "handle(net.minecraft.network.PacketListener)"(arg0: Internal.PacketListener_): void;
        getMethod(): Internal.ServerScoreboard$Method;
        getObjectiveName(): string;
        get class(): typeof any
        get skippable(): boolean
        get owner(): string
        get score(): number
        get method(): Internal.ServerScoreboard$Method
        get objectiveName(): string
    }
    type ClientboundSetScorePacket_ = ClientboundSetScorePacket;
    interface ColorResolver {
        abstract getColor(arg0: Internal.Biome_, arg1: number, arg2: number): number;
        (arg0: Internal.Biome, arg1: number, arg2: number): number;
    }
    type ColorResolver_ = ColorResolver | ((arg0: Internal.Biome, arg1: number, arg2: number)=> number);
    interface ChannelHandlerContext extends Internal.ChannelOutboundInvoker, io.netty.util.AttributeMap, Internal.ChannelInboundInvoker {
        abstract connect(arg0: Internal.SocketAddress_, arg1: Internal.SocketAddress_, arg2: Internal.ChannelPromise_): Internal.ChannelFuture;
        abstract pipeline(): Internal.ChannelPipeline;
        abstract deregister(arg0: Internal.ChannelPromise_): Internal.ChannelFuture;
        abstract fireChannelReadComplete(): this;
        abstract executor(): Internal.EventExecutor;
        /**
         * @deprecated
        */
        abstract attr<T>(arg0: Internal.AttributeKey_<T>): io.netty.util.Attribute<T>;
        abstract write(arg0: any): Internal.ChannelFuture;
        abstract writeAndFlush(arg0: any): Internal.ChannelFuture;
        abstract disconnect(): Internal.ChannelFuture;
        abstract isRemoved(): boolean;
        abstract close(): Internal.ChannelFuture;
        abstract write(arg0: any, arg1: Internal.ChannelPromise_): Internal.ChannelFuture;
        abstract connect(arg0: Internal.SocketAddress_): Internal.ChannelFuture;
        abstract connect(arg0: Internal.SocketAddress_, arg1: Internal.SocketAddress_): Internal.ChannelFuture;
        abstract deregister(): Internal.ChannelFuture;
        abstract fireChannelRegistered(): this;
        abstract fireChannelInactive(): this;
        abstract disconnect(arg0: Internal.ChannelPromise_): Internal.ChannelFuture;
        abstract "connect(java.net.SocketAddress,io.netty.channel.ChannelPromise)"(arg0: Internal.SocketAddress_, arg1: Internal.ChannelPromise_): Internal.ChannelFuture;
        abstract read(): this;
        abstract handler(): Internal.ChannelHandler;
        abstract newFailedFuture(arg0: Internal.Throwable_): Internal.ChannelFuture;
        abstract alloc(): Internal.ByteBufAllocator;
        abstract close(arg0: Internal.ChannelPromise_): Internal.ChannelFuture;
        abstract newSucceededFuture(): Internal.ChannelFuture;
        abstract fireExceptionCaught(arg0: Internal.Throwable_): this;
        abstract newProgressivePromise(): Internal.ChannelProgressivePromise;
        abstract "connect(java.net.SocketAddress,java.net.SocketAddress)"(arg0: Internal.SocketAddress_, arg1: Internal.SocketAddress_): Internal.ChannelFuture;
        abstract fireChannelUnregistered(): this;
        abstract flush(): this;
        abstract name(): string;
        abstract channel(): io.netty.channel.Channel;
        abstract bind(arg0: Internal.SocketAddress_, arg1: Internal.ChannelPromise_): Internal.ChannelFuture;
        abstract writeAndFlush(arg0: any, arg1: Internal.ChannelPromise_): Internal.ChannelFuture;
        abstract bind(arg0: Internal.SocketAddress_): Internal.ChannelFuture;
        abstract fireChannelRead(arg0: any): this;
        abstract connect(arg0: Internal.SocketAddress_, arg1: Internal.ChannelPromise_): Internal.ChannelFuture;
        abstract fireUserEventTriggered(arg0: any): this;
        abstract fireChannelWritabilityChanged(): this;
        /**
         * @deprecated
        */
        abstract hasAttr<T>(arg0: Internal.AttributeKey_<T>): boolean;
        abstract voidPromise(): Internal.ChannelPromise;
        abstract fireChannelActive(): this;
        abstract newPromise(): Internal.ChannelPromise;
        get removed(): boolean
    }
    type ChannelHandlerContext_ = ChannelHandlerContext;
    class TrunkVineDecorator extends Internal.TreeDecorator {
        constructor()
        place($$0: Internal.TreeDecorator$Context_): void;
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        static readonly CODEC: Internal.Codec<Internal.TrunkVineDecorator>;
        static readonly INSTANCE: (Internal.TrunkVineDecorator) & (Internal.TrunkVineDecorator);
    }
    type TrunkVineDecorator_ = TrunkVineDecorator;
    class SurfaceRuleBuilder {
        getClass(): typeof any;
        aboveCeil(state: Internal.BlockState_, height: number): this;
        chancedFloor(surfaceBlockA: Internal.BlockState_, surfaceBlockB: Internal.BlockState_): this;
        build(): Internal.SurfaceRules$RuleSource;
        chancedFloor(surfaceBlockA: Internal.BlockState_, surfaceBlockB: Internal.BlockState_, noise: Internal.NoiseCondition_): this;
        filler(state: Internal.BlockState_): this;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        "biome(net.minecraft.world.level.biome.Biome)"(biome: Internal.Biome_): this;
        belowFloor(state: Internal.BlockState_, height: number, noise: Internal.NoiseCondition_): this;
        rule(rule: Internal.SurfaceRules$RuleSource_): this;
        floor(state: Internal.BlockState_): this;
        toString(): string;
        chancedFloor(surfaceBlockA: Internal.BlockState_, surfaceBlockB: Internal.SurfaceRules$RuleSource_, noise: Internal.NoiseCondition_): this;
        biome(biome: Internal.Biome_): this;
        subsurface(state: Internal.BlockState_, depth: number): this;
        belowFloor(state: Internal.BlockState_, height: number): this;
        steep(state: Internal.BlockState_, depth: number): this;
        notifyAll(): void;
        "chancedFloor(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.levelgen.SurfaceRules$RuleSource,org.betterx.bclib.api.v2.levelgen.surface.rules.NoiseCondition)"(surfaceBlockA: Internal.BlockState_, surfaceBlockB: Internal.SurfaceRules$RuleSource_, noise: Internal.NoiseCondition_): this;
        rule(priority: number, rule: Internal.SurfaceRules$RuleSource_): this;
        hashCode(): number;
        "biome(net.minecraft.resources.ResourceKey)"(biomeKey: Internal.ResourceKey_<Internal.Biome>): this;
        surface(state: Internal.BlockState_): this;
        "chancedFloor(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.block.state.BlockState,org.betterx.bclib.api.v2.levelgen.surface.rules.NoiseCondition)"(surfaceBlockA: Internal.BlockState_, surfaceBlockB: Internal.BlockState_, noise: Internal.NoiseCondition_): this;
        wait(): void;
        wait(arg0: number): void;
        biome(biomeKey: Internal.ResourceKey_<Internal.Biome>): this;
        static start(): Internal.SurfaceRuleBuilder;
        equals(arg0: any): boolean;
        ceil(state: Internal.BlockState_): this;
        get class(): typeof any
    }
    type SurfaceRuleBuilder_ = SurfaceRuleBuilder;
    interface PositionTracker {
        abstract isVisibleBy(arg0: Internal.LivingEntity_): boolean;
        abstract currentBlockPosition(): BlockPos;
        abstract currentPosition(): Vec3d;
    }
    type PositionTracker_ = PositionTracker;
    class Curse$Type extends Internal.Enum<Internal.Curse$Type> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        toString(): string;
        static values(): Internal.Curse$Type[];
        notifyAll(): void;
        compareTo(arg0: Internal.Curse$Type_): number;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.Curse$Type>>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        static valueOf(name: string): Internal.Curse$Type;
        compareTo(arg0: any): number;
        name(): string;
        getDeclaringClass(): typeof Internal.Curse$Type;
        hashCode(): number;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        "compareTo(moriyashiine.bewitchment.api.registry.Curse$Type)"(arg0: Internal.Curse$Type_): number;
        get class(): typeof any
        get declaringClass(): typeof Internal.Curse$Type
        static readonly GREATER: (Internal.Curse$Type) & (Internal.Curse$Type);
        static readonly LESSER: (Internal.Curse$Type) & (Internal.Curse$Type);
    }
    type Curse$Type_ = Curse$Type | "lesser" | "greater";
    class SectionStorage <R> implements com.ishland.c2me.base.mixin.access.ISerializingRegionBasedStorage, Internal.AutoCloseable, Internal.RegionBasedStorageSectionExtended<any>, Internal.ISerializingRegionBasedStorage {
        constructor($$0: Internal.Path_, $$1: Internal.Function_<Internal.Runnable, Internal.Codec<R>>, $$2: Internal.Function_<Internal.Runnable, R>, $$3: Internal.DataFixer_, $$4: any_, $$5: boolean, $$6: Internal.RegistryAccess_, $$7: Internal.LevelHeightAccessor_)
        getClass(): typeof any;
        toString(): string;
        flush($$0: Internal.ChunkPos_): void;
        notifyAll(): void;
        update(pos: Internal.ChunkPos_, tag: Internal.CompoundTag_): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        wait(): void;
        close(): void;
        wait(arg0: number): void;
        getInChunkColumn(chunkX: number, chunkZ: number): Internal.Iterable<any>;
        getWithinChunkColumn(chunkX: number, chunkZ: number): Internal.Stream<any>;
        equals(arg0: any): boolean;
        getWorker(): Internal.IOWorker;
        hasWork(): boolean;
        get class(): typeof any
        get worker(): Internal.IOWorker
    }
    type SectionStorage_<R> = SectionStorage<R>;
    class TextColor implements Internal.IColor, dev.latvian.mods.rhino.mod.util.color.Color {
        getClass(): typeof any;
        static checkSpecialEquality(o: any, o1: any, shallow: boolean): boolean;
        static fromRgb($$0: number): Internal.TextColor;
        getRgbJS(): number;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        isAnimated(): boolean;
        static fromLegacyFormat($$0: Internal.ChatFormatting_): Internal.TextColor;
        getName(): string;
        getValue(): number;
        getHexJS(): string;
        getFireworkColorJS(): number;
        toString(): string;
        notifyAll(): void;
        getArgbJS(): number;
        specialEquals(o: any, shallow: boolean): boolean;
        formatValue(): string;
        getSerializeJS(): string;
        hashCode(): number;
        static parseColor($$0: string): Internal.TextColor;
        serialize(): string;
        wait(): void;
        createTextColorJS(): this;
        wait(arg0: number): void;
        equals($$0: any): boolean;
        get class(): typeof any
        get rgbJS(): number
        get animated(): boolean
        get name(): string
        get value(): number
        get hexJS(): string
        get fireworkColorJS(): number
        get argbJS(): number
        get serializeJS(): string
        readonly name: string;
        static readonly CODEC: Internal.Codec<Internal.TextColor>;
    }
    type TextColor_ = TextColor;
    class CustomReward extends Internal.Reward {
        constructor(id: number, quest: Internal.Quest_)
        writeData(nbt: Internal.CompoundTag_): void;
        getExcludeFromClaimAll(): boolean;
        getMutableTitle(): Internal.MutableComponent;
        getButtonText(): string;
        readData(nbt: Internal.CompoundTag_): void;
        editedFromGUI(): void;
        getQuest(): Internal.Quest;
        notify(): void;
        compareTo(arg0: any): number;
        isClaimAllHardcoded(): boolean;
        ignoreRewardBlocking(): boolean;
        clearCachedData(): void;
        getRawTitle(): string;
        static isNull(object: Internal.QuestObjectBase_): boolean;
        deleteSelf(): void;
        componentsToRefresh(): Internal.Set<Internal.RecipeModHelper$Components>;
        static getID(object: Internal.QuestObjectBase_): number;
        isValid(): boolean;
        static parseCodeString(id: string): number;
        deleteChildren(): void;
        onButtonClicked(button: dev.ftb.mods.ftblibrary.ui.Button_, canClick: boolean): void;
        addTitleInMouseOverText(): boolean;
        getTags(): Internal.Set<string>;
        forceProgress(teamData: Internal.TeamData_, progressChange: Internal.ProgressChange_): void;
        static "getCodeString(dev.ftb.mods.ftbquests.quest.QuestObjectBase)"(object: Internal.QuestObjectBase_): string;
        wait(): void;
        getTitle(): net.minecraft.network.chat.Component;
        setRawIcon(rawIcon: Internal.ItemStack_): void;
        static shouldSendNotifications(): boolean;
        "compareTo(java.lang.Object)"(arg0: any): number;
        getType(): Internal.RewardType;
        getAltIcon(): Internal.Icon;
        static titleToID(s: string): Optional<string>;
        onEditButtonClicked(gui: Internal.Runnable_): void;
        getClass(): typeof any;
        static getCodeString(object: Internal.QuestObjectBase_): string;
        getCodeString(): string;
        static copy<T extends Internal.QuestObjectBase>(orig: T, factory: Internal.Supplier_<T>): T;
        isTeamReward(): boolean;
        static getCodeString(id: number): string;
        createSubGroup(group: Internal.ConfigGroup_): Internal.ConfigGroup;
        getParentID(): number;
        wait(arg0: number, arg1: number): void;
        fillConfigGroup(config: Internal.ConfigGroup_): void;
        automatedClaimPost(blockEntity: Internal.BlockEntity_, playerId: Internal.UUID_, player: Internal.ServerPlayer_): void;
        getIcon(): Internal.Icon;
        getAltTitle(): net.minecraft.network.chat.Component;
        static "getCodeString(long)"(id: number): string;
        "compareTo(dev.ftb.mods.ftbquests.quest.QuestObjectBase)"(other: Internal.QuestObjectBase_): number;
        readNetData(buffer: Internal.FriendlyByteBuf_): void;
        hasTag(tag: string): boolean;
        compareTo(other: Internal.QuestObjectBase_): number;
        setRawTitle(rawTitle: string): void;
        toString(): string;
        getIngredient(widget: dev.ftb.mods.ftblibrary.ui.Widget_): Optional<Internal.PositionedIngredient>;
        getQuestChapter(): Internal.Chapter;
        notifyAll(): void;
        getQuestFile(): Internal.BaseQuestFile;
        getObjectType(): Internal.QuestObjectType;
        forceProgressRaw(teamData: Internal.TeamData_, progressChange: Internal.ProgressChange_): void;
        static parseHexId(id: string): Optional<number>;
        automatedClaimPre(blockEntity: Internal.BlockEntity_, items: Internal.List_<Internal.ItemStack>, random: Internal.RandomSource_, playerId: Internal.UUID_, player: Internal.ServerPlayer_): boolean;
        hashCode(): number;
        getAutoClaimType(): Internal.RewardAutoClaim;
        getPath(): Optional<string>;
        writeNetData(buffer: Internal.FriendlyByteBuf_): void;
        editedFromGUIOnServer(): void;
        onCreated(): void;
        claim(player: Internal.ServerPlayer_, notify: boolean): void;
        wait(arg0: number): void;
        equals(object: any): boolean;
        addMouseOverText(list: Internal.TooltipList_): void;
        get excludeFromClaimAll(): boolean
        get mutableTitle(): Internal.MutableComponent
        get buttonText(): string
        get quest(): Internal.Quest
        get claimAllHardcoded(): boolean
        get rawTitle(): string
        get valid(): boolean
        get tags(): Internal.Set<string>
        get title(): net.minecraft.network.chat.Component
        set rawIcon(rawIcon: Internal.ItemStack_)
        get type(): Internal.RewardType
        get altIcon(): Internal.Icon
        get class(): typeof any
        get codeString(): string
        get teamReward(): boolean
        get parentID(): number
        get icon(): Internal.Icon
        get altTitle(): net.minecraft.network.chat.Component
        set rawTitle(rawTitle: string)
        get questChapter(): Internal.Chapter
        get questFile(): Internal.BaseQuestFile
        get objectType(): Internal.QuestObjectType
        get autoClaimType(): Internal.RewardAutoClaim
        get path(): Optional<string>
    }
    type CustomReward_ = CustomReward;
    class LichKingsArmorItem extends Internal.ModifiableArmorItem {
        constructor(fzzyMaterial: Internal.ArmorMaterial_, type: Internal.ArmorItem$Type_, settings: Internal.Item$Properties_)
        onTick(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        getType(): Internal.ArmorItem$Type;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        addModifierTooltip(stack: Internal.ItemStack_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_, type: Internal.ModifierHelperType_<any>): void;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        setAttributeModifiers(arg0: Internal.Multimap_<any, any>): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        fzzy_core_correctSlot(slot: Internal.EquipmentSlot_): boolean;
        getCreativeTab(): string;
        postWearerHit(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        modifierObjectPredicate(livingEntity: Internal.LivingEntity_, stack: Internal.ItemStack_): ResourceLocation;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        defaultModifiers(type: Internal.ModifierHelperType_<any>): Internal.List<ResourceLocation>;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        static get($$0: Internal.ItemStack_): Internal.Equipable;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        kjs$getAttributeMap(): Internal.Multimap<any, any>;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getDefense(): number;
        kjs$getMutableAttributeMap(): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        getModifiers(stack: Internal.ItemStack_, type: Internal.ModifierHelperType_<any>): Internal.List<ResourceLocation>;
        fzzy_core_getCorrectSlot(): Internal.EquipmentSlot;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        getEquipmentSlot(): Internal.EquipmentSlot;
        onWearerKilledOther(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, victim: Internal.LivingEntity_, world: Internal.ServerLevel_): void;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        canBeModifiedBy(type: Internal.ModifierHelperType_<any>): boolean;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        static dispenseArmor($$0: Internal.BlockSource_, $$1: Internal.ItemStack_): boolean;
        getMaterial(): Internal.ArmorMaterial;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        incrementKillCount(stack: Internal.ItemStack_): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        getEquipSound(): Internal.SoundEvent;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        static access$getAttributeModifiers$s1152367662($this: Internal.LichKingsArmorItem_, slot: Internal.EquipmentSlot_): Internal.Multimap<any, any>;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        onAttack(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, attacker: Internal.LivingEntity_, source: DamageSource_, amount: number): number;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers(slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        getToughness(): number;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getKillCount(stack: Internal.ItemStack_): number;
        getTypeItemStackKey(): Internal.ItemStackKey;
        onWearerDamaged(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, attacker: Internal.LivingEntity_, source: DamageSource_, amount: number): number;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        postWearerMine(stack: Internal.ItemStack_, world: Internal.Level_, state: Internal.BlockState_, pos: BlockPos_, miner: Internal.Player_): void;
        kjs$setAttributeMap(arg0: Internal.Multimap_<any, any>): void;
        swapWithEquipmentSlot($$0: Internal.Item_, $$1: Internal.Level_, $$2: Internal.Player_, $$3: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get type(): Internal.ArmorItem$Type
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        set attributeModifiers(arg0: Internal.Multimap_<any, any>)
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        get defense(): number
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get equipmentSlot(): Internal.EquipmentSlot
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        get material(): Internal.ArmorMaterial
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get equipSound(): Internal.SoundEvent
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get toughness(): number
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type LichKingsArmorItem_ = LichKingsArmorItem;
    class CustomBossEvent extends Internal.ServerBossEvent {
        constructor($$0: ResourceLocation_, $$1: net.minecraft.network.chat.Component_)
        setValue($$0: number): void;
        getDisplayName(): net.minecraft.network.chat.Component;
        shouldCreateWorldFog(): boolean;
        getClass(): typeof any;
        addOfflinePlayer($$0: Internal.UUID_): void;
        setOverlay($$0: Internal.BossEvent$BossBarOverlay_): void;
        removePlayer($$0: Internal.ServerPlayer_): void;
        getPlayers(): Internal.Collection<Internal.ServerPlayer>;
        setColor($$0: Internal.BossEvent$BossBarColor_): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        static load($$0: Internal.CompoundTag_, $$1: ResourceLocation_): Internal.CustomBossEvent;
        setDarkenScreen($$0: boolean): Internal.BossEvent;
        setProgress($$0: number): void;
        setName($$0: net.minecraft.network.chat.Component_): void;
        shouldPlayBossMusic(): boolean;
        getValue(): number;
        isVisible(): boolean;
        shouldDarkenScreen(): boolean;
        setCreateWorldFog($$0: boolean): Internal.BossEvent;
        getColor(): Internal.BossEvent$BossBarColor;
        save(): Internal.CompoundTag;
        setPlayers($$0: Internal.Collection_<Internal.ServerPlayer>): boolean;
        setPlayBossMusic($$0: boolean): Internal.BossEvent;
        getProgress(): number;
        getName(): net.minecraft.network.chat.Component;
        toString(): string;
        getOverlay(): Internal.BossEvent$BossBarOverlay;
        notifyAll(): void;
        setMax($$0: number): void;
        removeAllPlayers(): void;
        onPlayerDisconnect($$0: Internal.ServerPlayer_): void;
        onPlayerConnect($$0: Internal.ServerPlayer_): void;
        hashCode(): number;
        wait(): void;
        getMax(): number;
        getTextId(): ResourceLocation;
        getId(): Internal.UUID;
        wait(arg0: number): void;
        addPlayer($$0: Internal.ServerPlayer_): void;
        equals(arg0: any): boolean;
        setVisible($$0: boolean): void;
        set value($$0: number)
        get displayName(): net.minecraft.network.chat.Component
        get class(): typeof any
        set overlay($$0: Internal.BossEvent$BossBarOverlay_)
        get players(): Internal.Collection<Internal.ServerPlayer>
        set color($$0: Internal.BossEvent$BossBarColor_)
        set darkenScreen($$0: boolean)
        set progress($$0: number)
        set name($$0: net.minecraft.network.chat.Component_)
        get value(): number
        get visible(): boolean
        set createWorldFog($$0: boolean)
        get color(): Internal.BossEvent$BossBarColor
        set players($$0: Internal.Collection_<Internal.ServerPlayer>)
        set playBossMusic($$0: boolean)
        get progress(): number
        get name(): net.minecraft.network.chat.Component
        get overlay(): Internal.BossEvent$BossBarOverlay
        set max($$0: number)
        get max(): number
        get textId(): ResourceLocation
        get id(): Internal.UUID
        set visible($$0: boolean)
    }
    type CustomBossEvent_ = CustomBossEvent;
    class ProbabilityFeatureConfiguration implements Internal.FeatureConfiguration {
        constructor($$0: number)
        getClass(): typeof any;
        hashCode(): number;
        getFeatures(): Internal.Stream<Internal.ConfiguredFeature<any, any>>;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        get features(): Internal.Stream<Internal.ConfiguredFeature<any, any>>
        readonly probability: number;
        static readonly CODEC: Internal.Codec<Internal.ProbabilityFeatureConfiguration>;
    }
    type ProbabilityFeatureConfiguration_ = ProbabilityFeatureConfiguration;
    interface Float2LongFunction extends Internal.DoubleToLongFunction, it.unimi.dsi.fastutil.Function<number, number> {
        composeByte(arg0: Internal.Byte2FloatFunction_): Internal.Byte2LongFunction;
        andThenLong(arg0: Internal.Long2LongFunction_): this;
        composeInt(arg0: Internal.Int2FloatFunction_): Internal.Int2LongFunction;
        composeShort(arg0: Internal.Short2FloatFunction_): Internal.Short2LongFunction;
        andThenDouble(arg0: Internal.Long2DoubleFunction_): Internal.Float2DoubleFunction;
        /**
         * @deprecated
        */
        "put(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): any;
        /**
         * @deprecated
        */
        andThen<T>(arg0: Internal.Function_<number, T>): Internal.Function<number, T>;
        /**
         * @deprecated
        */
        "get(java.lang.Object)"(arg0: any): number;
        "containsKey(float)"(arg0: number): boolean;
        andThenObject<T>(arg0: Internal.Long2ObjectFunction_<T>): Internal.Float2ObjectFunction<T>;
        /**
         * @deprecated
        */
        remove(arg0: any): number;
        /**
         * @deprecated
        */
        put(arg0: any, arg1: any): any;
        composeFloat(arg0: Internal.Float2FloatFunction_): this;
        composeLong(arg0: Internal.Long2FloatFunction_): Internal.Long2LongFunction;
        andThenInt(arg0: Internal.Long2IntFunction_): Internal.Float2IntFunction;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: number): number;
        andThenReference<T>(arg0: Internal.Long2ReferenceFunction_<T>): Internal.Float2ReferenceFunction<T>;
        remove(arg0: number): number;
        /**
         * @deprecated
        */
        "getOrDefault(java.lang.Object,java.lang.Long)"(arg0: any, arg1: number): number;
        identity<T>(): Internal.Function<T, T>;
        /**
         * @deprecated
        */
        "remove(java.lang.Object)"(arg0: any): number;
        /**
         * @deprecated
        */
        "containsKey(java.lang.Object)"(arg0: any): boolean;
        "remove(float)"(arg0: number): number;
        andThenShort(arg0: Internal.Long2ShortFunction_): Internal.Float2ShortFunction;
        put(arg0: number, arg1: number): number;
        composeChar(arg0: Internal.Char2FloatFunction_): Internal.Char2LongFunction;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: any): any;
        andThenByte(arg0: Internal.Long2ByteFunction_): Internal.Float2ByteFunction;
        composeReference<T>(arg0: Internal.Reference2FloatFunction_<T>): Internal.Reference2LongFunction<T>;
        /**
         * @deprecated
        */
        get(arg0: any): number;
        /**
         * @deprecated
        */
        containsKey(arg0: any): boolean;
        /**
         * @deprecated
        */
        "getOrDefault(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): any;
        "getOrDefault(float,long)"(arg0: number, arg1: number): number;
        /**
         * @deprecated
        */
        compose<T>(arg0: Internal.Function_<T, number>): Internal.Function<T, number>;
        containsKey(arg0: number): boolean;
        "put(float,long)"(arg0: number, arg1: number): number;
        abstract "get(float)"(arg0: number): number;
        andThenChar(arg0: Internal.Long2CharFunction_): Internal.Float2CharFunction;
        defaultReturnValue(): number;
        getOrDefault(arg0: number, arg1: number): number;
        composeObject<T>(arg0: Internal.Object2FloatFunction_<T>): Internal.Object2LongFunction<T>;
        /**
         * @deprecated
        */
        applyAsLong(arg0: number): number;
        apply(arg0: number): number;
        composeDouble(arg0: Internal.Double2FloatFunction_): Internal.Double2LongFunction;
        andThenFloat(arg0: Internal.Long2FloatFunction_): Internal.Float2FloatFunction;
        size(): number;
        abstract get(arg0: number): number;
        /**
         * @deprecated
        */
        "put(java.lang.Float,java.lang.Long)"(arg0: number, arg1: number): number;
        clear(): void;
        defaultReturnValue(arg0: number): void;
        /**
         * @deprecated
        */
        put(arg0: number, arg1: number): number;
    }
    type Float2LongFunction_ = Float2LongFunction;
    interface DraggableBoundsProvider {
        ofRectangles(bounds: Internal.Iterable_<me.shedaniel.math.Rectangle>): this;
        ofShape(shape: Internal.VoxelShape_): this;
        fromRectangle(bounds: me.shedaniel.math.Rectangle_): Internal.VoxelShape;
        ofShapes(shapes: Internal.Iterable_<Internal.VoxelShape>): this;
        concat(providers: Internal.Iterable_<Internal.DraggableBoundsProvider>): this;
        abstract bounds(): Internal.VoxelShape;
        ofRectangle(bounds: me.shedaniel.math.Rectangle_): this;
        empty(): this;
        (): Internal.VoxelShape_;
    }
    type DraggableBoundsProvider_ = DraggableBoundsProvider | (()=> Internal.VoxelShape_);
    abstract class ItemMediaHolder extends Internal.Item implements Internal.MediaHolderItem {
        constructor(pProperties: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getConsumptionPriority(stack: Internal.ItemStack_): number;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        abstract canRecharge(arg0: Internal.ItemStack_): boolean;
        appendHoverText(pStack: Internal.ItemStack_, pLevel: Internal.Level_, pTooltipComponents: Internal.List_<net.minecraft.network.chat.Component>, pIsAdvanced: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        abstract canProvideMedia(arg0: Internal.ItemStack_): boolean;
        getBarWidth(pStack: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor(pStack: Internal.ItemStack_): number;
        withdrawMedia(stack: Internal.ItemStack_, cost: number, simulate: boolean): number;
        getItem(): Internal.Item;
        getMaxMedia(stack: Internal.ItemStack_): number;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        static withMedia(stack: Internal.ItemStack_, media: number, maxMedia: number): Internal.ItemStack;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible(pStack: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMedia(stack: Internal.ItemStack_): number;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        getMediaFullness(stack: Internal.ItemStack_): number;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        insertMedia(stack: Internal.ItemStack_, amount: number, simulate: boolean): number;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setMedia(stack: Internal.ItemStack_, media: number): void;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
        static readonly TAG_MEDIA: ("hexcasting:media") & (string);
        static readonly TAG_MAX_MEDIA: ("hexcasting:start_media") & (string);
        static readonly HEX_COLOR: (Internal.TextColor) & (Internal.TextColor);
    }
    type ItemMediaHolder_ = ItemMediaHolder;
    class DropperBlockEntity extends Internal.DispenserBlockEntity {
        constructor($$0: BlockPos_, $$1: Internal.BlockState_)
        stopOpen($$0: Internal.Player_): void;
        handler$efn000$collective$setLevel(level: Internal.Level_, ci: Internal.CallbackInfo_): void;
        handler$ine002$lithium$setInventoryStackListReplacement(list: Internal.NonNullList_<any>, ci: Internal.CallbackInfo_): void;
        etf$getType(): Internal.EntityType<any>;
        emf$getVelocity(): Vec3d;
        fabric_setSuppress(suppress: boolean): void;
        clear(ingredient: Internal.Ingredient_): void;
        etf$isBlockEntity(): boolean;
        find(): number;
        hasAnyOf($$0: Internal.Set_<Internal.Item>): boolean;
        removeItem($$0: number, $$1: number): Internal.ItemStack;
        /**
         * @deprecated
        */
        setBlockState($$0: Internal.BlockState_): void;
        hasAttached(type: Internal.AttachmentType_<any>): boolean;
        things$setLock(arg0: Internal.LockCode_): void;
        setCulled(value: boolean): void;
        saveWithoutMetadata(): Internal.CompoundTag;
        setTimeout(): void;
        "setChanged()"(): void;
        isOutOfCamera(): boolean;
        setInventoryLithium(arg0: Internal.NonNullList_<any>): void;
        kjs$self(): net.minecraft.world.Container;
        getInventoryLithium(): Internal.NonNullList<any>;
        etf$canBeBright(): boolean;
        setRemoved(): void;
        asComponentProvider(): Internal.ComponentProvider;
        emf$isOnGround(): boolean;
        handler$efn000$collective$setRemoved(ci: Internal.CallbackInfo_): void;
        getRandomSlot($$0: Internal.RandomSource_): number;
        isItemValid(slot: number, stack: Internal.ItemStack_): boolean;
        getCustomName(): net.minecraft.network.chat.Component;
        getClass(): typeof any;
        abstract emitContentModified(): void;
        getLoottable(): ResourceLocation;
        countItem($$0: Internal.Item_): number;
        handler$inh000$lithium$readNbtStackListReplacement(nbt: Internal.CompoundTag_, ci: Internal.CallbackInfo_): void;
        hasAnyComparatorNearby(): boolean;
        invokeWriteNbt(arg0: Internal.CompoundTag_): void;
        static addEntityType($$0: Internal.CompoundTag_, $$1: Internal.BlockEntityType_<any>): void;
        "deserializeNBT(net.minecraft.nbt.Tag)"(arg0: Internal.Tag_): void;
        canPlaceItem($$0: number, $$1: Internal.ItemStack_): boolean;
        createMenu($$0: number, $$1: Internal.Inventory_, $$2: Internal.Player_): Internal.AbstractContainerMenu;
        clearRemoved(): void;
        emf$isWet(): boolean;
        listenForContentChangesOnce(stackList: Internal.LithiumStackList_, inventoryChangeListener: Internal.InventoryChangeListener_): void;
        getHeight(): number;
        triggerEvent($$0: number, $$1: number): boolean;
        emf$isGlowing(): boolean;
        hasLevel(): boolean;
        canTakeItem($$0: net.minecraft.world.Container_, $$1: number, $$2: Internal.ItemStack_): boolean;
        insertItem(slot: number, stack: Internal.ItemStack_, simulate: boolean): Internal.ItemStack;
        unpackLootTable($$0: Internal.Player_): void;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>, initializer: Internal.Supplier_<A>): A;
        clear(): void;
        wait(arg0: number): void;
        etf$getItemsEquipped(): Internal.Iterable<any>;
        abstract emitRemoved(): void;
        etf$getVelocity(): Vec3d;
        stopListenForMajorInventoryChanges(inventoryChangeListener: Internal.InventoryChangeListener_): void;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        etf$getWorld(): Internal.Level;
        getRenderAttachmentData(): any;
        getUpdateTag(): Internal.CompoundTag;
        modifyAttached<A>(type: Internal.AttachmentType_<A>, modifier: Internal.UnaryOperator_<A>): A;
        setLevel($$0: Internal.Level_): void;
        getSlots(): number;
        etf$getNbt(): Internal.CompoundTag;
        etf$getBlockPos(): BlockPos;
        fabric_onFinalCommit(slot: number, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): void;
        setItem($$0: number, $$1: Internal.ItemStack_): void;
        emf$prevPitch(): number;
        etf$getHandItems(): Internal.Iterable<any>;
        etf$getArmorItems(): Internal.Iterable<any>;
        emf$getY(): number;
        invalidateCaps(): void;
        getName(): net.minecraft.network.chat.Component;
        getSlotLimit(slot: number): number;
        static setLootTable($$0: Internal.BlockGetter_, $$1: Internal.RandomSource_, $$2: BlockPos_, $$3: ResourceLocation_): void;
        removeItemNoUpdate($$0: number): Internal.ItemStack;
        emf$age(): number;
        etf$hasCustomName(): boolean;
        static loadStatic($$0: BlockPos_, $$1: Internal.BlockState_, $$2: Internal.CompoundTag_): Internal.BlockEntity;
        wait(): void;
        emf$isTouchingWater(): boolean;
        emf$getVariableMap(): Internal.Object2FloatOpenHashMap<any>;
        getComponentContainer(): Internal.ComponentContainer;
        etf$getCustomName(): net.minecraft.network.chat.Component;
        fabric_writeAttachmentsToNbt(nbt: Internal.CompoundTag_): void;
        count(): number;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>): A;
        setOutOfCamera(value: boolean): void;
        isEmpty(): boolean;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        onlyOpCanSetNbt(): boolean;
        extractItem(slot: number, amount: number, simulate: boolean): Internal.ItemStack;
        getBlock(level: Internal.Level_): Internal.BlockContainerJS;
        serializeNBT(): Internal.Tag;
        canReceiveTransferCooldown(): boolean;
        saveWithFullMetadata(): Internal.CompoundTag;
        emf$getX(): number;
        deserializeNBT(arg0: Internal.Tag_): void;
        getAllItems(): Internal.List<Internal.ItemStack>;
        getRecipientsForComponentSync(): Internal.Iterable<any>;
        deserializeNBT(state: Internal.BlockState_, nbt: Internal.CompoundTag_): void;
        abstract forwardContentChangeOnce(arg0: Internal.InventoryChangeListener_, arg1: Internal.LithiumStackList_, arg2: Internal.InventoryChangeTracker_): void;
        insertItem(stack: Internal.ItemStack_, simulate: boolean): Internal.ItemStack;
        emf$hasPassengers(): boolean;
        setAttached(type: Internal.AttachmentType_<any>, value: any): any;
        fabric_readAttachmentsFromNbt(nbt: Internal.CompoundTag_): void;
        getRenderData(): any;
        isMutable(): boolean;
        find(ingredient: Internal.Ingredient_): number;
        emf$getPitch(): number;
        canOpen($$0: Internal.Player_): boolean;
        equals(arg0: any): boolean;
        emf$hasVehicle(): boolean;
        getItems(): Internal.NonNullList<any>;
        abstract stopForwardingMajorInventoryChanges(arg0: Internal.InventoryChangeListener_): void;
        load($$0: Internal.CompoundTag_): void;
        setChanged(): void;
        getAttachedOrSet<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        removeAttached<A>(type: Internal.AttachmentType_<A>): A;
        hasAnyMatching($$0: Internal.Predicate_<Internal.ItemStack>): boolean;
        emf$prevZ(): number;
        getWidth(): number;
        "isEmpty()"(): boolean;
        things$getLock(): Internal.LockCode;
        etf$getEntityKey(): string;
        etf$getPose(): Internal.Pose;
        hasCustomName(): boolean;
        isCulled(): boolean;
        getType(): Internal.BlockEntityType<any>;
        static transfer(original: Internal.AttachmentTarget_, target: Internal.AttachmentTarget_, isDeath: boolean): void;
        etf$getOptifineId(): number;
        getCustomData(): Internal.CompoundTag;
        getItem($$0: number): Internal.ItemStack;
        handler$hph000$item_obliterator$disableItemfromLootContainer(slot: number, stack: Internal.ItemStack_, info: Internal.CallbackInfo_): void;
        getDisplayName(): net.minecraft.network.chat.Component;
        emf$isInvisible(): boolean;
        static getPosFromTag($$0: Internal.CompoundTag_): BlockPos;
        etf$distanceTo(entity: Internal.Entity_): number;
        emf$isSprinting(): boolean;
        setCustomName($$0: net.minecraft.network.chat.Component_): void;
        abstract forwardMajorInventoryChanges(arg0: Internal.InventoryChangeListener_): void;
        saveToItem($$0: Internal.ItemStack_): void;
        "redirect$fpk000$fabric-transfer-api-v1$fabric_redirectMarkDirty"(self: Internal.RandomizableContainerBlockEntity_): void;
        "deserializeNBT(net.minecraft.nbt.CompoundTag)"(nbt: Internal.CompoundTag_): void;
        emf$isInLava(): boolean;
        startOpen($$0: Internal.Player_): void;
        onComparatorAdded(direction: Internal.Direction_, offset: number): void;
        getUpdatePacket(): Internal.Packet<Internal.ClientGamePacketListener>;
        fabric_hasPersistentAttachments(): boolean;
        shouldCloseCurrentScreen(): boolean;
        owo$setCachedState(arg0: Internal.BlockState_): void;
        fabric_getAttachments(): Internal.Map<any, any>;
        countNonEmpty(): number;
        listenForMajorInventoryChanges(inventoryChangeListener: Internal.InventoryChangeListener_): void;
        abstract emitFirstComparatorAdded(): void;
        toString(): string;
        notifyAll(): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        etf$getScoreboardTeam(): Internal.Team;
        generateLootLithium(): void;
        emf$getZ(): number;
        getLootTable(): ResourceLocation;
        getAttachedOrThrow<A>(type: Internal.AttachmentType_<A>): A;
        clearContent(): void;
        countNonEmpty(ingredient: Internal.Ingredient_): number;
        abstract emitStackListReplaced(): void;
        static tryClear($$0: any): void;
        getAttached(type: Internal.AttachmentType_<any>): any;
        emf$getYaw(): number;
        setStackInSlot(slot: number, stack: Internal.ItemStack_): void;
        notify(): void;
        getBlockPos(): BlockPos;
        isRemoved(): boolean;
        addItem($$0: Internal.ItemStack_): number;
        emf$isSneaking(): boolean;
        onLoad(): void;
        getContainerSize(): number;
        fillCrashReportCategory($$0: Internal.CrashReportCategory_): void;
        etf$getBlockY(): number;
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        emf$prevX(): number;
        getBlockState(): Internal.BlockState;
        handler$zzl000$porting_lib_base$port_lib$invalidate(ci: Internal.CallbackInfo_): void;
        toComponentPacket(key: Internal.ComponentKey_<any>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        getMaxStackSize(): number;
        static stillValidBlockEntity($$0: Internal.BlockEntity_, $$1: Internal.Player_): boolean;
        getAttachedOrGet<A>(type: Internal.AttachmentType_<A>, defaultValue: Internal.Supplier_<A>): A;
        fabric_onTransfer(slot: number, transaction: Internal.TransactionContext_): void;
        setLootTable($$0: ResourceLocation_, $$1: number): void;
        count(ingredient: Internal.Ingredient_): number;
        saveWithId(): Internal.CompoundTag;
        emitCallbackReplaced(): void;
        setTransferCooldown(currentTime: number): void;
        wait(arg0: number, arg1: number): void;
        getLevel(): Internal.Level;
        port_lib$saveMetadata(arg0: Internal.CompoundTag_): void;
        static stillValidBlockEntity($$0: Internal.BlockEntity_, $$1: Internal.Player_, $$2: number): boolean;
        getStackInSlot(slot: number): Internal.ItemStack;
        emf$prevY(): number;
        asContainer(): net.minecraft.world.Container;
        emf$isOnFire(): boolean;
        etf$getUuid(): Internal.UUID;
        isForcedVisible(): boolean;
        stillValid($$0: Internal.Player_): boolean;
        deserializeNBT(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        emf$getTypeString(): string;
        getAttachedOrElse<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        static canUnlock($$0: Internal.Player_, $$1: Internal.LockCode_, $$2: net.minecraft.network.chat.Component_): boolean;
        emf$isAlive(): boolean;
        /**
         * @deprecated
        */
        set blockState($$0: Internal.BlockState_)
        set culled(value: boolean)
        get outOfCamera(): boolean
        set inventoryLithium(arg0: Internal.NonNullList_<any>)
        get inventoryLithium(): Internal.NonNullList<any>
        get customName(): net.minecraft.network.chat.Component
        get class(): typeof any
        get loottable(): ResourceLocation
        get height(): number
        get renderAttachmentData(): any
        get updateTag(): Internal.CompoundTag
        set level($$0: Internal.Level_)
        get slots(): number
        get name(): net.minecraft.network.chat.Component
        get componentContainer(): Internal.ComponentContainer
        set outOfCamera(value: boolean)
        get empty(): boolean
        get allItems(): Internal.List<Internal.ItemStack>
        get recipientsForComponentSync(): Internal.Iterable<any>
        get renderData(): any
        get mutable(): boolean
        get items(): Internal.NonNullList<any>
        get width(): number
        get "empty()"(): boolean
        get culled(): boolean
        get type(): Internal.BlockEntityType<any>
        get customData(): Internal.CompoundTag
        get displayName(): net.minecraft.network.chat.Component
        set customName($$0: net.minecraft.network.chat.Component_)
        get updatePacket(): Internal.Packet<Internal.ClientGamePacketListener>
        get lootTable(): ResourceLocation
        get blockPos(): BlockPos
        get removed(): boolean
        get containerSize(): number
        get blockState(): Internal.BlockState
        get maxStackSize(): number
        set transferCooldown(currentTime: number)
        get level(): Internal.Level
        get forcedVisible(): boolean
    }
    type DropperBlockEntity_ = DropperBlockEntity;
    interface FavoriteEntryType$Section {
        abstract getDefaultEntries(): Internal.List<Internal.FavoriteEntry>;
        abstract getText(): net.minecraft.network.chat.Component;
        abstract add(arg0: boolean, ...arg1: Internal.FavoriteEntry_[]): void;
        add(...entries: Internal.FavoriteEntry_[]): void;
        abstract getEntries(): Internal.List<Internal.FavoriteEntry>;
        get defaultEntries(): Internal.List<Internal.FavoriteEntry>
        get text(): net.minecraft.network.chat.Component
        get entries(): Internal.List<Internal.FavoriteEntry>
    }
    type FavoriteEntryType$Section_ = FavoriteEntryType$Section;
    class DropTarget implements Internal.DropTargetListener, Internal.Serializable {
        constructor()
        constructor(arg0: Internal.Component_, arg1: number, arg2: Internal.DropTargetListener_, arg3: boolean, arg4: Internal.FlavorMap_)
        constructor(arg0: Internal.Component_, arg1: number, arg2: Internal.DropTargetListener_)
        constructor(arg0: Internal.Component_, arg1: number, arg2: Internal.DropTargetListener_, arg3: boolean)
        constructor(arg0: Internal.Component_, arg1: Internal.DropTargetListener_)
        setDefaultActions(arg0: number): void;
        getClass(): typeof any;
        removeDropTargetListener(arg0: Internal.DropTargetListener_): void;
        dragOver(arg0: Internal.DropTargetDragEvent_): void;
        isActive(): boolean;
        getDropTargetContext(): Internal.DropTargetContext;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getComponent(): Internal.Component;
        setActive(arg0: boolean): void;
        getFlavorMap(): Internal.FlavorMap;
        dropActionChanged(arg0: Internal.DropTargetDragEvent_): void;
        addNotify(): void;
        getDefaultActions(): number;
        setComponent(arg0: Internal.Component_): void;
        toString(): string;
        notifyAll(): void;
        dragExit(arg0: Internal.DropTargetEvent_): void;
        setFlavorMap(arg0: Internal.FlavorMap_): void;
        hashCode(): number;
        removeNotify(): void;
        drop(arg0: Internal.DropTargetDropEvent_): void;
        wait(): void;
        dragEnter(arg0: Internal.DropTargetDragEvent_): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        addDropTargetListener(arg0: Internal.DropTargetListener_): void;
        set defaultActions(arg0: number)
        get class(): typeof any
        get active(): boolean
        get dropTargetContext(): Internal.DropTargetContext
        get component(): Internal.Component
        set active(arg0: boolean)
        get flavorMap(): Internal.FlavorMap
        get defaultActions(): number
        set component(arg0: Internal.Component_)
        set flavorMap(arg0: Internal.FlavorMap_)
    }
    type DropTarget_ = DropTarget;
    /**
     * Invoked when a player crafts an item.
    */
    class ItemCraftedEventJS extends Internal.PlayerEventJS {
        constructor(player: Internal.Player_, crafted: Internal.ItemStack_, container: net.minecraft.world.Container_)
        getClass(): typeof any;
        /**
         * Stops the event with default exit value. Execution will be stopped **immediately**.
         * 
         * `exit` denotes a `default` outcome.
        */
        exit(): any;
        /**
         * Cancels the event with the given exit value. Execution will be stopped **immediately**.
         * 
         * `cancel` denotes a `false` outcome.
        */
        cancel(value: any): any;
        toString(): string;
        /**
         * Removes the specified game stage from the player
        */
        removeGameStage(stage: string): void;
        /**
         * The item that was crafted.
        */
        getItem(): Internal.ItemStack;
        notifyAll(): void;
        /**
         * Stops the event with the given exit value. Execution will be stopped **immediately**.
         * 
         * `exit` denotes a `default` outcome.
        */
        exit(value: any): any;
        notify(): void;
        /**
         * Adds the specified game stage to the player
        */
        addGameStage(stage: string): void;
        wait(arg0: number, arg1: number): void;
        getLevel(): Internal.Level;
        /**
         * Stops the event with the given exit value. Execution will be stopped **immediately**.
         * 
         * `success` denotes a `true` outcome.
        */
        success(value: any): any;
        hashCode(): number;
        /**
         * The player that crafted the item.
        */
        getEntity(): Internal.Entity;
        /**
         * The inventory that the item was crafted in.
        */
        getInventory(): Internal.InventoryKJS;
        wait(): void;
        /**
         * Cancels the event with default exit value. Execution will be stopped **immediately**.
         * 
         * `cancel` denotes a `false` outcome.
        */
        cancel(): any;
        wait(arg0: number): void;
        getPlayer(): Internal.Player;
        /**
         * Stops the event with default exit value. Execution will be stopped **immediately**.
         * 
         * `success` denotes a `true` outcome.
        */
        success(): any;
        equals(arg0: any): boolean;
        /**
         * Checks if the player has the specified game stage
        */
        hasGameStage(stage: string): boolean;
        getServer(): Internal.MinecraftServer;
        get class(): typeof any
        /**
         * The item that was crafted.
        */
        get item(): Internal.ItemStack
        get level(): Internal.Level
        /**
         * The player that crafted the item.
        */
        get entity(): Internal.Entity
        /**
         * The inventory that the item was crafted in.
        */
        get inventory(): Internal.InventoryKJS
        get player(): Internal.Player
        get server(): Internal.MinecraftServer
    }
    type ItemCraftedEventJS_ = ItemCraftedEventJS;
    interface TypeWrapperFactory$Simple <T> extends Internal.TypeWrapperFactory<T> {
        wrap(cx: Internal.Context_, o: any): T;
        abstract wrapSimple(arg0: any): T;
        (arg0: any): T;
    }
    type TypeWrapperFactory$Simple_<T> = ((arg0: any)=> T) | TypeWrapperFactory$Simple<T>;
    class Vex extends Internal.Monster implements Internal.TraceableEntity {
        constructor($$0: Internal.EntityType_<Internal.Vex>, $$1: Internal.Level_)
        handler$hak000$gobber2$gobberOccludeVibrationSignals(cir: Internal.CallbackInfoReturnable_<any>): void;
        handler$fed001$extraalchemy$writeNbt(tag: Internal.CompoundTag_, cb: Internal.CallbackInfo_): void;
        etf$getType(): Internal.EntityType<any>;
        getUpVector($$0: number): Vec3d;
        gameEvent($$0: Internal.GameEvent_, $$1: Internal.Entity_): void;
        static checkMobSpawnRules($$0: Internal.EntityType_<Internal.Mob>, $$1: Internal.LevelAccessor_, $$2: Internal.MobSpawnType_, $$3: BlockPos_, $$4: Internal.RandomSource_): boolean;
        setDefaultMovementSpeedMultiplier(speed: number): void;
        isSuppressingBounce(): boolean;
        setTarget($$0: Internal.LivingEntity_): void;
        handler$han001$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        setCulled(value: boolean): void;
        handler$leb003$puzzleslib$hurt(source: DamageSource_, amount: number, callback: Internal.CallbackInfoReturnable_<any>): void;
        isOnFire(): boolean;
        getPositionCodec(): Internal.VecDeltaCodec;
        setMaxUpStep($$0: number): void;
        updateFluidHeightAndDoFluidPushing($$0: Internal.TagKey_<Internal.Fluid>, $$1: number): boolean;
        convertTo<T extends Internal.Mob>($$0: Internal.EntityType_<T>, $$1: boolean): T;
        getFallFlyingTicks(): number;
        setPosition(x: number, y: number, z: number): void;
        runCommandSilent(command: string): number;
        chunkPosition(): Internal.ChunkPos;
        emf$isOnGround(): boolean;
        dropLeash($$0: boolean, $$1: boolean): void;
        gameEvent($$0: Internal.GameEvent_): void;
        setXxa($$0: number): void;
        setDelayedLeashHolderId($$0: number): void;
        isShiftKeyDown(): boolean;
        setUUID($$0: Internal.UUID_): void;
        checkBelowWorld(): void;
        handler$leb000$puzzleslib$startUsingItem(hand: Internal.InteractionHand_, callback: Internal.CallbackInfo_): void;
        setMotionZ(z: number): void;
        "deserializeNBT(net.minecraft.nbt.Tag)"(arg0: Internal.Tag_): void;
        canFreeze(): boolean;
        ignoreExplosion(): boolean;
        getBlockY(): number;
        getIsInsideStructureTracker(): Internal.IsInsideStructureTracker;
        setPlayerHitTimer(arg0: number): void;
        isSpectator(): boolean;
        setMainHandItem(item: Internal.ItemStack_): void;
        removeEffectNoUpdate($$0: Internal.MobEffect_): Internal.MobEffectInstance;
        spawnAtLocation($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        getPersistentData(): Internal.CompoundTag;
        getHealth(): number;
        getMaxHealth(): number;
        emf$isGlowing(): boolean;
        setPathfindingMalus($$0: Internal.BlockPathTypes_, $$1: number): void;
        isRegisteredToWorld(): boolean;
        getRandomZ($$0: number): number;
        pehkui_getOnGround(): boolean;
        setAggressive($$0: boolean): void;
        handler$lef000$puzzleslib$checkDespawn(callback: Internal.CallbackInfo_): void;
        getFusionModel(layerIndex: number): Internal.Triple<any, any, any>;
        setRemoved($$0: Internal.Entity$RemovalReason_): void;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>, initializer: Internal.Supplier_<A>): A;
        getDistanceSq($$0: number, $$1: number, $$2: number): number;
        isInWaterRainOrBubble(): boolean;
        getRemovalReason(): Internal.Entity$RemovalReason;
        etf$getVelocity(): Vec3d;
        hex$markHurt(): void;
        resetFallDistance(): void;
        canSprint(): boolean;
        blockPosition(): BlockPos;
        setBoundingBox($$0: Internal.AABB_): void;
        isAmbientCreature(): boolean;
        setZza($$0: number): void;
        getBlock(): Internal.BlockContainerJS;
        setEquipment(slot: Internal.EquipmentSlot_, item: Internal.ItemStack_): void;
        etf$getHandItems(): Internal.Iterable<any>;
        randomTeleport($$0: number, $$1: number, $$2: number, $$3: boolean): boolean;
        getName(): net.minecraft.network.chat.Component;
        playAmbientSound(): void;
        onGround(): boolean;
        handler$leb000$puzzleslib$canBeAffected(effectInstance: Internal.MobEffectInstance_, callback: Internal.CallbackInfoReturnable_<any>): void;
        getControlledVehicle(): Internal.Entity;
        isOnSameTeam($$0: Internal.Entity_): boolean;
        getArmorValue(): number;
        tick(): void;
        localvar$lef000$puzzleslib$setTarget(entity: Internal.LivingEntity_): Internal.LivingEntity;
        getKillCredit(): Internal.LivingEntity;
        emf$isTouchingWater(): boolean;
        emf$getVariableMap(): Internal.Object2FloatOpenHashMap<any>;
        getComponentContainer(): Internal.ComponentContainer;
        hasPermissions($$0: number): boolean;
        getDynamicLightPrevZ(): number;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        pehkui_readScaleNbt(nbt: Internal.CompoundTag_): void;
        setOutOfCamera(value: boolean): void;
        static createMobAttributes(): Internal.AttributeSupplier$Builder;
        isAutoSpinAttack(): boolean;
        getRemainingFireTicks(): number;
        botania_getAmbientSound(): Internal.SoundEvent;
        onlyOpCanSetNbt(): boolean;
        tcdcommons_getCustomData(): Internal.GenericProperties<any>;
        fireImmune(): boolean;
        addMotion($$0: number, $$1: number, $$2: number): void;
        getMaxFallDistance(): number;
        isHolding($$0: Internal.Item_): boolean;
        getZ($$0: number): number;
        static areAllEffectsAmbient($$0: Internal.Collection_<Internal.MobEffectInstance>): boolean;
        doHurtTarget($$0: Internal.Entity_): boolean;
        getTicksFrozen(): number;
        wrapWithCondition$kom000$porting_lib_entity$port_lib$captureDrops(level: Internal.Level_, entity: Internal.Entity_): boolean;
        handler$lef000$puzzleslib$addAdditionalSaveData(compound: Internal.CompoundTag_, callback: Internal.CallbackInfo_): void;
        deflect(chance: number, source: Internal.Entity_): boolean;
        getRandomX($$0: number): number;
        getDynamicLightZ(): number;
        spawnAtLocation($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        pick($$0: number, $$1: number, $$2: boolean): Internal.HitResult;
        getVoicePitch(): number;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        setSleepingPos($$0: BlockPos_): void;
        changeDimension(p_20118_: Internal.ServerLevel_, teleporter: Internal.ITeleporter_): Internal.Entity;
        isDescending(): boolean;
        getAttributeBaseValue($$0: Internal.Attribute_): number;
        emf$getPitch(): number;
        sendEffectToPassengers($$0: Internal.MobEffectInstance_): void;
        getHeadRotSpeed(): number;
        getLastHurtByPlayer(): Internal.Player;
        getYHeadRot(): number;
        handler$cbi000$besmirchment$isTeammate(other: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getProjectile($$0: Internal.ItemStack_): Internal.ItemStack;
        localvar$leb000$puzzleslib$addEffect(oldEffectInstance: Internal.MobEffectInstance_, effectInstance: Internal.MobEffectInstance_, entity: Internal.Entity_): Internal.MobEffectInstance;
        static getAlpha(le: Internal.LivingEntity_, partialTicks: number): number;
        frameworkGetDataHolder(): com.mrcrayfish.framework.entity.sync.DataHolder;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        syncPacketPositionCodec($$0: number, $$1: number, $$2: number): void;
        setAbsorptionAmount($$0: number): void;
        setRecallData(pos: Internal.DimensionalPosition_): void;
        port_lib$spawnItemParticles(arg0: Internal.ItemStack_, arg1: number): void;
        shouldRenderAtSqrDistance($$0: number): boolean;
        getAttachedOrSet<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        damageSources(): Internal.DamageSources;
        removeAttached<A>(type: Internal.AttachmentType_<A>): A;
        removeAllGoals($$0: Internal.Predicate_<Internal.Goal>): void;
        swing(): void;
        recreateFromPacket($$0: Internal.ClientboundAddEntityPacket_): void;
        setDeltaMovement($$0: Vec3d_): void;
        getLeashOffset($$0: number): Vec3d;
        isBaby(): boolean;
        isCulled(): boolean;
        damageEquipment(slot: Internal.EquipmentSlot_): void;
        isGlowing(): boolean;
        getWalkTargetValue($$0: BlockPos_): number;
        canBreatheUnderwater(): boolean;
        getLeashedByEntities(): Internal.Set<any>;
        die($$0: DamageSource_): void;
        etf$getOptifineId(): number;
        removeAllEffects(): boolean;
        dynamicLightWorld(): Internal.Level;
        getLeashOffset(): Vec3d;
        hasLineOfSight($$0: Internal.Entity_): boolean;
        hex$getLastHurt(): number;
        onClimbable(): boolean;
        isAttackable(): boolean;
        getSlot($$0: number): Internal.SlotAccess;
        "deserializeNBT(net.minecraft.nbt.CompoundTag)"(nbt: Internal.CompoundTag_): void;
        emf$isInLava(): boolean;
        pehkui_constructScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        stopSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isUnderWater(): boolean;
        stopRiding(): void;
        getLeashHolder(): Internal.Entity;
        getX($$0: number): number;
        getSensing(): Internal.Sensing;
        localvar$kpc000$porting_lib_entity$port_lib$modifyMultiplier(multiplier: number): number;
        getLegsArmorItem(): Internal.ItemStack;
        getLuminance(): number;
        callUnsetRemoved(): void;
        captureDrops(value: Internal.Collection_<Internal.ItemEntity>): Internal.Collection<Internal.ItemEntity>;
        getSelfAndPassengers(): Internal.Stream<any>;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        handler$egi000$collective$LivingEntity_hurt(damageSource: DamageSource_, f: number, ci: Internal.CallbackInfoReturnable_<any>): void;
        getDeltaMovement(): Vec3d;
        canTakeItem($$0: Internal.ItemStack_): boolean;
        shouldDropExperience(): boolean;
        hasPassenger($$0: Internal.Entity_): boolean;
        be_getTravelerState(): Internal.TravelerState;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        getDynamicLightX(): number;
        setSecondsOnFire($$0: number): void;
        moveTo($$0: number, $$1: number, $$2: number): void;
        emf$getZ(): number;
        "getDisplayName()"(): net.minecraft.network.chat.Component;
        getLootTable(): ResourceLocation;
        getTicksUsingItem(): number;
        bettertrims$getWornMaterials(): Internal.List<any>;
        getArrowCount(): number;
        getMoveControl(): Internal.MoveControl;
        setMotion($$0: number, $$1: number, $$2: number): void;
        playSound($$0: Internal.SoundEvent_): void;
        getDefaultMovementSpeed(): number;
        handler$ikg000$lithium$tryShortcutFluidPushing(tag: Internal.TagKey_<any>, speed: number, cir: Internal.CallbackInfoReturnable_<any>, box: Internal.AABB_, x1: number, x2: number, y1: number, y2: number, z1: number, z2: number, zero: number): void;
        handler$hak000$gobber2$setFrozenTicks(frozenTicks: number, ci: Internal.CallbackInfo_): void;
        restoreFrom($$0: Internal.Entity_): void;
        isPeacefulCreature(): boolean;
        setOnGround($$0: boolean): void;
        addEffect($$0: Internal.MobEffectInstance_, $$1: Internal.Entity_): boolean;
        emf$getYaw(): number;
        ate(): void;
        setPos($$0: number, $$1: number, $$2: number): void;
        notify(): void;
        setPersistenceRequired(): void;
        getLastHurtByMobTimestamp(): number;
        getVehicle(): Internal.Entity;
        isEffectiveAi(): boolean;
        handler$kom000$porting_lib_entity$port_lib$startRiding(entity: Internal.Entity_, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        startRiding($$0: Internal.Entity_, $$1: boolean): boolean;
        getStringUuid(): string;
        setSwimming($$0: boolean): void;
        getMainArm(): Internal.HumanoidArm;
        checkSpawnRules($$0: Internal.LevelAccessor_, $$1: Internal.MobSpawnType_): boolean;
        getRotationVector(): Internal.Vec2;
        getHurtDir(): number;
        etf$getBlockY(): number;
        isSprinting(): boolean;
        isMaxGroupSizeReached($$0: number): boolean;
        getMotionY(): number;
        getOffhandItem(): Internal.ItemStack;
        canCollideWith($$0: Internal.Entity_): boolean;
        setLuminance(luminance: number): void;
        getBlockExplosionResistance($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.FluidState_, $$5: number): number;
        setLootTable(arg0: ResourceLocation_): void;
        getOwner(): Internal.Mob;
        clearSleepingPos(): void;
        canSpawnSprintParticle(): boolean;
        "moveTo(net.minecraft.core.BlockPos,float,float)"($$0: BlockPos_, $$1: number, $$2: number): void;
        hex$checkTotemDeathProtection(arg0: DamageSource_): boolean;
        getLastHurtMob(): Internal.LivingEntity;
        moveRelative($$0: number, $$1: Vec3d_): void;
        saveAsPassenger($$0: Internal.CompoundTag_): boolean;
        static gatherClosestChunks(chunks: Internal.LongSet_, x: number, y: number, z: number): void;
        handler$kom000$porting_lib_entity$afterSave(nbt: Internal.CompoundTag_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getSoundSource(): Internal.SoundSource;
        getLastDamageSource(): DamageSource;
        setNoActionTime($$0: number): void;
        setMovementSpeedAddition(speed: number): void;
        removeAfterChangingDimensions(): void;
        equipmentHasChanged($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        getPose(): Internal.Pose;
        getAttribute($$0: Internal.Attribute_): Internal.AttributeInstance;
        setPositionAndRotation($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        canBeAffected($$0: Internal.MobEffectInstance_): boolean;
        getRestrictCenter(): BlockPos;
        isLeftHanded(): boolean;
        invokeShouldDropLoot(): boolean;
        handler$kpc000$porting_lib_entity$port_lib$onFinishUsing(ci: Internal.CallbackInfo_, hand: Internal.InteractionHand_, result: Internal.ItemStack_): void;
        etf$getUuid(): Internal.UUID;
        removeVehicle(): void;
        shouldFusionRecomputeModel(layerIndex: number): boolean;
        modifyExpressionValue$zcl000$porting_lib_base$port_lib$canContinueUsing(original: boolean): boolean;
        setZ(z: number): void;
        getY(): number;
        deserializeNBT(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        eat($$0: Internal.Level_, $$1: Internal.ItemStack_): Internal.ItemStack;
        bookshelf$makePoofParticles(): void;
        isWithinMeleeAttackRange($$0: Internal.LivingEntity_): boolean;
        setCurrentModifyFoodPowers(powers: Internal.List_<any>): void;
        static checkMonsterSpawnRules($$0: Internal.EntityType_<Internal.Monster>, $$1: Internal.ServerLevelAccessor_, $$2: Internal.MobSpawnType_, $$3: BlockPos_, $$4: Internal.RandomSource_): boolean;
        broadcastBreakEvent($$0: Internal.EquipmentSlot_): void;
        modifyExpressionValue$zhf000$additionalentityattributes$additionalEntityAttributes$modifyUpwardSwimming(original: number, fluid: Internal.TagKey_<any>): number;
        handler$nbm000$things$onShieldBlock(source: DamageSource_, cir: Internal.CallbackInfoReturnable_<any>): void;
        showVehicleHealth(): boolean;
        "getOwner()"(): Internal.Entity;
        getDistance(pos: BlockPos_): number;
        isBlocking(): boolean;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number): void;
        removeAttribute(attribute: Internal.Attribute_, identifier: string): void;
        emf$getVelocity(): Vec3d;
        handler$lef000$puzzleslib$finalizeSpawn(level: Internal.ServerLevelAccessor_, difficulty: Internal.DifficultyInstance_, reason: Internal.MobSpawnType_, spawnData: Internal.SpawnGroupData_, dataTag: Internal.CompoundTag_, callback: Internal.CallbackInfoReturnable_<any>): void;
        etf$isBlockEntity(): boolean;
        shouldUpdateDynamicLight(): boolean;
        isPushedByFluid(): boolean;
        setOriginalFoodStack(original: Internal.ItemStack_): void;
        getArmorCoverPercentage(): number;
        handleRelativeFrictionAndCalculateMovement($$0: Vec3d_, $$1: number): Vec3d;
        turn($$0: number, $$1: number): void;
        getAirSupply(): number;
        moveTo($$0: BlockPos_, $$1: number, $$2: number): void;
        isPlayer(): boolean;
        isAnimal(): boolean;
        "handler$fgd000$fabric-dimensions-v1$getTeleportTarget"(destination: Internal.ServerLevel_, cir: Internal.CallbackInfoReturnable_<any>): void;
        canBeCollidedWith(): boolean;
        getMotionDirection(): Internal.Direction;
        asComponentProvider(): Internal.ComponentProvider;
        lavaHurt(): void;
        handleDamageEvent($$0: DamageSource_): void;
        setBoundOrigin($$0: BlockPos_): void;
        getFabricBalmData(): Internal.CompoundTag;
        canChangeDimensions(): boolean;
        static tickEntity(entity: Internal.Entity_): void;
        getCommandSenderWorld(): Internal.Level;
        getTotalMovementSpeed(): number;
        changeDimension($$0: Internal.ServerLevel_): Internal.Entity;
        getOwner(): Internal.Entity;
        localvar$zno000$apoli$modifyFallingVelocity(in_: number): number;
        handler$kom000$porting_lib_entity$afterLoad(nbt: Internal.CompoundTag_, ci: Internal.CallbackInfo_): void;
        pehkui_shouldIgnoreScaleNbt(): boolean;
        isMoving(): boolean;
        attack(hp: number): void;
        getAttributes(): Internal.AttributeMap;
        "hasPassenger(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.Entity>): boolean;
        botania_playHurtSound(arg0: DamageSource_): void;
        getDimensions($$0: Internal.Pose_): Internal.EntityDimensions;
        invokeGetLeashOffset(): Vec3d;
        isSwimming(): boolean;
        setSprinting($$0: boolean): void;
        mayInteract($$0: Internal.Level_, $$1: BlockPos_): boolean;
        handler$kpc000$porting_lib_entity$port_lib$attackEvent(source: DamageSource_, amount: number, cir: Internal.CallbackInfoReturnable_<any>): void;
        getDynamicLightLevel(): Internal.Level;
        setPortalCooldown(): void;
        getAttackAnim($$0: number): number;
        hex$setLastHurt(arg0: number): void;
        setX(x: number): void;
        getPortalWaitTime(): number;
        getBlockStateOn(): Internal.BlockState;
        wantsToPickUp($$0: Internal.ItemStack_): boolean;
        getItemBySlot($$0: Internal.EquipmentSlot_): Internal.ItemStack;
        getFluidHeightLoosely(tag: Internal.TagKey_<any>): number;
        method_5776(): boolean;
        getFluidJumpThreshold(): number;
        handler$elg000$crittersandcompanions$onRegisterGoals(callback: Internal.CallbackInfo_): void;
        getCachedSouls(): number;
        "setPositionAndRotation(double,double,double,float,float)"($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        isInvisibleTo($$0: Internal.Player_): boolean;
        stopSleeping(): void;
        setAirSupply($$0: number): void;
        getOnPos(): BlockPos;
        etf$getWorld(): Internal.Level;
        isUndead(): boolean;
        static createLivingAttributes(): Internal.AttributeSupplier$Builder;
        setUseItemRemaining(arg0: number): void;
        pehkui_getScales(): Internal.Map<any, any>;
        getTargetSelector(): Internal.GoalSelector;
        setRegisteredToWorld(navigation: Internal.PathNavigation_): void;
        isSleeping(): boolean;
        stopUsingItem(): void;
        etf$getNbt(): Internal.CompoundTag;
        acceptsFailure(): boolean;
        etf$getBlockPos(): BlockPos;
        pehkui_setShouldIgnoreScaleNbt(ignore: boolean): void;
        setOnGroundWithKnownMovement($$0: boolean, $$1: Vec3d_): void;
        getFluidFallingAdjustedMovement($$0: number, $$1: boolean, $$2: Vec3d_): Vec3d;
        setOldPosAndRot(): void;
        static createMonsterAttributes(): Internal.AttributeSupplier$Builder;
        localvar$cjk000$bettertridents$doHurtTarget$modifyVariable$store(damageAmount: number, entity: Internal.Entity_): number;
        isFree($$0: number, $$1: number, $$2: number): boolean;
        getDismountPoses(): Internal.ImmutableList<Internal.Pose>;
        getLastHurtMobTimestamp(): number;
        lithiumOnEquipmentChanged(): void;
        "moveTo(double,double,double)"($$0: number, $$1: number, $$2: number): void;
        setRemainingFireTicks($$0: number): void;
        emf$age(): number;
        etf$hasCustomName(): boolean;
        /**
         * @deprecated
        */
        getOnPosLegacy(): BlockPos;
        port_lib$isJumping(): boolean;
        setPos($$0: Vec3d_): void;
        localvar$leb000$puzzleslib$knockback$2(ratioX: number): number;
        static "tickEntity(net.minecraft.world.entity.LivingEntity)"(entity: Internal.LivingEntity_): void;
        updateCachedSouls(): void;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        setCanPickUpLoot($$0: boolean): void;
        getMainHandItem(): Internal.ItemStack;
        handler$kom000$porting_lib_entity$port_lib$removeRidingEntity(ci: Internal.CallbackInfo_): void;
        setSilent($$0: boolean): void;
        captureDrops(): Internal.Collection<Internal.ItemEntity>;
        hasExactlyOnePlayerPassenger(): boolean;
        canBeSeenAsEnemy(): boolean;
        setLeftHanded($$0: boolean): void;
        getActiveEffects(): Internal.Collection<Internal.MobEffectInstance>;
        isOnPortalCooldown(): boolean;
        hurtArmor($$0: DamageSource_, $$1: number): void;
        canAttack($$0: Internal.LivingEntity_, $$1: Internal.TargetingConditions_): boolean;
        getAttributeValue($$0: Internal.Holder_<Internal.Attribute>): number;
        lambdynlights$setTrackedLitChunkPos(trackedLitChunkPos: Internal.LongSet_): void;
        fzzy_core_setModifierContainer(container: Internal.ModifierContainer_): void;
        setPitch($$0: number): void;
        setPosRaw($$0: number, $$1: number, $$2: number): void;
        handleEntityEvent($$0: number): void;
        isUsingItem(): boolean;
        isAlwaysTicking(): boolean;
        interactAt($$0: Internal.Player_, $$1: Vec3d_, $$2: Internal.InteractionHand_): Internal.InteractionResult;
        emf$getX(): number;
        puzzleslib$acceptCapturedDrops(capturedDrops: Internal.Collection_<any>): Internal.Collection<any>;
        handler$hak000$gobber2$gobberIsFireImmune(cir: Internal.CallbackInfoReturnable_<any>): void;
        lerpTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: boolean): void;
        onPassengerTurned($$0: Internal.Entity_): void;
        modifyReturnValue$zhe000$additionalentityattributes$getMaxAir(original: number): number;
        spawnAtLocation($$0: Internal.ItemLike_): Internal.ItemEntity;
        emf$hasPassengers(): boolean;
        serializeNBT(): Internal.CompoundTag;
        setAttached(type: Internal.AttachmentType_<any>, value: any): any;
        port_lib$getEntityString(): string;
        markEffectsDirty(): void;
        lithiumOnBlockCacheDeleted(): void;
        "spawnAtLocation(net.minecraft.world.level.ItemLike,int)"($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        setInvulnerable($$0: boolean): void;
        push($$0: Internal.Entity_): void;
        emf$hasVehicle(): boolean;
        maxUpStep(): number;
        getDynamicLightPrevY(): number;
        localvar$leb000$puzzleslib$hurt$1(amount: number, source: DamageSource_): number;
        setGlowing($$0: boolean): void;
        load($$0: Internal.CompoundTag_): void;
        "broadcastBreakEvent(net.minecraft.world.entity.EquipmentSlot)"($$0: Internal.EquipmentSlot_): void;
        setLeashedTo($$0: Internal.Entity_, $$1: boolean): void;
        isAlive(): boolean;
        startSleeping($$0: BlockPos_): void;
        getBbHeight(): number;
        getMeleeAttackRangeSqr($$0: Internal.LivingEntity_): number;
        handler$fed002$extraalchemy$readNbt(tag: Internal.CompoundTag_, cb: Internal.CallbackInfo_): void;
        bookshelf$getDrinkingSound(arg0: Internal.ItemStack_): Internal.SoundEvent;
        getTags(): Internal.Set<string>;
        getViewVector($$0: number): Vec3d;
        getLastAttacker(): Internal.LivingEntity;
        hasControllingPassenger(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number, $$2: number): boolean;
        absMoveTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        getLastRollTicks(): number;
        getGoalSelector(): Internal.GoalSelector;
        localvar$leb000$puzzleslib$causeFallDamage$2(damageMultiplier: number): number;
        onPathfindingStart(): void;
        handler$zzb000$porting_lib_attributes$port_lib$entityGravity(travelVector: Vec3d_, ci: Internal.CallbackInfo_): void;
        getPercentFrozen(): number;
        setPortalCooldown($$0: number): void;
        hasGlowingTag(): boolean;
        shouldBlockExplode($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: number): boolean;
        emf$isInvisible(): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        isLeashed(): boolean;
        addEffect($$0: Internal.MobEffectInstance_): boolean;
        emf$isSprinting(): boolean;
        handler$leb000$puzzleslib$knockback$0(strength: number, ratioX: number, ratioZ: number, callback: Internal.CallbackInfo_): void;
        handler$egi000$collective$LivingEntity_tick(ci: Internal.CallbackInfo_): void;
        handler$gec000$faster_entity_animations$getLeaningPitch(f: number, info: Internal.CallbackInfoReturnable_<any>): void;
        canRiderInteract(): boolean;
        getViewXRot($$0: number): number;
        handler$leb001$puzzleslib$die(damageSource: DamageSource_, callback: Internal.CallbackInfo_): void;
        fabric_getAttachments(): Internal.Map<any, any>;
        setPose($$0: Internal.Pose_): void;
        getReachDistance(): number;
        getEntityType(): Internal.EntityType<any>;
        isWaterCreature(): boolean;
        hex$playHurtSound(arg0: DamageSource_): void;
        pehkui_getScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        toString(): string;
        etf$getScoreboardTeam(): Internal.Team;
        setLastHurtByPlayer($$0: Internal.Player_): void;
        handler$ldh000$puzzleslib$removeVehicle(callback: Internal.CallbackInfo_): void;
        "getServer()"(): Internal.MinecraftServer;
        wasExperienceConsumed(): boolean;
        isPushable(): boolean;
        setYBodyRot($$0: number): void;
        foodEaten(is: Internal.ItemStack_): void;
        onClientRemoval(): void;
        getDistance(x: number, y: number, z: number): number;
        setMotionY(y: number): void;
        static createAttributes(): Internal.AttributeSupplier$Builder;
        getAttached(type: Internal.AttachmentType_<any>): any;
        setRotation(yaw: number, pitch: number): void;
        setLimitedLife($$0: number): void;
        isDynamicLightEnabled(): boolean;
        handler$ldh000$puzzleslib$startRiding(vehicle: Internal.Entity_, force: boolean, callback: Internal.CallbackInfoReturnable_<any>): void;
        setIsCharging($$0: boolean): void;
        calculateEntityAnimation($$0: boolean): void;
        forceAddEffect($$0: Internal.MobEffectInstance_, $$1: Internal.Entity_): void;
        setChestArmorItem(item: Internal.ItemStack_): void;
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        bookshelf$getHurtSound(arg0: DamageSource_): Internal.SoundEvent;
        onAboveBubbleCol($$0: boolean): void;
        archon$setOwner(uiud: string): void;
        "playSound(net.minecraft.sounds.SoundEvent,float,float)"(id: Internal.SoundEvent_, volume: number, pitch: number): void;
        toComponentPacket(key: Internal.ComponentKey_<any>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        isPassenger(): boolean;
        hasPose($$0: Internal.Pose_): boolean;
        supp$setSlimedTicks(newSlimedTicks: number, sync: boolean): void;
        isEyeInFluid($$0: Internal.TagKey_<Internal.Fluid>): boolean;
        isInvulnerableTo($$0: DamageSource_): boolean;
        makeStuckInBlock($$0: Internal.BlockState_, $$1: Vec3d_): void;
        getAttachedOrGet<A>(type: Internal.AttachmentType_<A>, defaultValue: Internal.Supplier_<A>): A;
        isSensitiveToWater(): boolean;
        skipAttackInteraction($$0: Internal.Entity_): boolean;
        lerpMotion($$0: number, $$1: number, $$2: number): void;
        "getAttributeValue(net.minecraft.core.Holder)"($$0: Internal.Holder_<Internal.Attribute>): number;
        shouldRender($$0: number, $$1: number, $$2: number): boolean;
        getJumpControl(): Internal.JumpControl;
        localvar$zcl000$porting_lib_base$port_lib$setSlipperiness(p: number): number;
        getFeetArmorItem(): Internal.ItemStack;
        handler$bia000$axiom$onTurn(d: number, e: number, ci: Internal.CallbackInfo_): void;
        static getViewScale(): number;
        handler$mpg000$tcdcommons$onAddStatusEffect(effect: Internal.MobEffectInstance_, source: Internal.Entity_, ci: Internal.CallbackInfoReturnable_<any>): void;
        getVisualRotationYInDegrees(): number;
        setSpeed($$0: number): void;
        requiresCustomPersistence(): boolean;
        handler$nbm000$things$onShieldHit(attacker: Internal.LivingEntity_, ci: Internal.CallbackInfo_): void;
        isDiscrete(): boolean;
        unRide(): void;
        getLevel(): Internal.Level;
        "spawnAtLocation(net.minecraft.world.item.ItemStack)"($$0: Internal.ItemStack_): Internal.ItemEntity;
        getCombatTracker(): Internal.CombatTracker;
        updateDynamicGameEventListener($$0: Internal.BiConsumer_<Internal.DynamicGameEventListener<any>, Internal.ServerLevel>): void;
        "onSyncedDataUpdated(net.minecraft.network.syncher.EntityDataAccessor)"($$0: Internal.EntityDataAccessor_<any>): void;
        emf$prevY(): number;
        isNoAi(): boolean;
        extinguishFire(): void;
        getChestArmorItem(): Internal.ItemStack;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number): void;
        port_lib$lastPos(): BlockPos;
        tell(message: net.minecraft.network.chat.Component_): void;
        closerThan($$0: Internal.Entity_, $$1: number): boolean;
        hex$getSoundVolume(): number;
        getDistanceSq(pos: BlockPos_): number;
        indicateDamage($$0: number, $$1: number): void;
        localvar$nbm000$things$waxGlandWater(j: number): number;
        canBeSeenByAnyone(): boolean;
        emf$getTypeString(): string;
        isFullyFrozen(): boolean;
        litematica_setWorld(arg0: Internal.Level_): void;
        isInWall(): boolean;
        getAllSlots(): Internal.Iterable<Internal.ItemStack>;
        handler$bfg003$artifacts$tick(ci: Internal.CallbackInfo_): void;
        remove($$0: Internal.Entity$RemovalReason_): void;
        getScale(): number;
        isSuppressingSlidingDownLadder(): boolean;
        getBlockZ(): number;
        handler$egi000$collective$LivingEntity_die(damageSource: DamageSource_, ci: Internal.CallbackInfo_): void;
        dampensVibrations(): boolean;
        hasAttached(type: Internal.AttachmentType_<any>): boolean;
        isSilent(): boolean;
        setUseItem(arg0: Internal.ItemStack_): void;
        "playSound(net.minecraft.sounds.SoundEvent)"($$0: Internal.SoundEvent_): void;
        getPitch(): number;
        getPathfindingMalus($$0: Internal.BlockPathTypes_): number;
        modify$nbm000$things$waxGlandLava(speed: number): number;
        getRandom(): Internal.RandomSource;
        canReplaceEqualItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        rotate($$0: Internal.Rotation_): number;
        handler$hcn000$hexcasting$onThunderHit(entityType: Internal.EntityType_<any>, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        getPassengersAndSelf(): Internal.Stream<any>;
        handler$leb000$puzzleslib$causeFallDamage$0(distance: number, damageMultiplier: number, damageSource: DamageSource_, callback: Internal.CallbackInfoReturnable_<any>): void;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        "getAttributeBaseValue(net.minecraft.core.Holder)"($$0: Internal.Holder_<Internal.Attribute>): number;
        method_5652($$0: Internal.CompoundTag_): void;
        clearRestriction(): void;
        redirect$jgg000$moonlight$fixSpawnAnimX(instance: Internal.Mob_, v: number): number;
        getOriginalFoodStack(): Internal.ItemStack;
        getBoundOrigin(): BlockPos;
        rayTrace(): Internal.RayTraceResultJS;
        alwaysAccepts(): boolean;
        "isHolding(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.ItemStack>): boolean;
        getNoActionTime(): number;
        isVisuallyCrawling(): boolean;
        isAggressive(): boolean;
        setYya($$0: number): void;
        setDropChance($$0: Internal.EquipmentSlot_, $$1: number): void;
        handler$ieb000$lambdynlights$onRemove(ci: Internal.CallbackInfo_): void;
        "broadcastBreakEvent(net.minecraft.world.InteractionHand)"($$0: Internal.InteractionHand_): void;
        port_lib$setRemovalReason(arg0: Internal.Entity$RemovalReason_): void;
        teleportRelative($$0: number, $$1: number, $$2: number): void;
        setBaby($$0: boolean): void;
        getLastHurtByMob(): Internal.LivingEntity;
        pehkui_setScaleCache(scaleCache: Internal.ScaleData_[]): void;
        isInWaterOrBubble(): boolean;
        getPortalCooldown(): number;
        getItem(): Internal.ItemStack;
        causeFallDamage($$0: number, $$1: number, $$2: DamageSource_): boolean;
        getDynamicLightChunksToRebuild(forced: boolean): Internal.LongSet;
        releaseUsingItem(): void;
        bw_getNextAirOnLand(arg0: number): number;
        getPosition($$0: number): Vec3d;
        removeFreeWill(): void;
        handler$leb000$puzzleslib$removeAllEffects(callback: Internal.CallbackInfoReturnable_<any>): void;
        removeWhenFarAway($$0: number): boolean;
        wait(arg0: number): void;
        isIgnoringBlockTriggers(): boolean;
        setRecordPlayingNearby($$0: BlockPos_, $$1: boolean): void;
        etf$getItemsEquipped(): Internal.Iterable<any>;
        getHandHoldingItemAngle($$0: Internal.Item_): Vec3d;
        hasItemInSlot($$0: Internal.EquipmentSlot_): boolean;
        distanceToSqr($$0: Vec3d_): number;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        modifyAttached<A>(type: Internal.AttachmentType_<A>, modifier: Internal.UnaryOperator_<A>): A;
        isSteppingCarefully(): boolean;
        handler$zno000$apoli$doSpiderClimbing(info: Internal.CallbackInfoReturnable_<any>): void;
        "spawnAtLocation(net.minecraft.world.item.ItemStack,float)"($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        getLightLevelDependentMagicValue(): number;
        getBlockX(): number;
        isFallFlying(): boolean;
        getEncodeId(): string;
        puzzleslib$getSpawnType(): Internal.MobSpawnType;
        bettertrims$setAvoidedDamage(avoidDamage: boolean): void;
        getY($$0: number): number;
        emf$prevPitch(): number;
        getMaxHeadXRot(): number;
        getNbt(): Internal.CompoundTag;
        setInvisible($$0: boolean): void;
        etf$getArmorItems(): Internal.Iterable<any>;
        isSubmergedInLoosely(tag: Internal.TagKey_<any>): boolean;
        getEffect($$0: Internal.MobEffect_): Internal.MobEffectInstance;
        setTotalMovementSpeedMultiplier(speed: number): void;
        getDynamicLightY(): number;
        setHealth($$0: number): void;
        attack($$0: DamageSource_, $$1: number): boolean;
        onInsideBubbleColumn($$0: boolean): void;
        handler$cfa000$betterend$be_hurt(source: DamageSource_, amount: number, info: Internal.CallbackInfoReturnable_<any>): void;
        getEyePosition(): Vec3d;
        getEyeHeight(): number;
        setDiscardFriction($$0: boolean): void;
        hasPassenger($$0: Internal.Predicate_<Internal.Entity>): boolean;
        bettertridents$getLastDamageSource(): DamageSource;
        getYaw(): number;
        swing($$0: Internal.InteractionHand_, $$1: boolean): void;
        getUsedItemHand(): Internal.InteractionHand;
        setDefaultMovementSpeed(speed: number): void;
        canAttackType($$0: Internal.EntityType_<any>): boolean;
        hex$setLastDamageStamp(arg0: number): void;
        canEntityBeSeen(entity: Internal.LivingEntity_): boolean;
        modifyExpressionValue$zhf000$additionalentityattributes$additionalEntityAttributes$knockDownwards(original: number): number;
        getBrain(): Internal.Brain<any>;
        modify$bpk000$bclib$be_travel(moveDelta: Vec3d_): Vec3d;
        setCustomNameVisible($$0: boolean): void;
        isAlliedTo($$0: Internal.Team_): boolean;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>): A;
        canFireProjectileWeapon($$0: Internal.ProjectileWeaponItem_): boolean;
        getControllingPassenger(): Internal.LivingEntity;
        bw_getNextAirUnderwater(arg0: number): number;
        getScriptType(): Internal.ScriptType;
        handler$leb000$puzzleslib$releaseUsingItem(callback: Internal.CallbackInfo_): void;
        handler$cbm000$besmirchment$handleStatus(status: number, ci: Internal.CallbackInfo_): void;
        port_lib$getDeathSound(): Internal.SoundEvent;
        shouldDiscardFriction(): boolean;
        startRiding($$0: Internal.Entity_): boolean;
        saveWithoutId($$0: Internal.CompoundTag_): Internal.CompoundTag;
        getForward(): Vec3d;
        setFeetArmorItem(item: Internal.ItemStack_): void;
        getId(): number;
        pehkui_isFirstUpdate(): boolean;
        canBeHitByProjectile(): boolean;
        getRecipientsForComponentSync(): Internal.Iterable<any>;
        handler$zcl000$porting_lib_base$port_lib$onUsingTick(ci: Internal.CallbackInfo_): void;
        getEyeY(): number;
        handler$ham000$gobber2$gobberClimbing(cir: Internal.CallbackInfoReturnable_<any>): void;
        skipDropExperience(): void;
        fabric_readAttachmentsFromNbt(nbt: Internal.CompoundTag_): void;
        localvar$leb000$puzzleslib$getVisibilityPercent(value: number, lookingEntity: Internal.Entity_): number;
        getBoundingBox(): Internal.AABB;
        isInWaterOrRain(): boolean;
        handler$leb000$puzzleslib$die$1(damageSource: DamageSource_, callback: Internal.CallbackInfo_): void;
        setOwner($$0: Internal.Mob_): void;
        setItemSlot($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_): void;
        equals($$0: any): boolean;
        getViewYRot($$0: number): number;
        fabric_setCustomTeleportTarget(teleportTarget: Internal.PortalInfo_): void;
        dismountsUnderwater(): boolean;
        isAffectedByPotions(): boolean;
        playerTouch($$0: Internal.Player_): void;
        addTag($$0: string): boolean;
        getEyeHeight($$0: Internal.Pose_): number;
        getAddEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>;
        callIsBeingRainedOn(): boolean;
        static getEquipmentForSlot($$0: Internal.EquipmentSlot_, $$1: number): Internal.Item;
        isWithinRestriction($$0: BlockPos_): boolean;
        getTeam(): Internal.Team;
        static of(entity: Internal.LivingEntity_): Internal.EntityProperties;
        setTicksFrozen($$0: number): void;
        getUseItem(): Internal.ItemStack;
        getMyRidingOffset(): number;
        handler$hal000$gobber2$gobberCanBreatheInWater(cir: Internal.CallbackInfoReturnable_<any>): void;
        dismountTo($$0: number, $$1: number, $$2: number): void;
        etf$getEntityKey(): string;
        etf$getPose(): Internal.Pose;
        hasCustomName(): boolean;
        getSwimAmount($$0: number): number;
        isLiving(): boolean;
        getX(): number;
        isVehicle(): boolean;
        static transfer(original: Internal.AttachmentTarget_, target: Internal.AttachmentTarget_, isDeath: boolean): void;
        bettertrims$didAvoidDamage(): boolean;
        resetDynamicLight(): void;
        handler$han000$gobber2$gobberSetTarget(target: Internal.LivingEntity_, ci: Internal.CallbackInfo_): void;
        handler$kpc001$porting_lib_entity$onJump(ci: Internal.CallbackInfo_): void;
        spawnAtLocation($$0: Internal.ItemStack_): Internal.ItemEntity;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        handler$zcl000$porting_lib_base$port_lib$canBeAffected(effect: Internal.MobEffectInstance_, cir: Internal.CallbackInfoReturnable_<any>): void;
        thunderHit($$0: Internal.ServerLevel_, $$1: Internal.LightningBolt_): void;
        setIsInPowderSnow($$0: boolean): void;
        etf$distanceTo(entity: Internal.Entity_): number;
        doEnchantDamageEffects($$0: Internal.LivingEntity_, $$1: Internal.Entity_): void;
        setCustomName($$0: net.minecraft.network.chat.Component_): void;
        lambdynlights$scheduleTrackedChunksRebuild(renderer: Internal.LevelRenderer_): void;
        handler$hak000$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        getTeamId(): string;
        setStingerCount($$0: number): void;
        getMaxHeadYRot(): number;
        isCustomNameVisible(): boolean;
        isSupportedBy($$0: BlockPos_): boolean;
        getPistonPushReaction(): Internal.PushReaction;
        lookAt($$0: Internal.EntityAnchorArgument$Anchor_, $$1: Vec3d_): void;
        handler$kpc000$porting_lib_entity$port_lib$cancelFall(fallDistance: number, multiplier: number, source: DamageSource_, cir: Internal.CallbackInfoReturnable_<any>): void;
        hurtCurrentlyUsedShield($$0: number): void;
        getLootTableSeed(): number;
        collide($$0: Vec3d_): Vec3d;
        getMotionX(): number;
        "onSyncedDataUpdated(java.util.List)"($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        canBeLeashed($$0: Internal.Player_): boolean;
        hasIndirectPassenger($$0: Internal.Entity_): boolean;
        gear_core_setActiveSets(sets: Internal.HashMap_<any, any>): void;
        getEntityData(): Internal.SynchedEntityData;
        bookshelf$getFallDamageSound(arg0: number): Internal.SoundEvent;
        handleInsidePortal($$0: BlockPos_): void;
        getPotionEffects(): Internal.EntityPotionEffectsJS;
        getLastHurtByPlayerTime(): number;
        absMoveTo($$0: number, $$1: number, $$2: number): void;
        handler$cfa000$betterend$be_canBeAffected(mobEffectInstance: Internal.MobEffectInstance_, info: Internal.CallbackInfoReturnable_<any>): void;
        isOnRails(): boolean;
        getAttachedOrThrow<A>(type: Internal.AttachmentType_<A>): A;
        getStingerCount(): number;
        markFusionRecomputeModels(): void;
        getFallSounds(): Internal.LivingEntity$Fallsounds;
        getAttributeTotalValue(attribute: Internal.Attribute_): number;
        getDimensionChangingDelay(): number;
        handler$cbi000$besmirchment$getScoreboardTeam(cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDynamicLuminance(): number;
        setYaw($$0: number): void;
        getPickRadius(): number;
        isPathFinding(): boolean;
        supp$getSlimedTicks(): number;
        isRemoved(): boolean;
        emf$isSneaking(): boolean;
        teleportToWithTicket($$0: number, $$1: number, $$2: number): void;
        spawnAnim(): void;
        getJumpBoostPower(): number;
        fillCrashReportCategory($$0: Internal.CrashReportCategory_): void;
        self(): Internal.Entity;
        refreshDimensions(): void;
        pehkui_writeScaleNbt(nbt: Internal.CompoundTag_): Internal.CompoundTag;
        bookshelf$getAmbientSound(): Internal.SoundEvent;
        "spawnAtLocation(net.minecraft.world.level.ItemLike)"($$0: Internal.ItemLike_): Internal.ItemEntity;
        "getAttributeValue(net.minecraft.world.entity.ai.attributes.Attribute)"($$0: Internal.Attribute_): number;
        "isHolding(net.minecraft.world.item.Item)"($$0: Internal.Item_): boolean;
        setShiftKeyDown($$0: boolean): void;
        getEyePosition($$0: number): Vec3d;
        getPassengers(): Internal.EntityArrayList;
        handler$ldh000$puzzleslib$spawnAtLocation(stack: Internal.ItemStack_, offsetY: number, callback: Internal.CallbackInfoReturnable_<any>, itemEntity: Internal.ItemEntity_): void;
        getZ(): number;
        bettertrims$applyCelestialToAttackCooldown(original: number): number;
        teleportTo($$0: number, $$1: number, $$2: number): void;
        handler$zbk000$porting_lib_base$port_lib$spawnSprintParticle(ci: Internal.CallbackInfo_, pos: BlockPos_, state: Internal.BlockState_): void;
        getAttributeBaseValue($$0: Internal.Holder_<Internal.Attribute>): number;
        getServer(): Internal.MinecraftServer;
        getExperienceReward(): number;
        getFirstPassenger(): Internal.Entity;
        heal($$0: number): void;
        handler$leb01a$puzzleslib$tick(callback: Internal.CallbackInfo_): void;
        setLastHurtMob($$0: Internal.Entity_): void;
        setLastHurtByMob($$0: Internal.LivingEntity_): void;
        interact($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        getDismountLocationForPassenger($$0: Internal.LivingEntity_): Vec3d;
        isCharging(): boolean;
        checkSlowFallDistance(): void;
        getLeashingEntities(): Internal.Set<any>;
        canStandOnFluid($$0: Internal.FluidState_): boolean;
        setFabricBalmData(tag: Internal.CompoundTag_): void;
        touchingUnloadedChunk(): boolean;
        modifyAttribute(attribute: Internal.Attribute_, identifier: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getLookAngle(): Vec3d;
        modifyReturnValue$zhf000$additionalentityattributes$additionalEntityAttributes$modifyJumpVelocity(original: number): number;
        getAmbientSoundInterval(): number;
        emf$isOnFire(): boolean;
        setArrowCount($$0: number): void;
        getMotionZ(): number;
        isPersistenceRequired(): boolean;
        isInvisible(): boolean;
        is($$0: Internal.Entity_): boolean;
        getBedOrientation(): Internal.Direction;
        ejectPassengers(): void;
        removeEffect($$0: Internal.MobEffect_): boolean;
        updateDynamicLightPreviousCoordinates(): void;
        getProfile(): Internal.GameProfile;
        isDeadOrDying(): boolean;
        setHeadArmorItem(item: Internal.ItemStack_): void;
        static setViewScale($$0: number): void;
        emf$isAlive(): boolean;
        take($$0: Internal.Entity_, $$1: number): void;
        setLevelCallback($$0: Internal.EntityInLevelCallback_): void;
        getLookControl(): Internal.LookControl;
        isPreventingPlayerRest($$0: Internal.Player_): boolean;
        redirect$joh000$origins$method_26317Proxy(entity: Internal.LivingEntity_, d: number, bl: boolean, vec3d: Vec3d_): Vec3d;
        playSound($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        canAttack($$0: Internal.LivingEntity_): boolean;
        getOffHandItem(): Internal.ItemStack;
        startSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isOnScoreboardTeam(teamId: string): boolean;
        startUsingItem($$0: Internal.InteractionHand_): void;
        invokePlayEquipmentBreakEffects(arg0: Internal.ItemStack_): void;
        localvar$bbb000$architectury$modifyLevelCallback_setLevelCallback(callback: Internal.EntityInLevelCallback_): Internal.EntityInLevelCallback;
        position(): Vec3d;
        setTimeout(): void;
        static getEquipmentSlotForItem($$0: Internal.ItemStack_): Internal.EquipmentSlot;
        getEquipment(slot: Internal.EquipmentSlot_): Internal.ItemStack;
        displayFireAnimation(): boolean;
        isOutOfCamera(): boolean;
        getRopeHoldPosition($$0: number): Vec3d;
        copyPosition($$0: Internal.Entity_): void;
        "hasPassenger(net.minecraft.world.entity.Entity)"($$0: Internal.Entity_): boolean;
        extraalchemy_spawnParticles(arg0: Internal.ItemStack_, arg1: number): void;
        etf$canBeBright(): boolean;
        isCrouching(): boolean;
        "getAttributeBaseValue(net.minecraft.world.entity.ai.attributes.Attribute)"($$0: Internal.Attribute_): number;
        onLeaveCombat(): void;
        wrapOperation$bgd000$artifacts$travel(block: Internal.Block_, original: Internal.Operation_<any>): number;
        setY(y: number): void;
        getAttributeValue($$0: Internal.Attribute_): number;
        getFeetBlockState(): Internal.BlockState;
        archon$isOwner(player: Internal.Player_): boolean;
        isWithinRestriction(): boolean;
        getChangeListener(): Internal.EntityInLevelCallback;
        positionRider($$0: Internal.Entity_): void;
        baseTick(): void;
        broadcastToPlayer($$0: Internal.ServerPlayer_): boolean;
        setSharedFlag($$0: number, $$1: boolean): void;
        getSleepingPos(): Optional<BlockPos>;
        damageHeldItem(): void;
        getCustomName(): net.minecraft.network.chat.Component;
        getClass(): typeof any;
        isVisuallySwimming(): boolean;
        getMaxAirSupply(): number;
        handler$zcl000$porting_lib_base$port_lib$addEffect(newEffect: Internal.MobEffectInstance_, source: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>, oldEffect: Internal.MobEffectInstance_): void;
        setItemInHand($$0: Internal.InteractionHand_, $$1: Internal.ItemStack_): void;
        dynamicLightTick(): void;
        setMaxHealth(hp: number): void;
        getFacing(): Internal.Direction;
        emf$isWet(): boolean;
        isPassengerOfSameVehicle($$0: Internal.Entity_): boolean;
        getBoundingBoxForCulling(): Internal.AABB;
        getTarget(): Internal.LivingEntity;
        static collideBoundingBox(entity: Internal.Entity_, movement: Vec3d_, entityBoundingBox: Internal.AABB_, world: Internal.Level_, collisions: Internal.List_<any>): Vec3d;
        fzzy_core_getModifierContainer(): Internal.ModifierContainer;
        restrictTo($$0: BlockPos_, $$1: number): void;
        trackingPosition(): Vec3d;
        getNameTagOffsetY(): number;
        isInvulnerable(): boolean;
        isInLava(): boolean;
        isInWater(): boolean;
        awardKillScore($$0: Internal.Entity_, $$1: number, $$2: DamageSource_): void;
        finalizeSpawn($$0: Internal.ServerLevelAccessor_, $$1: Internal.DifficultyInstance_, $$2: Internal.MobSpawnType_, $$3: Internal.SpawnGroupData_, $$4: Internal.CompoundTag_): Internal.SpawnGroupData;
        localvar$leb000$puzzleslib$knockback$3(ratioZ: number): number;
        unsetRemoved(): void;
        pehkui_getScaleCache(): Internal.ScaleData[];
        swing($$0: Internal.InteractionHand_): void;
        hasEffect($$0: Internal.MobEffect_): boolean;
        getHeldItem(hand: Internal.InteractionHand_): Internal.ItemStack;
        setFusionModel(layerIndex: number, model: Internal.Triple_<any, any, any>): void;
        getRootVehicle(): Internal.Entity;
        onPathfindingDone(): void;
        save($$0: Internal.CompoundTag_): boolean;
        archon$setLifetime(seconds: number): void;
        modify$zhf000$additionalentityattributes$additionalEntityAttributes$waterSpeed(original: number): number;
        getLocalBoundsForPose($$0: Internal.Pose_): Internal.AABB;
        isNoGravity(): boolean;
        dodge(chance: number): boolean;
        onItemPickup($$0: Internal.ItemEntity_): void;
        hex$setLastDamageSource(arg0: DamageSource_): void;
        emf$getY(): number;
        handler$kom000$porting_lib_entity$port_lib$entityInit(entityType: Internal.EntityType_<any>, world: Internal.Level_, ci: Internal.CallbackInfo_): void;
        bookshelf$createHoverEvent(): Internal.HoverEvent;
        updateSwimming(): void;
        isHolding($$0: Internal.Predicate_<Internal.ItemStack>): boolean;
        getSpeed(): number;
        abstract getCachedFeetBlockState(): Internal.BlockState;
        shouldInformAdmins(): boolean;
        rideTick(): void;
        port_lib$onEffectRemoved(arg0: Internal.MobEffectInstance_): void;
        handler$zll000$amethyst_imbuement$onAttackWhilstStunnedNoTarget(hand: Internal.InteractionHand_, ci: Internal.CallbackInfo_): void;
        wait(): void;
        getUuid(): Internal.UUID;
        "getOwner()"(): Internal.Mob;
        setOffHandItem(item: Internal.ItemStack_): void;
        spawn(): void;
        setNoAi($$0: boolean): void;
        teleportTo($$0: Internal.ServerLevel_, $$1: number, $$2: number, $$3: number, $$4: Internal.Set_<Internal.RelativeMovement>, $$5: number, $$6: number): boolean;
        etf$getCustomName(): net.minecraft.network.chat.Component;
        fabric_writeAttachmentsToNbt(nbt: Internal.CompoundTag_): void;
        shouldShowName(): boolean;
        getArmorSlots(): Internal.Iterable<Internal.ItemStack>;
        canPickUpLoot(): boolean;
        kill(): void;
        onEnterCombat(): void;
        updateNavigationRegistration(): void;
        animateHurt($$0: number): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        handler$kom000$porting_lib_entity$port_lib$onEntityRemove(reason: Internal.Entity$RemovalReason_, ci: Internal.CallbackInfo_): void;
        static resetForwardDirectionOfRelativePortalPosition($$0: Vec3d_): Vec3d;
        callGetEyeHeight(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        hasRestriction(): boolean;
        getHeadArmorItem(): Internal.ItemStack;
        deserializeNBT(arg0: Internal.Tag_): void;
        getCurrentModifyFoodPowers(): Internal.List<any>;
        getBbWidth(): number;
        splitIntoDynamicLightEntries(): Internal.Stream<Internal.SpatialLookupEntry>;
        static checkAnyLightMonsterSpawnRules($$0: Internal.EntityType_<Internal.Monster>, $$1: Internal.LevelAccessor_, $$2: Internal.MobSpawnType_, $$3: BlockPos_, $$4: Internal.RandomSource_): boolean;
        addDeltaMovement($$0: Vec3d_): void;
        pehkui_setOnGround(onGround: boolean): void;
        localvar$leb000$puzzleslib$knockback$1(strength: number): number;
        bettertrims$addLateAttributes(adder: Internal.Consumer_<any>): void;
        handler$lef000$puzzleslib$readAdditionalSaveData(compound: Internal.CompoundTag_, callback: Internal.CallbackInfo_): void;
        sendLeashState(): void;
        "getName()"(): net.minecraft.network.chat.Component;
        mirror($$0: Internal.Mirror_): number;
        static port_lib$collideWithShapes(vec3: Vec3d_, aABB: Internal.AABB_, list: Internal.List_<Internal.VoxelShape>): Vec3d;
        knockback($$0: number, $$1: number, $$2: number): void;
        getTicksRequiredToFreeze(): number;
        getVisibilityPercent($$0: Internal.Entity_): number;
        getMaxSpawnClusterSize(): number;
        localvar$kpc000$porting_lib_entity$port_lib$modifyDistance(fallDistance: number): number;
        artifacts$getPocketPistonLength(): number;
        emf$prevZ(): number;
        getUsername(): string;
        move($$0: Internal.MoverType_, $$1: Vec3d_): void;
        lithiumOnBlockCacheSet(newState: Internal.BlockState_): void;
        isPickable(): boolean;
        setYHeadRot($$0: number): void;
        setJumping($$0: boolean): void;
        getCustomData(): Internal.CompoundTag;
        handler$zno000$apoli$getGroup(info: Internal.CallbackInfoReturnable_<any>): void;
        getPickResult(): Internal.ItemStack;
        "getMainHandItem()"(): Internal.ItemStack;
        getAbsorptionAmount(): number;
        getRandomY(): number;
        onEffectRemoved($$0: Internal.MobEffectInstance_): void;
        getDisplayName(): net.minecraft.network.chat.Component;
        static "tickEntity(net.minecraft.world.entity.Entity)"(entity: Internal.Entity_): void;
        getMobType(): Internal.MobType;
        travel($$0: Vec3d_): void;
        getItemInHand($$0: Internal.InteractionHand_): Internal.ItemStack;
        localvar$leb000$puzzleslib$hurt$0(amount: number, source: DamageSource_): number;
        getDynamicLightPrevX(): number;
        shouldBeSaved(): boolean;
        fabric_hasPersistentAttachments(): boolean;
        method_5749($$0: Internal.CompoundTag_): void;
        hurtHelmet($$0: DamageSource_, $$1: number): void;
        removeTag($$0: string): boolean;
        isHoldingInAnyHand(i: Internal.Ingredient_): boolean;
        getFluidHeight($$0: Internal.TagKey_<Internal.Fluid>): number;
        canSpawnSoulSpeedParticle(): boolean;
        notifyAll(): void;
        aiStep(): void;
        handler$leb000$puzzleslib$removeEffect(effect: Internal.MobEffect_, callback: Internal.CallbackInfoReturnable_<any>): void;
        getPassengersRidingOffset(): number;
        setAttributeBaseValue(attribute: Internal.Attribute_, value: number): void;
        distanceToEntitySqr($$0: Internal.Entity_): number;
        isFrame(): boolean;
        broadcastBreakEvent($$0: Internal.InteractionHand_): void;
        setLegsArmorItem(item: Internal.ItemStack_): void;
        localvar$leb000$puzzleslib$causeFallDamage$1(fallDistance: number): number;
        discard(): void;
        "handler$mhe000$step-height-entity-attribute$getStepHeight"(cir: Internal.CallbackInfoReturnable_<any>): void;
        sendSystemMessage($$0: net.minecraft.network.chat.Component_): void;
        acceptsSuccess(): boolean;
        static tickEntity(entity: Internal.LivingEntity_): void;
        setNoGravity($$0: boolean): void;
        getUseItemRemainingTicks(): number;
        gear_core_getActiveSets(): Internal.HashMap<any, any>;
        getIndirectPassengers(): Internal.Iterable<any>;
        attackable(): boolean;
        createCommandSourceStack(): Internal.CommandSourceStack;
        getNavigation(): Internal.PathNavigation;
        isControlledByLocalInstance(): boolean;
        isMonster(): boolean;
        pehkui_setShouldSyncScales(sync: boolean): void;
        handler$cbm000$besmirchment$canTarget(type: Internal.EntityType_<any>, cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastClimbablePos(): Optional<BlockPos>;
        getEatingSound($$0: Internal.ItemStack_): Internal.SoundEvent;
        setLastDynamicLuminance(luminance: number): void;
        getPerceivedTargetDistanceSquareForMeleeAttack($$0: Internal.LivingEntity_): number;
        setId($$0: number): void;
        onSyncedDataUpdated($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        getHorizontalFacing(): Internal.Direction;
        getType(): string;
        isDamageSourceBlocked($$0: DamageSource_): boolean;
        getLightProbePosition($$0: number): Vec3d;
        getActiveEffectsMap(): Internal.Map<Internal.MobEffect, Internal.MobEffectInstance>;
        wrapOperation$mac000$smarterfarmers$smarterFarmers$overrideMobGriefing(instance: Internal.GameRules_, key: Internal.GameRules$Key_<any>, original: Internal.Operation_<any>): boolean;
        emf$prevX(): number;
        onEquipItem($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_, $$2: Internal.ItemStack_): void;
        static isDarkEnoughToSpawn($$0: Internal.ServerLevelAccessor_, $$1: BlockPos_, $$2: Internal.RandomSource_): boolean;
        checkDespawn(): void;
        pehkui_shouldSyncScales(): boolean;
        getWalkTargetValue($$0: BlockPos_, $$1: Internal.LevelReader_): number;
        lookAt($$0: Internal.Entity_, $$1: number, $$2: number): void;
        setHeldItem(hand: Internal.InteractionHand_, item: Internal.ItemStack_): void;
        port_lib$maybeDisableShield(arg0: Internal.Player_, arg1: Internal.ItemStack_, arg2: Internal.ItemStack_): void;
        equipItemIfPossible($$0: Internal.ItemStack_): Internal.ItemStack;
        onSyncedDataUpdated($$0: Internal.EntityDataAccessor_<any>): void;
        lerpHeadTo($$0: number, $$1: number): void;
        canDisableShield(): boolean;
        setMotionX(x: number): void;
        getHandSlots(): Internal.Iterable<Internal.ItemStack>;
        distanceToEntity($$0: Internal.Entity_): number;
        bookshelf$getDeathSound(): Internal.SoundEvent;
        wait(arg0: number, arg1: number): void;
        getTeamColor(): number;
        lithiumSetClimbingMobCachingSectionUpdateBehavior(listenForCachedBlockChanges: boolean): void;
        setNbt(nbt: Internal.CompoundTag_): void;
        lambdynlights$getTrackedLitChunkPos(): Internal.LongSet;
        checkSpawnObstruction($$0: Internal.LevelReader_): boolean;
        getRecallPosition(): Internal.DimensionalPosition;
        extinguish(): void;
        setDynamicLightEnabled(enabled: boolean): void;
        getRestrictRadius(): number;
        moveTo($$0: Vec3d_): void;
        isColliding($$0: BlockPos_, $$1: Internal.BlockState_): boolean;
        "swing(net.minecraft.world.InteractionHand)"(hand: Internal.InteractionHand_): void;
        lambdynlights$updateDynamicLight(renderer: Internal.LevelRenderer_): boolean;
        getRegisteredNavigation(): Internal.PathNavigation;
        bettertrims$isWearing(effect: Internal.TrimEffect_): boolean;
        static port_lib$collideWithShapes$porting_lib_accessors_$md$424943$0(arg0: Vec3d_, arg1: Internal.AABB_, arg2: Internal.List_<any>): Vec3d;
        isForcedVisible(): boolean;
        isInvertedHealAndHarm(): boolean;
        handler$jon000$origins$doWaterBreathing(info: Internal.CallbackInfoReturnable_<any>): void;
        canHoldItem($$0: Internal.ItemStack_): boolean;
        killedEntity($$0: Internal.ServerLevel_, $$1: Internal.LivingEntity_): boolean;
        getAttachedOrElse<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        isFreezing(): boolean;
        runCommand(command: string): number;
        hex$getDeathSound(): Internal.SoundEvent;
        setGuaranteedDrop($$0: Internal.EquipmentSlot_): void;
        setSharedFlagOnFire($$0: boolean): void;
        set defaultMovementSpeedMultiplier(speed: number)
        get suppressingBounce(): boolean
        set target($$0: Internal.LivingEntity_)
        set culled(value: boolean)
        get onFire(): boolean
        get positionCodec(): Internal.VecDeltaCodec
        set maxUpStep($$0: number)
        get fallFlyingTicks(): number
        set xxa($$0: number)
        set delayedLeashHolderId($$0: number)
        get shiftKeyDown(): boolean
        set UUID($$0: Internal.UUID_)
        set motionZ(z: number)
        get blockY(): number
        get isInsideStructureTracker(): Internal.IsInsideStructureTracker
        set playerHitTimer(arg0: number)
        get spectator(): boolean
        set mainHandItem(item: Internal.ItemStack_)
        get persistentData(): Internal.CompoundTag
        get health(): number
        get maxHealth(): number
        get registeredToWorld(): boolean
        set aggressive($$0: boolean)
        set removed($$0: Internal.Entity$RemovalReason_)
        get inWaterRainOrBubble(): boolean
        get removalReason(): Internal.Entity$RemovalReason
        set boundingBox($$0: Internal.AABB_)
        get ambientCreature(): boolean
        set zza($$0: number)
        get block(): Internal.BlockContainerJS
        get name(): net.minecraft.network.chat.Component
        get controlledVehicle(): Internal.Entity
        get armorValue(): number
        get killCredit(): Internal.LivingEntity
        get componentContainer(): Internal.ComponentContainer
        get dynamicLightPrevZ(): number
        set outOfCamera(value: boolean)
        get autoSpinAttack(): boolean
        get remainingFireTicks(): number
        get maxFallDistance(): number
        get ticksFrozen(): number
        get dynamicLightZ(): number
        get voicePitch(): number
        set statusMessage(message: net.minecraft.network.chat.Component_)
        set sleepingPos($$0: BlockPos_)
        get descending(): boolean
        get headRotSpeed(): number
        get lastHurtByPlayer(): Internal.Player
        get YHeadRot(): number
        set absorptionAmount($$0: number)
        set recallData(pos: Internal.DimensionalPosition_)
        set deltaMovement($$0: Vec3d_)
        get baby(): boolean
        get culled(): boolean
        get glowing(): boolean
        get leashedByEntities(): Internal.Set<any>
        get leashOffset(): Vec3d
        get attackable(): boolean
        get underWater(): boolean
        get leashHolder(): Internal.Entity
        get sensing(): Internal.Sensing
        get legsArmorItem(): Internal.ItemStack
        get luminance(): number
        get selfAndPassengers(): Internal.Stream<any>
        get deltaMovement(): Vec3d
        get dynamicLightX(): number
        set secondsOnFire($$0: number)
        get "displayName()"(): net.minecraft.network.chat.Component
        get lootTable(): ResourceLocation
        get ticksUsingItem(): number
        get arrowCount(): number
        get moveControl(): Internal.MoveControl
        get defaultMovementSpeed(): number
        get peacefulCreature(): boolean
        set onGround($$0: boolean)
        get lastHurtByMobTimestamp(): number
        get vehicle(): Internal.Entity
        get effectiveAi(): boolean
        get stringUuid(): string
        set swimming($$0: boolean)
        get mainArm(): Internal.HumanoidArm
        get rotationVector(): Internal.Vec2
        get hurtDir(): number
        get sprinting(): boolean
        get motionY(): number
        get offhandItem(): Internal.ItemStack
        set luminance(luminance: number)
        set lootTable(arg0: ResourceLocation_)
        get owner(): Internal.Mob
        get lastHurtMob(): Internal.LivingEntity
        get soundSource(): Internal.SoundSource
        get lastDamageSource(): DamageSource
        set noActionTime($$0: number)
        set movementSpeedAddition(speed: number)
        get pose(): Internal.Pose
        get restrictCenter(): BlockPos
        get leftHanded(): boolean
        set z(z: number)
        get y(): number
        set currentModifyFoodPowers(powers: Internal.List_<any>)
        get "owner()"(): Internal.Entity
        get blocking(): boolean
        get pushedByFluid(): boolean
        set originalFoodStack(original: Internal.ItemStack_)
        get armorCoverPercentage(): number
        get airSupply(): number
        get player(): boolean
        get animal(): boolean
        get motionDirection(): Internal.Direction
        set boundOrigin($$0: BlockPos_)
        get fabricBalmData(): Internal.CompoundTag
        get commandSenderWorld(): Internal.Level
        get totalMovementSpeed(): number
        get owner(): Internal.Entity
        get moving(): boolean
        get attributes(): Internal.AttributeMap
        get swimming(): boolean
        set sprinting($$0: boolean)
        get dynamicLightLevel(): Internal.Level
        set x(x: number)
        get portalWaitTime(): number
        get blockStateOn(): Internal.BlockState
        get fluidJumpThreshold(): number
        get cachedSouls(): number
        set airSupply($$0: number)
        get onPos(): BlockPos
        get undead(): boolean
        set useItemRemaining(arg0: number)
        get targetSelector(): Internal.GoalSelector
        set registeredToWorld(navigation: Internal.PathNavigation_)
        get sleeping(): boolean
        get dismountPoses(): Internal.ImmutableList<Internal.Pose>
        get lastHurtMobTimestamp(): number
        set remainingFireTicks($$0: number)
        /**
         * @deprecated
        */
        get onPosLegacy(): BlockPos
        set pos($$0: Vec3d_)
        set canPickUpLoot($$0: boolean)
        get mainHandItem(): Internal.ItemStack
        set silent($$0: boolean)
        set leftHanded($$0: boolean)
        get activeEffects(): Internal.Collection<Internal.MobEffectInstance>
        get onPortalCooldown(): boolean
        set pitch($$0: number)
        get usingItem(): boolean
        get alwaysTicking(): boolean
        set invulnerable($$0: boolean)
        get dynamicLightPrevY(): number
        set glowing($$0: boolean)
        get alive(): boolean
        get bbHeight(): number
        get tags(): Internal.Set<string>
        get lastAttacker(): Internal.LivingEntity
        get lastRollTicks(): number
        get goalSelector(): Internal.GoalSelector
        get percentFrozen(): number
        set portalCooldown($$0: number)
        set position(block: Internal.BlockContainerJS_)
        get leashed(): boolean
        set pose($$0: Internal.Pose_)
        get reachDistance(): number
        get entityType(): Internal.EntityType<any>
        get waterCreature(): boolean
        set lastHurtByPlayer($$0: Internal.Player_)
        get "server()"(): Internal.MinecraftServer
        get pushable(): boolean
        set YBodyRot($$0: number)
        set motionY(y: number)
        set limitedLife($$0: number)
        get dynamicLightEnabled(): boolean
        set isCharging($$0: boolean)
        set chestArmorItem(item: Internal.ItemStack_)
        get passenger(): boolean
        get sensitiveToWater(): boolean
        get jumpControl(): Internal.JumpControl
        get feetArmorItem(): Internal.ItemStack
        get viewScale(): number
        get visualRotationYInDegrees(): number
        set speed($$0: number)
        get discrete(): boolean
        get level(): Internal.Level
        get combatTracker(): Internal.CombatTracker
        get noAi(): boolean
        get chestArmorItem(): Internal.ItemStack
        get fullyFrozen(): boolean
        get inWall(): boolean
        get allSlots(): Internal.Iterable<Internal.ItemStack>
        get scale(): number
        get suppressingSlidingDownLadder(): boolean
        get blockZ(): number
        get silent(): boolean
        set useItem(arg0: Internal.ItemStack_)
        get pitch(): number
        get random(): Internal.RandomSource
        get passengersAndSelf(): Internal.Stream<any>
        get originalFoodStack(): Internal.ItemStack
        get boundOrigin(): BlockPos
        get noActionTime(): number
        get visuallyCrawling(): boolean
        get aggressive(): boolean
        set yya($$0: number)
        set baby($$0: boolean)
        get lastHurtByMob(): Internal.LivingEntity
        get inWaterOrBubble(): boolean
        get portalCooldown(): number
        get item(): Internal.ItemStack
        get ignoringBlockTriggers(): boolean
        get steppingCarefully(): boolean
        get lightLevelDependentMagicValue(): number
        get blockX(): number
        get fallFlying(): boolean
        get encodeId(): string
        get maxHeadXRot(): number
        get nbt(): Internal.CompoundTag
        set invisible($$0: boolean)
        set totalMovementSpeedMultiplier(speed: number)
        get dynamicLightY(): number
        set health($$0: number)
        get eyePosition(): Vec3d
        get eyeHeight(): number
        set discardFriction($$0: boolean)
        get yaw(): number
        get usedItemHand(): Internal.InteractionHand
        set defaultMovementSpeed(speed: number)
        get brain(): Internal.Brain<any>
        set customNameVisible($$0: boolean)
        get controllingPassenger(): Internal.LivingEntity
        get scriptType(): Internal.ScriptType
        get forward(): Vec3d
        set feetArmorItem(item: Internal.ItemStack_)
        get id(): number
        get recipientsForComponentSync(): Internal.Iterable<any>
        get eyeY(): number
        get boundingBox(): Internal.AABB
        get inWaterOrRain(): boolean
        set owner($$0: Internal.Mob_)
        get affectedByPotions(): boolean
        get addEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>
        get team(): Internal.Team
        set ticksFrozen($$0: number)
        get useItem(): Internal.ItemStack
        get myRidingOffset(): number
        get living(): boolean
        get x(): number
        get vehicle(): boolean
        set isInPowderSnow($$0: boolean)
        set customName($$0: net.minecraft.network.chat.Component_)
        get teamId(): string
        set stingerCount($$0: number)
        get maxHeadYRot(): number
        get customNameVisible(): boolean
        get pistonPushReaction(): Internal.PushReaction
        get lootTableSeed(): number
        get motionX(): number
        get entityData(): Internal.SynchedEntityData
        get potionEffects(): Internal.EntityPotionEffectsJS
        get lastHurtByPlayerTime(): number
        get onRails(): boolean
        get stingerCount(): number
        get fallSounds(): Internal.LivingEntity$Fallsounds
        get dimensionChangingDelay(): number
        get lastDynamicLuminance(): number
        set yaw($$0: number)
        get pickRadius(): number
        get pathFinding(): boolean
        get removed(): boolean
        get jumpBoostPower(): number
        set shiftKeyDown($$0: boolean)
        get passengers(): Internal.EntityArrayList
        get z(): number
        get server(): Internal.MinecraftServer
        get experienceReward(): number
        get firstPassenger(): Internal.Entity
        set lastHurtMob($$0: Internal.Entity_)
        set lastHurtByMob($$0: Internal.LivingEntity_)
        get charging(): boolean
        get leashingEntities(): Internal.Set<any>
        set fabricBalmData(tag: Internal.CompoundTag_)
        get lookAngle(): Vec3d
        get ambientSoundInterval(): number
        set arrowCount($$0: number)
        get motionZ(): number
        get persistenceRequired(): boolean
        get invisible(): boolean
        get bedOrientation(): Internal.Direction
        get profile(): Internal.GameProfile
        get deadOrDying(): boolean
        set headArmorItem(item: Internal.ItemStack_)
        set viewScale($$0: number)
        set levelCallback($$0: Internal.EntityInLevelCallback_)
        get lookControl(): Internal.LookControl
        get offHandItem(): Internal.ItemStack
        get outOfCamera(): boolean
        get crouching(): boolean
        set y(y: number)
        get feetBlockState(): Internal.BlockState
        get withinRestriction(): boolean
        get changeListener(): Internal.EntityInLevelCallback
        get sleepingPos(): Optional<BlockPos>
        get customName(): net.minecraft.network.chat.Component
        get class(): typeof any
        get visuallySwimming(): boolean
        get maxAirSupply(): number
        set maxHealth(hp: number)
        get facing(): Internal.Direction
        get boundingBoxForCulling(): Internal.AABB
        get target(): Internal.LivingEntity
        get nameTagOffsetY(): number
        get invulnerable(): boolean
        get inLava(): boolean
        get inWater(): boolean
        get rootVehicle(): Internal.Entity
        get noGravity(): boolean
        get speed(): number
        get cachedFeetBlockState(): Internal.BlockState
        get uuid(): Internal.UUID
        get "owner()"(): Internal.Mob
        set offHandItem(item: Internal.ItemStack_)
        set noAi($$0: boolean)
        get armorSlots(): Internal.Iterable<Internal.ItemStack>
        get headArmorItem(): Internal.ItemStack
        get currentModifyFoodPowers(): Internal.List<any>
        get bbWidth(): number
        get "name()"(): net.minecraft.network.chat.Component
        get ticksRequiredToFreeze(): number
        get maxSpawnClusterSize(): number
        get username(): string
        get pickable(): boolean
        set YHeadRot($$0: number)
        set jumping($$0: boolean)
        get customData(): Internal.CompoundTag
        get pickResult(): Internal.ItemStack
        get "mainHandItem()"(): Internal.ItemStack
        get absorptionAmount(): number
        get randomY(): number
        get displayName(): net.minecraft.network.chat.Component
        get mobType(): Internal.MobType
        get dynamicLightPrevX(): number
        get passengersRidingOffset(): number
        get frame(): boolean
        set legsArmorItem(item: Internal.ItemStack_)
        set noGravity($$0: boolean)
        get useItemRemainingTicks(): number
        get indirectPassengers(): Internal.Iterable<any>
        get navigation(): Internal.PathNavigation
        get controlledByLocalInstance(): boolean
        get monster(): boolean
        get lastClimbablePos(): Optional<BlockPos>
        set lastDynamicLuminance(luminance: number)
        set id($$0: number)
        get horizontalFacing(): Internal.Direction
        get type(): string
        get activeEffectsMap(): Internal.Map<Internal.MobEffect, Internal.MobEffectInstance>
        set motionX(x: number)
        get handSlots(): Internal.Iterable<Internal.ItemStack>
        get teamColor(): number
        set nbt(nbt: Internal.CompoundTag_)
        get recallPosition(): Internal.DimensionalPosition
        set dynamicLightEnabled(enabled: boolean)
        get restrictRadius(): number
        get registeredNavigation(): Internal.PathNavigation
        get forcedVisible(): boolean
        get invertedHealAndHarm(): boolean
        get freezing(): boolean
        set guaranteedDrop($$0: Internal.EquipmentSlot_)
        set sharedFlagOnFire($$0: boolean)
        static readonly TICKS_PER_FLAP: (4) & (number);
        static readonly FLAP_DEGREES_PER_TICK: (45.836624) & (number);
    }
    type Vex_ = Vex;
    class CauldronBrewingRecipe$Serializer implements Internal.RecipeSerializer<Internal.CauldronBrewingRecipe> {
        constructor()
        read(id: ResourceLocation_, json: Internal.JsonObject_): Internal.CauldronBrewingRecipe;
        getClass(): typeof any;
        "read(net.minecraft.resources.ResourceLocation,net.minecraft.network.FriendlyByteBuf)"(id: ResourceLocation_, buf: Internal.FriendlyByteBuf_): Internal.CauldronBrewingRecipe;
        toString(): string;
        notifyAll(): void;
        toNetwork(arg0: Internal.FriendlyByteBuf_, arg1: Internal.Recipe_<any>): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        read(id: ResourceLocation_, buf: Internal.FriendlyByteBuf_): Internal.CauldronBrewingRecipe;
        static register<S extends Internal.RecipeSerializer<T>, T extends Internal.Recipe<any>>($$0: string, $$1: S): S;
        hashCode(): number;
        fromJson(arg0: ResourceLocation_, arg1: Internal.JsonObject_): Internal.Recipe<any>;
        wait(): void;
        wait(arg0: number): void;
        "read(net.minecraft.resources.ResourceLocation,com.google.gson.JsonObject)"(id: ResourceLocation_, json: Internal.JsonObject_): Internal.CauldronBrewingRecipe;
        write(buf: Internal.FriendlyByteBuf_, recipe: Internal.CauldronBrewingRecipe_): void;
        equals(arg0: any): boolean;
        fromNetwork(arg0: ResourceLocation_, arg1: Internal.FriendlyByteBuf_): Internal.Recipe<any>;
        get class(): typeof any
    }
    type CauldronBrewingRecipe$Serializer_ = CauldronBrewingRecipe$Serializer;
    class DualNoiseProvider extends Internal.NoiseProvider {
        constructor($$0: Internal.InclusiveRange_<number>, $$1: Internal.NormalNoise$NoiseParameters_, $$2: number, $$3: number, $$4: Internal.NormalNoise$NoiseParameters_, $$5: number, $$6: Internal.List_<Internal.BlockState>)
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        static simple($$0: Internal.Block_): Internal.SimpleStateProvider;
        hashCode(): number;
        static simple($$0: Internal.BlockState_): Internal.SimpleStateProvider;
        wait(): void;
        static "simple(net.minecraft.world.level.block.state.BlockState)"($$0: Internal.BlockState_): Internal.SimpleStateProvider;
        wait(arg0: number): void;
        getState($$0: Internal.RandomSource_, $$1: BlockPos_): Internal.BlockState;
        equals(arg0: any): boolean;
        static "simple(net.minecraft.world.level.block.Block)"($$0: Internal.Block_): Internal.SimpleStateProvider;
        get class(): typeof any
        static readonly CODEC: Internal.Codec<Internal.DualNoiseProvider>;
    }
    type DualNoiseProvider_ = DualNoiseProvider;
    interface Watchable {
        abstract register(arg0: Internal.WatchService_, ...arg1: Internal.WatchEvent$Kind_<any>[]): Internal.WatchKey;
        abstract register(arg0: Internal.WatchService_, arg1: Internal.WatchEvent$Kind_<any>[], ...arg2: any_[]): Internal.WatchKey;
    }
    type Watchable_ = Watchable;
    class Cat extends Internal.TamableAnimal implements Internal.VariantHolder<Internal.CatVariant> {
        constructor($$0: Internal.EntityType_<Internal.Cat>, $$1: Internal.Level_)
        handler$hak000$gobber2$gobberOccludeVibrationSignals(cir: Internal.CallbackInfoReturnable_<any>): void;
        handler$fed001$extraalchemy$writeNbt(tag: Internal.CompoundTag_, cb: Internal.CallbackInfo_): void;
        etf$getType(): Internal.EntityType<any>;
        getUpVector($$0: number): Vec3d;
        gameEvent($$0: Internal.GameEvent_, $$1: Internal.Entity_): void;
        static checkMobSpawnRules($$0: Internal.EntityType_<Internal.Mob>, $$1: Internal.LevelAccessor_, $$2: Internal.MobSpawnType_, $$3: BlockPos_, $$4: Internal.RandomSource_): boolean;
        setDefaultMovementSpeedMultiplier(speed: number): void;
        isSuppressingBounce(): boolean;
        setTarget($$0: Internal.LivingEntity_): void;
        handler$han001$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        setCulled(value: boolean): void;
        handler$leb003$puzzleslib$hurt(source: DamageSource_, amount: number, callback: Internal.CallbackInfoReturnable_<any>): void;
        isOnFire(): boolean;
        getOwner(): Internal.LivingEntity;
        getPositionCodec(): Internal.VecDeltaCodec;
        setMaxUpStep($$0: number): void;
        updateFluidHeightAndDoFluidPushing($$0: Internal.TagKey_<Internal.Fluid>, $$1: number): boolean;
        convertTo<T extends Internal.Mob>($$0: Internal.EntityType_<T>, $$1: boolean): T;
        getFallFlyingTicks(): number;
        setPosition(x: number, y: number, z: number): void;
        runCommandSilent(command: string): number;
        chunkPosition(): Internal.ChunkPos;
        emf$isOnGround(): boolean;
        dropLeash($$0: boolean, $$1: boolean): void;
        gameEvent($$0: Internal.GameEvent_): void;
        setXxa($$0: number): void;
        setDelayedLeashHolderId($$0: number): void;
        isShiftKeyDown(): boolean;
        setUUID($$0: Internal.UUID_): void;
        checkBelowWorld(): void;
        isRelaxStateOne(): boolean;
        handler$leb000$puzzleslib$startUsingItem(hand: Internal.InteractionHand_, callback: Internal.CallbackInfo_): void;
        setMotionZ(z: number): void;
        "deserializeNBT(net.minecraft.nbt.Tag)"(arg0: Internal.Tag_): void;
        canFreeze(): boolean;
        ignoreExplosion(): boolean;
        getBlockY(): number;
        getIsInsideStructureTracker(): Internal.IsInsideStructureTracker;
        setPlayerHitTimer(arg0: number): void;
        isSpectator(): boolean;
        setMainHandItem(item: Internal.ItemStack_): void;
        removeEffectNoUpdate($$0: Internal.MobEffect_): Internal.MobEffectInstance;
        spawnAtLocation($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        getPersistentData(): Internal.CompoundTag;
        getHealth(): number;
        getMaxHealth(): number;
        emf$isGlowing(): boolean;
        setPathfindingMalus($$0: Internal.BlockPathTypes_, $$1: number): void;
        isRegisteredToWorld(): boolean;
        getRandomZ($$0: number): number;
        pehkui_getOnGround(): boolean;
        setAggressive($$0: boolean): void;
        handler$lef000$puzzleslib$checkDespawn(callback: Internal.CallbackInfo_): void;
        getFusionModel(layerIndex: number): Internal.Triple<any, any, any>;
        setRemoved($$0: Internal.Entity$RemovalReason_): void;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>, initializer: Internal.Supplier_<A>): A;
        getDistanceSq($$0: number, $$1: number, $$2: number): number;
        isInWaterRainOrBubble(): boolean;
        getRemovalReason(): Internal.Entity$RemovalReason;
        etf$getVelocity(): Vec3d;
        hex$markHurt(): void;
        resetFallDistance(): void;
        canSprint(): boolean;
        blockPosition(): BlockPos;
        setBoundingBox($$0: Internal.AABB_): void;
        isAmbientCreature(): boolean;
        method_5958(): void;
        setZza($$0: number): void;
        getBlock(): Internal.BlockContainerJS;
        setEquipment(slot: Internal.EquipmentSlot_, item: Internal.ItemStack_): void;
        etf$getHandItems(): Internal.Iterable<any>;
        randomTeleport($$0: number, $$1: number, $$2: number, $$3: boolean): boolean;
        getName(): net.minecraft.network.chat.Component;
        playAmbientSound(): void;
        onGround(): boolean;
        getVariant(): Internal.CatVariant;
        handler$leb000$puzzleslib$canBeAffected(effectInstance: Internal.MobEffectInstance_, callback: Internal.CallbackInfoReturnable_<any>): void;
        getControlledVehicle(): Internal.Entity;
        isOnSameTeam($$0: Internal.Entity_): boolean;
        getArmorValue(): number;
        tick(): void;
        localvar$lef000$puzzleslib$setTarget(entity: Internal.LivingEntity_): Internal.LivingEntity;
        getKillCredit(): Internal.LivingEntity;
        emf$isTouchingWater(): boolean;
        emf$getVariableMap(): Internal.Object2FloatOpenHashMap<any>;
        getComponentContainer(): Internal.ComponentContainer;
        hasPermissions($$0: number): boolean;
        getDynamicLightPrevZ(): number;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        pehkui_readScaleNbt(nbt: Internal.CompoundTag_): void;
        setOutOfCamera(value: boolean): void;
        static createMobAttributes(): Internal.AttributeSupplier$Builder;
        isAutoSpinAttack(): boolean;
        getRemainingFireTicks(): number;
        botania_getAmbientSound(): Internal.SoundEvent;
        onlyOpCanSetNbt(): boolean;
        tcdcommons_getCustomData(): Internal.GenericProperties<any>;
        fireImmune(): boolean;
        addMotion($$0: number, $$1: number, $$2: number): void;
        getMaxFallDistance(): number;
        isHolding($$0: Internal.Item_): boolean;
        getZ($$0: number): number;
        static areAllEffectsAmbient($$0: Internal.Collection_<Internal.MobEffectInstance>): boolean;
        doHurtTarget($$0: Internal.Entity_): boolean;
        getTicksFrozen(): number;
        wrapWithCondition$kom000$porting_lib_entity$port_lib$captureDrops(level: Internal.Level_, entity: Internal.Entity_): boolean;
        handler$lef000$puzzleslib$addAdditionalSaveData(compound: Internal.CompoundTag_, callback: Internal.CallbackInfo_): void;
        deflect(chance: number, source: Internal.Entity_): boolean;
        getRandomX($$0: number): number;
        getDynamicLightZ(): number;
        spawnAtLocation($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        pick($$0: number, $$1: number, $$2: boolean): Internal.HitResult;
        getVoicePitch(): number;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        setSleepingPos($$0: BlockPos_): void;
        changeDimension(p_20118_: Internal.ServerLevel_, teleporter: Internal.ITeleporter_): Internal.Entity;
        isDescending(): boolean;
        getAttributeBaseValue($$0: Internal.Attribute_): number;
        emf$getPitch(): number;
        sendEffectToPassengers($$0: Internal.MobEffectInstance_): void;
        getHeadRotSpeed(): number;
        getLastHurtByPlayer(): Internal.Player;
        getYHeadRot(): number;
        handler$cbi000$besmirchment$isTeammate(other: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>): void;
        localvar$leb000$puzzleslib$addEffect(oldEffectInstance: Internal.MobEffectInstance_, effectInstance: Internal.MobEffectInstance_, entity: Internal.Entity_): Internal.MobEffectInstance;
        getProjectile($$0: Internal.ItemStack_): Internal.ItemStack;
        static getAlpha(le: Internal.LivingEntity_, partialTicks: number): number;
        frameworkGetDataHolder(): com.mrcrayfish.framework.entity.sync.DataHolder;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        syncPacketPositionCodec($$0: number, $$1: number, $$2: number): void;
        setAbsorptionAmount($$0: number): void;
        setRecallData(pos: Internal.DimensionalPosition_): void;
        port_lib$spawnItemParticles(arg0: Internal.ItemStack_, arg1: number): void;
        shouldRenderAtSqrDistance($$0: number): boolean;
        getAttachedOrSet<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        damageSources(): Internal.DamageSources;
        removeAttached<A>(type: Internal.AttachmentType_<A>): A;
        removeAllGoals($$0: Internal.Predicate_<Internal.Goal>): void;
        swing(): void;
        recreateFromPacket($$0: Internal.ClientboundAddEntityPacket_): void;
        setDeltaMovement($$0: Vec3d_): void;
        getLeashOffset($$0: number): Vec3d;
        isBaby(): boolean;
        isCulled(): boolean;
        damageEquipment(slot: Internal.EquipmentSlot_): void;
        isGlowing(): boolean;
        getWalkTargetValue($$0: BlockPos_): number;
        canBreatheUnderwater(): boolean;
        getLeashedByEntities(): Internal.Set<any>;
        die($$0: DamageSource_): void;
        etf$getOptifineId(): number;
        removeAllEffects(): boolean;
        dynamicLightWorld(): Internal.Level;
        getLeashOffset(): Vec3d;
        hasLineOfSight($$0: Internal.Entity_): boolean;
        hex$getLastHurt(): number;
        onClimbable(): boolean;
        isAttackable(): boolean;
        getSlot($$0: number): Internal.SlotAccess;
        "deserializeNBT(net.minecraft.nbt.CompoundTag)"(nbt: Internal.CompoundTag_): void;
        emf$isInLava(): boolean;
        pehkui_constructScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        stopSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isUnderWater(): boolean;
        stopRiding(): void;
        getLeashHolder(): Internal.Entity;
        getX($$0: number): number;
        getSensing(): Internal.Sensing;
        localvar$kpc000$porting_lib_entity$port_lib$modifyMultiplier(multiplier: number): number;
        getLegsArmorItem(): Internal.ItemStack;
        getLuminance(): number;
        callUnsetRemoved(): void;
        captureDrops(value: Internal.Collection_<Internal.ItemEntity>): Internal.Collection<Internal.ItemEntity>;
        getSelfAndPassengers(): Internal.Stream<any>;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        handler$egi000$collective$LivingEntity_hurt(damageSource: DamageSource_, f: number, ci: Internal.CallbackInfoReturnable_<any>): void;
        getDeltaMovement(): Vec3d;
        canTakeItem($$0: Internal.ItemStack_): boolean;
        shouldDropExperience(): boolean;
        hasPassenger($$0: Internal.Entity_): boolean;
        be_getTravelerState(): Internal.TravelerState;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        getDynamicLightX(): number;
        setSecondsOnFire($$0: number): void;
        moveTo($$0: number, $$1: number, $$2: number): void;
        emf$getZ(): number;
        "getDisplayName()"(): net.minecraft.network.chat.Component;
        getLootTable(): ResourceLocation;
        getTicksUsingItem(): number;
        bettertrims$getWornMaterials(): Internal.List<any>;
        getArrowCount(): number;
        getMoveControl(): Internal.MoveControl;
        setMotion($$0: number, $$1: number, $$2: number): void;
        playSound($$0: Internal.SoundEvent_): void;
        setOrderedToSit($$0: boolean): void;
        getCollarColor(): Internal.DyeColor;
        getDefaultMovementSpeed(): number;
        handler$ikg000$lithium$tryShortcutFluidPushing(tag: Internal.TagKey_<any>, speed: number, cir: Internal.CallbackInfoReturnable_<any>, box: Internal.AABB_, x1: number, x2: number, y1: number, y2: number, z1: number, z2: number, zero: number): void;
        handler$hak000$gobber2$setFrozenTicks(frozenTicks: number, ci: Internal.CallbackInfo_): void;
        restoreFrom($$0: Internal.Entity_): void;
        isPeacefulCreature(): boolean;
        setOnGround($$0: boolean): void;
        addEffect($$0: Internal.MobEffectInstance_, $$1: Internal.Entity_): boolean;
        emf$getYaw(): number;
        ate(): void;
        setPos($$0: number, $$1: number, $$2: number): void;
        notify(): void;
        setPersistenceRequired(): void;
        getLastHurtByMobTimestamp(): number;
        getVehicle(): Internal.Entity;
        canFallInLove(): boolean;
        isEffectiveAi(): boolean;
        handler$kom000$porting_lib_entity$port_lib$startRiding(entity: Internal.Entity_, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        startRiding($$0: Internal.Entity_, $$1: boolean): boolean;
        getStringUuid(): string;
        setSwimming($$0: boolean): void;
        getMainArm(): Internal.HumanoidArm;
        checkSpawnRules($$0: Internal.LevelAccessor_, $$1: Internal.MobSpawnType_): boolean;
        getRotationVector(): Internal.Vec2;
        getHurtDir(): number;
        etf$getBlockY(): number;
        isSprinting(): boolean;
        isMaxGroupSizeReached($$0: number): boolean;
        getMotionY(): number;
        getOffhandItem(): Internal.ItemStack;
        canCollideWith($$0: Internal.Entity_): boolean;
        setLuminance(luminance: number): void;
        "setVariant(net.minecraft.world.entity.animal.CatVariant)"($$0: Internal.CatVariant_): void;
        getBlockExplosionResistance($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.FluidState_, $$5: number): number;
        setLootTable(arg0: ResourceLocation_): void;
        clearSleepingPos(): void;
        canSpawnSprintParticle(): boolean;
        "moveTo(net.minecraft.core.BlockPos,float,float)"($$0: BlockPos_, $$1: number, $$2: number): void;
        hex$checkTotemDeathProtection(arg0: DamageSource_): boolean;
        getLastHurtMob(): Internal.LivingEntity;
        moveRelative($$0: number, $$1: Vec3d_): void;
        saveAsPassenger($$0: Internal.CompoundTag_): boolean;
        static gatherClosestChunks(chunks: Internal.LongSet_, x: number, y: number, z: number): void;
        handler$kom000$porting_lib_entity$afterSave(nbt: Internal.CompoundTag_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDamageSource(): DamageSource;
        getSoundSource(): Internal.SoundSource;
        setNoActionTime($$0: number): void;
        setMovementSpeedAddition(speed: number): void;
        removeAfterChangingDimensions(): void;
        equipmentHasChanged($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        getPose(): Internal.Pose;
        getAttribute($$0: Internal.Attribute_): Internal.AttributeInstance;
        setPositionAndRotation($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        canBeAffected($$0: Internal.MobEffectInstance_): boolean;
        ageUp($$0: number): void;
        getRestrictCenter(): BlockPos;
        isLeftHanded(): boolean;
        invokeShouldDropLoot(): boolean;
        handler$kpc000$porting_lib_entity$port_lib$onFinishUsing(ci: Internal.CallbackInfo_, hand: Internal.InteractionHand_, result: Internal.ItemStack_): void;
        etf$getUuid(): Internal.UUID;
        removeVehicle(): void;
        shouldFusionRecomputeModel(layerIndex: number): boolean;
        modifyExpressionValue$zcl000$porting_lib_base$port_lib$canContinueUsing(original: boolean): boolean;
        setZ(z: number): void;
        getResourceLocation(): ResourceLocation;
        getY(): number;
        deserializeNBT(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        finalizeSpawnChildFromBreeding($$0: Internal.ServerLevel_, $$1: Internal.Animal_, $$2: Internal.AgeableMob_): void;
        eat($$0: Internal.Level_, $$1: Internal.ItemStack_): Internal.ItemStack;
        bookshelf$makePoofParticles(): void;
        isWithinMeleeAttackRange($$0: Internal.LivingEntity_): boolean;
        setCurrentModifyFoodPowers(powers: Internal.List_<any>): void;
        broadcastBreakEvent($$0: Internal.EquipmentSlot_): void;
        modifyExpressionValue$zhf000$additionalentityattributes$additionalEntityAttributes$modifyUpwardSwimming(original: number, fluid: Internal.TagKey_<any>): number;
        handler$nbm000$things$onShieldBlock(source: DamageSource_, cir: Internal.CallbackInfoReturnable_<any>): void;
        showVehicleHealth(): boolean;
        getDistance(pos: BlockPos_): number;
        isBlocking(): boolean;
        "getBreedOffspring(net.minecraft.server.level.ServerLevel,net.minecraft.world.entity.AgeableMob)"(arg0: Internal.ServerLevel_, arg1: Internal.AgeableMob_): Internal.AgeableMob;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number): void;
        removeAttribute(attribute: Internal.Attribute_, identifier: string): void;
        emf$getVelocity(): Vec3d;
        handler$lef000$puzzleslib$finalizeSpawn(level: Internal.ServerLevelAccessor_, difficulty: Internal.DifficultyInstance_, reason: Internal.MobSpawnType_, spawnData: Internal.SpawnGroupData_, dataTag: Internal.CompoundTag_, callback: Internal.CallbackInfoReturnable_<any>): void;
        etf$isBlockEntity(): boolean;
        shouldUpdateDynamicLight(): boolean;
        isPushedByFluid(): boolean;
        setOriginalFoodStack(original: Internal.ItemStack_): void;
        getArmorCoverPercentage(): number;
        handleRelativeFrictionAndCalculateMovement($$0: Vec3d_, $$1: number): Vec3d;
        turn($$0: number, $$1: number): void;
        getAirSupply(): number;
        moveTo($$0: BlockPos_, $$1: number, $$2: number): void;
        isPlayer(): boolean;
        isAnimal(): boolean;
        "handler$fgd000$fabric-dimensions-v1$getTeleportTarget"(destination: Internal.ServerLevel_, cir: Internal.CallbackInfoReturnable_<any>): void;
        canBeCollidedWith(): boolean;
        getMotionDirection(): Internal.Direction;
        asComponentProvider(): Internal.ComponentProvider;
        lavaHurt(): void;
        handleDamageEvent($$0: DamageSource_): void;
        tame($$0: Internal.Player_): void;
        getFabricBalmData(): Internal.CompoundTag;
        canChangeDimensions(): boolean;
        static tickEntity(entity: Internal.Entity_): void;
        getCommandSenderWorld(): Internal.Level;
        getTotalMovementSpeed(): number;
        changeDimension($$0: Internal.ServerLevel_): Internal.Entity;
        localvar$zno000$apoli$modifyFallingVelocity(in_: number): number;
        handler$kom000$porting_lib_entity$afterLoad(nbt: Internal.CompoundTag_, ci: Internal.CallbackInfo_): void;
        pehkui_shouldIgnoreScaleNbt(): boolean;
        isMoving(): boolean;
        attack(hp: number): void;
        getAttributes(): Internal.AttributeMap;
        "hasPassenger(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.Entity>): boolean;
        botania_playHurtSound(arg0: DamageSource_): void;
        getDimensions($$0: Internal.Pose_): Internal.EntityDimensions;
        setInSittingPose($$0: boolean): void;
        spawnChildFromBreeding($$0: Internal.ServerLevel_, $$1: Internal.Animal_): void;
        setInLoveTime($$0: number): void;
        invokeGetLeashOffset(): Vec3d;
        isSwimming(): boolean;
        setSprinting($$0: boolean): void;
        mayInteract($$0: Internal.Level_, $$1: BlockPos_): boolean;
        handler$kpc000$porting_lib_entity$port_lib$attackEvent(source: DamageSource_, amount: number, cir: Internal.CallbackInfoReturnable_<any>): void;
        getDynamicLightLevel(): Internal.Level;
        setPortalCooldown(): void;
        getAttackAnim($$0: number): number;
        hex$setLastHurt(arg0: number): void;
        setX(x: number): void;
        getPortalWaitTime(): number;
        getBlockStateOn(): Internal.BlockState;
        wantsToPickUp($$0: Internal.ItemStack_): boolean;
        getItemBySlot($$0: Internal.EquipmentSlot_): Internal.ItemStack;
        getFluidHeightLoosely(tag: Internal.TagKey_<any>): number;
        setOwnerUUID($$0: Internal.UUID_): void;
        getFluidJumpThreshold(): number;
        getCachedSouls(): number;
        "getVariant()"(): any;
        "setPositionAndRotation(double,double,double,float,float)"(x: number, y: number, z: number, yaw: number, pitch: number): void;
        isInvisibleTo($$0: Internal.Player_): boolean;
        stopSleeping(): void;
        setAirSupply($$0: number): void;
        getOnPos(): BlockPos;
        etf$getWorld(): Internal.Level;
        isUndead(): boolean;
        static createLivingAttributes(): Internal.AttributeSupplier$Builder;
        setUseItemRemaining(arg0: number): void;
        pehkui_getScales(): Internal.Map<any, any>;
        getTargetSelector(): Internal.GoalSelector;
        setRegisteredToWorld(navigation: Internal.PathNavigation_): void;
        isSleeping(): boolean;
        stopUsingItem(): void;
        etf$getNbt(): Internal.CompoundTag;
        acceptsFailure(): boolean;
        etf$getBlockPos(): BlockPos;
        pehkui_setShouldIgnoreScaleNbt(ignore: boolean): void;
        setOnGroundWithKnownMovement($$0: boolean, $$1: Vec3d_): void;
        getFluidFallingAdjustedMovement($$0: number, $$1: boolean, $$2: Vec3d_): Vec3d;
        setOldPosAndRot(): void;
        localvar$cjk000$bettertridents$doHurtTarget$modifyVariable$store(damageAmount: number, entity: Internal.Entity_): number;
        isFree($$0: number, $$1: number, $$2: number): boolean;
        getDismountPoses(): Internal.ImmutableList<Internal.Pose>;
        getLastHurtMobTimestamp(): number;
        lithiumOnEquipmentChanged(): void;
        "moveTo(double,double,double)"($$0: number, $$1: number, $$2: number): void;
        setRemainingFireTicks($$0: number): void;
        setRelaxStateOne($$0: boolean): void;
        emf$age(): number;
        etf$hasCustomName(): boolean;
        /**
         * @deprecated
        */
        getOnPosLegacy(): BlockPos;
        port_lib$isJumping(): boolean;
        setPos($$0: Vec3d_): void;
        localvar$leb000$puzzleslib$knockback$2(ratioX: number): number;
        static "tickEntity(net.minecraft.world.entity.LivingEntity)"(entity: Internal.LivingEntity_): void;
        updateCachedSouls(): void;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        setCanPickUpLoot($$0: boolean): void;
        getMainHandItem(): Internal.ItemStack;
        handler$kom000$porting_lib_entity$port_lib$removeRidingEntity(ci: Internal.CallbackInfo_): void;
        setSilent($$0: boolean): void;
        captureDrops(): Internal.Collection<Internal.ItemEntity>;
        hasExactlyOnePlayerPassenger(): boolean;
        canBeSeenAsEnemy(): boolean;
        setLeftHanded($$0: boolean): void;
        getActiveEffects(): Internal.Collection<Internal.MobEffectInstance>;
        isOnPortalCooldown(): boolean;
        hurtArmor($$0: DamageSource_, $$1: number): void;
        canAttack($$0: Internal.LivingEntity_, $$1: Internal.TargetingConditions_): boolean;
        getAttributeValue($$0: Internal.Holder_<Internal.Attribute>): number;
        lambdynlights$setTrackedLitChunkPos(trackedLitChunkPos: Internal.LongSet_): void;
        fzzy_core_setModifierContainer(container: Internal.ModifierContainer_): void;
        setPitch($$0: number): void;
        setPosRaw($$0: number, $$1: number, $$2: number): void;
        handleEntityEvent($$0: number): void;
        isUsingItem(): boolean;
        isAlwaysTicking(): boolean;
        interactAt($$0: Internal.Player_, $$1: Vec3d_, $$2: Internal.InteractionHand_): Internal.InteractionResult;
        emf$getX(): number;
        puzzleslib$acceptCapturedDrops(capturedDrops: Internal.Collection_<any>): Internal.Collection<any>;
        handler$hak000$gobber2$gobberIsFireImmune(cir: Internal.CallbackInfoReturnable_<any>): void;
        lerpTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: boolean): void;
        onPassengerTurned($$0: Internal.Entity_): void;
        modifyReturnValue$zhe000$additionalentityattributes$getMaxAir(original: number): number;
        spawnAtLocation($$0: Internal.ItemLike_): Internal.ItemEntity;
        emf$hasPassengers(): boolean;
        serializeNBT(): Internal.CompoundTag;
        setAttached(type: Internal.AttachmentType_<any>, value: any): any;
        port_lib$getEntityString(): string;
        markEffectsDirty(): void;
        lithiumOnBlockCacheDeleted(): void;
        "spawnAtLocation(net.minecraft.world.level.ItemLike,int)"($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        setInvulnerable($$0: boolean): void;
        push($$0: Internal.Entity_): void;
        emf$hasVehicle(): boolean;
        canMate($$0: Internal.Animal_): boolean;
        method_5992($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        maxUpStep(): number;
        getDynamicLightPrevY(): number;
        localvar$leb000$puzzleslib$hurt$1(amount: number, source: DamageSource_): number;
        setGlowing($$0: boolean): void;
        load($$0: Internal.CompoundTag_): void;
        "broadcastBreakEvent(net.minecraft.world.entity.EquipmentSlot)"($$0: Internal.EquipmentSlot_): void;
        setLeashedTo($$0: Internal.Entity_, $$1: boolean): void;
        isAlive(): boolean;
        startSleeping($$0: BlockPos_): void;
        getBbHeight(): number;
        getMeleeAttackRangeSqr($$0: Internal.LivingEntity_): number;
        handler$fed002$extraalchemy$readNbt(tag: Internal.CompoundTag_, cb: Internal.CallbackInfo_): void;
        bookshelf$getDrinkingSound(arg0: Internal.ItemStack_): Internal.SoundEvent;
        setTame($$0: boolean): void;
        getTags(): Internal.Set<string>;
        getViewVector($$0: number): Vec3d;
        getLastAttacker(): Internal.LivingEntity;
        hasControllingPassenger(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number, $$2: number): boolean;
        absMoveTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        getLastRollTicks(): number;
        getGoalSelector(): Internal.GoalSelector;
        localvar$leb000$puzzleslib$causeFallDamage$2(damageMultiplier: number): number;
        onPathfindingStart(): void;
        handler$zzb000$porting_lib_attributes$port_lib$entityGravity(travelVector: Vec3d_, ci: Internal.CallbackInfo_): void;
        getPercentFrozen(): number;
        setPortalCooldown($$0: number): void;
        hasGlowingTag(): boolean;
        shouldBlockExplode($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: number): boolean;
        emf$isInvisible(): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        isLeashed(): boolean;
        addEffect($$0: Internal.MobEffectInstance_): boolean;
        emf$isSprinting(): boolean;
        handler$leb000$puzzleslib$knockback$0(strength: number, ratioX: number, ratioZ: number, callback: Internal.CallbackInfo_): void;
        setVariant($$0: Internal.CatVariant_): void;
        getVariant(): any;
        ageUp($$0: number, $$1: boolean): void;
        handler$egi000$collective$LivingEntity_tick(ci: Internal.CallbackInfo_): void;
        handler$gec000$faster_entity_animations$getLeaningPitch(f: number, info: Internal.CallbackInfoReturnable_<any>): void;
        canRiderInteract(): boolean;
        getViewXRot($$0: number): number;
        handler$leb001$puzzleslib$die(damageSource: DamageSource_, callback: Internal.CallbackInfo_): void;
        fabric_getAttachments(): Internal.Map<any, any>;
        setPose($$0: Internal.Pose_): void;
        getReachDistance(): number;
        getEntityType(): Internal.EntityType<any>;
        isWaterCreature(): boolean;
        hex$playHurtSound(arg0: DamageSource_): void;
        pehkui_getScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        toString(): string;
        etf$getScoreboardTeam(): Internal.Team;
        getBreedOffspring(arg0: Internal.ServerLevel_, arg1: Internal.AgeableMob_): Internal.AgeableMob;
        setLastHurtByPlayer($$0: Internal.Player_): void;
        handler$ldh000$puzzleslib$removeVehicle(callback: Internal.CallbackInfo_): void;
        "getServer()"(): Internal.MinecraftServer;
        wasExperienceConsumed(): boolean;
        isPushable(): boolean;
        setYBodyRot($$0: number): void;
        foodEaten(is: Internal.ItemStack_): void;
        onClientRemoval(): void;
        getDistance(x: number, y: number, z: number): number;
        setMotionY(y: number): void;
        static createAttributes(): Internal.AttributeSupplier$Builder;
        localvar$lcp000$puzzleslib$spawnChildFromBreeding(child: Internal.AgeableMob_, serverLevel: Internal.ServerLevel_, partner: Internal.Animal_): Internal.AgeableMob;
        getAttached(type: Internal.AttachmentType_<any>): any;
        setRotation(yaw: number, pitch: number): void;
        isDynamicLightEnabled(): boolean;
        handler$ldh000$puzzleslib$startRiding(vehicle: Internal.Entity_, force: boolean, callback: Internal.CallbackInfoReturnable_<any>): void;
        calculateEntityAnimation($$0: boolean): void;
        forceAddEffect($$0: Internal.MobEffectInstance_, $$1: Internal.Entity_): void;
        setChestArmorItem(item: Internal.ItemStack_): void;
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        bookshelf$getHurtSound(arg0: DamageSource_): Internal.SoundEvent;
        onAboveBubbleCol($$0: boolean): void;
        archon$setOwner(uiud: string): void;
        "playSound(net.minecraft.sounds.SoundEvent,float,float)"(id: Internal.SoundEvent_, volume: number, pitch: number): void;
        toComponentPacket(key: Internal.ComponentKey_<any>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        isPassenger(): boolean;
        hasPose($$0: Internal.Pose_): boolean;
        supp$setSlimedTicks(newSlimedTicks: number, sync: boolean): void;
        isEyeInFluid($$0: Internal.TagKey_<Internal.Fluid>): boolean;
        isInvulnerableTo($$0: DamageSource_): boolean;
        makeStuckInBlock($$0: Internal.BlockState_, $$1: Vec3d_): void;
        getAttachedOrGet<A>(type: Internal.AttachmentType_<A>, defaultValue: Internal.Supplier_<A>): A;
        isSensitiveToWater(): boolean;
        skipAttackInteraction($$0: Internal.Entity_): boolean;
        lerpMotion($$0: number, $$1: number, $$2: number): void;
        "getAttributeValue(net.minecraft.core.Holder)"($$0: Internal.Holder_<Internal.Attribute>): number;
        shouldRender($$0: number, $$1: number, $$2: number): boolean;
        getJumpControl(): Internal.JumpControl;
        localvar$zcl000$porting_lib_base$port_lib$setSlipperiness(p: number): number;
        getFeetArmorItem(): Internal.ItemStack;
        handler$bia000$axiom$onTurn(d: number, e: number, ci: Internal.CallbackInfo_): void;
        static getViewScale(): number;
        getRelaxStateOneAmount($$0: number): number;
        handler$mpg000$tcdcommons$onAddStatusEffect(effect: Internal.MobEffectInstance_, source: Internal.Entity_, ci: Internal.CallbackInfoReturnable_<any>): void;
        getVisualRotationYInDegrees(): number;
        setSpeed($$0: number): void;
        requiresCustomPersistence(): boolean;
        handler$nbm000$things$onShieldHit(attacker: Internal.LivingEntity_, ci: Internal.CallbackInfo_): void;
        isDiscrete(): boolean;
        unRide(): void;
        getLevel(): Internal.Level;
        "spawnAtLocation(net.minecraft.world.item.ItemStack)"($$0: Internal.ItemStack_): Internal.ItemEntity;
        getCombatTracker(): Internal.CombatTracker;
        updateDynamicGameEventListener($$0: Internal.BiConsumer_<Internal.DynamicGameEventListener<any>, Internal.ServerLevel>): void;
        canBreed(): boolean;
        "onSyncedDataUpdated(net.minecraft.network.syncher.EntityDataAccessor)"($$0: Internal.EntityDataAccessor_<any>): void;
        emf$prevY(): number;
        isNoAi(): boolean;
        extinguishFire(): void;
        getChestArmorItem(): Internal.ItemStack;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number): void;
        port_lib$lastPos(): BlockPos;
        tell(message: net.minecraft.network.chat.Component_): void;
        closerThan($$0: Internal.Entity_, $$1: number): boolean;
        hex$getSoundVolume(): number;
        getDistanceSq(pos: BlockPos_): number;
        indicateDamage($$0: number, $$1: number): void;
        localvar$nbm000$things$waxGlandWater(j: number): number;
        canBeSeenByAnyone(): boolean;
        emf$getTypeString(): string;
        getLieDownAmountTail($$0: number): number;
        setVariant(arg0: any): void;
        isFullyFrozen(): boolean;
        setLying($$0: boolean): void;
        litematica_setWorld(arg0: Internal.Level_): void;
        isInWall(): boolean;
        getAllSlots(): Internal.Iterable<Internal.ItemStack>;
        getLieDownAmount($$0: number): number;
        handler$bfg003$artifacts$tick(ci: Internal.CallbackInfo_): void;
        remove($$0: Internal.Entity$RemovalReason_): void;
        getScale(): number;
        isSuppressingSlidingDownLadder(): boolean;
        getBlockZ(): number;
        handler$egi000$collective$LivingEntity_die(damageSource: DamageSource_, ci: Internal.CallbackInfo_): void;
        dampensVibrations(): boolean;
        hasAttached(type: Internal.AttachmentType_<any>): boolean;
        isSilent(): boolean;
        setUseItem(arg0: Internal.ItemStack_): void;
        "playSound(net.minecraft.sounds.SoundEvent)"($$0: Internal.SoundEvent_): void;
        getPitch(): number;
        getPathfindingMalus($$0: Internal.BlockPathTypes_): number;
        modify$nbm000$things$waxGlandLava(speed: number): number;
        getRandom(): Internal.RandomSource;
        canReplaceEqualItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        rotate($$0: Internal.Rotation_): number;
        handler$hcn000$hexcasting$onThunderHit(entityType: Internal.EntityType_<any>, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        getPassengersAndSelf(): Internal.Stream<any>;
        handler$leb000$puzzleslib$causeFallDamage$0(distance: number, damageMultiplier: number, damageSource: DamageSource_, callback: Internal.CallbackInfoReturnable_<any>): void;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        "getAttributeBaseValue(net.minecraft.core.Holder)"($$0: Internal.Holder_<Internal.Attribute>): number;
        method_5652($$0: Internal.CompoundTag_): void;
        clearRestriction(): void;
        redirect$jgg000$moonlight$fixSpawnAnimX(instance: Internal.Mob_, v: number): number;
        getOriginalFoodStack(): Internal.ItemStack;
        getAge(): number;
        rayTrace(): Internal.RayTraceResultJS;
        alwaysAccepts(): boolean;
        "isHolding(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.ItemStack>): boolean;
        getNoActionTime(): number;
        isVisuallyCrawling(): boolean;
        isAggressive(): boolean;
        setYya($$0: number): void;
        setDropChance($$0: Internal.EquipmentSlot_, $$1: number): void;
        handler$ieb000$lambdynlights$onRemove(ci: Internal.CallbackInfo_): void;
        "broadcastBreakEvent(net.minecraft.world.InteractionHand)"($$0: Internal.InteractionHand_): void;
        port_lib$setRemovalReason(arg0: Internal.Entity$RemovalReason_): void;
        teleportRelative($$0: number, $$1: number, $$2: number): void;
        isFood($$0: Internal.ItemStack_): boolean;
        setBaby($$0: boolean): void;
        getLastHurtByMob(): Internal.LivingEntity;
        pehkui_setScaleCache(scaleCache: Internal.ScaleData_[]): void;
        isInWaterOrBubble(): boolean;
        botania_setLoveCause(arg0: Internal.UUID_): void;
        getPortalCooldown(): number;
        getItem(): Internal.ItemStack;
        causeFallDamage($$0: number, $$1: number, $$2: DamageSource_): boolean;
        getDynamicLightChunksToRebuild(forced: boolean): Internal.LongSet;
        releaseUsingItem(): void;
        bw_getNextAirOnLand(arg0: number): number;
        getPosition($$0: number): Vec3d;
        removeFreeWill(): void;
        handler$leb000$puzzleslib$removeAllEffects(callback: Internal.CallbackInfoReturnable_<any>): void;
        removeWhenFarAway($$0: number): boolean;
        wait(arg0: number): void;
        isIgnoringBlockTriggers(): boolean;
        setRecordPlayingNearby($$0: BlockPos_, $$1: boolean): void;
        etf$getItemsEquipped(): Internal.Iterable<any>;
        getHandHoldingItemAngle($$0: Internal.Item_): Vec3d;
        hasItemInSlot($$0: Internal.EquipmentSlot_): boolean;
        distanceToSqr($$0: Vec3d_): number;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        modifyAttached<A>(type: Internal.AttachmentType_<A>, modifier: Internal.UnaryOperator_<A>): A;
        isSteppingCarefully(): boolean;
        handler$zno000$apoli$doSpiderClimbing(info: Internal.CallbackInfoReturnable_<any>): void;
        "spawnAtLocation(net.minecraft.world.item.ItemStack,float)"($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        getBlockX(): number;
        /**
         * @deprecated
        */
        getLightLevelDependentMagicValue(): number;
        isFallFlying(): boolean;
        getEncodeId(): string;
        puzzleslib$getSpawnType(): Internal.MobSpawnType;
        bettertrims$setAvoidedDamage(avoidDamage: boolean): void;
        getY($$0: number): number;
        emf$prevPitch(): number;
        getMaxHeadXRot(): number;
        getNbt(): Internal.CompoundTag;
        setInvisible($$0: boolean): void;
        etf$getArmorItems(): Internal.Iterable<any>;
        isSubmergedInLoosely(tag: Internal.TagKey_<any>): boolean;
        getEffect($$0: Internal.MobEffect_): Internal.MobEffectInstance;
        setTotalMovementSpeedMultiplier(speed: number): void;
        getDynamicLightY(): number;
        setHealth($$0: number): void;
        attack($$0: DamageSource_, $$1: number): boolean;
        onInsideBubbleColumn($$0: boolean): void;
        handler$cfa000$betterend$be_hurt(source: DamageSource_, amount: number, info: Internal.CallbackInfoReturnable_<any>): void;
        getEyePosition(): Vec3d;
        getEyeHeight(): number;
        setDiscardFriction($$0: boolean): void;
        hasPassenger($$0: Internal.Predicate_<Internal.Entity>): boolean;
        bettertridents$getLastDamageSource(): DamageSource;
        getYaw(): number;
        swing($$0: Internal.InteractionHand_, $$1: boolean): void;
        getUsedItemHand(): Internal.InteractionHand;
        setDefaultMovementSpeed(speed: number): void;
        canAttackType($$0: Internal.EntityType_<any>): boolean;
        hex$setLastDamageStamp(arg0: number): void;
        canEntityBeSeen(entity: Internal.LivingEntity_): boolean;
        modifyExpressionValue$zhf000$additionalentityattributes$additionalEntityAttributes$knockDownwards(original: number): number;
        getBrain(): Internal.Brain<any>;
        modify$bpk000$bclib$be_travel(moveDelta: Vec3d_): Vec3d;
        setCustomNameVisible($$0: boolean): void;
        isAlliedTo($$0: Internal.Team_): boolean;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>): A;
        canFireProjectileWeapon($$0: Internal.ProjectileWeaponItem_): boolean;
        getControllingPassenger(): Internal.LivingEntity;
        bw_getNextAirUnderwater(arg0: number): number;
        getScriptType(): Internal.ScriptType;
        handler$leb000$puzzleslib$releaseUsingItem(callback: Internal.CallbackInfo_): void;
        isLying(): boolean;
        handler$cbm000$besmirchment$handleStatus(status: number, ci: Internal.CallbackInfo_): void;
        port_lib$getDeathSound(): Internal.SoundEvent;
        shouldDiscardFriction(): boolean;
        startRiding($$0: Internal.Entity_): boolean;
        saveWithoutId($$0: Internal.CompoundTag_): Internal.CompoundTag;
        getForward(): Vec3d;
        setFeetArmorItem(item: Internal.ItemStack_): void;
        getId(): number;
        pehkui_isFirstUpdate(): boolean;
        canBeHitByProjectile(): boolean;
        getRecipientsForComponentSync(): Internal.Iterable<any>;
        handler$zcl000$porting_lib_base$port_lib$onUsingTick(ci: Internal.CallbackInfo_): void;
        getEyeY(): number;
        handler$ham000$gobber2$gobberClimbing(cir: Internal.CallbackInfoReturnable_<any>): void;
        skipDropExperience(): void;
        fabric_readAttachmentsFromNbt(nbt: Internal.CompoundTag_): void;
        localvar$leb000$puzzleslib$getVisibilityPercent(value: number, lookingEntity: Internal.Entity_): number;
        getBoundingBox(): Internal.AABB;
        isInWaterOrRain(): boolean;
        handler$leb000$puzzleslib$die$1(damageSource: DamageSource_, callback: Internal.CallbackInfo_): void;
        setItemSlot($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_): void;
        equals($$0: any): boolean;
        getViewYRot($$0: number): number;
        fabric_setCustomTeleportTarget(teleportTarget: Internal.PortalInfo_): void;
        dismountsUnderwater(): boolean;
        isAffectedByPotions(): boolean;
        playerTouch($$0: Internal.Player_): void;
        addTag($$0: string): boolean;
        getEyeHeight($$0: Internal.Pose_): number;
        getAddEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>;
        callIsBeingRainedOn(): boolean;
        static getEquipmentForSlot($$0: Internal.EquipmentSlot_, $$1: number): Internal.Item;
        isWithinRestriction($$0: BlockPos_): boolean;
        getTeam(): Internal.Team;
        handler$lde001$puzzleslib$mobInteract(player: Internal.Player_, interactionHand: Internal.InteractionHand_, callback: Internal.CallbackInfoReturnable_<any>): void;
        static of(entity: Internal.LivingEntity_): Internal.EntityProperties;
        setTicksFrozen($$0: number): void;
        getUseItem(): Internal.ItemStack;
        getMyRidingOffset(): number;
        handler$hal000$gobber2$gobberCanBreatheInWater(cir: Internal.CallbackInfoReturnable_<any>): void;
        dismountTo($$0: number, $$1: number, $$2: number): void;
        etf$getEntityKey(): string;
        etf$getPose(): Internal.Pose;
        hasCustomName(): boolean;
        getSwimAmount($$0: number): number;
        isLiving(): boolean;
        getX(): number;
        isVehicle(): boolean;
        static transfer(original: Internal.AttachmentTarget_, target: Internal.AttachmentTarget_, isDeath: boolean): void;
        bettertrims$didAvoidDamage(): boolean;
        resetDynamicLight(): void;
        handler$han000$gobber2$gobberSetTarget(target: Internal.LivingEntity_, ci: Internal.CallbackInfo_): void;
        handler$kpc001$porting_lib_entity$onJump(ci: Internal.CallbackInfo_): void;
        spawnAtLocation($$0: Internal.ItemStack_): Internal.ItemEntity;
        setCollarColor($$0: Internal.DyeColor_): void;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        handler$zcl000$porting_lib_base$port_lib$canBeAffected(effect: Internal.MobEffectInstance_, cir: Internal.CallbackInfoReturnable_<any>): void;
        thunderHit($$0: Internal.ServerLevel_, $$1: Internal.LightningBolt_): void;
        setIsInPowderSnow($$0: boolean): void;
        etf$distanceTo(entity: Internal.Entity_): number;
        doEnchantDamageEffects($$0: Internal.LivingEntity_, $$1: Internal.Entity_): void;
        setCustomName($$0: net.minecraft.network.chat.Component_): void;
        lambdynlights$scheduleTrackedChunksRebuild(renderer: Internal.LevelRenderer_): void;
        handler$hak000$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        getTeamId(): string;
        setStingerCount($$0: number): void;
        getBreedOffspring($$0: Internal.ServerLevel_, $$1: Internal.AgeableMob_): this;
        getMaxHeadYRot(): number;
        isCustomNameVisible(): boolean;
        isSupportedBy($$0: BlockPos_): boolean;
        getPistonPushReaction(): Internal.PushReaction;
        lookAt($$0: Internal.EntityAnchorArgument$Anchor_, $$1: Vec3d_): void;
        handler$kpc000$porting_lib_entity$port_lib$cancelFall(fallDistance: number, multiplier: number, source: DamageSource_, cir: Internal.CallbackInfoReturnable_<any>): void;
        hurtCurrentlyUsedShield($$0: number): void;
        getLootTableSeed(): number;
        collide($$0: Vec3d_): Vec3d;
        getMotionX(): number;
        "onSyncedDataUpdated(java.util.List)"($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        canBeLeashed($$0: Internal.Player_): boolean;
        hasIndirectPassenger($$0: Internal.Entity_): boolean;
        gear_core_setActiveSets(sets: Internal.HashMap_<any, any>): void;
        getEntityData(): Internal.SynchedEntityData;
        bookshelf$getFallDamageSound(arg0: number): Internal.SoundEvent;
        handleInsidePortal($$0: BlockPos_): void;
        getPotionEffects(): Internal.EntityPotionEffectsJS;
        getLastHurtByPlayerTime(): number;
        absMoveTo($$0: number, $$1: number, $$2: number): void;
        handler$cfa000$betterend$be_canBeAffected(mobEffectInstance: Internal.MobEffectInstance_, info: Internal.CallbackInfoReturnable_<any>): void;
        isOnRails(): boolean;
        getAttachedOrThrow<A>(type: Internal.AttachmentType_<A>): A;
        getStingerCount(): number;
        markFusionRecomputeModels(): void;
        getFallSounds(): Internal.LivingEntity$Fallsounds;
        getAttributeTotalValue(attribute: Internal.Attribute_): number;
        getDimensionChangingDelay(): number;
        handler$cbi000$besmirchment$getScoreboardTeam(cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDynamicLuminance(): number;
        setYaw($$0: number): void;
        getPickRadius(): number;
        isPathFinding(): boolean;
        isTame(): boolean;
        supp$getSlimedTicks(): number;
        isRemoved(): boolean;
        emf$isSneaking(): boolean;
        teleportToWithTicket($$0: number, $$1: number, $$2: number): void;
        spawnAnim(): void;
        getJumpBoostPower(): number;
        fillCrashReportCategory($$0: Internal.CrashReportCategory_): void;
        self(): Internal.Entity;
        refreshDimensions(): void;
        pehkui_writeScaleNbt(nbt: Internal.CompoundTag_): Internal.CompoundTag;
        bookshelf$getAmbientSound(): Internal.SoundEvent;
        "spawnAtLocation(net.minecraft.world.level.ItemLike)"($$0: Internal.ItemLike_): Internal.ItemEntity;
        "getAttributeValue(net.minecraft.world.entity.ai.attributes.Attribute)"($$0: Internal.Attribute_): number;
        "isHolding(net.minecraft.world.item.Item)"($$0: Internal.Item_): boolean;
        setShiftKeyDown($$0: boolean): void;
        getEyePosition($$0: number): Vec3d;
        getPassengers(): Internal.EntityArrayList;
        handler$ldh000$puzzleslib$spawnAtLocation(stack: Internal.ItemStack_, offsetY: number, callback: Internal.CallbackInfoReturnable_<any>, itemEntity: Internal.ItemEntity_): void;
        getZ(): number;
        bettertrims$applyCelestialToAttackCooldown(original: number): number;
        teleportTo($$0: number, $$1: number, $$2: number): void;
        handler$zbk000$porting_lib_base$port_lib$spawnSprintParticle(ci: Internal.CallbackInfo_, pos: BlockPos_, state: Internal.BlockState_): void;
        getAttributeBaseValue($$0: Internal.Holder_<Internal.Attribute>): number;
        getServer(): Internal.MinecraftServer;
        getExperienceReward(): number;
        getFirstPassenger(): Internal.Entity;
        heal($$0: number): void;
        handler$leb01a$puzzleslib$tick(callback: Internal.CallbackInfo_): void;
        setLastHurtMob($$0: Internal.Entity_): void;
        setLastHurtByMob($$0: Internal.LivingEntity_): void;
        interact($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        getDismountLocationForPassenger($$0: Internal.LivingEntity_): Vec3d;
        "getBreedOffspring(net.minecraft.server.level.ServerLevel,net.minecraft.world.entity.AgeableMob)"($$0: Internal.ServerLevel_, $$1: Internal.AgeableMob_): this;
        checkSlowFallDistance(): void;
        getLeashingEntities(): Internal.Set<any>;
        level(): Internal.EntityGetter;
        canStandOnFluid($$0: Internal.FluidState_): boolean;
        setFabricBalmData(tag: Internal.CompoundTag_): void;
        touchingUnloadedChunk(): boolean;
        modifyAttribute(attribute: Internal.Attribute_, identifier: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getLookAngle(): Vec3d;
        modifyReturnValue$zhf000$additionalentityattributes$additionalEntityAttributes$modifyJumpVelocity(original: number): number;
        getAmbientSoundInterval(): number;
        emf$isOnFire(): boolean;
        setArrowCount($$0: number): void;
        getMotionZ(): number;
        isPersistenceRequired(): boolean;
        isInvisible(): boolean;
        is($$0: Internal.Entity_): boolean;
        getBedOrientation(): Internal.Direction;
        ejectPassengers(): void;
        removeEffect($$0: Internal.MobEffect_): boolean;
        updateDynamicLightPreviousCoordinates(): void;
        getProfile(): Internal.GameProfile;
        setInLove($$0: Internal.Player_): void;
        isDeadOrDying(): boolean;
        setHeadArmorItem(item: Internal.ItemStack_): void;
        static setViewScale($$0: number): void;
        emf$isAlive(): boolean;
        take($$0: Internal.Entity_, $$1: number): void;
        setLevelCallback($$0: Internal.EntityInLevelCallback_): void;
        getLookControl(): Internal.LookControl;
        redirect$joh000$origins$method_26317Proxy(entity: Internal.LivingEntity_, d: number, bl: boolean, vec3d: Vec3d_): Vec3d;
        playSound($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        isOrderedToSit(): boolean;
        canAttack($$0: Internal.LivingEntity_): boolean;
        static getSpeedUpSecondsWhenFeeding($$0: number): number;
        getOffHandItem(): Internal.ItemStack;
        startSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isOnScoreboardTeam(teamId: string): boolean;
        startUsingItem($$0: Internal.InteractionHand_): void;
        invokePlayEquipmentBreakEffects(arg0: Internal.ItemStack_): void;
        localvar$bbb000$architectury$modifyLevelCallback_setLevelCallback(callback: Internal.EntityInLevelCallback_): Internal.EntityInLevelCallback;
        position(): Vec3d;
        setTimeout(): void;
        static getEquipmentSlotForItem($$0: Internal.ItemStack_): Internal.EquipmentSlot;
        getEquipment(slot: Internal.EquipmentSlot_): Internal.ItemStack;
        displayFireAnimation(): boolean;
        isOutOfCamera(): boolean;
        getRopeHoldPosition($$0: number): Vec3d;
        copyPosition($$0: Internal.Entity_): void;
        "hasPassenger(net.minecraft.world.entity.Entity)"($$0: Internal.Entity_): boolean;
        extraalchemy_spawnParticles(arg0: Internal.ItemStack_, arg1: number): void;
        etf$canBeBright(): boolean;
        isCrouching(): boolean;
        "getAttributeBaseValue(net.minecraft.world.entity.ai.attributes.Attribute)"($$0: Internal.Attribute_): number;
        onLeaveCombat(): void;
        wrapOperation$bgd000$artifacts$travel(block: Internal.Block_, original: Internal.Operation_<any>): number;
        setY(y: number): void;
        getAttributeValue($$0: Internal.Attribute_): number;
        getFeetBlockState(): Internal.BlockState;
        archon$isOwner(player: Internal.Player_): boolean;
        isWithinRestriction(): boolean;
        getChangeListener(): Internal.EntityInLevelCallback;
        positionRider($$0: Internal.Entity_): void;
        baseTick(): void;
        broadcastToPlayer($$0: Internal.ServerPlayer_): boolean;
        setSharedFlag($$0: number, $$1: boolean): void;
        getSleepingPos(): Optional<BlockPos>;
        damageHeldItem(): void;
        getCustomName(): net.minecraft.network.chat.Component;
        getClass(): typeof any;
        isVisuallySwimming(): boolean;
        getMaxAirSupply(): number;
        handler$zcl000$porting_lib_base$port_lib$addEffect(newEffect: Internal.MobEffectInstance_, source: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>, oldEffect: Internal.MobEffectInstance_): void;
        setItemInHand($$0: Internal.InteractionHand_, $$1: Internal.ItemStack_): void;
        dynamicLightTick(): void;
        setMaxHealth(hp: number): void;
        getFacing(): Internal.Direction;
        emf$isWet(): boolean;
        isPassengerOfSameVehicle($$0: Internal.Entity_): boolean;
        getBoundingBoxForCulling(): Internal.AABB;
        setAge($$0: number): void;
        getTarget(): Internal.LivingEntity;
        static collideBoundingBox(entity: Internal.Entity_, movement: Vec3d_, entityBoundingBox: Internal.AABB_, world: Internal.Level_, collisions: Internal.List_<any>): Vec3d;
        fzzy_core_getModifierContainer(): Internal.ModifierContainer;
        restrictTo($$0: BlockPos_, $$1: number): void;
        isInLove(): boolean;
        trackingPosition(): Vec3d;
        getNameTagOffsetY(): number;
        isInvulnerable(): boolean;
        isInLava(): boolean;
        isInWater(): boolean;
        awardKillScore($$0: Internal.Entity_, $$1: number, $$2: DamageSource_): void;
        finalizeSpawn($$0: Internal.ServerLevelAccessor_, $$1: Internal.DifficultyInstance_, $$2: Internal.MobSpawnType_, $$3: Internal.SpawnGroupData_, $$4: Internal.CompoundTag_): Internal.SpawnGroupData;
        localvar$leb000$puzzleslib$knockback$3(ratioZ: number): number;
        unsetRemoved(): void;
        pehkui_getScaleCache(): Internal.ScaleData[];
        swing($$0: Internal.InteractionHand_): void;
        hasEffect($$0: Internal.MobEffect_): boolean;
        getHeldItem(hand: Internal.InteractionHand_): Internal.ItemStack;
        setFusionModel(layerIndex: number, model: Internal.Triple_<any, any, any>): void;
        getRootVehicle(): Internal.Entity;
        getOwnerUUID(): Internal.UUID;
        onPathfindingDone(): void;
        save($$0: Internal.CompoundTag_): boolean;
        archon$setLifetime(seconds: number): void;
        modify$zhf000$additionalentityattributes$additionalEntityAttributes$waterSpeed(original: number): number;
        getLocalBoundsForPose($$0: Internal.Pose_): Internal.AABB;
        isNoGravity(): boolean;
        dodge(chance: number): boolean;
        onItemPickup($$0: Internal.ItemEntity_): void;
        hex$setLastDamageSource(arg0: DamageSource_): void;
        emf$getY(): number;
        handler$kom000$porting_lib_entity$port_lib$entityInit(entityType: Internal.EntityType_<any>, world: Internal.Level_, ci: Internal.CallbackInfo_): void;
        resetLove(): void;
        bookshelf$createHoverEvent(): Internal.HoverEvent;
        updateSwimming(): void;
        isHolding($$0: Internal.Predicate_<Internal.ItemStack>): boolean;
        getSpeed(): number;
        abstract getCachedFeetBlockState(): Internal.BlockState;
        shouldInformAdmins(): boolean;
        rideTick(): void;
        port_lib$onEffectRemoved(arg0: Internal.MobEffectInstance_): void;
        handler$zll000$amethyst_imbuement$onAttackWhilstStunnedNoTarget(hand: Internal.InteractionHand_, ci: Internal.CallbackInfo_): void;
        wait(): void;
        getUuid(): Internal.UUID;
        setOffHandItem(item: Internal.ItemStack_): void;
        spawn(): void;
        setNoAi($$0: boolean): void;
        teleportTo($$0: Internal.ServerLevel_, $$1: number, $$2: number, $$3: number, $$4: Internal.Set_<Internal.RelativeMovement>, $$5: number, $$6: number): boolean;
        hiss(): void;
        etf$getCustomName(): net.minecraft.network.chat.Component;
        fabric_writeAttachmentsToNbt(nbt: Internal.CompoundTag_): void;
        shouldShowName(): boolean;
        getArmorSlots(): Internal.Iterable<Internal.ItemStack>;
        canPickUpLoot(): boolean;
        kill(): void;
        onEnterCombat(): void;
        updateNavigationRegistration(): void;
        animateHurt($$0: number): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        handler$kom000$porting_lib_entity$port_lib$onEntityRemove(reason: Internal.Entity$RemovalReason_, ci: Internal.CallbackInfo_): void;
        static resetForwardDirectionOfRelativePortalPosition($$0: Vec3d_): Vec3d;
        callGetEyeHeight(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        hasRestriction(): boolean;
        getHeadArmorItem(): Internal.ItemStack;
        deserializeNBT(arg0: Internal.Tag_): void;
        getCurrentModifyFoodPowers(): Internal.List<any>;
        getBbWidth(): number;
        splitIntoDynamicLightEntries(): Internal.Stream<Internal.SpatialLookupEntry>;
        addDeltaMovement($$0: Vec3d_): void;
        pehkui_setOnGround(onGround: boolean): void;
        localvar$leb000$puzzleslib$knockback$1(strength: number): number;
        wantsToAttack($$0: Internal.LivingEntity_, $$1: Internal.LivingEntity_): boolean;
        bettertrims$addLateAttributes(adder: Internal.Consumer_<any>): void;
        handler$lef000$puzzleslib$readAdditionalSaveData(compound: Internal.CompoundTag_, callback: Internal.CallbackInfo_): void;
        sendLeashState(): void;
        "getName()"(): net.minecraft.network.chat.Component;
        mirror($$0: Internal.Mirror_): number;
        static port_lib$collideWithShapes(vec3: Vec3d_, aABB: Internal.AABB_, list: Internal.List_<Internal.VoxelShape>): Vec3d;
        knockback($$0: number, $$1: number, $$2: number): void;
        getTicksRequiredToFreeze(): number;
        getVisibilityPercent($$0: Internal.Entity_): number;
        getMaxSpawnClusterSize(): number;
        localvar$kpc000$porting_lib_entity$port_lib$modifyDistance(fallDistance: number): number;
        artifacts$getPocketPistonLength(): number;
        emf$prevZ(): number;
        isInSittingPose(): boolean;
        getUsername(): string;
        getInLoveTime(): number;
        move($$0: Internal.MoverType_, $$1: Vec3d_): void;
        "setVariant(java.lang.Object)"(arg0: any): void;
        lithiumOnBlockCacheSet(newState: Internal.BlockState_): void;
        isPickable(): boolean;
        setYHeadRot($$0: number): void;
        setJumping($$0: boolean): void;
        getCustomData(): Internal.CompoundTag;
        handler$zno000$apoli$getGroup(info: Internal.CallbackInfoReturnable_<any>): void;
        getPickResult(): Internal.ItemStack;
        "getMainHandItem()"(): Internal.ItemStack;
        getAbsorptionAmount(): number;
        getRandomY(): number;
        onEffectRemoved($$0: Internal.MobEffectInstance_): void;
        getDisplayName(): net.minecraft.network.chat.Component;
        static "tickEntity(net.minecraft.world.entity.Entity)"(entity: Internal.Entity_): void;
        getMobType(): Internal.MobType;
        travel($$0: Vec3d_): void;
        getItemInHand($$0: Internal.InteractionHand_): Internal.ItemStack;
        localvar$leb000$puzzleslib$hurt$0(amount: number, source: DamageSource_): number;
        getDynamicLightPrevX(): number;
        shouldBeSaved(): boolean;
        fabric_hasPersistentAttachments(): boolean;
        method_5749($$0: Internal.CompoundTag_): void;
        hurtHelmet($$0: DamageSource_, $$1: number): void;
        removeTag($$0: string): boolean;
        isHoldingInAnyHand(i: Internal.Ingredient_): boolean;
        getFluidHeight($$0: Internal.TagKey_<Internal.Fluid>): number;
        canSpawnSoulSpeedParticle(): boolean;
        notifyAll(): void;
        aiStep(): void;
        handler$leb000$puzzleslib$removeEffect(effect: Internal.MobEffect_, callback: Internal.CallbackInfoReturnable_<any>): void;
        getPassengersRidingOffset(): number;
        setAttributeBaseValue(attribute: Internal.Attribute_, value: number): void;
        distanceToEntitySqr($$0: Internal.Entity_): number;
        isFrame(): boolean;
        broadcastBreakEvent($$0: Internal.InteractionHand_): void;
        setLegsArmorItem(item: Internal.ItemStack_): void;
        localvar$leb000$puzzleslib$causeFallDamage$1(fallDistance: number): number;
        discard(): void;
        "handler$mhe000$step-height-entity-attribute$getStepHeight"(cir: Internal.CallbackInfoReturnable_<any>): void;
        sendSystemMessage($$0: net.minecraft.network.chat.Component_): void;
        acceptsSuccess(): boolean;
        static tickEntity(entity: Internal.LivingEntity_): void;
        setNoGravity($$0: boolean): void;
        getUseItemRemainingTicks(): number;
        gear_core_getActiveSets(): Internal.HashMap<any, any>;
        getIndirectPassengers(): Internal.Iterable<any>;
        attackable(): boolean;
        createCommandSourceStack(): Internal.CommandSourceStack;
        getNavigation(): Internal.PathNavigation;
        isControlledByLocalInstance(): boolean;
        isMonster(): boolean;
        pehkui_setShouldSyncScales(sync: boolean): void;
        handler$cbm000$besmirchment$canTarget(type: Internal.EntityType_<any>, cir: Internal.CallbackInfoReturnable_<any>): void;
        getLoveCause(): Internal.ServerPlayer;
        getLastClimbablePos(): Optional<BlockPos>;
        getEatingSound($$0: Internal.ItemStack_): Internal.SoundEvent;
        setLastDynamicLuminance(luminance: number): void;
        getPerceivedTargetDistanceSquareForMeleeAttack($$0: Internal.LivingEntity_): number;
        setId($$0: number): void;
        onSyncedDataUpdated($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        getHorizontalFacing(): Internal.Direction;
        getType(): string;
        static checkAnimalSpawnRules($$0: Internal.EntityType_<Internal.Animal>, $$1: Internal.LevelAccessor_, $$2: Internal.MobSpawnType_, $$3: BlockPos_, $$4: Internal.RandomSource_): boolean;
        isDamageSourceBlocked($$0: DamageSource_): boolean;
        getLightProbePosition($$0: number): Vec3d;
        getActiveEffectsMap(): Internal.Map<Internal.MobEffect, Internal.MobEffectInstance>;
        wrapOperation$mac000$smarterfarmers$smarterFarmers$overrideMobGriefing(instance: Internal.GameRules_, key: Internal.GameRules$Key_<any>, original: Internal.Operation_<any>): boolean;
        emf$prevX(): number;
        onEquipItem($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_, $$2: Internal.ItemStack_): void;
        checkDespawn(): void;
        pehkui_shouldSyncScales(): boolean;
        getWalkTargetValue($$0: BlockPos_, $$1: Internal.LevelReader_): number;
        lookAt($$0: Internal.Entity_, $$1: number, $$2: number): void;
        setHeldItem(hand: Internal.InteractionHand_, item: Internal.ItemStack_): void;
        port_lib$maybeDisableShield(arg0: Internal.Player_, arg1: Internal.ItemStack_, arg2: Internal.ItemStack_): void;
        equipItemIfPossible($$0: Internal.ItemStack_): Internal.ItemStack;
        onSyncedDataUpdated($$0: Internal.EntityDataAccessor_<any>): void;
        lerpHeadTo($$0: number, $$1: number): void;
        canDisableShield(): boolean;
        setMotionX(x: number): void;
        isOwnedBy($$0: Internal.LivingEntity_): boolean;
        getHandSlots(): Internal.Iterable<Internal.ItemStack>;
        distanceToEntity($$0: Internal.Entity_): number;
        bookshelf$getDeathSound(): Internal.SoundEvent;
        wait(arg0: number, arg1: number): void;
        getTeamColor(): number;
        lithiumSetClimbingMobCachingSectionUpdateBehavior(listenForCachedBlockChanges: boolean): void;
        setNbt(nbt: Internal.CompoundTag_): void;
        "getVariant()"(): Internal.CatVariant;
        lambdynlights$getTrackedLitChunkPos(): Internal.LongSet;
        checkSpawnObstruction($$0: Internal.LevelReader_): boolean;
        getRecallPosition(): Internal.DimensionalPosition;
        extinguish(): void;
        setDynamicLightEnabled(enabled: boolean): void;
        getRestrictRadius(): number;
        moveTo($$0: Vec3d_): void;
        isColliding($$0: BlockPos_, $$1: Internal.BlockState_): boolean;
        "swing(net.minecraft.world.InteractionHand)"($$0: Internal.InteractionHand_): void;
        lambdynlights$updateDynamicLight(renderer: Internal.LevelRenderer_): boolean;
        getRegisteredNavigation(): Internal.PathNavigation;
        bettertrims$isWearing(effect: Internal.TrimEffect_): boolean;
        static port_lib$collideWithShapes$porting_lib_accessors_$md$424943$0(arg0: Vec3d_, arg1: Internal.AABB_, arg2: Internal.List_<any>): Vec3d;
        isForcedVisible(): boolean;
        isInvertedHealAndHarm(): boolean;
        handler$jon000$origins$doWaterBreathing(info: Internal.CallbackInfoReturnable_<any>): void;
        canHoldItem($$0: Internal.ItemStack_): boolean;
        killedEntity($$0: Internal.ServerLevel_, $$1: Internal.LivingEntity_): boolean;
        getAttachedOrElse<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        isFreezing(): boolean;
        runCommand(command: string): number;
        hex$getDeathSound(): Internal.SoundEvent;
        setGuaranteedDrop($$0: Internal.EquipmentSlot_): void;
        setSharedFlagOnFire($$0: boolean): void;
        set defaultMovementSpeedMultiplier(speed: number)
        get suppressingBounce(): boolean
        set target($$0: Internal.LivingEntity_)
        set culled(value: boolean)
        get onFire(): boolean
        get owner(): Internal.LivingEntity
        get positionCodec(): Internal.VecDeltaCodec
        set maxUpStep($$0: number)
        get fallFlyingTicks(): number
        set xxa($$0: number)
        set delayedLeashHolderId($$0: number)
        get shiftKeyDown(): boolean
        set UUID($$0: Internal.UUID_)
        get relaxStateOne(): boolean
        set motionZ(z: number)
        get blockY(): number
        get isInsideStructureTracker(): Internal.IsInsideStructureTracker
        set playerHitTimer(arg0: number)
        get spectator(): boolean
        set mainHandItem(item: Internal.ItemStack_)
        get persistentData(): Internal.CompoundTag
        get health(): number
        get maxHealth(): number
        get registeredToWorld(): boolean
        set aggressive($$0: boolean)
        set removed($$0: Internal.Entity$RemovalReason_)
        get inWaterRainOrBubble(): boolean
        get removalReason(): Internal.Entity$RemovalReason
        set boundingBox($$0: Internal.AABB_)
        get ambientCreature(): boolean
        set zza($$0: number)
        get block(): Internal.BlockContainerJS
        get name(): net.minecraft.network.chat.Component
        get variant(): Internal.CatVariant
        get controlledVehicle(): Internal.Entity
        get armorValue(): number
        get killCredit(): Internal.LivingEntity
        get componentContainer(): Internal.ComponentContainer
        get dynamicLightPrevZ(): number
        set outOfCamera(value: boolean)
        get autoSpinAttack(): boolean
        get remainingFireTicks(): number
        get maxFallDistance(): number
        get ticksFrozen(): number
        get dynamicLightZ(): number
        get voicePitch(): number
        set statusMessage(message: net.minecraft.network.chat.Component_)
        set sleepingPos($$0: BlockPos_)
        get descending(): boolean
        get headRotSpeed(): number
        get lastHurtByPlayer(): Internal.Player
        get YHeadRot(): number
        set absorptionAmount($$0: number)
        set recallData(pos: Internal.DimensionalPosition_)
        set deltaMovement($$0: Vec3d_)
        get baby(): boolean
        get culled(): boolean
        get glowing(): boolean
        get leashedByEntities(): Internal.Set<any>
        get leashOffset(): Vec3d
        get attackable(): boolean
        get underWater(): boolean
        get leashHolder(): Internal.Entity
        get sensing(): Internal.Sensing
        get legsArmorItem(): Internal.ItemStack
        get luminance(): number
        get selfAndPassengers(): Internal.Stream<any>
        get deltaMovement(): Vec3d
        get dynamicLightX(): number
        set secondsOnFire($$0: number)
        get "displayName()"(): net.minecraft.network.chat.Component
        get lootTable(): ResourceLocation
        get ticksUsingItem(): number
        get arrowCount(): number
        get moveControl(): Internal.MoveControl
        set orderedToSit($$0: boolean)
        get collarColor(): Internal.DyeColor
        get defaultMovementSpeed(): number
        get peacefulCreature(): boolean
        set onGround($$0: boolean)
        get lastHurtByMobTimestamp(): number
        get vehicle(): Internal.Entity
        get effectiveAi(): boolean
        get stringUuid(): string
        set swimming($$0: boolean)
        get mainArm(): Internal.HumanoidArm
        get rotationVector(): Internal.Vec2
        get hurtDir(): number
        get sprinting(): boolean
        get motionY(): number
        get offhandItem(): Internal.ItemStack
        set luminance(luminance: number)
        set "variant(net.minecraft.world.entity.animal.CatVariant)"($$0: Internal.CatVariant_)
        set lootTable(arg0: ResourceLocation_)
        get lastHurtMob(): Internal.LivingEntity
        get lastDamageSource(): DamageSource
        get soundSource(): Internal.SoundSource
        set noActionTime($$0: number)
        set movementSpeedAddition(speed: number)
        get pose(): Internal.Pose
        get restrictCenter(): BlockPos
        get leftHanded(): boolean
        set z(z: number)
        get resourceLocation(): ResourceLocation
        get y(): number
        set currentModifyFoodPowers(powers: Internal.List_<any>)
        get blocking(): boolean
        get pushedByFluid(): boolean
        set originalFoodStack(original: Internal.ItemStack_)
        get armorCoverPercentage(): number
        get airSupply(): number
        get player(): boolean
        get animal(): boolean
        get motionDirection(): Internal.Direction
        get fabricBalmData(): Internal.CompoundTag
        get commandSenderWorld(): Internal.Level
        get totalMovementSpeed(): number
        get moving(): boolean
        get attributes(): Internal.AttributeMap
        set inSittingPose($$0: boolean)
        set inLoveTime($$0: number)
        get swimming(): boolean
        set sprinting($$0: boolean)
        get dynamicLightLevel(): Internal.Level
        set x(x: number)
        get portalWaitTime(): number
        get blockStateOn(): Internal.BlockState
        set ownerUUID($$0: Internal.UUID_)
        get fluidJumpThreshold(): number
        get cachedSouls(): number
        get "variant()"(): any
        set airSupply($$0: number)
        get onPos(): BlockPos
        get undead(): boolean
        set useItemRemaining(arg0: number)
        get targetSelector(): Internal.GoalSelector
        set registeredToWorld(navigation: Internal.PathNavigation_)
        get sleeping(): boolean
        get dismountPoses(): Internal.ImmutableList<Internal.Pose>
        get lastHurtMobTimestamp(): number
        set remainingFireTicks($$0: number)
        set relaxStateOne($$0: boolean)
        /**
         * @deprecated
        */
        get onPosLegacy(): BlockPos
        set pos($$0: Vec3d_)
        set canPickUpLoot($$0: boolean)
        get mainHandItem(): Internal.ItemStack
        set silent($$0: boolean)
        set leftHanded($$0: boolean)
        get activeEffects(): Internal.Collection<Internal.MobEffectInstance>
        get onPortalCooldown(): boolean
        set pitch($$0: number)
        get usingItem(): boolean
        get alwaysTicking(): boolean
        set invulnerable($$0: boolean)
        get dynamicLightPrevY(): number
        set glowing($$0: boolean)
        get alive(): boolean
        get bbHeight(): number
        set tame($$0: boolean)
        get tags(): Internal.Set<string>
        get lastAttacker(): Internal.LivingEntity
        get lastRollTicks(): number
        get goalSelector(): Internal.GoalSelector
        get percentFrozen(): number
        set portalCooldown($$0: number)
        set position(block: Internal.BlockContainerJS_)
        get leashed(): boolean
        set variant($$0: Internal.CatVariant_)
        get variant(): any
        set pose($$0: Internal.Pose_)
        get reachDistance(): number
        get entityType(): Internal.EntityType<any>
        get waterCreature(): boolean
        set lastHurtByPlayer($$0: Internal.Player_)
        get "server()"(): Internal.MinecraftServer
        get pushable(): boolean
        set YBodyRot($$0: number)
        set motionY(y: number)
        get dynamicLightEnabled(): boolean
        set chestArmorItem(item: Internal.ItemStack_)
        get passenger(): boolean
        get sensitiveToWater(): boolean
        get jumpControl(): Internal.JumpControl
        get feetArmorItem(): Internal.ItemStack
        get viewScale(): number
        get visualRotationYInDegrees(): number
        set speed($$0: number)
        get discrete(): boolean
        get level(): Internal.Level
        get combatTracker(): Internal.CombatTracker
        get noAi(): boolean
        get chestArmorItem(): Internal.ItemStack
        set variant(arg0: any)
        get fullyFrozen(): boolean
        set lying($$0: boolean)
        get inWall(): boolean
        get allSlots(): Internal.Iterable<Internal.ItemStack>
        get scale(): number
        get suppressingSlidingDownLadder(): boolean
        get blockZ(): number
        get silent(): boolean
        set useItem(arg0: Internal.ItemStack_)
        get pitch(): number
        get random(): Internal.RandomSource
        get passengersAndSelf(): Internal.Stream<any>
        get originalFoodStack(): Internal.ItemStack
        get age(): number
        get noActionTime(): number
        get visuallyCrawling(): boolean
        get aggressive(): boolean
        set yya($$0: number)
        set baby($$0: boolean)
        get lastHurtByMob(): Internal.LivingEntity
        get inWaterOrBubble(): boolean
        get portalCooldown(): number
        get item(): Internal.ItemStack
        get ignoringBlockTriggers(): boolean
        get steppingCarefully(): boolean
        get blockX(): number
        /**
         * @deprecated
        */
        get lightLevelDependentMagicValue(): number
        get fallFlying(): boolean
        get encodeId(): string
        get maxHeadXRot(): number
        get nbt(): Internal.CompoundTag
        set invisible($$0: boolean)
        set totalMovementSpeedMultiplier(speed: number)
        get dynamicLightY(): number
        set health($$0: number)
        get eyePosition(): Vec3d
        get eyeHeight(): number
        set discardFriction($$0: boolean)
        get yaw(): number
        get usedItemHand(): Internal.InteractionHand
        set defaultMovementSpeed(speed: number)
        get brain(): Internal.Brain<any>
        set customNameVisible($$0: boolean)
        get controllingPassenger(): Internal.LivingEntity
        get scriptType(): Internal.ScriptType
        get lying(): boolean
        get forward(): Vec3d
        set feetArmorItem(item: Internal.ItemStack_)
        get id(): number
        get recipientsForComponentSync(): Internal.Iterable<any>
        get eyeY(): number
        get boundingBox(): Internal.AABB
        get inWaterOrRain(): boolean
        get affectedByPotions(): boolean
        get addEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>
        get team(): Internal.Team
        set ticksFrozen($$0: number)
        get useItem(): Internal.ItemStack
        get myRidingOffset(): number
        get living(): boolean
        get x(): number
        get vehicle(): boolean
        set collarColor($$0: Internal.DyeColor_)
        set isInPowderSnow($$0: boolean)
        set customName($$0: net.minecraft.network.chat.Component_)
        get teamId(): string
        set stingerCount($$0: number)
        get maxHeadYRot(): number
        get customNameVisible(): boolean
        get pistonPushReaction(): Internal.PushReaction
        get lootTableSeed(): number
        get motionX(): number
        get entityData(): Internal.SynchedEntityData
        get potionEffects(): Internal.EntityPotionEffectsJS
        get lastHurtByPlayerTime(): number
        get onRails(): boolean
        get stingerCount(): number
        get fallSounds(): Internal.LivingEntity$Fallsounds
        get dimensionChangingDelay(): number
        get lastDynamicLuminance(): number
        set yaw($$0: number)
        get pickRadius(): number
        get pathFinding(): boolean
        get tame(): boolean
        get removed(): boolean
        get jumpBoostPower(): number
        set shiftKeyDown($$0: boolean)
        get passengers(): Internal.EntityArrayList
        get z(): number
        get server(): Internal.MinecraftServer
        get experienceReward(): number
        get firstPassenger(): Internal.Entity
        set lastHurtMob($$0: Internal.Entity_)
        set lastHurtByMob($$0: Internal.LivingEntity_)
        get leashingEntities(): Internal.Set<any>
        set fabricBalmData(tag: Internal.CompoundTag_)
        get lookAngle(): Vec3d
        get ambientSoundInterval(): number
        set arrowCount($$0: number)
        get motionZ(): number
        get persistenceRequired(): boolean
        get invisible(): boolean
        get bedOrientation(): Internal.Direction
        get profile(): Internal.GameProfile
        set inLove($$0: Internal.Player_)
        get deadOrDying(): boolean
        set headArmorItem(item: Internal.ItemStack_)
        set viewScale($$0: number)
        set levelCallback($$0: Internal.EntityInLevelCallback_)
        get lookControl(): Internal.LookControl
        get orderedToSit(): boolean
        get offHandItem(): Internal.ItemStack
        get outOfCamera(): boolean
        get crouching(): boolean
        set y(y: number)
        get feetBlockState(): Internal.BlockState
        get withinRestriction(): boolean
        get changeListener(): Internal.EntityInLevelCallback
        get sleepingPos(): Optional<BlockPos>
        get customName(): net.minecraft.network.chat.Component
        get class(): typeof any
        get visuallySwimming(): boolean
        get maxAirSupply(): number
        set maxHealth(hp: number)
        get facing(): Internal.Direction
        get boundingBoxForCulling(): Internal.AABB
        set age($$0: number)
        get target(): Internal.LivingEntity
        get inLove(): boolean
        get nameTagOffsetY(): number
        get invulnerable(): boolean
        get inLava(): boolean
        get inWater(): boolean
        get rootVehicle(): Internal.Entity
        get ownerUUID(): Internal.UUID
        get noGravity(): boolean
        get speed(): number
        get cachedFeetBlockState(): Internal.BlockState
        get uuid(): Internal.UUID
        set offHandItem(item: Internal.ItemStack_)
        set noAi($$0: boolean)
        get armorSlots(): Internal.Iterable<Internal.ItemStack>
        get headArmorItem(): Internal.ItemStack
        get currentModifyFoodPowers(): Internal.List<any>
        get bbWidth(): number
        get "name()"(): net.minecraft.network.chat.Component
        get ticksRequiredToFreeze(): number
        get maxSpawnClusterSize(): number
        get inSittingPose(): boolean
        get username(): string
        get inLoveTime(): number
        set "variant(java.lang.Object)"(arg0: any)
        get pickable(): boolean
        set YHeadRot($$0: number)
        set jumping($$0: boolean)
        get customData(): Internal.CompoundTag
        get pickResult(): Internal.ItemStack
        get "mainHandItem()"(): Internal.ItemStack
        get absorptionAmount(): number
        get randomY(): number
        get displayName(): net.minecraft.network.chat.Component
        get mobType(): Internal.MobType
        get dynamicLightPrevX(): number
        get passengersRidingOffset(): number
        get frame(): boolean
        set legsArmorItem(item: Internal.ItemStack_)
        set noGravity($$0: boolean)
        get useItemRemainingTicks(): number
        get indirectPassengers(): Internal.Iterable<any>
        get navigation(): Internal.PathNavigation
        get controlledByLocalInstance(): boolean
        get monster(): boolean
        get loveCause(): Internal.ServerPlayer
        get lastClimbablePos(): Optional<BlockPos>
        set lastDynamicLuminance(luminance: number)
        set id($$0: number)
        get horizontalFacing(): Internal.Direction
        get type(): string
        get activeEffectsMap(): Internal.Map<Internal.MobEffect, Internal.MobEffectInstance>
        set motionX(x: number)
        get handSlots(): Internal.Iterable<Internal.ItemStack>
        get teamColor(): number
        set nbt(nbt: Internal.CompoundTag_)
        get "variant()"(): Internal.CatVariant
        get recallPosition(): Internal.DimensionalPosition
        set dynamicLightEnabled(enabled: boolean)
        get restrictRadius(): number
        get registeredNavigation(): Internal.PathNavigation
        get forcedVisible(): boolean
        get invertedHealAndHarm(): boolean
        get freezing(): boolean
        set guaranteedDrop($$0: Internal.EquipmentSlot_)
        set sharedFlagOnFire($$0: boolean)
        static readonly TEMPT_SPEED_MOD: (0.6) & (number);
        static readonly SPRINT_SPEED_MOD: (1.33) & (number);
        static readonly WALK_SPEED_MOD: (0.8) & (number);
    }
    type Cat_ = Cat;
    class ShapelessKubeJSRecipe$SerializerKJS implements Internal.RecipeSerializer<Internal.ShapelessKubeJSRecipe> {
        constructor()
        getClass(): typeof any;
        "fromNetwork(net.minecraft.resources.ResourceLocation,net.minecraft.network.FriendlyByteBuf)"(arg0: ResourceLocation_, arg1: Internal.FriendlyByteBuf_): Internal.Recipe<any>;
        toString(): string;
        "toNetwork(net.minecraft.network.FriendlyByteBuf,net.minecraft.world.item.crafting.Recipe)"(arg0: Internal.FriendlyByteBuf_, arg1: Internal.Recipe_<any>): void;
        notifyAll(): void;
        toNetwork(arg0: Internal.FriendlyByteBuf_, arg1: Internal.Recipe_<any>): void;
        notify(): void;
        "fromJson(net.minecraft.resources.ResourceLocation,com.google.gson.JsonObject)"(arg0: ResourceLocation_, arg1: Internal.JsonObject_): Internal.Recipe<any>;
        wait(arg0: number, arg1: number): void;
        fromJson(id: ResourceLocation_, json: Internal.JsonObject_): Internal.ShapelessKubeJSRecipe;
        "toNetwork(net.minecraft.network.FriendlyByteBuf,dev.latvian.mods.kubejs.recipe.special.ShapelessKubeJSRecipe)"(buf: Internal.FriendlyByteBuf_, r: Internal.ShapelessKubeJSRecipe_): void;
        fromNetwork(id: ResourceLocation_, buf: Internal.FriendlyByteBuf_): Internal.ShapelessKubeJSRecipe;
        static register<S extends Internal.RecipeSerializer<T>, T extends Internal.Recipe<any>>($$0: string, $$1: S): S;
        hashCode(): number;
        fromJson(arg0: ResourceLocation_, arg1: Internal.JsonObject_): Internal.Recipe<any>;
        "fromJson(net.minecraft.resources.ResourceLocation,com.google.gson.JsonObject)"(id: ResourceLocation_, json: Internal.JsonObject_): Internal.ShapelessKubeJSRecipe;
        "fromNetwork(net.minecraft.resources.ResourceLocation,net.minecraft.network.FriendlyByteBuf)"(id: ResourceLocation_, buf: Internal.FriendlyByteBuf_): Internal.ShapelessKubeJSRecipe;
        wait(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        toNetwork(buf: Internal.FriendlyByteBuf_, r: Internal.ShapelessKubeJSRecipe_): void;
        fromNetwork(arg0: ResourceLocation_, arg1: Internal.FriendlyByteBuf_): Internal.Recipe<any>;
        get class(): typeof any
    }
    type ShapelessKubeJSRecipe$SerializerKJS_ = ShapelessKubeJSRecipe$SerializerKJS;
    interface BlockBuilderProvider {
        getBlockBuilder(): Internal.BlockBuilder;
        get blockBuilder(): Internal.BlockBuilder
    }
    type BlockBuilderProvider_ = BlockBuilderProvider;
    interface TooltipComponent {
    }
    type TooltipComponent_ = TooltipComponent;
    class FullChunkStatus extends Internal.Enum<Internal.FullChunkStatus> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        toString(): string;
        static valueOf($$0: string): Internal.FullChunkStatus;
        notifyAll(): void;
        isOrAfter($$0: Internal.FullChunkStatus_): boolean;
        notify(): void;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.FullChunkStatus>>;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        compareTo(arg0: Internal.FullChunkStatus_): number;
        static values(): Internal.FullChunkStatus[];
        name(): string;
        getDeclaringClass(): typeof Internal.FullChunkStatus;
        hashCode(): number;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        "compareTo(net.minecraft.server.level.FullChunkStatus)"(arg0: Internal.FullChunkStatus_): number;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        get class(): typeof any
        get declaringClass(): typeof Internal.FullChunkStatus
        static readonly BLOCK_TICKING: (Internal.FullChunkStatus) & (Internal.FullChunkStatus);
        static readonly INACCESSIBLE: (Internal.FullChunkStatus) & (Internal.FullChunkStatus);
        static readonly ENTITY_TICKING: (Internal.FullChunkStatus) & (Internal.FullChunkStatus);
        static readonly FULL: (Internal.FullChunkStatus) & (Internal.FullChunkStatus);
    }
    type FullChunkStatus_ = "inaccessible" | "entity_ticking" | "full" | FullChunkStatus | "block_ticking";
    interface LightTextureAccessor {
        abstract getFlicker(): number;
        abstract isDirty(): boolean;
        get flicker(): number
        get dirty(): boolean
    }
    type LightTextureAccessor_ = LightTextureAccessor;
    class EnderpearlItem extends Internal.Item {
        constructor($$0: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type EnderpearlItem_ = EnderpearlItem;
    class ExplosionDamageCalculator {
        constructor()
        getClass(): typeof any;
        shouldBlockExplode($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: number): boolean;
        hashCode(): number;
        handler$zbm000$porting_lib_base$port_lib$explosionBlock(explosion: Internal.Explosion_, reader: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, fluid: Internal.FluidState_, cir: Internal.CallbackInfoReturnable_<any>): void;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        getBlockExplosionResistance($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.FluidState_): Optional<number>;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
    }
    type ExplosionDamageCalculator_ = ExplosionDamageCalculator;
    class BCLFeatureBuilder$AsPillar extends Internal.BCLFeatureBuilder<org.betterx.bclib.api.v3.levelgen.features.features.PillarFeature, Internal.PillarFeatureConfig> {
        createConfiguration(): Internal.PillarFeatureConfig;
        static "start(net.minecraft.resources.ResourceLocation,net.minecraft.world.level.levelgen.feature.stateproviders.BlockStateProvider)"(featureID: ResourceLocation_, provider: Internal.BlockStateProvider_): Internal.BCLFeatureBuilder$ForSimpleBlock;
        "blockState(net.minecraft.world.level.levelgen.feature.stateproviders.BlockStateProvider)"(v: Internal.BlockStateProvider_): this;
        static startSequence(featureID: ResourceLocation_): Internal.BCLFeatureBuilder$AsSequence;
        static "start(net.minecraft.resources.ResourceLocation,net.minecraft.world.level.block.state.BlockState)"(featureID: ResourceLocation_, state: Internal.BlockState_): Internal.BCLFeatureBuilder$ForSimpleBlock;
        static startRandomPatch(featureID: ResourceLocation_, featureToPlace: Internal.Holder_<Internal.PlacedFeature>): Internal.BCLFeatureBuilder$RandomPatch;
        notify(): void;
        maxHeight(v: number): this;
        static startWithTemplates(featureID: ResourceLocation_): Internal.BCLFeatureBuilder$WithTemplates;
        blockState(v: Internal.Block_): this;
        minHeight(v: Internal.IntProvider_): this;
        allowedPlacement(predicate: net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate_): this;
        static startRandomSelect(featureID: ResourceLocation_): Internal.BCLFeatureBuilder$AsRandomSelect;
        static start(featureID: ResourceLocation_, state: Internal.BlockState_): Internal.BCLFeatureBuilder$ForSimpleBlock;
        static startWeightedRandomPatch(featureID: ResourceLocation_): Internal.BCLFeatureBuilder$WeightedBlockPatch;
        buildAndRegister(bootstrapCtx: Internal.BootstapContext_<Internal.ConfiguredFeature<any, any>>): Internal.BCLConfigureFeature<org.betterx.bclib.api.v3.levelgen.features.features.PillarFeature, Internal.PillarFeatureConfig>;
        static registerUnbound(bootstapContext: Internal.BootstapContext_<Internal.ConfiguredFeature<any, any>>): void;
        static startWeighted(featureID: ResourceLocation_): Internal.BCLFeatureBuilder$WeightedBlock;
        buildInline(): Internal.BCLConfigureFeature<org.betterx.bclib.api.v3.levelgen.features.features.PillarFeature, Internal.PillarFeatureConfig>;
        inlinePlace(placer: Internal.BCLInlinePlacedBuilder_<org.betterx.bclib.api.v3.levelgen.features.features.PillarFeature, Internal.PillarFeatureConfig>): Internal.Holder<Internal.PlacedFeature>;
        static register<F extends Feature<FC>, FC extends Internal.FeatureConfiguration>(ctx: Internal.BootstapContext_<Internal.ConfiguredFeature<any, any>>, id: ResourceLocation_, cFeature: Internal.ConfiguredFeature_<FC, F>): Internal.Holder<Internal.ConfiguredFeature<FC, F>>;
        static start<F extends Feature<FC>, FC extends Internal.FeatureConfiguration>(featureID: ResourceLocation_, feature: F): Internal.BCLFeatureBuilder$WithConfiguration<F, FC>;
        wait(): void;
        static startBonemealPatch(featureID: ResourceLocation_): Internal.BCLFeatureBuilder$WeightedBlockPatch;
        static startOre(featureID: ResourceLocation_): Internal.BCLFeatureBuilder$AsOre;
        getClass(): typeof any;
        static start(featureID: ResourceLocation_, provider: Internal.BlockStateProvider_): Internal.BCLFeatureBuilder$ForSimpleBlock;
        inlinePlace(): Internal.BCLInlinePlacedBuilder<org.betterx.bclib.api.v3.levelgen.features.features.PillarFeature, Internal.PillarFeatureConfig>;
        "minHeight(net.minecraft.util.valueproviders.IntProvider)"(v: Internal.IntProvider_): this;
        wait(arg0: number, arg1: number): void;
        static start(featureID: ResourceLocation_, block: Internal.Block_): Internal.BCLFeatureBuilder$ForSimpleBlock;
        static startColumn(featureID: ResourceLocation_): Internal.BCLFeatureBuilder$AsBlockColumn<Internal.BlockColumnFeature>;
        static startRandomSelect(featureID: ResourceLocation_, placementModFunction: Internal.BCLFeatureBuilder$AsMultiPlaceRandomSelect$Placer_): Internal.BCLFeatureBuilder$AsMultiPlaceRandomSelect;
        build(): Internal.BCLConfigureFeature$Unregistered<org.betterx.bclib.api.v3.levelgen.features.features.PillarFeature, Internal.PillarFeatureConfig>;
        static startBonemealNetherVegetation(featureID: ResourceLocation_): Internal.BCLFeatureBuilder$NetherForrestVegetation;
        maxHeight(v: Internal.IntProvider_): this;
        static startFacing(featureID: ResourceLocation_): Internal.BCLFeatureBuilder$FacingBlock;
        static "start(net.minecraft.resources.ResourceLocation,net.minecraft.world.level.levelgen.feature.Feature)"<F extends Feature<FC>, FC extends Internal.FeatureConfiguration>(featureID: ResourceLocation_, feature: F): Internal.BCLFeatureBuilder$WithConfiguration<F, FC>;
        toString(): string;
        "maxHeight(net.minecraft.util.valueproviders.IntProvider)"(v: Internal.IntProvider_): this;
        notifyAll(): void;
        static startPillar(featureID: ResourceLocation_, transformer: Internal.PillarFeatureConfig$KnownTransformers_): Internal.BCLFeatureBuilder$AsPillar;
        blockState(v: Internal.BlockState_): this;
        blockState(v: Internal.BlockStateProvider_): this;
        direction(v: Internal.Direction_): this;
        static startNetherVegetation(featureID: ResourceLocation_): Internal.BCLFeatureBuilder$NetherForrestVegetation;
        hashCode(): number;
        wait(arg0: number): void;
        "minHeight(int)"(v: number): this;
        "maxHeight(int)"(v: number): this;
        "blockState(net.minecraft.world.level.block.state.BlockState)"(v: Internal.BlockState_): this;
        static "start(net.minecraft.resources.ResourceLocation,net.minecraft.world.level.block.Block)"(featureID: ResourceLocation_, block: Internal.Block_): Internal.BCLFeatureBuilder$ForSimpleBlock;
        equals(arg0: any): boolean;
        minHeight(v: number): this;
        "blockState(net.minecraft.world.level.block.Block)"(v: Internal.Block_): this;
        get class(): typeof any
    }
    type BCLFeatureBuilder$AsPillar_ = BCLFeatureBuilder$AsPillar;
    class WeighedSoundEvents implements Internal.Weighted<Internal.Sound> {
        constructor($$0: ResourceLocation_, $$1: string)
        getClass(): typeof any;
        toString(): string;
        getSound(arg0: Internal.RandomSource_): any;
        "getSound(net.minecraft.util.RandomSource)"(arg0: Internal.RandomSource_): any;
        notifyAll(): void;
        getSound($$0: Internal.RandomSource_): Internal.Sound;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getSubtitle(): net.minecraft.network.chat.Component;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        addSound($$0: Internal.Weighted_<Internal.Sound>): void;
        getWeight(): number;
        equals(arg0: any): boolean;
        preloadIfRequired($$0: Internal.SoundEngine_): void;
        "getSound(net.minecraft.util.RandomSource)"($$0: Internal.RandomSource_): Internal.Sound;
        get class(): typeof any
        get subtitle(): net.minecraft.network.chat.Component
        get weight(): number
    }
    type WeighedSoundEvents_ = WeighedSoundEvents;
    interface AnnotatedType extends Internal.AnnotatedElement {
        getAnnotationsByType<T extends Internal.Annotation>(arg0: T): T[];
        getDeclaredAnnotation<T extends Internal.Annotation>(arg0: T): T;
        getAnnotatedOwnerType(): this;
        getDeclaredAnnotationsByType<T extends Internal.Annotation>(arg0: T): T[];
        abstract getAnnotation<T extends Internal.Annotation>(arg0: T): T;
        abstract getAnnotations(): Internal.Annotation[];
        abstract getDeclaredAnnotations(): Internal.Annotation[];
        abstract getType(): Internal.Type;
        isAnnotationPresent(arg0: typeof Internal.Annotation): boolean;
        get annotatedOwnerType(): Internal.AnnotatedType
        get annotations(): Internal.Annotation[]
        get declaredAnnotations(): Internal.Annotation[]
        get type(): Internal.Type
    }
    type AnnotatedType_ = AnnotatedType;
    class SwampOgreFeature extends Internal.AbstractSwampFeature<Internal.ResourceLocationFeatureConfiguration> {
        constructor()
        getClass(): typeof any;
        place(context: Internal.FeaturePlaceContext_<Internal.ResourceLocationFeatureConfiguration>): boolean;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        place($$0: Internal.ResourceLocationFeatureConfiguration_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.ResourceLocationFeatureConfiguration, Feature<Internal.ResourceLocationFeatureConfiguration>>>;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        get class(): typeof any
    }
    type SwampOgreFeature_ = SwampOgreFeature;
    class StainedGlassBlock extends Internal.AbstractGlassBlock implements Internal.BeaconBeamBlock {
        constructor($$0: Internal.DyeColor_, $$1: Internal.BlockBehaviour$Properties_)
        /**
         * @deprecated
        */
        getOcclusionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        /**
         * @deprecated
        */
        getSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        axiom$customPickBlockStack(): Internal.ItemStack;
        getSoundType($$0: Internal.BlockState_): SoundType;
        getVisualShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        handler$efo000$collective$Block_playerDestroy(level: Internal.Level_, player: Internal.Player_, blockPos: BlockPos_, blockState: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number, $$5: number): void;
        /**
         * @deprecated
        */
        randomTick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: Internal.BlockEntity_): void;
        static canSupportRigidBlock($$0: Internal.BlockGetter_, $$1: BlockPos_): boolean;
        static popResource($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.ItemStack_): void;
        setRandomTickCallback(callback: Internal.Consumer_<any>): void;
        getDescriptionId(): string;
        stepOn($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Entity_): void;
        fallOn($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: BlockPos_, $$3: Internal.Entity_, $$4: number): void;
        getColor(): Internal.DyeColor;
        getSettings(): Internal.BlockBehaviour$Properties;
        getExplosionResistance(): number;
        asItem(): Internal.Item;
        /**
         * @deprecated
        */
        triggerEvent($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: number, $$4: number): boolean;
        getTypeData(): Internal.CompoundTag;
        setFriction(arg0: number): void;
        /**
         * @deprecated
        */
        getRenderShape($$0: Internal.BlockState_): Internal.RenderShape;
        canCull(): boolean;
        customShapeUpdate(blockState: Internal.CustomBlockState_, levelReader: Internal.LevelReader_, blockPos: BlockPos_): Internal.CustomBlockState;
        getJumpFactor(): number;
        getSpeedFactor(): number;
        static canSupportCenter($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.Direction_): boolean;
        skipRendering($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getLightBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        /**
         * @deprecated
        */
        shouldAttemptToCull(state: Internal.BlockState_): boolean;
        playerDestroy($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.BlockEntity_, $$5: Internal.ItemStack_): void;
        isPossibleToRespawnInThis($$0: Internal.BlockState_): boolean;
        getCustomStateForPlacement(blockPlaceContext: Internal.BlockPlaceContext_): Internal.CustomBlockState;
        /**
         * @deprecated
        */
        getDirectSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        getProperties(): Internal.BlockBehaviour$Properties;
        playerWillDestroy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Player_): void;
        getClass(): typeof any;
        getMaxVerticalOffset(): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.item.context.BlockPlaceContext)"($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        useShapeForLightOcclusion($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        getDrops($$0: Internal.BlockState_, $$1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getStateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>;
        customShouldDrawFace(view: Internal.BlockGetter_, thisState: Internal.BlockState_, sideState: Internal.BlockState_, thisPos: BlockPos_, sidePos: BlockPos_, side: Internal.Direction_): Optional<any>;
        /**
         * @deprecated
        */
        entityInside($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Entity_): void;
        setBlockBuilder(b: Internal.BlockBuilder_): void;
        handler$ldb000$puzzleslib$playerDestroy$0(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        setRequiresTool(v: boolean): void;
        setSpeedFactor(arg0: number): void;
        axiom$getPossibleCustomStates(): Internal.List<any>;
        setExplosionResistance(arg0: number): void;
        toString(): string;
        port_lib$popExperience(arg0: Internal.ServerLevel_, arg1: BlockPos_, arg2: number): void;
        notifyAll(): void;
        getToolModifiedState(state: Internal.BlockState_, world: Internal.Level_, pos: BlockPos_, player: Internal.Player_, stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): Internal.BlockState;
        getId(): string;
        getLootTable(): ResourceLocation;
        puzzleslib$setItem(arg0: Internal.Item_): void;
        axiom$translationKey(): string;
        /**
         * @deprecated
        */
        getInteractionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        propagatesSkylightDown($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        setPlacedBy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.LivingEntity_, $$4: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        onPlace($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Block>;
        static popResourceFromFace($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.ItemStack_): void;
        getFriction(): number;
        handlePrecipitation($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Biome$Precipitation_): void;
        /**
         * @deprecated
        */
        hasAnalogOutputSignal($$0: Internal.BlockState_): boolean;
        wait(arg0: number): void;
        /**
         * @deprecated
        */
        getFluidState($$0: Internal.BlockState_): Internal.FluidState;
        handler$koh000$porting_lib_entity$getDestroySpeed(blockState: Internal.BlockState_, player: Internal.Player_, blockGetter: Internal.BlockGetter_, pos: BlockPos_, cir: Internal.CallbackInfoReturnable_<any>): void;
        /**
         * @deprecated
        */
        getAnalogOutputSignal($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): number;
        handler$efo000$collective$Block_setPlacedBy(level: Internal.Level_, blockPos: BlockPos_, blockState: Internal.BlockState_, livingEntity: Internal.LivingEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        tick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        supportsExternalFaceHiding(state: Internal.BlockState_): boolean;
        handler$ldb000$puzzleslib$playerDestroy$1(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        notify(): void;
        axiom$asItemStack(): Internal.ItemStack;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        neighborChanged($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Block_, $$4: BlockPos_, $$5: boolean): void;
        handler$zhd000$additionalentityattributes$additionalEntityAttributes$saveBreakingPlayer(world: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, stack: Internal.ItemStack_, callbackInfo: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        getBlockSupportShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        canSustainPlant(state: Internal.BlockState_, world: Internal.BlockGetter_, pos: BlockPos_, facing: Internal.Direction_, plantable: Internal.IPlantable_): boolean;
        /**
         * @deprecated
        */
        isCollisionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static isFaceFull($$0: Internal.VoxelShape_, $$1: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getMenuProvider($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): Internal.MenuProvider;
        static byItem($$0: Internal.Item_): Internal.Block;
        static updateFromNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        updateIndirectNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: number, $$4: number): void;
        destroy($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): void;
        handler$fdc000$everycomp$addSimpleFastECdrops(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, cir: Internal.CallbackInfoReturnable_<any>, resId: ResourceLocation_, lootParams: Internal.LootParams_, serverLevel: Internal.ServerLevel_, lootTable: Internal.LootTable_): void;
        getToolModifiedState(state: Internal.BlockState_, context: Internal.UseOnContext_, toolAction: Internal.ToolAction_, simulate: boolean): Internal.BlockState;
        /**
         * @deprecated
        */
        use($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_, $$4: Internal.InteractionHand_, $$5: Internal.BlockHitResult_): Internal.InteractionResult;
        setLightEmission(v: number): void;
        doNormalInteractions(): boolean;
        setJumpFactor(arg0: number): void;
        /**
         * @deprecated
        */
        canSurvive($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        getShadeBrightness($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): void;
        getAppearance(state: Internal.BlockState_, renderView: Internal.BlockAndTintGetter_, pos: BlockPos_, side: Internal.Direction_, sourceState: Internal.BlockState_, sourcePos: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        getCollisionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        setDestroySpeed(v: number): void;
        usesCustomShouldDrawFace(state: Internal.BlockState_): boolean;
        defaultBlockState(): Internal.BlockState;
        cantCullAgainst(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        getStateForPlacement($$0: Internal.BlockPlaceContext_): Internal.BlockState;
        arch$holder(): Internal.Holder<Internal.Block>;
        wait(): void;
        getCloneItemStack($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        hasDynamicShape(): boolean;
        getMaxHorizontalOffset(): number;
        /**
         * @deprecated
        */
        getDestroyProgress($$0: Internal.BlockState_, $$1: Internal.Player_, $$2: Internal.BlockGetter_, $$3: BlockPos_): number;
        /**
         * @deprecated
        */
        getSeed($$0: Internal.BlockState_, $$1: BlockPos_): number;
        defaultDestroyTime(): number;
        dropFromExplosion($$0: Internal.Explosion_): boolean;
        /**
         * @deprecated
        */
        updateShape($$0: Internal.BlockState_, $$1: Internal.Direction_, $$2: Internal.BlockState_, $$3: Internal.LevelAccessor_, $$4: BlockPos_, $$5: BlockPos_): Internal.BlockState;
        isRandomlyTicking($$0: Internal.BlockState_): boolean;
        static isShapeFullBlock(shape: Internal.VoxelShape_): boolean;
        withPropertiesOf($$0: Internal.BlockState_): Internal.BlockState;
        static isExceptionForConnection($$0: Internal.BlockState_): boolean;
        setIsRandomlyTicking(arg0: boolean): void;
        hidesNeighborFace(level: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, neighborState: Internal.BlockState_, dir: Internal.Direction_): boolean;
        onTreeGrow(state: Internal.BlockState_, level: Internal.LevelReader_, placeFunction: Internal.BiConsumer_<BlockPos, Internal.BlockState>, randomSource: Internal.RandomSource_, pos: BlockPos_, config: Internal.TreeConfiguration_): boolean;
        /**
         * @deprecated
        */
        rotate($$0: Internal.BlockState_, $$1: Internal.Rotation_): Internal.BlockState;
        defaultMapColor(): Internal.MapColor;
        getStateAtViewpoint(state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_, viewpoint: Vec3d_): Internal.BlockState;
        wait(arg0: number, arg1: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.BlockGetter_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        setNameKey(arg0: string): void;
        static box($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): Internal.VoxelShape;
        /**
         * @deprecated
        */
        mirror($$0: Internal.BlockState_, $$1: Internal.Mirror_): Internal.BlockState;
        wasExploded($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Explosion_): void;
        getName(): Internal.MutableComponent;
        updateEntityAfterFallOn($$0: Internal.BlockGetter_, $$1: Internal.Entity_): void;
        animateTick($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        axiom$getResourceLocation(): ResourceLocation;
        arch$registryName(): ResourceLocation;
        axiom$getProperties(): Internal.Collection<any>;
        getBlockBuilder(): Internal.BlockBuilder;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        isSignalSource($$0: Internal.BlockState_): boolean;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number): void;
        /**
         * @deprecated
        */
        attack($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): void;
        /**
         * @deprecated
        */
        getShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        shouldAttemptToCull(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        onProjectileHit($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockHitResult_, $$3: Internal.Projectile_): void;
        static stateById($$0: number): Internal.BlockState;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): Internal.List<Internal.ItemStack>;
        requiredFeatures(): Internal.FeatureFlagSet;
        hashCode(): number;
        axiom$defaultCustomState(): Internal.CustomBlockState;
        setCanCull(canCull: boolean): void;
        /**
         * @deprecated
        */
        isOcclusionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static getId($$0: Internal.BlockState_): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.material.Fluid)"($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        static pushEntitiesUp($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        isPathfindable($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.PathComputationType_): boolean;
        setSoundType(arg0: SoundType_): void;
        handler$cef000$betterend$be_getDroppedStacks(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, info: Internal.CallbackInfoReturnable_<any>): void;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_): Internal.List<Internal.ItemStack>;
        /**
         * @deprecated
        */
        onRemove($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        /**
         * @deprecated
        */
        cantCullAgainst(state: Internal.BlockState_): boolean;
        setHasCollision(arg0: boolean): void;
        static shouldRenderFace($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_, $$4: BlockPos_): boolean;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        spawnAfterBreak($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.ItemStack_, $$4: boolean): void;
        set randomTickCallback(callback: Internal.Consumer_<any>)
        get descriptionId(): string
        get color(): Internal.DyeColor
        get settings(): Internal.BlockBehaviour$Properties
        get explosionResistance(): number
        get typeData(): Internal.CompoundTag
        set friction(arg0: number)
        get jumpFactor(): number
        get speedFactor(): number
        get properties(): Internal.BlockBehaviour$Properties
        get class(): typeof any
        get maxVerticalOffset(): number
        get stateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>
        set blockBuilder(b: Internal.BlockBuilder_)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        set speedFactor(arg0: number)
        set explosionResistance(arg0: number)
        get id(): string
        get lootTable(): ResourceLocation
        get friction(): number
        set lightEmission(v: number)
        set jumpFactor(arg0: number)
        set destroySpeed(v: number)
        get maxHorizontalOffset(): number
        set isRandomlyTicking(arg0: boolean)
        set nameKey(arg0: string)
        get name(): Internal.MutableComponent
        get blockBuilder(): Internal.BlockBuilder
        get idLocation(): ResourceLocation
        get mod(): string
        set canCull(canCull: boolean)
        set soundType(arg0: SoundType_)
        set hasCollision(arg0: boolean)
    }
    type StainedGlassBlock_ = StainedGlassBlock;
    abstract class AbstractObject2ObjectFunction <K, V> implements Internal.Object2ObjectFunction<K, V>, Internal.Serializable {
        getClass(): typeof any;
        andThen<V>(arg0: Internal.Function_<V, V>): Internal.Function<K, V>;
        getOrDefault(arg0: any, arg1: V): V;
        composeShort(arg0: Internal.Short2ObjectFunction_<K>): Internal.Short2ObjectFunction<V>;
        composeByte(arg0: Internal.Byte2ObjectFunction_<K>): Internal.Byte2ObjectFunction<V>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        containsKey(arg0: any): boolean;
        put(arg0: K, arg1: V): V;
        andThenFloat(arg0: Internal.Object2FloatFunction_<V>): Internal.Object2FloatFunction<K>;
        abstract get(arg0: any): V;
        remove(arg0: any): V;
        composeFloat(arg0: Internal.Float2ObjectFunction_<K>): Internal.Float2ObjectFunction<V>;
        andThenLong(arg0: Internal.Object2LongFunction_<V>): Internal.Object2LongFunction<K>;
        apply(arg0: K): V;
        andThenReference<T>(arg0: Internal.Object2ReferenceFunction_<V, T>): Internal.Object2ReferenceFunction<K, T>;
        composeChar(arg0: Internal.Char2ObjectFunction_<K>): Internal.Char2ObjectFunction<V>;
        toString(): string;
        andThenInt(arg0: Internal.Object2IntFunction_<V>): Internal.Object2IntFunction<K>;
        andThenShort(arg0: Internal.Object2ShortFunction_<V>): Internal.Object2ShortFunction<K>;
        andThenDouble(arg0: Internal.Object2DoubleFunction_<V>): Internal.Object2DoubleFunction<K>;
        composeInt(arg0: Internal.Int2ObjectFunction_<K>): Internal.Int2ObjectFunction<V>;
        notifyAll(): void;
        composeObject<T>(arg0: Internal.Object2ObjectFunction_<T, K>): Internal.Object2ObjectFunction<T, V>;
        composeDouble(arg0: Internal.Double2ObjectFunction_<K>): Internal.Double2ObjectFunction<V>;
        andThenByte(arg0: Internal.Object2ByteFunction_<V>): Internal.Object2ByteFunction<K>;
        composeReference<T>(arg0: Internal.Reference2ObjectFunction_<T, K>): Internal.Reference2ObjectFunction<T, V>;
        composeLong(arg0: Internal.Long2ObjectFunction_<K>): Internal.Long2ObjectFunction<V>;
        hashCode(): number;
        size(): number;
        andThenChar(arg0: Internal.Object2CharFunction_<V>): Internal.Object2CharFunction<K>;
        compose<V>(arg0: Internal.Function_<V, K>): Internal.Function<V, V>;
        wait(): void;
        clear(): void;
        andThenObject<T>(arg0: Internal.Object2ObjectFunction_<V, T>): Internal.Object2ObjectFunction<K, T>;
        wait(arg0: number): void;
        defaultReturnValue(): V;
        equals(arg0: any): boolean;
        static identity<T>(): Internal.Function<T, T>;
        defaultReturnValue(arg0: V): void;
        get class(): typeof any
    }
    type AbstractObject2ObjectFunction_<K, V> = AbstractObject2ObjectFunction<K, V>;
    class PageAttributes$OriginType extends Internal.AttributeValue {
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        static readonly PRINTABLE: (Internal.PageAttributes$OriginType) & (Internal.PageAttributes$OriginType);
        static readonly PHYSICAL: (Internal.PageAttributes$OriginType) & (Internal.PageAttributes$OriginType);
    }
    type PageAttributes$OriginType_ = PageAttributes$OriginType;
    class WrapFactory {
        constructor()
        isJavaPrimitiveWrap(): boolean;
        getClass(): typeof any;
        toString(): string;
        wrap(cx: Internal.Context_, scope: Internal.Scriptable_, obj: any, staticType: typeof any): any;
        notifyAll(): void;
        wrapJavaClass(cx: Internal.Context_, scope: Internal.Scriptable_, javaClass: typeof any): Internal.Scriptable;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        wrapNewObject(scope: Internal.Scriptable_, obj: any, cx: Internal.Context_): Internal.Scriptable;
        hashCode(): number;
        setJavaPrimitiveWrap(value: boolean): void;
        wait(): void;
        wait(arg0: number): void;
        wrapAsJavaObject(cx: Internal.Context_, scope: Internal.Scriptable_, javaObject: any, staticType: typeof any): Internal.Scriptable;
        equals(arg0: any): boolean;
        get javaPrimitiveWrap(): boolean
        get class(): typeof any
        set javaPrimitiveWrap(value: boolean)
    }
    type WrapFactory_ = WrapFactory;
    /**
     * @deprecated
     * This class is marked to be removed in future!
    */
    interface MenuInfoProvider <T extends Internal.AbstractContainerMenu, D extends me.shedaniel.rei.api.common.display.Display> {
        abstract provideClient(arg0: D, arg1: Internal.MenuSerializationContext_<T, any, D>, arg2: T): Optional<Internal.MenuInfo<T, D>>;
        abstract provide(arg0: Internal.CategoryIdentifier_<D>, arg1: T, arg2: Internal.MenuSerializationContext_<T, any, D>, arg3: Internal.CompoundTag_): Optional<Internal.MenuInfo<T, D>>;
    }
    type MenuInfoProvider_<T extends Internal.AbstractContainerMenu, D extends me.shedaniel.rei.api.common.display.Display> = MenuInfoProvider<T, D>;
    class FluteItem extends Internal.SongInstrumentItem implements Internal.IThirdPersonAnimationProvider, Internal.IThirdPersonSpecialItemRenderer, Internal.IFirstPersonAnimationProvider {
        constructor(properties: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        static "attachToItem(net.minecraft.world.item.Item,net.mehvahdjukaar.moonlight.api.item.IThirdPersonAnimationProvider)"(target: Internal.Item_, object: Internal.IThirdPersonAnimationProvider_): void;
        static interactWithPet(stack: Internal.ItemStack_, player: Internal.Player_, target: Internal.Entity_, hand: Internal.InteractionHand_): boolean;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, worldIn: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, flagIn: Internal.TooltipFlag_): void;
        onUseTick(level: Internal.Level_, entity: Internal.LivingEntity_, stack: Internal.ItemStack_, remainingUseDuration: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        poseLeftArm<T extends Internal.LivingEntity>(stack: Internal.ItemStack_, model: Internal.HumanoidModel_<T>, entity: T, mainHand: Internal.HumanoidArm_): boolean;
        getUseAnimation(pStack: Internal.ItemStack_): Internal.UseAnim;
        getDescriptionId(): string;
        isValidRepairItem(pStack: Internal.ItemStack_, pRepairCandidate: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        static attachToItem(target: Internal.Item_, object: Internal.IThirdPersonAnimationProvider_): void;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        getVolume(): number;
        static attachToItem(target: Internal.Item_, object: Internal.IThirdPersonSpecialItemRenderer_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        animateItemFirstPerson(entity: Internal.Player_, stack: Internal.ItemStack_, hand: Internal.InteractionHand_, arm: Internal.HumanoidArm_, poseStack: Internal.PoseStack_, partialTicks: number, pitch: number, attackAnim: number, handHeight: number): void;
        renderThirdPersonItem<T extends Internal.Player, M extends Internal.EntityModel<T> & Internal.ArmedModel & Internal.HeadedModel>(parentModel: M, entity: Internal.LivingEntity_, stack: Internal.ItemStack_, humanoidArm: Internal.HumanoidArm_, poseStack: Internal.PoseStack_, bufferSource: Internal.MultiBufferSource_, light: number): void;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        isTwoHanded(): boolean;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        static "attachToItem(net.minecraft.world.item.Item,net.mehvahdjukaar.moonlight.api.item.IThirdPersonSpecialItemRenderer)"(target: Internal.Item_, object: Internal.IThirdPersonSpecialItemRenderer_): void;
        getSound(): Internal.SoundEvent;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getPitch(note: number): number;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(level: Internal.Level_, player: Internal.Player_, handIn: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        animateItemFirstPerson(entity: Internal.LivingEntity_, stack: Internal.ItemStack_, hand: Internal.InteractionHand_, matrixStack: Internal.PoseStack_, partialTicks: number, pitch: number, attackAnim: number, handHeight: number): void;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil(pStack: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        poseRightArm<T extends Internal.LivingEntity>(stack: Internal.ItemStack_, model: Internal.HumanoidModel_<T>, entity: T, mainHand: Internal.HumanoidArm_): boolean;
        static "attachToItem(net.minecraft.world.item.Item,net.mehvahdjukaar.moonlight.api.item.IFirstPersonAnimationProvider)"(target: Internal.Item_, object: Internal.IFirstPersonAnimationProvider_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        spawnNoteParticle(level: Internal.Level_, entity: Internal.LivingEntity_, note: number): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing(pStack: Internal.ItemStack_, pLevel: Internal.Level_, entity: Internal.LivingEntity_, pTimeCharged: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration(stack: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        static attachToItem(target: Internal.Item_, object: Internal.IFirstPersonAnimationProvider_): void;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        static get(target: Internal.Item_): Internal.IThirdPersonAnimationProvider;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        static getMaxHeadXRot(xRot: number): number;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        get volume(): number
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get twoHanded(): boolean
        get attackDamageModifierId(): Internal.UUID
        get sound(): Internal.SoundEvent
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type FluteItem_ = FluteItem;
    class GingerbreadItem extends Internal.Item {
        constructor()
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(itemstack: Internal.ItemStack_, world: Internal.Level_, list: Internal.List_<net.minecraft.network.chat.Component>, flag: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration(itemstack: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type GingerbreadItem_ = GingerbreadItem;
    abstract class RectangularShape implements Internal.Shape, Internal.Cloneable {
        clone(): any;
        getClass(): typeof any;
        abstract contains(arg0: number, arg1: number): boolean;
        getBounds(): Internal.Rectangle;
        getMaxX(): number;
        getMaxY(): number;
        intersects(arg0: Internal.Rectangle2D_): boolean;
        getCenterY(): number;
        abstract isEmpty(): boolean;
        getCenterX(): number;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        setFrameFromCenter(arg0: number, arg1: number, arg2: number, arg3: number): void;
        abstract contains(arg0: number, arg1: number, arg2: number, arg3: number): boolean;
        getPathIterator(arg0: Internal.AffineTransform_, arg1: number): Internal.PathIterator;
        abstract getWidth(): number;
        abstract intersects(arg0: number, arg1: number, arg2: number, arg3: number): boolean;
        setFrame(arg0: Internal.Rectangle2D_): void;
        abstract getBounds2D(): Internal.Rectangle2D;
        contains(arg0: Internal.Rectangle2D_): boolean;
        getMinX(): number;
        abstract getHeight(): number;
        getMinY(): number;
        toString(): string;
        setFrameFromCenter(arg0: Internal.Point2D_, arg1: Internal.Point2D_): void;
        "contains(java.awt.geom.Point2D)"(arg0: Internal.Point2D_): boolean;
        notifyAll(): void;
        abstract setFrame(arg0: number, arg1: number, arg2: number, arg3: number): void;
        abstract getPathIterator(arg0: Internal.AffineTransform_): Internal.PathIterator;
        setFrameFromDiagonal(arg0: number, arg1: number, arg2: number, arg3: number): void;
        contains(arg0: Internal.Point2D_): boolean;
        abstract getX(): number;
        "contains(java.awt.geom.Rectangle2D)"(arg0: Internal.Rectangle2D_): boolean;
        abstract getY(): number;
        setFrame(arg0: Internal.Point2D_, arg1: Internal.Dimension2D_): void;
        hashCode(): number;
        wait(): void;
        getFrame(): Internal.Rectangle2D;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        setFrameFromDiagonal(arg0: Internal.Point2D_, arg1: Internal.Point2D_): void;
        get class(): typeof any
        get bounds(): Internal.Rectangle
        get maxX(): number
        get maxY(): number
        get centerY(): number
        get empty(): boolean
        get centerX(): number
        get width(): number
        set frame(arg0: Internal.Rectangle2D_)
        get bounds2D(): Internal.Rectangle2D
        get minX(): number
        get height(): number
        get minY(): number
        get x(): number
        get y(): number
        get frame(): Internal.Rectangle2D
    }
    type RectangularShape_ = RectangularShape;
    class BaseDrinkItem extends Internal.ModelProviderItem {
        constructor(settings: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        getItemModel(resourceLocation: ResourceLocation_): Internal.BlockModel;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getUseAnimation(stack: Internal.ItemStack_): Internal.UseAnim;
        getDescriptionId(): string;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(world: Internal.Level_, user: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration(stack: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem(stack: Internal.ItemStack_, level: Internal.Level_, user: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type BaseDrinkItem_ = BaseDrinkItem;
    class AnvilRecipe implements Internal.UnknownReceipBookCategory, Internal.Recipe<net.minecraft.world.Container> {
        constructor(identifier: ResourceLocation_, input: Internal.Ingredient_, output: Internal.ItemStack_, inputCount: number, toolLevel: number, anvilLevel: number, damage: number)
        getGroup(): string;
        getToastSymbol(): Internal.ItemStack;
        getIngredient(c: net.minecraft.world.Container_): Internal.ItemStack;
        notify(): void;
        getId(): ResourceLocation;
        static isHammer(tool: Internal.Item_): boolean;
        checkHammerDurability(craftingInventory: net.minecraft.world.Container_, player: Internal.Player_): boolean;
        isIn(tag: ResourceLocation_): boolean;
        handler$bpa000$bclib$bcl_getRemainingItems(container: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>): void;
        static getIngredientSlot(c: net.minecraft.world.Container_): number;
        isSpecial(): boolean;
        getDamage(): number;
        matches(craftingInventory: net.minecraft.world.Container_): boolean;
        canCraftInDimensions(width: number, height: number): boolean;
        getMainIngredient(): Internal.Ingredient;
        showNotification(): boolean;
        replaceInput(match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): boolean;
        getType(): ResourceLocation;
        static getHammerSlot(c: net.minecraft.world.Container_): number;
        "handler$fie000$fabric-item-api-v1$captureStack"(inventory: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>, defaultedList: Internal.NonNullList_<any>, i: number): void;
        wait(): void;
        isIncomplete(): boolean;
        getClass(): typeof any;
        craft(craftingInventory: net.minecraft.world.Container_, player: Internal.Player_): Internal.ItemStack;
        getSchema(): Internal.RecipeSchema;
        wait(arg0: number, arg1: number): void;
        getAnvilLevel(): number;
        getSerializer(): Internal.RecipeSerializer<any>;
        assemble(craftingInventory: net.minecraft.world.Container_, acc: Internal.RegistryAccess_): Internal.ItemStack;
        static register(): void;
        getHammer(c: net.minecraft.world.Container_): Internal.ItemStack;
        matches(craftingInventory: net.minecraft.world.Container_, world: Internal.Level_): boolean;
        getMod(): string;
        getRemainingItems($$0: net.minecraft.world.Container_): Internal.NonNullList<Internal.ItemStack>;
        getIngredients(): Internal.NonNullList<Internal.Ingredient>;
        hasOutput(match: Internal.ReplacementMatch_): boolean;
        getResultItem(acc: Internal.RegistryAccess_): Internal.ItemStack;
        toString(): string;
        notifyAll(): void;
        getInputCount(): number;
        setGroup(group: string): void;
        static getAllHammers(): Internal.Iterable<Internal.Holder<Internal.Item>>;
        hashCode(): number;
        getOrCreateId(): ResourceLocation;
        canUse(tool: Internal.Item_): boolean;
        hasInput(match: Internal.ReplacementMatch_): boolean;
        wait(arg0: number): void;
        replaceOutput(match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): boolean;
        equals(o: any): boolean;
        get group(): string
        get toastSymbol(): Internal.ItemStack
        get id(): ResourceLocation
        get special(): boolean
        get damage(): number
        get mainIngredient(): Internal.Ingredient
        get type(): ResourceLocation
        get incomplete(): boolean
        get class(): typeof any
        get schema(): Internal.RecipeSchema
        get anvilLevel(): number
        get serializer(): Internal.RecipeSerializer<any>
        get mod(): string
        get ingredients(): Internal.NonNullList<Internal.Ingredient>
        get inputCount(): number
        set group(group: string)
        get allHammers(): Internal.Iterable<Internal.Holder<Internal.Item>>
        get orCreateId(): ResourceLocation
        static readonly GROUP: ("smithing") & (string);
        static readonly SERIALIZER: (Internal.AnvilRecipe$Serializer) & (Internal.AnvilRecipe$Serializer);
        static readonly TYPE: Internal.RecipeType<Internal.AnvilRecipe>;
        static readonly ID: (ResourceLocation) & (ResourceLocation);
    }
    type AnvilRecipe_ = AnvilRecipe;
    interface LootPoolBuilderExtension {
        name(name: string): Internal.LootPool$Builder;
    }
    type LootPoolBuilderExtension_ = LootPoolBuilderExtension;
    interface VillagerTrades$ItemListing {
        abstract getOffer(arg0: Internal.Entity_, arg1: Internal.RandomSource_): Internal.MerchantOffer;
        (arg0: Internal.Entity, arg1: Internal.RandomSource): Internal.MerchantOffer_;
    }
    type VillagerTrades$ItemListing_ = VillagerTrades$ItemListing | ((arg0: Internal.Entity, arg1: Internal.RandomSource)=> Internal.MerchantOffer_);
    class TrimPattern extends Internal.Record {
        constructor($$0: ResourceLocation_, $$1: Internal.Holder_<Internal.Item>, $$2: net.minecraft.network.chat.Component_)
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        templateItem(): Internal.Holder<Internal.Item>;
        description(): net.minecraft.network.chat.Component;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        assetId(): ResourceLocation;
        equals($$0: any): boolean;
        copyWithStyle($$0: Internal.Holder_<Internal.TrimMaterial>): net.minecraft.network.chat.Component;
        get class(): typeof any
        static readonly CODEC: Internal.Codec<Internal.Holder<Internal.TrimPattern>>;
        static readonly DIRECT_CODEC: Internal.Codec<Internal.TrimPattern>;
    }
    type TrimPattern_ = Special.TrimPattern | TrimPattern;
    abstract class DragonRespawnStage extends Internal.Enum<Internal.DragonRespawnStage> implements Internal.StringRepresentable {
        getClass(): typeof any;
        static valueOf(name: string): Internal.DragonRespawnStage;
        static fromEnumWithMapping<E extends Internal.Enum<E> & Internal.StringRepresentable>($$0: Internal.Supplier_<E[]>, $$1: Internal.Function_<string, string>): Internal.StringRepresentable$EnumCodec<E>;
        getSerializedName(): string;
        static byName(name: string): Internal.DragonRespawnStage;
        notify(): void;
        getDeclaringClass(): typeof Internal.DragonRespawnStage;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        compareTo(arg0: Internal.DragonRespawnStage_): number;
        static fromEnum<E extends Internal.Enum<E> & Internal.StringRepresentable>($$0: Internal.Supplier_<E[]>): Internal.StringRepresentable$EnumCodec<E>;
        abstract tick(arg0: Internal.ServerLevel_, arg1: Internal.EndDragonFight_, arg2: Internal.List_<Internal.EndCrystal>, arg3: number, arg4: BlockPos_): void;
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        toString(): string;
        notifyAll(): void;
        static values(): Internal.DragonRespawnStage[];
        name(): string;
        hashCode(): number;
        static keys($$0: Internal.StringRepresentable_[]): Internal.Keyable;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.DragonRespawnStage>>;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        "compareTo(com.yungnickyoung.minecraft.betterendisland.world.DragonRespawnStage)"(arg0: Internal.DragonRespawnStage_): number;
        get class(): typeof any
        get serializedName(): string
        get declaringClass(): typeof Internal.DragonRespawnStage
        static readonly END: Internal.DragonRespawnStage;
        static readonly CODEC: Internal.StringRepresentable$EnumCodec<Internal.DragonRespawnStage>;
        static readonly PREPARING_TO_SUMMON_PILLARS: Internal.DragonRespawnStage;
        static readonly START: Internal.DragonRespawnStage;
        static readonly SUMMONING_PILLARS: Internal.DragonRespawnStage;
        static readonly SUMMONING_DRAGON: Internal.DragonRespawnStage;
    }
    type DragonRespawnStage_ = "summoning_pillars" | "start" | "summoning_dragon" | DragonRespawnStage | "end" | "preparing_to_summon_pillars";
    class ManaPoolMinecartItem extends Internal.Item {
        constructor(builder: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn(context: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type ManaPoolMinecartItem_ = ManaPoolMinecartItem;
    class StaffHostileEnsnarement extends Internal.BaseStaff {
        constructor(settings: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, world: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, tooltipContext: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn(context: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil(stack: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type StaffHostileEnsnarement_ = StaffHostileEnsnarement;
    class ItemUpgradeBalance extends Internal.ItemUpgrade {
        constructor(properties: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        getAllowMultiple(): boolean;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(itemStack: Internal.ItemStack_, world: Internal.Level_, list: Internal.List_<net.minecraft.network.chat.Component>, advanced: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        setAllowMultiple(allow: boolean): void;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        getUpgradeGroup(): number;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        getDescription(): net.minecraft.network.chat.Component;
        asIngredient(): Internal.Ingredient;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        isEnabled(): boolean;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        doesSneakBypassUse(stack: Internal.ItemStack_, level: Internal.LevelReader_, pos: BlockPos_, player: Internal.Player_): boolean;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get allowMultiple(): boolean
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        set allowMultiple(allow: boolean)
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        get upgradeGroup(): number
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        get enabled(): boolean
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type ItemUpgradeBalance_ = ItemUpgradeBalance;
    class LithostitchedTemplates implements Internal.Iterable<Internal.StructurePoolElement> {
        constructor()
        getClass(): typeof any;
        toString(): string;
        add(element: Internal.StructurePoolElement_, weight: number): this;
        notifyAll(): void;
        shuffle(random: Internal.RandomSource_): Internal.List<Internal.StructurePoolElement>;
        notify(): void;
        forEach(arg0: Internal.Consumer_<Internal.StructurePoolElement>): void;
        wait(arg0: number, arg1: number): void;
        iterator(): Internal.Iterator<Internal.StructurePoolElement>;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        spliterator(): Internal.Spliterator<Internal.StructurePoolElement>;
        stream(): Internal.Stream<Internal.StructurePoolElement>;
        equals(arg0: any): boolean;
        get class(): typeof any
    }
    type LithostitchedTemplates_ = LithostitchedTemplates;
    class ChorusPlantBlock extends Internal.PipeBlock {
        constructor($$0: Internal.BlockBehaviour$Properties_)
        /**
         * @deprecated
        */
        getOcclusionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        /**
         * @deprecated
        */
        getSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        axiom$customPickBlockStack(): Internal.ItemStack;
        getSoundType($$0: Internal.BlockState_): SoundType;
        /**
         * @deprecated
        */
        getVisualShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        handler$efo000$collective$Block_playerDestroy(level: Internal.Level_, player: Internal.Player_, blockPos: BlockPos_, blockState: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number, $$5: number): void;
        /**
         * @deprecated
        */
        randomTick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: Internal.BlockEntity_): void;
        static canSupportRigidBlock($$0: Internal.BlockGetter_, $$1: BlockPos_): boolean;
        static popResource($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.ItemStack_): void;
        setRandomTickCallback(callback: Internal.Consumer_<any>): void;
        getDescriptionId(): string;
        stepOn($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Entity_): void;
        fallOn($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: BlockPos_, $$3: Internal.Entity_, $$4: number): void;
        getSettings(): Internal.BlockBehaviour$Properties;
        getExplosionResistance(): number;
        asItem(): Internal.Item;
        /**
         * @deprecated
        */
        triggerEvent($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: number, $$4: number): boolean;
        getTypeData(): Internal.CompoundTag;
        setFriction(arg0: number): void;
        /**
         * @deprecated
        */
        getRenderShape($$0: Internal.BlockState_): Internal.RenderShape;
        canCull(): boolean;
        customShapeUpdate(blockState: Internal.CustomBlockState_, levelReader: Internal.LevelReader_, blockPos: BlockPos_): Internal.CustomBlockState;
        getJumpFactor(): number;
        getSpeedFactor(): number;
        static canSupportCenter($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        skipRendering($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getLightBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        playerDestroy($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.BlockEntity_, $$5: Internal.ItemStack_): void;
        shouldAttemptToCull(state: Internal.BlockState_): boolean;
        isPossibleToRespawnInThis($$0: Internal.BlockState_): boolean;
        getCustomStateForPlacement(blockPlaceContext: Internal.BlockPlaceContext_): Internal.CustomBlockState;
        /**
         * @deprecated
        */
        getDirectSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        getProperties(): Internal.BlockBehaviour$Properties;
        playerWillDestroy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Player_): void;
        getClass(): typeof any;
        getMaxVerticalOffset(): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.item.context.BlockPlaceContext)"($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        useShapeForLightOcclusion($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        getDrops($$0: Internal.BlockState_, $$1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getStateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>;
        /**
         * @deprecated
        */
        entityInside($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Entity_): void;
        setBlockBuilder(b: Internal.BlockBuilder_): void;
        handler$ldb000$puzzleslib$playerDestroy$0(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        setRequiresTool(v: boolean): void;
        setSpeedFactor(arg0: number): void;
        axiom$getPossibleCustomStates(): Internal.List<any>;
        setExplosionResistance(arg0: number): void;
        toString(): string;
        port_lib$popExperience(arg0: Internal.ServerLevel_, arg1: BlockPos_, arg2: number): void;
        notifyAll(): void;
        getToolModifiedState(state: Internal.BlockState_, world: Internal.Level_, pos: BlockPos_, player: Internal.Player_, stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): Internal.BlockState;
        getId(): string;
        getLootTable(): ResourceLocation;
        puzzleslib$setItem(arg0: Internal.Item_): void;
        axiom$translationKey(): string;
        /**
         * @deprecated
        */
        getInteractionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        propagatesSkylightDown($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        setPlacedBy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.LivingEntity_, $$4: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        onPlace($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Block>;
        static popResourceFromFace($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.ItemStack_): void;
        getFriction(): number;
        handlePrecipitation($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Biome$Precipitation_): void;
        /**
         * @deprecated
        */
        hasAnalogOutputSignal($$0: Internal.BlockState_): boolean;
        wait(arg0: number): void;
        /**
         * @deprecated
        */
        getFluidState($$0: Internal.BlockState_): Internal.FluidState;
        handler$koh000$porting_lib_entity$getDestroySpeed(blockState: Internal.BlockState_, player: Internal.Player_, blockGetter: Internal.BlockGetter_, pos: BlockPos_, cir: Internal.CallbackInfoReturnable_<any>): void;
        /**
         * @deprecated
        */
        getAnalogOutputSignal($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): number;
        handler$efo000$collective$Block_setPlacedBy(level: Internal.Level_, blockPos: BlockPos_, blockState: Internal.BlockState_, livingEntity: Internal.LivingEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        tick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        supportsExternalFaceHiding(state: Internal.BlockState_): boolean;
        handler$ldb000$puzzleslib$playerDestroy$1(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        notify(): void;
        axiom$asItemStack(): Internal.ItemStack;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        neighborChanged($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Block_, $$4: BlockPos_, $$5: boolean): void;
        handler$zhd000$additionalentityattributes$additionalEntityAttributes$saveBreakingPlayer(world: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, stack: Internal.ItemStack_, callbackInfo: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        getBlockSupportShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        canSustainPlant(state: Internal.BlockState_, world: Internal.BlockGetter_, pos: BlockPos_, facing: Internal.Direction_, plantable: Internal.IPlantable_): boolean;
        /**
         * @deprecated
        */
        isCollisionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static isFaceFull($$0: Internal.VoxelShape_, $$1: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getMenuProvider($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): Internal.MenuProvider;
        static byItem($$0: Internal.Item_): Internal.Block;
        static updateFromNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        updateIndirectNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: number, $$4: number): void;
        destroy($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): void;
        handler$fdc000$everycomp$addSimpleFastECdrops(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, cir: Internal.CallbackInfoReturnable_<any>, resId: ResourceLocation_, lootParams: Internal.LootParams_, serverLevel: Internal.ServerLevel_, lootTable: Internal.LootTable_): void;
        getToolModifiedState(state: Internal.BlockState_, context: Internal.UseOnContext_, toolAction: Internal.ToolAction_, simulate: boolean): Internal.BlockState;
        /**
         * @deprecated
        */
        use($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_, $$4: Internal.InteractionHand_, $$5: Internal.BlockHitResult_): Internal.InteractionResult;
        setLightEmission(v: number): void;
        doNormalInteractions(): boolean;
        setJumpFactor(arg0: number): void;
        canSurvive($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): void;
        /**
         * @deprecated
        */
        getShadeBrightness($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        getAppearance(state: Internal.BlockState_, renderView: Internal.BlockAndTintGetter_, pos: BlockPos_, side: Internal.Direction_, sourceState: Internal.BlockState_, sourcePos: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        getCollisionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        setDestroySpeed(v: number): void;
        defaultBlockState(): Internal.BlockState;
        usesCustomShouldDrawFace(state: Internal.BlockState_): boolean;
        getStateForPlacement($$0: Internal.BlockPlaceContext_): Internal.BlockState;
        cantCullAgainst(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        arch$holder(): Internal.Holder<Internal.Block>;
        wait(): void;
        getCloneItemStack($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        hasDynamicShape(): boolean;
        getMaxHorizontalOffset(): number;
        /**
         * @deprecated
        */
        getDestroyProgress($$0: Internal.BlockState_, $$1: Internal.Player_, $$2: Internal.BlockGetter_, $$3: BlockPos_): number;
        /**
         * @deprecated
        */
        getSeed($$0: Internal.BlockState_, $$1: BlockPos_): number;
        defaultDestroyTime(): number;
        updateShape($$0: Internal.BlockState_, $$1: Internal.Direction_, $$2: Internal.BlockState_, $$3: Internal.LevelAccessor_, $$4: BlockPos_, $$5: BlockPos_): Internal.BlockState;
        dropFromExplosion($$0: Internal.Explosion_): boolean;
        isRandomlyTicking($$0: Internal.BlockState_): boolean;
        static isShapeFullBlock(shape: Internal.VoxelShape_): boolean;
        withPropertiesOf($$0: Internal.BlockState_): Internal.BlockState;
        static isExceptionForConnection($$0: Internal.BlockState_): boolean;
        setIsRandomlyTicking(arg0: boolean): void;
        hidesNeighborFace(level: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, neighborState: Internal.BlockState_, dir: Internal.Direction_): boolean;
        onTreeGrow(state: Internal.BlockState_, level: Internal.LevelReader_, placeFunction: Internal.BiConsumer_<BlockPos, Internal.BlockState>, randomSource: Internal.RandomSource_, pos: BlockPos_, config: Internal.TreeConfiguration_): boolean;
        /**
         * @deprecated
        */
        rotate($$0: Internal.BlockState_, $$1: Internal.Rotation_): Internal.BlockState;
        defaultMapColor(): Internal.MapColor;
        getStateAtViewpoint(state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_, viewpoint: Vec3d_): Internal.BlockState;
        wait(arg0: number, arg1: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.BlockGetter_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        setNameKey(arg0: string): void;
        static box($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): Internal.VoxelShape;
        /**
         * @deprecated
        */
        mirror($$0: Internal.BlockState_, $$1: Internal.Mirror_): Internal.BlockState;
        wasExploded($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Explosion_): void;
        getName(): Internal.MutableComponent;
        updateEntityAfterFallOn($$0: Internal.BlockGetter_, $$1: Internal.Entity_): void;
        animateTick($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        customShouldDrawFace(view: Internal.BlockGetter_, thisState: Internal.BlockState_, sideState: Internal.BlockState_, thisPos: BlockPos_, sidePos: BlockPos_, side: Internal.Direction_): Optional<boolean>;
        axiom$getResourceLocation(): ResourceLocation;
        arch$registryName(): ResourceLocation;
        axiom$getProperties(): Internal.Collection<any>;
        getBlockBuilder(): Internal.BlockBuilder;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        isSignalSource($$0: Internal.BlockState_): boolean;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number): void;
        /**
         * @deprecated
        */
        attack($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): void;
        getShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        shouldAttemptToCull(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        onProjectileHit($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockHitResult_, $$3: Internal.Projectile_): void;
        getStateForPlacement($$0: Internal.BlockGetter_, $$1: BlockPos_): Internal.BlockState;
        static stateById($$0: number): Internal.BlockState;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): Internal.List<Internal.ItemStack>;
        requiredFeatures(): Internal.FeatureFlagSet;
        hashCode(): number;
        axiom$defaultCustomState(): Internal.CustomBlockState;
        setCanCull(canCull: boolean): void;
        /**
         * @deprecated
        */
        isOcclusionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static getId($$0: Internal.BlockState_): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.material.Fluid)"($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        static pushEntitiesUp($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): Internal.BlockState;
        isPathfindable($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.PathComputationType_): boolean;
        setSoundType(arg0: SoundType_): void;
        handler$cef000$betterend$be_getDroppedStacks(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, info: Internal.CallbackInfoReturnable_<any>): void;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_): Internal.List<Internal.ItemStack>;
        /**
         * @deprecated
        */
        onRemove($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        cantCullAgainst(state: Internal.BlockState_): boolean;
        setHasCollision(arg0: boolean): void;
        static shouldRenderFace($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_, $$4: BlockPos_): boolean;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        spawnAfterBreak($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.ItemStack_, $$4: boolean): void;
        set randomTickCallback(callback: Internal.Consumer_<any>)
        get descriptionId(): string
        get settings(): Internal.BlockBehaviour$Properties
        get explosionResistance(): number
        get typeData(): Internal.CompoundTag
        set friction(arg0: number)
        get jumpFactor(): number
        get speedFactor(): number
        get properties(): Internal.BlockBehaviour$Properties
        get class(): typeof any
        get maxVerticalOffset(): number
        get stateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>
        set blockBuilder(b: Internal.BlockBuilder_)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        set speedFactor(arg0: number)
        set explosionResistance(arg0: number)
        get id(): string
        get lootTable(): ResourceLocation
        get friction(): number
        set lightEmission(v: number)
        set jumpFactor(arg0: number)
        set destroySpeed(v: number)
        get maxHorizontalOffset(): number
        set isRandomlyTicking(arg0: boolean)
        set nameKey(arg0: string)
        get name(): Internal.MutableComponent
        get blockBuilder(): Internal.BlockBuilder
        get idLocation(): ResourceLocation
        get mod(): string
        set canCull(canCull: boolean)
        set soundType(arg0: SoundType_)
        set hasCollision(arg0: boolean)
    }
    type ChorusPlantBlock_ = ChorusPlantBlock;
    class VanillaModelLayerProperties {
        getClass(): typeof any;
        static get(location: Internal.ModelLayerLocation_, renderer: Internal.EntityRenderer_<any>): Internal.VanillaModelLayerProperties;
        transform(poseStack: Internal.PoseStack_): void;
        toString(): string;
        notifyAll(): void;
        getOffsetX(): number;
        getOffsetY(): number;
        getOffsetZ(): number;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        shouldFlipX(): boolean;
        shouldFlipZ(): boolean;
        shouldFlipY(): boolean;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        get class(): typeof any
        get offsetX(): number
        get offsetY(): number
        get offsetZ(): number
    }
    type VanillaModelLayerProperties_ = VanillaModelLayerProperties;
    interface IoSupplier <T> {
        create($$0: Internal.Path_): Internal.IoSupplier<Internal.InputStream>;
        abstract get(): T;
        create($$0: Internal.ZipFile_, $$1: Internal.ZipEntry_): Internal.IoSupplier<Internal.InputStream>;
        (): T;
    }
    type IoSupplier_<T> = IoSupplier<T> | (()=> T);
    class BlobFoliagePlacer extends Internal.FoliagePlacer {
        constructor($$0: Internal.IntProvider_, $$1: Internal.IntProvider_, $$2: number)
        getClass(): typeof any;
        hashCode(): number;
        createFoliage($$0: Internal.LevelSimulatedReader_, $$1: Internal.FoliagePlacer$FoliageSetter_, $$2: Internal.RandomSource_, $$3: Internal.TreeConfiguration_, $$4: number, $$5: Internal.FoliagePlacer$FoliageAttachment_, $$6: number, $$7: number): void;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        foliageHeight($$0: Internal.RandomSource_, $$1: number, $$2: Internal.TreeConfiguration_): number;
        equals(arg0: any): boolean;
        notify(): void;
        foliageRadius($$0: Internal.RandomSource_, $$1: number): number;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        static readonly CODEC: Internal.Codec<Internal.BlobFoliagePlacer>;
    }
    type BlobFoliagePlacer_ = BlobFoliagePlacer;
    class TagKey <T> extends Internal.Record {
        constructor($$0: Internal.ResourceKey_<Internal.Registry<T>>, $$1: ResourceLocation_)
        getClass(): typeof any;
        static create<T>($$0: Internal.ResourceKey_<Internal.Registry<T>>, $$1: ResourceLocation_): Internal.TagKey<T>;
        toString(): string;
        cast<E>($$0: Internal.ResourceKey_<Internal.Registry<E>>): Optional<Internal.TagKey<E>>;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        location(): ResourceLocation;
        static codec<T>($$0: Internal.ResourceKey_<Internal.Registry<T>>): Internal.Codec<Internal.TagKey<T>>;
        wait(): void;
        registry(): Internal.ResourceKey<Internal.Registry<T>>;
        wait(arg0: number): void;
        isFor($$0: Internal.ResourceKey_<Internal.Registry<any>>): boolean;
        static hashedCodec<T>($$0: Internal.ResourceKey_<Internal.Registry<T>>): Internal.Codec<Internal.TagKey<T>>;
        equals($$0: any): boolean;
        get class(): typeof any
    }
    type TagKey_<T> = TagKey<T>;
    interface IAquiferSamplerFluidLevel {
    }
    type IAquiferSamplerFluidLevel_ = IAquiferSamplerFluidLevel;
    interface IntIterator extends Internal.PrimitiveIterator$OfInt {
        forEachRemaining(arg0: any): void;
        "forEachRemaining(it.unimi.dsi.fastutil.ints.IntConsumer)"(arg0: it.unimi.dsi.fastutil.ints.IntConsumer_): void;
        /**
         * @deprecated
        */
        next(): any;
        skip(arg0: number): number;
        forEachRemaining(arg0: it.unimi.dsi.fastutil.ints.IntConsumer_): void;
        forEachRemaining(arg0: Internal.IntConsumer_): void;
        /**
         * @deprecated
        */
        forEachRemaining(arg0: Internal.Consumer_<number>): void;
        remove(): void;
        /**
         * @deprecated
        */
        "forEachRemaining(java.util.function.Consumer)"(arg0: Internal.Consumer_<number>): void;
        "forEachRemaining(java.lang.Object)"(arg0: any): void;
        "forEachRemaining(java.util.function.IntConsumer)"(arg0: Internal.IntConsumer_): void;
        abstract hasNext(): boolean;
        abstract nextInt(): number;
    }
    type IntIterator_ = IntIterator;
    interface ToIntBiFunction <T, U> {
        abstract applyAsInt(arg0: T, arg1: U): number;
        (arg0: T, arg1: U): number;
    }
    type ToIntBiFunction_<T, U> = ToIntBiFunction<T, U> | ((arg0: T, arg1: U)=> number);
    class CopperWardItem extends Internal.ShieldItem implements Internal.Modifiable, Internal.SpellcastersReagent {
        constructor(attribute: Internal.Attribute_, modifier: Internal.AttributeModifier_, settings: Internal.Item$Properties_)
        onTick(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        addModifierTooltip(stack: Internal.ItemStack_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_, type: Internal.ModifierHelperType_<any>): void;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, world: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        getDescriptionId(): string;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        fzzy_core_correctSlot(slot: Internal.EquipmentSlot_): boolean;
        getCreativeTab(): string;
        postWearerHit(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        modifierObjectPredicate(livingEntity: Internal.LivingEntity_, stack: Internal.ItemStack_): ResourceLocation;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        defaultModifiers(type: Internal.ModifierHelperType_<any>): Internal.List<ResourceLocation>;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        static get($$0: Internal.ItemStack_): Internal.Equipable;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        fzzy_core_getCorrectSlot(): Internal.EquipmentSlot;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        getEquipmentSlot(): Internal.EquipmentSlot;
        onWearerKilledOther(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, victim: Internal.LivingEntity_, world: Internal.ServerLevel_): void;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        static getColor($$0: Internal.ItemStack_): Internal.DyeColor;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        canBeModifiedBy(type: Internal.ModifierHelperType_<any>): boolean;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        incrementKillCount(stack: Internal.ItemStack_): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        getAttributeModifier(): kotlin.Pair<Internal.Attribute, Internal.AttributeModifier>;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        getEquipSound(): Internal.SoundEvent;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        port_lib$canPerformAction(stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): boolean;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        onAttack(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, attacker: Internal.LivingEntity_, source: DamageSource_, amount: number): number;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getKillCount(stack: Internal.ItemStack_): number;
        getTypeItemStackKey(): Internal.ItemStackKey;
        onWearerDamaged(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, attacker: Internal.LivingEntity_, source: DamageSource_, amount: number): number;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        swapWithEquipmentSlot($$0: Internal.Item_, $$1: Internal.Level_, $$2: Internal.Player_, $$3: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get equipmentSlot(): Internal.EquipmentSlot
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        get attributeModifier(): kotlin.Pair<Internal.Attribute, Internal.AttributeModifier>
        set attackSpeed(attackSpeed: number)
        get equipSound(): Internal.SoundEvent
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type CopperWardItem_ = CopperWardItem;
    class AxolotlAttackablesSensor extends Internal.NearestVisibleLivingEntitySensor {
        constructor()
        getClass(): typeof any;
        toString(): string;
        static isEntityTargetable($$0: Internal.LivingEntity_, $$1: Internal.LivingEntity_): boolean;
        notifyAll(): void;
        static isEntityAttackableIgnoringLineOfSight($$0: Internal.LivingEntity_, $$1: Internal.LivingEntity_): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        tick($$0: Internal.ServerLevel_, $$1: Internal.LivingEntity_): void;
        wait(): void;
        getLastSenseTime(): number;
        static isEntityAttackable($$0: Internal.LivingEntity_, $$1: Internal.LivingEntity_): boolean;
        wait(arg0: number): void;
        getSenseInterval(): number;
        setLastSenseTime(arg0: number): void;
        equals(arg0: any): boolean;
        requires(): Internal.Set<Internal.MemoryModuleType<any>>;
        get class(): typeof any
        get lastSenseTime(): number
        get senseInterval(): number
        set lastSenseTime(arg0: number)
        static readonly TARGET_DETECTION_DISTANCE: (8.0) & (number);
    }
    type AxolotlAttackablesSensor_ = AxolotlAttackablesSensor;
    class SpecterBangleItem extends Internal.TrinketItem {
        constructor(settings: Internal.Item$Properties_)
        onTick(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        addModifierTooltip(stack: Internal.ItemStack_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_, type: Internal.ModifierHelperType_<any>): void;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        static "equipItem(net.minecraft.world.entity.LivingEntity,net.minecraft.world.item.ItemStack)"(user: Internal.LivingEntity_, stack: Internal.ItemStack_): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        fzzy_core_correctSlot(slot: Internal.EquipmentSlot_): boolean;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        postWearerHit(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        static equipItem(user: Internal.Player_, stack: Internal.ItemStack_): boolean;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        static equipItem(user: Internal.LivingEntity_, stack: Internal.ItemStack_): boolean;
        modifierObjectPredicate(livingEntity: Internal.LivingEntity_, stack: Internal.ItemStack_): ResourceLocation;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        onBreak(stack: Internal.ItemStack_, slot: dev.emi.trinkets.api.SlotReference_, entity: Internal.LivingEntity_): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        defaultModifiers(type: Internal.ModifierHelperType_<any>): Internal.List<ResourceLocation>;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        onEquip(stack: Internal.ItemStack_, slot: dev.emi.trinkets.api.SlotReference_, entity: Internal.LivingEntity_): void;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        getDropRule(stack: Internal.ItemStack_, slot: dev.emi.trinkets.api.SlotReference_, entity: Internal.LivingEntity_): Internal.TrinketEnums$DropRule;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        fzzy_core_getCorrectSlot(): Internal.EquipmentSlot;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        getModifiers(stack: Internal.ItemStack_, slot: dev.emi.trinkets.api.SlotReference_, entity: Internal.LivingEntity_, uuid: Internal.UUID_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(world: Internal.Level_, user: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        onWearerKilledOther(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, victim: Internal.LivingEntity_, world: Internal.ServerLevel_): void;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        tick(stack: Internal.ItemStack_, slot: dev.emi.trinkets.api.SlotReference_, entity: Internal.LivingEntity_): void;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        canBeModifiedBy(type: Internal.ModifierHelperType_<any>): boolean;
        static "equipItem(net.minecraft.world.entity.player.Player,net.minecraft.world.item.ItemStack)"(user: Internal.Player_, stack: Internal.ItemStack_): boolean;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        incrementKillCount(stack: Internal.ItemStack_): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        canEquip(stack: Internal.ItemStack_, slot: dev.emi.trinkets.api.SlotReference_, entity: Internal.LivingEntity_): boolean;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canUnequip(stack: Internal.ItemStack_, slot: dev.emi.trinkets.api.SlotReference_, entity: Internal.LivingEntity_): boolean;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        onAttack(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, attacker: Internal.LivingEntity_, source: DamageSource_, amount: number): number;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        onUnequip(stack: Internal.ItemStack_, slot: dev.emi.trinkets.api.SlotReference_, entity: Internal.LivingEntity_): void;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        getKillCount(stack: Internal.ItemStack_): number;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        onWearerDamaged(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, attacker: Internal.LivingEntity_, source: DamageSource_, amount: number): number;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type SpecterBangleItem_ = SpecterBangleItem;
    class SurfaceRelativeThresholdFilter extends Internal.PlacementFilter {
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        getPositions($$0: Internal.PlacementContext_, $$1: Internal.RandomSource_, $$2: BlockPos_): Internal.Stream<BlockPos>;
        wait(): void;
        type(): Internal.PlacementModifierType<any>;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        static of($$0: Internal.Heightmap$Types_, $$1: number, $$2: number): Internal.SurfaceRelativeThresholdFilter;
        get class(): typeof any
        static readonly CODEC: Internal.Codec<Internal.SurfaceRelativeThresholdFilter>;
    }
    type SurfaceRelativeThresholdFilter_ = SurfaceRelativeThresholdFilter;
    class ShulkerBoxBlockEntity$AnimationStatus extends Internal.Enum<Internal.ShulkerBoxBlockEntity$AnimationStatus> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        toString(): string;
        static valueOf($$0: string): Internal.ShulkerBoxBlockEntity$AnimationStatus;
        notifyAll(): void;
        notify(): void;
        static values(): Internal.ShulkerBoxBlockEntity$AnimationStatus[];
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        name(): string;
        hashCode(): number;
        compareTo(arg0: Internal.ShulkerBoxBlockEntity$AnimationStatus_): number;
        getDeclaringClass(): typeof Internal.ShulkerBoxBlockEntity$AnimationStatus;
        "compareTo(net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity$AnimationStatus)"(arg0: Internal.ShulkerBoxBlockEntity$AnimationStatus_): number;
        ordinal(): number;
        wait(): void;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.ShulkerBoxBlockEntity$AnimationStatus>>;
        wait(arg0: number): void;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        get class(): typeof any
        get declaringClass(): typeof Internal.ShulkerBoxBlockEntity$AnimationStatus
        static readonly OPENING: (Internal.ShulkerBoxBlockEntity$AnimationStatus) & (Internal.ShulkerBoxBlockEntity$AnimationStatus);
        static readonly CLOSED: (Internal.ShulkerBoxBlockEntity$AnimationStatus) & (Internal.ShulkerBoxBlockEntity$AnimationStatus);
        static readonly CLOSING: (Internal.ShulkerBoxBlockEntity$AnimationStatus) & (Internal.ShulkerBoxBlockEntity$AnimationStatus);
        static readonly OPENED: (Internal.ShulkerBoxBlockEntity$AnimationStatus) & (Internal.ShulkerBoxBlockEntity$AnimationStatus);
    }
    type ShulkerBoxBlockEntity$AnimationStatus_ = "opening" | ShulkerBoxBlockEntity$AnimationStatus | "closing" | "closed" | "opened";
    interface IOpenableScreen extends Internal.Runnable {
        closeGui(): void;
        abstract openGui(): void;
        closeContextMenu(): void;
        closeGui(openPrevScreen: boolean): void;
        run(): void;
        openAfter(runnable: Internal.Runnable_): Internal.Runnable;
        openGuiLater(): void;
        (): void;
    }
    type IOpenableScreen_ = (()=> void) | IOpenableScreen;
    class ByteProcessor$IndexOfProcessor implements Internal.ByteProcessor {
        constructor(arg0: number)
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        process(arg0: number): boolean;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
    }
    type ByteProcessor$IndexOfProcessor_ = ByteProcessor$IndexOfProcessor;
    interface BlockStatePathingCache {
        abstract getNeighborPathNodeType(): Internal.BlockPathTypes;
        abstract getPathNodeType(): Internal.BlockPathTypes;
        get neighborPathNodeType(): Internal.BlockPathTypes
        get pathNodeType(): Internal.BlockPathTypes
    }
    type BlockStatePathingCache_ = BlockStatePathingCache;
    class MessageSignature$Packed extends Internal.Record {
        constructor($$0: number, $$1: Internal.MessageSignature_)
        constructor($$0: number)
        constructor($$0: Internal.MessageSignature_)
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        id(): number;
        wait(): void;
        static read($$0: Internal.FriendlyByteBuf_): Internal.MessageSignature$Packed;
        wait(arg0: number): void;
        equals($$0: any): boolean;
        unpack($$0: Internal.MessageSignatureCache_): Optional<Internal.MessageSignature>;
        static write($$0: Internal.FriendlyByteBuf_, $$1: Internal.MessageSignature$Packed_): void;
        fullSignature(): Internal.MessageSignature;
        get class(): typeof any
        static readonly FULL_SIGNATURE: (-1) & (number);
    }
    type MessageSignature$Packed_ = MessageSignature$Packed;
    class ConstantInt extends Internal.IntProvider {
        getMinValue(): number;
        getClass(): typeof any;
        sample($$0: Internal.RandomSource_): number;
        toString(): string;
        getMaxValue(): number;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getType(): Internal.IntProviderType<any>;
        hashCode(): number;
        wait(): void;
        static of($$0: number): Internal.ConstantInt;
        wait(arg0: number): void;
        getValue(): number;
        equals(arg0: any): boolean;
        static codec($$0: number, $$1: number): Internal.Codec<Internal.IntProvider>;
        static codec<T extends Internal.IntProvider>($$0: number, $$1: number, $$2: Internal.Codec_<T>): Internal.Codec<T>;
        get minValue(): number
        get class(): typeof any
        get maxValue(): number
        get type(): Internal.IntProviderType<any>
        get value(): number
        static readonly ZERO: (Internal.ConstantInt) & (Internal.ConstantInt);
        static readonly CODEC: Internal.Codec<Internal.ConstantInt>;
    }
    type ConstantInt_ = ConstantInt;
    class EndDragonFight$Data extends Internal.Record {
        constructor($$0: boolean, $$1: boolean, $$2: boolean, $$3: boolean, $$4: Optional_<Internal.UUID>, $$5: Optional_<BlockPos>, $$6: Optional_<Internal.List<number>>)
        getClass(): typeof any;
        dragonUUID(): Optional<Internal.UUID>;
        toString(): string;
        notifyAll(): void;
        dragonKilled(): boolean;
        gateways(): Optional<Internal.List<number>>;
        needsStateScanning(): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        isRespawning(): boolean;
        hashCode(): number;
        wait(): void;
        previouslyKilled(): boolean;
        wait(arg0: number): void;
        exitPortalLocation(): Optional<BlockPos>;
        equals($$0: any): boolean;
        get class(): typeof any
        get respawning(): boolean
        static readonly CODEC: Internal.Codec<Internal.EndDragonFight$Data>;
        static readonly DEFAULT: (Internal.EndDragonFight$Data) & (Internal.EndDragonFight$Data);
    }
    type EndDragonFight$Data_ = EndDragonFight$Data;
    class InfusionRitual implements net.minecraft.world.Container {
        constructor(pedestal: any_, world: Internal.Level_, pos: BlockPos_)
        stopOpen($$0: Internal.Player_): void;
        static tryClear($$0: any): void;
        setStackInSlot(slot: number, stack: Internal.ItemStack_): void;
        notify(): void;
        clear(ingredient: Internal.Ingredient_): void;
        find(): number;
        hasAnyOf($$0: Internal.Set_<Internal.Item>): boolean;
        removeItem(slot: number, amount: number): Internal.ItemStack;
        toTag(tag: Internal.CompoundTag_): Internal.CompoundTag;
        getSlots(): number;
        setChanged(): void;
        fromTag(tag: Internal.CompoundTag_): void;
        getContainerSize(): number;
        setItem(slot: number, stack: Internal.ItemStack_): void;
        static getMap(): Internal.Point[];
        "setChanged()"(): void;
        hasAnyMatching($$0: Internal.Predicate_<Internal.ItemStack>): boolean;
        isValid(): boolean;
        kjs$self(): net.minecraft.world.Container;
        getWidth(): number;
        getSlotLimit(slot: number): number;
        getMaxStackSize(): number;
        "isEmpty()"(): boolean;
        removeItemNoUpdate(slot: number): Internal.ItemStack;
        static stillValidBlockEntity($$0: Internal.BlockEntity_, $$1: Internal.Player_): boolean;
        tick(): void;
        checkRecipe(): boolean;
        wait(): void;
        getItem(slot: number): Internal.ItemStack;
        hasRecipe(): boolean;
        isItemValid(slot: number, stack: Internal.ItemStack_): boolean;
        getClass(): typeof any;
        count(ingredient: Internal.Ingredient_): number;
        count(): number;
        setTransferCooldown(currentTime: number): void;
        countItem($$0: Internal.Item_): number;
        isEmpty(): boolean;
        wait(arg0: number, arg1: number): void;
        canPlaceItem(slot: number, stack: Internal.ItemStack_): boolean;
        setDirty(): void;
        startOpen($$0: Internal.Player_): void;
        extractItem(slot: number, amount: number, simulate: boolean): Internal.ItemStack;
        getBlock(level: Internal.Level_): Internal.BlockContainerJS;
        static stillValidBlockEntity($$0: Internal.BlockEntity_, $$1: Internal.Player_, $$2: number): boolean;
        canReceiveTransferCooldown(): boolean;
        reset(): void;
        getStackInSlot(slot: number): Internal.ItemStack;
        getHeight(): number;
        countNonEmpty(): number;
        asContainer(): net.minecraft.world.Container;
        toString(): string;
        notifyAll(): void;
        getAllItems(): Internal.List<Internal.ItemStack>;
        setLocation(world: Internal.Level_, pos: BlockPos_): void;
        canTakeItem($$0: net.minecraft.world.Container_, $$1: number, $$2: Internal.ItemStack_): boolean;
        insertItem(stack: Internal.ItemStack_, simulate: boolean): Internal.ItemStack;
        configure(): void;
        stillValid(player: Internal.Player_): boolean;
        insertItem(slot: number, stack: Internal.ItemStack_, simulate: boolean): Internal.ItemStack;
        hashCode(): number;
        isMutable(): boolean;
        clear(): void;
        wait(arg0: number): void;
        find(ingredient: Internal.Ingredient_): number;
        equals(arg0: any): boolean;
        clearContent(): void;
        countNonEmpty(ingredient: Internal.Ingredient_): number;
        get slots(): number
        get containerSize(): number
        get map(): Internal.Point[]
        get valid(): boolean
        get width(): number
        get maxStackSize(): number
        get "empty()"(): boolean
        get class(): typeof any
        set transferCooldown(currentTime: number)
        get empty(): boolean
        get height(): number
        get allItems(): Internal.List<Internal.ItemStack>
        get mutable(): boolean
    }
    type InfusionRitual_ = InfusionRitual;
    interface FinishedRecipe {
        abstract serializeRecipeData(arg0: Internal.JsonObject_): void;
        abstract getId(): ResourceLocation;
        abstract getAdvancementId(): ResourceLocation;
        abstract serializeAdvancement(): Internal.JsonObject;
        abstract getType(): Internal.RecipeSerializer<any>;
        serializeRecipe(): Internal.JsonObject;
        get id(): ResourceLocation
        get advancementId(): ResourceLocation
        get type(): Internal.RecipeSerializer<any>
    }
    type FinishedRecipe_ = FinishedRecipe;
    class MinecartTNT extends Internal.AbstractMinecart {
        constructor($$0: Internal.Level_, $$1: number, $$2: number, $$3: number)
        constructor($$0: Internal.EntityType_<Internal.MinecartTNT>, $$1: Internal.Level_)
        litematica_setWorld(arg0: Internal.Level_): void;
        handler$hak000$gobber2$gobberOccludeVibrationSignals(cir: Internal.CallbackInfoReturnable_<any>): void;
        isInWall(): boolean;
        etf$getType(): Internal.EntityType<any>;
        getAllSlots(): Internal.Iterable<Internal.ItemStack>;
        getUpVector($$0: number): Vec3d;
        getPos($$0: number, $$1: number, $$2: number): Vec3d;
        gameEvent($$0: Internal.GameEvent_, $$1: Internal.Entity_): void;
        remove($$0: Internal.Entity$RemovalReason_): void;
        getBlockZ(): number;
        isSuppressingBounce(): boolean;
        setHurtTime($$0: number): void;
        dampensVibrations(): boolean;
        hasAttached(type: Internal.AttachmentType_<any>): boolean;
        isSilent(): boolean;
        "playSound(net.minecraft.sounds.SoundEvent)"($$0: Internal.SoundEvent_): void;
        setCulled(value: boolean): void;
        getPitch(): number;
        isOnFire(): boolean;
        rotate($$0: Internal.Rotation_): number;
        getPositionCodec(): Internal.VecDeltaCodec;
        getPassengersAndSelf(): Internal.Stream<any>;
        setMaxUpStep($$0: number): void;
        updateFluidHeightAndDoFluidPushing($$0: Internal.TagKey_<Internal.Fluid>, $$1: number): boolean;
        setPosition(x: number, y: number, z: number): void;
        runCommandSilent(command: string): number;
        chunkPosition(): Internal.ChunkPos;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        emf$isOnGround(): boolean;
        gameEvent($$0: Internal.GameEvent_): void;
        alwaysAccepts(): boolean;
        isShiftKeyDown(): boolean;
        setUUID($$0: Internal.UUID_): void;
        checkBelowWorld(): void;
        isVisuallyCrawling(): boolean;
        setMotionZ(z: number): void;
        abstract getDropItem(): Internal.Item;
        handler$ieb000$lambdynlights$onRemove(ci: Internal.CallbackInfo_): void;
        "deserializeNBT(net.minecraft.nbt.Tag)"(arg0: Internal.Tag_): void;
        canFreeze(): boolean;
        ignoreExplosion(): boolean;
        port_lib$setRemovalReason(arg0: Internal.Entity$RemovalReason_): void;
        teleportRelative($$0: number, $$1: number, $$2: number): void;
        getBlockY(): number;
        getIsInsideStructureTracker(): Internal.IsInsideStructureTracker;
        isSpectator(): boolean;
        pehkui_setScaleCache(scaleCache: Internal.ScaleData_[]): void;
        isInWaterOrBubble(): boolean;
        spawnAtLocation($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        getPersistentData(): Internal.CompoundTag;
        getPortalCooldown(): number;
        emf$isGlowing(): boolean;
        getItem(): Internal.ItemStack;
        primeFuse(): void;
        causeFallDamage($$0: number, $$1: number, $$2: DamageSource_): boolean;
        getRandomZ($$0: number): number;
        pehkui_getOnGround(): boolean;
        getFusionModel(layerIndex: number): Internal.Triple<any, any, any>;
        getDynamicLightChunksToRebuild(forced: boolean): Internal.LongSet;
        getPosition($$0: number): Vec3d;
        setRemoved($$0: Internal.Entity$RemovalReason_): void;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>, initializer: Internal.Supplier_<A>): A;
        getDistanceSq($$0: number, $$1: number, $$2: number): number;
        isInWaterRainOrBubble(): boolean;
        getRemovalReason(): Internal.Entity$RemovalReason;
        wait(arg0: number): void;
        isIgnoringBlockTriggers(): boolean;
        getDamage(): number;
        etf$getItemsEquipped(): Internal.Iterable<any>;
        getHandHoldingItemAngle($$0: Internal.Item_): Vec3d;
        etf$getVelocity(): Vec3d;
        getPosOffs($$0: number, $$1: number, $$2: number, $$3: number): Vec3d;
        hex$markHurt(): void;
        distanceToSqr($$0: Vec3d_): number;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        resetFallDistance(): void;
        canSprint(): boolean;
        modifyAttached<A>(type: Internal.AttachmentType_<A>, modifier: Internal.UnaryOperator_<A>): A;
        blockPosition(): BlockPos;
        isSteppingCarefully(): boolean;
        setBoundingBox($$0: Internal.AABB_): void;
        isAmbientCreature(): boolean;
        "spawnAtLocation(net.minecraft.world.item.ItemStack,float)"($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        getDisplayBlockState(): Internal.BlockState;
        getBlockX(): number;
        /**
         * @deprecated
        */
        getLightLevelDependentMagicValue(): number;
        getEncodeId(): string;
        getY($$0: number): number;
        emf$prevPitch(): number;
        getBlock(): Internal.BlockContainerJS;
        getNbt(): Internal.CompoundTag;
        etf$getHandItems(): Internal.Iterable<any>;
        setInvisible($$0: boolean): void;
        etf$getArmorItems(): Internal.Iterable<any>;
        getName(): net.minecraft.network.chat.Component;
        isSubmergedInLoosely(tag: Internal.TagKey_<any>): boolean;
        onGround(): boolean;
        getDynamicLightY(): number;
        getControlledVehicle(): Internal.Entity;
        isOnSameTeam($$0: Internal.Entity_): boolean;
        attack($$0: DamageSource_, $$1: number): boolean;
        onInsideBubbleColumn($$0: boolean): void;
        tick(): void;
        invokeGetMaxOffRailSpeed(): number;
        getEyePosition(): Vec3d;
        getEyeHeight(): number;
        hasPassenger($$0: Internal.Predicate_<Internal.Entity>): boolean;
        getYaw(): number;
        emf$isTouchingWater(): boolean;
        emf$getVariableMap(): Internal.Object2FloatOpenHashMap<any>;
        getComponentContainer(): Internal.ComponentContainer;
        hasPermissions($$0: number): boolean;
        getDynamicLightPrevZ(): number;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        pehkui_readScaleNbt(nbt: Internal.CompoundTag_): void;
        setCustomNameVisible($$0: boolean): void;
        isAlliedTo($$0: Internal.Team_): boolean;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>): A;
        setOutOfCamera(value: boolean): void;
        getControllingPassenger(): Internal.LivingEntity;
        getRemainingFireTicks(): number;
        getScriptType(): Internal.ScriptType;
        onlyOpCanSetNbt(): boolean;
        startRiding($$0: Internal.Entity_): boolean;
        saveWithoutId($$0: Internal.CompoundTag_): Internal.CompoundTag;
        getForward(): Vec3d;
        tcdcommons_getCustomData(): Internal.GenericProperties<any>;
        fireImmune(): boolean;
        addMotion($$0: number, $$1: number, $$2: number): void;
        getMaxFallDistance(): number;
        getZ($$0: number): number;
        getId(): number;
        pehkui_isFirstUpdate(): boolean;
        canBeHitByProjectile(): boolean;
        getTicksFrozen(): number;
        wrapWithCondition$kom000$porting_lib_entity$port_lib$captureDrops(level: Internal.Level_, entity: Internal.Entity_): boolean;
        getRecipientsForComponentSync(): Internal.Iterable<any>;
        getRandomX($$0: number): number;
        getDynamicLightZ(): number;
        getEyeY(): number;
        spawnAtLocation($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        pick($$0: number, $$1: number, $$2: boolean): Internal.HitResult;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        fabric_readAttachmentsFromNbt(nbt: Internal.CompoundTag_): void;
        getBoundingBox(): Internal.AABB;
        changeDimension(p_20118_: Internal.ServerLevel_, teleporter: Internal.ITeleporter_): Internal.Entity;
        isInWaterOrRain(): boolean;
        isDescending(): boolean;
        emf$getPitch(): number;
        setItemSlot($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_): void;
        getYHeadRot(): number;
        handler$cbi000$besmirchment$isTeammate(other: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>): void;
        equals($$0: any): boolean;
        getViewYRot($$0: number): number;
        fabric_setCustomTeleportTarget(teleportTarget: Internal.PortalInfo_): void;
        dismountsUnderwater(): boolean;
        frameworkGetDataHolder(): com.mrcrayfish.framework.entity.sync.DataHolder;
        playerTouch($$0: Internal.Player_): void;
        addTag($$0: string): boolean;
        getEyeHeight($$0: Internal.Pose_): number;
        getAddEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>;
        syncPacketPositionCodec($$0: number, $$1: number, $$2: number): void;
        callIsBeingRainedOn(): boolean;
        setDamage($$0: number): void;
        getDisplayOffset(): number;
        getTeam(): Internal.Team;
        shouldRenderAtSqrDistance($$0: number): boolean;
        getAttachedOrSet<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        damageSources(): Internal.DamageSources;
        removeAttached<A>(type: Internal.AttachmentType_<A>): A;
        setTicksFrozen($$0: number): void;
        recreateFromPacket($$0: Internal.ClientboundAddEntityPacket_): void;
        getMyRidingOffset(): number;
        dismountTo($$0: number, $$1: number, $$2: number): void;
        setDeltaMovement($$0: Vec3d_): void;
        getLeashOffset($$0: number): Vec3d;
        etf$getEntityKey(): string;
        etf$getPose(): Internal.Pose;
        hasCustomName(): boolean;
        captureDrops(): Internal.Collection<any>;
        isCulled(): boolean;
        isLiving(): boolean;
        isGlowing(): boolean;
        getX(): number;
        isVehicle(): boolean;
        static transfer(original: Internal.AttachmentTarget_, target: Internal.AttachmentTarget_, isDeath: boolean): void;
        etf$getOptifineId(): number;
        dynamicLightWorld(): Internal.Level;
        getLeashOffset(): Vec3d;
        resetDynamicLight(): void;
        isAttackable(): boolean;
        spawnAtLocation($$0: Internal.ItemStack_): Internal.ItemEntity;
        getMaxSpeedOnRail(): number;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        thunderHit($$0: Internal.ServerLevel_, $$1: Internal.LightningBolt_): void;
        setIsInPowderSnow($$0: boolean): void;
        etf$distanceTo(entity: Internal.Entity_): number;
        doEnchantDamageEffects($$0: Internal.LivingEntity_, $$1: Internal.Entity_): void;
        setCustomName($$0: net.minecraft.network.chat.Component_): void;
        getSlot($$0: number): Internal.SlotAccess;
        lambdynlights$scheduleTrackedChunksRebuild(renderer: Internal.LevelRenderer_): void;
        "deserializeNBT(net.minecraft.nbt.CompoundTag)"(nbt: Internal.CompoundTag_): void;
        emf$isInLava(): boolean;
        pehkui_constructScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        handler$hak000$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        getTeamId(): string;
        stopSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isUnderWater(): boolean;
        stopRiding(): void;
        isCustomNameVisible(): boolean;
        isSupportedBy($$0: BlockPos_): boolean;
        getPistonPushReaction(): Internal.PushReaction;
        getX($$0: number): number;
        lookAt($$0: Internal.EntityAnchorArgument$Anchor_, $$1: Vec3d_): void;
        getLuminance(): number;
        callUnsetRemoved(): void;
        getSelfAndPassengers(): Internal.Stream<any>;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        getDeltaMovement(): Vec3d;
        collide($$0: Vec3d_): Vec3d;
        getMotionX(): number;
        "onSyncedDataUpdated(java.util.List)"($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        hasPassenger($$0: Internal.Entity_): boolean;
        be_getTravelerState(): Internal.TravelerState;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        hasIndirectPassenger($$0: Internal.Entity_): boolean;
        getDynamicLightX(): number;
        getEntityData(): Internal.SynchedEntityData;
        setSecondsOnFire($$0: number): void;
        moveTo($$0: number, $$1: number, $$2: number): void;
        emf$getZ(): number;
        "getDisplayName()"(): net.minecraft.network.chat.Component;
        handleInsidePortal($$0: BlockPos_): void;
        setMotion($$0: number, $$1: number, $$2: number): void;
        playSound($$0: Internal.SoundEvent_): void;
        absMoveTo($$0: number, $$1: number, $$2: number): void;
        isOnRails(): boolean;
        getAttachedOrThrow<A>(type: Internal.AttachmentType_<A>): A;
        handler$ikg000$lithium$tryShortcutFluidPushing(tag: Internal.TagKey_<any>, speed: number, cir: Internal.CallbackInfoReturnable_<any>, box: Internal.AABB_, x1: number, x2: number, y1: number, y2: number, z1: number, z2: number, zero: number): void;
        handler$hak000$gobber2$setFrozenTicks(frozenTicks: number, ci: Internal.CallbackInfo_): void;
        restoreFrom($$0: Internal.Entity_): void;
        markFusionRecomputeModels(): void;
        getDimensionChangingDelay(): number;
        isPeacefulCreature(): boolean;
        setOnGround($$0: boolean): void;
        emf$getYaw(): number;
        handler$cbi000$besmirchment$getScoreboardTeam(cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDynamicLuminance(): number;
        setPos($$0: number, $$1: number, $$2: number): void;
        setYaw($$0: number): void;
        getPickRadius(): number;
        notify(): void;
        getVehicle(): Internal.Entity;
        isEffectiveAi(): boolean;
        handler$kom000$porting_lib_entity$port_lib$startRiding(entity: Internal.Entity_, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        startRiding($$0: Internal.Entity_, $$1: boolean): boolean;
        getStringUuid(): string;
        isRemoved(): boolean;
        emf$isSneaking(): boolean;
        setSwimming($$0: boolean): void;
        teleportToWithTicket($$0: number, $$1: number, $$2: number): void;
        fillCrashReportCategory($$0: Internal.CrashReportCategory_): void;
        getRotationVector(): Internal.Vec2;
        refreshDimensions(): void;
        pehkui_writeScaleNbt(nbt: Internal.CompoundTag_): Internal.CompoundTag;
        self(): Internal.Entity;
        etf$getBlockY(): number;
        isSprinting(): boolean;
        "spawnAtLocation(net.minecraft.world.level.ItemLike)"($$0: Internal.ItemLike_): Internal.ItemEntity;
        getMotionY(): number;
        canCollideWith($$0: Internal.Entity_): boolean;
        setLuminance(luminance: number): void;
        setShiftKeyDown($$0: boolean): void;
        getEyePosition($$0: number): Vec3d;
        getPassengers(): Internal.EntityArrayList;
        getBlockExplosionResistance($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.FluidState_, $$5: number): number;
        handler$ldh000$puzzleslib$spawnAtLocation(stack: Internal.ItemStack_, offsetY: number, callback: Internal.CallbackInfoReturnable_<any>, itemEntity: Internal.ItemEntity_): void;
        port_lib$getMaxSpeed(): number;
        getZ(): number;
        canSpawnSprintParticle(): boolean;
        "moveTo(net.minecraft.core.BlockPos,float,float)"($$0: BlockPos_, $$1: number, $$2: number): void;
        teleportTo($$0: number, $$1: number, $$2: number): void;
        handler$zbk000$porting_lib_base$port_lib$spawnSprintParticle(ci: Internal.CallbackInfo_, pos: BlockPos_, state: Internal.BlockState_): void;
        getServer(): Internal.MinecraftServer;
        moveRelative($$0: number, $$1: Vec3d_): void;
        getFirstPassenger(): Internal.Entity;
        saveAsPassenger($$0: Internal.CompoundTag_): boolean;
        static gatherClosestChunks(chunks: Internal.LongSet_, x: number, y: number, z: number): void;
        handler$kom000$porting_lib_entity$afterSave(nbt: Internal.CompoundTag_, cir: Internal.CallbackInfoReturnable_<any>): void;
        interact($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        setHurtDir($$0: number): void;
        getDismountLocationForPassenger($$0: Internal.LivingEntity_): Vec3d;
        checkSlowFallDistance(): void;
        getSoundSource(): Internal.SoundSource;
        setFabricBalmData(tag: Internal.CompoundTag_): void;
        removeAfterChangingDimensions(): void;
        getPose(): Internal.Pose;
        touchingUnloadedChunk(): boolean;
        getHurtDir(): number;
        getLookAngle(): Vec3d;
        setPositionAndRotation($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        emf$isOnFire(): boolean;
        getMotionZ(): number;
        etf$getUuid(): Internal.UUID;
        removeVehicle(): void;
        isInvisible(): boolean;
        shouldFusionRecomputeModel(layerIndex: number): boolean;
        is($$0: Internal.Entity_): boolean;
        setZ(z: number): void;
        ejectPassengers(): void;
        getY(): number;
        deserializeNBT(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        updateDynamicLightPreviousCoordinates(): void;
        getProfile(): Internal.GameProfile;
        static setViewScale($$0: number): void;
        emf$isAlive(): boolean;
        setLevelCallback($$0: Internal.EntityInLevelCallback_): void;
        showVehicleHealth(): boolean;
        getDistance(pos: BlockPos_): number;
        playSound($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        emf$getVelocity(): Vec3d;
        setCustomDisplay($$0: boolean): void;
        getCurrentRailPos(): BlockPos;
        etf$isBlockEntity(): boolean;
        shouldUpdateDynamicLight(): boolean;
        startSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isOnScoreboardTeam(teamId: string): boolean;
        isPushedByFluid(): boolean;
        localvar$bbb000$architectury$modifyLevelCallback_setLevelCallback(callback: Internal.EntityInLevelCallback_): Internal.EntityInLevelCallback;
        position(): Vec3d;
        setTimeout(): void;
        displayFireAnimation(): boolean;
        turn($$0: number, $$1: number): void;
        isOutOfCamera(): boolean;
        getAirSupply(): number;
        getRopeHoldPosition($$0: number): Vec3d;
        copyPosition($$0: Internal.Entity_): void;
        "hasPassenger(net.minecraft.world.entity.Entity)"($$0: Internal.Entity_): boolean;
        etf$canBeBright(): boolean;
        isCrouching(): boolean;
        moveTo($$0: BlockPos_, $$1: number, $$2: number): void;
        isPlayer(): boolean;
        isAnimal(): boolean;
        getMotionDirection(): Internal.Direction;
        "handler$fgd000$fabric-dimensions-v1$getTeleportTarget"(destination: Internal.ServerLevel_, cir: Internal.CallbackInfoReturnable_<any>): void;
        canBeCollidedWith(): boolean;
        asComponentProvider(): Internal.ComponentProvider;
        setY(y: number): void;
        getFeetBlockState(): Internal.BlockState;
        lavaHurt(): void;
        handleDamageEvent($$0: DamageSource_): void;
        getFabricBalmData(): Internal.CompoundTag;
        canChangeDimensions(): boolean;
        getChangeListener(): Internal.EntityInLevelCallback;
        static tickEntity(entity: Internal.Entity_): void;
        getCommandSenderWorld(): Internal.Level;
        positionRider($$0: Internal.Entity_): void;
        baseTick(): void;
        broadcastToPlayer($$0: Internal.ServerPlayer_): boolean;
        changeDimension($$0: Internal.ServerLevel_): Internal.Entity;
        setSharedFlag($$0: number, $$1: boolean): void;
        handler$kom000$porting_lib_entity$afterLoad(nbt: Internal.CompoundTag_, ci: Internal.CallbackInfo_): void;
        getCustomName(): net.minecraft.network.chat.Component;
        getClass(): typeof any;
        pehkui_shouldIgnoreScaleNbt(): boolean;
        isMoving(): boolean;
        isVisuallySwimming(): boolean;
        getMaxAirSupply(): number;
        attack(hp: number): void;
        dynamicLightTick(): void;
        getFacing(): Internal.Direction;
        emf$isWet(): boolean;
        hasCustomDisplay(): boolean;
        "hasPassenger(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.Entity>): boolean;
        getDimensions($$0: Internal.Pose_): Internal.EntityDimensions;
        isPassengerOfSameVehicle($$0: Internal.Entity_): boolean;
        invokeGetLeashOffset(): Vec3d;
        getBoundingBoxForCulling(): Internal.AABB;
        isSwimming(): boolean;
        mayInteract($$0: Internal.Level_, $$1: BlockPos_): boolean;
        static collideBoundingBox(entity: Internal.Entity_, movement: Vec3d_, entityBoundingBox: Internal.AABB_, world: Internal.Level_, collisions: Internal.List_<any>): Vec3d;
        setSprinting($$0: boolean): void;
        getDynamicLightLevel(): Internal.Level;
        setPortalCooldown(): void;
        setX(x: number): void;
        trackingPosition(): Vec3d;
        getNameTagOffsetY(): number;
        setDisplayOffset($$0: number): void;
        isPrimed(): boolean;
        isInvulnerable(): boolean;
        isInLava(): boolean;
        isInWater(): boolean;
        getPortalWaitTime(): number;
        awardKillScore($$0: Internal.Entity_, $$1: number, $$2: DamageSource_): void;
        getBlockStateOn(): Internal.BlockState;
        getFluidHeightLoosely(tag: Internal.TagKey_<any>): number;
        getFluidJumpThreshold(): number;
        unsetRemoved(): void;
        "setPositionAndRotation(double,double,double,float,float)"($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        isInvisibleTo($$0: Internal.Player_): boolean;
        pehkui_getScaleCache(): Internal.ScaleData[];
        setFusionModel(layerIndex: number, model: Internal.Triple_<any, any, any>): void;
        setAirSupply($$0: number): void;
        getOnPos(): BlockPos;
        getRootVehicle(): Internal.Entity;
        etf$getWorld(): Internal.Level;
        save($$0: Internal.CompoundTag_): boolean;
        pehkui_getScales(): Internal.Map<any, any>;
        isNoGravity(): boolean;
        getDefaultDisplayOffset(): number;
        etf$getNbt(): Internal.CompoundTag;
        acceptsFailure(): boolean;
        etf$getBlockPos(): BlockPos;
        pehkui_setShouldIgnoreScaleNbt(ignore: boolean): void;
        setOnGroundWithKnownMovement($$0: boolean, $$1: Vec3d_): void;
        setOldPosAndRot(): void;
        emf$getY(): number;
        handler$kom000$porting_lib_entity$port_lib$entityInit(entityType: Internal.EntityType_<any>, world: Internal.Level_, ci: Internal.CallbackInfo_): void;
        bookshelf$createHoverEvent(): Internal.HoverEvent;
        isFree($$0: number, $$1: number, $$2: number): boolean;
        updateSwimming(): void;
        "moveTo(double,double,double)"($$0: number, $$1: number, $$2: number): void;
        setRemainingFireTicks($$0: number): void;
        getCachedFeetBlockState(): Internal.BlockState;
        shouldInformAdmins(): boolean;
        rideTick(): void;
        emf$age(): number;
        etf$hasCustomName(): boolean;
        /**
         * @deprecated
        */
        getOnPosLegacy(): BlockPos;
        setPos($$0: Vec3d_): void;
        wait(): void;
        getUuid(): Internal.UUID;
        spawn(): void;
        teleportTo($$0: Internal.ServerLevel_, $$1: number, $$2: number, $$3: number, $$4: Internal.Set_<Internal.RelativeMovement>, $$5: number, $$6: number): boolean;
        handler$kom000$porting_lib_entity$port_lib$removeRidingEntity(ci: Internal.CallbackInfo_): void;
        etf$getCustomName(): net.minecraft.network.chat.Component;
        captureDrops(value: Internal.Collection_<any>): Internal.Collection<any>;
        fabric_writeAttachmentsToNbt(nbt: Internal.CompoundTag_): void;
        shouldShowName(): boolean;
        setSilent($$0: boolean): void;
        getArmorSlots(): Internal.Iterable<Internal.ItemStack>;
        hasExactlyOnePlayerPassenger(): boolean;
        kill(): void;
        isOnPortalCooldown(): boolean;
        animateHurt($$0: number): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        handler$kom000$porting_lib_entity$port_lib$onEntityRemove(reason: Internal.Entity$RemovalReason_, ci: Internal.CallbackInfo_): void;
        lambdynlights$setTrackedLitChunkPos(trackedLitChunkPos: Internal.LongSet_): void;
        static createMinecart($$0: Internal.Level_, $$1: number, $$2: number, $$3: number, $$4: Internal.AbstractMinecart$Type_): Internal.AbstractMinecart;
        callGetEyeHeight(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        setPitch($$0: number): void;
        setPosRaw($$0: number, $$1: number, $$2: number): void;
        handleEntityEvent($$0: number): void;
        isAlwaysTicking(): boolean;
        interactAt($$0: Internal.Player_, $$1: Vec3d_, $$2: Internal.InteractionHand_): Internal.InteractionResult;
        emf$getX(): number;
        deserializeNBT(arg0: Internal.Tag_): void;
        puzzleslib$acceptCapturedDrops(capturedDrops: Internal.Collection_<any>): Internal.Collection<any>;
        handler$hak000$gobber2$gobberIsFireImmune(cir: Internal.CallbackInfoReturnable_<any>): void;
        lerpTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: boolean): void;
        onPassengerTurned($$0: Internal.Entity_): void;
        modifyReturnValue$zhe000$additionalentityattributes$getMaxAir(original: number): number;
        spawnAtLocation($$0: Internal.ItemLike_): Internal.ItemEntity;
        emf$hasPassengers(): boolean;
        serializeNBT(): Internal.CompoundTag;
        setAttached(type: Internal.AttachmentType_<any>, value: any): any;
        getBbWidth(): number;
        splitIntoDynamicLightEntries(): Internal.Stream<Internal.SpatialLookupEntry>;
        port_lib$getEntityString(): string;
        addDeltaMovement($$0: Vec3d_): void;
        pehkui_setOnGround(onGround: boolean): void;
        lithiumOnBlockCacheDeleted(): void;
        "spawnAtLocation(net.minecraft.world.level.ItemLike,int)"($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        setInvulnerable($$0: boolean): void;
        "getName()"(): net.minecraft.network.chat.Component;
        push($$0: Internal.Entity_): void;
        emf$hasVehicle(): boolean;
        mirror($$0: Internal.Mirror_): number;
        activateMinecart($$0: number, $$1: number, $$2: number, $$3: boolean): void;
        static port_lib$collideWithShapes(vec3: Vec3d_, aABB: Internal.AABB_, list: Internal.List_<Internal.VoxelShape>): Vec3d;
        getTicksRequiredToFreeze(): number;
        getDynamicLightPrevY(): number;
        maxUpStep(): number;
        setGlowing($$0: boolean): void;
        load($$0: Internal.CompoundTag_): void;
        isAlive(): boolean;
        emf$prevZ(): number;
        getBbHeight(): number;
        getUsername(): string;
        move($$0: Internal.MoverType_, $$1: Vec3d_): void;
        getTags(): Internal.Set<string>;
        getViewVector($$0: number): Vec3d;
        lithiumOnBlockCacheSet(newState: Internal.BlockState_): void;
        isPickable(): boolean;
        setYHeadRot($$0: number): void;
        getMinecartType(): Internal.AbstractMinecart$Type;
        hasControllingPassenger(): boolean;
        moveMinecartOnRail(pos: BlockPos_): void;
        closerThan($$0: Internal.Entity_, $$1: number, $$2: number): boolean;
        absMoveTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        getCustomData(): Internal.CompoundTag;
        getPickResult(): Internal.ItemStack;
        getPercentFrozen(): number;
        getRandomY(): number;
        setPortalCooldown($$0: number): void;
        getDisplayName(): net.minecraft.network.chat.Component;
        shouldBlockExplode($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: number): boolean;
        hasGlowingTag(): boolean;
        emf$isInvisible(): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        emf$isSprinting(): boolean;
        getDynamicLightPrevX(): number;
        shouldBeSaved(): boolean;
        fabric_hasPersistentAttachments(): boolean;
        getViewXRot($$0: number): number;
        canRiderInteract(): boolean;
        destroy($$0: DamageSource_): void;
        fabric_getAttachments(): Internal.Map<any, any>;
        removeTag($$0: string): boolean;
        setPose($$0: Internal.Pose_): void;
        getFluidHeight($$0: Internal.TagKey_<Internal.Fluid>): number;
        getEntityType(): Internal.EntityType<any>;
        isWaterCreature(): boolean;
        pehkui_getScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        toString(): string;
        notifyAll(): void;
        getPassengersRidingOffset(): number;
        etf$getScoreboardTeam(): Internal.Team;
        getFuse(): number;
        distanceToEntitySqr($$0: Internal.Entity_): number;
        handler$ldh000$puzzleslib$removeVehicle(callback: Internal.CallbackInfo_): void;
        "getServer()"(): Internal.MinecraftServer;
        isFrame(): boolean;
        isPushable(): boolean;
        setYBodyRot($$0: number): void;
        discard(): void;
        onClientRemoval(): void;
        "handler$mhe000$step-height-entity-attribute$getStepHeight"(cir: Internal.CallbackInfoReturnable_<any>): void;
        sendSystemMessage($$0: net.minecraft.network.chat.Component_): void;
        acceptsSuccess(): boolean;
        getDistance(x: number, y: number, z: number): number;
        setMotionY(y: number): void;
        setNoGravity($$0: boolean): void;
        getAttached(type: Internal.AttachmentType_<any>): any;
        getIndirectPassengers(): Internal.Iterable<any>;
        setRotation(yaw: number, pitch: number): void;
        isDynamicLightEnabled(): boolean;
        handler$ldh000$puzzleslib$startRiding(vehicle: Internal.Entity_, force: boolean, callback: Internal.CallbackInfoReturnable_<any>): void;
        createCommandSourceStack(): Internal.CommandSourceStack;
        isControlledByLocalInstance(): boolean;
        isMonster(): boolean;
        pehkui_setShouldSyncScales(sync: boolean): void;
        setLastDynamicLuminance(luminance: number): void;
        setId($$0: number): void;
        onSyncedDataUpdated($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        getHorizontalFacing(): Internal.Direction;
        getType(): string;
        getLightProbePosition($$0: number): Vec3d;
        getDefaultDisplayBlockState(): Internal.BlockState;
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        onAboveBubbleCol($$0: boolean): void;
        emf$prevX(): number;
        "playSound(net.minecraft.sounds.SoundEvent,float,float)"($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        toComponentPacket(key: Internal.ComponentKey_<any>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        isPassenger(): boolean;
        hasPose($$0: Internal.Pose_): boolean;
        checkDespawn(): void;
        pehkui_shouldSyncScales(): boolean;
        isEyeInFluid($$0: Internal.TagKey_<Internal.Fluid>): boolean;
        isInvulnerableTo($$0: DamageSource_): boolean;
        makeStuckInBlock($$0: Internal.BlockState_, $$1: Vec3d_): void;
        getAttachedOrGet<A>(type: Internal.AttachmentType_<A>, defaultValue: Internal.Supplier_<A>): A;
        skipAttackInteraction($$0: Internal.Entity_): boolean;
        lerpMotion($$0: number, $$1: number, $$2: number): void;
        shouldRender($$0: number, $$1: number, $$2: number): boolean;
        onSyncedDataUpdated($$0: Internal.EntityDataAccessor_<any>): void;
        getHurtTime(): number;
        lerpHeadTo($$0: number, $$1: number): void;
        handler$bia000$axiom$onTurn(d: number, e: number, ci: Internal.CallbackInfo_): void;
        static getViewScale(): number;
        setMotionX(x: number): void;
        getHandSlots(): Internal.Iterable<Internal.ItemStack>;
        distanceToEntity($$0: Internal.Entity_): number;
        getVisualRotationYInDegrees(): number;
        wait(arg0: number, arg1: number): void;
        isDiscrete(): boolean;
        getTeamColor(): number;
        setNbt(nbt: Internal.CompoundTag_): void;
        lithiumSetClimbingMobCachingSectionUpdateBehavior(listening: boolean): void;
        unRide(): void;
        getLevel(): Internal.Level;
        "spawnAtLocation(net.minecraft.world.item.ItemStack)"($$0: Internal.ItemStack_): Internal.ItemEntity;
        lambdynlights$getTrackedLitChunkPos(): Internal.LongSet;
        extinguish(): void;
        setDynamicLightEnabled(enabled: boolean): void;
        updateDynamicGameEventListener($$0: Internal.BiConsumer_<Internal.DynamicGameEventListener<any>, Internal.ServerLevel>): void;
        moveTo($$0: Vec3d_): void;
        isColliding($$0: BlockPos_, $$1: Internal.BlockState_): boolean;
        "onSyncedDataUpdated(net.minecraft.network.syncher.EntityDataAccessor)"($$0: Internal.EntityDataAccessor_<any>): void;
        emf$prevY(): number;
        extinguishFire(): void;
        lambdynlights$updateDynamicLight(renderer: Internal.LevelRenderer_): boolean;
        tell(message: net.minecraft.network.chat.Component_): void;
        static port_lib$collideWithShapes$porting_lib_accessors_$md$424943$0(arg0: Vec3d_, arg1: Internal.AABB_, arg2: Internal.List_<any>): Vec3d;
        isForcedVisible(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number): boolean;
        getDistanceSq(pos: BlockPos_): number;
        emf$getTypeString(): string;
        killedEntity($$0: Internal.ServerLevel_, $$1: Internal.LivingEntity_): boolean;
        getAttachedOrElse<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        isFreezing(): boolean;
        invokeWillHitBlockAt(arg0: BlockPos_): boolean;
        isFullyFrozen(): boolean;
        runCommand(command: string): number;
        setDisplayBlockState($$0: Internal.BlockState_): void;
        setSharedFlagOnFire($$0: boolean): void;
        get inWall(): boolean
        get allSlots(): Internal.Iterable<Internal.ItemStack>
        get blockZ(): number
        get suppressingBounce(): boolean
        set hurtTime($$0: number)
        get silent(): boolean
        set culled(value: boolean)
        get pitch(): number
        get onFire(): boolean
        get positionCodec(): Internal.VecDeltaCodec
        get passengersAndSelf(): Internal.Stream<any>
        set maxUpStep($$0: number)
        get shiftKeyDown(): boolean
        set UUID($$0: Internal.UUID_)
        get visuallyCrawling(): boolean
        set motionZ(z: number)
        get dropItem(): Internal.Item
        get blockY(): number
        get isInsideStructureTracker(): Internal.IsInsideStructureTracker
        get spectator(): boolean
        get inWaterOrBubble(): boolean
        get persistentData(): Internal.CompoundTag
        get portalCooldown(): number
        get item(): Internal.ItemStack
        set removed($$0: Internal.Entity$RemovalReason_)
        get inWaterRainOrBubble(): boolean
        get removalReason(): Internal.Entity$RemovalReason
        get ignoringBlockTriggers(): boolean
        get damage(): number
        get steppingCarefully(): boolean
        set boundingBox($$0: Internal.AABB_)
        get ambientCreature(): boolean
        get displayBlockState(): Internal.BlockState
        get blockX(): number
        /**
         * @deprecated
        */
        get lightLevelDependentMagicValue(): number
        get encodeId(): string
        get block(): Internal.BlockContainerJS
        get nbt(): Internal.CompoundTag
        set invisible($$0: boolean)
        get name(): net.minecraft.network.chat.Component
        get dynamicLightY(): number
        get controlledVehicle(): Internal.Entity
        get eyePosition(): Vec3d
        get eyeHeight(): number
        get yaw(): number
        get componentContainer(): Internal.ComponentContainer
        get dynamicLightPrevZ(): number
        set customNameVisible($$0: boolean)
        set outOfCamera(value: boolean)
        get controllingPassenger(): Internal.LivingEntity
        get remainingFireTicks(): number
        get scriptType(): Internal.ScriptType
        get forward(): Vec3d
        get maxFallDistance(): number
        get id(): number
        get ticksFrozen(): number
        get recipientsForComponentSync(): Internal.Iterable<any>
        get dynamicLightZ(): number
        get eyeY(): number
        set statusMessage(message: net.minecraft.network.chat.Component_)
        get boundingBox(): Internal.AABB
        get inWaterOrRain(): boolean
        get descending(): boolean
        get YHeadRot(): number
        get addEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>
        set damage($$0: number)
        get displayOffset(): number
        get team(): Internal.Team
        set ticksFrozen($$0: number)
        get myRidingOffset(): number
        set deltaMovement($$0: Vec3d_)
        get culled(): boolean
        get living(): boolean
        get glowing(): boolean
        get x(): number
        get vehicle(): boolean
        get leashOffset(): Vec3d
        get attackable(): boolean
        get maxSpeedOnRail(): number
        set isInPowderSnow($$0: boolean)
        set customName($$0: net.minecraft.network.chat.Component_)
        get teamId(): string
        get underWater(): boolean
        get customNameVisible(): boolean
        get pistonPushReaction(): Internal.PushReaction
        get luminance(): number
        get selfAndPassengers(): Internal.Stream<any>
        get deltaMovement(): Vec3d
        get motionX(): number
        get dynamicLightX(): number
        get entityData(): Internal.SynchedEntityData
        set secondsOnFire($$0: number)
        get "displayName()"(): net.minecraft.network.chat.Component
        get onRails(): boolean
        get dimensionChangingDelay(): number
        get peacefulCreature(): boolean
        set onGround($$0: boolean)
        get lastDynamicLuminance(): number
        set yaw($$0: number)
        get pickRadius(): number
        get vehicle(): Internal.Entity
        get effectiveAi(): boolean
        get stringUuid(): string
        get removed(): boolean
        set swimming($$0: boolean)
        get rotationVector(): Internal.Vec2
        get sprinting(): boolean
        get motionY(): number
        set luminance(luminance: number)
        set shiftKeyDown($$0: boolean)
        get passengers(): Internal.EntityArrayList
        get z(): number
        get server(): Internal.MinecraftServer
        get firstPassenger(): Internal.Entity
        set hurtDir($$0: number)
        get soundSource(): Internal.SoundSource
        set fabricBalmData(tag: Internal.CompoundTag_)
        get pose(): Internal.Pose
        get hurtDir(): number
        get lookAngle(): Vec3d
        get motionZ(): number
        get invisible(): boolean
        set z(z: number)
        get y(): number
        get profile(): Internal.GameProfile
        set viewScale($$0: number)
        set levelCallback($$0: Internal.EntityInLevelCallback_)
        set customDisplay($$0: boolean)
        get currentRailPos(): BlockPos
        get pushedByFluid(): boolean
        get outOfCamera(): boolean
        get airSupply(): number
        get crouching(): boolean
        get player(): boolean
        get animal(): boolean
        get motionDirection(): Internal.Direction
        set y(y: number)
        get feetBlockState(): Internal.BlockState
        get fabricBalmData(): Internal.CompoundTag
        get changeListener(): Internal.EntityInLevelCallback
        get commandSenderWorld(): Internal.Level
        get customName(): net.minecraft.network.chat.Component
        get class(): typeof any
        get moving(): boolean
        get visuallySwimming(): boolean
        get maxAirSupply(): number
        get facing(): Internal.Direction
        get boundingBoxForCulling(): Internal.AABB
        get swimming(): boolean
        set sprinting($$0: boolean)
        get dynamicLightLevel(): Internal.Level
        set x(x: number)
        get nameTagOffsetY(): number
        set displayOffset($$0: number)
        get primed(): boolean
        get invulnerable(): boolean
        get inLava(): boolean
        get inWater(): boolean
        get portalWaitTime(): number
        get blockStateOn(): Internal.BlockState
        get fluidJumpThreshold(): number
        set airSupply($$0: number)
        get onPos(): BlockPos
        get rootVehicle(): Internal.Entity
        get noGravity(): boolean
        get defaultDisplayOffset(): number
        set remainingFireTicks($$0: number)
        get cachedFeetBlockState(): Internal.BlockState
        /**
         * @deprecated
        */
        get onPosLegacy(): BlockPos
        set pos($$0: Vec3d_)
        get uuid(): Internal.UUID
        set silent($$0: boolean)
        get armorSlots(): Internal.Iterable<Internal.ItemStack>
        get onPortalCooldown(): boolean
        set pitch($$0: number)
        get alwaysTicking(): boolean
        get bbWidth(): number
        set invulnerable($$0: boolean)
        get "name()"(): net.minecraft.network.chat.Component
        get ticksRequiredToFreeze(): number
        get dynamicLightPrevY(): number
        set glowing($$0: boolean)
        get alive(): boolean
        get bbHeight(): number
        get username(): string
        get tags(): Internal.Set<string>
        get pickable(): boolean
        set YHeadRot($$0: number)
        get minecartType(): Internal.AbstractMinecart$Type
        get customData(): Internal.CompoundTag
        get pickResult(): Internal.ItemStack
        get percentFrozen(): number
        get randomY(): number
        set portalCooldown($$0: number)
        get displayName(): net.minecraft.network.chat.Component
        set position(block: Internal.BlockContainerJS_)
        get dynamicLightPrevX(): number
        set pose($$0: Internal.Pose_)
        get entityType(): Internal.EntityType<any>
        get waterCreature(): boolean
        get passengersRidingOffset(): number
        get fuse(): number
        get "server()"(): Internal.MinecraftServer
        get frame(): boolean
        get pushable(): boolean
        set YBodyRot($$0: number)
        set motionY(y: number)
        set noGravity($$0: boolean)
        get indirectPassengers(): Internal.Iterable<any>
        get dynamicLightEnabled(): boolean
        get controlledByLocalInstance(): boolean
        get monster(): boolean
        set lastDynamicLuminance(luminance: number)
        set id($$0: number)
        get horizontalFacing(): Internal.Direction
        get type(): string
        get defaultDisplayBlockState(): Internal.BlockState
        get passenger(): boolean
        get hurtTime(): number
        get viewScale(): number
        set motionX(x: number)
        get handSlots(): Internal.Iterable<Internal.ItemStack>
        get visualRotationYInDegrees(): number
        get discrete(): boolean
        get teamColor(): number
        set nbt(nbt: Internal.CompoundTag_)
        get level(): Internal.Level
        set dynamicLightEnabled(enabled: boolean)
        get forcedVisible(): boolean
        get freezing(): boolean
        get fullyFrozen(): boolean
        set displayBlockState($$0: Internal.BlockState_)
        set sharedFlagOnFire($$0: boolean)
    }
    type MinecartTNT_ = MinecartTNT;
    class RuleBasedBlockStateProvider extends Internal.Record {
        constructor($$0: Internal.BlockStateProvider_, $$1: Internal.List_<Internal.RuleBasedBlockStateProvider$Rule>)
        getClass(): typeof any;
        getState($$0: Internal.WorldGenLevel_, $$1: Internal.RandomSource_, $$2: BlockPos_): Internal.BlockState;
        toString(): string;
        notifyAll(): void;
        fallback(): Internal.BlockStateProvider;
        notify(): void;
        static "simple(net.minecraft.world.level.levelgen.feature.stateproviders.BlockStateProvider)"($$0: Internal.BlockStateProvider_): Internal.RuleBasedBlockStateProvider;
        static simple($$0: Internal.BlockStateProvider_): Internal.RuleBasedBlockStateProvider;
        rules(): Internal.List<Internal.RuleBasedBlockStateProvider$Rule>;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        static "simple(net.minecraft.world.level.block.Block)"($$0: Internal.Block_): Internal.RuleBasedBlockStateProvider;
        static simple($$0: Internal.Block_): Internal.RuleBasedBlockStateProvider;
        wait(): void;
        wait(arg0: number): void;
        equals($$0: any): boolean;
        get class(): typeof any
        static readonly CODEC: Internal.Codec<Internal.RuleBasedBlockStateProvider>;
    }
    type RuleBasedBlockStateProvider_ = RuleBasedBlockStateProvider;
    interface AmbiguityConsumer <S> {
        abstract ambiguous(arg0: Internal.CommandNode_<S>, arg1: Internal.CommandNode_<S>, arg2: Internal.CommandNode_<S>, arg3: Internal.Collection_<string>): void;
        (arg0: Internal.CommandNode<S>, arg1: Internal.CommandNode<S>, arg2: Internal.CommandNode<S>, arg3: Internal.Collection<string>): void;
    }
    type AmbiguityConsumer_<S> = ((arg0: Internal.CommandNode<S>, arg1: Internal.CommandNode<S>, arg2: Internal.CommandNode<S>, arg3: Internal.Collection<string>)=> void) | AmbiguityConsumer<S>;
    class ContainerEvent extends Internal.ComponentEvent {
        constructor(arg0: Internal.Component_, arg1: number, arg2: Internal.Component_)
        getClass(): typeof any;
        toString(): string;
        paramString(): string;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getChild(): Internal.Component;
        hashCode(): number;
        wait(): void;
        getContainer(): Internal.Container;
        wait(arg0: number): void;
        setSource(arg0: any): void;
        getComponent(): Internal.Component;
        getSource(): any;
        equals(arg0: any): boolean;
        getID(): number;
        get class(): typeof any
        get child(): Internal.Component
        get container(): Internal.Container
        set source(arg0: any)
        get component(): Internal.Component
        get source(): any
        get ID(): number
        static readonly CONTAINER_FIRST: (300) & (number);
        static readonly CONTAINER_LAST: (301) & (number);
        static readonly COMPONENT_ADDED: (300) & (number);
        static readonly COMPONENT_REMOVED: (301) & (number);
    }
    type ContainerEvent_ = ContainerEvent;
    abstract class StructurePoolElement {
        abstract getBoundingBox(arg0: Internal.StructureTemplateManager_, arg1: BlockPos_, arg2: Internal.Rotation_): Internal.BoundingBox;
        getClass(): typeof any;
        notify(): void;
        getGroundLevelDelta(): number;
        wait(arg0: number, arg1: number): void;
        abstract place(arg0: Internal.StructureTemplateManager_, arg1: Internal.WorldGenLevel_, arg2: Internal.StructureManager_, arg3: Internal.ChunkGenerator_, arg4: BlockPos_, arg5: BlockPos_, arg6: Internal.Rotation_, arg7: Internal.BoundingBox_, arg8: Internal.RandomSource_, arg9: boolean): boolean;
        static list($$0: Internal.List_<Internal.Function<Internal.StructureTemplatePool$Projection, Internal.StructurePoolElement>>): Internal.Function<Internal.StructureTemplatePool$Projection, Internal.ListPoolElement>;
        getProjection(): Internal.StructureTemplatePool$Projection;
        static empty(): Internal.Function<Internal.StructureTemplatePool$Projection, Internal.EmptyPoolElement>;
        static legacy($$0: string, $$1: Internal.Holder_<Internal.StructureProcessorList>): Internal.Function<Internal.StructureTemplatePool$Projection, Internal.LegacySinglePoolElement>;
        abstract getType(): Internal.StructurePoolElementType<any>;
        toString(): string;
        abstract getShuffledJigsawBlocks(arg0: Internal.StructureTemplateManager_, arg1: BlockPos_, arg2: Internal.Rotation_, arg3: Internal.RandomSource_): Internal.List<Internal.StructureTemplate$StructureBlockInfo>;
        static single($$0: string): Internal.Function<Internal.StructureTemplatePool$Projection, Internal.SinglePoolElement>;
        notifyAll(): void;
        handleDataMarker($$0: Internal.LevelAccessor_, $$1: Internal.StructureTemplate$StructureBlockInfo_, $$2: BlockPos_, $$3: Internal.Rotation_, $$4: Internal.RandomSource_, $$5: Internal.BoundingBox_): void;
        abstract getSize(arg0: Internal.StructureTemplateManager_, arg1: Internal.Rotation_): Vec3i;
        setProjection($$0: Internal.StructureTemplatePool$Projection_): this;
        hashCode(): number;
        static legacy($$0: string): Internal.Function<Internal.StructureTemplatePool$Projection, Internal.LegacySinglePoolElement>;
        wait(): void;
        wait(arg0: number): void;
        static single($$0: string, $$1: Internal.Holder_<Internal.StructureProcessorList>): Internal.Function<Internal.StructureTemplatePool$Projection, Internal.SinglePoolElement>;
        equals(arg0: any): boolean;
        static feature($$0: Internal.Holder_<Internal.PlacedFeature>): Internal.Function<Internal.StructureTemplatePool$Projection, Internal.FeaturePoolElement>;
        get class(): typeof any
        get groundLevelDelta(): number
        get projection(): Internal.StructureTemplatePool$Projection
        get type(): Internal.StructurePoolElementType<any>
        set projection($$0: Internal.StructureTemplatePool$Projection_)
        static CODEC: Internal.Codec<Internal.StructurePoolElement>;
    }
    type StructurePoolElement_ = StructurePoolElement;
    interface ParticleEmitting {
        access$particleChance$jd($this: Internal.ParticleEmitting_): number;
        particleChance(): number;
        emitParticles(world: Internal.Level_, client: Internal.Minecraft_, user: Internal.LivingEntity_): void;
        access$sendParticlePacket$jd($this: Internal.ParticleEmitting_, user: Internal.ServerPlayer_, id: string): void;
        access$emitParticles$jd($this: Internal.ParticleEmitting_, world: Internal.Level_, client: Internal.Minecraft_, user: Internal.LivingEntity_): void;
        sendParticlePacket(user: Internal.ServerPlayer_, id: string): void;
        readonly Companion: (Internal.ParticleEmitting$Companion) & (Internal.ParticleEmitting$Companion);
    }
    type ParticleEmitting_ = ParticleEmitting;
    class RuinedPortalStructure extends Internal.Structure {
        constructor($$0: Internal.Structure$StructureSettings_, $$1: any_)
        constructor($$0: Internal.Structure$StructureSettings_, $$1: Internal.List_<any>)
        static simpleCodec<S extends Internal.Structure>($$0: Internal.Function_<Internal.Structure$StructureSettings, S>): Internal.Codec<S>;
        getClass(): typeof any;
        generate($$0: Internal.RegistryAccess_, $$1: Internal.ChunkGenerator_, $$2: Internal.BiomeSource_, $$3: Internal.RandomState_, $$4: Internal.StructureTemplateManager_, $$5: number, $$6: Internal.ChunkPos_, $$7: number, $$8: Internal.LevelHeightAccessor_, $$9: Internal.Predicate_<Internal.Holder<Internal.Biome>>): Internal.StructureStart;
        toString(): string;
        biomes(): Internal.HolderSet<Internal.Biome>;
        findValidGenerationPoint($$0: Internal.Structure$GenerationContext_): Optional<Internal.Structure$GenerationStub>;
        spawnOverrides(): Internal.Map<Internal.MobCategory, Internal.StructureSpawnOverride>;
        step(): Internal.GenerationStep$Decoration;
        notifyAll(): void;
        notify(): void;
        terrainAdaptation(): Internal.TerrainAdjustment;
        wait(arg0: number, arg1: number): void;
        adjustBoundingBox($$0: Internal.BoundingBox_): Internal.BoundingBox;
        hashCode(): number;
        type(): Internal.StructureType<any>;
        static settingsCodec<S extends Internal.Structure>($$0: Internal.RecordCodecBuilder$Instance_<S>): Internal.RecordCodecBuilder<S, Internal.Structure$StructureSettings>;
        method_38676($$0: Internal.Structure$GenerationContext_): Optional<Internal.Structure$GenerationStub>;
        structurify$setStructureIdentifier(structureSetIdentifier: ResourceLocation_): void;
        wait(): void;
        structurify$getStructureIdentifier(): ResourceLocation;
        wait(arg0: number): void;
        afterPlace($$0: Internal.WorldGenLevel_, $$1: Internal.StructureManager_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: Internal.BoundingBox_, $$5: Internal.ChunkPos_, $$6: Internal.PiecesContainer_): void;
        equals(arg0: any): boolean;
        setStructureBiomes(newBiomes: Internal.HolderSet_<any>): void;
        get class(): typeof any
        set tingsCodec($$0: Internal.RecordCodecBuilder$Instance_<S>)
        set structureBiomes(newBiomes: Internal.HolderSet_<any>)
        static readonly CODEC: Internal.Codec<Internal.RuinedPortalStructure>;
    }
    type RuinedPortalStructure_ = RuinedPortalStructure;
    class ClientboundSetChunkCacheCenterPacket implements Internal.Packet<Internal.ClientGamePacketListener> {
        constructor($$0: number, $$1: number)
        constructor($$0: Internal.FriendlyByteBuf_)
        handle(arg0: Internal.PacketListener_): void;
        getClass(): typeof any;
        write($$0: Internal.FriendlyByteBuf_): void;
        getX(): number;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        isSkippable(): boolean;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        wait(): void;
        handle($$0: Internal.ClientGamePacketListener_): void;
        wait(arg0: number): void;
        "handle(net.minecraft.network.protocol.game.ClientGamePacketListener)"($$0: Internal.ClientGamePacketListener_): void;
        getZ(): number;
        equals(arg0: any): boolean;
        "handle(net.minecraft.network.PacketListener)"(arg0: Internal.PacketListener_): void;
        get class(): typeof any
        get x(): number
        get skippable(): boolean
        get z(): number
    }
    type ClientboundSetChunkCacheCenterPacket_ = ClientboundSetChunkCacheCenterPacket;
    class ListCodec <A> implements Internal.Codec<Internal.List<A>> {
        constructor(arg0: Internal.Codec_<A>)
        optionalFieldOf(arg0: string, arg1: Internal.List_<A>): Internal.MapCodec<Internal.List<A>>;
        dispatchMap<E>(arg0: Internal.Function_<E, Internal.List<A>>, arg1: Internal.Function_<Internal.List<A>, Internal.Codec<E>>): Internal.MapCodec<E>;
        static empty<A>(): Internal.MapEncoder<A>;
        static "of(com.mojang.serialization.MapEncoder,com.mojang.serialization.MapDecoder)"<A>(arg0: Internal.MapEncoder_<A>, arg1: Internal.MapDecoder_<A>): Internal.MapCodec<A>;
        static error<A>(arg0: string): Internal.Encoder<A>;
        static unit<A>(arg0: Internal.Supplier_<A>): Internal.Codec<A>;
        notify(): void;
        parse<T>(arg0: Internal.Dynamic_<T>): Internal.DataResult<Internal.List<A>>;
        orElse(arg0: Internal.UnaryOperator_<string>, arg1: Internal.List_<A>): Internal.Codec<Internal.List<A>>;
        static floatRange(arg0: number, arg1: number): Internal.Codec<number>;
        comap<B>(arg0: Internal.Function_<B, Internal.List<A>>): Internal.Encoder<B>;
        "encode(java.util.List,com.mojang.serialization.DynamicOps,java.lang.Object)"<T>(arg0: Internal.List_<A>, arg1: Internal.DynamicOps_<T>, arg2: T): Internal.DataResult<T>;
        withLifecycle(arg0: Internal.Lifecycle_): Internal.Codec<Internal.List<A>>;
        decode<T>(arg0: Internal.Dynamic_<T>): Internal.DataResult<com.mojang.datafixers.util.Pair<Internal.List<A>, T>>;
        stable(): Internal.Codec<Internal.List<A>>;
        static "of(com.mojang.serialization.Encoder,com.mojang.serialization.Decoder)"<A>(arg0: Internal.Encoder_<A>, arg1: Internal.Decoder_<A>): Internal.Codec<A>;
        partialDispatch<E>(arg0: string, arg1: Internal.Function_<E, Internal.DataResult<Internal.List<A>>>, arg2: Internal.Function_<Internal.List<A>, Internal.DataResult<Internal.Codec<E>>>): Internal.Codec<E>;
        static ofBoxed<A>(arg0: Internal.Decoder$Boxed_<A>): Internal.Decoder<A>;
        dispatch<E>(arg0: string, arg1: Internal.Function_<E, Internal.List<A>>, arg2: Internal.Function_<Internal.List<A>, Internal.Codec<E>>): Internal.Codec<E>;
        encode<T>(arg0: Internal.List_<A>, arg1: Internal.DynamicOps_<T>, arg2: T): Internal.DataResult<T>;
        orElseGet(arg0: Internal.UnaryOperator_<string>, arg1: Internal.Supplier_<Internal.List<A>>): Internal.Codec<Internal.List<A>>;
        optionalFieldOf(arg0: string, arg1: Internal.List_<A>, arg2: Internal.Lifecycle_): Internal.MapCodec<Internal.List<A>>;
        "orElseGet(java.util.function.UnaryOperator,java.util.function.Supplier)"(arg0: Internal.UnaryOperator_<string>, arg1: Internal.Supplier_<Internal.List<A>>): Internal.Codec<Internal.List<A>>;
        map<B>(arg0: Internal.Function_<Internal.List<A>, B>): Internal.Decoder<B>;
        terminal(): Internal.Decoder$Terminal<Internal.List<A>>;
        flatMap<B>(arg0: Internal.Function_<Internal.List<A>, Internal.DataResult<B>>): Internal.Decoder<B>;
        "orElse(java.util.function.UnaryOperator,java.util.List)"(arg0: Internal.UnaryOperator_<string>, arg1: Internal.List_<A>): Internal.Codec<Internal.List<A>>;
        static intRange(arg0: number, arg1: number): Internal.Codec<number>;
        static unit<A>(arg0: A): Internal.Codec<A>;
        comapFlatMap<S>(arg0: Internal.Function_<Internal.List<A>, Internal.DataResult<S>>, arg1: Internal.Function_<S, Internal.List<A>>): Internal.Codec<S>;
        encodeStart<T>(arg0: Internal.DynamicOps_<T>, arg1: Internal.List_<A>): Internal.DataResult<T>;
        simple(): Internal.Decoder$Simple<Internal.List<A>>;
        static pair<F, S>(arg0: Internal.Codec_<F>, arg1: Internal.Codec_<S>): Internal.Codec<com.mojang.datafixers.util.Pair<F, S>>;
        static either<F, S>(arg0: Internal.Codec_<F>, arg1: Internal.Codec_<S>): Internal.Codec<Internal.Either<F, S>>;
        static "unit(java.lang.Object)"<A>(arg0: A): Internal.Codec<A>;
        static checkRange<N extends number & Internal.Comparable<N>>(arg0: N, arg1: N): Internal.Function<N, Internal.DataResult<N>>;
        fieldOf(arg0: string): Internal.MapCodec<Internal.List<A>>;
        wait(): void;
        flatComapMap<S>(arg0: Internal.Function_<Internal.List<A>, S>, arg1: Internal.Function_<S, Internal.DataResult<Internal.List<A>>>): Internal.Codec<S>;
        flatXmap<S>(arg0: Internal.Function_<Internal.List<A>, Internal.DataResult<S>>, arg1: Internal.Function_<S, Internal.DataResult<Internal.List<A>>>): Internal.Codec<S>;
        static unboundedMap<K, V>(arg0: Internal.Codec_<K>, arg1: Internal.Codec_<V>): Internal.UnboundedMapCodec<K, V>;
        optionalFieldOf(arg0: string): Internal.MapCodec<Optional<Internal.List<A>>>;
        mapResult(arg0: Internal.Codec$ResultFunction_<Internal.List<A>>): Internal.Codec<Internal.List<A>>;
        static of<A>(arg0: Internal.Encoder_<A>, arg1: Internal.Decoder_<A>, arg2: string): Internal.Codec<A>;
        getClass(): typeof any;
        parse<T>(arg0: Internal.DynamicOps_<T>, arg1: T): Internal.DataResult<Internal.List<A>>;
        "encode(java.lang.Object,com.mojang.serialization.DynamicOps,java.lang.Object)"(arg0: any, arg1: Internal.DynamicOps_<any>, arg2: any): Internal.DataResult<any>;
        dispatch<E>(arg0: Internal.Function_<E, Internal.List<A>>, arg1: Internal.Function_<Internal.List<A>, Internal.Codec<E>>): Internal.Codec<E>;
        orElse(arg0: Internal.List_<A>): Internal.Codec<Internal.List<A>>;
        static ofSimple<A>(arg0: Internal.Decoder$Simple_<A>): Internal.Decoder<A>;
        static mapEither<F, S>(arg0: Internal.MapCodec_<F>, arg1: Internal.MapCodec_<S>): Internal.MapCodec<Internal.Either<F, S>>;
        optionalFieldOf(arg0: string, arg1: Internal.Lifecycle_, arg2: Internal.List_<A>, arg3: Internal.Lifecycle_): Internal.MapCodec<Internal.List<A>>;
        static doubleRange(arg0: number, arg1: number): Internal.Codec<number>;
        static optionalField<F>(arg0: string, arg1: Internal.Codec_<F>): Internal.MapCodec<Optional<F>>;
        static simpleMap<K, V>(arg0: Internal.Codec_<K>, arg1: Internal.Codec_<V>, arg2: Internal.Keyable_): Internal.SimpleMapCodec<K, V>;
        static ofTerminal<A>(arg0: Internal.Decoder$Terminal_<A>): Internal.Decoder<A>;
        encode(arg0: any, arg1: Internal.DynamicOps_<any>, arg2: any): Internal.DataResult<any>;
        wait(arg0: number, arg1: number): void;
        deprecated(arg0: number): Internal.Codec<Internal.List<A>>;
        static list<E>(arg0: Internal.Codec_<E>): Internal.Codec<Internal.List<E>>;
        flatComap<B>(arg0: Internal.Function_<B, Internal.DataResult<Internal.List<A>>>): Internal.Encoder<B>;
        "orElse(java.util.function.Consumer,java.util.List)"(arg0: Internal.Consumer_<string>, arg1: Internal.List_<A>): Internal.Codec<Internal.List<A>>;
        dispatchMap<E>(arg0: string, arg1: Internal.Function_<E, Internal.List<A>>, arg2: Internal.Function_<Internal.List<A>, Internal.Codec<E>>): Internal.MapCodec<E>;
        boxed(): Internal.Decoder$Boxed<Internal.List<A>>;
        promotePartial(arg0: Internal.Consumer_<any>): Internal.Decoder<any>;
        orElseGet(arg0: Internal.Supplier_<Internal.List<A>>): Internal.Codec<Internal.List<A>>;
        static of<A>(arg0: Internal.MapEncoder_<A>, arg1: Internal.MapDecoder_<A>): Internal.MapCodec<A>;
        static "unit(java.util.function.Supplier)"<A>(arg0: Internal.Supplier_<A>): Internal.Codec<A>;
        toString(): string;
        orElseGet(arg0: Internal.Consumer_<string>, arg1: Internal.Supplier_<Internal.List<A>>): Internal.Codec<Internal.List<A>>;
        static of<A>(arg0: Internal.Encoder_<A>, arg1: Internal.Decoder_<A>): Internal.Codec<A>;
        notifyAll(): void;
        listOf(): Internal.Codec<Internal.List<Internal.List<A>>>;
        orElse(arg0: Internal.Consumer_<string>, arg1: Internal.List_<A>): Internal.Codec<Internal.List<A>>;
        xmap<S>(arg0: Internal.Function_<Internal.List<A>, S>, arg1: Internal.Function_<S, Internal.List<A>>): Internal.Codec<S>;
        static compoundList<K, V>(arg0: Internal.Codec_<K>, arg1: Internal.Codec_<V>): Internal.Codec<Internal.List<com.mojang.datafixers.util.Pair<K, V>>>;
        static of<A>(arg0: Internal.MapEncoder_<A>, arg1: Internal.MapDecoder_<A>, arg2: Internal.Supplier_<string>): Internal.MapCodec<A>;
        "orElseGet(java.util.function.Consumer,java.util.function.Supplier)"(arg0: Internal.Consumer_<string>, arg1: Internal.Supplier_<Internal.List<A>>): Internal.Codec<Internal.List<A>>;
        decode<T>(arg0: Internal.DynamicOps_<T>, arg1: T): Internal.DataResult<com.mojang.datafixers.util.Pair<Internal.List<A>, T>>;
        hashCode(): number;
        wait(arg0: number): void;
        static "of(com.mojang.serialization.MapEncoder,com.mojang.serialization.MapDecoder,java.util.function.Supplier)"<A>(arg0: Internal.MapEncoder_<A>, arg1: Internal.MapDecoder_<A>, arg2: Internal.Supplier_<string>): Internal.MapCodec<A>;
        static "of(com.mojang.serialization.Encoder,com.mojang.serialization.Decoder,java.lang.String)"<A>(arg0: Internal.Encoder_<A>, arg1: Internal.Decoder_<A>, arg2: string): Internal.Codec<A>;
        equals(arg0: any): boolean;
        static mapPair<F, S>(arg0: Internal.MapCodec_<F>, arg1: Internal.MapCodec_<S>): Internal.MapCodec<com.mojang.datafixers.util.Pair<F, S>>;
        dispatchStable<E>(arg0: Internal.Function_<E, Internal.List<A>>, arg1: Internal.Function_<Internal.List<A>, Internal.Codec<E>>): Internal.Codec<E>;
        get class(): typeof any
    }
    type ListCodec_<A> = ListCodec<A>;
    interface DisplayAccessor {
        getDataTransformationInterpolationDurationId(): Internal.EntityDataAccessor<number>;
        get dataTransformationInterpolationDurationId(): Internal.EntityDataAccessor<number>
    }
    type DisplayAccessor_ = DisplayAccessor;
    class RecipeComponentValue <T> implements Internal.Map$Entry<Internal.RecipeKey<T>, T>, Internal.WrappedJS {
        constructor(key: Internal.RecipeKey_<T>, index: number)
        getClass(): typeof any;
        getKey(): any;
        shouldWrite(): boolean;
        isInput(recipe: Internal.RecipeJS_, match: Internal.ReplacementMatch_): boolean;
        getIndex(): number;
        copy(): this;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        write(): void;
        static copyOf<K, V>(arg0: Internal.Map$Entry_<K, V>): Internal.Map$Entry<K, V>;
        replaceOutput(recipe: Internal.RecipeJS_, match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): boolean;
        static comparingByKey<K extends Internal.Comparable<any>, V>(): Comparator<Internal.Map$Entry<K, V>>;
        static comparingByKey<K, V>(arg0: Comparator_<K>): Comparator<Internal.Map$Entry<K, V>>;
        toString(): string;
        replaceInput(recipe: Internal.RecipeJS_, match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): boolean;
        isOutput(recipe: Internal.RecipeJS_, match: Internal.ReplacementMatch_): boolean;
        notifyAll(): void;
        checkEmpty(): string;
        static comparingByValue<K, V extends Internal.Comparable<any>>(): Comparator<Internal.Map$Entry<K, V>>;
        hashCode(): number;
        wait(): void;
        getValue(): T;
        wait(arg0: number): void;
        static comparingByValue<K, V>(arg0: Comparator_<V>): Comparator<Internal.Map$Entry<K, V>>;
        equals(obj: any): boolean;
        setValue(newValue: T): T;
        get class(): typeof any
        get key(): any
        get index(): number
        get value(): T
        set value(newValue: T)
        readonly index: number;
        value: T;
        readonly key: Internal.RecipeKey<T>;
        static readonly EMPTY_ARRAY: Internal.RecipeComponentValue<any>[];
        write: boolean;
    }
    type RecipeComponentValue_<T> = RecipeComponentValue<T>;
    class GetClientGroupsCallbackJS <IN, OUT> {
        constructor(accessor: Internal.Accessor_<any>, groups: Internal.List_<Internal.ViewGroup<IN>>)
        getClass(): typeof any;
        addGroup(groupBuilderConsumer: Internal.Consumer_<Internal.ViewGroupBuilder<OUT>>): this;
        getAccessor(): Internal.Accessor<any>;
        toString(): string;
        "addGroup(java.util.List)"(group: Internal.List_<OUT>): this;
        notifyAll(): void;
        "addGroup(pie.ilikepiefoo.compat.jade.builder.ViewGroupBuilder)"(group: Internal.ViewGroupBuilder_<OUT>): this;
        getResultingGroups(): Internal.List<Internal.ViewGroupBuilder<OUT>>;
        getGroups(): Internal.List<Internal.ViewGroup<IN>>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        addGroups(groups: Internal.List_<Internal.ViewGroup<OUT>>): this;
        hashCode(): number;
        wait(): void;
        addGroup(group: Internal.List_<OUT>): this;
        clearGroups(): this;
        wait(arg0: number): void;
        addGroup(group: Internal.ViewGroupBuilder_<OUT>): this;
        equals(arg0: any): boolean;
        "addGroup(snownee.jade.api.view.ViewGroup)"(group: Internal.ViewGroup_<OUT>): this;
        "addGroup(java.util.function.Consumer)"(groupBuilderConsumer: Internal.Consumer_<Internal.ViewGroupBuilder<OUT>>): this;
        addGroup(group: Internal.ViewGroup_<OUT>): this;
        get class(): typeof any
        get accessor(): Internal.Accessor<any>
        get resultingGroups(): Internal.List<Internal.ViewGroupBuilder<OUT>>
        get groups(): Internal.List<Internal.ViewGroup<IN>>
        readonly accessor: Internal.Accessor<any>;
        readonly groups: Internal.List<Internal.ViewGroup<IN>>;
    }
    type GetClientGroupsCallbackJS_<IN, OUT> = GetClientGroupsCallbackJS<IN, OUT>;
    abstract class AbstractCandleBlock extends Internal.Block {
        /**
         * @deprecated
        */
        getOcclusionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        /**
         * @deprecated
        */
        getSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        axiom$customPickBlockStack(): Internal.ItemStack;
        getSoundType($$0: Internal.BlockState_): SoundType;
        /**
         * @deprecated
        */
        getVisualShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        handler$efo000$collective$Block_playerDestroy(level: Internal.Level_, player: Internal.Player_, blockPos: BlockPos_, blockState: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number, $$5: number): void;
        /**
         * @deprecated
        */
        randomTick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: Internal.BlockEntity_): void;
        static canSupportRigidBlock($$0: Internal.BlockGetter_, $$1: BlockPos_): boolean;
        static popResource($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.ItemStack_): void;
        setRandomTickCallback(callback: Internal.Consumer_<any>): void;
        getDescriptionId(): string;
        stepOn($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Entity_): void;
        fallOn($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: BlockPos_, $$3: Internal.Entity_, $$4: number): void;
        getSettings(): Internal.BlockBehaviour$Properties;
        getExplosionResistance(): number;
        asItem(): Internal.Item;
        /**
         * @deprecated
        */
        triggerEvent($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: number, $$4: number): boolean;
        getTypeData(): Internal.CompoundTag;
        setFriction(arg0: number): void;
        /**
         * @deprecated
        */
        getRenderShape($$0: Internal.BlockState_): Internal.RenderShape;
        canCull(): boolean;
        customShapeUpdate(blockState: Internal.CustomBlockState_, levelReader: Internal.LevelReader_, blockPos: BlockPos_): Internal.CustomBlockState;
        getJumpFactor(): number;
        getSpeedFactor(): number;
        static canSupportCenter($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        skipRendering($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getLightBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        playerDestroy($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.BlockEntity_, $$5: Internal.ItemStack_): void;
        shouldAttemptToCull(state: Internal.BlockState_): boolean;
        isPossibleToRespawnInThis($$0: Internal.BlockState_): boolean;
        getCustomStateForPlacement(blockPlaceContext: Internal.BlockPlaceContext_): Internal.CustomBlockState;
        /**
         * @deprecated
        */
        getDirectSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        getProperties(): Internal.BlockBehaviour$Properties;
        playerWillDestroy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Player_): void;
        getClass(): typeof any;
        getMaxVerticalOffset(): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.item.context.BlockPlaceContext)"($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        useShapeForLightOcclusion($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        getDrops($$0: Internal.BlockState_, $$1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getStateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>;
        /**
         * @deprecated
        */
        entityInside($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Entity_): void;
        setBlockBuilder(b: Internal.BlockBuilder_): void;
        handler$ldb000$puzzleslib$playerDestroy$0(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        setRequiresTool(v: boolean): void;
        setSpeedFactor(arg0: number): void;
        axiom$getPossibleCustomStates(): Internal.List<any>;
        setExplosionResistance(arg0: number): void;
        toString(): string;
        port_lib$popExperience(arg0: Internal.ServerLevel_, arg1: BlockPos_, arg2: number): void;
        notifyAll(): void;
        static isLit($$0: Internal.BlockState_): boolean;
        getToolModifiedState(state: Internal.BlockState_, world: Internal.Level_, pos: BlockPos_, player: Internal.Player_, stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): Internal.BlockState;
        getId(): string;
        getLootTable(): ResourceLocation;
        puzzleslib$setItem(arg0: Internal.Item_): void;
        axiom$translationKey(): string;
        /**
         * @deprecated
        */
        getInteractionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        propagatesSkylightDown($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        setPlacedBy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.LivingEntity_, $$4: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        onPlace($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Block>;
        static popResourceFromFace($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.ItemStack_): void;
        getFriction(): number;
        handlePrecipitation($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Biome$Precipitation_): void;
        /**
         * @deprecated
        */
        hasAnalogOutputSignal($$0: Internal.BlockState_): boolean;
        wait(arg0: number): void;
        /**
         * @deprecated
        */
        getFluidState($$0: Internal.BlockState_): Internal.FluidState;
        handler$koh000$porting_lib_entity$getDestroySpeed(blockState: Internal.BlockState_, player: Internal.Player_, blockGetter: Internal.BlockGetter_, pos: BlockPos_, cir: Internal.CallbackInfoReturnable_<any>): void;
        /**
         * @deprecated
        */
        getAnalogOutputSignal($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): number;
        handler$efo000$collective$Block_setPlacedBy(level: Internal.Level_, blockPos: BlockPos_, blockState: Internal.BlockState_, livingEntity: Internal.LivingEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        tick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        supportsExternalFaceHiding(state: Internal.BlockState_): boolean;
        handler$ldb000$puzzleslib$playerDestroy$1(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        notify(): void;
        axiom$asItemStack(): Internal.ItemStack;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        neighborChanged($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Block_, $$4: BlockPos_, $$5: boolean): void;
        handler$zhd000$additionalentityattributes$additionalEntityAttributes$saveBreakingPlayer(world: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, stack: Internal.ItemStack_, callbackInfo: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        getBlockSupportShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        canSustainPlant(state: Internal.BlockState_, world: Internal.BlockGetter_, pos: BlockPos_, facing: Internal.Direction_, plantable: Internal.IPlantable_): boolean;
        /**
         * @deprecated
        */
        isCollisionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static isFaceFull($$0: Internal.VoxelShape_, $$1: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getMenuProvider($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): Internal.MenuProvider;
        static byItem($$0: Internal.Item_): Internal.Block;
        static updateFromNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        updateIndirectNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: number, $$4: number): void;
        destroy($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): void;
        handler$fdc000$everycomp$addSimpleFastECdrops(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, cir: Internal.CallbackInfoReturnable_<any>, resId: ResourceLocation_, lootParams: Internal.LootParams_, serverLevel: Internal.ServerLevel_, lootTable: Internal.LootTable_): void;
        getToolModifiedState(state: Internal.BlockState_, context: Internal.UseOnContext_, toolAction: Internal.ToolAction_, simulate: boolean): Internal.BlockState;
        /**
         * @deprecated
        */
        use($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_, $$4: Internal.InteractionHand_, $$5: Internal.BlockHitResult_): Internal.InteractionResult;
        setLightEmission(v: number): void;
        doNormalInteractions(): boolean;
        setJumpFactor(arg0: number): void;
        /**
         * @deprecated
        */
        canSurvive($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): void;
        /**
         * @deprecated
        */
        getShadeBrightness($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        getAppearance(state: Internal.BlockState_, renderView: Internal.BlockAndTintGetter_, pos: BlockPos_, side: Internal.Direction_, sourceState: Internal.BlockState_, sourcePos: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        getCollisionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        setDestroySpeed(v: number): void;
        defaultBlockState(): Internal.BlockState;
        usesCustomShouldDrawFace(state: Internal.BlockState_): boolean;
        getStateForPlacement($$0: Internal.BlockPlaceContext_): Internal.BlockState;
        cantCullAgainst(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        arch$holder(): Internal.Holder<Internal.Block>;
        wait(): void;
        static extinguish($$0: Internal.Player_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): void;
        getCloneItemStack($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        hasDynamicShape(): boolean;
        getMaxHorizontalOffset(): number;
        /**
         * @deprecated
        */
        getDestroyProgress($$0: Internal.BlockState_, $$1: Internal.Player_, $$2: Internal.BlockGetter_, $$3: BlockPos_): number;
        /**
         * @deprecated
        */
        getSeed($$0: Internal.BlockState_, $$1: BlockPos_): number;
        defaultDestroyTime(): number;
        dropFromExplosion($$0: Internal.Explosion_): boolean;
        /**
         * @deprecated
        */
        updateShape($$0: Internal.BlockState_, $$1: Internal.Direction_, $$2: Internal.BlockState_, $$3: Internal.LevelAccessor_, $$4: BlockPos_, $$5: BlockPos_): Internal.BlockState;
        isRandomlyTicking($$0: Internal.BlockState_): boolean;
        static isShapeFullBlock(shape: Internal.VoxelShape_): boolean;
        withPropertiesOf($$0: Internal.BlockState_): Internal.BlockState;
        static isExceptionForConnection($$0: Internal.BlockState_): boolean;
        setIsRandomlyTicking(arg0: boolean): void;
        hidesNeighborFace(level: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, neighborState: Internal.BlockState_, dir: Internal.Direction_): boolean;
        onTreeGrow(state: Internal.BlockState_, level: Internal.LevelReader_, placeFunction: Internal.BiConsumer_<BlockPos, Internal.BlockState>, randomSource: Internal.RandomSource_, pos: BlockPos_, config: Internal.TreeConfiguration_): boolean;
        /**
         * @deprecated
        */
        rotate($$0: Internal.BlockState_, $$1: Internal.Rotation_): Internal.BlockState;
        defaultMapColor(): Internal.MapColor;
        getStateAtViewpoint(state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_, viewpoint: Vec3d_): Internal.BlockState;
        wait(arg0: number, arg1: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.BlockGetter_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        setNameKey(arg0: string): void;
        static box($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): Internal.VoxelShape;
        /**
         * @deprecated
        */
        mirror($$0: Internal.BlockState_, $$1: Internal.Mirror_): Internal.BlockState;
        wasExploded($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Explosion_): void;
        getName(): Internal.MutableComponent;
        updateEntityAfterFallOn($$0: Internal.BlockGetter_, $$1: Internal.Entity_): void;
        animateTick($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        customShouldDrawFace(view: Internal.BlockGetter_, thisState: Internal.BlockState_, sideState: Internal.BlockState_, thisPos: BlockPos_, sidePos: BlockPos_, side: Internal.Direction_): Optional<boolean>;
        axiom$getResourceLocation(): ResourceLocation;
        arch$registryName(): ResourceLocation;
        axiom$getProperties(): Internal.Collection<any>;
        getBlockBuilder(): Internal.BlockBuilder;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        isSignalSource($$0: Internal.BlockState_): boolean;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number): void;
        /**
         * @deprecated
        */
        attack($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): void;
        /**
         * @deprecated
        */
        getShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        shouldAttemptToCull(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        onProjectileHit($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockHitResult_, $$3: Internal.Projectile_): void;
        static stateById($$0: number): Internal.BlockState;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): Internal.List<Internal.ItemStack>;
        requiredFeatures(): Internal.FeatureFlagSet;
        hashCode(): number;
        axiom$defaultCustomState(): Internal.CustomBlockState;
        setCanCull(canCull: boolean): void;
        /**
         * @deprecated
        */
        isOcclusionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static getId($$0: Internal.BlockState_): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.material.Fluid)"($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        static pushEntitiesUp($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        isPathfindable($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.PathComputationType_): boolean;
        setSoundType(arg0: SoundType_): void;
        handler$cef000$betterend$be_getDroppedStacks(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, info: Internal.CallbackInfoReturnable_<any>): void;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_): Internal.List<Internal.ItemStack>;
        /**
         * @deprecated
        */
        onRemove($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        cantCullAgainst(state: Internal.BlockState_): boolean;
        setHasCollision(arg0: boolean): void;
        static shouldRenderFace($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_, $$4: BlockPos_): boolean;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        spawnAfterBreak($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.ItemStack_, $$4: boolean): void;
        set randomTickCallback(callback: Internal.Consumer_<any>)
        get descriptionId(): string
        get settings(): Internal.BlockBehaviour$Properties
        get explosionResistance(): number
        get typeData(): Internal.CompoundTag
        set friction(arg0: number)
        get jumpFactor(): number
        get speedFactor(): number
        get properties(): Internal.BlockBehaviour$Properties
        get class(): typeof any
        get maxVerticalOffset(): number
        get stateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>
        set blockBuilder(b: Internal.BlockBuilder_)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        set speedFactor(arg0: number)
        set explosionResistance(arg0: number)
        get id(): string
        get lootTable(): ResourceLocation
        get friction(): number
        set lightEmission(v: number)
        set jumpFactor(arg0: number)
        set destroySpeed(v: number)
        get maxHorizontalOffset(): number
        set isRandomlyTicking(arg0: boolean)
        set nameKey(arg0: string)
        get name(): Internal.MutableComponent
        get blockBuilder(): Internal.BlockBuilder
        get idLocation(): ResourceLocation
        get mod(): string
        set canCull(canCull: boolean)
        set soundType(arg0: SoundType_)
        set hasCollision(arg0: boolean)
        static readonly LIGHT_PER_CANDLE: (3) & (number);
        static readonly LIT: (Internal.BooleanProperty) & (Internal.BooleanProperty);
    }
    type AbstractCandleBlock_ = AbstractCandleBlock;
    class PotionTrade extends Internal.TransformableTrade<Internal.PotionTrade> {
        constructor(inputs: TradeItem_[])
        getClass(): typeof any;
        priceMultiplier(priceMultiplier: number): this;
        onlyBrewablePotion(): this;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getOffer(entity: Internal.Entity_, random: Internal.RandomSource_): Internal.MerchantOffer;
        hashCode(): number;
        maxUses(maxUses: number): this;
        item(item: Internal.Item_): this;
        wait(): void;
        potions(...potions: Internal.Potion_[]): this;
        noBrewablePotion(): this;
        wait(arg0: number): void;
        createOffer(entity: Internal.Entity_, random: Internal.RandomSource_): Internal.MerchantOffer;
        transform(offerModification: Internal.TransformableTrade$Transformer_): this;
        equals(arg0: any): boolean;
        villagerExperience(villagerExperience: number): this;
        get class(): typeof any
    }
    type PotionTrade_ = PotionTrade;
    class SleepingEventJS extends Internal.LivingEntityEventJS {
        constructor(entity: Internal.LivingEntity_, sleepingPos: BlockPos_)
        getClass(): typeof any;
        /**
         * Stops the event with default exit value. Execution will be stopped **immediately**.
         * 
         * `exit` denotes a `default` outcome.
        */
        exit(): any;
        /**
         * Cancels the event with the given exit value. Execution will be stopped **immediately**.
         * 
         * `cancel` denotes a `false` outcome.
        */
        cancel(value: any): any;
        toString(): string;
        static stopHandler(entity: Internal.LivingEntity_, sleepingPos: BlockPos_): void;
        notifyAll(): void;
        /**
         * Stops the event with the given exit value. Execution will be stopped **immediately**.
         * 
         * `exit` denotes a `default` outcome.
        */
        exit(value: any): any;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getLevel(): Internal.Level;
        /**
         * Stops the event with the given exit value. Execution will be stopped **immediately**.
         * 
         * `success` denotes a `true` outcome.
        */
        success(value: any): any;
        getPos(): Internal.BlockContainerJS;
        hashCode(): number;
        getEntity(): Internal.Entity;
        wait(): void;
        /**
         * Cancels the event with default exit value. Execution will be stopped **immediately**.
         * 
         * `cancel` denotes a `false` outcome.
        */
        cancel(): any;
        wait(arg0: number): void;
        getPlayer(): Internal.Player;
        /**
         * Stops the event with default exit value. Execution will be stopped **immediately**.
         * 
         * `success` denotes a `true` outcome.
        */
        success(): any;
        equals(arg0: any): boolean;
        getServer(): Internal.MinecraftServer;
        static startHandler(entity: Internal.LivingEntity_, sleepingPos: BlockPos_): void;
        getSleepingPos(): BlockPos;
        get class(): typeof any
        get level(): Internal.Level
        get pos(): Internal.BlockContainerJS
        get entity(): Internal.Entity
        get player(): Internal.Player
        get server(): Internal.MinecraftServer
        get sleepingPos(): BlockPos
    }
    type SleepingEventJS_ = SleepingEventJS;
    interface NoiseGeneratorSettingsAccess {
        abstract regions_unexplored$setSurfaceRule(arg0: Internal.SurfaceRules$RuleSource_): void;
        (arg0: Internal.SurfaceRules$RuleSource): void;
    }
    type NoiseGeneratorSettingsAccess_ = ((arg0: Internal.SurfaceRules$RuleSource)=> void) | NoiseGeneratorSettingsAccess;
    class RealmsWorldOptions extends Internal.ValueObject {
        constructor($$0: boolean, $$1: boolean, $$2: boolean, $$3: boolean, $$4: number, $$5: boolean, $$6: number, $$7: number, $$8: boolean, $$9: string)
        clone(): any;
        static createDefaults(): Internal.RealmsWorldOptions;
        getClass(): typeof any;
        toString(): string;
        "clone()"(): any;
        setEmpty($$0: boolean): void;
        notifyAll(): void;
        toJson(): string;
        static parse($$0: Internal.JsonObject_): Internal.RealmsWorldOptions;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getSlotName($$0: number): string;
        clone(): this;
        hashCode(): number;
        getDefaultSlotName($$0: number): string;
        wait(): void;
        wait(arg0: number): void;
        static createEmptyDefaults(): Internal.RealmsWorldOptions;
        equals(arg0: any): boolean;
        "clone()"(): this;
        get class(): typeof any
        set empty($$0: boolean)
        readonly difficulty: number;
        readonly commandBlocks: boolean;
        empty: boolean;
        templateImage: string;
        readonly gameMode: number;
        readonly spawnMonsters: boolean;
        readonly forceGameMode: boolean;
        templateId: number;
        readonly spawnAnimals: boolean;
        readonly spawnNPCs: boolean;
        readonly spawnProtection: number;
        readonly pvp: boolean;
    }
    type RealmsWorldOptions_ = RealmsWorldOptions;
    class BlockPlacerItem extends Internal.BlockItem {
        constructor(pBlock: Internal.Block_, pProperties: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        static setBlockEntityData($$0: Internal.ItemStack_, $$1: Internal.BlockEntityType_<any>, $$2: Internal.CompoundTag_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        abstract moonlight$addAdditionalBehavior(arg0: Internal.AdditionalItemPlacement_): void;
        static get(): Internal.BlockPlacerItem;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        modifyReturnValue$bkb000$axiom$canPlace(canPlace: boolean, blockPlaceContext: Internal.BlockPlaceContext_): boolean;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        getFoodProperties(): Internal.FoodProperties;
        canBeHurtBy($$0: DamageSource_): boolean;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        mimicGetPlacementState(pContext: Internal.BlockPlaceContext_, toPlace: Internal.Block_): Internal.BlockState;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        abstract moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        handler$mpi000$tcdcommons$onPlace(context: Internal.BlockPlaceContext_, ci: Internal.CallbackInfoReturnable_<any>): void;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        mimicPlace(pContext: Internal.BlockPlaceContext_, toPlace: Internal.Block_, overrideSound: SoundType_): Internal.InteractionResult;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        abstract moonlight$setClientAnimationExtension(arg0: any): void;
        abstract moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        isEdible(): boolean;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        wrapOperation$bkb000$axiom$place$getPlacementState(instance: Internal.BlockItem_, blockPlaceContext: Internal.BlockPlaceContext_, original: Internal.Operation_<any>): Internal.BlockState;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        static getBlockEntityData($$0: Internal.ItemStack_): Internal.CompoundTag;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        method_7709(pContext: Internal.BlockPlaceContext_, pState: Internal.BlockState_): boolean;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        removeFromBlockToItemMap(blockToItemMap: Internal.Map_<Internal.Block, Internal.Item>, itemIn: Internal.Item_): void;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        static updateCustomBlockEntityTag($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.ItemStack_): boolean;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        place($$0: Internal.BlockPlaceContext_): Internal.InteractionResult;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        getBlock(): Internal.Block;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        updatePlacementContext($$0: Internal.BlockPlaceContext_): Internal.BlockPlaceContext;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        registerBlocks(pBlockToItemMap: Internal.Map_<Internal.Block, Internal.Item>, pItem: Internal.Item_): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        mimicUseOn(pContext: Internal.UseOnContext_, toPlace: Internal.Block_, foodProperties: Internal.FoodProperties_): Internal.InteractionResult;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        puzzleslib$setBlock(arg0: Internal.Block_): void;
        wrapOperation$bkb000$axiom$place$updatePlacementContext(instance: Internal.BlockItem_, blockPlaceContext: Internal.BlockPlaceContext_, original: Internal.Operation_<any>): Internal.BlockPlaceContext;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        get block(): Internal.Block
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type BlockPlacerItem_ = BlockPlacerItem;
    class BendingTrunkPlacer extends Internal.TrunkPlacer {
        constructor($$0: number, $$1: number, $$2: number, $$3: number, $$4: Internal.IntProvider_)
        placeTrunk($$0: Internal.LevelSimulatedReader_, $$1: Internal.BiConsumer_<BlockPos, Internal.BlockState>, $$2: Internal.RandomSource_, $$3: number, $$4: BlockPos_, $$5: Internal.TreeConfiguration_): Internal.List<Internal.FoliagePlacer$FoliageAttachment>;
        getClass(): typeof any;
        hashCode(): number;
        isFree($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        toString(): string;
        getTreeHeight($$0: Internal.RandomSource_): number;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        static readonly CODEC: Internal.Codec<Internal.BendingTrunkPlacer>;
    }
    type BendingTrunkPlacer_ = BendingTrunkPlacer;
    class User {
        constructor($$0: string, $$1: string, $$2: string, $$3: Optional_<string>, $$4: Optional_<string>, $$5: Internal.User$Type_)
        getClass(): typeof any;
        getGameProfile(): Internal.GameProfile;
        getClientId(): Optional<string>;
        toString(): string;
        getSessionId(): string;
        notifyAll(): void;
        getXuid(): Optional<string>;
        notify(): void;
        getUuid(): string;
        wait(arg0: number, arg1: number): void;
        getAccessToken(): string;
        hashCode(): number;
        wait(): void;
        getName(): string;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        getType(): Internal.User$Type;
        getProfileId(): Internal.UUID;
        get class(): typeof any
        get gameProfile(): Internal.GameProfile
        get clientId(): Optional<string>
        get sessionId(): string
        get xuid(): Optional<string>
        get uuid(): string
        get accessToken(): string
        get name(): string
        get type(): Internal.User$Type
        get profileId(): Internal.UUID
    }
    type User_ = User;
    class UnboundedMapCodec <K, V> implements Internal.BaseMapCodec<K, V>, Internal.Codec<Internal.Map<K, V>> {
        constructor(arg0: Internal.Codec_<K>, arg1: Internal.Codec_<V>)
        keyCodec(): Internal.Codec<K>;
        orElseGet(arg0: Internal.Consumer_<string>, arg1: Internal.Supplier_<Internal.Map<K, V>>): Internal.Codec<Internal.Map<K, V>>;
        dispatchStable<E>(arg0: Internal.Function_<E, Internal.Map<K, V>>, arg1: Internal.Function_<Internal.Map<K, V>, Internal.Codec<E>>): Internal.Codec<E>;
        "encode(java.util.Map,com.mojang.serialization.DynamicOps,java.lang.Object)"<T>(arg0: Internal.Map_<K, V>, arg1: Internal.DynamicOps_<T>, arg2: T): Internal.DataResult<T>;
        "orElseGet(java.util.function.UnaryOperator,java.util.function.Supplier)"(arg0: Internal.UnaryOperator_<string>, arg1: Internal.Supplier_<Internal.Map<K, V>>): Internal.Codec<Internal.Map<K, V>>;
        optionalFieldOf(arg0: string, arg1: Internal.Map_<K, V>): Internal.MapCodec<Internal.Map<K, V>>;
        static empty<A>(): Internal.MapEncoder<A>;
        static "of(com.mojang.serialization.MapEncoder,com.mojang.serialization.MapDecoder)"<A>(arg0: Internal.MapEncoder_<A>, arg1: Internal.MapDecoder_<A>): Internal.MapCodec<A>;
        static error<A>(arg0: string): Internal.Encoder<A>;
        deprecated(arg0: number): Internal.Codec<Internal.Map<K, V>>;
        static unit<A>(arg0: Internal.Supplier_<A>): Internal.Codec<A>;
        notify(): void;
        "orElse(java.util.function.UnaryOperator,java.util.Map)"(arg0: Internal.UnaryOperator_<string>, arg1: Internal.Map_<K, V>): Internal.Codec<Internal.Map<K, V>>;
        optionalFieldOf(arg0: string, arg1: Internal.Map_<K, V>, arg2: Internal.Lifecycle_): Internal.MapCodec<Internal.Map<K, V>>;
        static floatRange(arg0: number, arg1: number): Internal.Codec<number>;
        dispatchMap<E>(arg0: Internal.Function_<E, Internal.Map<K, V>>, arg1: Internal.Function_<Internal.Map<K, V>, Internal.Codec<E>>): Internal.MapCodec<E>;
        encode<T>(arg0: Internal.Map_<K, V>, arg1: Internal.DynamicOps_<T>, arg2: Internal.RecordBuilder_<T>): Internal.RecordBuilder<T>;
        partialDispatch<E>(arg0: string, arg1: Internal.Function_<E, Internal.DataResult<Internal.Map<K, V>>>, arg2: Internal.Function_<Internal.Map<K, V>, Internal.DataResult<Internal.Codec<E>>>): Internal.Codec<E>;
        static "of(com.mojang.serialization.Encoder,com.mojang.serialization.Decoder)"<A>(arg0: Internal.Encoder_<A>, arg1: Internal.Decoder_<A>): Internal.Codec<A>;
        static ofBoxed<A>(arg0: Internal.Decoder$Boxed_<A>): Internal.Decoder<A>;
        dispatch<E>(arg0: string, arg1: Internal.Function_<E, Internal.Map<K, V>>, arg2: Internal.Function_<Internal.Map<K, V>, Internal.Codec<E>>): Internal.Codec<E>;
        parse<T>(arg0: Internal.DynamicOps_<T>, arg1: T): Internal.DataResult<Internal.Map<K, V>>;
        map<B>(arg0: Internal.Function_<Internal.Map<K, V>, B>): Internal.Decoder<B>;
        static intRange(arg0: number, arg1: number): Internal.Codec<number>;
        static unit<A>(arg0: A): Internal.Codec<A>;
        dispatchMap<E>(arg0: string, arg1: Internal.Function_<E, Internal.Map<K, V>>, arg2: Internal.Function_<Internal.Map<K, V>, Internal.Codec<E>>): Internal.MapCodec<E>;
        flatComap<B>(arg0: Internal.Function_<B, Internal.DataResult<Internal.Map<K, V>>>): Internal.Encoder<B>;
        decode<T>(arg0: Internal.Dynamic_<T>): Internal.DataResult<com.mojang.datafixers.util.Pair<Internal.Map<K, V>, T>>;
        static pair<F, S>(arg0: Internal.Codec_<F>, arg1: Internal.Codec_<S>): Internal.Codec<com.mojang.datafixers.util.Pair<F, S>>;
        elementCodec(): Internal.Codec<V>;
        static either<F, S>(arg0: Internal.Codec_<F>, arg1: Internal.Codec_<S>): Internal.Codec<Internal.Either<F, S>>;
        static "unit(java.lang.Object)"<A>(arg0: A): Internal.Codec<A>;
        static checkRange<N extends number & Internal.Comparable<N>>(arg0: N, arg1: N): Internal.Function<N, Internal.DataResult<N>>;
        wait(): void;
        boxed(): Internal.Decoder$Boxed<Internal.Map<K, V>>;
        static unboundedMap<K, V>(arg0: Internal.Codec_<K>, arg1: Internal.Codec_<V>): Internal.UnboundedMapCodec<K, V>;
        "decode(com.mojang.serialization.DynamicOps,java.lang.Object)"<T>(arg0: Internal.DynamicOps_<T>, arg1: T): Internal.DataResult<com.mojang.datafixers.util.Pair<Internal.Map<K, V>, T>>;
        "orElse(java.util.function.Consumer,java.util.Map)"(arg0: Internal.Consumer_<string>, arg1: Internal.Map_<K, V>): Internal.Codec<Internal.Map<K, V>>;
        optionalFieldOf(arg0: string): Internal.MapCodec<Optional<Internal.Map<K, V>>>;
        static of<A>(arg0: Internal.Encoder_<A>, arg1: Internal.Decoder_<A>, arg2: string): Internal.Codec<A>;
        encode<T>(arg0: Internal.Map_<K, V>, arg1: Internal.DynamicOps_<T>, arg2: T): Internal.DataResult<T>;
        getClass(): typeof any;
        "encode(java.lang.Object,com.mojang.serialization.DynamicOps,java.lang.Object)"(arg0: any, arg1: Internal.DynamicOps_<any>, arg2: any): Internal.DataResult<any>;
        orElse(arg0: Internal.Map_<K, V>): Internal.Codec<Internal.Map<K, V>>;
        static ofSimple<A>(arg0: Internal.Decoder$Simple_<A>): Internal.Decoder<A>;
        static mapEither<F, S>(arg0: Internal.MapCodec_<F>, arg1: Internal.MapCodec_<S>): Internal.MapCodec<Internal.Either<F, S>>;
        static doubleRange(arg0: number, arg1: number): Internal.Codec<number>;
        "decode(com.mojang.serialization.DynamicOps,com.mojang.serialization.MapLike)"<T>(arg0: Internal.DynamicOps_<T>, arg1: Internal.MapLike_<T>): Internal.DataResult<Internal.Map<K, V>>;
        static optionalField<F>(arg0: string, arg1: Internal.Codec_<F>): Internal.MapCodec<Optional<F>>;
        xmap<S>(arg0: Internal.Function_<Internal.Map<K, V>, S>, arg1: Internal.Function_<S, Internal.Map<K, V>>): Internal.Codec<S>;
        listOf(): Internal.Codec<Internal.List<Internal.Map<K, V>>>;
        static simpleMap<K, V>(arg0: Internal.Codec_<K>, arg1: Internal.Codec_<V>, arg2: Internal.Keyable_): Internal.SimpleMapCodec<K, V>;
        fieldOf(arg0: string): Internal.MapCodec<Internal.Map<K, V>>;
        parse<T>(arg0: Internal.Dynamic_<T>): Internal.DataResult<Internal.Map<K, V>>;
        "orElseGet(java.util.function.Consumer,java.util.function.Supplier)"(arg0: Internal.Consumer_<string>, arg1: Internal.Supplier_<Internal.Map<K, V>>): Internal.Codec<Internal.Map<K, V>>;
        flatComapMap<S>(arg0: Internal.Function_<Internal.Map<K, V>, S>, arg1: Internal.Function_<S, Internal.DataResult<Internal.Map<K, V>>>): Internal.Codec<S>;
        stable(): Internal.Codec<Internal.Map<K, V>>;
        orElseGet(arg0: Internal.UnaryOperator_<string>, arg1: Internal.Supplier_<Internal.Map<K, V>>): Internal.Codec<Internal.Map<K, V>>;
        simple(): Internal.Decoder$Simple<Internal.Map<K, V>>;
        static ofTerminal<A>(arg0: Internal.Decoder$Terminal_<A>): Internal.Decoder<A>;
        encode(arg0: any, arg1: Internal.DynamicOps_<any>, arg2: any): Internal.DataResult<any>;
        decode<T>(arg0: Internal.DynamicOps_<T>, arg1: Internal.MapLike_<T>): Internal.DataResult<Internal.Map<K, V>>;
        wait(arg0: number, arg1: number): void;
        decode<T>(arg0: Internal.DynamicOps_<T>, arg1: T): Internal.DataResult<com.mojang.datafixers.util.Pair<Internal.Map<K, V>, T>>;
        comapFlatMap<S>(arg0: Internal.Function_<Internal.Map<K, V>, Internal.DataResult<S>>, arg1: Internal.Function_<S, Internal.Map<K, V>>): Internal.Codec<S>;
        static list<E>(arg0: Internal.Codec_<E>): Internal.Codec<Internal.List<E>>;
        orElse(arg0: Internal.Consumer_<string>, arg1: Internal.Map_<K, V>): Internal.Codec<Internal.Map<K, V>>;
        comap<B>(arg0: Internal.Function_<B, Internal.Map<K, V>>): Internal.Encoder<B>;
        flatMap<B>(arg0: Internal.Function_<Internal.Map<K, V>, Internal.DataResult<B>>): Internal.Decoder<B>;
        promotePartial(arg0: Internal.Consumer_<any>): Internal.Decoder<any>;
        static of<A>(arg0: Internal.MapEncoder_<A>, arg1: Internal.MapDecoder_<A>): Internal.MapCodec<A>;
        mapResult(arg0: Internal.Codec$ResultFunction_<Internal.Map<K, V>>): Internal.Codec<Internal.Map<K, V>>;
        static "unit(java.util.function.Supplier)"<A>(arg0: Internal.Supplier_<A>): Internal.Codec<A>;
        dispatch<E>(arg0: Internal.Function_<E, Internal.Map<K, V>>, arg1: Internal.Function_<Internal.Map<K, V>, Internal.Codec<E>>): Internal.Codec<E>;
        encodeStart<T>(arg0: Internal.DynamicOps_<T>, arg1: Internal.Map_<K, V>): Internal.DataResult<T>;
        terminal(): Internal.Decoder$Terminal<Internal.Map<K, V>>;
        optionalFieldOf(arg0: string, arg1: Internal.Lifecycle_, arg2: Internal.Map_<K, V>, arg3: Internal.Lifecycle_): Internal.MapCodec<Internal.Map<K, V>>;
        toString(): string;
        static of<A>(arg0: Internal.Encoder_<A>, arg1: Internal.Decoder_<A>): Internal.Codec<A>;
        notifyAll(): void;
        static compoundList<K, V>(arg0: Internal.Codec_<K>, arg1: Internal.Codec_<V>): Internal.Codec<Internal.List<com.mojang.datafixers.util.Pair<K, V>>>;
        withLifecycle(arg0: Internal.Lifecycle_): Internal.Codec<Internal.Map<K, V>>;
        static of<A>(arg0: Internal.MapEncoder_<A>, arg1: Internal.MapDecoder_<A>, arg2: Internal.Supplier_<string>): Internal.MapCodec<A>;
        hashCode(): number;
        orElseGet(arg0: Internal.Supplier_<Internal.Map<K, V>>): Internal.Codec<Internal.Map<K, V>>;
        orElse(arg0: Internal.UnaryOperator_<string>, arg1: Internal.Map_<K, V>): Internal.Codec<Internal.Map<K, V>>;
        wait(arg0: number): void;
        static "of(com.mojang.serialization.MapEncoder,com.mojang.serialization.MapDecoder,java.util.function.Supplier)"<A>(arg0: Internal.MapEncoder_<A>, arg1: Internal.MapDecoder_<A>, arg2: Internal.Supplier_<string>): Internal.MapCodec<A>;
        "encode(java.util.Map,com.mojang.serialization.DynamicOps,com.mojang.serialization.RecordBuilder)"<T>(arg0: Internal.Map_<K, V>, arg1: Internal.DynamicOps_<T>, arg2: Internal.RecordBuilder_<T>): Internal.RecordBuilder<T>;
        flatXmap<S>(arg0: Internal.Function_<Internal.Map<K, V>, Internal.DataResult<S>>, arg1: Internal.Function_<S, Internal.DataResult<Internal.Map<K, V>>>): Internal.Codec<S>;
        static "of(com.mojang.serialization.Encoder,com.mojang.serialization.Decoder,java.lang.String)"<A>(arg0: Internal.Encoder_<A>, arg1: Internal.Decoder_<A>, arg2: string): Internal.Codec<A>;
        equals(arg0: any): boolean;
        static mapPair<F, S>(arg0: Internal.MapCodec_<F>, arg1: Internal.MapCodec_<S>): Internal.MapCodec<com.mojang.datafixers.util.Pair<F, S>>;
        get class(): typeof any
    }
    type UnboundedMapCodec_<K, V> = UnboundedMapCodec<K, V>;
    class SchedulingManager {
        constructor(executor: Internal.Executor_, maxScheduled: number)
        getClass(): typeof any;
        updatePriorityFromLevel(pos: number, level: number): void;
        toString(): string;
        getNeighborLockingManager(): Internal.NeighborLockingManager;
        enqueue(task: Internal.ScheduledTask_): void;
        notifyAll(): void;
        getExecutor(): Internal.Executor;
        setCurrentSyncLoad(pos: Internal.ChunkPos_): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        get class(): typeof any
        get neighborLockingManager(): Internal.NeighborLockingManager
        get executor(): Internal.Executor
        set currentSyncLoad(pos: Internal.ChunkPos_)
        static readonly MAX_LEVEL: (47) & (number);
    }
    type SchedulingManager_ = SchedulingManager;
    class SimpleRandomFeatureConfiguration implements Internal.FeatureConfiguration {
        constructor($$0: Internal.HolderSet_<Internal.PlacedFeature>)
        getClass(): typeof any;
        hashCode(): number;
        getFeatures(): Internal.Stream<Internal.ConfiguredFeature<any, any>>;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        get features(): Internal.Stream<Internal.ConfiguredFeature<any, any>>
        static readonly CODEC: Internal.Codec<Internal.SimpleRandomFeatureConfiguration>;
        readonly features: Internal.HolderSet<Internal.PlacedFeature>;
    }
    type SimpleRandomFeatureConfiguration_ = SimpleRandomFeatureConfiguration;
    abstract class CharBuffer extends Internal.Buffer implements Internal.Comparable<Internal.CharBuffer>, Internal.CharSequence, Internal.Appendable, Internal.Readable {
        put(arg0: string): this;
        abstract isDirect(): boolean;
        limit(): number;
        notify(): void;
        compareTo(arg0: any): number;
        "put(int,char[])"(arg0: number, arg1: string[]): this;
        "get(char[])"(arg0: string[]): this;
        "put(java.nio.CharBuffer)"(arg0: Internal.CharBuffer_): this;
        static "wrap(char[])"(arg0: string[]): Internal.CharBuffer;
        abstract order(): Internal.ByteOrder;
        reset(): this;
        put(arg0: number, arg1: string[]): this;
        charAt(arg0: number): string;
        get(arg0: number, arg1: string[]): this;
        put(arg0: Internal.CharBuffer_): this;
        length(): number;
        put(arg0: number, arg1: string[], arg2: number, arg3: number): this;
        put(arg0: number, arg1: Internal.CharBuffer_, arg2: number, arg3: number): this;
        limit(arg0: number): this;
        append(arg0: Internal.CharSequence_): Internal.Appendable;
        static "wrap(java.lang.CharSequence,int,int)"(arg0: Internal.CharSequence_, arg1: number, arg2: number): Internal.CharBuffer;
        static allocate(arg0: number): Internal.CharBuffer;
        position(): number;
        abstract put(arg0: string): this;
        append(arg0: string): this;
        static wrap(arg0: Internal.CharSequence_, arg1: number, arg2: number): Internal.CharBuffer;
        abstract slice(): this;
        static wrap(arg0: string[]): Internal.CharBuffer;
        static compare(arg0: Internal.CharSequence_, arg1: Internal.CharSequence_): number;
        compareTo(arg0: Internal.CharBuffer_): number;
        chars(): Internal.IntStream;
        wait(): void;
        get(arg0: string[], arg1: number, arg2: number): this;
        abstract isReadOnly(): boolean;
        "put(java.lang.String,int,int)"(arg0: string, arg1: number, arg2: number): this;
        put(arg0: string[], arg1: number, arg2: number): this;
        abstract "put(char)"(arg0: string): this;
        "compareTo(java.lang.Object)"(arg0: any): number;
        abstract "put(int,char)"(arg0: number, arg1: string): this;
        "append(char)"(arg0: string): this;
        "append(java.lang.CharSequence)"(arg0: Internal.CharSequence_): Internal.Appendable;
        "put(char[])"(arg0: string[]): this;
        getClass(): typeof any;
        static "wrap(java.lang.CharSequence)"(arg0: Internal.CharSequence_): Internal.CharBuffer;
        static wrap(arg0: string[], arg1: number, arg2: number): Internal.CharBuffer;
        capacity(): number;
        abstract get(): string;
        static wrap(arg0: Internal.CharSequence_): Internal.CharBuffer;
        array(): string[];
        static "wrap(char[],int,int)"(arg0: string[], arg1: number, arg2: number): Internal.CharBuffer;
        arrayOffset(): number;
        "put(java.lang.String)"(arg0: string): this;
        isEmpty(): boolean;
        clear(): this;
        flip(): this;
        wait(arg0: number, arg1: number): void;
        subSequence(arg0: number, arg1: number): Internal.CharSequence;
        read(arg0: Internal.CharBuffer_): number;
        abstract asReadOnlyBuffer(): this;
        get(arg0: number, arg1: string[], arg2: number, arg3: number): this;
        "put(int,char[],int,int)"(arg0: number, arg1: string[], arg2: number, arg3: number): this;
        abstract put(arg0: number, arg1: string): this;
        hasArray(): boolean;
        "put(int,java.nio.CharBuffer,int,int)"(arg0: number, arg1: Internal.CharBuffer_, arg2: number, arg3: number): this;
        "put(char[],int,int)"(arg0: string[], arg1: number, arg2: number): this;
        abstract compact(): this;
        toString(): string;
        abstract get(arg0: number): string;
        remaining(): number;
        get(arg0: string[]): this;
        rewind(): Internal.Buffer;
        notifyAll(): void;
        put(arg0: string, arg1: number, arg2: number): this;
        put(arg0: string[]): this;
        abstract "get(int)"(arg0: number): string;
        "compareTo(java.nio.CharBuffer)"(arg0: Internal.CharBuffer_): number;
        mark(): Internal.Buffer;
        append(arg0: Internal.CharSequence_, arg1: number, arg2: number): this;
        hashCode(): number;
        mismatch(arg0: Internal.CharBuffer_): number;
        position(arg0: number): Internal.Buffer;
        hasRemaining(): boolean;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        abstract slice(arg0: number, arg1: number): this;
        abstract duplicate(): this;
        codePoints(): Internal.IntStream;
        get direct(): boolean
        get readOnly(): boolean
        get class(): typeof any
        get empty(): boolean
    }
    type CharBuffer_ = CharBuffer;
    interface ClickArea$Result {
        abstract category(arg0: Internal.CategoryIdentifier_<any>): this;
        categories(categories: Internal.Iterable_<Internal.CategoryIdentifier<any>>): this;
        abstract isSuccessful(): boolean;
        abstract tooltip(arg0: Internal.Supplier_<net.minecraft.network.chat.Component[]>): this;
        fail(): this;
        abstract getCategories(): Internal.Stream<Internal.CategoryIdentifier<any>>;
        abstract executor(arg0: Internal.BooleanSupplier_): this;
        abstract execute(): boolean;
        abstract getTooltips(): net.minecraft.network.chat.Component[];
        success(): this;
        get successful(): boolean
        get categories(): Internal.Stream<Internal.CategoryIdentifier<any>>
        get tooltips(): net.minecraft.network.chat.Component[]
    }
    type ClickArea$Result_ = ClickArea$Result;
    class ItemCharmTicking extends Internal.ItemCharm {
        constructor(effect: any_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick(stack: Internal.ItemStack_, world: Internal.Level_, user: Internal.Entity_, slotIndex: number, selected: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type ItemCharmTicking_ = ItemCharmTicking;
    class ImageIcon extends Internal.Icon implements Internal.IResourceIcon {
        constructor(tex: ResourceLocation_)
        draw3D(graphics: Internal.GuiGraphics_): void;
        getClass(): typeof any;
        withTint(c: Internal.Color4I_): this;
        static "getIcon(com.google.gson.JsonElement)"(json: Internal.JsonElement_): Internal.Icon;
        aspectRatio(): number;
        isEmpty(): boolean;
        static empty(): Internal.Color4I;
        static getIcon(id: ResourceLocation_): Internal.Icon;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        bindTexture(): void;
        getIngredient(): any;
        combineWith(...icons: Internal.Icon_[]): Internal.Icon;
        withUV(arg0: number, arg1: number, arg2: number, arg3: number): Internal.Icon;
        combineWith(icon: Internal.Icon_): Internal.Icon;
        static "getIcon(net.minecraft.resources.ResourceLocation)"(id: ResourceLocation_): Internal.Icon;
        getPixelBufferFrameCount(): number;
        createPixelBuffer(): Internal.PixelBuffer;
        "combineWith(dev.ftb.mods.ftblibrary.icon.Icon[])"(...icons: Internal.Icon_[]): Internal.Icon;
        getJson(): Internal.JsonElement;
        withUV(x: number, y: number, w: number, h: number, tw: number, th: number): Internal.Icon;
        withPadding(padding: number): Internal.Icon;
        toString(): string;
        withBorder(color: Internal.Color4I_, roundEdges: boolean): Internal.Icon;
        notifyAll(): void;
        static getIcon(json: Internal.JsonElement_): Internal.Icon;
        hasPixelBuffer(): boolean;
        static getIcon(id: string): Internal.Icon;
        getResourceLocation(): ResourceLocation;
        "combineWith(dev.ftb.mods.ftblibrary.icon.Icon)"(icon: Internal.Icon_): Internal.Icon;
        hashCode(): number;
        drawStatic(graphics: Internal.GuiGraphics_, x: number, y: number, w: number, h: number): void;
        draw(graphics: Internal.GuiGraphics_, x: number, y: number, w: number, h: number): void;
        wait(): void;
        wait(arg0: number): void;
        static "getIcon(java.lang.String)"(id: string): Internal.Icon;
        withColor(color: Internal.Color4I_): this;
        equals(o: any): boolean;
        copy(): Internal.Icon;
        get class(): typeof any
        get empty(): boolean
        get ingredient(): any
        get pixelBufferFrameCount(): number
        get json(): Internal.JsonElement
        get resourceLocation(): ResourceLocation
        tileSize: number;
        maxV: number;
        color: Internal.Color4I;
        maxU: number;
        static readonly MISSING_IMAGE: (ResourceLocation) & (ResourceLocation);
        minU: number;
        readonly texture: ResourceLocation;
        minV: number;
    }
    type ImageIcon_ = ImageIcon;
    interface ComponentProvider extends Internal.ComponentAccess {
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        asComponentProvider(): this;
        getRecipientsForComponentSync(): Internal.Iterable<Internal.ServerPlayer>;
        toComponentPacket<C extends Internal.AutoSyncedComponent>(key: Internal.ComponentKey_<C>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        abstract getComponentContainer(): Internal.ComponentContainer;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        get recipientsForComponentSync(): Internal.Iterable<Internal.ServerPlayer>
        get componentContainer(): Internal.ComponentContainer
        (): Internal.ComponentContainer_;
    }
    type ComponentProvider_ = (()=> Internal.ComponentContainer_) | ComponentProvider;
    class PointedRedstoneFeature <P> extends Feature<Internal.PointedRedstoneConfiguration> {
        constructor(codec: Internal.Codec_<Internal.PointedRedstoneConfiguration>)
        getClass(): typeof any;
        toString(): string;
        place($$0: Internal.PointedRedstoneConfiguration_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        place(context: Internal.FeaturePlaceContext_<Internal.PointedRedstoneConfiguration>): boolean;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.PointedRedstoneConfiguration, Feature<Internal.PointedRedstoneConfiguration>>>;
        wait(): void;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        get class(): typeof any
    }
    type PointedRedstoneFeature_<P> = PointedRedstoneFeature<P>;
    class ComponentEvent extends Internal.AWTEvent {
        constructor(arg0: Internal.Component_, arg1: number)
        getClass(): typeof any;
        toString(): string;
        paramString(): string;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        setSource(arg0: any): void;
        getComponent(): Internal.Component;
        getSource(): any;
        equals(arg0: any): boolean;
        getID(): number;
        get class(): typeof any
        set source(arg0: any)
        get component(): Internal.Component
        get source(): any
        get ID(): number
        static readonly COMPONENT_FIRST: (100) & (number);
        static readonly COMPONENT_SHOWN: (102) & (number);
        static readonly COMPONENT_HIDDEN: (103) & (number);
        static readonly COMPONENT_LAST: (103) & (number);
        static readonly COMPONENT_MOVED: (100) & (number);
        static readonly COMPONENT_RESIZED: (101) & (number);
    }
    type ComponentEvent_ = ComponentEvent;
    interface BlockModelExtension {
        abstract getFusionModel(): Internal.ModelInstance<any>;
        abstract setFusionModel(model: Internal.ModelInstance_<any>): void;
        get fusionModel(): Internal.ModelInstance<any>
        set fusionModel(model: Internal.ModelInstance_<any>)
    }
    type BlockModelExtension_ = BlockModelExtension;
    class Uniform extends Internal.AbstractUniform implements Internal.AutoCloseable {
        constructor($$0: string, $$1: number, $$2: number, $$3: Internal.Shader_)
        upload(): void;
        getFloatBuffer(): Internal.FloatBuffer;
        static glGetAttribLocation($$0: number, $$1: Internal.CharSequence_): number;
        setLocation($$0: number): void;
        setMat3x3($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: number, $$7: number, $$8: number): void;
        set($$0: number, $$1: number): void;
        set($$0: number, $$1: number, $$2: number): void;
        notify(): void;
        setMat4x2($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: number, $$7: number): void;
        setMat4x4($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: number, $$7: number, $$8: number, $$9: number, $$10: number, $$11: number, $$12: number, $$13: number, $$14: number, $$15: number): void;
        "set(int,int,int)"($$0: number, $$1: number, $$2: number): void;
        "set(int,int,int,int)"($$0: number, $$1: number, $$2: number, $$3: number): void;
        set($$0: Vec3f_): void;
        static glGetUniformLocation($$0: number, $$1: Internal.CharSequence_): number;
        setMat3x4($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: number, $$7: number, $$8: number, $$9: number, $$10: number, $$11: number): void;
        static uploadInteger($$0: number, $$1: number): void;
        set($$0: number): void;
        "set(org.joml.Vector4f)"($$0: Vec4f_): void;
        "set(float[])"($$0: number[]): void;
        "setSafe(int,int,int,int)"($$0: number, $$1: number, $$2: number, $$3: number): void;
        static glBindAttribLocation($$0: number, $$1: number, $$2: Internal.CharSequence_): void;
        set($$0: Matrix4f_): void;
        "set(float,float,float,float)"($$0: number, $$1: number, $$2: number, $$3: number): void;
        wait(): void;
        "set(float)"($$0: number): void;
        "set(int)"($$0: number): void;
        getClass(): typeof any;
        getCount(): number;
        set($$0: number): void;
        setMat3x2($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): void;
        "set(int,float)"($$0: number, $$1: number): void;
        set($$0: number, $$1: number, $$2: number, $$3: number): void;
        "setSafe(float,float,float,float)"($$0: number, $$1: number, $$2: number, $$3: number): void;
        "set(int,int)"($$0: number, $$1: number): void;
        getIntBuffer(): Internal.IntBuffer;
        wait(arg0: number, arg1: number): void;
        "set(float,float)"($$0: number, $$1: number): void;
        set($$0: number, $$1: number): void;
        getType(): number;
        setSafe($$0: number, $$1: number, $$2: number, $$3: number): void;
        getName(): string;
        set($$0: Vec4f_): void;
        "set(org.joml.Matrix4f)"($$0: Matrix4f_): void;
        set($$0: number, $$1: number): void;
        set($$0: number, $$1: number, $$2: number, $$3: number): void;
        "set(float,float,float)"($$0: number, $$1: number, $$2: number): void;
        getLocation(): number;
        setMat2x2($$0: number, $$1: number, $$2: number, $$3: number): void;
        set($$0: number, $$1: number, $$2: number): void;
        toString(): string;
        setSafe($$0: number, $$1: number, $$2: number, $$3: number): void;
        notifyAll(): void;
        "set(org.joml.Matrix3f)"($$0: Matrix3f_): void;
        set($$0: number[]): void;
        setMat4x3($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: number, $$7: number, $$8: number, $$9: number, $$10: number, $$11: number): void;
        "set(org.joml.Vector3f)"($$0: Vec3f_): void;
        hashCode(): number;
        setMat2x4($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: number, $$7: number): void;
        set($$0: Matrix3f_): void;
        close(): void;
        wait(arg0: number): void;
        setMat2x3($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): void;
        equals(arg0: any): boolean;
        static getTypeFromString($$0: string): number;
        get floatBuffer(): Internal.FloatBuffer
        set location($$0: number)
        set "(org.joml.Vector4f)"($$0: Vec4f_)
        set "(float[])"($$0: number[])
        set "(float)"($$0: number)
        set "(int)"($$0: number)
        get class(): typeof any
        get count(): number
        get intBuffer(): Internal.IntBuffer
        get type(): number
        get name(): string
        set "(org.joml.Matrix4f)"($$0: Matrix4f_)
        get location(): number
        set "(org.joml.Matrix3f)"($$0: Matrix3f_)
        set "(org.joml.Vector3f)"($$0: Vec3f_)
        static readonly UT_MAT4: (10) & (number);
        static readonly UT_FLOAT4: (7) & (number);
        static readonly UT_MAT2: (8) & (number);
        static readonly UT_MAT3: (9) & (number);
        static readonly UT_INT2: (1) & (number);
        static readonly UT_INT1: (0) & (number);
        static readonly UT_INT4: (3) & (number);
        static readonly UT_FLOAT3: (6) & (number);
        static readonly UT_INT3: (2) & (number);
        static readonly UT_FLOAT2: (5) & (number);
        static readonly UT_FLOAT1: (4) & (number);
    }
    type Uniform_ = Uniform;
    abstract class ConfigWithVariants <T> extends Internal.ConfigValue<T> {
        constructor()
        getClass(): typeof any;
        setOrder(o: number): Internal.ConfigValue<T>;
        getStringForGUI(v: T): net.minecraft.network.chat.Component;
        addInfo(list: Internal.TooltipList_): void;
        onClicked(clickedWidget: dev.ftb.mods.ftblibrary.ui.Widget_, button: Internal.MouseButton_, callback: Internal.ConfigCallback_): void;
        getColor(v: T): Internal.Color4I;
        getTooltip(): string;
        notify(): void;
        getDefaultValue(): T;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        compareTo(o: Internal.ConfigValue_<T>): number;
        getIcon(): Internal.Icon;
        setIcon(i: Internal.Icon_): Internal.ConfigValue<T>;
        getName(): string;
        getGroup(): Internal.ConfigGroup;
        getStringForGUI(): net.minecraft.network.chat.Component;
        getColor(): Internal.Color4I;
        getPath(): string;
        applyValue(): void;
        setNameKey(key: string): Internal.ConfigValue<T>;
        getIcon(v: T): Internal.Icon;
        toString(): string;
        notifyAll(): void;
        setCanEdit(e: boolean): Internal.ConfigValue<T>;
        init(group: Internal.ConfigGroup_, id: string, value: T, setter: Internal.Consumer_<T>, defaultValue: T): Internal.ConfigValue<T>;
        static info(key: string, value: any): net.minecraft.network.chat.Component;
        "compareTo(dev.ftb.mods.ftblibrary.config.ConfigValue)"(o: Internal.ConfigValue_<T>): number;
        hashCode(): number;
        abstract getIteration(arg0: T, arg1: boolean): T;
        setValue(value: T): void;
        wait(): void;
        getNameKey(): string;
        getValue(): T;
        copy(value: T): T;
        isEqual(v1: T, v2: T): boolean;
        wait(arg0: number): void;
        getCanEdit(): boolean;
        setDefaultValue(defaultValue: T): void;
        setCurrentValue(v: T): boolean;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        get class(): typeof any
        set order(o: number)
        get tooltip(): string
        get defaultValue(): T
        get icon(): Internal.Icon
        set icon(i: Internal.Icon_)
        get name(): string
        get group(): Internal.ConfigGroup
        get stringForGUI(): net.minecraft.network.chat.Component
        get color(): Internal.Color4I
        get path(): string
        set nameKey(key: string)
        set canEdit(e: boolean)
        set value(value: T)
        get nameKey(): string
        get value(): T
        get canEdit(): boolean
        set defaultValue(defaultValue: T)
        set currentValue(v: T)
    }
    type ConfigWithVariants_<T> = ConfigWithVariants<T>;
    class ClientboundRecipePacket$State extends Internal.Enum<Internal.ClientboundRecipePacket$State> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        static values(): Internal.ClientboundRecipePacket$State[];
        getDeclaringClass(): typeof Internal.ClientboundRecipePacket$State;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        static valueOf($$0: string): Internal.ClientboundRecipePacket$State;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        name(): string;
        hashCode(): number;
        "compareTo(net.minecraft.network.protocol.game.ClientboundRecipePacket$State)"(arg0: Internal.ClientboundRecipePacket$State_): number;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.ClientboundRecipePacket$State>>;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        compareTo(arg0: Internal.ClientboundRecipePacket$State_): number;
        get class(): typeof any
        get declaringClass(): typeof Internal.ClientboundRecipePacket$State
        static readonly REMOVE: (Internal.ClientboundRecipePacket$State) & (Internal.ClientboundRecipePacket$State);
        static readonly ADD: (Internal.ClientboundRecipePacket$State) & (Internal.ClientboundRecipePacket$State);
        static readonly INIT: (Internal.ClientboundRecipePacket$State) & (Internal.ClientboundRecipePacket$State);
    }
    type ClientboundRecipePacket$State_ = "init" | "remove" | ClientboundRecipePacket$State | "add";
    class UnstableReservoirRodItem extends Internal.Item {
        constructor(props: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick(world: Internal.Level_, living: Internal.LivingEntity_, stack: Internal.ItemStack_, count: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getUseAnimation(stack: Internal.ItemStack_): Internal.UseAnim;
        getDescriptionId(): string;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(world: Internal.Level_, player: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        static spawnMissile(world: Internal.Level_, thrower: Internal.LivingEntity_, x: number, y: number, z: number): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration(stack: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type UnstableReservoirRodItem_ = UnstableReservoirRodItem;
    interface ScreenInputDelegate {
        abstract architectury_delegateInputs(): Internal.Screen;
        (): Internal.Screen_;
    }
    type ScreenInputDelegate_ = ScreenInputDelegate | (()=> Internal.Screen_);
    interface BlockEntityGetter {
        abstract getLoadedExistingBlockEntity(arg0: BlockPos_): Internal.BlockEntity;
        (arg0: BlockPos): Internal.BlockEntity_;
    }
    type BlockEntityGetter_ = ((arg0: BlockPos)=> Internal.BlockEntity_) | BlockEntityGetter;
    interface BlockCountingSection {
        abstract mayContainAny(arg0: Internal.TrackedBlockStatePredicate_): boolean;
        (arg0: Internal.TrackedBlockStatePredicate): boolean;
    }
    type BlockCountingSection_ = ((arg0: Internal.TrackedBlockStatePredicate)=> boolean) | BlockCountingSection;
    class ClientboundBlockDestructionPacket implements Internal.Packet<Internal.ClientGamePacketListener> {
        constructor($$0: number, $$1: BlockPos_, $$2: number)
        constructor($$0: Internal.FriendlyByteBuf_)
        getProgress(): number;
        handle(arg0: Internal.PacketListener_): void;
        getClass(): typeof any;
        write($$0: Internal.FriendlyByteBuf_): void;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        isSkippable(): boolean;
        wait(arg0: number, arg1: number): void;
        getPos(): BlockPos;
        hashCode(): number;
        wait(): void;
        handle($$0: Internal.ClientGamePacketListener_): void;
        wait(arg0: number): void;
        "handle(net.minecraft.network.protocol.game.ClientGamePacketListener)"($$0: Internal.ClientGamePacketListener_): void;
        equals(arg0: any): boolean;
        "handle(net.minecraft.network.PacketListener)"(arg0: Internal.PacketListener_): void;
        getId(): number;
        get progress(): number
        get class(): typeof any
        get skippable(): boolean
        get pos(): BlockPos
        get id(): number
    }
    type ClientboundBlockDestructionPacket_ = ClientboundBlockDestructionPacket;
    class MushroomCow extends Internal.Cow implements Internal.Shearable, Internal.IShearable, Internal.MushroomCowAccessor, Internal.VariantHolder<Internal.MushroomCow$MushroomType> {
        constructor($$0: Internal.EntityType_<Internal.MushroomCow>, $$1: Internal.Level_)
        isShearable(item: Internal.ItemStack_, world: Internal.Level_, pos: BlockPos_): boolean;
        handler$hak000$gobber2$gobberOccludeVibrationSignals(cir: Internal.CallbackInfoReturnable_<any>): void;
        handler$fed001$extraalchemy$writeNbt(tag: Internal.CompoundTag_, cb: Internal.CallbackInfo_): void;
        etf$getType(): Internal.EntityType<any>;
        getUpVector($$0: number): Vec3d;
        gameEvent($$0: Internal.GameEvent_, $$1: Internal.Entity_): void;
        static checkMobSpawnRules($$0: Internal.EntityType_<Internal.Mob>, $$1: Internal.LevelAccessor_, $$2: Internal.MobSpawnType_, $$3: BlockPos_, $$4: Internal.RandomSource_): boolean;
        setDefaultMovementSpeedMultiplier(speed: number): void;
        isSuppressingBounce(): boolean;
        setTarget($$0: Internal.LivingEntity_): void;
        handler$han001$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        setCulled(value: boolean): void;
        handler$leb003$puzzleslib$hurt(source: DamageSource_, amount: number, callback: Internal.CallbackInfoReturnable_<any>): void;
        isOnFire(): boolean;
        getPositionCodec(): Internal.VecDeltaCodec;
        setMaxUpStep($$0: number): void;
        updateFluidHeightAndDoFluidPushing($$0: Internal.TagKey_<Internal.Fluid>, $$1: number): boolean;
        convertTo<T extends Internal.Mob>($$0: Internal.EntityType_<T>, $$1: boolean): T;
        getFallFlyingTicks(): number;
        setPosition(x: number, y: number, z: number): void;
        runCommandSilent(command: string): number;
        chunkPosition(): Internal.ChunkPos;
        emf$isOnGround(): boolean;
        dropLeash($$0: boolean, $$1: boolean): void;
        gameEvent($$0: Internal.GameEvent_): void;
        setXxa($$0: number): void;
        setDelayedLeashHolderId($$0: number): void;
        isShiftKeyDown(): boolean;
        setUUID($$0: Internal.UUID_): void;
        checkBelowWorld(): void;
        handler$leb000$puzzleslib$startUsingItem(hand: Internal.InteractionHand_, callback: Internal.CallbackInfo_): void;
        setMotionZ(z: number): void;
        "deserializeNBT(net.minecraft.nbt.Tag)"(arg0: Internal.Tag_): void;
        canFreeze(): boolean;
        ignoreExplosion(): boolean;
        getBlockY(): number;
        getIsInsideStructureTracker(): Internal.IsInsideStructureTracker;
        setPlayerHitTimer(arg0: number): void;
        isSpectator(): boolean;
        setMainHandItem(item: Internal.ItemStack_): void;
        removeEffectNoUpdate($$0: Internal.MobEffect_): Internal.MobEffectInstance;
        spawnAtLocation($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        getPersistentData(): Internal.CompoundTag;
        getHealth(): number;
        getMaxHealth(): number;
        emf$isGlowing(): boolean;
        setPathfindingMalus($$0: Internal.BlockPathTypes_, $$1: number): void;
        isRegisteredToWorld(): boolean;
        getRandomZ($$0: number): number;
        pehkui_getOnGround(): boolean;
        setAggressive($$0: boolean): void;
        handler$lef000$puzzleslib$checkDespawn(callback: Internal.CallbackInfo_): void;
        getFusionModel(layerIndex: number): Internal.Triple<any, any, any>;
        setRemoved($$0: Internal.Entity$RemovalReason_): void;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>, initializer: Internal.Supplier_<A>): A;
        getDistanceSq($$0: number, $$1: number, $$2: number): number;
        isInWaterRainOrBubble(): boolean;
        getRemovalReason(): Internal.Entity$RemovalReason;
        etf$getVelocity(): Vec3d;
        hex$markHurt(): void;
        resetFallDistance(): void;
        canSprint(): boolean;
        blockPosition(): BlockPos;
        setBoundingBox($$0: Internal.AABB_): void;
        isAmbientCreature(): boolean;
        setZza($$0: number): void;
        getBlock(): Internal.BlockContainerJS;
        setEquipment(slot: Internal.EquipmentSlot_, item: Internal.ItemStack_): void;
        etf$getHandItems(): Internal.Iterable<any>;
        randomTeleport($$0: number, $$1: number, $$2: number, $$3: boolean): boolean;
        getName(): net.minecraft.network.chat.Component;
        playAmbientSound(): void;
        onGround(): boolean;
        handler$leb000$puzzleslib$canBeAffected(effectInstance: Internal.MobEffectInstance_, callback: Internal.CallbackInfoReturnable_<any>): void;
        getControlledVehicle(): Internal.Entity;
        isOnSameTeam($$0: Internal.Entity_): boolean;
        getArmorValue(): number;
        tick(): void;
        onSheared(player: Internal.Player_, item: Internal.ItemStack_, world: Internal.Level_, pos: BlockPos_, fortune: number): Internal.List<any>;
        localvar$lef000$puzzleslib$setTarget(entity: Internal.LivingEntity_): Internal.LivingEntity;
        getKillCredit(): Internal.LivingEntity;
        emf$isTouchingWater(): boolean;
        emf$getVariableMap(): Internal.Object2FloatOpenHashMap<any>;
        getComponentContainer(): Internal.ComponentContainer;
        hasPermissions($$0: number): boolean;
        getDynamicLightPrevZ(): number;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        pehkui_readScaleNbt(nbt: Internal.CompoundTag_): void;
        shear($$0: Internal.SoundSource_): void;
        setOutOfCamera(value: boolean): void;
        static createMobAttributes(): Internal.AttributeSupplier$Builder;
        isAutoSpinAttack(): boolean;
        getRemainingFireTicks(): number;
        botania_getAmbientSound(): Internal.SoundEvent;
        onlyOpCanSetNbt(): boolean;
        tcdcommons_getCustomData(): Internal.GenericProperties<any>;
        fireImmune(): boolean;
        addMotion($$0: number, $$1: number, $$2: number): void;
        getMaxFallDistance(): number;
        isHolding($$0: Internal.Item_): boolean;
        getZ($$0: number): number;
        static areAllEffectsAmbient($$0: Internal.Collection_<Internal.MobEffectInstance>): boolean;
        doHurtTarget($$0: Internal.Entity_): boolean;
        getTicksFrozen(): number;
        wrapWithCondition$kom000$porting_lib_entity$port_lib$captureDrops(level: Internal.Level_, entity: Internal.Entity_): boolean;
        handler$lef000$puzzleslib$addAdditionalSaveData(compound: Internal.CompoundTag_, callback: Internal.CallbackInfo_): void;
        deflect(chance: number, source: Internal.Entity_): boolean;
        getRandomX($$0: number): number;
        getDynamicLightZ(): number;
        spawnAtLocation($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        pick($$0: number, $$1: number, $$2: boolean): Internal.HitResult;
        getVoicePitch(): number;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        setSleepingPos($$0: BlockPos_): void;
        changeDimension(p_20118_: Internal.ServerLevel_, teleporter: Internal.ITeleporter_): Internal.Entity;
        isDescending(): boolean;
        getAttributeBaseValue($$0: Internal.Attribute_): number;
        emf$getPitch(): number;
        sendEffectToPassengers($$0: Internal.MobEffectInstance_): void;
        getHeadRotSpeed(): number;
        getLastHurtByPlayer(): Internal.Player;
        getYHeadRot(): number;
        handler$cbi000$besmirchment$isTeammate(other: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>): void;
        localvar$leb000$puzzleslib$addEffect(oldEffectInstance: Internal.MobEffectInstance_, effectInstance: Internal.MobEffectInstance_, entity: Internal.Entity_): Internal.MobEffectInstance;
        getProjectile($$0: Internal.ItemStack_): Internal.ItemStack;
        static getAlpha(le: Internal.LivingEntity_, partialTicks: number): number;
        frameworkGetDataHolder(): com.mrcrayfish.framework.entity.sync.DataHolder;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        syncPacketPositionCodec($$0: number, $$1: number, $$2: number): void;
        setAbsorptionAmount($$0: number): void;
        setRecallData(pos: Internal.DimensionalPosition_): void;
        port_lib$spawnItemParticles(arg0: Internal.ItemStack_, arg1: number): void;
        setEffectDuration(arg0: number): void;
        shouldRenderAtSqrDistance($$0: number): boolean;
        getAttachedOrSet<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        damageSources(): Internal.DamageSources;
        removeAttached<A>(type: Internal.AttachmentType_<A>): A;
        removeAllGoals($$0: Internal.Predicate_<Internal.Goal>): void;
        swing(): void;
        recreateFromPacket($$0: Internal.ClientboundAddEntityPacket_): void;
        setDeltaMovement($$0: Vec3d_): void;
        getLeashOffset($$0: number): Vec3d;
        isBaby(): boolean;
        isCulled(): boolean;
        damageEquipment(slot: Internal.EquipmentSlot_): void;
        isGlowing(): boolean;
        getWalkTargetValue($$0: BlockPos_): number;
        canBreatheUnderwater(): boolean;
        getLeashedByEntities(): Internal.Set<any>;
        die($$0: DamageSource_): void;
        etf$getOptifineId(): number;
        removeAllEffects(): boolean;
        dynamicLightWorld(): Internal.Level;
        getLeashOffset(): Vec3d;
        hasLineOfSight($$0: Internal.Entity_): boolean;
        hex$getLastHurt(): number;
        onClimbable(): boolean;
        isAttackable(): boolean;
        getSlot($$0: number): Internal.SlotAccess;
        "deserializeNBT(net.minecraft.nbt.CompoundTag)"(nbt: Internal.CompoundTag_): void;
        emf$isInLava(): boolean;
        pehkui_constructScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        stopSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isUnderWater(): boolean;
        stopRiding(): void;
        getLeashHolder(): Internal.Entity;
        getX($$0: number): number;
        getSensing(): Internal.Sensing;
        localvar$kpc000$porting_lib_entity$port_lib$modifyMultiplier(multiplier: number): number;
        getLegsArmorItem(): Internal.ItemStack;
        getLuminance(): number;
        callUnsetRemoved(): void;
        captureDrops(value: Internal.Collection_<Internal.ItemEntity>): Internal.Collection<Internal.ItemEntity>;
        getSelfAndPassengers(): Internal.Stream<any>;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        handler$egi000$collective$LivingEntity_hurt(damageSource: DamageSource_, f: number, ci: Internal.CallbackInfoReturnable_<any>): void;
        getDeltaMovement(): Vec3d;
        canTakeItem($$0: Internal.ItemStack_): boolean;
        shouldDropExperience(): boolean;
        hasPassenger($$0: Internal.Entity_): boolean;
        be_getTravelerState(): Internal.TravelerState;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        getDynamicLightX(): number;
        setSecondsOnFire($$0: number): void;
        moveTo($$0: number, $$1: number, $$2: number): void;
        emf$getZ(): number;
        "getDisplayName()"(): net.minecraft.network.chat.Component;
        getLootTable(): ResourceLocation;
        getTicksUsingItem(): number;
        bettertrims$getWornMaterials(): Internal.List<any>;
        getArrowCount(): number;
        getMoveControl(): Internal.MoveControl;
        setMotion($$0: number, $$1: number, $$2: number): void;
        playSound($$0: Internal.SoundEvent_): void;
        getDefaultMovementSpeed(): number;
        handler$ikg000$lithium$tryShortcutFluidPushing(tag: Internal.TagKey_<any>, speed: number, cir: Internal.CallbackInfoReturnable_<any>, box: Internal.AABB_, x1: number, x2: number, y1: number, y2: number, z1: number, z2: number, zero: number): void;
        handler$hak000$gobber2$setFrozenTicks(frozenTicks: number, ci: Internal.CallbackInfo_): void;
        restoreFrom($$0: Internal.Entity_): void;
        isPeacefulCreature(): boolean;
        setOnGround($$0: boolean): void;
        addEffect($$0: Internal.MobEffectInstance_, $$1: Internal.Entity_): boolean;
        emf$getYaw(): number;
        ate(): void;
        setPos($$0: number, $$1: number, $$2: number): void;
        notify(): void;
        setPersistenceRequired(): void;
        getLastHurtByMobTimestamp(): number;
        getVehicle(): Internal.Entity;
        canFallInLove(): boolean;
        isEffectiveAi(): boolean;
        handler$kom000$porting_lib_entity$port_lib$startRiding(entity: Internal.Entity_, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        startRiding($$0: Internal.Entity_, $$1: boolean): boolean;
        getStringUuid(): string;
        setSwimming($$0: boolean): void;
        getMainArm(): Internal.HumanoidArm;
        checkSpawnRules($$0: Internal.LevelAccessor_, $$1: Internal.MobSpawnType_): boolean;
        getRotationVector(): Internal.Vec2;
        getHurtDir(): number;
        etf$getBlockY(): number;
        isSprinting(): boolean;
        isMaxGroupSizeReached($$0: number): boolean;
        getMotionY(): number;
        getOffhandItem(): Internal.ItemStack;
        canCollideWith($$0: Internal.Entity_): boolean;
        setLuminance(luminance: number): void;
        getBlockExplosionResistance($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.FluidState_, $$5: number): number;
        setLootTable(arg0: ResourceLocation_): void;
        clearSleepingPos(): void;
        canSpawnSprintParticle(): boolean;
        "moveTo(net.minecraft.core.BlockPos,float,float)"($$0: BlockPos_, $$1: number, $$2: number): void;
        hex$checkTotemDeathProtection(arg0: DamageSource_): boolean;
        getLastHurtMob(): Internal.LivingEntity;
        moveRelative($$0: number, $$1: Vec3d_): void;
        saveAsPassenger($$0: Internal.CompoundTag_): boolean;
        static gatherClosestChunks(chunks: Internal.LongSet_, x: number, y: number, z: number): void;
        handler$kom000$porting_lib_entity$afterSave(nbt: Internal.CompoundTag_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDamageSource(): DamageSource;
        getSoundSource(): Internal.SoundSource;
        setNoActionTime($$0: number): void;
        setMovementSpeedAddition(speed: number): void;
        removeAfterChangingDimensions(): void;
        equipmentHasChanged($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        getPose(): Internal.Pose;
        getAttribute($$0: Internal.Attribute_): Internal.AttributeInstance;
        setPositionAndRotation($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        canBeAffected($$0: Internal.MobEffectInstance_): boolean;
        ageUp($$0: number): void;
        getRestrictCenter(): BlockPos;
        isLeftHanded(): boolean;
        invokeShouldDropLoot(): boolean;
        handler$kpc000$porting_lib_entity$port_lib$onFinishUsing(ci: Internal.CallbackInfo_, hand: Internal.InteractionHand_, result: Internal.ItemStack_): void;
        etf$getUuid(): Internal.UUID;
        removeVehicle(): void;
        shouldFusionRecomputeModel(layerIndex: number): boolean;
        modifyExpressionValue$zcl000$porting_lib_base$port_lib$canContinueUsing(original: boolean): boolean;
        setZ(z: number): void;
        getY(): number;
        deserializeNBT(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        finalizeSpawnChildFromBreeding($$0: Internal.ServerLevel_, $$1: Internal.Animal_, $$2: Internal.AgeableMob_): void;
        eat($$0: Internal.Level_, $$1: Internal.ItemStack_): Internal.ItemStack;
        bookshelf$makePoofParticles(): void;
        isWithinMeleeAttackRange($$0: Internal.LivingEntity_): boolean;
        setCurrentModifyFoodPowers(powers: Internal.List_<any>): void;
        broadcastBreakEvent($$0: Internal.EquipmentSlot_): void;
        modifyExpressionValue$zhf000$additionalentityattributes$additionalEntityAttributes$modifyUpwardSwimming(original: number, fluid: Internal.TagKey_<any>): number;
        handler$nbm000$things$onShieldBlock(source: DamageSource_, cir: Internal.CallbackInfoReturnable_<any>): void;
        showVehicleHealth(): boolean;
        getDistance(pos: BlockPos_): number;
        isBlocking(): boolean;
        "getBreedOffspring(net.minecraft.server.level.ServerLevel,net.minecraft.world.entity.AgeableMob)"(arg0: Internal.ServerLevel_, arg1: Internal.AgeableMob_): Internal.AgeableMob;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number): void;
        removeAttribute(attribute: Internal.Attribute_, identifier: string): void;
        emf$getVelocity(): Vec3d;
        handler$lef000$puzzleslib$finalizeSpawn(level: Internal.ServerLevelAccessor_, difficulty: Internal.DifficultyInstance_, reason: Internal.MobSpawnType_, spawnData: Internal.SpawnGroupData_, dataTag: Internal.CompoundTag_, callback: Internal.CallbackInfoReturnable_<any>): void;
        setVariant($$0: Internal.MushroomCow$MushroomType_): void;
        etf$isBlockEntity(): boolean;
        shouldUpdateDynamicLight(): boolean;
        isPushedByFluid(): boolean;
        setOriginalFoodStack(original: Internal.ItemStack_): void;
        getArmorCoverPercentage(): number;
        handleRelativeFrictionAndCalculateMovement($$0: Vec3d_, $$1: number): Vec3d;
        turn($$0: number, $$1: number): void;
        getAirSupply(): number;
        moveTo($$0: BlockPos_, $$1: number, $$2: number): void;
        isPlayer(): boolean;
        isAnimal(): boolean;
        "handler$fgd000$fabric-dimensions-v1$getTeleportTarget"(destination: Internal.ServerLevel_, cir: Internal.CallbackInfoReturnable_<any>): void;
        canBeCollidedWith(): boolean;
        getMotionDirection(): Internal.Direction;
        asComponentProvider(): Internal.ComponentProvider;
        lavaHurt(): void;
        handleDamageEvent($$0: DamageSource_): void;
        getFabricBalmData(): Internal.CompoundTag;
        canChangeDimensions(): boolean;
        static tickEntity(entity: Internal.Entity_): void;
        getCommandSenderWorld(): Internal.Level;
        getTotalMovementSpeed(): number;
        changeDimension($$0: Internal.ServerLevel_): Internal.Entity;
        localvar$zno000$apoli$modifyFallingVelocity(in_: number): number;
        handler$kom000$porting_lib_entity$afterLoad(nbt: Internal.CompoundTag_, ci: Internal.CallbackInfo_): void;
        pehkui_shouldIgnoreScaleNbt(): boolean;
        isMoving(): boolean;
        attack(hp: number): void;
        getAttributes(): Internal.AttributeMap;
        "hasPassenger(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.Entity>): boolean;
        botania_playHurtSound(arg0: DamageSource_): void;
        getDimensions($$0: Internal.Pose_): Internal.EntityDimensions;
        spawnChildFromBreeding($$0: Internal.ServerLevel_, $$1: Internal.Animal_): void;
        setInLoveTime($$0: number): void;
        invokeGetLeashOffset(): Vec3d;
        isSwimming(): boolean;
        setSprinting($$0: boolean): void;
        mayInteract($$0: Internal.Level_, $$1: BlockPos_): boolean;
        handler$kpc000$porting_lib_entity$port_lib$attackEvent(source: DamageSource_, amount: number, cir: Internal.CallbackInfoReturnable_<any>): void;
        getDynamicLightLevel(): Internal.Level;
        setPortalCooldown(): void;
        getAttackAnim($$0: number): number;
        hex$setLastHurt(arg0: number): void;
        setX(x: number): void;
        getPortalWaitTime(): number;
        getBlockStateOn(): Internal.BlockState;
        wantsToPickUp($$0: Internal.ItemStack_): boolean;
        getItemBySlot($$0: Internal.EquipmentSlot_): Internal.ItemStack;
        getFluidHeightLoosely(tag: Internal.TagKey_<any>): number;
        getFluidJumpThreshold(): number;
        getCachedSouls(): number;
        "getVariant()"(): any;
        "setPositionAndRotation(double,double,double,float,float)"($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        isInvisibleTo($$0: Internal.Player_): boolean;
        stopSleeping(): void;
        setAirSupply($$0: number): void;
        getOnPos(): BlockPos;
        etf$getWorld(): Internal.Level;
        isUndead(): boolean;
        static createLivingAttributes(): Internal.AttributeSupplier$Builder;
        setUseItemRemaining(arg0: number): void;
        pehkui_getScales(): Internal.Map<any, any>;
        getTargetSelector(): Internal.GoalSelector;
        setRegisteredToWorld(navigation: Internal.PathNavigation_): void;
        isSleeping(): boolean;
        stopUsingItem(): void;
        etf$getNbt(): Internal.CompoundTag;
        acceptsFailure(): boolean;
        etf$getBlockPos(): BlockPos;
        pehkui_setShouldIgnoreScaleNbt(ignore: boolean): void;
        setOnGroundWithKnownMovement($$0: boolean, $$1: Vec3d_): void;
        getFluidFallingAdjustedMovement($$0: number, $$1: boolean, $$2: Vec3d_): Vec3d;
        setOldPosAndRot(): void;
        localvar$cjk000$bettertridents$doHurtTarget$modifyVariable$store(damageAmount: number, entity: Internal.Entity_): number;
        isFree($$0: number, $$1: number, $$2: number): boolean;
        getDismountPoses(): Internal.ImmutableList<Internal.Pose>;
        getLastHurtMobTimestamp(): number;
        lithiumOnEquipmentChanged(): void;
        "moveTo(double,double,double)"($$0: number, $$1: number, $$2: number): void;
        setRemainingFireTicks($$0: number): void;
        emf$age(): number;
        etf$hasCustomName(): boolean;
        /**
         * @deprecated
        */
        getOnPosLegacy(): BlockPos;
        port_lib$isJumping(): boolean;
        setPos($$0: Vec3d_): void;
        localvar$leb000$puzzleslib$knockback$2(ratioX: number): number;
        static "tickEntity(net.minecraft.world.entity.LivingEntity)"(entity: Internal.LivingEntity_): void;
        updateCachedSouls(): void;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        setCanPickUpLoot($$0: boolean): void;
        getMainHandItem(): Internal.ItemStack;
        handler$kom000$porting_lib_entity$port_lib$removeRidingEntity(ci: Internal.CallbackInfo_): void;
        setSilent($$0: boolean): void;
        captureDrops(): Internal.Collection<Internal.ItemEntity>;
        hasExactlyOnePlayerPassenger(): boolean;
        canBeSeenAsEnemy(): boolean;
        setLeftHanded($$0: boolean): void;
        getActiveEffects(): Internal.Collection<Internal.MobEffectInstance>;
        isOnPortalCooldown(): boolean;
        hurtArmor($$0: DamageSource_, $$1: number): void;
        canAttack($$0: Internal.LivingEntity_, $$1: Internal.TargetingConditions_): boolean;
        getAttributeValue($$0: Internal.Holder_<Internal.Attribute>): number;
        lambdynlights$setTrackedLitChunkPos(trackedLitChunkPos: Internal.LongSet_): void;
        fzzy_core_setModifierContainer(container: Internal.ModifierContainer_): void;
        setPitch($$0: number): void;
        setPosRaw($$0: number, $$1: number, $$2: number): void;
        handleEntityEvent($$0: number): void;
        isUsingItem(): boolean;
        isAlwaysTicking(): boolean;
        interactAt($$0: Internal.Player_, $$1: Vec3d_, $$2: Internal.InteractionHand_): Internal.InteractionResult;
        getBreedOffspring($$0: Internal.ServerLevel_, $$1: Internal.AgeableMob_): this;
        emf$getX(): number;
        puzzleslib$acceptCapturedDrops(capturedDrops: Internal.Collection_<any>): Internal.Collection<any>;
        handler$hak000$gobber2$gobberIsFireImmune(cir: Internal.CallbackInfoReturnable_<any>): void;
        lerpTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: boolean): void;
        onPassengerTurned($$0: Internal.Entity_): void;
        modifyReturnValue$zhe000$additionalentityattributes$getMaxAir(original: number): number;
        spawnAtLocation($$0: Internal.ItemLike_): Internal.ItemEntity;
        emf$hasPassengers(): boolean;
        serializeNBT(): Internal.CompoundTag;
        setAttached(type: Internal.AttachmentType_<any>, value: any): any;
        port_lib$getEntityString(): string;
        markEffectsDirty(): void;
        lithiumOnBlockCacheDeleted(): void;
        "spawnAtLocation(net.minecraft.world.level.ItemLike,int)"($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        setInvulnerable($$0: boolean): void;
        push($$0: Internal.Entity_): void;
        emf$hasVehicle(): boolean;
        canMate($$0: Internal.Animal_): boolean;
        method_5992($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        maxUpStep(): number;
        getDynamicLightPrevY(): number;
        localvar$leb000$puzzleslib$hurt$1(amount: number, source: DamageSource_): number;
        setGlowing($$0: boolean): void;
        load($$0: Internal.CompoundTag_): void;
        "broadcastBreakEvent(net.minecraft.world.entity.EquipmentSlot)"($$0: Internal.EquipmentSlot_): void;
        setLeashedTo($$0: Internal.Entity_, $$1: boolean): void;
        isAlive(): boolean;
        startSleeping($$0: BlockPos_): void;
        getBbHeight(): number;
        getMeleeAttackRangeSqr($$0: Internal.LivingEntity_): number;
        handler$fed002$extraalchemy$readNbt(tag: Internal.CompoundTag_, cb: Internal.CallbackInfo_): void;
        bookshelf$getDrinkingSound(arg0: Internal.ItemStack_): Internal.SoundEvent;
        getTags(): Internal.Set<string>;
        getViewVector($$0: number): Vec3d;
        getLastAttacker(): Internal.LivingEntity;
        hasControllingPassenger(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number, $$2: number): boolean;
        absMoveTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        getLastRollTicks(): number;
        getGoalSelector(): Internal.GoalSelector;
        localvar$leb000$puzzleslib$causeFallDamage$2(damageMultiplier: number): number;
        onPathfindingStart(): void;
        handler$zzb000$porting_lib_attributes$port_lib$entityGravity(travelVector: Vec3d_, ci: Internal.CallbackInfo_): void;
        getPercentFrozen(): number;
        setPortalCooldown($$0: number): void;
        hasGlowingTag(): boolean;
        shouldBlockExplode($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: number): boolean;
        emf$isInvisible(): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        isLeashed(): boolean;
        addEffect($$0: Internal.MobEffectInstance_): boolean;
        emf$isSprinting(): boolean;
        handler$leb000$puzzleslib$knockback$0(strength: number, ratioX: number, ratioZ: number, callback: Internal.CallbackInfo_): void;
        getVariant(): any;
        ageUp($$0: number, $$1: boolean): void;
        handler$egi000$collective$LivingEntity_tick(ci: Internal.CallbackInfo_): void;
        handler$gec000$faster_entity_animations$getLeaningPitch(f: number, info: Internal.CallbackInfoReturnable_<any>): void;
        canRiderInteract(): boolean;
        getViewXRot($$0: number): number;
        handler$leb001$puzzleslib$die(damageSource: DamageSource_, callback: Internal.CallbackInfo_): void;
        fabric_getAttachments(): Internal.Map<any, any>;
        setPose($$0: Internal.Pose_): void;
        getReachDistance(): number;
        getEntityType(): Internal.EntityType<any>;
        isWaterCreature(): boolean;
        hex$playHurtSound(arg0: DamageSource_): void;
        pehkui_getScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        toString(): string;
        etf$getScoreboardTeam(): Internal.Team;
        getBreedOffspring(arg0: Internal.ServerLevel_, arg1: Internal.AgeableMob_): Internal.AgeableMob;
        setLastHurtByPlayer($$0: Internal.Player_): void;
        handler$ldh000$puzzleslib$removeVehicle(callback: Internal.CallbackInfo_): void;
        "getServer()"(): Internal.MinecraftServer;
        wasExperienceConsumed(): boolean;
        isPushable(): boolean;
        setYBodyRot($$0: number): void;
        foodEaten(is: Internal.ItemStack_): void;
        onClientRemoval(): void;
        getDistance(x: number, y: number, z: number): number;
        setMotionY(y: number): void;
        static createAttributes(): Internal.AttributeSupplier$Builder;
        localvar$lcp000$puzzleslib$spawnChildFromBreeding(child: Internal.AgeableMob_, serverLevel: Internal.ServerLevel_, partner: Internal.Animal_): Internal.AgeableMob;
        getAttached(type: Internal.AttachmentType_<any>): any;
        setRotation(yaw: number, pitch: number): void;
        isDynamicLightEnabled(): boolean;
        handler$ldh000$puzzleslib$startRiding(vehicle: Internal.Entity_, force: boolean, callback: Internal.CallbackInfoReturnable_<any>): void;
        getBreedOffspring(arg0: Internal.ServerLevel_, arg1: Internal.AgeableMob_): Internal.Cow;
        calculateEntityAnimation($$0: boolean): void;
        forceAddEffect($$0: Internal.MobEffectInstance_, $$1: Internal.Entity_): void;
        setChestArmorItem(item: Internal.ItemStack_): void;
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        bookshelf$getHurtSound(arg0: DamageSource_): Internal.SoundEvent;
        onAboveBubbleCol($$0: boolean): void;
        archon$setOwner(uiud: string): void;
        "playSound(net.minecraft.sounds.SoundEvent,float,float)"($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        toComponentPacket(key: Internal.ComponentKey_<any>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        isPassenger(): boolean;
        hasPose($$0: Internal.Pose_): boolean;
        supp$setSlimedTicks(newSlimedTicks: number, sync: boolean): void;
        isEyeInFluid($$0: Internal.TagKey_<Internal.Fluid>): boolean;
        isInvulnerableTo($$0: DamageSource_): boolean;
        makeStuckInBlock($$0: Internal.BlockState_, $$1: Vec3d_): void;
        getAttachedOrGet<A>(type: Internal.AttachmentType_<A>, defaultValue: Internal.Supplier_<A>): A;
        isSensitiveToWater(): boolean;
        skipAttackInteraction($$0: Internal.Entity_): boolean;
        lerpMotion($$0: number, $$1: number, $$2: number): void;
        "getAttributeValue(net.minecraft.core.Holder)"($$0: Internal.Holder_<Internal.Attribute>): number;
        shouldRender($$0: number, $$1: number, $$2: number): boolean;
        getJumpControl(): Internal.JumpControl;
        localvar$zcl000$porting_lib_base$port_lib$setSlipperiness(p: number): number;
        "getBreedOffspring(net.minecraft.server.level.ServerLevel,net.minecraft.world.entity.AgeableMob)"(arg0: Internal.ServerLevel_, arg1: Internal.AgeableMob_): Internal.Cow;
        getFeetArmorItem(): Internal.ItemStack;
        handler$bia000$axiom$onTurn(d: number, e: number, ci: Internal.CallbackInfo_): void;
        static getViewScale(): number;
        handler$mpg000$tcdcommons$onAddStatusEffect(effect: Internal.MobEffectInstance_, source: Internal.Entity_, ci: Internal.CallbackInfoReturnable_<any>): void;
        getVisualRotationYInDegrees(): number;
        setSpeed($$0: number): void;
        requiresCustomPersistence(): boolean;
        handler$nbm000$things$onShieldHit(attacker: Internal.LivingEntity_, ci: Internal.CallbackInfo_): void;
        isDiscrete(): boolean;
        unRide(): void;
        getLevel(): Internal.Level;
        "spawnAtLocation(net.minecraft.world.item.ItemStack)"($$0: Internal.ItemStack_): Internal.ItemEntity;
        getCombatTracker(): Internal.CombatTracker;
        updateDynamicGameEventListener($$0: Internal.BiConsumer_<Internal.DynamicGameEventListener<any>, Internal.ServerLevel>): void;
        static checkMushroomSpawnRules($$0: Internal.EntityType_<Internal.MushroomCow>, $$1: Internal.LevelAccessor_, $$2: Internal.MobSpawnType_, $$3: BlockPos_, $$4: Internal.RandomSource_): boolean;
        canBreed(): boolean;
        "onSyncedDataUpdated(net.minecraft.network.syncher.EntityDataAccessor)"($$0: Internal.EntityDataAccessor_<any>): void;
        emf$prevY(): number;
        isNoAi(): boolean;
        extinguishFire(): void;
        getChestArmorItem(): Internal.ItemStack;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number): void;
        port_lib$lastPos(): BlockPos;
        tell(message: net.minecraft.network.chat.Component_): void;
        closerThan($$0: Internal.Entity_, $$1: number): boolean;
        hex$getSoundVolume(): number;
        getDistanceSq(pos: BlockPos_): number;
        indicateDamage($$0: number, $$1: number): void;
        localvar$nbm000$things$waxGlandWater(j: number): number;
        canBeSeenByAnyone(): boolean;
        emf$getTypeString(): string;
        setVariant(arg0: any): void;
        isFullyFrozen(): boolean;
        litematica_setWorld(arg0: Internal.Level_): void;
        isInWall(): boolean;
        getAllSlots(): Internal.Iterable<Internal.ItemStack>;
        handler$bfg003$artifacts$tick(ci: Internal.CallbackInfo_): void;
        remove($$0: Internal.Entity$RemovalReason_): void;
        getScale(): number;
        isSuppressingSlidingDownLadder(): boolean;
        getBlockZ(): number;
        handler$egi000$collective$LivingEntity_die(damageSource: DamageSource_, ci: Internal.CallbackInfo_): void;
        dampensVibrations(): boolean;
        hasAttached(type: Internal.AttachmentType_<any>): boolean;
        isSilent(): boolean;
        setUseItem(arg0: Internal.ItemStack_): void;
        "playSound(net.minecraft.sounds.SoundEvent)"(id: Internal.SoundEvent_): void;
        getPitch(): number;
        getPathfindingMalus($$0: Internal.BlockPathTypes_): number;
        modify$nbm000$things$waxGlandLava(speed: number): number;
        getRandom(): Internal.RandomSource;
        canReplaceEqualItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        rotate($$0: Internal.Rotation_): number;
        handler$hcn000$hexcasting$onThunderHit(entityType: Internal.EntityType_<any>, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        getPassengersAndSelf(): Internal.Stream<any>;
        handler$leb000$puzzleslib$causeFallDamage$0(distance: number, damageMultiplier: number, damageSource: DamageSource_, callback: Internal.CallbackInfoReturnable_<any>): void;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        "getAttributeBaseValue(net.minecraft.core.Holder)"($$0: Internal.Holder_<Internal.Attribute>): number;
        method_5652($$0: Internal.CompoundTag_): void;
        clearRestriction(): void;
        redirect$jgg000$moonlight$fixSpawnAnimX(instance: Internal.Mob_, v: number): number;
        getOriginalFoodStack(): Internal.ItemStack;
        getAge(): number;
        rayTrace(): Internal.RayTraceResultJS;
        alwaysAccepts(): boolean;
        "isHolding(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.ItemStack>): boolean;
        getNoActionTime(): number;
        isVisuallyCrawling(): boolean;
        isAggressive(): boolean;
        setYya($$0: number): void;
        setDropChance($$0: Internal.EquipmentSlot_, $$1: number): void;
        handler$ieb000$lambdynlights$onRemove(ci: Internal.CallbackInfo_): void;
        "broadcastBreakEvent(net.minecraft.world.InteractionHand)"($$0: Internal.InteractionHand_): void;
        port_lib$setRemovalReason(arg0: Internal.Entity$RemovalReason_): void;
        teleportRelative($$0: number, $$1: number, $$2: number): void;
        isFood($$0: Internal.ItemStack_): boolean;
        setBaby($$0: boolean): void;
        getLastHurtByMob(): Internal.LivingEntity;
        pehkui_setScaleCache(scaleCache: Internal.ScaleData_[]): void;
        isInWaterOrBubble(): boolean;
        botania_setLoveCause(arg0: Internal.UUID_): void;
        getPortalCooldown(): number;
        getItem(): Internal.ItemStack;
        causeFallDamage($$0: number, $$1: number, $$2: DamageSource_): boolean;
        getDynamicLightChunksToRebuild(forced: boolean): Internal.LongSet;
        releaseUsingItem(): void;
        bw_getNextAirOnLand(arg0: number): number;
        getPosition($$0: number): Vec3d;
        removeFreeWill(): void;
        handler$leb000$puzzleslib$removeAllEffects(callback: Internal.CallbackInfoReturnable_<any>): void;
        getEffectDuration(): number;
        removeWhenFarAway($$0: number): boolean;
        wait(arg0: number): void;
        isIgnoringBlockTriggers(): boolean;
        setRecordPlayingNearby($$0: BlockPos_, $$1: boolean): void;
        etf$getItemsEquipped(): Internal.Iterable<any>;
        getHandHoldingItemAngle($$0: Internal.Item_): Vec3d;
        hasItemInSlot($$0: Internal.EquipmentSlot_): boolean;
        distanceToSqr($$0: Vec3d_): number;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        "getBreedOffspring(net.minecraft.server.level.ServerLevel,net.minecraft.world.entity.AgeableMob)"($$0: Internal.ServerLevel_, $$1: Internal.AgeableMob_): this;
        modifyAttached<A>(type: Internal.AttachmentType_<A>, modifier: Internal.UnaryOperator_<A>): A;
        isSteppingCarefully(): boolean;
        handler$zno000$apoli$doSpiderClimbing(info: Internal.CallbackInfoReturnable_<any>): void;
        "spawnAtLocation(net.minecraft.world.item.ItemStack,float)"($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        getBlockX(): number;
        /**
         * @deprecated
        */
        getLightLevelDependentMagicValue(): number;
        isFallFlying(): boolean;
        getEncodeId(): string;
        puzzleslib$getSpawnType(): Internal.MobSpawnType;
        bettertrims$setAvoidedDamage(avoidDamage: boolean): void;
        getY($$0: number): number;
        emf$prevPitch(): number;
        getMaxHeadXRot(): number;
        getNbt(): Internal.CompoundTag;
        setInvisible($$0: boolean): void;
        etf$getArmorItems(): Internal.Iterable<any>;
        isSubmergedInLoosely(tag: Internal.TagKey_<any>): boolean;
        getEffect($$0: Internal.MobEffect_): Internal.MobEffectInstance;
        setTotalMovementSpeedMultiplier(speed: number): void;
        getDynamicLightY(): number;
        setHealth($$0: number): void;
        attack($$0: DamageSource_, $$1: number): boolean;
        onInsideBubbleColumn($$0: boolean): void;
        handler$cfa000$betterend$be_hurt(source: DamageSource_, amount: number, info: Internal.CallbackInfoReturnable_<any>): void;
        getEyePosition(): Vec3d;
        getEyeHeight(): number;
        setDiscardFriction($$0: boolean): void;
        hasPassenger($$0: Internal.Predicate_<Internal.Entity>): boolean;
        bettertridents$getLastDamageSource(): DamageSource;
        getYaw(): number;
        swing($$0: Internal.InteractionHand_, $$1: boolean): void;
        getUsedItemHand(): Internal.InteractionHand;
        setDefaultMovementSpeed(speed: number): void;
        canAttackType($$0: Internal.EntityType_<any>): boolean;
        hex$setLastDamageStamp(arg0: number): void;
        canEntityBeSeen(entity: Internal.LivingEntity_): boolean;
        modifyExpressionValue$zhf000$additionalentityattributes$additionalEntityAttributes$knockDownwards(original: number): number;
        getBrain(): Internal.Brain<any>;
        modify$bpk000$bclib$be_travel(moveDelta: Vec3d_): Vec3d;
        setCustomNameVisible($$0: boolean): void;
        isAlliedTo($$0: Internal.Team_): boolean;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>): A;
        canFireProjectileWeapon($$0: Internal.ProjectileWeaponItem_): boolean;
        getControllingPassenger(): Internal.LivingEntity;
        bw_getNextAirUnderwater(arg0: number): number;
        getScriptType(): Internal.ScriptType;
        handler$leb000$puzzleslib$releaseUsingItem(callback: Internal.CallbackInfo_): void;
        handler$cbm000$besmirchment$handleStatus(status: number, ci: Internal.CallbackInfo_): void;
        port_lib$getDeathSound(): Internal.SoundEvent;
        shouldDiscardFriction(): boolean;
        startRiding($$0: Internal.Entity_): boolean;
        saveWithoutId($$0: Internal.CompoundTag_): Internal.CompoundTag;
        getForward(): Vec3d;
        setFeetArmorItem(item: Internal.ItemStack_): void;
        getId(): number;
        pehkui_isFirstUpdate(): boolean;
        canBeHitByProjectile(): boolean;
        getRecipientsForComponentSync(): Internal.Iterable<any>;
        handler$zcl000$porting_lib_base$port_lib$onUsingTick(ci: Internal.CallbackInfo_): void;
        getEyeY(): number;
        handler$ham000$gobber2$gobberClimbing(cir: Internal.CallbackInfoReturnable_<any>): void;
        skipDropExperience(): void;
        fabric_readAttachmentsFromNbt(nbt: Internal.CompoundTag_): void;
        localvar$leb000$puzzleslib$getVisibilityPercent(value: number, lookingEntity: Internal.Entity_): number;
        getBoundingBox(): Internal.AABB;
        isInWaterOrRain(): boolean;
        handler$leb000$puzzleslib$die$1(damageSource: DamageSource_, callback: Internal.CallbackInfo_): void;
        setItemSlot($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_): void;
        equals($$0: any): boolean;
        getViewYRot($$0: number): number;
        fabric_setCustomTeleportTarget(teleportTarget: Internal.PortalInfo_): void;
        dismountsUnderwater(): boolean;
        isAffectedByPotions(): boolean;
        playerTouch($$0: Internal.Player_): void;
        addTag($$0: string): boolean;
        getEyeHeight($$0: Internal.Pose_): number;
        getAddEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>;
        callIsBeingRainedOn(): boolean;
        static getEquipmentForSlot($$0: Internal.EquipmentSlot_, $$1: number): Internal.Item;
        isWithinRestriction($$0: BlockPos_): boolean;
        getTeam(): Internal.Team;
        static of(entity: Internal.LivingEntity_): Internal.EntityProperties;
        setTicksFrozen($$0: number): void;
        getUseItem(): Internal.ItemStack;
        getMyRidingOffset(): number;
        handler$hal000$gobber2$gobberCanBreatheInWater(cir: Internal.CallbackInfoReturnable_<any>): void;
        dismountTo($$0: number, $$1: number, $$2: number): void;
        etf$getEntityKey(): string;
        etf$getPose(): Internal.Pose;
        hasCustomName(): boolean;
        getSwimAmount($$0: number): number;
        isLiving(): boolean;
        getX(): number;
        isVehicle(): boolean;
        static transfer(original: Internal.AttachmentTarget_, target: Internal.AttachmentTarget_, isDeath: boolean): void;
        bettertrims$didAvoidDamage(): boolean;
        resetDynamicLight(): void;
        handler$han000$gobber2$gobberSetTarget(target: Internal.LivingEntity_, ci: Internal.CallbackInfo_): void;
        handler$kpc001$porting_lib_entity$onJump(ci: Internal.CallbackInfo_): void;
        spawnAtLocation($$0: Internal.ItemStack_): Internal.ItemEntity;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        thunderHit($$0: Internal.ServerLevel_, $$1: Internal.LightningBolt_): void;
        handler$zcl000$porting_lib_base$port_lib$canBeAffected(effect: Internal.MobEffectInstance_, cir: Internal.CallbackInfoReturnable_<any>): void;
        setIsInPowderSnow($$0: boolean): void;
        etf$distanceTo(entity: Internal.Entity_): number;
        doEnchantDamageEffects($$0: Internal.LivingEntity_, $$1: Internal.Entity_): void;
        setCustomName($$0: net.minecraft.network.chat.Component_): void;
        lambdynlights$scheduleTrackedChunksRebuild(renderer: Internal.LevelRenderer_): void;
        handler$hak000$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        getTeamId(): string;
        setStingerCount($$0: number): void;
        getMaxHeadYRot(): number;
        isCustomNameVisible(): boolean;
        isSupportedBy($$0: BlockPos_): boolean;
        getPistonPushReaction(): Internal.PushReaction;
        lookAt($$0: Internal.EntityAnchorArgument$Anchor_, $$1: Vec3d_): void;
        handler$kpc000$porting_lib_entity$port_lib$cancelFall(fallDistance: number, multiplier: number, source: DamageSource_, cir: Internal.CallbackInfoReturnable_<any>): void;
        hurtCurrentlyUsedShield($$0: number): void;
        getLootTableSeed(): number;
        collide($$0: Vec3d_): Vec3d;
        getMotionX(): number;
        "onSyncedDataUpdated(java.util.List)"($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        canBeLeashed($$0: Internal.Player_): boolean;
        hasIndirectPassenger($$0: Internal.Entity_): boolean;
        gear_core_setActiveSets(sets: Internal.HashMap_<any, any>): void;
        getEntityData(): Internal.SynchedEntityData;
        bookshelf$getFallDamageSound(arg0: number): Internal.SoundEvent;
        handleInsidePortal($$0: BlockPos_): void;
        getPotionEffects(): Internal.EntityPotionEffectsJS;
        getLastHurtByPlayerTime(): number;
        absMoveTo($$0: number, $$1: number, $$2: number): void;
        handler$cfa000$betterend$be_canBeAffected(mobEffectInstance: Internal.MobEffectInstance_, info: Internal.CallbackInfoReturnable_<any>): void;
        isOnRails(): boolean;
        getAttachedOrThrow<A>(type: Internal.AttachmentType_<A>): A;
        getStingerCount(): number;
        "setVariant(net.minecraft.world.entity.animal.MushroomCow$MushroomType)"($$0: Internal.MushroomCow$MushroomType_): void;
        markFusionRecomputeModels(): void;
        getFallSounds(): Internal.LivingEntity$Fallsounds;
        getAttributeTotalValue(attribute: Internal.Attribute_): number;
        getDimensionChangingDelay(): number;
        handler$cbi000$besmirchment$getScoreboardTeam(cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDynamicLuminance(): number;
        setYaw($$0: number): void;
        getPickRadius(): number;
        isPathFinding(): boolean;
        supp$getSlimedTicks(): number;
        isRemoved(): boolean;
        emf$isSneaking(): boolean;
        teleportToWithTicket($$0: number, $$1: number, $$2: number): void;
        spawnAnim(): void;
        getJumpBoostPower(): number;
        fillCrashReportCategory($$0: Internal.CrashReportCategory_): void;
        self(): Internal.Entity;
        refreshDimensions(): void;
        pehkui_writeScaleNbt(nbt: Internal.CompoundTag_): Internal.CompoundTag;
        bookshelf$getAmbientSound(): Internal.SoundEvent;
        "getAttributeValue(net.minecraft.world.entity.ai.attributes.Attribute)"($$0: Internal.Attribute_): number;
        "spawnAtLocation(net.minecraft.world.level.ItemLike)"($$0: Internal.ItemLike_): Internal.ItemEntity;
        "isHolding(net.minecraft.world.item.Item)"($$0: Internal.Item_): boolean;
        setShiftKeyDown($$0: boolean): void;
        getEyePosition($$0: number): Vec3d;
        getPassengers(): Internal.EntityArrayList;
        handler$ldh000$puzzleslib$spawnAtLocation(stack: Internal.ItemStack_, offsetY: number, callback: Internal.CallbackInfoReturnable_<any>, itemEntity: Internal.ItemEntity_): void;
        getZ(): number;
        bettertrims$applyCelestialToAttackCooldown(original: number): number;
        teleportTo($$0: number, $$1: number, $$2: number): void;
        handler$zbk000$porting_lib_base$port_lib$spawnSprintParticle(ci: Internal.CallbackInfo_, pos: BlockPos_, state: Internal.BlockState_): void;
        getAttributeBaseValue($$0: Internal.Holder_<Internal.Attribute>): number;
        getServer(): Internal.MinecraftServer;
        getExperienceReward(): number;
        getFirstPassenger(): Internal.Entity;
        heal($$0: number): void;
        handler$leb01a$puzzleslib$tick(callback: Internal.CallbackInfo_): void;
        setLastHurtMob($$0: Internal.Entity_): void;
        setLastHurtByMob($$0: Internal.LivingEntity_): void;
        interact($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        getDismountLocationForPassenger($$0: Internal.LivingEntity_): Vec3d;
        checkSlowFallDistance(): void;
        getLeashingEntities(): Internal.Set<any>;
        canStandOnFluid($$0: Internal.FluidState_): boolean;
        setFabricBalmData(tag: Internal.CompoundTag_): void;
        touchingUnloadedChunk(): boolean;
        modifyAttribute(attribute: Internal.Attribute_, identifier: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getLookAngle(): Vec3d;
        modifyReturnValue$zhf000$additionalentityattributes$additionalEntityAttributes$modifyJumpVelocity(original: number): number;
        getAmbientSoundInterval(): number;
        emf$isOnFire(): boolean;
        setArrowCount($$0: number): void;
        getMotionZ(): number;
        isPersistenceRequired(): boolean;
        isInvisible(): boolean;
        is($$0: Internal.Entity_): boolean;
        getBedOrientation(): Internal.Direction;
        ejectPassengers(): void;
        removeEffect($$0: Internal.MobEffect_): boolean;
        updateDynamicLightPreviousCoordinates(): void;
        getProfile(): Internal.GameProfile;
        setInLove($$0: Internal.Player_): void;
        isDeadOrDying(): boolean;
        setHeadArmorItem(item: Internal.ItemStack_): void;
        static setViewScale($$0: number): void;
        emf$isAlive(): boolean;
        take($$0: Internal.Entity_, $$1: number): void;
        setLevelCallback($$0: Internal.EntityInLevelCallback_): void;
        getLookControl(): Internal.LookControl;
        redirect$joh000$origins$method_26317Proxy(entity: Internal.LivingEntity_, d: number, bl: boolean, vec3d: Vec3d_): Vec3d;
        playSound($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        canAttack($$0: Internal.LivingEntity_): boolean;
        static getSpeedUpSecondsWhenFeeding($$0: number): number;
        getEffect(): Internal.MobEffect;
        getOffHandItem(): Internal.ItemStack;
        startSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isOnScoreboardTeam(teamId: string): boolean;
        startUsingItem($$0: Internal.InteractionHand_): void;
        invokePlayEquipmentBreakEffects(arg0: Internal.ItemStack_): void;
        localvar$bbb000$architectury$modifyLevelCallback_setLevelCallback(callback: Internal.EntityInLevelCallback_): Internal.EntityInLevelCallback;
        position(): Vec3d;
        setTimeout(): void;
        static getEquipmentSlotForItem($$0: Internal.ItemStack_): Internal.EquipmentSlot;
        getEquipment(slot: Internal.EquipmentSlot_): Internal.ItemStack;
        displayFireAnimation(): boolean;
        isOutOfCamera(): boolean;
        getRopeHoldPosition($$0: number): Vec3d;
        copyPosition($$0: Internal.Entity_): void;
        "hasPassenger(net.minecraft.world.entity.Entity)"($$0: Internal.Entity_): boolean;
        extraalchemy_spawnParticles(arg0: Internal.ItemStack_, arg1: number): void;
        etf$canBeBright(): boolean;
        isCrouching(): boolean;
        "getAttributeBaseValue(net.minecraft.world.entity.ai.attributes.Attribute)"($$0: Internal.Attribute_): number;
        readyForShearing(): boolean;
        onLeaveCombat(): void;
        wrapOperation$bgd000$artifacts$travel(block: Internal.Block_, original: Internal.Operation_<any>): number;
        setY(y: number): void;
        getAttributeValue($$0: Internal.Attribute_): number;
        getFeetBlockState(): Internal.BlockState;
        archon$isOwner(player: Internal.Player_): boolean;
        isWithinRestriction(): boolean;
        getChangeListener(): Internal.EntityInLevelCallback;
        positionRider($$0: Internal.Entity_): void;
        baseTick(): void;
        broadcastToPlayer($$0: Internal.ServerPlayer_): boolean;
        setSharedFlag($$0: number, $$1: boolean): void;
        getSleepingPos(): Optional<BlockPos>;
        damageHeldItem(): void;
        getCustomName(): net.minecraft.network.chat.Component;
        setEffect(arg0: Internal.MobEffect_): void;
        getClass(): typeof any;
        isVisuallySwimming(): boolean;
        getMaxAirSupply(): number;
        handler$zcl000$porting_lib_base$port_lib$addEffect(newEffect: Internal.MobEffectInstance_, source: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>, oldEffect: Internal.MobEffectInstance_): void;
        setItemInHand($$0: Internal.InteractionHand_, $$1: Internal.ItemStack_): void;
        dynamicLightTick(): void;
        setMaxHealth(hp: number): void;
        getFacing(): Internal.Direction;
        emf$isWet(): boolean;
        isPassengerOfSameVehicle($$0: Internal.Entity_): boolean;
        getBoundingBoxForCulling(): Internal.AABB;
        setAge($$0: number): void;
        getTarget(): Internal.LivingEntity;
        static collideBoundingBox(entity: Internal.Entity_, movement: Vec3d_, entityBoundingBox: Internal.AABB_, world: Internal.Level_, collisions: Internal.List_<any>): Vec3d;
        fzzy_core_getModifierContainer(): Internal.ModifierContainer;
        restrictTo($$0: BlockPos_, $$1: number): void;
        isInLove(): boolean;
        trackingPosition(): Vec3d;
        getNameTagOffsetY(): number;
        isInvulnerable(): boolean;
        isInLava(): boolean;
        isInWater(): boolean;
        awardKillScore($$0: Internal.Entity_, $$1: number, $$2: DamageSource_): void;
        finalizeSpawn($$0: Internal.ServerLevelAccessor_, $$1: Internal.DifficultyInstance_, $$2: Internal.MobSpawnType_, $$3: Internal.SpawnGroupData_, $$4: Internal.CompoundTag_): Internal.SpawnGroupData;
        localvar$leb000$puzzleslib$knockback$3(ratioZ: number): number;
        unsetRemoved(): void;
        pehkui_getScaleCache(): Internal.ScaleData[];
        swing($$0: Internal.InteractionHand_): void;
        hasEffect($$0: Internal.MobEffect_): boolean;
        getHeldItem(hand: Internal.InteractionHand_): Internal.ItemStack;
        setFusionModel(layerIndex: number, model: Internal.Triple_<any, any, any>): void;
        getRootVehicle(): Internal.Entity;
        onPathfindingDone(): void;
        save($$0: Internal.CompoundTag_): boolean;
        archon$setLifetime(seconds: number): void;
        modify$zhf000$additionalentityattributes$additionalEntityAttributes$waterSpeed(original: number): number;
        getLocalBoundsForPose($$0: Internal.Pose_): Internal.AABB;
        isNoGravity(): boolean;
        dodge(chance: number): boolean;
        onItemPickup($$0: Internal.ItemEntity_): void;
        hex$setLastDamageSource(arg0: DamageSource_): void;
        emf$getY(): number;
        handler$kom000$porting_lib_entity$port_lib$entityInit(entityType: Internal.EntityType_<any>, world: Internal.Level_, ci: Internal.CallbackInfo_): void;
        resetLove(): void;
        bookshelf$createHoverEvent(): Internal.HoverEvent;
        updateSwimming(): void;
        isHolding($$0: Internal.Predicate_<Internal.ItemStack>): boolean;
        getSpeed(): number;
        abstract getCachedFeetBlockState(): Internal.BlockState;
        shouldInformAdmins(): boolean;
        rideTick(): void;
        port_lib$onEffectRemoved(arg0: Internal.MobEffectInstance_): void;
        handler$zll000$amethyst_imbuement$onAttackWhilstStunnedNoTarget(hand: Internal.InteractionHand_, ci: Internal.CallbackInfo_): void;
        wait(): void;
        getUuid(): Internal.UUID;
        setOffHandItem(item: Internal.ItemStack_): void;
        spawn(): void;
        setNoAi($$0: boolean): void;
        teleportTo($$0: Internal.ServerLevel_, $$1: number, $$2: number, $$3: number, $$4: Internal.Set_<Internal.RelativeMovement>, $$5: number, $$6: number): boolean;
        etf$getCustomName(): net.minecraft.network.chat.Component;
        fabric_writeAttachmentsToNbt(nbt: Internal.CompoundTag_): void;
        shouldShowName(): boolean;
        getArmorSlots(): Internal.Iterable<Internal.ItemStack>;
        canPickUpLoot(): boolean;
        kill(): void;
        onEnterCombat(): void;
        updateNavigationRegistration(): void;
        animateHurt($$0: number): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        handler$kom000$porting_lib_entity$port_lib$onEntityRemove(reason: Internal.Entity$RemovalReason_, ci: Internal.CallbackInfo_): void;
        static resetForwardDirectionOfRelativePortalPosition($$0: Vec3d_): Vec3d;
        callGetEyeHeight(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        hasRestriction(): boolean;
        getHeadArmorItem(): Internal.ItemStack;
        deserializeNBT(arg0: Internal.Tag_): void;
        getCurrentModifyFoodPowers(): Internal.List<any>;
        getBbWidth(): number;
        splitIntoDynamicLightEntries(): Internal.Stream<Internal.SpatialLookupEntry>;
        addDeltaMovement($$0: Vec3d_): void;
        pehkui_setOnGround(onGround: boolean): void;
        localvar$leb000$puzzleslib$knockback$1(strength: number): number;
        bettertrims$addLateAttributes(adder: Internal.Consumer_<any>): void;
        handler$lef000$puzzleslib$readAdditionalSaveData(compound: Internal.CompoundTag_, callback: Internal.CallbackInfo_): void;
        sendLeashState(): void;
        "getName()"(): net.minecraft.network.chat.Component;
        mirror($$0: Internal.Mirror_): number;
        static port_lib$collideWithShapes(vec3: Vec3d_, aABB: Internal.AABB_, list: Internal.List_<Internal.VoxelShape>): Vec3d;
        knockback($$0: number, $$1: number, $$2: number): void;
        getTicksRequiredToFreeze(): number;
        getVisibilityPercent($$0: Internal.Entity_): number;
        getMaxSpawnClusterSize(): number;
        localvar$kpc000$porting_lib_entity$port_lib$modifyDistance(fallDistance: number): number;
        artifacts$getPocketPistonLength(): number;
        emf$prevZ(): number;
        getUsername(): string;
        getInLoveTime(): number;
        move($$0: Internal.MoverType_, $$1: Vec3d_): void;
        "setVariant(java.lang.Object)"(arg0: any): void;
        lithiumOnBlockCacheSet(newState: Internal.BlockState_): void;
        isPickable(): boolean;
        setYHeadRot($$0: number): void;
        setJumping($$0: boolean): void;
        getCustomData(): Internal.CompoundTag;
        handler$zno000$apoli$getGroup(info: Internal.CallbackInfoReturnable_<any>): void;
        getPickResult(): Internal.ItemStack;
        "getMainHandItem()"(): Internal.ItemStack;
        getAbsorptionAmount(): number;
        getRandomY(): number;
        onEffectRemoved($$0: Internal.MobEffectInstance_): void;
        getDisplayName(): net.minecraft.network.chat.Component;
        static "tickEntity(net.minecraft.world.entity.Entity)"(entity: Internal.Entity_): void;
        getMobType(): Internal.MobType;
        travel($$0: Vec3d_): void;
        "getVariant()"(): Internal.MushroomCow$MushroomType;
        getItemInHand($$0: Internal.InteractionHand_): Internal.ItemStack;
        localvar$leb000$puzzleslib$hurt$0(amount: number, source: DamageSource_): number;
        getDynamicLightPrevX(): number;
        shouldBeSaved(): boolean;
        fabric_hasPersistentAttachments(): boolean;
        method_5749($$0: Internal.CompoundTag_): void;
        hurtHelmet($$0: DamageSource_, $$1: number): void;
        removeTag($$0: string): boolean;
        isHoldingInAnyHand(i: Internal.Ingredient_): boolean;
        getFluidHeight($$0: Internal.TagKey_<Internal.Fluid>): number;
        canSpawnSoulSpeedParticle(): boolean;
        notifyAll(): void;
        aiStep(): void;
        handler$leb000$puzzleslib$removeEffect(effect: Internal.MobEffect_, callback: Internal.CallbackInfoReturnable_<any>): void;
        getPassengersRidingOffset(): number;
        setAttributeBaseValue(attribute: Internal.Attribute_, value: number): void;
        distanceToEntitySqr($$0: Internal.Entity_): number;
        isFrame(): boolean;
        broadcastBreakEvent($$0: Internal.InteractionHand_): void;
        setLegsArmorItem(item: Internal.ItemStack_): void;
        localvar$leb000$puzzleslib$causeFallDamage$1(fallDistance: number): number;
        discard(): void;
        "handler$mhe000$step-height-entity-attribute$getStepHeight"(cir: Internal.CallbackInfoReturnable_<any>): void;
        sendSystemMessage($$0: net.minecraft.network.chat.Component_): void;
        acceptsSuccess(): boolean;
        getVariant(): Internal.MushroomCow$MushroomType;
        static tickEntity(entity: Internal.LivingEntity_): void;
        setNoGravity($$0: boolean): void;
        getUseItemRemainingTicks(): number;
        gear_core_getActiveSets(): Internal.HashMap<any, any>;
        getIndirectPassengers(): Internal.Iterable<any>;
        attackable(): boolean;
        createCommandSourceStack(): Internal.CommandSourceStack;
        getNavigation(): Internal.PathNavigation;
        isControlledByLocalInstance(): boolean;
        isMonster(): boolean;
        pehkui_setShouldSyncScales(sync: boolean): void;
        handler$cbm000$besmirchment$canTarget(type: Internal.EntityType_<any>, cir: Internal.CallbackInfoReturnable_<any>): void;
        getLoveCause(): Internal.ServerPlayer;
        getLastClimbablePos(): Optional<BlockPos>;
        getEatingSound($$0: Internal.ItemStack_): Internal.SoundEvent;
        setLastDynamicLuminance(luminance: number): void;
        getPerceivedTargetDistanceSquareForMeleeAttack($$0: Internal.LivingEntity_): number;
        setId($$0: number): void;
        onSyncedDataUpdated($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        getHorizontalFacing(): Internal.Direction;
        getType(): string;
        static checkAnimalSpawnRules($$0: Internal.EntityType_<Internal.Animal>, $$1: Internal.LevelAccessor_, $$2: Internal.MobSpawnType_, $$3: BlockPos_, $$4: Internal.RandomSource_): boolean;
        isDamageSourceBlocked($$0: DamageSource_): boolean;
        getLightProbePosition($$0: number): Vec3d;
        getActiveEffectsMap(): Internal.Map<Internal.MobEffect, Internal.MobEffectInstance>;
        wrapOperation$mac000$smarterfarmers$smarterFarmers$overrideMobGriefing(instance: Internal.GameRules_, key: Internal.GameRules$Key_<any>, original: Internal.Operation_<any>): boolean;
        emf$prevX(): number;
        onEquipItem($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_, $$2: Internal.ItemStack_): void;
        checkDespawn(): void;
        pehkui_shouldSyncScales(): boolean;
        getWalkTargetValue($$0: BlockPos_, $$1: Internal.LevelReader_): number;
        lookAt($$0: Internal.Entity_, $$1: number, $$2: number): void;
        setHeldItem(hand: Internal.InteractionHand_, item: Internal.ItemStack_): void;
        port_lib$maybeDisableShield(arg0: Internal.Player_, arg1: Internal.ItemStack_, arg2: Internal.ItemStack_): void;
        equipItemIfPossible($$0: Internal.ItemStack_): Internal.ItemStack;
        onSyncedDataUpdated($$0: Internal.EntityDataAccessor_<any>): void;
        lerpHeadTo($$0: number, $$1: number): void;
        canDisableShield(): boolean;
        setMotionX(x: number): void;
        getHandSlots(): Internal.Iterable<Internal.ItemStack>;
        distanceToEntity($$0: Internal.Entity_): number;
        bookshelf$getDeathSound(): Internal.SoundEvent;
        wait(arg0: number, arg1: number): void;
        getTeamColor(): number;
        lithiumSetClimbingMobCachingSectionUpdateBehavior(listenForCachedBlockChanges: boolean): void;
        setNbt(nbt: Internal.CompoundTag_): void;
        lambdynlights$getTrackedLitChunkPos(): Internal.LongSet;
        checkSpawnObstruction($$0: Internal.LevelReader_): boolean;
        getRecallPosition(): Internal.DimensionalPosition;
        extinguish(): void;
        setDynamicLightEnabled(enabled: boolean): void;
        getRestrictRadius(): number;
        moveTo($$0: Vec3d_): void;
        isColliding($$0: BlockPos_, $$1: Internal.BlockState_): boolean;
        "swing(net.minecraft.world.InteractionHand)"($$0: Internal.InteractionHand_): void;
        lambdynlights$updateDynamicLight(renderer: Internal.LevelRenderer_): boolean;
        getRegisteredNavigation(): Internal.PathNavigation;
        bettertrims$isWearing(effect: Internal.TrimEffect_): boolean;
        static port_lib$collideWithShapes$porting_lib_accessors_$md$424943$0(arg0: Vec3d_, arg1: Internal.AABB_, arg2: Internal.List_<any>): Vec3d;
        isForcedVisible(): boolean;
        isInvertedHealAndHarm(): boolean;
        handler$jon000$origins$doWaterBreathing(info: Internal.CallbackInfoReturnable_<any>): void;
        canHoldItem($$0: Internal.ItemStack_): boolean;
        killedEntity($$0: Internal.ServerLevel_, $$1: Internal.LivingEntity_): boolean;
        getAttachedOrElse<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        isFreezing(): boolean;
        runCommand(command: string): number;
        hex$getDeathSound(): Internal.SoundEvent;
        setGuaranteedDrop($$0: Internal.EquipmentSlot_): void;
        setSharedFlagOnFire($$0: boolean): void;
        set defaultMovementSpeedMultiplier(speed: number)
        get suppressingBounce(): boolean
        set target($$0: Internal.LivingEntity_)
        set culled(value: boolean)
        get onFire(): boolean
        get positionCodec(): Internal.VecDeltaCodec
        set maxUpStep($$0: number)
        get fallFlyingTicks(): number
        set xxa($$0: number)
        set delayedLeashHolderId($$0: number)
        get shiftKeyDown(): boolean
        set UUID($$0: Internal.UUID_)
        set motionZ(z: number)
        get blockY(): number
        get isInsideStructureTracker(): Internal.IsInsideStructureTracker
        set playerHitTimer(arg0: number)
        get spectator(): boolean
        set mainHandItem(item: Internal.ItemStack_)
        get persistentData(): Internal.CompoundTag
        get health(): number
        get maxHealth(): number
        get registeredToWorld(): boolean
        set aggressive($$0: boolean)
        set removed($$0: Internal.Entity$RemovalReason_)
        get inWaterRainOrBubble(): boolean
        get removalReason(): Internal.Entity$RemovalReason
        set boundingBox($$0: Internal.AABB_)
        get ambientCreature(): boolean
        set zza($$0: number)
        get block(): Internal.BlockContainerJS
        get name(): net.minecraft.network.chat.Component
        get controlledVehicle(): Internal.Entity
        get armorValue(): number
        get killCredit(): Internal.LivingEntity
        get componentContainer(): Internal.ComponentContainer
        get dynamicLightPrevZ(): number
        set outOfCamera(value: boolean)
        get autoSpinAttack(): boolean
        get remainingFireTicks(): number
        get maxFallDistance(): number
        get ticksFrozen(): number
        get dynamicLightZ(): number
        get voicePitch(): number
        set statusMessage(message: net.minecraft.network.chat.Component_)
        set sleepingPos($$0: BlockPos_)
        get descending(): boolean
        get headRotSpeed(): number
        get lastHurtByPlayer(): Internal.Player
        get YHeadRot(): number
        set absorptionAmount($$0: number)
        set recallData(pos: Internal.DimensionalPosition_)
        set effectDuration(arg0: number)
        set deltaMovement($$0: Vec3d_)
        get baby(): boolean
        get culled(): boolean
        get glowing(): boolean
        get leashedByEntities(): Internal.Set<any>
        get leashOffset(): Vec3d
        get attackable(): boolean
        get underWater(): boolean
        get leashHolder(): Internal.Entity
        get sensing(): Internal.Sensing
        get legsArmorItem(): Internal.ItemStack
        get luminance(): number
        get selfAndPassengers(): Internal.Stream<any>
        get deltaMovement(): Vec3d
        get dynamicLightX(): number
        set secondsOnFire($$0: number)
        get "displayName()"(): net.minecraft.network.chat.Component
        get lootTable(): ResourceLocation
        get ticksUsingItem(): number
        get arrowCount(): number
        get moveControl(): Internal.MoveControl
        get defaultMovementSpeed(): number
        get peacefulCreature(): boolean
        set onGround($$0: boolean)
        get lastHurtByMobTimestamp(): number
        get vehicle(): Internal.Entity
        get effectiveAi(): boolean
        get stringUuid(): string
        set swimming($$0: boolean)
        get mainArm(): Internal.HumanoidArm
        get rotationVector(): Internal.Vec2
        get hurtDir(): number
        get sprinting(): boolean
        get motionY(): number
        get offhandItem(): Internal.ItemStack
        set luminance(luminance: number)
        set lootTable(arg0: ResourceLocation_)
        get lastHurtMob(): Internal.LivingEntity
        get lastDamageSource(): DamageSource
        get soundSource(): Internal.SoundSource
        set noActionTime($$0: number)
        set movementSpeedAddition(speed: number)
        get pose(): Internal.Pose
        get restrictCenter(): BlockPos
        get leftHanded(): boolean
        set z(z: number)
        get y(): number
        set currentModifyFoodPowers(powers: Internal.List_<any>)
        get blocking(): boolean
        set variant($$0: Internal.MushroomCow$MushroomType_)
        get pushedByFluid(): boolean
        set originalFoodStack(original: Internal.ItemStack_)
        get armorCoverPercentage(): number
        get airSupply(): number
        get player(): boolean
        get animal(): boolean
        get motionDirection(): Internal.Direction
        get fabricBalmData(): Internal.CompoundTag
        get commandSenderWorld(): Internal.Level
        get totalMovementSpeed(): number
        get moving(): boolean
        get attributes(): Internal.AttributeMap
        set inLoveTime($$0: number)
        get swimming(): boolean
        set sprinting($$0: boolean)
        get dynamicLightLevel(): Internal.Level
        set x(x: number)
        get portalWaitTime(): number
        get blockStateOn(): Internal.BlockState
        get fluidJumpThreshold(): number
        get cachedSouls(): number
        get "variant()"(): any
        set airSupply($$0: number)
        get onPos(): BlockPos
        get undead(): boolean
        set useItemRemaining(arg0: number)
        get targetSelector(): Internal.GoalSelector
        set registeredToWorld(navigation: Internal.PathNavigation_)
        get sleeping(): boolean
        get dismountPoses(): Internal.ImmutableList<Internal.Pose>
        get lastHurtMobTimestamp(): number
        set remainingFireTicks($$0: number)
        /**
         * @deprecated
        */
        get onPosLegacy(): BlockPos
        set pos($$0: Vec3d_)
        set canPickUpLoot($$0: boolean)
        get mainHandItem(): Internal.ItemStack
        set silent($$0: boolean)
        set leftHanded($$0: boolean)
        get activeEffects(): Internal.Collection<Internal.MobEffectInstance>
        get onPortalCooldown(): boolean
        set pitch($$0: number)
        get usingItem(): boolean
        get alwaysTicking(): boolean
        set invulnerable($$0: boolean)
        get dynamicLightPrevY(): number
        set glowing($$0: boolean)
        get alive(): boolean
        get bbHeight(): number
        get tags(): Internal.Set<string>
        get lastAttacker(): Internal.LivingEntity
        get lastRollTicks(): number
        get goalSelector(): Internal.GoalSelector
        get percentFrozen(): number
        set portalCooldown($$0: number)
        set position(block: Internal.BlockContainerJS_)
        get leashed(): boolean
        get variant(): any
        set pose($$0: Internal.Pose_)
        get reachDistance(): number
        get entityType(): Internal.EntityType<any>
        get waterCreature(): boolean
        set lastHurtByPlayer($$0: Internal.Player_)
        get "server()"(): Internal.MinecraftServer
        get pushable(): boolean
        set YBodyRot($$0: number)
        set motionY(y: number)
        get dynamicLightEnabled(): boolean
        set chestArmorItem(item: Internal.ItemStack_)
        get passenger(): boolean
        get sensitiveToWater(): boolean
        get jumpControl(): Internal.JumpControl
        get feetArmorItem(): Internal.ItemStack
        get viewScale(): number
        get visualRotationYInDegrees(): number
        set speed($$0: number)
        get discrete(): boolean
        get level(): Internal.Level
        get combatTracker(): Internal.CombatTracker
        get noAi(): boolean
        get chestArmorItem(): Internal.ItemStack
        set variant(arg0: any)
        get fullyFrozen(): boolean
        get inWall(): boolean
        get allSlots(): Internal.Iterable<Internal.ItemStack>
        get scale(): number
        get suppressingSlidingDownLadder(): boolean
        get blockZ(): number
        get silent(): boolean
        set useItem(arg0: Internal.ItemStack_)
        get pitch(): number
        get random(): Internal.RandomSource
        get passengersAndSelf(): Internal.Stream<any>
        get originalFoodStack(): Internal.ItemStack
        get age(): number
        get noActionTime(): number
        get visuallyCrawling(): boolean
        get aggressive(): boolean
        set yya($$0: number)
        set baby($$0: boolean)
        get lastHurtByMob(): Internal.LivingEntity
        get inWaterOrBubble(): boolean
        get portalCooldown(): number
        get item(): Internal.ItemStack
        get effectDuration(): number
        get ignoringBlockTriggers(): boolean
        get steppingCarefully(): boolean
        get blockX(): number
        /**
         * @deprecated
        */
        get lightLevelDependentMagicValue(): number
        get fallFlying(): boolean
        get encodeId(): string
        get maxHeadXRot(): number
        get nbt(): Internal.CompoundTag
        set invisible($$0: boolean)
        set totalMovementSpeedMultiplier(speed: number)
        get dynamicLightY(): number
        set health($$0: number)
        get eyePosition(): Vec3d
        get eyeHeight(): number
        set discardFriction($$0: boolean)
        get yaw(): number
        get usedItemHand(): Internal.InteractionHand
        set defaultMovementSpeed(speed: number)
        get brain(): Internal.Brain<any>
        set customNameVisible($$0: boolean)
        get controllingPassenger(): Internal.LivingEntity
        get scriptType(): Internal.ScriptType
        get forward(): Vec3d
        set feetArmorItem(item: Internal.ItemStack_)
        get id(): number
        get recipientsForComponentSync(): Internal.Iterable<any>
        get eyeY(): number
        get boundingBox(): Internal.AABB
        get inWaterOrRain(): boolean
        get affectedByPotions(): boolean
        get addEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>
        get team(): Internal.Team
        set ticksFrozen($$0: number)
        get useItem(): Internal.ItemStack
        get myRidingOffset(): number
        get living(): boolean
        get x(): number
        get vehicle(): boolean
        set isInPowderSnow($$0: boolean)
        set customName($$0: net.minecraft.network.chat.Component_)
        get teamId(): string
        set stingerCount($$0: number)
        get maxHeadYRot(): number
        get customNameVisible(): boolean
        get pistonPushReaction(): Internal.PushReaction
        get lootTableSeed(): number
        get motionX(): number
        get entityData(): Internal.SynchedEntityData
        get potionEffects(): Internal.EntityPotionEffectsJS
        get lastHurtByPlayerTime(): number
        get onRails(): boolean
        get stingerCount(): number
        set "variant(net.minecraft.world.entity.animal.MushroomCow$MushroomType)"($$0: Internal.MushroomCow$MushroomType_)
        get fallSounds(): Internal.LivingEntity$Fallsounds
        get dimensionChangingDelay(): number
        get lastDynamicLuminance(): number
        set yaw($$0: number)
        get pickRadius(): number
        get pathFinding(): boolean
        get removed(): boolean
        get jumpBoostPower(): number
        set shiftKeyDown($$0: boolean)
        get passengers(): Internal.EntityArrayList
        get z(): number
        get server(): Internal.MinecraftServer
        get experienceReward(): number
        get firstPassenger(): Internal.Entity
        set lastHurtMob($$0: Internal.Entity_)
        set lastHurtByMob($$0: Internal.LivingEntity_)
        get leashingEntities(): Internal.Set<any>
        set fabricBalmData(tag: Internal.CompoundTag_)
        get lookAngle(): Vec3d
        get ambientSoundInterval(): number
        set arrowCount($$0: number)
        get motionZ(): number
        get persistenceRequired(): boolean
        get invisible(): boolean
        get bedOrientation(): Internal.Direction
        get profile(): Internal.GameProfile
        set inLove($$0: Internal.Player_)
        get deadOrDying(): boolean
        set headArmorItem(item: Internal.ItemStack_)
        set viewScale($$0: number)
        set levelCallback($$0: Internal.EntityInLevelCallback_)
        get lookControl(): Internal.LookControl
        get effect(): Internal.MobEffect
        get offHandItem(): Internal.ItemStack
        get outOfCamera(): boolean
        get crouching(): boolean
        set y(y: number)
        get feetBlockState(): Internal.BlockState
        get withinRestriction(): boolean
        get changeListener(): Internal.EntityInLevelCallback
        get sleepingPos(): Optional<BlockPos>
        get customName(): net.minecraft.network.chat.Component
        set effect(arg0: Internal.MobEffect_)
        get class(): typeof any
        get visuallySwimming(): boolean
        get maxAirSupply(): number
        set maxHealth(hp: number)
        get facing(): Internal.Direction
        get boundingBoxForCulling(): Internal.AABB
        set age($$0: number)
        get target(): Internal.LivingEntity
        get inLove(): boolean
        get nameTagOffsetY(): number
        get invulnerable(): boolean
        get inLava(): boolean
        get inWater(): boolean
        get rootVehicle(): Internal.Entity
        get noGravity(): boolean
        get speed(): number
        get cachedFeetBlockState(): Internal.BlockState
        get uuid(): Internal.UUID
        set offHandItem(item: Internal.ItemStack_)
        set noAi($$0: boolean)
        get armorSlots(): Internal.Iterable<Internal.ItemStack>
        get headArmorItem(): Internal.ItemStack
        get currentModifyFoodPowers(): Internal.List<any>
        get bbWidth(): number
        get "name()"(): net.minecraft.network.chat.Component
        get ticksRequiredToFreeze(): number
        get maxSpawnClusterSize(): number
        get username(): string
        get inLoveTime(): number
        set "variant(java.lang.Object)"(arg0: any)
        get pickable(): boolean
        set YHeadRot($$0: number)
        set jumping($$0: boolean)
        get customData(): Internal.CompoundTag
        get pickResult(): Internal.ItemStack
        get "mainHandItem()"(): Internal.ItemStack
        get absorptionAmount(): number
        get randomY(): number
        get displayName(): net.minecraft.network.chat.Component
        get mobType(): Internal.MobType
        get "variant()"(): Internal.MushroomCow$MushroomType
        get dynamicLightPrevX(): number
        get passengersRidingOffset(): number
        get frame(): boolean
        set legsArmorItem(item: Internal.ItemStack_)
        get variant(): Internal.MushroomCow$MushroomType
        set noGravity($$0: boolean)
        get useItemRemainingTicks(): number
        get indirectPassengers(): Internal.Iterable<any>
        get navigation(): Internal.PathNavigation
        get controlledByLocalInstance(): boolean
        get monster(): boolean
        get loveCause(): Internal.ServerPlayer
        get lastClimbablePos(): Optional<BlockPos>
        set lastDynamicLuminance(luminance: number)
        set id($$0: number)
        get horizontalFacing(): Internal.Direction
        get type(): string
        get activeEffectsMap(): Internal.Map<Internal.MobEffect, Internal.MobEffectInstance>
        set motionX(x: number)
        get handSlots(): Internal.Iterable<Internal.ItemStack>
        get teamColor(): number
        set nbt(nbt: Internal.CompoundTag_)
        get recallPosition(): Internal.DimensionalPosition
        set dynamicLightEnabled(enabled: boolean)
        get restrictRadius(): number
        get registeredNavigation(): Internal.PathNavigation
        get forcedVisible(): boolean
        get invertedHealAndHarm(): boolean
        get freezing(): boolean
        set guaranteedDrop($$0: Internal.EquipmentSlot_)
        set sharedFlagOnFire($$0: boolean)
    }
    type MushroomCow_ = MushroomCow;
}
declare namespace com.b1n_ry.yigd.mixin.accessor {
    interface WorldRendererAccessor {
        abstract getBufferBuilders(): Internal.RenderBuffers;
        get bufferBuilders(): Internal.RenderBuffers
        (): Internal.RenderBuffers_;
    }
    type WorldRendererAccessor_ = WorldRendererAccessor | (()=> Internal.RenderBuffers_);
}
declare namespace com.klikli_dev.modonomicon.networking {
    interface Message {
        onServerReceived(minecraftServer: Internal.MinecraftServer_, player: Internal.ServerPlayer_): void;
        abstract getId(): ResourceLocation;
        onClientReceived(minecraft: Internal.Minecraft_, player: Internal.Player_): void;
        abstract encode(arg0: Internal.FriendlyByteBuf_): void;
        abstract decode(arg0: Internal.FriendlyByteBuf_): void;
        get id(): ResourceLocation
    }
    type Message_ = Message;
}
declare namespace net.fabricmc.fabric.mixin.networking.accessor {
    interface ServerPlayNetworkHandlerAccessor {
        abstract getConnection(): Internal.Connection;
        get connection(): Internal.Connection
        (): Internal.Connection_;
    }
    type ServerPlayNetworkHandlerAccessor_ = ServerPlayNetworkHandlerAccessor | (()=> Internal.Connection_);
}
declare namespace it.unimi.dsi.fastutil.longs {
    interface LongConsumer extends Internal.LongConsumer, Internal.Consumer<number> {
        /**
         * @deprecated
        */
        "andThen(java.util.function.Consumer)"(arg0: Internal.Consumer_<number>): Internal.Consumer<number>;
        andThen(arg0: Internal.LongConsumer_): Internal.LongConsumer;
        andThen(arg0: it.unimi.dsi.fastutil.longs.LongConsumer_): this;
        /**
         * @deprecated
        */
        accept(arg0: any): void;
        /**
         * @deprecated
        */
        accept(arg0: number): void;
        "andThen(java.util.function.LongConsumer)"(arg0: Internal.LongConsumer_): Internal.LongConsumer;
        /**
         * @deprecated
        */
        "accept(java.lang.Long)"(arg0: number): void;
        /**
         * @deprecated
        */
        andThen(arg0: Internal.Consumer_<number>): Internal.Consumer<number>;
        abstract accept(arg0: number): void;
        /**
         * @deprecated
        */
        "accept(java.lang.Object)"(arg0: any): void;
        abstract "accept(long)"(arg0: number): void;
        "andThen(it.unimi.dsi.fastutil.longs.LongConsumer)"(arg0: it.unimi.dsi.fastutil.longs.LongConsumer_): this;
    }
    type LongConsumer_ = LongConsumer;
}
declare namespace io.github.fabricators_of_create.porting_lib.mixin.accessors.client.accessor {
    interface ScreenAccessor {
        abstract port_lib$getMinecraft(): Internal.Minecraft;
        abstract port_lib$getChildren(): Internal.List<Internal.GuiEventListener>;
        abstract port_lib$getRenderables(): Internal.List<Internal.Renderable>;
    }
    type ScreenAccessor_ = ScreenAccessor;
}
declare namespace com.klikli_dev.modonomicon.book {
    class BookIcon {
        constructor(stack: Internal.ItemStack_)
        constructor(texture: ResourceLocation_, width: number, height: number)
        getClass(): typeof any;
        toString(): string;
        render(guiGraphics: Internal.GuiGraphics_, x: number, y: number): void;
        notifyAll(): void;
        toNetwork(buffer: Internal.FriendlyByteBuf_): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        static fromJson(jsonElement: Internal.JsonElement_): com.klikli_dev.modonomicon.book.BookIcon;
        hashCode(): number;
        wait(): void;
        static fromNetwork(buffer: Internal.FriendlyByteBuf_): com.klikli_dev.modonomicon.book.BookIcon;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        get class(): typeof any
    }
    type BookIcon_ = BookIcon;
}
