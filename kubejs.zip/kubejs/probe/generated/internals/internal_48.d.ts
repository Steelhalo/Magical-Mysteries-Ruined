/// <reference path="./internal_*.d.ts" />
declare namespace corgitaco.corgilib.world.level {
    interface RandomTickScheduler {
        abstract getScheduledRandomTicks(): Internal.List<BlockPos>;
        abstract scheduleRandomTick(arg0: BlockPos_): void;
        get scheduledRandomTicks(): Internal.List<BlockPos>
    }
    type RandomTickScheduler_ = RandomTickScheduler;
}
declare namespace Internal {
    abstract class BaseScreen extends Internal.Panel {
        constructor()
        getScrollStep(): number;
        static getClipboardString(): string;
        mousePressed(button: Internal.MouseButton_): boolean;
        getY(): number;
        closeGui(openPrevScreen: boolean): void;
        scrollPanel(scroll: number): boolean;
        getTheme(): Internal.Theme;
        mouseDragged(button: number, dragX: number, dragY: number): boolean;
        add(widget: dev.ftb.mods.ftblibrary.ui.Widget_): void;
        drawDefaultBackground(graphics: Internal.GuiGraphics_): boolean;
        isDefaultScrollVertical(): boolean;
        setPos(x: number, y: number): void;
        keyPressed(key: dev.ftb.mods.ftblibrary.ui.input.Key_): boolean;
        isGhostIngredientTarget(ingredient: any): boolean;
        getPartialTicks(): number;
        setScrollX(scroll: number): void;
        openContextMenu(menuItems: Internal.List_<Internal.ContextMenuItem>): Internal.ContextMenu;
        getWidth(): number;
        getDrawLayer(): Internal.Widget$DrawLayer;
        getContextMenu(): Optional<Internal.ModalPanel>;
        closeModalPanel(panel: Internal.ModalPanel_): void;
        isMouseOverAnyWidget(): boolean;
        keyReleased(key: dev.ftb.mods.ftblibrary.ui.input.Key_): void;
        onPostInit(): void;
        getMouseX(): number;
        "compareTo(dev.ftb.mods.ftblibrary.ui.Widget)"(widget: dev.ftb.mods.ftblibrary.ui.Widget_): number;
        static isShiftKeyDown(): boolean;
        "compareTo(java.lang.Object)"(arg0: any): number;
        static setClipboardString(string: string): void;
        shouldCloseOnEsc(): boolean;
        getClass(): typeof any;
        setScrollStep(s: number): void;
        handleClick(scheme: string, path: string): boolean;
        getX(): number;
        getParent(): Internal.Panel;
        run(): void;
        updateMouseOver(mouseX: number, mouseY: number): void;
        getPosY(): number;
        static isMouseButtonDown(button: Internal.MouseButton_): boolean;
        setOnlyRenderWidgetsInside(value: boolean): void;
        popModalPanel(): Internal.ModalPanel;
        setScrollY(scroll: number): void;
        getWidget(index: number): dev.ftb.mods.ftblibrary.ui.Widget;
        setPosAndSize(x: number, y: number, w: number, h: number): dev.ftb.mods.ftblibrary.ui.Widget;
        setWidth(v: number): void;
        getHeight(): number;
        openYesNoFull(title: net.minecraft.network.chat.Component_, desc: net.minecraft.network.chat.Component_, callback: Internal.BooleanConsumer_): void;
        charTyped(c: string, modifiers: Internal.KeyModifiers_): boolean;
        getContentHeight(): number;
        toString(): string;
        setSize(w: number, h: number): void;
        getCursor(): Internal.CursorType;
        isOffset(): boolean;
        notifyAll(): void;
        mouseReleased(button: Internal.MouseButton_): void;
        collidesWith(x: number, y: number, w: number, h: number): boolean;
        openGuiLater(): void;
        getScrollX(): number;
        getPrevScreen(): Internal.Screen;
        getOnlyInteractWithWidgetsInside(): boolean;
        checkMouseOver(mouseX: number, mouseY: number): boolean;
        isMouseOver(x: number, y: number, w: number, h: number): boolean;
        getScreen(): com.mojang.blaze3d.platform.Window;
        doesGuiPauseGame(): boolean;
        openYesNo(title: net.minecraft.network.chat.Component_, desc: net.minecraft.network.chat.Component_, callback: Internal.Runnable_): void;
        drawWidget(graphics: Internal.GuiGraphics_, theme: Internal.Theme_, widget: dev.ftb.mods.ftblibrary.ui.Widget_, x: number, y: number, w: number, h: number): void;
        openContextMenu(newContextMenu: Internal.ContextMenu_): void;
        handleClick(click: string): boolean;
        wait(arg0: number): void;
        setHeight(v: number): void;
        addMouseOverText(list: Internal.TooltipList_): void;
        shouldDraw(): boolean;
        compareTo(widget: dev.ftb.mods.ftblibrary.ui.Widget_): number;
        "openContextMenu(java.util.List)"(menuItems: Internal.List_<Internal.ContextMenuItem>): Internal.ContextMenu;
        updateGui(mx: number, my: number, pt: number): void;
        notify(): void;
        compareTo(arg0: any): number;
        getWidgets(): Internal.List<dev.ftb.mods.ftblibrary.ui.Widget>;
        getPosX(): number;
        closeGui(): void;
        openGui(): void;
        "openContextMenu(dev.ftb.mods.ftblibrary.ui.ContextMenu)"(newContextMenu: Internal.ContextMenu_): void;
        getWidgetType(): Internal.WidgetType;
        alignWidgets(): void;
        setX(v: number): void;
        clearWidgets(): void;
        setOnlyInteractWithWidgetsInside(value: boolean): void;
        anyModalPanelOpen(): boolean;
        getScrollY(): number;
        setFocusedWidget(widget: dev.ftb.mods.ftblibrary.ui.Widget_): void;
        onInit(): boolean;
        getGui(): this;
        tick(): void;
        pushModalPanel(modalPanel: Internal.ModalPanel_): void;
        onClosedByKey(key: dev.ftb.mods.ftblibrary.ui.input.Key_): boolean;
        wait(): void;
        refreshWidgets(): void;
        getTitle(): net.minecraft.network.chat.Component;
        openAfter(runnable: Internal.Runnable_): Internal.Runnable;
        draw(graphics: Internal.GuiGraphics_, theme: Internal.Theme_, x: number, y: number, w: number, h: number): void;
        getContentWidth(): number;
        drawBackground(graphics: Internal.GuiGraphics_, theme: Internal.Theme_, x: number, y: number, w: number, h: number): void;
        closeContextMenu(): void;
        mouseScrolled(scroll: number): boolean;
        shouldAddMouseOverText(): boolean;
        getIngredientUnderMouse(): Optional<Internal.PositionedIngredient>;
        wait(arg0: number, arg1: number): void;
        isEnabled(): boolean;
        setOffset(flag: boolean): void;
        movePanelScroll(dx: number, dy: number): boolean;
        setY(v: number): void;
        static isCtrlKeyDown(): boolean;
        static isKeyDown(key: number): boolean;
        abstract addWidgets(): void;
        isMouseOver(): boolean;
        playClickSound(): void;
        mouseDoubleClicked(button: Internal.MouseButton_): boolean;
        onClosed(): void;
        acceptGhostIngredient(ingredient: any): void;
        getMouseY(): number;
        drawOffsetBackground(graphics: Internal.GuiGraphics_, theme: Internal.Theme_, x: number, y: number, w: number, h: number): void;
        isMouseOver(widget: dev.ftb.mods.ftblibrary.ui.Widget_): boolean;
        hashCode(): number;
        getOnlyRenderWidgetsInside(): boolean;
        setDrawLayer(drawLayer: Internal.Widget$DrawLayer_): void;
        drawForeground(graphics: Internal.GuiGraphics_, theme: Internal.Theme_, x: number, y: number, w: number, h: number): void;
        addAll(list: Internal.Iterable_<dev.ftb.mods.ftblibrary.ui.Widget>): void;
        initGui(): void;
        align(layout: Internal.WidgetLayout_): number;
        onBack(): void;
        equals(arg0: any): boolean;
        get scrollStep(): number
        get clipboardString(): string
        get y(): number
        get theme(): Internal.Theme
        get defaultScrollVertical(): boolean
        get partialTicks(): number
        set scrollX(scroll: number)
        get width(): number
        get drawLayer(): Internal.Widget$DrawLayer
        get contextMenu(): Optional<Internal.ModalPanel>
        get mouseOverAnyWidget(): boolean
        get mouseX(): number
        get shiftKeyDown(): boolean
        set clipboardString(string: string)
        get class(): typeof any
        set scrollStep(s: number)
        get x(): number
        get parent(): Internal.Panel
        get posY(): number
        set onlyRenderWidgetsInside(value: boolean)
        set scrollY(scroll: number)
        set width(v: number)
        get height(): number
        get contentHeight(): number
        get cursor(): Internal.CursorType
        get offset(): boolean
        get scrollX(): number
        get prevScreen(): Internal.Screen
        get onlyInteractWithWidgetsInside(): boolean
        get screen(): com.mojang.blaze3d.platform.Window
        set height(v: number)
        get widgets(): Internal.List<dev.ftb.mods.ftblibrary.ui.Widget>
        get posX(): number
        get widgetType(): Internal.WidgetType
        set x(v: number)
        set onlyInteractWithWidgetsInside(value: boolean)
        get scrollY(): number
        set focusedWidget(widget: dev.ftb.mods.ftblibrary.ui.Widget_)
        get gui(): Internal.BaseScreen
        get title(): net.minecraft.network.chat.Component
        get contentWidth(): number
        get ingredientUnderMouse(): Optional<Internal.PositionedIngredient>
        get enabled(): boolean
        set offset(flag: boolean)
        set y(v: number)
        get ctrlKeyDown(): boolean
        get mouseOver(): boolean
        get mouseY(): number
        get onlyRenderWidgetsInside(): boolean
        set drawLayer(drawLayer: Internal.Widget$DrawLayer_)
    }
    type BaseScreen_ = BaseScreen;
    class IntTag extends Internal.NumericTag {
        getClass(): typeof any;
        static checkSpecialEquality(o: any, o1: any, shallow: boolean): boolean;
        "accept(net.minecraft.nbt.StreamTagVisitor)"($$0: Internal.StreamTagVisitor_): Internal.StreamTagVisitor$ValueResult;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        "accept(net.minecraft.nbt.TagVisitor)"($$0: Internal.TagVisitor_): void;
        sizeInBytes(): number;
        getAsFloat(): number;
        getAsLong(): number;
        acceptAsRoot($$0: Internal.StreamTagVisitor_): void;
        write($$0: Internal.DataOutput_): void;
        getId(): number;
        copy(): this;
        "copy()"(): this;
        toString(): string;
        notifyAll(): void;
        specialEquals(o: any, shallow: boolean): boolean;
        static valueOf($$0: number): Internal.IntTag;
        getAsDouble(): number;
        getType(): Internal.TagType<Internal.IntTag>;
        accept($$0: Internal.TagVisitor_): void;
        "copy()"(): Internal.Tag;
        getAsInt(): number;
        hashCode(): number;
        getAsString(): string;
        getAsByte(): number;
        getAsNumber(): number;
        copy(): Internal.Tag;
        wait(): void;
        wait(arg0: number): void;
        getAsShort(): number;
        equals($$0: any): boolean;
        accept($$0: Internal.StreamTagVisitor_): Internal.StreamTagVisitor$ValueResult;
        get class(): typeof any
        get asFloat(): number
        get asLong(): number
        get id(): number
        get asDouble(): number
        get type(): Internal.TagType<Internal.IntTag>
        get asInt(): number
        get asString(): string
        get asByte(): number
        get asNumber(): number
        get asShort(): number
        static readonly TYPE: Internal.TagType<Internal.IntTag>;
    }
    type IntTag_ = IntTag;
    interface SequentialBreaker {
        abstract breakOtherBlock(arg0: Internal.Player_, arg1: Internal.ItemStack_, arg2: BlockPos_, arg3: BlockPos_, arg4: Internal.Direction_): void;
        (arg0: Internal.Player, arg1: Internal.ItemStack, arg2: BlockPos, arg3: BlockPos, arg4: Internal.Direction): void;
    }
    type SequentialBreaker_ = SequentialBreaker | ((arg0: Internal.Player, arg1: Internal.ItemStack, arg2: BlockPos, arg3: BlockPos, arg4: Internal.Direction)=> void);
    interface GenerationProperties {
        abstract getFeatures(arg0: Internal.GenerationStep$Decoration_): Internal.Iterable<Internal.Holder<Internal.PlacedFeature>>;
        abstract getCarvers(arg0: Internal.GenerationStep$Carving_): Internal.Iterable<Internal.Holder<Internal.ConfiguredWorldCarver<any>>>;
        abstract getFeatures(): Internal.List<Internal.Iterable<Internal.Holder<Internal.PlacedFeature>>>;
        get features(): Internal.List<Internal.Iterable<Internal.Holder<Internal.PlacedFeature>>>
    }
    type GenerationProperties_ = GenerationProperties;
    abstract class AbstractLong2ObjectMap <V> extends Internal.AbstractLong2ObjectFunction<V> implements Internal.Serializable, Internal.Long2ObjectMap<V> {
        "replace(java.lang.Long,java.lang.Object,java.lang.Object)"(arg0: number, arg1: V, arg2: V): boolean;
        "computeIfPresent(java.lang.Long,java.util.function.BiFunction)"(arg0: number, arg1: Internal.BiFunction_<number, V, V>): V;
        "merge(long,java.lang.Object,java.util.function.BiFunction)"(arg0: number, arg1: V, arg2: Internal.BiFunction_<V, V, V>): V;
        containsValue(arg0: any): boolean;
        remove(arg0: number): V;
        "apply(java.lang.Long)"(arg0: number): V;
        composeReference<T>(arg0: Internal.Reference2LongFunction_<T>): Internal.Reference2ObjectFunction<T, V>;
        "remove(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): boolean;
        composeDouble(arg0: Internal.Double2LongFunction_): Internal.Double2ObjectFunction<V>;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V): Internal.Map<K, V>;
        "computeIfAbsent(long,it.unimi.dsi.fastutil.longs.Long2ObjectFunction)"(arg0: number, arg1: Internal.Long2ObjectFunction_<V>): V;
        andThenObject<T>(arg0: Internal.Object2ObjectFunction_<V, T>): Internal.Long2ObjectFunction<T>;
        andThenLong(arg0: Internal.Object2LongFunction_<V>): Internal.Long2LongFunction;
        "computeIfAbsent(java.lang.Long,java.util.function.Function)"(arg0: number, arg1: Internal.Function_<number, V>): V;
        /**
         * @deprecated
        */
        get(arg0: any): V;
        "computeIfPresent(long,java.util.function.BiFunction)"(arg0: number, arg1: Internal.BiFunction_<number, V, V>): V;
        /**
         * @deprecated
        */
        put(arg0: any, arg1: any): any;
        andThenFloat(arg0: Internal.Object2FloatFunction_<V>): Internal.Long2FloatFunction;
        composeLong(arg0: Internal.Long2LongFunction_): Internal.Long2ObjectFunction<V>;
        andThenShort(arg0: Internal.Object2ShortFunction_<V>): Internal.Long2ShortFunction;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V): Internal.Map<K, V>;
        merge(arg0: number, arg1: V, arg2: Internal.BiFunction_<V, V, V>): V;
        abstract "get(long)"(arg0: number): V;
        "replace(java.lang.Long,java.lang.Object)"(arg0: number, arg1: V): V;
        static ofEntries<K, V>(...arg0: Internal.Map$Entry_<K, V>[]): Internal.Map<K, V>;
        abstract defaultReturnValue(): V;
        static of<K, V>(arg0: K, arg1: V): Internal.Map<K, V>;
        /**
         * @deprecated
        */
        "containsKey(java.lang.Object)"(arg0: any): boolean;
        getClass(): typeof any;
        compute(arg0: number, arg1: Internal.BiFunction_<number, V, V>): V;
        "getOrDefault(long,java.lang.Object)"(arg0: number, arg1: V): V;
        composeShort(arg0: Internal.Short2LongFunction_): Internal.Short2ObjectFunction<V>;
        static of<K, V>(): Internal.Map<K, V>;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: V): V;
        "compute(java.lang.Long,java.util.function.BiFunction)"(arg0: number, arg1: Internal.BiFunction_<number, V, V>): V;
        andThenByte(arg0: Internal.Object2ByteFunction_<V>): Internal.Long2ByteFunction;
        put(arg0: number, arg1: V): V;
        composeFloat(arg0: Internal.Float2LongFunction_): Internal.Float2ObjectFunction<V>;
        compute(arg0: number, arg1: Internal.BiFunction_<number, V, V>): V;
        /**
         * @deprecated
        */
        remove(arg0: any): V;
        "remove(long)"(arg0: number): V;
        toString(): string;
        notifyAll(): void;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V): Internal.Map<K, V>;
        "merge(java.lang.Long,java.lang.Object,java.util.function.BiFunction)"(arg0: number, arg1: V, arg2: Internal.BiFunction_<V, V, V>): V;
        remove(arg0: any, arg1: any): boolean;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V): Internal.Map<K, V>;
        merge(arg0: number, arg1: V, arg2: Internal.BiFunction_<V, V, V>): V;
        "computeIfAbsent(long,java.util.function.LongFunction)"(arg0: number, arg1: Internal.LongFunction_<V>): V;
        abstract size(): number;
        /**
         * @deprecated
        */
        compose<T>(arg0: Internal.Function_<T, number>): Internal.Function<T, V>;
        "remove(long,java.lang.Object)"(arg0: number, arg1: any): boolean;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V, arg16: K, arg17: V): Internal.Map<K, V>;
        clear(): void;
        composeChar(arg0: Internal.Char2LongFunction_): Internal.Char2ObjectFunction<V>;
        wait(arg0: number): void;
        replace(arg0: number, arg1: V): V;
        abstract long2ObjectEntrySet(): Internal.ObjectSet<Internal.Long2ObjectMap$Entry<V>>;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V): Internal.Map<K, V>;
        andThenReference<T>(arg0: Internal.Object2ReferenceFunction_<V, T>): Internal.Long2ReferenceFunction<T>;
        replace(arg0: number, arg1: V): V;
        andThen<V>(arg0: Internal.Function_<V, V>): Internal.Function<number, V>;
        "putIfAbsent(java.lang.Long,java.lang.Object)"(arg0: number, arg1: V): V;
        "replace(long,java.lang.Object,java.lang.Object)"(arg0: number, arg1: V, arg2: V): boolean;
        composeByte(arg0: Internal.Byte2LongFunction_): Internal.Byte2ObjectFunction<V>;
        notify(): void;
        /**
         * @deprecated
        */
        "put(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): any;
        "apply(long)"(arg0: number): V;
        keySet(): Internal.Set<any>;
        "putIfAbsent(long,java.lang.Object)"(arg0: number, arg1: V): V;
        computeIfPresent(arg0: number, arg1: Internal.BiFunction_<number, V, V>): V;
        /**
         * @deprecated
        */
        put(arg0: number, arg1: V): V;
        andThenInt(arg0: Internal.Object2IntFunction_<V>): Internal.Long2IntFunction;
        "compute(long,java.util.function.BiFunction)"(arg0: number, arg1: Internal.BiFunction_<number, V, V>): V;
        static copyOf<K, V>(arg0: Internal.Map_<K, V>): Internal.Map<K, V>;
        computeIfAbsent(arg0: number, arg1: Internal.LongFunction_<V>): V;
        /**
         * @deprecated
        */
        "put(java.lang.Long,java.lang.Object)"(arg0: number, arg1: V): V;
        /**
         * @deprecated
        */
        entrySet(): Internal.Set<any>;
        computeIfPresent(arg0: number, arg1: Internal.BiFunction_<number, V, V>): V;
        apply(arg0: number): V;
        putAll(arg0: Internal.Map_<number, V>): void;
        containsKey(arg0: number): boolean;
        composeObject<T>(arg0: Internal.Object2LongFunction_<T>): Internal.Object2ObjectFunction<T, V>;
        "replace(long,java.lang.Object)"(arg0: number, arg1: V): V;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V): Internal.Map<K, V>;
        composeInt(arg0: Internal.Int2LongFunction_): Internal.Int2ObjectFunction<V>;
        wait(): void;
        putIfAbsent(arg0: number, arg1: V): V;
        getOrDefault(arg0: number, arg1: V): V;
        static identity<T>(): Internal.Function<T, T>;
        abstract defaultReturnValue(arg0: V): void;
        remove(arg0: number, arg1: any): boolean;
        forEach(arg0: Internal.BiConsumer_<number, V>): void;
        "put(long,java.lang.Object)"(arg0: number, arg1: V): V;
        /**
         * @deprecated
        */
        "getOrDefault(java.lang.Object,java.lang.Object)"(arg0: any, arg1: V): V;
        "containsKey(long)"(arg0: number): boolean;
        replace(arg0: number, arg1: V, arg2: V): boolean;
        computeIfAbsent(arg0: number, arg1: Internal.Function_<number, V>): V;
        isEmpty(): boolean;
        /**
         * @deprecated
        */
        computeIfAbsentPartial(arg0: number, arg1: Internal.Long2ObjectFunction_<V>): V;
        static entry<K, V>(arg0: K, arg1: V): Internal.Map$Entry<K, V>;
        wait(arg0: number, arg1: number): void;
        replace(arg0: number, arg1: V, arg2: V): boolean;
        /**
         * @deprecated
        */
        containsKey(arg0: any): boolean;
        computeIfAbsent(arg0: number, arg1: Internal.Long2ObjectFunction_<V>): V;
        apply(arg0: number): V;
        replaceAll(arg0: Internal.BiFunction_<number, V, V>): void;
        /**
         * @deprecated
        */
        "get(java.lang.Object)"(arg0: any): V;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V): Internal.Map<K, V>;
        andThenDouble(arg0: Internal.Object2DoubleFunction_<V>): Internal.Long2DoubleFunction;
        values(): Internal.ObjectCollection<V>;
        abstract get(arg0: number): V;
        hashCode(): number;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V, arg16: K, arg17: V, arg18: K, arg19: V): Internal.Map<K, V>;
        equals(arg0: any): boolean;
        andThenChar(arg0: Internal.Object2CharFunction_<V>): Internal.Long2CharFunction;
        putIfAbsent(arg0: number, arg1: V): V;
        /**
         * @deprecated
        */
        "remove(java.lang.Object)"(arg0: any): V;
        get class(): typeof any
        get empty(): boolean
    }
    type AbstractLong2ObjectMap_<V> = AbstractLong2ObjectMap<V>;
    class EntityComponentProviderBuilder extends Internal.ToggleableProviderBuilder {
        constructor(uniqueIdentifier: ResourceLocation_)
        getClass(): typeof any;
        setEnabledByDefault(enabledByDefault: boolean): Internal.ToggleableProviderBuilder;
        tooltipRetriever(tooltipRetriever: Internal.EntityComponentProviderBuilder$TooltipRetriever_): this;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        setTooltipRetriever(tooltipRetriever: Internal.EntityComponentProviderBuilder$TooltipRetriever_): this;
        isRequired(): boolean;
        setRequired(isRequired: boolean): Internal.ToggleableProviderBuilder;
        required(): Internal.ToggleableProviderBuilder;
        icon(iconRetriever: Internal.EntityComponentProviderBuilder$IconRetriever_): this;
        toString(): string;
        setIconRetriever(iconRetriever: Internal.EntityComponentProviderBuilder$IconRetriever_): this;
        notifyAll(): void;
        getTooltipRetriever(): Internal.EntityComponentProviderBuilder$TooltipRetriever;
        iconRetriever(iconRetriever: Internal.EntityComponentProviderBuilder$IconRetriever_): this;
        isEnabledByDefault(): boolean;
        setDefaultPriority(priority: number): Internal.JadeProviderBuilder;
        getDefaultPriority(): number;
        tooltip(tooltipRetriever: Internal.EntityComponentProviderBuilder$TooltipRetriever_): this;
        hashCode(): number;
        wait(): void;
        getUniqueIdentifier(): ResourceLocation;
        getIconRetriever(): Internal.EntityComponentProviderBuilder$IconRetriever;
        wait(arg0: number): void;
        enabledByDefault(): Internal.ToggleableProviderBuilder;
        equals(arg0: any): boolean;
        get class(): typeof any
        set enabledByDefault(enabledByDefault: boolean)
        set tooltipRetriever(tooltipRetriever: Internal.EntityComponentProviderBuilder$TooltipRetriever_)
        get required(): boolean
        set required(isRequired: boolean)
        set iconRetriever(iconRetriever: Internal.EntityComponentProviderBuilder$IconRetriever_)
        get tooltipRetriever(): Internal.EntityComponentProviderBuilder$TooltipRetriever
        get enabledByDefault(): boolean
        set defaultPriority(priority: number)
        get defaultPriority(): number
        get uniqueIdentifier(): ResourceLocation
        get iconRetriever(): Internal.EntityComponentProviderBuilder$IconRetriever
    }
    type EntityComponentProviderBuilder_ = EntityComponentProviderBuilder;
    class SinglePoolElement extends Internal.StructurePoolElement implements dev.worldgen.lithostitched.mixin.common.SinglePoolElementAccessor, Internal.WaystoneStructurePoolElement, Internal.SinglePoolElementAccessor {
        constructor($$0: Internal.Either_<ResourceLocation, Internal.StructureTemplate>, $$1: Internal.Holder_<Internal.StructureProcessorList>, $$2: Internal.StructureTemplatePool$Projection_)
        handler$ndg000$waystones$place(structureTemplateManager: Internal.StructureTemplateManager_, worldGenLevel: Internal.WorldGenLevel_, structureManager: Internal.StructureManager_, chunkGenerator: Internal.ChunkGenerator_, pos: BlockPos_, blockPos2: BlockPos_, rotation: Internal.Rotation_, boundingBox: Internal.BoundingBox_, randomSource: Internal.RandomSource_, bl: boolean, callbackInfo: Internal.CallbackInfoReturnable_<any>): void;
        getBoundingBox($$0: Internal.StructureTemplateManager_, $$1: BlockPos_, $$2: Internal.Rotation_): Internal.BoundingBox;
        getClass(): typeof any;
        getProcessors(): Internal.Holder<any>;
        notify(): void;
        getGroundLevelDelta(): number;
        wait(arg0: number, arg1: number): void;
        place($$0: Internal.StructureTemplateManager_, $$1: Internal.WorldGenLevel_, $$2: Internal.StructureManager_, $$3: Internal.ChunkGenerator_, $$4: BlockPos_, $$5: BlockPos_, $$6: Internal.Rotation_, $$7: Internal.BoundingBox_, $$8: Internal.RandomSource_, $$9: boolean): boolean;
        callGetTemplate(arg0: Internal.StructureTemplateManager_): Internal.StructureTemplate;
        getDataMarkers($$0: Internal.StructureTemplateManager_, $$1: BlockPos_, $$2: Internal.Rotation_, $$3: boolean): Internal.List<Internal.StructureTemplate$StructureBlockInfo>;
        static list($$0: Internal.List_<Internal.Function<Internal.StructureTemplatePool$Projection, Internal.StructurePoolElement>>): Internal.Function<Internal.StructureTemplatePool$Projection, Internal.ListPoolElement>;
        getProjection(): Internal.StructureTemplatePool$Projection;
        static empty(): Internal.Function<Internal.StructureTemplatePool$Projection, Internal.EmptyPoolElement>;
        static legacy($$0: string, $$1: Internal.Holder_<Internal.StructureProcessorList>): Internal.Function<Internal.StructureTemplatePool$Projection, Internal.LegacySinglePoolElement>;
        getType(): Internal.StructurePoolElementType<any>;
        toString(): string;
        getShuffledJigsawBlocks($$0: Internal.StructureTemplateManager_, $$1: BlockPos_, $$2: Internal.Rotation_, $$3: Internal.RandomSource_): Internal.List<Internal.StructureTemplate$StructureBlockInfo>;
        waystones$isWaystone(): boolean;
        static single($$0: string): Internal.Function<Internal.StructureTemplatePool$Projection, Internal.SinglePoolElement>;
        notifyAll(): void;
        handleDataMarker($$0: Internal.LevelAccessor_, $$1: Internal.StructureTemplate$StructureBlockInfo_, $$2: BlockPos_, $$3: Internal.Rotation_, $$4: Internal.RandomSource_, $$5: Internal.BoundingBox_): void;
        setProcessors(arg0: Internal.Holder_<any>): void;
        getSize($$0: Internal.StructureTemplateManager_, $$1: Internal.Rotation_): Vec3i;
        setProjection($$0: Internal.StructureTemplatePool$Projection_): Internal.StructurePoolElement;
        hashCode(): number;
        static legacy($$0: string): Internal.Function<Internal.StructureTemplatePool$Projection, Internal.LegacySinglePoolElement>;
        wait(): void;
        waystones$setIsWaystone(isWaystone: boolean): void;
        getTemplate(): Internal.Either<any, any>;
        wait(arg0: number): void;
        static single($$0: string, $$1: Internal.Holder_<Internal.StructureProcessorList>): Internal.Function<Internal.StructureTemplatePool$Projection, Internal.SinglePoolElement>;
        equals(arg0: any): boolean;
        static feature($$0: Internal.Holder_<Internal.PlacedFeature>): Internal.Function<Internal.StructureTemplatePool$Projection, Internal.FeaturePoolElement>;
        get class(): typeof any
        get processors(): Internal.Holder<any>
        get groundLevelDelta(): number
        get projection(): Internal.StructureTemplatePool$Projection
        get type(): Internal.StructurePoolElementType<any>
        set processors(arg0: Internal.Holder_<any>)
        set projection($$0: Internal.StructureTemplatePool$Projection_)
        get template(): Internal.Either<any, any>
        static readonly CODEC: Internal.Codec<Internal.SinglePoolElement>;
    }
    type SinglePoolElement_ = SinglePoolElement;
    class AnimationApplier extends Internal.AnimationProcessor {
        constructor(animation: Internal.IAnimation_)
        getClass(): typeof any;
        getFirstPersonMode(): Internal.FirstPersonMode;
        updatePart(partName: string, part: Internal.ModelPart_): void;
        toString(): string;
        notifyAll(): void;
        getBend(modelName: string): Internal.Pair<number, number>;
        isFirstPersonAnimationDisabled(): boolean;
        isActive(): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        tick(): void;
        getFirstPersonConfiguration(): Internal.FirstPersonConfiguration;
        hashCode(): number;
        setTickDelta(tickDelta: number): void;
        wait(): void;
        wait(arg0: number): void;
        get3DTransform(modelName: string, type: Internal.TransformType_, value0: Internal.Vec3f_): Internal.Vec3f;
        equals(arg0: any): boolean;
        get class(): typeof any
        get firstPersonMode(): Internal.FirstPersonMode
        get firstPersonAnimationDisabled(): boolean
        get active(): boolean
        get firstPersonConfiguration(): Internal.FirstPersonConfiguration
        set tickDelta(tickDelta: number)
    }
    type AnimationApplier_ = AnimationApplier;
    class TaggedChoice$TaggedChoiceType <K> extends com.mojang.datafixers.types.Type<com.mojang.datafixers.util.Pair<K, any>> implements Internal.TaggedChoiceTypeExtension {
        constructor(arg0: string, arg1: com.mojang.datafixers.types.Type_<K>, arg2: Internal.Object2ObjectMap_<K, com.mojang.datafixers.types.Type<any>>)
        getKeyType(): com.mojang.datafixers.types.Type<K>;
        getSetType<FT, FR>(arg0: Internal.OpticFinder_<FT>, arg1: com.mojang.datafixers.types.Type_<FR>): com.mojang.datafixers.types.Type<any>;
        ifSame<B>(arg0: com.mojang.datafixers.types.Type_<B>, arg1: B): Optional<com.mojang.datafixers.util.Pair<K, any>>;
        static elementResult<K, FT, FR>(arg0: K, arg1: Internal.TaggedChoice$TaggedChoiceType_<K>, arg2: Internal.RewriteResult_<FT, FR>): Internal.RewriteResult<com.mojang.datafixers.util.Pair<K, any>, com.mojang.datafixers.util.Pair<K, any>>;
        codec(): Internal.Codec<com.mojang.datafixers.util.Pair<K, any>>;
        notify(): void;
        readTyped<T>(arg0: Internal.Dynamic_<T>): Internal.DataResult<com.mojang.datafixers.util.Pair<Internal.Typed<com.mojang.datafixers.util.Pair<K, any>>, T>>;
        findTypeInChildren<FT, FR>(arg0: com.mojang.datafixers.types.Type_<FT>, arg1: com.mojang.datafixers.types.Type_<FR>, arg2: Internal.Type$TypeMatcher_<FT, FR>, arg3: boolean): Internal.Either<Internal.TypedOptic<com.mojang.datafixers.util.Pair<K, any>, any, FT, FR>, Internal.Type$FieldNotFoundException>;
        ifSame<B>(arg0: Internal.Typed_<B>): Optional<com.mojang.datafixers.util.Pair<K, any>>;
        static unbox<A>(arg0: Internal.App_<Internal.Type$Mu, A>): com.mojang.datafixers.types.Type<A>;
        findTypeCached<FT, FR>(arg0: com.mojang.datafixers.types.Type_<FT>, arg1: com.mojang.datafixers.types.Type_<FR>, arg2: Internal.Type$TypeMatcher_<FT, FR>, arg3: boolean): Internal.Either<Internal.TypedOptic<com.mojang.datafixers.util.Pair<K, any>, any, FT, FR>, Internal.Type$FieldNotFoundException>;
        "ifSame(com.mojang.datafixers.types.Type,com.mojang.datafixers.RewriteResult)"<B>(arg0: com.mojang.datafixers.types.Type_<B>, arg1: Internal.RewriteResult_<B, any>): Optional<Internal.RewriteResult<com.mojang.datafixers.util.Pair<K, any>, any>>;
        rewrite(arg0: Internal.TypeRewriteRule_, arg1: Internal.PointFreeRule_): Optional<Internal.RewriteResult<com.mojang.datafixers.util.Pair<K, any>, any>>;
        read<T>(arg0: Internal.DynamicOps_<T>, arg1: Internal.TypeRewriteRule_, arg2: Internal.PointFreeRule_, arg3: T): Internal.DataResult<com.mojang.datafixers.util.Pair<Optional<any>, T>>;
        write<T>(arg0: Internal.DynamicOps_<T>, arg1: com.mojang.datafixers.util.Pair_<K, any>): Internal.DataResult<T>;
        pointTyped(arg0: Internal.DynamicOps_<any>): Optional<Internal.Typed<com.mojang.datafixers.util.Pair<K, any>>>;
        rewriteOrNop(arg0: Internal.TypeRewriteRule_): Internal.RewriteResult<com.mojang.datafixers.util.Pair<K, any>, any>;
        ifSame<B>(arg0: com.mojang.datafixers.types.Type_<B>, arg1: Internal.RewriteResult_<B, any>): Optional<Internal.RewriteResult<com.mojang.datafixers.util.Pair<K, any>, any>>;
        wait(): void;
        point(arg0: Internal.DynamicOps_<any>, arg1: K, arg2: any): Optional<Internal.Typed<com.mojang.datafixers.util.Pair<K, any>>>;
        readTyped<T>(arg0: Internal.DynamicOps_<T>, arg1: T): Internal.DataResult<com.mojang.datafixers.util.Pair<Internal.Typed<com.mojang.datafixers.util.Pair<K, any>>, T>>;
        buildTemplate(): Internal.TypeTemplate;
        getClass(): typeof any;
        findChoiceType(arg0: string, arg1: number): Optional<Internal.TaggedChoice$TaggedChoiceType<any>>;
        read<T>(arg0: Internal.Dynamic_<T>): Internal.DataResult<com.mojang.datafixers.util.Pair<com.mojang.datafixers.util.Pair<K, any>, Internal.Dynamic<T>>>;
        all(arg0: Internal.TypeRewriteRule_, arg1: boolean, arg2: boolean): Internal.RewriteResult<com.mojang.datafixers.util.Pair<K, any>, any>;
        wait(arg0: number, arg1: number): void;
        readAndWrite<T>(arg0: Internal.DynamicOps_<T>, arg1: com.mojang.datafixers.types.Type_<any>, arg2: Internal.TypeRewriteRule_, arg3: Internal.PointFreeRule_, arg4: T): Internal.DataResult<T>;
        findField(arg0: string): Internal.OpticFinder<any>;
        getName(): string;
        equals(arg0: any, arg1: boolean, arg2: boolean): boolean;
        "ifSame(com.mojang.datafixers.types.Type,java.lang.Object)"<B>(arg0: com.mojang.datafixers.types.Type_<B>, arg1: B): Optional<com.mojang.datafixers.util.Pair<K, any>>;
        writeDynamic<T>(arg0: Internal.DynamicOps_<T>, arg1: com.mojang.datafixers.util.Pair_<K, any>): Internal.DataResult<Internal.Dynamic<T>>;
        static opticView<S, T, A, B>(arg0: com.mojang.datafixers.types.Type_<S>, arg1: Internal.RewriteResult_<A, B>, arg2: Internal.TypedOptic_<S, T, A, B>): Internal.RewriteResult<S, T>;
        finder(): Internal.OpticFinder<com.mojang.datafixers.util.Pair<K, any>>;
        toString(): string;
        everywhere(arg0: Internal.TypeRewriteRule_, arg1: Internal.PointFreeRule_, arg2: boolean, arg3: boolean): Optional<Internal.RewriteResult<com.mojang.datafixers.util.Pair<K, any>, any>>;
        notifyAll(): void;
        fabric$setFailSoft(cond: boolean): void;
        findCheckedType(arg0: number): Optional<com.mojang.datafixers.types.Type<any>>;
        point(arg0: Internal.DynamicOps_<any>): Optional<com.mojang.datafixers.util.Pair<K, any>>;
        hasType(arg0: K): boolean;
        findFieldTypeOpt(arg0: string): Optional<com.mojang.datafixers.types.Type<any>>;
        hashCode(): number;
        findType<FT, FR>(arg0: com.mojang.datafixers.types.Type_<FT>, arg1: com.mojang.datafixers.types.Type_<FR>, arg2: Internal.Type$TypeMatcher_<FT, FR>, arg3: boolean): Internal.Either<Internal.TypedOptic<com.mojang.datafixers.util.Pair<K, any>, any, FT, FR>, Internal.Type$FieldNotFoundException>;
        findFieldType(arg0: string): com.mojang.datafixers.types.Type<any>;
        wait(arg0: number): void;
        types(): Internal.Map<K, com.mojang.datafixers.types.Type<any>>;
        one(arg0: Internal.TypeRewriteRule_): Optional<Internal.RewriteResult<com.mojang.datafixers.util.Pair<K, any>, any>>;
        equals(arg0: any): boolean;
        updateMu(arg0: Internal.RecursiveTypeFamily_): com.mojang.datafixers.types.Type<any>;
        template(): Internal.TypeTemplate;
        get keyType(): com.mojang.datafixers.types.Type<K>
        get class(): typeof any
        get name(): string
    }
    type TaggedChoice$TaggedChoiceType_<K> = TaggedChoice$TaggedChoiceType<K>;
    class LevelType extends Internal.Enum<Internal.LevelType> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getDeclaringClass(): typeof Internal.LevelType;
        getClass(): typeof any;
        "compareTo(com.mojang.realmsclient.util.LevelType)"(arg0: Internal.LevelType_): number;
        getName(): net.minecraft.network.chat.Component;
        toString(): string;
        notifyAll(): void;
        compareTo(arg0: Internal.LevelType_): number;
        static values(): Internal.LevelType[];
        notify(): void;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.LevelType>>;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        name(): string;
        getDtoIndex(): number;
        hashCode(): number;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        static valueOf($$0: string): Internal.LevelType;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        get declaringClass(): typeof Internal.LevelType
        get class(): typeof any
        get name(): net.minecraft.network.chat.Component
        get dtoIndex(): number
        static readonly AMPLIFIED: (Internal.LevelType) & (Internal.LevelType);
        static readonly DEFAULT: (Internal.LevelType) & (Internal.LevelType);
        static readonly LARGE_BIOMES: (Internal.LevelType) & (Internal.LevelType);
        static readonly FLAT: (Internal.LevelType) & (Internal.LevelType);
    }
    type LevelType_ = "flat" | LevelType | "large_biomes" | "amplified" | "default";
    class CarvingMaskPlacement extends Internal.PlacementModifier {
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        getPositions($$0: Internal.PlacementContext_, $$1: Internal.RandomSource_, $$2: BlockPos_): Internal.Stream<BlockPos>;
        static forStep($$0: Internal.GenerationStep$Carving_): Internal.CarvingMaskPlacement;
        wait(): void;
        type(): Internal.PlacementModifierType<any>;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        static readonly CODEC: Internal.Codec<Internal.CarvingMaskPlacement>;
    }
    type CarvingMaskPlacement_ = CarvingMaskPlacement;
    interface AgeableListModelAccessor {
        abstract porting_lib$scaleHead(): boolean;
        abstract porting_lib$babyYHeadOffset(): number;
        abstract porting_lib$bodyYOffset(): number;
        abstract porting_lib$babyHeadScale(): number;
        abstract porting_lib$babyZHeadOffset(): number;
        abstract porting_lib$babyBodyScale(): number;
    }
    type AgeableListModelAccessor_ = AgeableListModelAccessor;
    class NeighborLockingManager {
        constructor()
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        releaseLock(pos: number): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        isLocked(pos: number): boolean;
        hashCode(): number;
        addReleaseListener(pos: number, runnable: Internal.Runnable_): void;
        wait(): void;
        wait(arg0: number): void;
        acquireLock(pos: number): void;
        equals(arg0: any): boolean;
        get class(): typeof any
    }
    type NeighborLockingManager_ = NeighborLockingManager;
    class Direction8 extends Internal.Enum<Internal.Direction8> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        toString(): string;
        compareTo(arg0: Internal.Direction8_): number;
        "compareTo(net.minecraft.core.Direction8)"(arg0: Internal.Direction8_): number;
        notifyAll(): void;
        static valueOf($$0: string): Internal.Direction8;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.Direction8>>;
        name(): string;
        getDirections(): Internal.Set<Internal.Direction>;
        hashCode(): number;
        getStepX(): number;
        getStepZ(): number;
        getDeclaringClass(): typeof Internal.Direction8;
        ordinal(): number;
        wait(): void;
        static values(): Internal.Direction8[];
        wait(arg0: number): void;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        get class(): typeof any
        get directions(): Internal.Set<Internal.Direction>
        get stepX(): number
        get stepZ(): number
        get declaringClass(): typeof Internal.Direction8
        static readonly NORTH_EAST: (Internal.Direction8) & (Internal.Direction8);
        static readonly EAST: (Internal.Direction8) & (Internal.Direction8);
        static readonly NORTH_WEST: (Internal.Direction8) & (Internal.Direction8);
        static readonly SOUTH_EAST: (Internal.Direction8) & (Internal.Direction8);
        static readonly SOUTH_WEST: (Internal.Direction8) & (Internal.Direction8);
        static readonly NORTH: (Internal.Direction8) & (Internal.Direction8);
        static readonly SOUTH: (Internal.Direction8) & (Internal.Direction8);
        static readonly WEST: (Internal.Direction8) & (Internal.Direction8);
    }
    type Direction8_ = "north_west" | "west" | "north_east" | "east" | "south_west" | "south" | "north" | Direction8 | "south_east";
    class XORFilterItem extends Internal.InventoryFilterItem {
        constructor()
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, world: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, flag: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getDisplayItemStacks(filter: Internal.ItemStack_, list: Internal.List_<Internal.ItemStack>): void;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        addSlots(filter: Internal.ItemStack_, list: Internal.List_<Internal.InventoryFilterItem$FilterSlot>): void;
        getInventorySize(filter: Internal.ItemStack_): number;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(world: Internal.Level_, player: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        filterItem(filter: Internal.ItemStack_, item: Internal.Item_): boolean;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        addInfo(filter: Internal.ItemStack_, info: Internal.FilterInfo_, expanded: boolean): void;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        static getInventory(stack: Internal.ItemStack_): Internal.ItemInventory;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        resetFilterData(filter: Internal.ItemStack_): void;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        filter(filter: Internal.ItemStack_, stack: Internal.ItemStack_): boolean;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick(stack: Internal.ItemStack_, level: Internal.Level_, entity: Internal.Entity_, i: number, bl: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        clearFilterCache(filter: Internal.ItemStack_): void;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type XORFilterItem_ = XORFilterItem;
    abstract class AbstractByteBufAllocator implements Internal.ByteBufAllocator {
        compositeDirectBuffer(arg0: number): Internal.CompositeByteBuf;
        getClass(): typeof any;
        compositeHeapBuffer(arg0: number): Internal.CompositeByteBuf;
        compositeBuffer(): Internal.CompositeByteBuf;
        ioBuffer(): Internal.ByteBuf;
        heapBuffer(arg0: number): Internal.ByteBuf;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        calculateNewCapacity(arg0: number, arg1: number): number;
        directBuffer(arg0: number, arg1: number): Internal.ByteBuf;
        buffer(): Internal.ByteBuf;
        toString(): string;
        compositeDirectBuffer(): Internal.CompositeByteBuf;
        heapBuffer(arg0: number, arg1: number): Internal.ByteBuf;
        notifyAll(): void;
        heapBuffer(): Internal.ByteBuf;
        ioBuffer(arg0: number): Internal.ByteBuf;
        compositeBuffer(arg0: number): Internal.CompositeByteBuf;
        directBuffer(): Internal.ByteBuf;
        abstract isDirectBufferPooled(): boolean;
        hashCode(): number;
        directBuffer(arg0: number): Internal.ByteBuf;
        ioBuffer(arg0: number, arg1: number): Internal.ByteBuf;
        buffer(arg0: number, arg1: number): Internal.ByteBuf;
        wait(): void;
        wait(arg0: number): void;
        compositeHeapBuffer(): Internal.CompositeByteBuf;
        equals(arg0: any): boolean;
        buffer(arg0: number): Internal.ByteBuf;
        get class(): typeof any
        get directBufferPooled(): boolean
    }
    type AbstractByteBufAllocator_ = AbstractByteBufAllocator;
    abstract class AbstractSwampFeature <C extends Internal.FeatureConfiguration> extends Internal.AbstractNbtFeature<C> {
        constructor(codec: Internal.Codec_<C>)
        getClass(): typeof any;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<C, Feature<C>>>;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        place($$0: C, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        abstract place(arg0: Internal.FeaturePlaceContext_<C>): boolean;
        get class(): typeof any
    }
    type AbstractSwampFeature_<C extends Internal.FeatureConfiguration> = AbstractSwampFeature<C>;
    interface DoubleToIntFunction {
        abstract applyAsInt(arg0: number): number;
        (arg0: number): number;
    }
    type DoubleToIntFunction_ = ((arg0: number)=> number) | DoubleToIntFunction;
    class RenderContext implements Internal.Cloneable {
        constructor(arg0: Internal.AffineTransform_, arg1: Internal.Shape_)
        constructor(arg0: Internal.AffineTransform_)
        constructor(arg0: Internal.AffineTransform_, arg1: Internal.RenderingHints_)
        constructor(arg0: Internal.AffineTransform_, arg1: Internal.Shape_, arg2: Internal.RenderingHints_)
        clone(): any;
        getClass(): typeof any;
        toString(): string;
        preConcatenateTransform(arg0: Internal.AffineTransform_): void;
        concatenateTransform(arg0: Internal.AffineTransform_): void;
        /**
         * @deprecated
        */
        concetenateTransform(arg0: Internal.AffineTransform_): void;
        setAreaOfInterest(arg0: Internal.Shape_): void;
        notifyAll(): void;
        getTransform(): Internal.AffineTransform;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        setTransform(arg0: Internal.AffineTransform_): void;
        /**
         * @deprecated
        */
        preConcetenateTransform(arg0: Internal.AffineTransform_): void;
        getAreaOfInterest(): Internal.Shape;
        hashCode(): number;
        setRenderingHints(arg0: Internal.RenderingHints_): void;
        wait(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        getRenderingHints(): Internal.RenderingHints;
        get class(): typeof any
        set areaOfInterest(arg0: Internal.Shape_)
        get transform(): Internal.AffineTransform
        set transform(arg0: Internal.AffineTransform_)
        get areaOfInterest(): Internal.Shape
        set renderingHints(arg0: Internal.RenderingHints_)
        get renderingHints(): Internal.RenderingHints
    }
    type RenderContext_ = RenderContext;
    interface DraggableStackVisitor$BoundsProvider extends Internal.DraggableBoundsProvider {
        concat(providers: Internal.Iterable_<Internal.DraggableStackVisitor$BoundsProvider>): this;
        ofShape(shape: Internal.VoxelShape_): this;
        fromRectangle(bounds: me.shedaniel.math.Rectangle_): Internal.VoxelShape;
        ofRectangle(bounds: me.shedaniel.math.Rectangle_): this;
        empty(): this;
        abstract bounds(): Internal.VoxelShape;
        ofShapes(shapes: Internal.Iterable_<Internal.VoxelShape>): this;
        ofRectangles(bounds: Internal.Iterable_<me.shedaniel.math.Rectangle>): this;
        (): Internal.VoxelShape_;
    }
    type DraggableStackVisitor$BoundsProvider_ = DraggableStackVisitor$BoundsProvider | (()=> Internal.VoxelShape_);
    interface Paint extends Internal.Transparency {
        abstract createContext(arg0: Internal.ColorModel_, arg1: Internal.Rectangle_, arg2: Internal.Rectangle2D_, arg3: Internal.AffineTransform_, arg4: Internal.RenderingHints_): Internal.PaintContext;
        abstract getTransparency(): number;
        get transparency(): number
    }
    type Paint_ = Paint;
    class ManaResourceItem extends Internal.Item {
        constructor(props: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn(ctx: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type ManaResourceItem_ = ManaResourceItem;
    class ScatteredOreFeature extends Feature<Internal.OreConfiguration> {
        getClass(): typeof any;
        place($$0: Internal.FeaturePlaceContext_<Internal.OreConfiguration>): boolean;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.OreConfiguration, Feature<Internal.OreConfiguration>>>;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        place($$0: Internal.OreConfiguration_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        wait(): void;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        get class(): typeof any
    }
    type ScatteredOreFeature_ = ScatteredOreFeature;
    interface SurfaceMaterialProvider {
        create(top: Internal.BlockState_, under: Internal.BlockState_, alt: Internal.BlockState_, genFloorRule: boolean): this;
        abstract getAltTopMaterial(): Internal.BlockState;
        abstract getUnderMaterial(): Internal.BlockState;
        abstract generateFloorRule(): boolean;
        abstract surface(): Internal.SurfaceRuleBuilder;
        abstract getTopMaterial(): Internal.BlockState;
        get altTopMaterial(): Internal.BlockState
        get underMaterial(): Internal.BlockState
        get topMaterial(): Internal.BlockState
        readonly CODEC: Internal.Codec<Internal.SurfaceMaterialProvider>;
    }
    type SurfaceMaterialProvider_ = SurfaceMaterialProvider;
    class AssignedSurfaceRule {
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        static readonly CODEC: Internal.Codec<Internal.AssignedSurfaceRule>;
        readonly ruleSource: Internal.SurfaceRules$RuleSource;
        readonly biomeID: ResourceLocation;
    }
    type AssignedSurfaceRule_ = Special.SurfaceRules | AssignedSurfaceRule;
    class WaterBottleMatchingRecipe extends Internal.ShapedRecipe {
        constructor(recipe: Internal.ShapedRecipe_)
        constructor(id: ResourceLocation_, group: string, category: Internal.CraftingBookCategory_, width: number, height: number, recipeItems: Internal.NonNullList_<Internal.Ingredient>, result: Internal.ItemStack_)
        getGroup(): string;
        static dissolvePattern$bookshelf_$md$424943$3(arg0: string[], arg1: Internal.Map_<any, any>, arg2: number, arg3: number): Internal.NonNullList<any>;
        getToastSymbol(): Internal.ItemStack;
        "matches(net.minecraft.world.inventory.CraftingContainer,net.minecraft.world.level.Level)"(craftingContainer: Internal.CraftingContainer_, level: Internal.Level_): boolean;
        static keyFromJson$bookshelf_$md$424943$0(arg0: Internal.JsonObject_): Internal.Map<any, any>;
        notify(): void;
        getRemainingItems($$0: Internal.CraftingContainer_): Internal.NonNullList<Internal.ItemStack>;
        assemble($$0: Internal.CraftingContainer_, $$1: Internal.RegistryAccess_): Internal.ItemStack;
        getId(): ResourceLocation;
        isIn(tag: ResourceLocation_): boolean;
        handler$bpa000$bclib$bcl_getRemainingItems(container: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>): void;
        static bookshelf$dissolvePattern(pattern: string[], ingredients: Internal.Map_<string, Internal.Ingredient>, width: number, height: number): Internal.NonNullList<Internal.Ingredient>;
        isSpecial(): boolean;
        getWidth(): number;
        "assemble(net.minecraft.world.inventory.CraftingContainer,net.minecraft.core.RegistryAccess)"($$0: Internal.CraftingContainer_, $$1: Internal.RegistryAccess_): Internal.ItemStack;
        canCraftInDimensions($$0: number, $$1: number): boolean;
        showNotification(): boolean;
        replaceInput(match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): boolean;
        static itemStackFromJson($$0: Internal.JsonObject_): Internal.ItemStack;
        getType(): ResourceLocation;
        static dissolvePattern($$0: string[], $$1: Internal.Map_<string, Internal.Ingredient>, $$2: number, $$3: number): Internal.NonNullList<Internal.Ingredient>;
        "handler$fie000$fabric-item-api-v1$captureStack"(inventory: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>, defaultedList: Internal.NonNullList_<any>, i: number): void;
        wait(): void;
        isIncomplete(): boolean;
        matches($$0: Internal.CraftingContainer_, $$1: number, $$2: number, $$3: boolean): boolean;
        getClass(): typeof any;
        static keyFromJson($$0: Internal.JsonObject_): Internal.Map<string, Internal.Ingredient>;
        matches(craftingContainer: Internal.CraftingContainer_, level: Internal.Level_): boolean;
        getSchema(): Internal.RecipeSchema;
        "assemble(net.minecraft.world.Container,net.minecraft.core.RegistryAccess)"(arg0: net.minecraft.world.Container_, arg1: Internal.RegistryAccess_): Internal.ItemStack;
        wait(arg0: number, arg1: number): void;
        category(): Internal.CraftingBookCategory;
        static shrink$bookshelf_$md$424943$1(...arg0: string[]): string[];
        getSerializer(): Internal.RecipeSerializer<any>;
        assemble(arg0: net.minecraft.world.Container_, arg1: Internal.RegistryAccess_): Internal.ItemStack;
        static bookshelf$shrink(...pattern: string[]): string[];
        static bookshelf$keyFromJson($$0: Internal.JsonObject_): Internal.Map<string, Internal.Ingredient>;
        matches(arg0: net.minecraft.world.Container_, arg1: Internal.Level_): boolean;
        getHeight(): number;
        getMod(): string;
        getIngredients(): Internal.NonNullList<Internal.Ingredient>;
        hasOutput(match: Internal.ReplacementMatch_): boolean;
        getResultItem($$0: Internal.RegistryAccess_): Internal.ItemStack;
        toString(): string;
        notifyAll(): void;
        "matches(net.minecraft.world.Container,net.minecraft.world.level.Level)"(arg0: net.minecraft.world.Container_, arg1: Internal.Level_): boolean;
        static patternFromJson($$0: Internal.JsonArray_): string[];
        static shrink(...$$0: string[]): string[];
        setGroup(group: string): void;
        static itemFromJson($$0: Internal.JsonObject_): Internal.Item;
        static bookshelf$patternFromJson(json: Internal.JsonArray_): string[];
        hashCode(): number;
        getOrCreateId(): ResourceLocation;
        hasInput(match: Internal.ReplacementMatch_): boolean;
        static patternFromJson$bookshelf_$md$424943$2(arg0: Internal.JsonArray_): string[];
        wait(arg0: number): void;
        replaceOutput(match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): boolean;
        equals(arg0: any): boolean;
        get group(): string
        get toastSymbol(): Internal.ItemStack
        get id(): ResourceLocation
        get special(): boolean
        get width(): number
        get type(): ResourceLocation
        get incomplete(): boolean
        get class(): typeof any
        get schema(): Internal.RecipeSchema
        get serializer(): Internal.RecipeSerializer<any>
        get height(): number
        get mod(): string
        get ingredients(): Internal.NonNullList<Internal.Ingredient>
        set group(group: string)
        get orCreateId(): ResourceLocation
        static readonly SERIALIZER: (Internal.WaterBottleMatchingRecipe$Serializer) & (Internal.RecipeSerializer<Internal.WaterBottleMatchingRecipe>);
    }
    type WaterBottleMatchingRecipe_ = WaterBottleMatchingRecipe;
    interface VerticalAnchor {
        aboveBottom($$0: number): this;
        absolute($$0: number): this;
        belowTop($$0: number): this;
        bottom(): this;
        top(): this;
        abstract resolveY(arg0: Internal.WorldGenerationContext_): number;
        (arg0: Internal.WorldGenerationContext): number;
        readonly BOTTOM: (Internal.VerticalAnchor$AboveBottom) & (Internal.VerticalAnchor);
        readonly CODEC: Internal.Codec<Internal.VerticalAnchor>;
        readonly TOP: (Internal.VerticalAnchor$BelowTop) & (Internal.VerticalAnchor);
    }
    type VerticalAnchor_ = ((arg0: Internal.WorldGenerationContext)=> number) | VerticalAnchor;
    abstract class Toolkit {
        getMenuShortcutKeyMaskEx(): number;
        getSystemSelection(): Internal.Clipboard;
        abstract "getImage(java.lang.String)"(arg0: string): Internal.Image;
        static getProperty(arg0: string, arg1: string): string;
        notify(): void;
        "createImage(byte[])"(arg0: number[]): Internal.Image;
        abstract mapInputMethodHighlight(arg0: Internal.InputMethodHighlight_): Internal.Map<Internal.TextAttribute, any>;
        createCustomCursor(arg0: Internal.Image_, arg1: Internal.Point_, arg2: string): Internal.Cursor;
        isDynamicLayoutActive(): boolean;
        getBestCursorSize(arg0: number, arg1: number): Internal.Dimension;
        abstract "createImage(java.lang.String)"(arg0: string): Internal.Image;
        getPropertyChangeListeners(): Internal.PropertyChangeListener[];
        abstract createImage(arg0: number[], arg1: number, arg2: number): Internal.Image;
        isAlwaysOnTopSupported(): boolean;
        abstract createImage(arg0: Internal.ImageProducer_): Internal.Image;
        areExtraMouseButtonsEnabled(): boolean;
        abstract "getImage(java.net.URL)"(arg0: Internal.URL_): Internal.Image;
        getLockingKeyState(arg0: number): boolean;
        abstract checkImage(arg0: Internal.Image_, arg1: number, arg2: number, arg3: Internal.ImageObserver_): number;
        setLockingKeyState(arg0: number, arg1: boolean): void;
        createImage(arg0: number[]): Internal.Image;
        removeAWTEventListener(arg0: Internal.AWTEventListener_): void;
        wait(): void;
        abstract createImage(arg0: string): Internal.Image;
        getScreenInsets(arg0: Internal.GraphicsConfiguration_): Internal.Insets;
        getClass(): typeof any;
        removePropertyChangeListener(arg0: string, arg1: Internal.PropertyChangeListener_): void;
        abstract getImage(arg0: Internal.URL_): Internal.Image;
        abstract "createImage(java.net.URL)"(arg0: Internal.URL_): Internal.Image;
        abstract createImage(arg0: Internal.URL_): Internal.Image;
        abstract getImage(arg0: string): Internal.Image;
        getMaximumCursorColors(): number;
        wait(arg0: number, arg1: number): void;
        /**
         * @deprecated
        */
        abstract getFontMetrics(arg0: Internal.Font_): Internal.FontMetrics;
        getDesktopProperty(arg0: string): any;
        getAWTEventListeners(): Internal.AWTEventListener[];
        addPropertyChangeListener(arg0: string, arg1: Internal.PropertyChangeListener_): void;
        /**
         * @deprecated
        */
        abstract getFontList(): string[];
        abstract getColorModel(): Internal.ColorModel;
        getSystemEventQueue(): Internal.EventQueue;
        abstract isModalExclusionTypeSupported(arg0: Internal.Dialog$ModalExclusionType_): boolean;
        getAWTEventListeners(arg0: number): Internal.AWTEventListener[];
        abstract sync(): void;
        abstract getPrintJob(arg0: Internal.Frame_, arg1: string, arg2: Internal.Properties_): Internal.PrintJob;
        abstract isModalityTypeSupported(arg0: Internal.Dialog$ModalityType_): boolean;
        getPropertyChangeListeners(arg0: string): Internal.PropertyChangeListener[];
        toString(): string;
        isFrameStateSupported(arg0: number): boolean;
        abstract getScreenResolution(): number;
        notifyAll(): void;
        addAWTEventListener(arg0: Internal.AWTEventListener_, arg1: number): void;
        createDragGestureRecognizer<T extends Internal.DragGestureRecognizer>(arg0: T, arg1: Internal.DragSource_, arg2: Internal.Component_, arg3: number, arg4: Internal.DragGestureListener_): T;
        abstract beep(): void;
        abstract getScreenSize(): Internal.Dimension;
        /**
         * @deprecated
        */
        getMenuShortcutKeyMask(): number;
        static getDefaultToolkit(): Internal.Toolkit;
        hashCode(): number;
        setDynamicLayout(arg0: boolean): void;
        getPrintJob(arg0: Internal.Frame_, arg1: string, arg2: Internal.JobAttributes_, arg3: Internal.PageAttributes_): Internal.PrintJob;
        abstract prepareImage(arg0: Internal.Image_, arg1: number, arg2: number, arg3: Internal.ImageObserver_): boolean;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        abstract "createImage(java.awt.image.ImageProducer)"(arg0: Internal.ImageProducer_): Internal.Image;
        abstract getSystemClipboard(): Internal.Clipboard;
        get menuShortcutKeyMaskEx(): number
        get systemSelection(): Internal.Clipboard
        get dynamicLayoutActive(): boolean
        get propertyChangeListeners(): Internal.PropertyChangeListener[]
        get alwaysOnTopSupported(): boolean
        get class(): typeof any
        get maximumCursorColors(): number
        get AWTEventListeners(): Internal.AWTEventListener[]
        /**
         * @deprecated
        */
        get fontList(): string[]
        get colorModel(): Internal.ColorModel
        get systemEventQueue(): Internal.EventQueue
        get screenResolution(): number
        get screenSize(): Internal.Dimension
        /**
         * @deprecated
        */
        get menuShortcutKeyMask(): number
        get defaultToolkit(): Internal.Toolkit
        set dynamicLayout(arg0: boolean)
        get systemClipboard(): Internal.Clipboard
    }
    type Toolkit_ = Toolkit;
    class CharniaFeature extends Internal.UnderwaterPlantFeature {
        constructor()
        place(featureConfig: Internal.FeaturePlaceContext_<Internal.SinglePlantFeatureConfig>): boolean;
        getClass(): typeof any;
        "generate(org.betterx.betterend.world.features.SinglePlantFeatureConfig,net.minecraft.world.level.WorldGenLevel,net.minecraft.util.RandomSource,net.minecraft.core.BlockPos)"(cfg: Internal.SinglePlantFeatureConfig_, world: Internal.WorldGenLevel_, random: Internal.RandomSource_, blockPos: BlockPos_): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        "generate(org.betterx.betterend.world.features.ScatterFeatureConfig,net.minecraft.world.level.WorldGenLevel,net.minecraft.util.RandomSource,net.minecraft.core.BlockPos)"(arg0: Internal.ScatterFeatureConfig_, arg1: Internal.WorldGenLevel_, arg2: Internal.RandomSource_, arg3: BlockPos_): void;
        canGenerate(cfg: Internal.SinglePlantFeatureConfig_, world: Internal.WorldGenLevel_, random: Internal.RandomSource_, center: BlockPos_, blockPos: BlockPos_, radius: number): boolean;
        generate(arg0: Internal.ScatterFeatureConfig_, arg1: Internal.WorldGenLevel_, arg2: Internal.RandomSource_, arg3: BlockPos_): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.SinglePlantFeatureConfig, Feature<Internal.SinglePlantFeatureConfig>>>;
        toString(): string;
        "canGenerate(org.betterx.betterend.world.features.SinglePlantFeatureConfig,net.minecraft.world.level.WorldGenLevel,net.minecraft.util.RandomSource,net.minecraft.core.BlockPos,net.minecraft.core.BlockPos,float)"(cfg: Internal.SinglePlantFeatureConfig_, world: Internal.WorldGenLevel_, random: Internal.RandomSource_, center: BlockPos_, blockPos: BlockPos_, radius: number): boolean;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        "canGenerate(org.betterx.betterend.world.features.ScatterFeatureConfig,net.minecraft.world.level.WorldGenLevel,net.minecraft.util.RandomSource,net.minecraft.core.BlockPos,net.minecraft.core.BlockPos,float)"(arg0: Internal.ScatterFeatureConfig_, arg1: Internal.WorldGenLevel_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: BlockPos_, arg5: number): boolean;
        hashCode(): number;
        canGenerate(arg0: Internal.ScatterFeatureConfig_, arg1: Internal.WorldGenLevel_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: BlockPos_, arg5: number): boolean;
        wait(): void;
        place($$0: Internal.SinglePlantFeatureConfig_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        generate(cfg: Internal.SinglePlantFeatureConfig_, world: Internal.WorldGenLevel_, random: Internal.RandomSource_, blockPos: BlockPos_): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        get class(): typeof any
    }
    type CharniaFeature_ = CharniaFeature;
    class BCLBiome implements Internal.BiomeData {
        constructor(biomeID: ResourceLocation_, type: Internal.BiomeAPI$BiomeType_)
        getClass(): typeof any;
        static codecWithSettings<T extends Internal.BCLBiome, P11>(instance: Internal.RecordCodecBuilder$Instance_<T>, p11: Internal.RecordCodecBuilder_<T, P11>): Internal.Products$P11<Internal.RecordCodecBuilder$Mu<T>, number, number, number, number, boolean, Optional<ResourceLocation>, ResourceLocation, Optional<Internal.List<Internal.Climate$ParameterPoint>>, Optional<ResourceLocation>, Optional<string>, P11>;
        isSame(biome: Internal.BCLBiome_): boolean;
        static codecWithSettings<T extends Internal.BCLBiome>(instance: Internal.RecordCodecBuilder$Instance_<T>): Internal.Products$P10<Internal.RecordCodecBuilder$Mu<T>, number, number, number, number, boolean, Optional<ResourceLocation>, ResourceLocation, Optional<Internal.List<Internal.Climate$ParameterPoint>>, Optional<ResourceLocation>, Optional<string>>;
        configGroup(): string;
        static codecWithSettings<T extends Internal.BCLBiome, P11, P12, P13>(instance: Internal.RecordCodecBuilder$Instance_<T>, p11: Internal.RecordCodecBuilder_<T, P11>, p12: Internal.RecordCodecBuilder_<T, P12>, p13: Internal.RecordCodecBuilder_<T, P13>): Internal.Products$P13<Internal.RecordCodecBuilder$Mu<T>, number, number, number, number, boolean, Optional<ResourceLocation>, ResourceLocation, Optional<Internal.List<Internal.Climate$ParameterPoint>>, Optional<ResourceLocation>, Optional<string>, P11, P12, P13>;
        equals(key: Internal.ResourceKey_<Internal.Biome>): boolean;
        is(loc: ResourceLocation_): boolean;
        "is(net.minecraft.resources.ResourceLocation)"(loc: ResourceLocation_): boolean;
        addSubBiome(biome: Internal.BCLBiome_): this;
        forEachClimateParameter(consumer: Internal.Consumer_<Internal.Climate$ParameterPoint>): void;
        notify(): void;
        "equals(net.minecraft.resources.ResourceKey)"(key: Internal.ResourceKey_<Internal.Biome>): boolean;
        wait(arg0: number, arg1: number): void;
        "equals(org.betterx.bclib.api.v2.levelgen.biomes.BCLBiome)"(biome: Internal.BCLBiome_): boolean;
        getEdge(): this;
        getBCLBiomeKey(): Internal.ResourceKey<Internal.BCLBiome>;
        "is(net.minecraft.resources.ResourceKey)"(key: Internal.ResourceKey_<Internal.Biome>): boolean;
        "equals(java.lang.Object)"(obj: any): boolean;
        static codecWithSettings<T extends Internal.BCLBiome, P11, P12>(instance: Internal.RecordCodecBuilder$Instance_<T>, p11: Internal.RecordCodecBuilder_<T, P11>, p12: Internal.RecordCodecBuilder_<T, P12>): Internal.Products$P12<Internal.RecordCodecBuilder$Mu<T>, number, number, number, number, boolean, Optional<ResourceLocation>, ResourceLocation, Optional<Internal.List<Internal.Climate$ParameterPoint>>, Optional<ResourceLocation>, Optional<string>, P11, P12>;
        hasParentBiome(): boolean;
        getParentBiome(): this;
        forEachSubBiome(consumer: Internal.BiConsumer_<Internal.BCLBiome, number>): void;
        equals(biome: Internal.BCLBiome_): boolean;
        equals(loc: ResourceLocation_): boolean;
        toString(): string;
        notifyAll(): void;
        hasEdge(): boolean;
        is(key: Internal.ResourceKey_<Internal.Biome>): boolean;
        getBiomeKey(): Internal.ResourceKey<Internal.Biome>;
        codec(): Internal.KeyDispatchDataCodec<Internal.BCLBiome>;
        isEdgeBiome(): boolean;
        "is(org.betterx.bclib.api.v2.levelgen.biomes.BCLBiome)"(biome: Internal.BCLBiome_): boolean;
        hashCode(): number;
        getID(): ResourceLocation;
        addEdge(newEdge: Internal.BCLBiome_): this;
        wait(): void;
        wait(arg0: number): void;
        getIntendedType(): Internal.BiomeAPI$BiomeType;
        "equals(net.minecraft.resources.ResourceLocation)"(loc: ResourceLocation_): boolean;
        equals(obj: any): boolean;
        is(biome: Internal.BCLBiome_): boolean;
        static codecWithSettings<T extends Internal.BCLBiome, P11, P12, P13, P14>(instance: Internal.RecordCodecBuilder$Instance_<T>, p11: Internal.RecordCodecBuilder_<T, P11>, p12: Internal.RecordCodecBuilder_<T, P12>, p13: Internal.RecordCodecBuilder_<T, P13>, p14: Internal.RecordCodecBuilder_<T, P14>): Internal.Products$P14<Internal.RecordCodecBuilder$Mu<T>, number, number, number, number, boolean, Optional<ResourceLocation>, ResourceLocation, Optional<Internal.List<Internal.Climate$ParameterPoint>>, Optional<ResourceLocation>, Optional<string>, P11, P12, P13, P14>;
        get class(): typeof any
        get edge(): Internal.BCLBiome
        get BCLBiomeKey(): Internal.ResourceKey<Internal.BCLBiome>
        get parentBiome(): Internal.BCLBiome
        get biomeKey(): Internal.ResourceKey<Internal.Biome>
        get edgeBiome(): boolean
        get ID(): ResourceLocation
        get intendedType(): Internal.BiomeAPI$BiomeType
        readonly settings: Internal.BCLBiomeSettings;
        static readonly CODEC: Internal.Codec<Internal.BCLBiome>;
        static readonly KEY_CODEC: Internal.KeyDispatchDataCodec<Internal.BCLBiome>;
    }
    type BCLBiome_ = Special.Biome | BCLBiome;
    interface INearbyItemAwareEntity {
        abstract getNearbyItems(): number;
        abstract setNearbyItems(arg0: number): void;
        get nearbyItems(): number
        set nearbyItems(arg0: number)
    }
    type INearbyItemAwareEntity_ = INearbyItemAwareEntity;
    class EMFJemData {
        constructor()
        getClass(): typeof any;
        validateJemTexture(textureIn: string, canRemoveRedundancy: boolean): ResourceLocation;
        validateJemTexture(textureIn: string): ResourceLocation;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        getMobModelIDInfo(): Internal.EMFModel_ID;
        wait(arg0: number, arg1: number): void;
        getAllTopLevelAnimationsByVanillaPartName(): Internal.LinkedHashMap<string, Internal.List<Internal.LinkedHashMap<string, string>>>;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        prepare(directoryContext: Internal.EMFDirectoryHandler_, mobModelIDInfo: Internal.EMFModel_ID_): void;
        equals(arg0: any): boolean;
        getCustomTexture(): ResourceLocation;
        get class(): typeof any
        get mobModelIDInfo(): Internal.EMFModel_ID
        get allTopLevelAnimationsByVanillaPartName(): Internal.LinkedHashMap<string, Internal.List<Internal.LinkedHashMap<string, string>>>
        get customTexture(): ResourceLocation
        texture: string;
        directoryContext: Internal.EMFDirectoryHandler;
        textureSize: number[];
        models: Internal.LinkedList<Internal.EMFPartData>;
        shadow_size: number;
    }
    type EMFJemData_ = EMFJemData;
    class BigAuroraCrystalFeature extends Internal.DefaultFeature {
        constructor()
        static getPosOnSurfaceWG(world: Internal.WorldGenLevel_, pos: BlockPos_): BlockPos;
        getClass(): typeof any;
        static getPosOnSurface(world: Internal.WorldGenLevel_, pos: BlockPos_): BlockPos;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        place($$0: Internal.NoneFeatureConfiguration_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        static getPosOnSurfaceRaycast(world: Internal.WorldGenLevel_, pos: BlockPos_): BlockPos;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        place(featureConfig: Internal.FeaturePlaceContext_<Internal.NoneFeatureConfiguration>): boolean;
        static getYOnSurfaceWG(world: Internal.WorldGenLevel_, x: number, z: number): number;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        static getPosOnSurfaceRaycast(world: Internal.WorldGenLevel_, pos: BlockPos_, dist: number): BlockPos;
        wait(): void;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.NoneFeatureConfiguration, Feature<Internal.NoneFeatureConfiguration>>>;
        static getYOnSurface(world: Internal.WorldGenLevel_, x: number, z: number): number;
        get class(): typeof any
    }
    type BigAuroraCrystalFeature_ = BigAuroraCrystalFeature;
    class SelfReturningItem extends Internal.Item {
        constructor(builder: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        hasCraftingRemainingItem(): boolean;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type SelfReturningItem_ = SelfReturningItem;
    interface AbstractClientPlayerEntityAccessor {
        abstract setPlayerListEntry(arg0: Internal.PlayerInfo_): void;
        set playerListEntry(arg0: Internal.PlayerInfo_)
        (arg0: Internal.PlayerInfo): void;
    }
    type AbstractClientPlayerEntityAccessor_ = ((arg0: Internal.PlayerInfo)=> void) | AbstractClientPlayerEntityAccessor;
    class ServerOpListEntry extends Internal.StoredUserEntry<Internal.GameProfile> {
        constructor($$0: Internal.GameProfile_, $$1: number, $$2: boolean)
        constructor($$0: Internal.JsonObject_)
        getClass(): typeof any;
        getLevel(): number;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getBypassesPlayerLimit(): boolean;
        get class(): typeof any
        get level(): number
        get bypassesPlayerLimit(): boolean
    }
    type ServerOpListEntry_ = ServerOpListEntry;
    abstract class FieldNamingPolicy extends Internal.Enum<Internal.FieldNamingPolicy> implements Internal.FieldNamingStrategy {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        abstract translateName(arg0: Internal.Field_): string;
        getDeclaringClass(): typeof Internal.FieldNamingPolicy;
        toString(): string;
        compareTo(arg0: Internal.FieldNamingPolicy_): number;
        notifyAll(): void;
        static values(): Internal.FieldNamingPolicy[];
        "compareTo(com.google.gson.FieldNamingPolicy)"(arg0: Internal.FieldNamingPolicy_): number;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        name(): string;
        hashCode(): number;
        static valueOf(arg0: string): Internal.FieldNamingPolicy;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.FieldNamingPolicy>>;
        get class(): typeof any
        get declaringClass(): typeof Internal.FieldNamingPolicy
        static readonly UPPER_CASE_WITH_UNDERSCORES: Internal.FieldNamingPolicy;
        static readonly IDENTITY: Internal.FieldNamingPolicy;
        static readonly UPPER_CAMEL_CASE: Internal.FieldNamingPolicy;
        static readonly LOWER_CASE_WITH_UNDERSCORES: Internal.FieldNamingPolicy;
        static readonly LOWER_CASE_WITH_DASHES: Internal.FieldNamingPolicy;
        static readonly UPPER_CAMEL_CASE_WITH_SPACES: Internal.FieldNamingPolicy;
        static readonly LOWER_CASE_WITH_DOTS: Internal.FieldNamingPolicy;
    }
    type FieldNamingPolicy_ = "lower_case_with_underscores" | "lower_case_with_dashes" | "identity" | "upper_camel_case_with_spaces" | "lower_case_with_dots" | "upper_case_with_underscores" | FieldNamingPolicy | "upper_camel_case";
    interface ItemTintFunction {
        abstract getColor(arg0: Internal.ItemStack_, arg1: number): dev.latvian.mods.rhino.mod.util.color.Color;
        of(cx: Internal.Context_, o: any): this;
        (arg0: Internal.ItemStack, arg1: number): dev.latvian.mods.rhino.mod.util.color.Color_;
        readonly POTION: Internal.ItemTintFunction;
        readonly DISPLAY_COLOR_NBT: Internal.ItemTintFunction;
        readonly BLOCK: Internal.ItemTintFunction;
        readonly MAP: Internal.ItemTintFunction;
    }
    type ItemTintFunction_ = ((arg0: Internal.ItemStack, arg1: number)=> dev.latvian.mods.rhino.mod.util.color.Color_) | ItemTintFunction;
    class SnowAndFreezeFeature extends Feature<Internal.NoneFeatureConfiguration> {
        constructor($$0: Internal.Codec_<Internal.NoneFeatureConfiguration>)
        getClass(): typeof any;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        place($$0: Internal.NoneFeatureConfiguration_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        place($$0: Internal.FeaturePlaceContext_<Internal.NoneFeatureConfiguration>): boolean;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.NoneFeatureConfiguration, Feature<Internal.NoneFeatureConfiguration>>>;
        get class(): typeof any
    }
    type SnowAndFreezeFeature_ = SnowAndFreezeFeature;
    interface IMixinVineBlock {
        abstract invokeShouldConnectUp(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Direction_): boolean;
        (arg0: Internal.BlockGetter, arg1: BlockPos, arg2: Internal.Direction): boolean;
    }
    type IMixinVineBlock_ = IMixinVineBlock | ((arg0: Internal.BlockGetter, arg1: BlockPos, arg2: Internal.Direction)=> boolean);
    class IntConfig extends Internal.NumberConfig<number> {
        constructor(mn: number, mx: number)
        getValue(): number;
        setCanEdit(e: boolean): Internal.ConfigValue<number>;
        scrollValue(currentValue: number, forward: boolean): Optional<number>;
        onClicked(clicked: dev.ftb.mods.ftblibrary.ui.Widget_, button: Internal.MouseButton_, callback: Internal.ConfigCallback_): void;
        getTooltip(): string;
        notify(): void;
        setNameKey(key: string): Internal.ConfigValue<number>;
        compareTo(arg0: any): number;
        setIcon(i: Internal.Icon_): Internal.ConfigValue<number>;
        "getColor(java.lang.Object)"(arg0: any): Internal.Color4I;
        "compareTo(dev.ftb.mods.ftblibrary.config.ConfigValue)"(o: Internal.ConfigValue_<number>): number;
        getStringForGUI(v: number): net.minecraft.network.chat.Component;
        "getStringForGUI(java.lang.Integer)"(v: number): net.minecraft.network.chat.Component;
        copy(value: number): number;
        getStringForGUI(): net.minecraft.network.chat.Component;
        scrollValue(arg0: any, arg1: boolean): Optional<any>;
        applyValue(): void;
        setOrder(o: number): Internal.ConfigValue<number>;
        canScroll(): boolean;
        fader(v: boolean): Internal.NumberConfig<number>;
        getColor(arg0: any): Internal.Color4I;
        parse(callback: Internal.Consumer_<number>, string: string): boolean;
        "scrollValue(java.lang.Integer,boolean)"(currentValue: number, forward: boolean): Optional<number>;
        wait(): void;
        getNameKey(): string;
        getStringFromValue(v: number): string;
        "compareTo(java.lang.Object)"(arg0: any): number;
        getClass(): typeof any;
        setCurrentValue(v: number): boolean;
        getIcon(v: number): Internal.Icon;
        withScrollIncrement(increment: number): Internal.NumberConfig<number>;
        addInfo(list: Internal.TooltipList_): void;
        wait(arg0: number, arg1: number): void;
        setValue(value: number): void;
        setDefaultValue(defaultValue: number): void;
        isEqual(v1: number, v2: number): boolean;
        getIcon(): Internal.Icon;
        getName(): string;
        getGroup(): Internal.ConfigGroup;
        getStringForGUI(arg0: any): net.minecraft.network.chat.Component;
        getColor(): Internal.Color4I;
        "getStringForGUI(java.lang.Object)"(arg0: any): net.minecraft.network.chat.Component;
        getColor(v: number): Internal.Color4I;
        getPath(): string;
        "scrollValue(java.lang.Object,boolean)"(arg0: any, arg1: boolean): Optional<any>;
        "getColor(java.lang.Integer)"(v: number): Internal.Color4I;
        toString(): string;
        init(group: Internal.ConfigGroup_, id: string, value: number, setter: Internal.Consumer_<number>, defaultValue: number): Internal.ConfigValue<number>;
        notifyAll(): void;
        static info(key: string, value: any): net.minecraft.network.chat.Component;
        getDefaultValue(): number;
        hashCode(): number;
        compareTo(o: Internal.ConfigValue_<number>): number;
        wait(arg0: number): void;
        getCanEdit(): boolean;
        equals(arg0: any): boolean;
        get value(): number
        set canEdit(e: boolean)
        get tooltip(): string
        set nameKey(key: string)
        set icon(i: Internal.Icon_)
        get stringForGUI(): net.minecraft.network.chat.Component
        set order(o: number)
        get nameKey(): string
        get class(): typeof any
        set currentValue(v: number)
        set value(value: number)
        set defaultValue(defaultValue: number)
        get icon(): Internal.Icon
        get name(): string
        get group(): Internal.ConfigGroup
        get color(): Internal.Color4I
        get path(): string
        get defaultValue(): number
        get canEdit(): boolean
    }
    type IntConfig_ = IntConfig;
    class PrintStream extends Internal.FilterOutputStream implements Internal.Closeable, Internal.Appendable {
        constructor(arg0: Internal.File_)
        constructor(arg0: Internal.OutputStream_, arg1: boolean)
        constructor(arg0: Internal.OutputStream_)
        constructor(arg0: string, arg1: string)
        constructor(arg0: string, arg1: Internal.Charset_)
        constructor(arg0: Internal.File_, arg1: Internal.Charset_)
        constructor(arg0: Internal.OutputStream_, arg1: boolean, arg2: Internal.Charset_)
        constructor(arg0: string)
        constructor(arg0: Internal.OutputStream_, arg1: boolean, arg2: string)
        constructor(arg0: Internal.File_, arg1: string)
        print(arg0: string): void;
        "println(int)"(arg0: number): void;
        "println(java.lang.Object)"(arg0: any): void;
        printf(arg0: string, ...arg1: any[]): this;
        append(arg0: Internal.CharSequence_, arg1: number, arg2: number): Internal.Appendable;
        notify(): void;
        println(arg0: string): void;
        write(arg0: number): void;
        print(arg0: number): void;
        "print(float)"(arg0: number): void;
        print(arg0: boolean): void;
        "append(char)"(arg0: string): Internal.Appendable;
        "println(long)"(arg0: number): void;
        println(arg0: string): void;
        append(arg0: Internal.CharSequence_): Internal.Appendable;
        "println(java.lang.String)"(arg0: string): void;
        "println(char)"(arg0: string): void;
        println(arg0: number): void;
        checkError(): boolean;
        print(arg0: any): void;
        static nullOutputStream(): Internal.OutputStream;
        print(arg0: string): void;
        wait(): void;
        println(arg0: any): void;
        "append(java.lang.CharSequence)"(arg0: Internal.CharSequence_): Internal.Appendable;
        getClass(): typeof any;
        println(arg0: number): void;
        "write(byte[])"(arg0: number[]): void;
        println(): void;
        "print(int)"(arg0: number): void;
        format(arg0: Internal.Locale_, arg1: string, ...arg2: any[]): this;
        println(arg0: number): void;
        write(arg0: number[]): void;
        append(arg0: string): Internal.Appendable;
        wait(arg0: number, arg1: number): void;
        "print(java.lang.String)"(arg0: string): void;
        print(arg0: number): void;
        flush(): void;
        "print(char[])"(arg0: string[]): void;
        write(arg0: number[], arg1: number, arg2: number): void;
        format(arg0: string, ...arg1: any[]): this;
        print(arg0: number): void;
        "println(float)"(arg0: number): void;
        "println(double)"(arg0: number): void;
        "println(boolean)"(arg0: boolean): void;
        toString(): string;
        println(arg0: string[]): void;
        println(arg0: boolean): void;
        printf(arg0: Internal.Locale_, arg1: string, ...arg2: any[]): this;
        notifyAll(): void;
        "println(char[])"(arg0: string[]): void;
        "print(long)"(arg0: number): void;
        "print(java.lang.Object)"(arg0: any): void;
        "print(double)"(arg0: number): void;
        hashCode(): number;
        println(arg0: number): void;
        print(arg0: string[]): void;
        "print(char)"(arg0: string): void;
        "print(boolean)"(arg0: boolean): void;
        close(): void;
        wait(arg0: number): void;
        writeBytes(arg0: number[]): void;
        print(arg0: number): void;
        equals(arg0: any): boolean;
        "write(int)"(arg0: number): void;
        get class(): typeof any
    }
    type PrintStream_ = PrintStream;
    interface BiomeSourceAccess {
        abstract regions_unexplored$invokeCodec(): Internal.Codec<Internal.BiomeSource>;
        (): Internal.Codec_<Internal.BiomeSource>;
    }
    type BiomeSourceAccess_ = BiomeSourceAccess | (()=> Internal.Codec_<Internal.BiomeSource>);
    class NetherPickaxe extends Internal.BasePickaxeItem implements Internal.InitialStackStateProvider {
        constructor(material: Internal.Tier_, attackDamage: number, attackSpeed: number)
        onTick(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        bclib_getBlockTag(): Internal.TagKey<any>;
        onWearerUse(stack: Internal.ItemStack_, world: Internal.Level_, user: Internal.Player_, hand: Internal.InteractionHand_): void;
        getItemModel(resourceLocation: ResourceLocation_): Internal.BlockModel;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        addModifierTooltip(stack: Internal.ItemStack_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_, type: Internal.ModifierHelperType_<any>): void;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy(itemStack: Internal.ItemStack_, level: Internal.Level_, player: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        fzzy_core_correctSlot(slot: Internal.EquipmentSlot_): boolean;
        getCreativeTab(): string;
        postWearerHit(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        modifierObjectPredicate(livingEntity: Internal.LivingEntity_, stack: Internal.ItemStack_): ResourceLocation;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        kjs$getAttributeMap(): Internal.Multimap<any, any>;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        kjs$getMutableAttributeMap(): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        fzzy_core_getCorrectSlot(): Internal.EquipmentSlot;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        onWearerKilledOther(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, victim: Internal.LivingEntity_, world: Internal.ServerLevel_): void;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        putEnchantments(stack: Internal.ItemStack_, defaultEnchants: Internal.Map_<Internal.Enchantment, number>): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        canBeModifiedBy(type: Internal.ModifierHelperType_<any>): boolean;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        getAttackDamage(): number;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        incrementKillCount(stack: Internal.ItemStack_): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        defaultModifiers(type: Internal.ModifierHelperType_<any>): Internal.List<any>;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        port_lib$canPerformAction(stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): boolean;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        getTier(): Internal.Tier;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        "onCraftedBy(net.minecraft.world.item.ItemStack,net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player)"(itemStack: Internal.ItemStack_, level: Internal.Level_, player: Internal.Player_): void;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        initializeState(stack: Internal.ItemStack_): void;
        getKillCount(stack: Internal.ItemStack_): number;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        postWearerMine(stack: Internal.ItemStack_, world: Internal.Level_, state: Internal.BlockState_, pos: BlockPos_, miner: Internal.Player_): void;
        kjs$setAttributeMap(arg0: Internal.Multimap_<any, any>): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        get attackDamage(): number
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        get tier(): Internal.Tier
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type NetherPickaxe_ = NetherPickaxe;
    interface PlayerEntityExtensions {
        abstract impersonate_getActualGameProfile(): Internal.GameProfile;
        abstract impersonate_resetCape(): void;
        abstract impersonate_disableCape(): void;
    }
    type PlayerEntityExtensions_ = PlayerEntityExtensions;
    /**
     * Invoked when a player right clicks on an entity.
    */
    class ItemEntityInteractedEventJS extends Internal.PlayerEventJS {
        constructor(player: Internal.Player_, entity: Internal.Entity_, hand: Internal.InteractionHand_)
        getClass(): typeof any;
        /**
         * Stops the event with default exit value. Execution will be stopped **immediately**.
         * 
         * `exit` denotes a `default` outcome.
        */
        exit(): any;
        /**
         * Cancels the event with the given exit value. Execution will be stopped **immediately**.
         * 
         * `cancel` denotes a `false` outcome.
        */
        cancel(value: any): any;
        /**
         * Removes the specified game stage from the player
        */
        removeGameStage(stage: string): void;
        /**
         * The player that interacted with the entity.
        */
        getEntity(): Internal.Player;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getLevel(): Internal.Level;
        /**
         * The entity that was interacted with.
        */
        getTarget(): Internal.Entity;
        /**
         * The hand that was used to interact with the entity.
        */
        getHand(): Internal.InteractionHand;
        getPlayer(): Internal.Player;
        /**
         * Checks if the player has the specified game stage
        */
        hasGameStage(stage: string): boolean;
        toString(): string;
        /**
         * The item that was used to interact with the entity.
        */
        getItem(): Internal.ItemStack;
        notifyAll(): void;
        /**
         * Stops the event with the given exit value. Execution will be stopped **immediately**.
         * 
         * `exit` denotes a `default` outcome.
        */
        exit(value: any): any;
        /**
         * Adds the specified game stage to the player
        */
        addGameStage(stage: string): void;
        /**
         * Stops the event with the given exit value. Execution will be stopped **immediately**.
         * 
         * `success` denotes a `true` outcome.
        */
        success(value: any): any;
        hashCode(): number;
        wait(): void;
        /**
         * Cancels the event with default exit value. Execution will be stopped **immediately**.
         * 
         * `cancel` denotes a `false` outcome.
        */
        cancel(): any;
        wait(arg0: number): void;
        /**
         * Stops the event with default exit value. Execution will be stopped **immediately**.
         * 
         * `success` denotes a `true` outcome.
        */
        success(): any;
        equals(arg0: any): boolean;
        getServer(): Internal.MinecraftServer;
        get class(): typeof any
        /**
         * The player that interacted with the entity.
        */
        get entity(): Internal.Player
        get level(): Internal.Level
        /**
         * The entity that was interacted with.
        */
        get target(): Internal.Entity
        /**
         * The hand that was used to interact with the entity.
        */
        get hand(): Internal.InteractionHand
        get player(): Internal.Player
        /**
         * The item that was used to interact with the entity.
        */
        get item(): Internal.ItemStack
        get server(): Internal.MinecraftServer
    }
    type ItemEntityInteractedEventJS_ = ItemEntityInteractedEventJS;
    interface BiomeProperties {
        abstract getEffectsProperties(): Internal.EffectsProperties;
        abstract getClimateProperties(): Internal.ClimateProperties;
        abstract getGenerationProperties(): Internal.GenerationProperties;
        abstract getSpawnProperties(): Internal.SpawnProperties;
        get effectsProperties(): Internal.EffectsProperties
        get climateProperties(): Internal.ClimateProperties
        get generationProperties(): Internal.GenerationProperties
        get spawnProperties(): Internal.SpawnProperties
    }
    type BiomeProperties_ = BiomeProperties;
    class ModuleDescriptor$Builder {
        version(arg0: string): this;
        getClass(): typeof any;
        requires(arg0: Internal.ModuleDescriptor$Requires_): this;
        "opens(java.lang.module.ModuleDescriptor$Opens)"(arg0: Internal.ModuleDescriptor$Opens_): this;
        requires(arg0: string): this;
        provides(arg0: string, arg1: Internal.List_<string>): this;
        "version(java.lang.String)"(arg0: string): this;
        notify(): void;
        opens(arg0: string): this;
        wait(arg0: number, arg1: number): void;
        build(): Internal.ModuleDescriptor;
        opens(arg0: Internal.ModuleDescriptor$Opens_): this;
        provides(arg0: Internal.ModuleDescriptor$Provides_): this;
        uses(arg0: string): this;
        exports(arg0: Internal.Set_<Internal.ModuleDescriptor$Exports$Modifier>, arg1: string, arg2: Internal.Set_<string>): this;
        exports(arg0: Internal.Set_<Internal.ModuleDescriptor$Exports$Modifier>, arg1: string): this;
        exports(arg0: string): this;
        "requires(java.lang.String)"(arg0: string): this;
        opens(arg0: Internal.Set_<Internal.ModuleDescriptor$Opens$Modifier>, arg1: string, arg2: Internal.Set_<string>): this;
        requires(arg0: Internal.Set_<Internal.ModuleDescriptor$Requires$Modifier>, arg1: string): this;
        version(arg0: Internal.ModuleDescriptor$Version_): this;
        toString(): string;
        "exports(java.util.Set,java.lang.String)"(arg0: Internal.Set_<Internal.ModuleDescriptor$Exports$Modifier>, arg1: string): this;
        notifyAll(): void;
        opens(arg0: Internal.Set_<Internal.ModuleDescriptor$Opens$Modifier>, arg1: string): this;
        mainClass(arg0: string): this;
        packages(arg0: Internal.Set_<string>): this;
        "exports(java.lang.module.ModuleDescriptor$Exports)"(arg0: Internal.ModuleDescriptor$Exports_): this;
        "exports(java.lang.String,java.util.Set)"(arg0: string, arg1: Internal.Set_<string>): this;
        exports(arg0: Internal.ModuleDescriptor$Exports_): this;
        opens(arg0: string, arg1: Internal.Set_<string>): this;
        requires(arg0: Internal.Set_<Internal.ModuleDescriptor$Requires$Modifier>, arg1: string, arg2: Internal.ModuleDescriptor$Version_): this;
        "version(java.lang.module.ModuleDescriptor$Version)"(arg0: Internal.ModuleDescriptor$Version_): this;
        "exports(java.lang.String)"(arg0: string): this;
        hashCode(): number;
        "opens(java.lang.String,java.util.Set)"(arg0: string, arg1: Internal.Set_<string>): this;
        wait(): void;
        "opens(java.lang.String)"(arg0: string): this;
        wait(arg0: number): void;
        "requires(java.lang.module.ModuleDescriptor$Requires)"(arg0: Internal.ModuleDescriptor$Requires_): this;
        equals(arg0: any): boolean;
        exports(arg0: string, arg1: Internal.Set_<string>): this;
        "opens(java.util.Set,java.lang.String)"(arg0: Internal.Set_<Internal.ModuleDescriptor$Opens$Modifier>, arg1: string): this;
        get class(): typeof any
    }
    type ModuleDescriptor$Builder_ = ModuleDescriptor$Builder;
    class ModifierHelperType$Companion {
        constructor($constructor_marker: any_)
        getClass(): typeof any;
        add(stack: Internal.ItemStack_, id: Internal.SlotId_, modifierContainer: Internal.ModifierContainer_): void;
        toString(): string;
        remove(stack: Internal.ItemStack_, id: Internal.SlotId_, modifierContainer: Internal.ModifierContainer_): void;
        init(): void;
        static access$getTypeFromEither($this: Internal.ModifierHelperType$Companion_, either: Internal.Either_<any, any>): Internal.DataResult<any>;
        notifyAll(): void;
        getCODEC(): Internal.Codec<Internal.ArrayListMultimap<Internal.ModifierHelperType<any>, Internal.AbstractModifier<any>>>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        areModifiersEqual(old: Internal.ItemStack_, young: Internal.ItemStack_): boolean;
        getREGISTRY(): Internal.MappedRegistry<Internal.ModifierHelperType<any>>;
        wait(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        register<T extends Internal.AbstractModifier<T>>(type: Internal.ModifierHelperType_<T>): Internal.ModifierHelperType<T>;
        getEMPTY_TYPE(): Internal.ModifierHelperType$Companion$EmptyType;
        get class(): typeof any
        get CODEC(): Internal.Codec<Internal.ArrayListMultimap<Internal.ModifierHelperType<any>, Internal.AbstractModifier<any>>>
        get REGISTRY(): Internal.MappedRegistry<Internal.ModifierHelperType<any>>
        get EMPTY_TYPE(): Internal.ModifierHelperType$Companion$EmptyType
    }
    type ModifierHelperType$Companion_ = ModifierHelperType$Companion;
    class CropBlockBuilder extends Internal.BlockBuilder {
        constructor(i: ResourceLocation_)
        /**
         * Bounces entities that land on this block by bounciness * their fall velocity.
         * Do not make bounciness negative, as that is a recipe for a long and laggy trip to the void
        */
        bounciness(bounciness: number): Internal.BlockBuilder;
        /**
         * Note block instrument.
        */
        instrument(i: Internal.NoteBlockInstrument_): Internal.BlockBuilder;
        createAdditionalObjects(): void;
        /**
         * Set if the crop should drop seeds when harvested.
        */
        dropSeed(dropSeed: boolean): this;
        /**
         * Tags the item with the given tag.
        */
        tagItem(tag: ResourceLocation_): Internal.BlockBuilder;
        /**
         * Sets the translation key for this object, e.g. `block.minecraft.stone`.
        */
        translationKey(key: string): Internal.BuilderBase<Internal.Block>;
        sandSoundType(): Internal.BlockBuilder;
        /**
         * Set the shape of the block.
        */
        box(x0: number, y0: number, z0: number, x1: number, y1: number, z1: number): Internal.BlockBuilder;
        get(): Internal.Block;
        getRegistryType(): Internal.RegistryInfo<any>;
        /**
         * Texture the block on all sides with the same texture.
        */
        textureAll(tex: string): Internal.BlockBuilder;
        /**
         * Makes displayName() override language files.
        */
        formattedDisplayName(): Internal.BuilderBase<Internal.Block>;
        /**
         * Sets the block's map color dynamically per block state. If unset, defaults to NONE.
        */
        dynamicMapColor(m: Internal.Function_<Internal.BlockState, any>): Internal.BlockBuilder;
        /**
         * Tags both the block and the item with the given tag.
        */
        tagBoth(tag: ResourceLocation_): Internal.BlockBuilder;
        /**
         * Makes the block unbreakable.
        */
        unbreakable(): Internal.BlockBuilder;
        randomTick(randomTickCallback: Internal.Consumer_<Internal.RandomTickCallbackJS>): Internal.BlockBuilder;
        /**
         * Set the age of the crop and the shape of the crop at that age.
        */
        age(age: number, builder: Internal.Consumer_<Internal.CropBlockBuilder$ShapeBuilder>): this;
        /**
         * Sets the light level of the block. Defaults to 0 (no light).
        */
        lightLevel(light: number): Internal.BlockBuilder;
        /**
         * Combined method of formattedDisplayName().displayName(name).
        */
        formattedDisplayName(name: net.minecraft.network.chat.Component_): Internal.BuilderBase<Internal.Block>;
        /**
         * Sets the display name for this object, e.g. `Stone`.
         * 
         * This will be overridden by a lang file if it exists.
        */
        displayName(name: net.minecraft.network.chat.Component_): Internal.BuilderBase<Internal.Block>;
        /**
         * Set the age of the crop. Note that the box will be the same for all ages (A full block size).
        */
        age(age: number): this;
        /**
         * Makes the block not be solid.
        */
        notSolid(): Internal.BlockBuilder;
        static createShape(boxes: Internal.List_<Internal.AABB>): Internal.VoxelShape;
        generateLang(lang: Internal.LangEventJS_): void;
        /**
         * Clears all drops for the block.
        */
        noDrops(): Internal.BlockBuilder;
        getClass(): typeof any;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        setWaterlogged(waterlogged: boolean): Internal.BlockBuilder;
        grassSoundType(): Internal.BlockBuilder;
        createProperties(): Internal.BlockBehaviour$Properties;
        /**
         * Sets the block's sound type. Defaults to wood.
        */
        soundType(m: SoundType_): Internal.BlockBuilder;
        "transformObject(java.lang.Object)"(arg0: any): any;
        /**
         * Set the callback used for determining how the block rotates
        */
        rotateState(callbackJS: Internal.Consumer_<Internal.BlockStateRotateCallbackJS>): Internal.BlockBuilder;
        /**
         * Set the callback used for right-clicking on the block
        */
        rightClick(callbackJS: Internal.Consumer_<Internal.BlockRightClickedEventJS>): Internal.BlockBuilder;
        /**
         * Makes the block require a tool to have drops when broken.
        */
        requiresTool(f: boolean): Internal.BlockBuilder;
        /**
         * Sets the hardness of the block. Defaults to 1.5.
         * 
         * Setting this to -1 will make the block unbreakable like bedrock.
        */
        hardness(h: number): Internal.BlockBuilder;
        /**
         * Creates a Block Entity for this block
        */
        blockEntity(callback: Internal.Consumer_<Internal.BlockEntityInfo>): Internal.BlockBuilder;
        /**
         * Set the block to have no corresponding item.
        */
        noItem(): Internal.BlockBuilder;
        createObject(): Internal.Block;
        transformObject(arg0: any): any;
        /**
         * Add a crop output with a 100% chance.
        */
        crop(output: any): this;
        bonemeal(bonemealCallback: Internal.ToIntFunction_<Internal.RandomTickCallbackJS>): this;
        /**
         * Set the callback used for determining how the block is mirrored
        */
        mirrorState(callbackJS: Internal.Consumer_<Internal.BlockStateMirrorCallbackJS>): Internal.BlockBuilder;
        /**
         * Set how slippery the block is.
        */
        slipperiness(f: number): Internal.BlockBuilder;
        toString(): string;
        woodSoundType(): Internal.BlockBuilder;
        notifyAll(): void;
        transformObject(obj: Internal.Block_): Internal.Block;
        /**
         * Set how this block bounces/moves entities that land on top of this. Do not use this to modify the block, use fallOn instead!
         * Use ctx.bounce(height) or ctx.setVelocity(x, y, z) to change the entities velocity.
        */
        afterFallenOn(callbackJS: Internal.Consumer_<Internal.AfterEntityFallenOnBlockCallbackJS>): Internal.BlockBuilder;
        /**
         * Makes the block suffocating.
        */
        suffocating(b: boolean): Internal.BlockBuilder;
        /**
         * Set the color of a specific layer of the block.
        */
        color(index: number, color: Internal.BlockTintFunction_): Internal.BlockBuilder;
        wait(arg0: number): void;
        /**
         * Set how fast you can walk on the block.
         * 
         * Any value above 1 will make you walk insanely fast as your speed is multiplied by this value each tick.
         * 
         * Recommended values are between 0.1 and 1, useful for mimicking soul sand or ice.
        */
        speedFactor(f: number): Internal.BlockBuilder;
        cropSoundType(): Internal.BlockBuilder;
        newID(pre: string, post: string): ResourceLocation;
        "transformObject(net.minecraft.world.level.block.Block)"(obj: Internal.Block_): Internal.Block;
        /**
         * Set what happens when an entity falls on the block. Do not use this for moving them, use bounce instead!
        */
        fallenOn(callbackJS: Internal.Consumer_<Internal.EntityFallenOnBlockCallbackJS>): Internal.BlockBuilder;
        /**
         * Set the block's model.
        */
        model(m: string): Internal.BlockBuilder;
        getTranslationKeyGroup(): string;
        notify(): void;
        /**
         * Makes the block a redstone conductor.
        */
        redstoneConductor(b: boolean): Internal.BlockBuilder;
        noSoundType(): Internal.BlockBuilder;
        /**
         * Modifies the block's item representation.
        */
        item(i: Internal.Consumer_<Internal.BlockItemBuilder>): Internal.BlockBuilder;
        /**
         * Set the default state of the block.
        */
        defaultState(callbackJS: Internal.Consumer_<Internal.BlockStateModifyCallbackJS>): Internal.BlockBuilder;
        /**
         * Set what happens when an entity steps on the block
         * This is called every tick for every entity standing on the block, so be careful what you do here.
        */
        steppedOn(callbackJS: Internal.Consumer_<Internal.EntitySteppedOnBlockCallbackJS>): Internal.BlockBuilder;
        /**
         * Helper method for setting the render type of the block to `translucent` correctly.
        */
        defaultTranslucent(): Internal.BlockBuilder;
        /**
         * Makes the block view blocking.
        */
        viewBlocking(b: boolean): Internal.BlockBuilder;
        /**
         * Add a crop output with a specific chance.
        */
        crop(output: any, chance: number): this;
        /**
         * Add a blockstate property to the block.
         * 
         * For example, facing, lit, etc.
        */
        property(property: Internal.Property_<any>): Internal.BlockBuilder;
        /**
         * Sets the blast resistance of the block. Defaults to 3.
        */
        resistance(r: number): Internal.BlockBuilder;
        gravelSoundType(): Internal.BlockBuilder;
        getBuilderTranslationKey(): string;
        /**
         * Set the shape of the block.
        */
        box(x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, scale16: boolean): Internal.BlockBuilder;
        /**
         * Set the callback for determining the blocks state when placed.
        */
        placementState(callbackJS: Internal.Consumer_<Internal.BlockStateModifyPlacementCallbackJS>): Internal.BlockBuilder;
        /**
         * Set if the block can be replaced by something else.
        */
        canBeReplaced(callbackJS: Internal.Predicate_<Internal.CanBeReplacedCallbackJS>): Internal.BlockBuilder;
        wait(): void;
        /**
         * Set how this block reacts after an explosion. Note the block has already been destroyed at this point
        */
        exploded(callbackJS: Internal.Consumer_<Internal.BlockExplodedCallbackJS>): Internal.BlockBuilder;
        /**
         * Sets the block's map color. Defaults to NONE.
        */
        mapColor(m: Internal.MapColor_): Internal.BlockBuilder;
        /**
         * Sets the render type of the block. Can be `cutout`, `cutout_mipped`, `translucent`, or `basic`.
        */
        renderType(l: string): Internal.BlockBuilder;
        stoneSoundType(): Internal.BlockBuilder;
        /**
         * Makes the block can be waterlogged.
        */
        waterlogged(): Internal.BlockBuilder;
        wait(arg0: number, arg1: number): void;
        /**
         * Set how high you can jump on the block.
        */
        jumpFactor(f: number): Internal.BlockBuilder;
        /**
         * Set the color of a specific layer of the block.
        */
        color(color: Internal.BlockTintFunction_): Internal.BlockBuilder;
        generateDataJsons(generator: Internal.DataJsonGenerator_): void;
        texture(id: string, tex: string): Internal.BlockBuilder;
        /**
         * Texture a specific side of the block.
        */
        textureSide(direction: Internal.Direction_, tex: string): Internal.BlockBuilder;
        /**
         * Checks if the block can be waterlogged.
        */
        canBeWaterlogged(): boolean;
        /**
         * Tags both the block and the item with the given tag.
        */
        tag(arg0: ResourceLocation_): Internal.BuilderBase<any>;
        glassSoundType(): Internal.BlockBuilder;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        getWaterlogged(): boolean;
        /**
         * Tags the block with the given tag.
        */
        tagBlock(tag: ResourceLocation_): Internal.BlockBuilder;
        /**
         * Sets the opacity of the block. Opaque blocks do not let light through.
        */
        opaque(o: boolean): Internal.BlockBuilder;
        /**
         * Makes mobs not spawn on the block.
        */
        noValidSpawns(b: boolean): Internal.BlockBuilder;
        material(material: string): Internal.BlockBuilder;
        /**
         * Makes the block transparent.
        */
        transparent(b: boolean): Internal.BlockBuilder;
        /**
         * Helper method for setting the render type of the block to `cutout` correctly.
        */
        defaultCutout(): Internal.BlockBuilder;
        survive(surviveCallback: Internal.CropBlockBuilder$SurviveCallback_): this;
        /**
         * Sets the block should be a full block or not, like cactus or doors.
        */
        fullBlock(f: boolean): Internal.BlockBuilder;
        /**
         * Makes the block not collide with entities.
        */
        noCollision(): Internal.BlockBuilder;
        hashCode(): number;
        growTick(growSpeedCallback: Internal.ToDoubleFunction_<Internal.RandomTickCallbackJS>): this;
        /**
         * Makes the block require a tool to have drops when broken.
        */
        requiresTool(): Internal.BlockBuilder;
        equals(arg0: any): boolean;
        generateAssetJsons(generator: Internal.AssetJsonGenerator_): void;
        get registryType(): Internal.RegistryInfo<any>
        get class(): typeof any
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        set waterlogged(waterlogged: boolean)
        get translationKeyGroup(): string
        get builderTranslationKey(): string
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        get waterlogged(): boolean
    }
    type CropBlockBuilder_ = CropBlockBuilder;
    interface CommandBuildContext {
        abstract holderLookup<T>(arg0: Internal.ResourceKey_<Internal.Registry<T>>): Internal.HolderLookup<T>;
        configurable($$0: Internal.RegistryAccess_, $$1: Internal.FeatureFlagSet_): Internal.CommandBuildContext$Configurable;
        simple($$0: Internal.HolderLookup$Provider_, $$1: Internal.FeatureFlagSet_): this;
        (arg0: Internal.ResourceKey<Internal.Registry<T>>): Internal.HolderLookup_<T>;
    }
    type CommandBuildContext_ = CommandBuildContext | ((arg0: Internal.ResourceKey<Internal.Registry<T>>)=> Internal.HolderLookup_<T>);
    class Tesselator implements Internal.MixinSetTessBuffer {
        constructor()
        constructor($$0: number)
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        static setInstance(tes: Internal.Tesselator_): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        getBuilder(): Internal.BufferBuilder;
        static setInstance$inline_$md$424943$0(arg0: Internal.Tesselator_): void;
        end(): void;
        wait(): void;
        static getInstance(): Internal.Tesselator;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        get class(): typeof any
        set instance(tes: Internal.Tesselator_)
        get builder(): Internal.BufferBuilder
        set instance$inline_$md$424943$0(arg0: Internal.Tesselator_)
        get instance(): Internal.Tesselator
    }
    type Tesselator_ = Tesselator;
    abstract class AbstractHorse extends Internal.Animal implements Internal.AbstractHorseAccess, Internal.AbstractHorseAccessor, Internal.HasCustomInventoryScreen, Internal.Saddleable, Internal.OwnableEntity, net.minecraft.world.ContainerListener, Internal.PlayerRideableJumping {
        handler$hak000$gobber2$gobberOccludeVibrationSignals(cir: Internal.CallbackInfoReturnable_<any>): void;
        handler$fed001$extraalchemy$writeNbt(tag: Internal.CompoundTag_, cb: Internal.CallbackInfo_): void;
        etf$getType(): Internal.EntityType<any>;
        getUpVector($$0: number): Vec3d;
        gameEvent($$0: Internal.GameEvent_, $$1: Internal.Entity_): void;
        static checkMobSpawnRules($$0: Internal.EntityType_<Internal.Mob>, $$1: Internal.LevelAccessor_, $$2: Internal.MobSpawnType_, $$3: BlockPos_, $$4: Internal.RandomSource_): boolean;
        setDefaultMovementSpeedMultiplier(speed: number): void;
        handler$gdo000$faster_entity_animations$getEatingAnimationProgress(f: number, info: Internal.CallbackInfoReturnable_<any>): void;
        isSuppressingBounce(): boolean;
        setTarget($$0: Internal.LivingEntity_): void;
        handler$gdo000$faster_entity_animations$getAngryAnimationProgress(f: number, info: Internal.CallbackInfoReturnable_<any>): void;
        handler$han001$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        setCulled(value: boolean): void;
        handler$leb003$puzzleslib$hurt(source: DamageSource_, amount: number, callback: Internal.CallbackInfoReturnable_<any>): void;
        isOnFire(): boolean;
        getOwner(): Internal.LivingEntity;
        getPositionCodec(): Internal.VecDeltaCodec;
        setMaxUpStep($$0: number): void;
        updateFluidHeightAndDoFluidPushing($$0: Internal.TagKey_<Internal.Fluid>, $$1: number): boolean;
        convertTo<T extends Internal.Mob>($$0: Internal.EntityType_<T>, $$1: boolean): T;
        getFallFlyingTicks(): number;
        setPosition(x: number, y: number, z: number): void;
        runCommandSilent(command: string): number;
        chunkPosition(): Internal.ChunkPos;
        emf$isOnGround(): boolean;
        dropLeash($$0: boolean, $$1: boolean): void;
        gameEvent($$0: Internal.GameEvent_): void;
        setXxa($$0: number): void;
        setDelayedLeashHolderId($$0: number): void;
        isShiftKeyDown(): boolean;
        setUUID($$0: Internal.UUID_): void;
        checkBelowWorld(): void;
        handler$leb000$puzzleslib$startUsingItem(hand: Internal.InteractionHand_, callback: Internal.CallbackInfo_): void;
        setMotionZ(z: number): void;
        "deserializeNBT(net.minecraft.nbt.Tag)"(arg0: Internal.Tag_): void;
        canFreeze(): boolean;
        ignoreExplosion(): boolean;
        getBlockY(): number;
        getIsInsideStructureTracker(): Internal.IsInsideStructureTracker;
        setPlayerHitTimer(arg0: number): void;
        isSpectator(): boolean;
        setMainHandItem(item: Internal.ItemStack_): void;
        removeEffectNoUpdate($$0: Internal.MobEffect_): Internal.MobEffectInstance;
        spawnAtLocation($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        getPersistentData(): Internal.CompoundTag;
        getHealth(): number;
        getMaxHealth(): number;
        emf$isGlowing(): boolean;
        setPathfindingMalus($$0: Internal.BlockPathTypes_, $$1: number): void;
        isRegisteredToWorld(): boolean;
        getRandomZ($$0: number): number;
        pehkui_getOnGround(): boolean;
        setAggressive($$0: boolean): void;
        handler$lef000$puzzleslib$checkDespawn(callback: Internal.CallbackInfo_): void;
        getFusionModel(layerIndex: number): Internal.Triple<any, any, any>;
        setRemoved($$0: Internal.Entity$RemovalReason_): void;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>, initializer: Internal.Supplier_<A>): A;
        getDistanceSq($$0: number, $$1: number, $$2: number): number;
        isInWaterRainOrBubble(): boolean;
        getRemovalReason(): Internal.Entity$RemovalReason;
        etf$getVelocity(): Vec3d;
        handler$lcn000$puzzleslib$executeRidersJump(playerJumpPendingScale: number, travelVector: Vec3d_, callback: Internal.CallbackInfo_): void;
        hex$markHurt(): void;
        resetFallDistance(): void;
        canSprint(): boolean;
        blockPosition(): BlockPos;
        isEating(): boolean;
        setBoundingBox($$0: Internal.AABB_): void;
        isAmbientCreature(): boolean;
        setZza($$0: number): void;
        getBlock(): Internal.BlockContainerJS;
        setEquipment(slot: Internal.EquipmentSlot_, item: Internal.ItemStack_): void;
        etf$getHandItems(): Internal.Iterable<any>;
        randomTeleport($$0: number, $$1: number, $$2: number, $$3: boolean): boolean;
        getName(): net.minecraft.network.chat.Component;
        playAmbientSound(): void;
        onGround(): boolean;
        handler$leb000$puzzleslib$canBeAffected(effectInstance: Internal.MobEffectInstance_, callback: Internal.CallbackInfoReturnable_<any>): void;
        getControlledVehicle(): Internal.Entity;
        isOnSameTeam($$0: Internal.Entity_): boolean;
        getArmorValue(): number;
        tick(): void;
        localvar$lef000$puzzleslib$setTarget(entity: Internal.LivingEntity_): Internal.LivingEntity;
        getKillCredit(): Internal.LivingEntity;
        emf$isTouchingWater(): boolean;
        emf$getVariableMap(): Internal.Object2FloatOpenHashMap<any>;
        getComponentContainer(): Internal.ComponentContainer;
        hasPermissions($$0: number): boolean;
        getDynamicLightPrevZ(): number;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        pehkui_readScaleNbt(nbt: Internal.CompoundTag_): void;
        setOutOfCamera(value: boolean): void;
        static createMobAttributes(): Internal.AttributeSupplier$Builder;
        isAutoSpinAttack(): boolean;
        getRemainingFireTicks(): number;
        botania_getAmbientSound(): Internal.SoundEvent;
        onlyOpCanSetNbt(): boolean;
        tcdcommons_getCustomData(): Internal.GenericProperties<any>;
        fireImmune(): boolean;
        addMotion($$0: number, $$1: number, $$2: number): void;
        getMaxFallDistance(): number;
        isHolding($$0: Internal.Item_): boolean;
        getZ($$0: number): number;
        static areAllEffectsAmbient($$0: Internal.Collection_<Internal.MobEffectInstance>): boolean;
        doHurtTarget($$0: Internal.Entity_): boolean;
        getTicksFrozen(): number;
        wrapWithCondition$kom000$porting_lib_entity$port_lib$captureDrops(level: Internal.Level_, entity: Internal.Entity_): boolean;
        handler$lef000$puzzleslib$addAdditionalSaveData(compound: Internal.CompoundTag_, callback: Internal.CallbackInfo_): void;
        deflect(chance: number, source: Internal.Entity_): boolean;
        getRandomX($$0: number): number;
        getDynamicLightZ(): number;
        spawnAtLocation($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        pick($$0: number, $$1: number, $$2: boolean): Internal.HitResult;
        getVoicePitch(): number;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        setSleepingPos($$0: BlockPos_): void;
        changeDimension(p_20118_: Internal.ServerLevel_, teleporter: Internal.ITeleporter_): Internal.Entity;
        isDescending(): boolean;
        getAttributeBaseValue($$0: Internal.Attribute_): number;
        emf$getPitch(): number;
        sendEffectToPassengers($$0: Internal.MobEffectInstance_): void;
        getHeadRotSpeed(): number;
        getLastHurtByPlayer(): Internal.Player;
        getYHeadRot(): number;
        handler$cbi000$besmirchment$isTeammate(other: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>): void;
        localvar$leb000$puzzleslib$addEffect(oldEffectInstance: Internal.MobEffectInstance_, effectInstance: Internal.MobEffectInstance_, entity: Internal.Entity_): Internal.MobEffectInstance;
        getProjectile($$0: Internal.ItemStack_): Internal.ItemStack;
        static getAlpha(le: Internal.LivingEntity_, partialTicks: number): number;
        frameworkGetDataHolder(): com.mrcrayfish.framework.entity.sync.DataHolder;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        syncPacketPositionCodec($$0: number, $$1: number, $$2: number): void;
        setAbsorptionAmount($$0: number): void;
        setRecallData(pos: Internal.DimensionalPosition_): void;
        port_lib$spawnItemParticles(arg0: Internal.ItemStack_, arg1: number): void;
        shouldRenderAtSqrDistance($$0: number): boolean;
        getAttachedOrSet<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        damageSources(): Internal.DamageSources;
        removeAttached<A>(type: Internal.AttachmentType_<A>): A;
        removeAllGoals($$0: Internal.Predicate_<Internal.Goal>): void;
        swing(): void;
        recreateFromPacket($$0: Internal.ClientboundAddEntityPacket_): void;
        setDeltaMovement($$0: Vec3d_): void;
        getLeashOffset($$0: number): Vec3d;
        isBaby(): boolean;
        isCulled(): boolean;
        damageEquipment(slot: Internal.EquipmentSlot_): void;
        isGlowing(): boolean;
        getWalkTargetValue($$0: BlockPos_): number;
        canBreatheUnderwater(): boolean;
        getLeashedByEntities(): Internal.Set<any>;
        die($$0: DamageSource_): void;
        etf$getOptifineId(): number;
        removeAllEffects(): boolean;
        dynamicLightWorld(): Internal.Level;
        getLeashOffset(): Vec3d;
        fedFood($$0: Internal.Player_, $$1: Internal.ItemStack_): Internal.InteractionResult;
        hasLineOfSight($$0: Internal.Entity_): boolean;
        hex$getLastHurt(): number;
        onClimbable(): boolean;
        isAttackable(): boolean;
        getSaddleSoundEvent(): Internal.SoundEvent;
        getSlot($$0: number): Internal.SlotAccess;
        "deserializeNBT(net.minecraft.nbt.CompoundTag)"(nbt: Internal.CompoundTag_): void;
        emf$isInLava(): boolean;
        pehkui_constructScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        stopSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isUnderWater(): boolean;
        stopRiding(): void;
        getLeashHolder(): Internal.Entity;
        getX($$0: number): number;
        getSensing(): Internal.Sensing;
        localvar$kpc000$porting_lib_entity$port_lib$modifyMultiplier(multiplier: number): number;
        getLegsArmorItem(): Internal.ItemStack;
        getLuminance(): number;
        callUnsetRemoved(): void;
        captureDrops(value: Internal.Collection_<Internal.ItemEntity>): Internal.Collection<Internal.ItemEntity>;
        getSelfAndPassengers(): Internal.Stream<any>;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        handler$egi000$collective$LivingEntity_hurt(damageSource: DamageSource_, f: number, ci: Internal.CallbackInfoReturnable_<any>): void;
        getDeltaMovement(): Vec3d;
        canTakeItem($$0: Internal.ItemStack_): boolean;
        shouldDropExperience(): boolean;
        hasPassenger($$0: Internal.Entity_): boolean;
        be_getTravelerState(): Internal.TravelerState;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        getDynamicLightX(): number;
        setSecondsOnFire($$0: number): void;
        moveTo($$0: number, $$1: number, $$2: number): void;
        emf$getZ(): number;
        "getDisplayName()"(): net.minecraft.network.chat.Component;
        getLootTable(): ResourceLocation;
        getTicksUsingItem(): number;
        bettertrims$getWornMaterials(): Internal.List<any>;
        getArrowCount(): number;
        getMoveControl(): Internal.MoveControl;
        setMotion($$0: number, $$1: number, $$2: number): void;
        setStanding($$0: boolean): void;
        playSound($$0: Internal.SoundEvent_): void;
        handler$mjp000$supplementaries$eatSugarCube(player: Internal.Player_, stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getDefaultMovementSpeed(): number;
        handler$ikg000$lithium$tryShortcutFluidPushing(tag: Internal.TagKey_<any>, speed: number, cir: Internal.CallbackInfoReturnable_<any>, box: Internal.AABB_, x1: number, x2: number, y1: number, y2: number, z1: number, z2: number, zero: number): void;
        handler$hak000$gobber2$setFrozenTicks(frozenTicks: number, ci: Internal.CallbackInfo_): void;
        restoreFrom($$0: Internal.Entity_): void;
        method_6062(): boolean;
        isPeacefulCreature(): boolean;
        setOnGround($$0: boolean): void;
        addEffect($$0: Internal.MobEffectInstance_, $$1: Internal.Entity_): boolean;
        emf$getYaw(): number;
        ate(): void;
        setPos($$0: number, $$1: number, $$2: number): void;
        notify(): void;
        setPersistenceRequired(): void;
        getLastHurtByMobTimestamp(): number;
        getVehicle(): Internal.Entity;
        canFallInLove(): boolean;
        isEffectiveAi(): boolean;
        handler$kom000$porting_lib_entity$port_lib$startRiding(entity: Internal.Entity_, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        startRiding($$0: Internal.Entity_, $$1: boolean): boolean;
        getStringUuid(): string;
        setSwimming($$0: boolean): void;
        getMainArm(): Internal.HumanoidArm;
        checkSpawnRules($$0: Internal.LevelAccessor_, $$1: Internal.MobSpawnType_): boolean;
        getRotationVector(): Internal.Vec2;
        getHurtDir(): number;
        etf$getBlockY(): number;
        isSprinting(): boolean;
        isMaxGroupSizeReached($$0: number): boolean;
        getMotionY(): number;
        getOffhandItem(): Internal.ItemStack;
        canCollideWith($$0: Internal.Entity_): boolean;
        setLuminance(luminance: number): void;
        getBlockExplosionResistance($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.FluidState_, $$5: number): number;
        setLootTable(arg0: ResourceLocation_): void;
        clearSleepingPos(): void;
        canSpawnSprintParticle(): boolean;
        "moveTo(net.minecraft.core.BlockPos,float,float)"($$0: BlockPos_, $$1: number, $$2: number): void;
        hex$checkTotemDeathProtection(arg0: DamageSource_): boolean;
        getLastHurtMob(): Internal.LivingEntity;
        moveRelative($$0: number, $$1: Vec3d_): void;
        saveAsPassenger($$0: Internal.CompoundTag_): boolean;
        static gatherClosestChunks(chunks: Internal.LongSet_, x: number, y: number, z: number): void;
        handler$kom000$porting_lib_entity$afterSave(nbt: Internal.CompoundTag_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDamageSource(): DamageSource;
        getSoundSource(): Internal.SoundSource;
        isJumping(): boolean;
        setNoActionTime($$0: number): void;
        setMovementSpeedAddition(speed: number): void;
        removeAfterChangingDimensions(): void;
        equipmentHasChanged($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        getPose(): Internal.Pose;
        getAttribute($$0: Internal.Attribute_): Internal.AttributeInstance;
        setPositionAndRotation($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        canBeAffected($$0: Internal.MobEffectInstance_): boolean;
        ageUp($$0: number): void;
        getRestrictCenter(): BlockPos;
        isLeftHanded(): boolean;
        invokeShouldDropLoot(): boolean;
        handler$kpc000$porting_lib_entity$port_lib$onFinishUsing(ci: Internal.CallbackInfo_, hand: Internal.InteractionHand_, result: Internal.ItemStack_): void;
        etf$getUuid(): Internal.UUID;
        removeVehicle(): void;
        shouldFusionRecomputeModel(layerIndex: number): boolean;
        modifyExpressionValue$zcl000$porting_lib_base$port_lib$canContinueUsing(original: boolean): boolean;
        setZ(z: number): void;
        getY(): number;
        deserializeNBT(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        finalizeSpawnChildFromBreeding($$0: Internal.ServerLevel_, $$1: Internal.Animal_, $$2: Internal.AgeableMob_): void;
        eat($$0: Internal.Level_, $$1: Internal.ItemStack_): Internal.ItemStack;
        setIsJumping($$0: boolean): void;
        bookshelf$makePoofParticles(): void;
        isWithinMeleeAttackRange($$0: Internal.LivingEntity_): boolean;
        setCurrentModifyFoodPowers(powers: Internal.List_<any>): void;
        broadcastBreakEvent($$0: Internal.EquipmentSlot_): void;
        modifyExpressionValue$zhf000$additionalentityattributes$additionalEntityAttributes$modifyUpwardSwimming(original: number, fluid: Internal.TagKey_<any>): number;
        handler$nbm000$things$onShieldBlock(source: DamageSource_, cir: Internal.CallbackInfoReturnable_<any>): void;
        showVehicleHealth(): boolean;
        getDistance(pos: BlockPos_): number;
        isBlocking(): boolean;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number): void;
        removeAttribute(attribute: Internal.Attribute_, identifier: string): void;
        emf$getVelocity(): Vec3d;
        handler$lef000$puzzleslib$finalizeSpawn(level: Internal.ServerLevelAccessor_, difficulty: Internal.DifficultyInstance_, reason: Internal.MobSpawnType_, spawnData: Internal.SpawnGroupData_, dataTag: Internal.CompoundTag_, callback: Internal.CallbackInfoReturnable_<any>): void;
        etf$isBlockEntity(): boolean;
        shouldUpdateDynamicLight(): boolean;
        isPushedByFluid(): boolean;
        setOriginalFoodStack(original: Internal.ItemStack_): void;
        getArmorCoverPercentage(): number;
        handleRelativeFrictionAndCalculateMovement($$0: Vec3d_, $$1: number): Vec3d;
        turn($$0: number, $$1: number): void;
        getAirSupply(): number;
        moveTo($$0: BlockPos_, $$1: number, $$2: number): void;
        isPlayer(): boolean;
        isAnimal(): boolean;
        "handler$fgd000$fabric-dimensions-v1$getTeleportTarget"(destination: Internal.ServerLevel_, cir: Internal.CallbackInfoReturnable_<any>): void;
        canBeCollidedWith(): boolean;
        getMotionDirection(): Internal.Direction;
        asComponentProvider(): Internal.ComponentProvider;
        lavaHurt(): void;
        handleDamageEvent($$0: DamageSource_): void;
        getFabricBalmData(): Internal.CompoundTag;
        canChangeDimensions(): boolean;
        static tickEntity(entity: Internal.Entity_): void;
        getCommandSenderWorld(): Internal.Level;
        getTotalMovementSpeed(): number;
        changeDimension($$0: Internal.ServerLevel_): Internal.Entity;
        localvar$zno000$apoli$modifyFallingVelocity(in_: number): number;
        handler$kom000$porting_lib_entity$afterLoad(nbt: Internal.CompoundTag_, ci: Internal.CallbackInfo_): void;
        pehkui_shouldIgnoreScaleNbt(): boolean;
        isMoving(): boolean;
        attack(hp: number): void;
        getAttributes(): Internal.AttributeMap;
        "hasPassenger(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.Entity>): boolean;
        botania_playHurtSound(arg0: DamageSource_): void;
        getDimensions($$0: Internal.Pose_): Internal.EntityDimensions;
        spawnChildFromBreeding($$0: Internal.ServerLevel_, $$1: Internal.Animal_): void;
        setInLoveTime($$0: number): void;
        invokeGetLeashOffset(): Vec3d;
        isSwimming(): boolean;
        setSprinting($$0: boolean): void;
        mayInteract($$0: Internal.Level_, $$1: BlockPos_): boolean;
        handler$kpc000$porting_lib_entity$port_lib$attackEvent(source: DamageSource_, amount: number, cir: Internal.CallbackInfoReturnable_<any>): void;
        getDynamicLightLevel(): Internal.Level;
        setPortalCooldown(): void;
        getAttackAnim($$0: number): number;
        hex$setLastHurt(arg0: number): void;
        setX(x: number): void;
        getPortalWaitTime(): number;
        getBlockStateOn(): Internal.BlockState;
        wantsToPickUp($$0: Internal.ItemStack_): boolean;
        getItemBySlot($$0: Internal.EquipmentSlot_): Internal.ItemStack;
        getFluidHeightLoosely(tag: Internal.TagKey_<any>): number;
        setOwnerUUID($$0: Internal.UUID_): void;
        getFluidJumpThreshold(): number;
        getCachedSouls(): number;
        "setPositionAndRotation(double,double,double,float,float)"($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        isInvisibleTo($$0: Internal.Player_): boolean;
        stopSleeping(): void;
        setAirSupply($$0: number): void;
        getOnPos(): BlockPos;
        etf$getWorld(): Internal.Level;
        isUndead(): boolean;
        static createBaseHorseAttributes(): Internal.AttributeSupplier$Builder;
        static createLivingAttributes(): Internal.AttributeSupplier$Builder;
        setUseItemRemaining(arg0: number): void;
        pehkui_getScales(): Internal.Map<any, any>;
        getTargetSelector(): Internal.GoalSelector;
        setRegisteredToWorld(navigation: Internal.PathNavigation_): void;
        isSleeping(): boolean;
        stopUsingItem(): void;
        etf$getNbt(): Internal.CompoundTag;
        acceptsFailure(): boolean;
        etf$getBlockPos(): BlockPos;
        pehkui_setShouldIgnoreScaleNbt(ignore: boolean): void;
        setOnGroundWithKnownMovement($$0: boolean, $$1: Vec3d_): void;
        getFluidFallingAdjustedMovement($$0: number, $$1: boolean, $$2: Vec3d_): Vec3d;
        setOldPosAndRot(): void;
        localvar$cjk000$bettertridents$doHurtTarget$modifyVariable$store(damageAmount: number, entity: Internal.Entity_): number;
        isFree($$0: number, $$1: number, $$2: number): boolean;
        getDismountPoses(): Internal.ImmutableList<Internal.Pose>;
        getLastHurtMobTimestamp(): number;
        lithiumOnEquipmentChanged(): void;
        "moveTo(double,double,double)"($$0: number, $$1: number, $$2: number): void;
        setRemainingFireTicks($$0: number): void;
        emf$age(): number;
        etf$hasCustomName(): boolean;
        /**
         * @deprecated
        */
        getOnPosLegacy(): BlockPos;
        port_lib$isJumping(): boolean;
        setPos($$0: Vec3d_): void;
        localvar$leb000$puzzleslib$knockback$2(ratioX: number): number;
        static "tickEntity(net.minecraft.world.entity.LivingEntity)"(entity: Internal.LivingEntity_): void;
        updateCachedSouls(): void;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        setCanPickUpLoot($$0: boolean): void;
        getMainHandItem(): Internal.ItemStack;
        canEatGrass(): boolean;
        handler$kom000$porting_lib_entity$port_lib$removeRidingEntity(ci: Internal.CallbackInfo_): void;
        setSilent($$0: boolean): void;
        openCustomInventoryScreen($$0: Internal.Player_): void;
        captureDrops(): Internal.Collection<Internal.ItemEntity>;
        hasExactlyOnePlayerPassenger(): boolean;
        canBeSeenAsEnemy(): boolean;
        setLeftHanded($$0: boolean): void;
        getActiveEffects(): Internal.Collection<Internal.MobEffectInstance>;
        isOnPortalCooldown(): boolean;
        hurtArmor($$0: DamageSource_, $$1: number): void;
        canAttack($$0: Internal.LivingEntity_, $$1: Internal.TargetingConditions_): boolean;
        getAttributeValue($$0: Internal.Holder_<Internal.Attribute>): number;
        lambdynlights$setTrackedLitChunkPos(trackedLitChunkPos: Internal.LongSet_): void;
        fzzy_core_setModifierContainer(container: Internal.ModifierContainer_): void;
        setPitch($$0: number): void;
        setPosRaw($$0: number, $$1: number, $$2: number): void;
        handleEntityEvent($$0: number): void;
        isUsingItem(): boolean;
        isAlwaysTicking(): boolean;
        interactAt($$0: Internal.Player_, $$1: Vec3d_, $$2: Internal.InteractionHand_): Internal.InteractionResult;
        emf$getX(): number;
        puzzleslib$acceptCapturedDrops(capturedDrops: Internal.Collection_<any>): Internal.Collection<any>;
        handler$hak000$gobber2$gobberIsFireImmune(cir: Internal.CallbackInfoReturnable_<any>): void;
        onPlayerJump($$0: number): void;
        lerpTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: boolean): void;
        onPassengerTurned($$0: Internal.Entity_): void;
        modifyReturnValue$zhe000$additionalentityattributes$getMaxAir(original: number): number;
        spawnAtLocation($$0: Internal.ItemLike_): Internal.ItemEntity;
        emf$hasPassengers(): boolean;
        serializeNBT(): Internal.CompoundTag;
        setAttached(type: Internal.AttachmentType_<any>, value: any): any;
        port_lib$getEntityString(): string;
        markEffectsDirty(): void;
        lithiumOnBlockCacheDeleted(): void;
        "spawnAtLocation(net.minecraft.world.level.ItemLike,int)"($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        setInvulnerable($$0: boolean): void;
        push($$0: Internal.Entity_): void;
        emf$hasVehicle(): boolean;
        canMate($$0: Internal.Animal_): boolean;
        method_5992($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        maxUpStep(): number;
        getDynamicLightPrevY(): number;
        localvar$leb000$puzzleslib$hurt$1(amount: number, source: DamageSource_): number;
        setGlowing($$0: boolean): void;
        load($$0: Internal.CompoundTag_): void;
        "broadcastBreakEvent(net.minecraft.world.entity.EquipmentSlot)"($$0: Internal.EquipmentSlot_): void;
        setLeashedTo($$0: Internal.Entity_, $$1: boolean): void;
        isAlive(): boolean;
        startSleeping($$0: BlockPos_): void;
        getBbHeight(): number;
        getMeleeAttackRangeSqr($$0: Internal.LivingEntity_): number;
        handler$fed002$extraalchemy$readNbt(tag: Internal.CompoundTag_, cb: Internal.CallbackInfo_): void;
        bookshelf$getDrinkingSound(arg0: Internal.ItemStack_): Internal.SoundEvent;
        getTags(): Internal.Set<string>;
        getViewVector($$0: number): Vec3d;
        getLastAttacker(): Internal.LivingEntity;
        hasControllingPassenger(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number, $$2: number): boolean;
        absMoveTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        getLastRollTicks(): number;
        getGoalSelector(): Internal.GoalSelector;
        localvar$leb000$puzzleslib$causeFallDamage$2(damageMultiplier: number): number;
        onPathfindingStart(): void;
        handler$zzb000$porting_lib_attributes$port_lib$entityGravity(travelVector: Vec3d_, ci: Internal.CallbackInfo_): void;
        getPercentFrozen(): number;
        setPortalCooldown($$0: number): void;
        hasGlowingTag(): boolean;
        shouldBlockExplode($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: number): boolean;
        emf$isInvisible(): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        isLeashed(): boolean;
        addEffect($$0: Internal.MobEffectInstance_): boolean;
        emf$isSprinting(): boolean;
        handler$leb000$puzzleslib$knockback$0(strength: number, ratioX: number, ratioZ: number, callback: Internal.CallbackInfo_): void;
        ageUp($$0: number, $$1: boolean): void;
        handler$egi000$collective$LivingEntity_tick(ci: Internal.CallbackInfo_): void;
        handler$gec000$faster_entity_animations$getLeaningPitch(f: number, info: Internal.CallbackInfoReturnable_<any>): void;
        canRiderInteract(): boolean;
        getViewXRot($$0: number): number;
        handler$leb001$puzzleslib$die(damageSource: DamageSource_, callback: Internal.CallbackInfo_): void;
        fabric_getAttachments(): Internal.Map<any, any>;
        setPose($$0: Internal.Pose_): void;
        getReachDistance(): number;
        getEntityType(): Internal.EntityType<any>;
        isWaterCreature(): boolean;
        hex$playHurtSound(arg0: DamageSource_): void;
        pehkui_getScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        toString(): string;
        canWearArmor(): boolean;
        etf$getScoreboardTeam(): Internal.Team;
        getBreedOffspring($$0: Internal.ServerLevel_, $$1: Internal.AgeableMob_): Internal.AgeableMob;
        setLastHurtByPlayer($$0: Internal.Player_): void;
        handler$ldh000$puzzleslib$removeVehicle(callback: Internal.CallbackInfo_): void;
        "getServer()"(): Internal.MinecraftServer;
        getAmbientStandSound(): Internal.SoundEvent;
        wasExperienceConsumed(): boolean;
        isPushable(): boolean;
        setYBodyRot($$0: number): void;
        foodEaten(is: Internal.ItemStack_): void;
        onClientRemoval(): void;
        getDistance(x: number, y: number, z: number): number;
        setMotionY(y: number): void;
        localvar$lcp000$puzzleslib$spawnChildFromBreeding(child: Internal.AgeableMob_, serverLevel: Internal.ServerLevel_, partner: Internal.Animal_): Internal.AgeableMob;
        getAttached(type: Internal.AttachmentType_<any>): any;
        setRotation(yaw: number, pitch: number): void;
        isDynamicLightEnabled(): boolean;
        handler$ldh000$puzzleslib$startRiding(vehicle: Internal.Entity_, force: boolean, callback: Internal.CallbackInfoReturnable_<any>): void;
        calculateEntityAnimation($$0: boolean): void;
        forceAddEffect($$0: Internal.MobEffectInstance_, $$1: Internal.Entity_): void;
        setBred($$0: boolean): void;
        setChestArmorItem(item: Internal.ItemStack_): void;
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        bookshelf$getHurtSound(arg0: DamageSource_): Internal.SoundEvent;
        onAboveBubbleCol($$0: boolean): void;
        archon$setOwner(uiud: string): void;
        "playSound(net.minecraft.sounds.SoundEvent,float,float)"($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        toComponentPacket(key: Internal.ComponentKey_<any>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        isPassenger(): boolean;
        hasPose($$0: Internal.Pose_): boolean;
        supp$setSlimedTicks(newSlimedTicks: number, sync: boolean): void;
        isEyeInFluid($$0: Internal.TagKey_<Internal.Fluid>): boolean;
        isInvulnerableTo($$0: DamageSource_): boolean;
        makeStuckInBlock($$0: Internal.BlockState_, $$1: Vec3d_): void;
        getAttachedOrGet<A>(type: Internal.AttachmentType_<A>, defaultValue: Internal.Supplier_<A>): A;
        isSensitiveToWater(): boolean;
        skipAttackInteraction($$0: Internal.Entity_): boolean;
        lerpMotion($$0: number, $$1: number, $$2: number): void;
        "getAttributeValue(net.minecraft.core.Holder)"($$0: Internal.Holder_<Internal.Attribute>): number;
        shouldRender($$0: number, $$1: number, $$2: number): boolean;
        getJumpControl(): Internal.JumpControl;
        localvar$zcl000$porting_lib_base$port_lib$setSlipperiness(p: number): number;
        getFeetArmorItem(): Internal.ItemStack;
        isSaddleable(): boolean;
        handler$bia000$axiom$onTurn(d: number, e: number, ci: Internal.CallbackInfo_): void;
        static getViewScale(): number;
        handler$mpg000$tcdcommons$onAddStatusEffect(effect: Internal.MobEffectInstance_, source: Internal.Entity_, ci: Internal.CallbackInfoReturnable_<any>): void;
        getVisualRotationYInDegrees(): number;
        setSpeed($$0: number): void;
        requiresCustomPersistence(): boolean;
        handler$nbm000$things$onShieldHit(attacker: Internal.LivingEntity_, ci: Internal.CallbackInfo_): void;
        isDiscrete(): boolean;
        unRide(): void;
        getLevel(): Internal.Level;
        "spawnAtLocation(net.minecraft.world.item.ItemStack)"($$0: Internal.ItemStack_): Internal.ItemEntity;
        getCombatTracker(): Internal.CombatTracker;
        getCustomJump(): number;
        updateDynamicGameEventListener($$0: Internal.BiConsumer_<Internal.DynamicGameEventListener<any>, Internal.ServerLevel>): void;
        canBreed(): boolean;
        "onSyncedDataUpdated(net.minecraft.network.syncher.EntityDataAccessor)"($$0: Internal.EntityDataAccessor_<any>): void;
        emf$prevY(): number;
        isNoAi(): boolean;
        extinguishFire(): void;
        getChestArmorItem(): Internal.ItemStack;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number): void;
        port_lib$lastPos(): BlockPos;
        tell(message: net.minecraft.network.chat.Component_): void;
        closerThan($$0: Internal.Entity_, $$1: number): boolean;
        hex$getSoundVolume(): number;
        getDistanceSq(pos: BlockPos_): number;
        indicateDamage($$0: number, $$1: number): void;
        localvar$nbm000$things$waxGlandWater(j: number): number;
        canBeSeenByAnyone(): boolean;
        emf$getTypeString(): string;
        isFullyFrozen(): boolean;
        litematica_setWorld(arg0: Internal.Level_): void;
        isInWall(): boolean;
        getAllSlots(): Internal.Iterable<Internal.ItemStack>;
        getInventory(): Internal.SimpleContainer;
        handler$bfg003$artifacts$tick(ci: Internal.CallbackInfo_): void;
        remove($$0: Internal.Entity$RemovalReason_): void;
        getScale(): number;
        isSuppressingSlidingDownLadder(): boolean;
        getBlockZ(): number;
        handler$egi000$collective$LivingEntity_die(damageSource: DamageSource_, ci: Internal.CallbackInfo_): void;
        dampensVibrations(): boolean;
        hasAttached(type: Internal.AttachmentType_<any>): boolean;
        isSilent(): boolean;
        setUseItem(arg0: Internal.ItemStack_): void;
        "playSound(net.minecraft.sounds.SoundEvent)"(id: Internal.SoundEvent_): void;
        getPitch(): number;
        getPathfindingMalus($$0: Internal.BlockPathTypes_): number;
        modify$nbm000$things$waxGlandLava(speed: number): number;
        getRandom(): Internal.RandomSource;
        canReplaceEqualItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        rotate($$0: Internal.Rotation_): number;
        handler$hcn000$hexcasting$onThunderHit(entityType: Internal.EntityType_<any>, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        getPassengersAndSelf(): Internal.Stream<any>;
        handler$leb000$puzzleslib$causeFallDamage$0(distance: number, damageMultiplier: number, damageSource: DamageSource_, callback: Internal.CallbackInfoReturnable_<any>): void;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        "getAttributeBaseValue(net.minecraft.core.Holder)"($$0: Internal.Holder_<Internal.Attribute>): number;
        getMaxTemper(): number;
        method_5652($$0: Internal.CompoundTag_): void;
        clearRestriction(): void;
        redirect$jgg000$moonlight$fixSpawnAnimX(instance: Internal.Mob_, v: number): number;
        getOriginalFoodStack(): Internal.ItemStack;
        getAge(): number;
        rayTrace(): Internal.RayTraceResultJS;
        alwaysAccepts(): boolean;
        "isHolding(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.ItemStack>): boolean;
        getNoActionTime(): number;
        isVisuallyCrawling(): boolean;
        isAggressive(): boolean;
        isWearingArmor(): boolean;
        setYya($$0: number): void;
        setDropChance($$0: Internal.EquipmentSlot_, $$1: number): void;
        handler$ieb000$lambdynlights$onRemove(ci: Internal.CallbackInfo_): void;
        "broadcastBreakEvent(net.minecraft.world.InteractionHand)"($$0: Internal.InteractionHand_): void;
        port_lib$setRemovalReason(arg0: Internal.Entity$RemovalReason_): void;
        teleportRelative($$0: number, $$1: number, $$2: number): void;
        isFood($$0: Internal.ItemStack_): boolean;
        setBaby($$0: boolean): void;
        getTemper(): number;
        getLastHurtByMob(): Internal.LivingEntity;
        pehkui_setScaleCache(scaleCache: Internal.ScaleData_[]): void;
        isInWaterOrBubble(): boolean;
        botania_setLoveCause(arg0: Internal.UUID_): void;
        tameWithName($$0: Internal.Player_): boolean;
        getPortalCooldown(): number;
        getItem(): Internal.ItemStack;
        causeFallDamage($$0: number, $$1: number, $$2: DamageSource_): boolean;
        getDynamicLightChunksToRebuild(forced: boolean): Internal.LongSet;
        getFlag($$0: number): boolean;
        releaseUsingItem(): void;
        bw_getNextAirOnLand(arg0: number): number;
        getPosition($$0: number): Vec3d;
        removeFreeWill(): void;
        handler$leb000$puzzleslib$removeAllEffects(callback: Internal.CallbackInfoReturnable_<any>): void;
        removeWhenFarAway($$0: number): boolean;
        wait(arg0: number): void;
        isIgnoringBlockTriggers(): boolean;
        setRecordPlayingNearby($$0: BlockPos_, $$1: boolean): void;
        etf$getItemsEquipped(): Internal.Iterable<any>;
        getHandHoldingItemAngle($$0: Internal.Item_): Vec3d;
        hasItemInSlot($$0: Internal.EquipmentSlot_): boolean;
        distanceToSqr($$0: Vec3d_): number;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        modifyAttached<A>(type: Internal.AttachmentType_<A>, modifier: Internal.UnaryOperator_<A>): A;
        isSteppingCarefully(): boolean;
        handler$zno000$apoli$doSpiderClimbing(info: Internal.CallbackInfoReturnable_<any>): void;
        "spawnAtLocation(net.minecraft.world.item.ItemStack,float)"($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        getBlockX(): number;
        /**
         * @deprecated
        */
        getLightLevelDependentMagicValue(): number;
        isFallFlying(): boolean;
        getEncodeId(): string;
        puzzleslib$getSpawnType(): Internal.MobSpawnType;
        makeMad(): void;
        bettertrims$setAvoidedDamage(avoidDamage: boolean): void;
        getY($$0: number): number;
        emf$prevPitch(): number;
        getMaxHeadXRot(): number;
        getNbt(): Internal.CompoundTag;
        setInvisible($$0: boolean): void;
        etf$getArmorItems(): Internal.Iterable<any>;
        isSaddled(): boolean;
        isSubmergedInLoosely(tag: Internal.TagKey_<any>): boolean;
        getEffect($$0: Internal.MobEffect_): Internal.MobEffectInstance;
        setTotalMovementSpeedMultiplier(speed: number): void;
        getDynamicLightY(): number;
        setHealth($$0: number): void;
        attack($$0: DamageSource_, $$1: number): boolean;
        onInsideBubbleColumn($$0: boolean): void;
        handler$cfa000$betterend$be_hurt(source: DamageSource_, amount: number, info: Internal.CallbackInfoReturnable_<any>): void;
        getAmbientStandInterval(): number;
        getEyePosition(): Vec3d;
        getEyeHeight(): number;
        setDiscardFriction($$0: boolean): void;
        hasPassenger($$0: Internal.Predicate_<Internal.Entity>): boolean;
        bettertridents$getLastDamageSource(): DamageSource;
        getYaw(): number;
        swing($$0: Internal.InteractionHand_, $$1: boolean): void;
        getUsedItemHand(): Internal.InteractionHand;
        setDefaultMovementSpeed(speed: number): void;
        canAttackType($$0: Internal.EntityType_<any>): boolean;
        hex$setLastDamageStamp(arg0: number): void;
        canEntityBeSeen(entity: Internal.LivingEntity_): boolean;
        modifyExpressionValue$zhf000$additionalentityattributes$additionalEntityAttributes$knockDownwards(original: number): number;
        getBrain(): Internal.Brain<any>;
        modify$bpk000$bclib$be_travel(moveDelta: Vec3d_): Vec3d;
        setCustomNameVisible($$0: boolean): void;
        isAlliedTo($$0: Internal.Team_): boolean;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>): A;
        getControllingPassenger(): Internal.LivingEntity;
        canFireProjectileWeapon($$0: Internal.ProjectileWeaponItem_): boolean;
        bw_getNextAirUnderwater(arg0: number): number;
        getScriptType(): Internal.ScriptType;
        handler$leb000$puzzleslib$releaseUsingItem(callback: Internal.CallbackInfo_): void;
        equipSaddle($$0: Internal.SoundSource_): void;
        handler$cbm000$besmirchment$handleStatus(status: number, ci: Internal.CallbackInfo_): void;
        port_lib$getDeathSound(): Internal.SoundEvent;
        shouldDiscardFriction(): boolean;
        startRiding($$0: Internal.Entity_): boolean;
        saveWithoutId($$0: Internal.CompoundTag_): Internal.CompoundTag;
        getForward(): Vec3d;
        setFeetArmorItem(item: Internal.ItemStack_): void;
        getId(): number;
        pehkui_isFirstUpdate(): boolean;
        canBeHitByProjectile(): boolean;
        getRecipientsForComponentSync(): Internal.Iterable<any>;
        handler$zcl000$porting_lib_base$port_lib$onUsingTick(ci: Internal.CallbackInfo_): void;
        getEyeY(): number;
        handler$ham000$gobber2$gobberClimbing(cir: Internal.CallbackInfoReturnable_<any>): void;
        skipDropExperience(): void;
        fabric_readAttachmentsFromNbt(nbt: Internal.CompoundTag_): void;
        localvar$leb000$puzzleslib$getVisibilityPercent(value: number, lookingEntity: Internal.Entity_): number;
        getBoundingBox(): Internal.AABB;
        isInWaterOrRain(): boolean;
        getStandAnim($$0: number): number;
        handler$leb000$puzzleslib$die$1(damageSource: DamageSource_, callback: Internal.CallbackInfo_): void;
        setItemSlot($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_): void;
        equals($$0: any): boolean;
        getViewYRot($$0: number): number;
        fabric_setCustomTeleportTarget(teleportTarget: Internal.PortalInfo_): void;
        dismountsUnderwater(): boolean;
        isAffectedByPotions(): boolean;
        playerTouch($$0: Internal.Player_): void;
        addTag($$0: string): boolean;
        getEyeHeight($$0: Internal.Pose_): number;
        getAddEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>;
        callIsBeingRainedOn(): boolean;
        static getEquipmentForSlot($$0: Internal.EquipmentSlot_, $$1: number): Internal.Item;
        isWithinRestriction($$0: BlockPos_): boolean;
        getTeam(): Internal.Team;
        handler$mjp000$supplementaries$addSugarCube(ci: Internal.CallbackInfo_): void;
        static of(entity: Internal.LivingEntity_): Internal.EntityProperties;
        setTicksFrozen($$0: number): void;
        isArmor($$0: Internal.ItemStack_): boolean;
        getUseItem(): Internal.ItemStack;
        getMyRidingOffset(): number;
        handler$hal000$gobber2$gobberCanBreatheInWater(cir: Internal.CallbackInfoReturnable_<any>): void;
        dismountTo($$0: number, $$1: number, $$2: number): void;
        etf$getEntityKey(): string;
        etf$getPose(): Internal.Pose;
        hasCustomName(): boolean;
        getSwimAmount($$0: number): number;
        isLiving(): boolean;
        getX(): number;
        isVehicle(): boolean;
        static transfer(original: Internal.AttachmentTarget_, target: Internal.AttachmentTarget_, isDeath: boolean): void;
        bettertrims$didAvoidDamage(): boolean;
        resetDynamicLight(): void;
        setTemper($$0: number): void;
        handler$han000$gobber2$gobberSetTarget(target: Internal.LivingEntity_, ci: Internal.CallbackInfo_): void;
        handler$kpc001$porting_lib_entity$onJump(ci: Internal.CallbackInfo_): void;
        spawnAtLocation($$0: Internal.ItemStack_): Internal.ItemEntity;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        handler$zcl000$porting_lib_base$port_lib$canBeAffected(effect: Internal.MobEffectInstance_, cir: Internal.CallbackInfoReturnable_<any>): void;
        thunderHit($$0: Internal.ServerLevel_, $$1: Internal.LightningBolt_): void;
        setIsInPowderSnow($$0: boolean): void;
        etf$distanceTo(entity: Internal.Entity_): number;
        doEnchantDamageEffects($$0: Internal.LivingEntity_, $$1: Internal.Entity_): void;
        setCustomName($$0: net.minecraft.network.chat.Component_): void;
        lambdynlights$scheduleTrackedChunksRebuild(renderer: Internal.LevelRenderer_): void;
        handler$hak000$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        getTeamId(): string;
        setStingerCount($$0: number): void;
        getMaxHeadYRot(): number;
        isCustomNameVisible(): boolean;
        isSupportedBy($$0: BlockPos_): boolean;
        getPistonPushReaction(): Internal.PushReaction;
        lookAt($$0: Internal.EntityAnchorArgument$Anchor_, $$1: Vec3d_): void;
        handler$kpc000$porting_lib_entity$port_lib$cancelFall(fallDistance: number, multiplier: number, source: DamageSource_, cir: Internal.CallbackInfoReturnable_<any>): void;
        hurtCurrentlyUsedShield($$0: number): void;
        getLootTableSeed(): number;
        collide($$0: Vec3d_): Vec3d;
        getMotionX(): number;
        "onSyncedDataUpdated(java.util.List)"($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        canBeLeashed($$0: Internal.Player_): boolean;
        hasIndirectPassenger($$0: Internal.Entity_): boolean;
        gear_core_setActiveSets(sets: Internal.HashMap_<any, any>): void;
        getEntityData(): Internal.SynchedEntityData;
        bookshelf$getFallDamageSound(arg0: number): Internal.SoundEvent;
        handleInsidePortal($$0: BlockPos_): void;
        getPotionEffects(): Internal.EntityPotionEffectsJS;
        getLastHurtByPlayerTime(): number;
        absMoveTo($$0: number, $$1: number, $$2: number): void;
        handler$cfa000$betterend$be_canBeAffected(mobEffectInstance: Internal.MobEffectInstance_, info: Internal.CallbackInfoReturnable_<any>): void;
        isOnRails(): boolean;
        getAttachedOrThrow<A>(type: Internal.AttachmentType_<A>): A;
        handler$efj000$collective$AbstractHorse_travel(player: Internal.Player_, vec3: Vec3d_, ci: Internal.CallbackInfo_): void;
        getStingerCount(): number;
        markFusionRecomputeModels(): void;
        getFallSounds(): Internal.LivingEntity$Fallsounds;
        getAttributeTotalValue(attribute: Internal.Attribute_): number;
        getDimensionChangingDelay(): number;
        handler$cbi000$besmirchment$getScoreboardTeam(cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDynamicLuminance(): number;
        setYaw($$0: number): void;
        getPickRadius(): number;
        isPathFinding(): boolean;
        supp$getSlimedTicks(): number;
        isRemoved(): boolean;
        handleStopJump(): void;
        getEatAnim($$0: number): number;
        emf$isSneaking(): boolean;
        teleportToWithTicket($$0: number, $$1: number, $$2: number): void;
        spawnAnim(): void;
        getJumpBoostPower(): number;
        fillCrashReportCategory($$0: Internal.CrashReportCategory_): void;
        self(): Internal.Entity;
        refreshDimensions(): void;
        pehkui_writeScaleNbt(nbt: Internal.CompoundTag_): Internal.CompoundTag;
        bookshelf$getAmbientSound(): Internal.SoundEvent;
        "getAttributeValue(net.minecraft.world.entity.ai.attributes.Attribute)"($$0: Internal.Attribute_): number;
        "spawnAtLocation(net.minecraft.world.level.ItemLike)"($$0: Internal.ItemLike_): Internal.ItemEntity;
        "isHolding(net.minecraft.world.item.Item)"($$0: Internal.Item_): boolean;
        setShiftKeyDown($$0: boolean): void;
        getEyePosition($$0: number): Vec3d;
        getPassengers(): Internal.EntityArrayList;
        standIfPossible(): void;
        handler$ldh000$puzzleslib$spawnAtLocation(stack: Internal.ItemStack_, offsetY: number, callback: Internal.CallbackInfoReturnable_<any>, itemEntity: Internal.ItemEntity_): void;
        getZ(): number;
        bettertrims$applyCelestialToAttackCooldown(original: number): number;
        teleportTo($$0: number, $$1: number, $$2: number): void;
        handler$zbk000$porting_lib_base$port_lib$spawnSprintParticle(ci: Internal.CallbackInfo_, pos: BlockPos_, state: Internal.BlockState_): void;
        getAttributeBaseValue($$0: Internal.Holder_<Internal.Attribute>): number;
        getServer(): Internal.MinecraftServer;
        getExperienceReward(): number;
        getFirstPassenger(): Internal.Entity;
        heal($$0: number): void;
        handler$leb01a$puzzleslib$tick(callback: Internal.CallbackInfo_): void;
        setLastHurtMob($$0: Internal.Entity_): void;
        setLastHurtByMob($$0: Internal.LivingEntity_): void;
        interact($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        getDismountLocationForPassenger($$0: Internal.LivingEntity_): Vec3d;
        checkSlowFallDistance(): void;
        getLeashingEntities(): Internal.Set<any>;
        level(): Internal.EntityGetter;
        canStandOnFluid($$0: Internal.FluidState_): boolean;
        setFabricBalmData(tag: Internal.CompoundTag_): void;
        touchingUnloadedChunk(): boolean;
        modifyAttribute(attribute: Internal.Attribute_, identifier: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getLookAngle(): Vec3d;
        modifyReturnValue$zhf000$additionalentityattributes$additionalEntityAttributes$modifyJumpVelocity(original: number): number;
        getAmbientSoundInterval(): number;
        emf$isOnFire(): boolean;
        setArrowCount($$0: number): void;
        getMotionZ(): number;
        isPersistenceRequired(): boolean;
        isInvisible(): boolean;
        is($$0: Internal.Entity_): boolean;
        isTamed(): boolean;
        getBedOrientation(): Internal.Direction;
        ejectPassengers(): void;
        removeEffect($$0: Internal.MobEffect_): boolean;
        updateDynamicLightPreviousCoordinates(): void;
        getProfile(): Internal.GameProfile;
        setInLove($$0: Internal.Player_): void;
        isDeadOrDying(): boolean;
        setHeadArmorItem(item: Internal.ItemStack_): void;
        static setViewScale($$0: number): void;
        emf$isAlive(): boolean;
        take($$0: Internal.Entity_, $$1: number): void;
        setLevelCallback($$0: Internal.EntityInLevelCallback_): void;
        getLookControl(): Internal.LookControl;
        handler$gdo000$faster_entity_animations$getEatingGrassAnimationProgress(f: number, info: Internal.CallbackInfoReturnable_<any>): void;
        isBred(): boolean;
        redirect$joh000$origins$method_26317Proxy(entity: Internal.LivingEntity_, d: number, bl: boolean, vec3d: Vec3d_): Vec3d;
        playSound($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        canAttack($$0: Internal.LivingEntity_): boolean;
        static getSpeedUpSecondsWhenFeeding($$0: number): number;
        getOffHandItem(): Internal.ItemStack;
        startSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isOnScoreboardTeam(teamId: string): boolean;
        startUsingItem($$0: Internal.InteractionHand_): void;
        invokePlayEquipmentBreakEffects(arg0: Internal.ItemStack_): void;
        localvar$bbb000$architectury$modifyLevelCallback_setLevelCallback(callback: Internal.EntityInLevelCallback_): Internal.EntityInLevelCallback;
        position(): Vec3d;
        setTimeout(): void;
        static getEquipmentSlotForItem($$0: Internal.ItemStack_): Internal.EquipmentSlot;
        getEquipment(slot: Internal.EquipmentSlot_): Internal.ItemStack;
        displayFireAnimation(): boolean;
        isOutOfCamera(): boolean;
        getRopeHoldPosition($$0: number): Vec3d;
        copyPosition($$0: Internal.Entity_): void;
        "hasPassenger(net.minecraft.world.entity.Entity)"($$0: Internal.Entity_): boolean;
        extraalchemy_spawnParticles(arg0: Internal.ItemStack_, arg1: number): void;
        etf$canBeBright(): boolean;
        isCrouching(): boolean;
        "getAttributeBaseValue(net.minecraft.world.entity.ai.attributes.Attribute)"(attribute: Internal.Attribute_): number;
        onLeaveCombat(): void;
        wrapOperation$bgd000$artifacts$travel(block: Internal.Block_, original: Internal.Operation_<any>): number;
        setY(y: number): void;
        getAttributeValue($$0: Internal.Attribute_): number;
        getFeetBlockState(): Internal.BlockState;
        archon$isOwner(player: Internal.Player_): boolean;
        isWithinRestriction(): boolean;
        getChangeListener(): Internal.EntityInLevelCallback;
        positionRider($$0: Internal.Entity_): void;
        baseTick(): void;
        broadcastToPlayer($$0: Internal.ServerPlayer_): boolean;
        setSharedFlag($$0: number, $$1: boolean): void;
        getSleepingPos(): Optional<BlockPos>;
        damageHeldItem(): void;
        getCustomName(): net.minecraft.network.chat.Component;
        getClass(): typeof any;
        isVisuallySwimming(): boolean;
        getMaxAirSupply(): number;
        handler$zcl000$porting_lib_base$port_lib$addEffect(newEffect: Internal.MobEffectInstance_, source: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>, oldEffect: Internal.MobEffectInstance_): void;
        setItemInHand($$0: Internal.InteractionHand_, $$1: Internal.ItemStack_): void;
        dynamicLightTick(): void;
        setMaxHealth(hp: number): void;
        getFacing(): Internal.Direction;
        emf$isWet(): boolean;
        getJumpCooldown(): number;
        isPassengerOfSameVehicle($$0: Internal.Entity_): boolean;
        getBoundingBoxForCulling(): Internal.AABB;
        setAge($$0: number): void;
        getTarget(): Internal.LivingEntity;
        static collideBoundingBox(entity: Internal.Entity_, movement: Vec3d_, entityBoundingBox: Internal.AABB_, world: Internal.Level_, collisions: Internal.List_<any>): Vec3d;
        fzzy_core_getModifierContainer(): Internal.ModifierContainer;
        restrictTo($$0: BlockPos_, $$1: number): void;
        isInLove(): boolean;
        trackingPosition(): Vec3d;
        getNameTagOffsetY(): number;
        isInvulnerable(): boolean;
        isInLava(): boolean;
        isInWater(): boolean;
        awardKillScore($$0: Internal.Entity_, $$1: number, $$2: DamageSource_): void;
        finalizeSpawn($$0: Internal.ServerLevelAccessor_, $$1: Internal.DifficultyInstance_, $$2: Internal.MobSpawnType_, $$3: Internal.SpawnGroupData_, $$4: Internal.CompoundTag_): Internal.SpawnGroupData;
        localvar$leb000$puzzleslib$knockback$3(ratioZ: number): number;
        handleStartJump($$0: number): void;
        unsetRemoved(): void;
        pehkui_getScaleCache(): Internal.ScaleData[];
        swing($$0: Internal.InteractionHand_): void;
        hasEffect($$0: Internal.MobEffect_): boolean;
        getHeldItem(hand: Internal.InteractionHand_): Internal.ItemStack;
        setFusionModel(layerIndex: number, model: Internal.Triple_<any, any, any>): void;
        getRootVehicle(): Internal.Entity;
        getOwnerUUID(): Internal.UUID;
        onPathfindingDone(): void;
        save($$0: Internal.CompoundTag_): boolean;
        archon$setLifetime(seconds: number): void;
        modify$zhf000$additionalentityattributes$additionalEntityAttributes$waterSpeed(original: number): number;
        getLocalBoundsForPose($$0: Internal.Pose_): Internal.AABB;
        isNoGravity(): boolean;
        dodge(chance: number): boolean;
        onItemPickup($$0: Internal.ItemEntity_): void;
        getMouthAnim($$0: number): number;
        hex$setLastDamageSource(arg0: DamageSource_): void;
        emf$getY(): number;
        handler$kom000$porting_lib_entity$port_lib$entityInit(entityType: Internal.EntityType_<any>, world: Internal.Level_, ci: Internal.CallbackInfo_): void;
        resetLove(): void;
        bookshelf$createHoverEvent(): Internal.HoverEvent;
        updateSwimming(): void;
        isHolding($$0: Internal.Predicate_<Internal.ItemStack>): boolean;
        getSpeed(): number;
        abstract getCachedFeetBlockState(): Internal.BlockState;
        shouldInformAdmins(): boolean;
        rideTick(): void;
        port_lib$onEffectRemoved(arg0: Internal.MobEffectInstance_): void;
        handler$zll000$amethyst_imbuement$onAttackWhilstStunnedNoTarget(hand: Internal.InteractionHand_, ci: Internal.CallbackInfo_): void;
        wait(): void;
        getUuid(): Internal.UUID;
        setOffHandItem(item: Internal.ItemStack_): void;
        spawn(): void;
        setNoAi($$0: boolean): void;
        teleportTo($$0: Internal.ServerLevel_, $$1: number, $$2: number, $$3: number, $$4: Internal.Set_<Internal.RelativeMovement>, $$5: number, $$6: number): boolean;
        etf$getCustomName(): net.minecraft.network.chat.Component;
        fabric_writeAttachmentsToNbt(nbt: Internal.CompoundTag_): void;
        shouldShowName(): boolean;
        getArmorSlots(): Internal.Iterable<Internal.ItemStack>;
        canPickUpLoot(): boolean;
        kill(): void;
        onEnterCombat(): void;
        updateNavigationRegistration(): void;
        animateHurt($$0: number): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        handler$kom000$porting_lib_entity$port_lib$onEntityRemove(reason: Internal.Entity$RemovalReason_, ci: Internal.CallbackInfo_): void;
        static resetForwardDirectionOfRelativePortalPosition($$0: Vec3d_): Vec3d;
        callGetEyeHeight(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        hasRestriction(): boolean;
        getHeadArmorItem(): Internal.ItemStack;
        botania_createInventory(): void;
        deserializeNBT(arg0: Internal.Tag_): void;
        setEating($$0: boolean): void;
        getCurrentModifyFoodPowers(): Internal.List<any>;
        getBbWidth(): number;
        splitIntoDynamicLightEntries(): Internal.Stream<Internal.SpatialLookupEntry>;
        addDeltaMovement($$0: Vec3d_): void;
        pehkui_setOnGround(onGround: boolean): void;
        localvar$leb000$puzzleslib$knockback$1(strength: number): number;
        setTamed($$0: boolean): void;
        bettertrims$addLateAttributes(adder: Internal.Consumer_<any>): void;
        handler$lef000$puzzleslib$readAdditionalSaveData(compound: Internal.CompoundTag_, callback: Internal.CallbackInfo_): void;
        sendLeashState(): void;
        "getName()"(): net.minecraft.network.chat.Component;
        mirror($$0: Internal.Mirror_): number;
        static port_lib$collideWithShapes(vec3: Vec3d_, aABB: Internal.AABB_, list: Internal.List_<Internal.VoxelShape>): Vec3d;
        knockback($$0: number, $$1: number, $$2: number): void;
        getTicksRequiredToFreeze(): number;
        getVisibilityPercent($$0: Internal.Entity_): number;
        getMaxSpawnClusterSize(): number;
        localvar$kpc000$porting_lib_entity$port_lib$modifyDistance(fallDistance: number): number;
        artifacts$getPocketPistonLength(): number;
        canJump(): boolean;
        emf$prevZ(): number;
        getUsername(): string;
        getInLoveTime(): number;
        move($$0: Internal.MoverType_, $$1: Vec3d_): void;
        lithiumOnBlockCacheSet(newState: Internal.BlockState_): void;
        isPickable(): boolean;
        setYHeadRot($$0: number): void;
        setJumping($$0: boolean): void;
        getCustomData(): Internal.CompoundTag;
        handler$zno000$apoli$getGroup(info: Internal.CallbackInfoReturnable_<any>): void;
        getPickResult(): Internal.ItemStack;
        "getMainHandItem()"(): Internal.ItemStack;
        getAbsorptionAmount(): number;
        getRandomY(): number;
        onEffectRemoved($$0: Internal.MobEffectInstance_): void;
        getDisplayName(): net.minecraft.network.chat.Component;
        static "tickEntity(net.minecraft.world.entity.Entity)"(entity: Internal.Entity_): void;
        getMobType(): Internal.MobType;
        travel($$0: Vec3d_): void;
        getItemInHand($$0: Internal.InteractionHand_): Internal.ItemStack;
        localvar$leb000$puzzleslib$hurt$0(amount: number, source: DamageSource_): number;
        getDynamicLightPrevX(): number;
        shouldBeSaved(): boolean;
        fabric_hasPersistentAttachments(): boolean;
        method_5749($$0: Internal.CompoundTag_): void;
        hurtHelmet($$0: DamageSource_, $$1: number): void;
        removeTag($$0: string): boolean;
        isHoldingInAnyHand(i: Internal.Ingredient_): boolean;
        getFluidHeight($$0: Internal.TagKey_<Internal.Fluid>): number;
        canSpawnSoulSpeedParticle(): boolean;
        notifyAll(): void;
        hasInventoryChanged($$0: net.minecraft.world.Container_): boolean;
        aiStep(): void;
        handler$leb000$puzzleslib$removeEffect(effect: Internal.MobEffect_, callback: Internal.CallbackInfoReturnable_<any>): void;
        getPassengersRidingOffset(): number;
        setAttributeBaseValue(attribute: Internal.Attribute_, value: number): void;
        distanceToEntitySqr($$0: Internal.Entity_): number;
        isFrame(): boolean;
        broadcastBreakEvent($$0: Internal.InteractionHand_): void;
        setLegsArmorItem(item: Internal.ItemStack_): void;
        localvar$leb000$puzzleslib$causeFallDamage$1(fallDistance: number): number;
        discard(): void;
        "handler$mhe000$step-height-entity-attribute$getStepHeight"(cir: Internal.CallbackInfoReturnable_<any>): void;
        sendSystemMessage($$0: net.minecraft.network.chat.Component_): void;
        acceptsSuccess(): boolean;
        static tickEntity(entity: Internal.LivingEntity_): void;
        setNoGravity($$0: boolean): void;
        getUseItemRemainingTicks(): number;
        gear_core_getActiveSets(): Internal.HashMap<any, any>;
        getIndirectPassengers(): Internal.Iterable<any>;
        attackable(): boolean;
        createCommandSourceStack(): Internal.CommandSourceStack;
        getNavigation(): Internal.PathNavigation;
        isControlledByLocalInstance(): boolean;
        isMonster(): boolean;
        pehkui_setShouldSyncScales(sync: boolean): void;
        handler$cbm000$besmirchment$canTarget(type: Internal.EntityType_<any>, cir: Internal.CallbackInfoReturnable_<any>): void;
        getLoveCause(): Internal.ServerPlayer;
        getLastClimbablePos(): Optional<BlockPos>;
        getEatingSound($$0: Internal.ItemStack_): Internal.SoundEvent;
        setLastDynamicLuminance(luminance: number): void;
        getPerceivedTargetDistanceSquareForMeleeAttack($$0: Internal.LivingEntity_): number;
        setId($$0: number): void;
        onSyncedDataUpdated($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        getHorizontalFacing(): Internal.Direction;
        getType(): string;
        static checkAnimalSpawnRules($$0: Internal.EntityType_<Internal.Animal>, $$1: Internal.LevelAccessor_, $$2: Internal.MobSpawnType_, $$3: BlockPos_, $$4: Internal.RandomSource_): boolean;
        isDamageSourceBlocked($$0: DamageSource_): boolean;
        getLightProbePosition($$0: number): Vec3d;
        getActiveEffectsMap(): Internal.Map<Internal.MobEffect, Internal.MobEffectInstance>;
        wrapOperation$mac000$smarterfarmers$smarterFarmers$overrideMobGriefing(instance: Internal.GameRules_, key: Internal.GameRules$Key_<any>, original: Internal.Operation_<any>): boolean;
        emf$prevX(): number;
        onEquipItem($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_, $$2: Internal.ItemStack_): void;
        checkDespawn(): void;
        pehkui_shouldSyncScales(): boolean;
        getWalkTargetValue($$0: BlockPos_, $$1: Internal.LevelReader_): number;
        lookAt($$0: Internal.Entity_, $$1: number, $$2: number): void;
        setHeldItem(hand: Internal.InteractionHand_, item: Internal.ItemStack_): void;
        port_lib$maybeDisableShield(arg0: Internal.Player_, arg1: Internal.ItemStack_, arg2: Internal.ItemStack_): void;
        equipItemIfPossible($$0: Internal.ItemStack_): Internal.ItemStack;
        onSyncedDataUpdated($$0: Internal.EntityDataAccessor_<any>): void;
        lerpHeadTo($$0: number, $$1: number): void;
        canDisableShield(): boolean;
        setMotionX(x: number): void;
        getHandSlots(): Internal.Iterable<Internal.ItemStack>;
        distanceToEntity($$0: Internal.Entity_): number;
        bookshelf$getDeathSound(): Internal.SoundEvent;
        wait(arg0: number, arg1: number): void;
        getTeamColor(): number;
        lithiumSetClimbingMobCachingSectionUpdateBehavior(listenForCachedBlockChanges: boolean): void;
        setNbt(nbt: Internal.CompoundTag_): void;
        lambdynlights$getTrackedLitChunkPos(): Internal.LongSet;
        checkSpawnObstruction($$0: Internal.LevelReader_): boolean;
        getRecallPosition(): Internal.DimensionalPosition;
        extinguish(): void;
        setDynamicLightEnabled(enabled: boolean): void;
        equipArmor($$0: Internal.Player_, $$1: Internal.ItemStack_): void;
        getRestrictRadius(): number;
        moveTo($$0: Vec3d_): void;
        isColliding($$0: BlockPos_, $$1: Internal.BlockState_): boolean;
        "swing(net.minecraft.world.InteractionHand)"($$0: Internal.InteractionHand_): void;
        lambdynlights$updateDynamicLight(renderer: Internal.LevelRenderer_): boolean;
        getRegisteredNavigation(): Internal.PathNavigation;
        bettertrims$isWearing(effect: Internal.TrimEffect_): boolean;
        static port_lib$collideWithShapes$porting_lib_accessors_$md$424943$0(arg0: Vec3d_, arg1: Internal.AABB_, arg2: Internal.List_<any>): Vec3d;
        isForcedVisible(): boolean;
        modifyTemper($$0: number): number;
        isInvertedHealAndHarm(): boolean;
        handler$jon000$origins$doWaterBreathing(info: Internal.CallbackInfoReturnable_<any>): void;
        canHoldItem($$0: Internal.ItemStack_): boolean;
        killedEntity($$0: Internal.ServerLevel_, $$1: Internal.LivingEntity_): boolean;
        getAttachedOrElse<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        isFreezing(): boolean;
        containerChanged($$0: net.minecraft.world.Container_): void;
        runCommand(command: string): number;
        isStanding(): boolean;
        hex$getDeathSound(): Internal.SoundEvent;
        setGuaranteedDrop($$0: Internal.EquipmentSlot_): void;
        setSharedFlagOnFire($$0: boolean): void;
        set defaultMovementSpeedMultiplier(speed: number)
        get suppressingBounce(): boolean
        set target($$0: Internal.LivingEntity_)
        set culled(value: boolean)
        get onFire(): boolean
        get owner(): Internal.LivingEntity
        get positionCodec(): Internal.VecDeltaCodec
        set maxUpStep($$0: number)
        get fallFlyingTicks(): number
        set xxa($$0: number)
        set delayedLeashHolderId($$0: number)
        get shiftKeyDown(): boolean
        set UUID($$0: Internal.UUID_)
        set motionZ(z: number)
        get blockY(): number
        get isInsideStructureTracker(): Internal.IsInsideStructureTracker
        set playerHitTimer(arg0: number)
        get spectator(): boolean
        set mainHandItem(item: Internal.ItemStack_)
        get persistentData(): Internal.CompoundTag
        get health(): number
        get maxHealth(): number
        get registeredToWorld(): boolean
        set aggressive($$0: boolean)
        set removed($$0: Internal.Entity$RemovalReason_)
        get inWaterRainOrBubble(): boolean
        get removalReason(): Internal.Entity$RemovalReason
        get eating(): boolean
        set boundingBox($$0: Internal.AABB_)
        get ambientCreature(): boolean
        set zza($$0: number)
        get block(): Internal.BlockContainerJS
        get name(): net.minecraft.network.chat.Component
        get controlledVehicle(): Internal.Entity
        get armorValue(): number
        get killCredit(): Internal.LivingEntity
        get componentContainer(): Internal.ComponentContainer
        get dynamicLightPrevZ(): number
        set outOfCamera(value: boolean)
        get autoSpinAttack(): boolean
        get remainingFireTicks(): number
        get maxFallDistance(): number
        get ticksFrozen(): number
        get dynamicLightZ(): number
        get voicePitch(): number
        set statusMessage(message: net.minecraft.network.chat.Component_)
        set sleepingPos($$0: BlockPos_)
        get descending(): boolean
        get headRotSpeed(): number
        get lastHurtByPlayer(): Internal.Player
        get YHeadRot(): number
        set absorptionAmount($$0: number)
        set recallData(pos: Internal.DimensionalPosition_)
        set deltaMovement($$0: Vec3d_)
        get baby(): boolean
        get culled(): boolean
        get glowing(): boolean
        get leashedByEntities(): Internal.Set<any>
        get leashOffset(): Vec3d
        get attackable(): boolean
        get saddleSoundEvent(): Internal.SoundEvent
        get underWater(): boolean
        get leashHolder(): Internal.Entity
        get sensing(): Internal.Sensing
        get legsArmorItem(): Internal.ItemStack
        get luminance(): number
        get selfAndPassengers(): Internal.Stream<any>
        get deltaMovement(): Vec3d
        get dynamicLightX(): number
        set secondsOnFire($$0: number)
        get "displayName()"(): net.minecraft.network.chat.Component
        get lootTable(): ResourceLocation
        get ticksUsingItem(): number
        get arrowCount(): number
        get moveControl(): Internal.MoveControl
        set standing($$0: boolean)
        get defaultMovementSpeed(): number
        get peacefulCreature(): boolean
        set onGround($$0: boolean)
        get lastHurtByMobTimestamp(): number
        get vehicle(): Internal.Entity
        get effectiveAi(): boolean
        get stringUuid(): string
        set swimming($$0: boolean)
        get mainArm(): Internal.HumanoidArm
        get rotationVector(): Internal.Vec2
        get hurtDir(): number
        get sprinting(): boolean
        get motionY(): number
        get offhandItem(): Internal.ItemStack
        set luminance(luminance: number)
        set lootTable(arg0: ResourceLocation_)
        get lastHurtMob(): Internal.LivingEntity
        get lastDamageSource(): DamageSource
        get soundSource(): Internal.SoundSource
        get jumping(): boolean
        set noActionTime($$0: number)
        set movementSpeedAddition(speed: number)
        get pose(): Internal.Pose
        get restrictCenter(): BlockPos
        get leftHanded(): boolean
        set z(z: number)
        get y(): number
        set isJumping($$0: boolean)
        set currentModifyFoodPowers(powers: Internal.List_<any>)
        get blocking(): boolean
        get pushedByFluid(): boolean
        set originalFoodStack(original: Internal.ItemStack_)
        get armorCoverPercentage(): number
        get airSupply(): number
        get player(): boolean
        get animal(): boolean
        get motionDirection(): Internal.Direction
        get fabricBalmData(): Internal.CompoundTag
        get commandSenderWorld(): Internal.Level
        get totalMovementSpeed(): number
        get moving(): boolean
        get attributes(): Internal.AttributeMap
        set inLoveTime($$0: number)
        get swimming(): boolean
        set sprinting($$0: boolean)
        get dynamicLightLevel(): Internal.Level
        set x(x: number)
        get portalWaitTime(): number
        get blockStateOn(): Internal.BlockState
        set ownerUUID($$0: Internal.UUID_)
        get fluidJumpThreshold(): number
        get cachedSouls(): number
        set airSupply($$0: number)
        get onPos(): BlockPos
        get undead(): boolean
        set useItemRemaining(arg0: number)
        get targetSelector(): Internal.GoalSelector
        set registeredToWorld(navigation: Internal.PathNavigation_)
        get sleeping(): boolean
        get dismountPoses(): Internal.ImmutableList<Internal.Pose>
        get lastHurtMobTimestamp(): number
        set remainingFireTicks($$0: number)
        /**
         * @deprecated
        */
        get onPosLegacy(): BlockPos
        set pos($$0: Vec3d_)
        set canPickUpLoot($$0: boolean)
        get mainHandItem(): Internal.ItemStack
        set silent($$0: boolean)
        set leftHanded($$0: boolean)
        get activeEffects(): Internal.Collection<Internal.MobEffectInstance>
        get onPortalCooldown(): boolean
        set pitch($$0: number)
        get usingItem(): boolean
        get alwaysTicking(): boolean
        set invulnerable($$0: boolean)
        get dynamicLightPrevY(): number
        set glowing($$0: boolean)
        get alive(): boolean
        get bbHeight(): number
        get tags(): Internal.Set<string>
        get lastAttacker(): Internal.LivingEntity
        get lastRollTicks(): number
        get goalSelector(): Internal.GoalSelector
        get percentFrozen(): number
        set portalCooldown($$0: number)
        set position(block: Internal.BlockContainerJS_)
        get leashed(): boolean
        set pose($$0: Internal.Pose_)
        get reachDistance(): number
        get entityType(): Internal.EntityType<any>
        get waterCreature(): boolean
        set lastHurtByPlayer($$0: Internal.Player_)
        get "server()"(): Internal.MinecraftServer
        get ambientStandSound(): Internal.SoundEvent
        get pushable(): boolean
        set YBodyRot($$0: number)
        set motionY(y: number)
        get dynamicLightEnabled(): boolean
        set bred($$0: boolean)
        set chestArmorItem(item: Internal.ItemStack_)
        get passenger(): boolean
        get sensitiveToWater(): boolean
        get jumpControl(): Internal.JumpControl
        get feetArmorItem(): Internal.ItemStack
        get saddleable(): boolean
        get viewScale(): number
        get visualRotationYInDegrees(): number
        set speed($$0: number)
        get discrete(): boolean
        get level(): Internal.Level
        get combatTracker(): Internal.CombatTracker
        get customJump(): number
        get noAi(): boolean
        get chestArmorItem(): Internal.ItemStack
        get fullyFrozen(): boolean
        get inWall(): boolean
        get allSlots(): Internal.Iterable<Internal.ItemStack>
        get inventory(): Internal.SimpleContainer
        get scale(): number
        get suppressingSlidingDownLadder(): boolean
        get blockZ(): number
        get silent(): boolean
        set useItem(arg0: Internal.ItemStack_)
        get pitch(): number
        get random(): Internal.RandomSource
        get passengersAndSelf(): Internal.Stream<any>
        get maxTemper(): number
        get originalFoodStack(): Internal.ItemStack
        get age(): number
        get noActionTime(): number
        get visuallyCrawling(): boolean
        get aggressive(): boolean
        get wearingArmor(): boolean
        set yya($$0: number)
        set baby($$0: boolean)
        get temper(): number
        get lastHurtByMob(): Internal.LivingEntity
        get inWaterOrBubble(): boolean
        get portalCooldown(): number
        get item(): Internal.ItemStack
        get ignoringBlockTriggers(): boolean
        get steppingCarefully(): boolean
        get blockX(): number
        /**
         * @deprecated
        */
        get lightLevelDependentMagicValue(): number
        get fallFlying(): boolean
        get encodeId(): string
        get maxHeadXRot(): number
        get nbt(): Internal.CompoundTag
        set invisible($$0: boolean)
        get saddled(): boolean
        set totalMovementSpeedMultiplier(speed: number)
        get dynamicLightY(): number
        set health($$0: number)
        get ambientStandInterval(): number
        get eyePosition(): Vec3d
        get eyeHeight(): number
        set discardFriction($$0: boolean)
        get yaw(): number
        get usedItemHand(): Internal.InteractionHand
        set defaultMovementSpeed(speed: number)
        get brain(): Internal.Brain<any>
        set customNameVisible($$0: boolean)
        get controllingPassenger(): Internal.LivingEntity
        get scriptType(): Internal.ScriptType
        get forward(): Vec3d
        set feetArmorItem(item: Internal.ItemStack_)
        get id(): number
        get recipientsForComponentSync(): Internal.Iterable<any>
        get eyeY(): number
        get boundingBox(): Internal.AABB
        get inWaterOrRain(): boolean
        get affectedByPotions(): boolean
        get addEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>
        get team(): Internal.Team
        set ticksFrozen($$0: number)
        get useItem(): Internal.ItemStack
        get myRidingOffset(): number
        get living(): boolean
        get x(): number
        get vehicle(): boolean
        set temper($$0: number)
        set isInPowderSnow($$0: boolean)
        set customName($$0: net.minecraft.network.chat.Component_)
        get teamId(): string
        set stingerCount($$0: number)
        get maxHeadYRot(): number
        get customNameVisible(): boolean
        get pistonPushReaction(): Internal.PushReaction
        get lootTableSeed(): number
        get motionX(): number
        get entityData(): Internal.SynchedEntityData
        get potionEffects(): Internal.EntityPotionEffectsJS
        get lastHurtByPlayerTime(): number
        get onRails(): boolean
        get stingerCount(): number
        get fallSounds(): Internal.LivingEntity$Fallsounds
        get dimensionChangingDelay(): number
        get lastDynamicLuminance(): number
        set yaw($$0: number)
        get pickRadius(): number
        get pathFinding(): boolean
        get removed(): boolean
        get jumpBoostPower(): number
        set shiftKeyDown($$0: boolean)
        get passengers(): Internal.EntityArrayList
        get z(): number
        get server(): Internal.MinecraftServer
        get experienceReward(): number
        get firstPassenger(): Internal.Entity
        set lastHurtMob($$0: Internal.Entity_)
        set lastHurtByMob($$0: Internal.LivingEntity_)
        get leashingEntities(): Internal.Set<any>
        set fabricBalmData(tag: Internal.CompoundTag_)
        get lookAngle(): Vec3d
        get ambientSoundInterval(): number
        set arrowCount($$0: number)
        get motionZ(): number
        get persistenceRequired(): boolean
        get invisible(): boolean
        get tamed(): boolean
        get bedOrientation(): Internal.Direction
        get profile(): Internal.GameProfile
        set inLove($$0: Internal.Player_)
        get deadOrDying(): boolean
        set headArmorItem(item: Internal.ItemStack_)
        set viewScale($$0: number)
        set levelCallback($$0: Internal.EntityInLevelCallback_)
        get lookControl(): Internal.LookControl
        get bred(): boolean
        get offHandItem(): Internal.ItemStack
        get outOfCamera(): boolean
        get crouching(): boolean
        set y(y: number)
        get feetBlockState(): Internal.BlockState
        get withinRestriction(): boolean
        get changeListener(): Internal.EntityInLevelCallback
        get sleepingPos(): Optional<BlockPos>
        get customName(): net.minecraft.network.chat.Component
        get class(): typeof any
        get visuallySwimming(): boolean
        get maxAirSupply(): number
        set maxHealth(hp: number)
        get facing(): Internal.Direction
        get jumpCooldown(): number
        get boundingBoxForCulling(): Internal.AABB
        set age($$0: number)
        get target(): Internal.LivingEntity
        get inLove(): boolean
        get nameTagOffsetY(): number
        get invulnerable(): boolean
        get inLava(): boolean
        get inWater(): boolean
        get rootVehicle(): Internal.Entity
        get ownerUUID(): Internal.UUID
        get noGravity(): boolean
        get speed(): number
        get cachedFeetBlockState(): Internal.BlockState
        get uuid(): Internal.UUID
        set offHandItem(item: Internal.ItemStack_)
        set noAi($$0: boolean)
        get armorSlots(): Internal.Iterable<Internal.ItemStack>
        get headArmorItem(): Internal.ItemStack
        set eating($$0: boolean)
        get currentModifyFoodPowers(): Internal.List<any>
        get bbWidth(): number
        set tamed($$0: boolean)
        get "name()"(): net.minecraft.network.chat.Component
        get ticksRequiredToFreeze(): number
        get maxSpawnClusterSize(): number
        get username(): string
        get inLoveTime(): number
        get pickable(): boolean
        set YHeadRot($$0: number)
        set jumping($$0: boolean)
        get customData(): Internal.CompoundTag
        get pickResult(): Internal.ItemStack
        get "mainHandItem()"(): Internal.ItemStack
        get absorptionAmount(): number
        get randomY(): number
        get displayName(): net.minecraft.network.chat.Component
        get mobType(): Internal.MobType
        get dynamicLightPrevX(): number
        get passengersRidingOffset(): number
        get frame(): boolean
        set legsArmorItem(item: Internal.ItemStack_)
        set noGravity($$0: boolean)
        get useItemRemainingTicks(): number
        get indirectPassengers(): Internal.Iterable<any>
        get navigation(): Internal.PathNavigation
        get controlledByLocalInstance(): boolean
        get monster(): boolean
        get loveCause(): Internal.ServerPlayer
        get lastClimbablePos(): Optional<BlockPos>
        set lastDynamicLuminance(luminance: number)
        set id($$0: number)
        get horizontalFacing(): Internal.Direction
        get type(): string
        get activeEffectsMap(): Internal.Map<Internal.MobEffect, Internal.MobEffectInstance>
        set motionX(x: number)
        get handSlots(): Internal.Iterable<Internal.ItemStack>
        get teamColor(): number
        set nbt(nbt: Internal.CompoundTag_)
        get recallPosition(): Internal.DimensionalPosition
        set dynamicLightEnabled(enabled: boolean)
        get restrictRadius(): number
        get registeredNavigation(): Internal.PathNavigation
        get forcedVisible(): boolean
        get invertedHealAndHarm(): boolean
        get freezing(): boolean
        get standing(): boolean
        set guaranteedDrop($$0: Internal.EquipmentSlot_)
        set sharedFlagOnFire($$0: boolean)
        static readonly MAX_JUMP_STRENGTH: (1.0) & (number);
        static readonly BREEDING_CROSS_FACTOR: (0.15) & (number);
        playerJumpPendingScale: number;
        static readonly CHEST_SLOT_OFFSET: (499) & (number);
        static readonly MAX_MOVEMENT_SPEED: (0.3375) & (number);
        static readonly INV_SLOT_ARMOR: (1) & (number);
        sprintCounter: number;
        static FOOD_ITEMS: (Internal.Ingredient) & (Internal.Ingredient);
        static readonly INVENTORY_SLOT_OFFSET: (500) & (number);
        tailCounter: number;
        static readonly INV_BASE_COUNT: (2) & (number);
        static readonly INV_SLOT_SADDLE: (0) & (number);
        static readonly EQUIPMENT_SLOT_OFFSET: (400) & (number);
    }
    type AbstractHorse_ = AbstractHorse;
    abstract class ChunkRenderDispatcher$RenderChunk$ChunkCompileTask implements Internal.Comparable<Internal.ChunkRenderDispatcher$RenderChunk$ChunkCompileTask> {
        constructor(arg0: Internal.ChunkRenderDispatcher$RenderChunk_, arg1: number, arg2: boolean)
        getClass(): typeof any;
        toString(): string;
        "compareTo(net.minecraft.client.renderer.chunk.ChunkRenderDispatcher$RenderChunk$ChunkCompileTask)"($$0: Internal.ChunkRenderDispatcher$RenderChunk$ChunkCompileTask_): number;
        notifyAll(): void;
        abstract cancel(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        hashCode(): number;
        wait(): void;
        compareTo($$0: Internal.ChunkRenderDispatcher$RenderChunk$ChunkCompileTask_): number;
        wait(arg0: number): void;
        "compareTo(java.lang.Object)"(arg0: any): number;
        abstract doTask(arg0: Internal.ChunkBufferBuilderPack_): Internal.CompletableFuture<Internal.ChunkRenderDispatcher$ChunkTaskResult>;
        equals(arg0: any): boolean;
        get class(): typeof any
    }
    type ChunkRenderDispatcher$RenderChunk$ChunkCompileTask_ = ChunkRenderDispatcher$RenderChunk$ChunkCompileTask;
    interface ChunkTracker$ChunkEventHandler {
        abstract apply(arg0: number, arg1: number): void;
        (arg0: number, arg1: number): void;
    }
    type ChunkTracker$ChunkEventHandler_ = ((arg0: number, arg1: number)=> void) | ChunkTracker$ChunkEventHandler;
    class RealmsDataFetcher {
        constructor($$0: Internal.RealmsClient_)
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        readonly newsManager: Internal.RealmsNewsManager;
        readonly serverListUpdateTask: Internal.DataFetcher$Task<Internal.List<Internal.RealmsServer>>;
        readonly notificationsTask: Internal.DataFetcher$Task<Internal.List<Internal.RealmsNotification>>;
        readonly newsTask: Internal.DataFetcher$Task<Internal.RealmsNews>;
        readonly dataFetcher: Internal.DataFetcher;
        readonly liveStatsTask: Internal.DataFetcher$Task<Internal.RealmsServerPlayerLists>;
        readonly trialAvailabilityTask: Internal.DataFetcher$Task<boolean>;
        readonly pendingInvitesTask: Internal.DataFetcher$Task<number>;
    }
    type RealmsDataFetcher_ = RealmsDataFetcher;
    class TreeFromStructureNBTConfig extends Internal.Record implements Internal.FeatureConfiguration {
        constructor(baseLocation: ResourceLocation_, canopyLocation: ResourceLocation_, height: Internal.IntProvider_, logProvider: Internal.BlockStateProvider_, leavesProvider: Internal.BlockStateProvider_, logTarget: Internal.Set_<Internal.Block>, leavesTarget: Internal.Set_<Internal.Block>, growableOn: net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate_, leavesPlacementFilter: net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate_, maxLogDepth: number, treeDecorators: Internal.List_<Internal.TreeDecorator>, placeFromNBT: Internal.Set_<Internal.Block>)
        constructor(baseLocation: ResourceLocation_, canopyLocation: ResourceLocation_, height: Internal.IntProvider_, logProvider: Internal.BlockStateProvider_, leavesProvider: Internal.BlockStateProvider_, logTarget: Internal.Supplier_<Internal.Block>, leavesTarget: Internal.Supplier_<Internal.Block>, growableOn: Internal.TagKey_<Internal.Block>, maxLogDepth: number, treeDecorators: Internal.List_<Internal.TreeDecorator>)
        constructor(baseLocation: ResourceLocation_, canopyLocation: ResourceLocation_, height: Internal.IntProvider_, logProvider: Internal.BlockStateProvider_, leavesProvider: Internal.BlockStateProvider_, logTarget: Internal.Collection_<Internal.Block>, leavesTarget: Internal.List_<Internal.Block>, growableOn: Internal.TagKey_<Internal.Block>, maxLogDepth: number, treeDecorators: Internal.List_<Internal.TreeDecorator>)
        constructor(baseLocation: ResourceLocation_, canopyLocation: ResourceLocation_, height: Internal.IntProvider_, logProvider: Internal.BlockStateProvider_, leavesProvider: Internal.BlockStateProvider_, logTarget: Internal.Block_, leavesTarget: Internal.Block_, growableOn: Internal.TagKey_<Internal.Block>, maxLogDepth: number)
        constructor(baseLocation: ResourceLocation_, canopyLocation: ResourceLocation_, height: Internal.IntProvider_, logProvider: Internal.BlockStateProvider_, leavesProvider: Internal.BlockStateProvider_, logTarget: Internal.Block_, leavesTarget: Internal.Block_, growableOn: Internal.TagKey_<Internal.Block>, maxLogDepth: number, treeDecorators: Internal.List_<Internal.TreeDecorator>)
        leavesProvider(): Internal.BlockStateProvider;
        getClass(): typeof any;
        height(): Internal.IntProvider;
        getFeatures(): Internal.Stream<Internal.ConfiguredFeature<any, any>>;
        toString(): string;
        notifyAll(): void;
        canopyLocation(): ResourceLocation;
        baseLocation(): ResourceLocation;
        maxLogDepth(): number;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        leavesTarget(): Internal.Set<Internal.Block>;
        logProvider(): Internal.BlockStateProvider;
        hashCode(): number;
        growableOn(): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        wait(): void;
        treeDecorators(): Internal.List<Internal.TreeDecorator>;
        wait(arg0: number): void;
        placeFromNBT(): Internal.Set<Internal.Block>;
        equals(o: any): boolean;
        leavesPlacementFilter(): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        logTarget(): Internal.Set<Internal.Block>;
        get class(): typeof any
        get features(): Internal.Stream<Internal.ConfiguredFeature<any, any>>
        static readonly CODEC: Internal.Codec<Internal.TreeFromStructureNBTConfig>;
        static readonly BLOCK_SET_CODEC: Internal.Codec<Internal.Set<Internal.Block>>;
    }
    type TreeFromStructureNBTConfig_ = TreeFromStructureNBTConfig;
    interface FocusListener extends Internal.EventListener {
        abstract focusGained(arg0: Internal.FocusEvent_): void;
        abstract focusLost(arg0: Internal.FocusEvent_): void;
    }
    type FocusListener_ = FocusListener;
    class MessageSignatureCache {
        constructor($$0: number)
        static createDefault(): Internal.MessageSignatureCache;
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        unpack($$0: number): Internal.MessageSignature;
        hashCode(): number;
        wait(): void;
        pack($$0: Internal.MessageSignature_): number;
        wait(arg0: number): void;
        push($$0: Internal.PlayerChatMessage_): void;
        equals(arg0: any): boolean;
        get class(): typeof any
        static readonly NOT_FOUND: (-1) & (number);
    }
    type MessageSignatureCache_ = MessageSignatureCache;
    class ManufactoryHaloItem extends Internal.AssemblyHaloItem {
        constructor(props: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, world: Internal.Level_, stacks: Internal.List_<net.minecraft.network.chat.Component>, flags: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        static onItemCrafted(player: Internal.Player_, inv: net.minecraft.world.Container_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        getGlowResource(stack: Internal.ItemStack_): ResourceLocation;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(world: Internal.Level_, player: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        onEntitySwing(stack: Internal.ItemStack_, living: Internal.LivingEntity_): boolean;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick(stack: Internal.ItemStack_, world: Internal.Level_, entity: Internal.Entity_, pos: number, equipped: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe(stack: Internal.ItemStack_, cursor: Internal.ItemStack_, slot: Internal.Slot_, click: Internal.ClickAction_, player: Internal.Player_, access: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
        static readonly TAG_ACTIVE: ("active") & (string);
    }
    type ManufactoryHaloItem_ = ManufactoryHaloItem;
    class Direction$AxisDirection extends Internal.Enum<Internal.Direction$AxisDirection> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        toString(): string;
        getStep(): number;
        notifyAll(): void;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.Direction$AxisDirection>>;
        "compareTo(net.minecraft.core.Direction$AxisDirection)"(arg0: Internal.Direction$AxisDirection_): number;
        getDeclaringClass(): typeof Internal.Direction$AxisDirection;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        name(): string;
        opposite(): this;
        hashCode(): number;
        static values(): Internal.Direction$AxisDirection[];
        ordinal(): number;
        wait(): void;
        getName(): string;
        compareTo(arg0: Internal.Direction$AxisDirection_): number;
        wait(arg0: number): void;
        static valueOf($$0: string): Internal.Direction$AxisDirection;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        get class(): typeof any
        get step(): number
        get declaringClass(): typeof Internal.Direction$AxisDirection
        get name(): string
        static readonly POSITIVE: (Internal.Direction$AxisDirection) & (Internal.Direction$AxisDirection);
        static readonly NEGATIVE: (Internal.Direction$AxisDirection) & (Internal.Direction$AxisDirection);
    }
    type Direction$AxisDirection_ = "negative" | "positive" | Direction$AxisDirection;
    interface ToNumberStrategy {
        abstract readNumber(arg0: Internal.JsonReader_): number;
        (arg0: Internal.JsonReader): number;
    }
    type ToNumberStrategy_ = ToNumberStrategy | ((arg0: Internal.JsonReader)=> number);
    class AllOfCondition$Builder extends Internal.CompositeLootItemCondition$Builder {
        constructor(...$$0: Internal.LootItemCondition$Builder_[])
        getClass(): typeof any;
        toString(): string;
        or($$0: Internal.LootItemCondition$Builder_): Internal.AnyOfCondition$Builder;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        and($$0: Internal.LootItemCondition$Builder_): this;
        build(): Internal.LootItemCondition;
        hashCode(): number;
        addTerm($$0: Internal.LootItemCondition$Builder_): void;
        invert(): Internal.LootItemCondition$Builder;
        wait(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        get class(): typeof any
    }
    type AllOfCondition$Builder_ = AllOfCondition$Builder;
    interface CustomBlockState extends Internal.CustomBlockStateOrTombstone {
        getProperties(): Internal.Collection<Internal.Property<any>>;
        abstract axiomHasProperty<T extends Internal.Comparable<T>>(arg0: Internal.Property_<T>): boolean;
        abstract setPropertyUnsafe<T extends Internal.Comparable<T>>(arg0: Internal.Property_<T>, arg1: Internal.Comparable_<any>): this;
        abstract getCustomBlock(): Internal.CustomBlock;
        abstract getProperty<T extends Internal.Comparable<T>>(arg0: Internal.Property_<T>): T;
        abstract getVanillaState(): Internal.BlockState;
        get properties(): Internal.Collection<Internal.Property<any>>
        get customBlock(): Internal.CustomBlock
        get vanillaState(): Internal.BlockState
    }
    type CustomBlockState_ = CustomBlockState;
    class ShulkerBullet extends Internal.Projectile {
        constructor($$0: Internal.EntityType_<Internal.ShulkerBullet>, $$1: Internal.Level_)
        constructor($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.Entity_, $$3: Internal.Direction$Axis_)
        litematica_setWorld(arg0: Internal.Level_): void;
        handler$hak000$gobber2$gobberOccludeVibrationSignals(cir: Internal.CallbackInfoReturnable_<any>): void;
        isInWall(): boolean;
        etf$getType(): Internal.EntityType<any>;
        getAllSlots(): Internal.Iterable<Internal.ItemStack>;
        getUpVector($$0: number): Vec3d;
        gameEvent($$0: Internal.GameEvent_, $$1: Internal.Entity_): void;
        remove($$0: Internal.Entity$RemovalReason_): void;
        getBlockZ(): number;
        isSuppressingBounce(): boolean;
        dampensVibrations(): boolean;
        hasAttached(type: Internal.AttachmentType_<any>): boolean;
        isSilent(): boolean;
        "playSound(net.minecraft.sounds.SoundEvent)"($$0: Internal.SoundEvent_): void;
        setCulled(value: boolean): void;
        getPitch(): number;
        isOnFire(): boolean;
        rotate($$0: Internal.Rotation_): number;
        getPositionCodec(): Internal.VecDeltaCodec;
        getPassengersAndSelf(): Internal.Stream<any>;
        setMaxUpStep($$0: number): void;
        updateFluidHeightAndDoFluidPushing($$0: Internal.TagKey_<Internal.Fluid>, $$1: number): boolean;
        setPosition(x: number, y: number, z: number): void;
        runCommandSilent(command: string): number;
        chunkPosition(): Internal.ChunkPos;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        emf$isOnGround(): boolean;
        gameEvent($$0: Internal.GameEvent_): void;
        alwaysAccepts(): boolean;
        isShiftKeyDown(): boolean;
        setUUID($$0: Internal.UUID_): void;
        checkBelowWorld(): void;
        isVisuallyCrawling(): boolean;
        setMotionZ(z: number): void;
        handler$ieb000$lambdynlights$onRemove(ci: Internal.CallbackInfo_): void;
        "deserializeNBT(net.minecraft.nbt.Tag)"(arg0: Internal.Tag_): void;
        canFreeze(): boolean;
        ignoreExplosion(): boolean;
        port_lib$setRemovalReason(arg0: Internal.Entity$RemovalReason_): void;
        teleportRelative($$0: number, $$1: number, $$2: number): void;
        getBlockY(): number;
        getIsInsideStructureTracker(): Internal.IsInsideStructureTracker;
        isSpectator(): boolean;
        pehkui_setScaleCache(scaleCache: Internal.ScaleData_[]): void;
        isInWaterOrBubble(): boolean;
        spawnAtLocation($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        getPersistentData(): Internal.CompoundTag;
        getPortalCooldown(): number;
        emf$isGlowing(): boolean;
        getItem(): Internal.ItemStack;
        getRandomZ($$0: number): number;
        pehkui_getOnGround(): boolean;
        causeFallDamage($$0: number, $$1: number, $$2: DamageSource_): boolean;
        getFusionModel(layerIndex: number): Internal.Triple<any, any, any>;
        getDynamicLightChunksToRebuild(forced: boolean): Internal.LongSet;
        getPosition($$0: number): Vec3d;
        setRemoved($$0: Internal.Entity$RemovalReason_): void;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>, initializer: Internal.Supplier_<A>): A;
        getDistanceSq($$0: number, $$1: number, $$2: number): number;
        isInWaterRainOrBubble(): boolean;
        getRemovalReason(): Internal.Entity$RemovalReason;
        wait(arg0: number): void;
        isIgnoringBlockTriggers(): boolean;
        etf$getItemsEquipped(): Internal.Iterable<any>;
        getHandHoldingItemAngle($$0: Internal.Item_): Vec3d;
        etf$getVelocity(): Vec3d;
        hex$markHurt(): void;
        distanceToSqr($$0: Vec3d_): number;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        resetFallDistance(): void;
        canSprint(): boolean;
        modifyAttached<A>(type: Internal.AttachmentType_<A>, modifier: Internal.UnaryOperator_<A>): A;
        blockPosition(): BlockPos;
        isSteppingCarefully(): boolean;
        setBoundingBox($$0: Internal.AABB_): void;
        isAmbientCreature(): boolean;
        "spawnAtLocation(net.minecraft.world.item.ItemStack,float)"($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        getLightLevelDependentMagicValue(): number;
        getBlockX(): number;
        getEncodeId(): string;
        getY($$0: number): number;
        emf$prevPitch(): number;
        getBlock(): Internal.BlockContainerJS;
        getNbt(): Internal.CompoundTag;
        etf$getHandItems(): Internal.Iterable<any>;
        setInvisible($$0: boolean): void;
        etf$getArmorItems(): Internal.Iterable<any>;
        getName(): net.minecraft.network.chat.Component;
        isSubmergedInLoosely(tag: Internal.TagKey_<any>): boolean;
        onGround(): boolean;
        getDynamicLightY(): number;
        getControlledVehicle(): Internal.Entity;
        isOnSameTeam($$0: Internal.Entity_): boolean;
        attack($$0: DamageSource_, $$1: number): boolean;
        onInsideBubbleColumn($$0: boolean): void;
        tick(): void;
        getEyePosition(): Vec3d;
        getEyeHeight(): number;
        hasPassenger($$0: Internal.Predicate_<Internal.Entity>): boolean;
        getYaw(): number;
        emf$isTouchingWater(): boolean;
        emf$getVariableMap(): Internal.Object2FloatOpenHashMap<any>;
        getComponentContainer(): Internal.ComponentContainer;
        hasPermissions($$0: number): boolean;
        getDynamicLightPrevZ(): number;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        pehkui_readScaleNbt(nbt: Internal.CompoundTag_): void;
        setCustomNameVisible($$0: boolean): void;
        isAlliedTo($$0: Internal.Team_): boolean;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>): A;
        setOutOfCamera(value: boolean): void;
        getControllingPassenger(): Internal.LivingEntity;
        getRemainingFireTicks(): number;
        getScriptType(): Internal.ScriptType;
        onlyOpCanSetNbt(): boolean;
        startRiding($$0: Internal.Entity_): boolean;
        saveWithoutId($$0: Internal.CompoundTag_): Internal.CompoundTag;
        getForward(): Vec3d;
        tcdcommons_getCustomData(): Internal.GenericProperties<any>;
        fireImmune(): boolean;
        addMotion($$0: number, $$1: number, $$2: number): void;
        getMaxFallDistance(): number;
        getZ($$0: number): number;
        getId(): number;
        pehkui_isFirstUpdate(): boolean;
        canBeHitByProjectile(): boolean;
        getTicksFrozen(): number;
        wrapWithCondition$kom000$porting_lib_entity$port_lib$captureDrops(level: Internal.Level_, entity: Internal.Entity_): boolean;
        getRecipientsForComponentSync(): Internal.Iterable<any>;
        getRandomX($$0: number): number;
        getDynamicLightZ(): number;
        getEyeY(): number;
        spawnAtLocation($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        pick($$0: number, $$1: number, $$2: boolean): Internal.HitResult;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        fabric_readAttachmentsFromNbt(nbt: Internal.CompoundTag_): void;
        getBoundingBox(): Internal.AABB;
        changeDimension(p_20118_: Internal.ServerLevel_, teleporter: Internal.ITeleporter_): Internal.Entity;
        isInWaterOrRain(): boolean;
        isDescending(): boolean;
        emf$getPitch(): number;
        setItemSlot($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_): void;
        getYHeadRot(): number;
        handler$cbi000$besmirchment$isTeammate(other: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>): void;
        equals($$0: any): boolean;
        getViewYRot($$0: number): number;
        fabric_setCustomTeleportTarget(teleportTarget: Internal.PortalInfo_): void;
        dismountsUnderwater(): boolean;
        frameworkGetDataHolder(): com.mrcrayfish.framework.entity.sync.DataHolder;
        playerTouch($$0: Internal.Player_): void;
        addTag($$0: string): boolean;
        getAddEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>;
        getEyeHeight($$0: Internal.Pose_): number;
        syncPacketPositionCodec($$0: number, $$1: number, $$2: number): void;
        setOwner($$0: Internal.Entity_): void;
        callIsBeingRainedOn(): boolean;
        getTeam(): Internal.Team;
        shouldRenderAtSqrDistance($$0: number): boolean;
        getAttachedOrSet<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        damageSources(): Internal.DamageSources;
        removeAttached<A>(type: Internal.AttachmentType_<A>): A;
        setTicksFrozen($$0: number): void;
        recreateFromPacket($$0: Internal.ClientboundAddEntityPacket_): void;
        getMyRidingOffset(): number;
        dismountTo($$0: number, $$1: number, $$2: number): void;
        bettertrims$getDeflected(): boolean;
        setDeltaMovement($$0: Vec3d_): void;
        getLeashOffset($$0: number): Vec3d;
        etf$getEntityKey(): string;
        etf$getPose(): Internal.Pose;
        hasCustomName(): boolean;
        captureDrops(): Internal.Collection<any>;
        isCulled(): boolean;
        isLiving(): boolean;
        isGlowing(): boolean;
        getX(): number;
        isVehicle(): boolean;
        static transfer(original: Internal.AttachmentTarget_, target: Internal.AttachmentTarget_, isDeath: boolean): void;
        etf$getOptifineId(): number;
        dynamicLightWorld(): Internal.Level;
        getLeashOffset(): Vec3d;
        resetDynamicLight(): void;
        isShot(): boolean;
        isAttackable(): boolean;
        spawnAtLocation($$0: Internal.ItemStack_): Internal.ItemEntity;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        thunderHit($$0: Internal.ServerLevel_, $$1: Internal.LightningBolt_): void;
        setIsInPowderSnow($$0: boolean): void;
        etf$distanceTo(entity: Internal.Entity_): number;
        doEnchantDamageEffects($$0: Internal.LivingEntity_, $$1: Internal.Entity_): void;
        setCustomName($$0: net.minecraft.network.chat.Component_): void;
        getSlot($$0: number): Internal.SlotAccess;
        lambdynlights$scheduleTrackedChunksRebuild(renderer: Internal.LevelRenderer_): void;
        "deserializeNBT(net.minecraft.nbt.CompoundTag)"(nbt: Internal.CompoundTag_): void;
        emf$isInLava(): boolean;
        pehkui_constructScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        handler$hak000$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        getTeamId(): string;
        stopSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isUnderWater(): boolean;
        stopRiding(): void;
        isCustomNameVisible(): boolean;
        isSupportedBy($$0: BlockPos_): boolean;
        getPistonPushReaction(): Internal.PushReaction;
        getX($$0: number): number;
        lookAt($$0: Internal.EntityAnchorArgument$Anchor_, $$1: Vec3d_): void;
        getLuminance(): number;
        callUnsetRemoved(): void;
        getSelfAndPassengers(): Internal.Stream<any>;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        getDeltaMovement(): Vec3d;
        collide($$0: Vec3d_): Vec3d;
        getMotionX(): number;
        "onSyncedDataUpdated(java.util.List)"($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        shoot($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        hasPassenger($$0: Internal.Entity_): boolean;
        be_getTravelerState(): Internal.TravelerState;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        hasIndirectPassenger($$0: Internal.Entity_): boolean;
        getDynamicLightX(): number;
        getEntityData(): Internal.SynchedEntityData;
        setSecondsOnFire($$0: number): void;
        moveTo($$0: number, $$1: number, $$2: number): void;
        emf$getZ(): number;
        "getDisplayName()"(): net.minecraft.network.chat.Component;
        handleInsidePortal($$0: BlockPos_): void;
        setMotion($$0: number, $$1: number, $$2: number): void;
        playSound($$0: Internal.SoundEvent_): void;
        absMoveTo($$0: number, $$1: number, $$2: number): void;
        isOnRails(): boolean;
        getAttachedOrThrow<A>(type: Internal.AttachmentType_<A>): A;
        handler$ikg000$lithium$tryShortcutFluidPushing(tag: Internal.TagKey_<any>, speed: number, cir: Internal.CallbackInfoReturnable_<any>, box: Internal.AABB_, x1: number, x2: number, y1: number, y2: number, z1: number, z2: number, zero: number): void;
        handler$hak000$gobber2$setFrozenTicks(frozenTicks: number, ci: Internal.CallbackInfo_): void;
        restoreFrom($$0: Internal.Entity_): void;
        markFusionRecomputeModels(): void;
        getDimensionChangingDelay(): number;
        isPeacefulCreature(): boolean;
        setOnGround($$0: boolean): void;
        emf$getYaw(): number;
        handler$cbi000$besmirchment$getScoreboardTeam(cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDynamicLuminance(): number;
        setPos($$0: number, $$1: number, $$2: number): void;
        setYaw($$0: number): void;
        getPickRadius(): number;
        notify(): void;
        getVehicle(): Internal.Entity;
        isEffectiveAi(): boolean;
        handler$kom000$porting_lib_entity$port_lib$startRiding(entity: Internal.Entity_, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        startRiding($$0: Internal.Entity_, $$1: boolean): boolean;
        getStringUuid(): string;
        isRemoved(): boolean;
        emf$isSneaking(): boolean;
        setSwimming($$0: boolean): void;
        teleportToWithTicket($$0: number, $$1: number, $$2: number): void;
        fillCrashReportCategory($$0: Internal.CrashReportCategory_): void;
        getRotationVector(): Internal.Vec2;
        refreshDimensions(): void;
        pehkui_writeScaleNbt(nbt: Internal.CompoundTag_): Internal.CompoundTag;
        self(): Internal.Entity;
        etf$getBlockY(): number;
        isSprinting(): boolean;
        "spawnAtLocation(net.minecraft.world.level.ItemLike)"($$0: Internal.ItemLike_): Internal.ItemEntity;
        getMotionY(): number;
        canCollideWith($$0: Internal.Entity_): boolean;
        setLuminance(luminance: number): void;
        setShiftKeyDown($$0: boolean): void;
        getEyePosition($$0: number): Vec3d;
        getPassengers(): Internal.EntityArrayList;
        getBlockExplosionResistance($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.FluidState_, $$5: number): number;
        handler$ldh000$puzzleslib$spawnAtLocation(stack: Internal.ItemStack_, offsetY: number, callback: Internal.CallbackInfoReturnable_<any>, itemEntity: Internal.ItemEntity_): void;
        getZ(): number;
        canSpawnSprintParticle(): boolean;
        "moveTo(net.minecraft.core.BlockPos,float,float)"($$0: BlockPos_, $$1: number, $$2: number): void;
        teleportTo($$0: number, $$1: number, $$2: number): void;
        shootFromRotation($$0: Internal.Entity_, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): void;
        handler$zbk000$porting_lib_base$port_lib$spawnSprintParticle(ci: Internal.CallbackInfo_, pos: BlockPos_, state: Internal.BlockState_): void;
        getServer(): Internal.MinecraftServer;
        moveRelative($$0: number, $$1: Vec3d_): void;
        getFirstPassenger(): Internal.Entity;
        saveAsPassenger($$0: Internal.CompoundTag_): boolean;
        static gatherClosestChunks(chunks: Internal.LongSet_, x: number, y: number, z: number): void;
        handler$kom000$porting_lib_entity$afterSave(nbt: Internal.CompoundTag_, cir: Internal.CallbackInfoReturnable_<any>): void;
        interact($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        getDismountLocationForPassenger($$0: Internal.LivingEntity_): Vec3d;
        checkLeftOwner(): boolean;
        checkSlowFallDistance(): void;
        getSoundSource(): Internal.SoundSource;
        setFabricBalmData(tag: Internal.CompoundTag_): void;
        removeAfterChangingDimensions(): void;
        getPose(): Internal.Pose;
        touchingUnloadedChunk(): boolean;
        getLookAngle(): Vec3d;
        setPositionAndRotation($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        emf$isOnFire(): boolean;
        getMotionZ(): number;
        etf$getUuid(): Internal.UUID;
        removeVehicle(): void;
        isInvisible(): boolean;
        shouldFusionRecomputeModel(layerIndex: number): boolean;
        is($$0: Internal.Entity_): boolean;
        setZ(z: number): void;
        ejectPassengers(): void;
        getY(): number;
        deserializeNBT(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        updateDynamicLightPreviousCoordinates(): void;
        getProfile(): Internal.GameProfile;
        static setViewScale($$0: number): void;
        emf$isAlive(): boolean;
        setLevelCallback($$0: Internal.EntityInLevelCallback_): void;
        showVehicleHealth(): boolean;
        getDistance(pos: BlockPos_): number;
        playSound($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        emf$getVelocity(): Vec3d;
        etf$isBlockEntity(): boolean;
        shouldUpdateDynamicLight(): boolean;
        startSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isOnScoreboardTeam(teamId: string): boolean;
        isPushedByFluid(): boolean;
        localvar$bbb000$architectury$modifyLevelCallback_setLevelCallback(callback: Internal.EntityInLevelCallback_): Internal.EntityInLevelCallback;
        position(): Vec3d;
        setTimeout(): void;
        displayFireAnimation(): boolean;
        turn($$0: number, $$1: number): void;
        isOutOfCamera(): boolean;
        getAirSupply(): number;
        getRopeHoldPosition($$0: number): Vec3d;
        copyPosition($$0: Internal.Entity_): void;
        "hasPassenger(net.minecraft.world.entity.Entity)"($$0: Internal.Entity_): boolean;
        etf$canBeBright(): boolean;
        isCrouching(): boolean;
        moveTo($$0: BlockPos_, $$1: number, $$2: number): void;
        isPlayer(): boolean;
        isAnimal(): boolean;
        "handler$fgd000$fabric-dimensions-v1$getTeleportTarget"(destination: Internal.ServerLevel_, cir: Internal.CallbackInfoReturnable_<any>): void;
        canBeCollidedWith(): boolean;
        getMotionDirection(): Internal.Direction;
        asComponentProvider(): Internal.ComponentProvider;
        setY(y: number): void;
        getFeetBlockState(): Internal.BlockState;
        lavaHurt(): void;
        handleDamageEvent($$0: DamageSource_): void;
        getFabricBalmData(): Internal.CompoundTag;
        canChangeDimensions(): boolean;
        getChangeListener(): Internal.EntityInLevelCallback;
        static tickEntity(entity: Internal.Entity_): void;
        getCommandSenderWorld(): Internal.Level;
        positionRider($$0: Internal.Entity_): void;
        baseTick(): void;
        broadcastToPlayer($$0: Internal.ServerPlayer_): boolean;
        changeDimension($$0: Internal.ServerLevel_): Internal.Entity;
        setSharedFlag($$0: number, $$1: boolean): void;
        getOwner(): Internal.Entity;
        handler$kom000$porting_lib_entity$afterLoad(nbt: Internal.CompoundTag_, ci: Internal.CallbackInfo_): void;
        getCustomName(): net.minecraft.network.chat.Component;
        getClass(): typeof any;
        pehkui_shouldIgnoreScaleNbt(): boolean;
        isMoving(): boolean;
        isVisuallySwimming(): boolean;
        getMaxAirSupply(): number;
        attack(hp: number): void;
        dynamicLightTick(): void;
        getFacing(): Internal.Direction;
        emf$isWet(): boolean;
        "hasPassenger(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.Entity>): boolean;
        getDimensions($$0: Internal.Pose_): Internal.EntityDimensions;
        isPassengerOfSameVehicle($$0: Internal.Entity_): boolean;
        invokeGetLeashOffset(): Vec3d;
        isSwimming(): boolean;
        getBoundingBoxForCulling(): Internal.AABB;
        mayInteract($$0: Internal.Level_, $$1: BlockPos_): boolean;
        static collideBoundingBox(entity: Internal.Entity_, movement: Vec3d_, entityBoundingBox: Internal.AABB_, world: Internal.Level_, collisions: Internal.List_<any>): Vec3d;
        setSprinting($$0: boolean): void;
        getDynamicLightLevel(): Internal.Level;
        setPortalCooldown(): void;
        setX(x: number): void;
        trackingPosition(): Vec3d;
        getNameTagOffsetY(): number;
        isInvulnerable(): boolean;
        isInLava(): boolean;
        isInWater(): boolean;
        getPortalWaitTime(): number;
        awardKillScore($$0: Internal.Entity_, $$1: number, $$2: DamageSource_): void;
        getBlockStateOn(): Internal.BlockState;
        getFluidHeightLoosely(tag: Internal.TagKey_<any>): number;
        getFluidJumpThreshold(): number;
        unsetRemoved(): void;
        "setPositionAndRotation(double,double,double,float,float)"($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        isInvisibleTo($$0: Internal.Player_): boolean;
        pehkui_getScaleCache(): Internal.ScaleData[];
        setFusionModel(layerIndex: number, model: Internal.Triple_<any, any, any>): void;
        setAirSupply($$0: number): void;
        getOnPos(): BlockPos;
        getRootVehicle(): Internal.Entity;
        getOwnerUUID(): Internal.UUID;
        etf$getWorld(): Internal.Level;
        save($$0: Internal.CompoundTag_): boolean;
        pehkui_getScales(): Internal.Map<any, any>;
        isNoGravity(): boolean;
        etf$getNbt(): Internal.CompoundTag;
        acceptsFailure(): boolean;
        etf$getBlockPos(): BlockPos;
        pehkui_setShouldIgnoreScaleNbt(ignore: boolean): void;
        setOnGroundWithKnownMovement($$0: boolean, $$1: Vec3d_): void;
        setOldPosAndRot(): void;
        bettertrims$setDeflected(deflected: boolean): void;
        emf$getY(): number;
        handler$kom000$porting_lib_entity$port_lib$entityInit(entityType: Internal.EntityType_<any>, world: Internal.Level_, ci: Internal.CallbackInfo_): void;
        bookshelf$createHoverEvent(): Internal.HoverEvent;
        isFree($$0: number, $$1: number, $$2: number): boolean;
        updateSwimming(): void;
        "moveTo(double,double,double)"($$0: number, $$1: number, $$2: number): void;
        setRemainingFireTicks($$0: number): void;
        getCachedFeetBlockState(): Internal.BlockState;
        shouldInformAdmins(): boolean;
        rideTick(): void;
        emf$age(): number;
        etf$hasCustomName(): boolean;
        /**
         * @deprecated
        */
        getOnPosLegacy(): BlockPos;
        setPos($$0: Vec3d_): void;
        wait(): void;
        getUuid(): Internal.UUID;
        spawn(): void;
        teleportTo($$0: Internal.ServerLevel_, $$1: number, $$2: number, $$3: number, $$4: Internal.Set_<Internal.RelativeMovement>, $$5: number, $$6: number): boolean;
        handler$kom000$porting_lib_entity$port_lib$removeRidingEntity(ci: Internal.CallbackInfo_): void;
        etf$getCustomName(): net.minecraft.network.chat.Component;
        captureDrops(value: Internal.Collection_<any>): Internal.Collection<any>;
        fabric_writeAttachmentsToNbt(nbt: Internal.CompoundTag_): void;
        shouldShowName(): boolean;
        setSilent($$0: boolean): void;
        getArmorSlots(): Internal.Iterable<Internal.ItemStack>;
        hasExactlyOnePlayerPassenger(): boolean;
        kill(): void;
        isOnPortalCooldown(): boolean;
        animateHurt($$0: number): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        handler$kom000$porting_lib_entity$port_lib$onEntityRemove(reason: Internal.Entity$RemovalReason_, ci: Internal.CallbackInfo_): void;
        lambdynlights$setTrackedLitChunkPos(trackedLitChunkPos: Internal.LongSet_): void;
        callGetEyeHeight(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        setPitch($$0: number): void;
        setPosRaw($$0: number, $$1: number, $$2: number): void;
        handleEntityEvent($$0: number): void;
        isAlwaysTicking(): boolean;
        interactAt($$0: Internal.Player_, $$1: Vec3d_, $$2: Internal.InteractionHand_): Internal.InteractionResult;
        emf$getX(): number;
        deserializeNBT(arg0: Internal.Tag_): void;
        puzzleslib$acceptCapturedDrops(capturedDrops: Internal.Collection_<any>): Internal.Collection<any>;
        handler$hak000$gobber2$gobberIsFireImmune(cir: Internal.CallbackInfoReturnable_<any>): void;
        lerpTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: boolean): void;
        onPassengerTurned($$0: Internal.Entity_): void;
        modifyReturnValue$zhe000$additionalentityattributes$getMaxAir(original: number): number;
        spawnAtLocation($$0: Internal.ItemLike_): Internal.ItemEntity;
        emf$hasPassengers(): boolean;
        serializeNBT(): Internal.CompoundTag;
        setAttached(type: Internal.AttachmentType_<any>, value: any): any;
        getBbWidth(): number;
        splitIntoDynamicLightEntries(): Internal.Stream<Internal.SpatialLookupEntry>;
        port_lib$getEntityString(): string;
        addDeltaMovement($$0: Vec3d_): void;
        pehkui_setOnGround(onGround: boolean): void;
        lithiumOnBlockCacheDeleted(): void;
        "spawnAtLocation(net.minecraft.world.level.ItemLike,int)"($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        setInvulnerable($$0: boolean): void;
        "getName()"(): net.minecraft.network.chat.Component;
        push($$0: Internal.Entity_): void;
        emf$hasVehicle(): boolean;
        mirror($$0: Internal.Mirror_): number;
        static port_lib$collideWithShapes(vec3: Vec3d_, aABB: Internal.AABB_, list: Internal.List_<Internal.VoxelShape>): Vec3d;
        getTicksRequiredToFreeze(): number;
        getDynamicLightPrevY(): number;
        maxUpStep(): number;
        setGlowing($$0: boolean): void;
        load($$0: Internal.CompoundTag_): void;
        isAlive(): boolean;
        emf$prevZ(): number;
        getBbHeight(): number;
        getUsername(): string;
        move($$0: Internal.MoverType_, $$1: Vec3d_): void;
        getTags(): Internal.Set<string>;
        getViewVector($$0: number): Vec3d;
        lithiumOnBlockCacheSet(newState: Internal.BlockState_): void;
        isPickable(): boolean;
        setYHeadRot($$0: number): void;
        hasControllingPassenger(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number, $$2: number): boolean;
        absMoveTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        getCustomData(): Internal.CompoundTag;
        getPickResult(): Internal.ItemStack;
        getPercentFrozen(): number;
        getRandomY(): number;
        setPortalCooldown($$0: number): void;
        getDisplayName(): net.minecraft.network.chat.Component;
        hasGlowingTag(): boolean;
        shouldBlockExplode($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: number): boolean;
        emf$isInvisible(): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        emf$isSprinting(): boolean;
        getDynamicLightPrevX(): number;
        shouldBeSaved(): boolean;
        fabric_hasPersistentAttachments(): boolean;
        getViewXRot($$0: number): number;
        canRiderInteract(): boolean;
        fabric_getAttachments(): Internal.Map<any, any>;
        removeTag($$0: string): boolean;
        setPose($$0: Internal.Pose_): void;
        getFluidHeight($$0: Internal.TagKey_<Internal.Fluid>): number;
        getEntityType(): Internal.EntityType<any>;
        isWaterCreature(): boolean;
        pehkui_getScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        toString(): string;
        notifyAll(): void;
        getPassengersRidingOffset(): number;
        etf$getScoreboardTeam(): Internal.Team;
        distanceToEntitySqr($$0: Internal.Entity_): number;
        handler$ldh000$puzzleslib$removeVehicle(callback: Internal.CallbackInfo_): void;
        "getServer()"(): Internal.MinecraftServer;
        isFrame(): boolean;
        setLeftOwner(arg0: boolean): void;
        isPushable(): boolean;
        setYBodyRot($$0: number): void;
        discard(): void;
        onClientRemoval(): void;
        "handler$mhe000$step-height-entity-attribute$getStepHeight"(cir: Internal.CallbackInfoReturnable_<any>): void;
        sendSystemMessage($$0: net.minecraft.network.chat.Component_): void;
        acceptsSuccess(): boolean;
        getDistance(x: number, y: number, z: number): number;
        setMotionY(y: number): void;
        setNoGravity($$0: boolean): void;
        getEffectSource(): Internal.Entity;
        getAttached(type: Internal.AttachmentType_<any>): any;
        getIndirectPassengers(): Internal.Iterable<any>;
        setRotation(yaw: number, pitch: number): void;
        isDynamicLightEnabled(): boolean;
        handler$ldh000$puzzleslib$startRiding(vehicle: Internal.Entity_, force: boolean, callback: Internal.CallbackInfoReturnable_<any>): void;
        createCommandSourceStack(): Internal.CommandSourceStack;
        isControlledByLocalInstance(): boolean;
        isMonster(): boolean;
        pehkui_setShouldSyncScales(sync: boolean): void;
        setLastDynamicLuminance(luminance: number): void;
        setId($$0: number): void;
        onSyncedDataUpdated($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        getHorizontalFacing(): Internal.Direction;
        getType(): string;
        getLightProbePosition($$0: number): Vec3d;
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        onAboveBubbleCol($$0: boolean): void;
        emf$prevX(): number;
        "playSound(net.minecraft.sounds.SoundEvent,float,float)"(id: Internal.SoundEvent_, volume: number, pitch: number): void;
        toComponentPacket(key: Internal.ComponentKey_<any>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        isPassenger(): boolean;
        hasPose($$0: Internal.Pose_): boolean;
        checkDespawn(): void;
        pehkui_shouldSyncScales(): boolean;
        isEyeInFluid($$0: Internal.TagKey_<Internal.Fluid>): boolean;
        isInvulnerableTo($$0: DamageSource_): boolean;
        makeStuckInBlock($$0: Internal.BlockState_, $$1: Vec3d_): void;
        getAttachedOrGet<A>(type: Internal.AttachmentType_<A>, defaultValue: Internal.Supplier_<A>): A;
        skipAttackInteraction($$0: Internal.Entity_): boolean;
        lerpMotion($$0: number, $$1: number, $$2: number): void;
        shouldRender($$0: number, $$1: number, $$2: number): boolean;
        onSyncedDataUpdated($$0: Internal.EntityDataAccessor_<any>): void;
        lerpHeadTo($$0: number, $$1: number): void;
        handler$bia000$axiom$onTurn(d: number, e: number, ci: Internal.CallbackInfo_): void;
        static getViewScale(): number;
        setMotionX(x: number): void;
        getHandSlots(): Internal.Iterable<Internal.ItemStack>;
        distanceToEntity($$0: Internal.Entity_): number;
        getVisualRotationYInDegrees(): number;
        isLeftOwner(): boolean;
        wait(arg0: number, arg1: number): void;
        isDiscrete(): boolean;
        getTeamColor(): number;
        setNbt(nbt: Internal.CompoundTag_): void;
        lithiumSetClimbingMobCachingSectionUpdateBehavior(listening: boolean): void;
        unRide(): void;
        getLevel(): Internal.Level;
        "spawnAtLocation(net.minecraft.world.item.ItemStack)"($$0: Internal.ItemStack_): Internal.ItemEntity;
        lambdynlights$getTrackedLitChunkPos(): Internal.LongSet;
        extinguish(): void;
        setDynamicLightEnabled(enabled: boolean): void;
        updateDynamicGameEventListener($$0: Internal.BiConsumer_<Internal.DynamicGameEventListener<any>, Internal.ServerLevel>): void;
        moveTo($$0: Vec3d_): void;
        isColliding($$0: BlockPos_, $$1: Internal.BlockState_): boolean;
        "onSyncedDataUpdated(net.minecraft.network.syncher.EntityDataAccessor)"($$0: Internal.EntityDataAccessor_<any>): void;
        emf$prevY(): number;
        extinguishFire(): void;
        lambdynlights$updateDynamicLight(renderer: Internal.LevelRenderer_): boolean;
        setShot(arg0: boolean): void;
        tell(message: net.minecraft.network.chat.Component_): void;
        static port_lib$collideWithShapes$porting_lib_accessors_$md$424943$0(arg0: Vec3d_, arg1: Internal.AABB_, arg2: Internal.List_<any>): Vec3d;
        isForcedVisible(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number): boolean;
        getDistanceSq(pos: BlockPos_): number;
        emf$getTypeString(): string;
        killedEntity($$0: Internal.ServerLevel_, $$1: Internal.LivingEntity_): boolean;
        getAttachedOrElse<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        isFreezing(): boolean;
        isFullyFrozen(): boolean;
        runCommand(command: string): number;
        setSharedFlagOnFire($$0: boolean): void;
        get inWall(): boolean
        get allSlots(): Internal.Iterable<Internal.ItemStack>
        get blockZ(): number
        get suppressingBounce(): boolean
        get silent(): boolean
        set culled(value: boolean)
        get pitch(): number
        get onFire(): boolean
        get positionCodec(): Internal.VecDeltaCodec
        get passengersAndSelf(): Internal.Stream<any>
        set maxUpStep($$0: number)
        get shiftKeyDown(): boolean
        set UUID($$0: Internal.UUID_)
        get visuallyCrawling(): boolean
        set motionZ(z: number)
        get blockY(): number
        get isInsideStructureTracker(): Internal.IsInsideStructureTracker
        get spectator(): boolean
        get inWaterOrBubble(): boolean
        get persistentData(): Internal.CompoundTag
        get portalCooldown(): number
        get item(): Internal.ItemStack
        set removed($$0: Internal.Entity$RemovalReason_)
        get inWaterRainOrBubble(): boolean
        get removalReason(): Internal.Entity$RemovalReason
        get ignoringBlockTriggers(): boolean
        get steppingCarefully(): boolean
        set boundingBox($$0: Internal.AABB_)
        get ambientCreature(): boolean
        get lightLevelDependentMagicValue(): number
        get blockX(): number
        get encodeId(): string
        get block(): Internal.BlockContainerJS
        get nbt(): Internal.CompoundTag
        set invisible($$0: boolean)
        get name(): net.minecraft.network.chat.Component
        get dynamicLightY(): number
        get controlledVehicle(): Internal.Entity
        get eyePosition(): Vec3d
        get eyeHeight(): number
        get yaw(): number
        get componentContainer(): Internal.ComponentContainer
        get dynamicLightPrevZ(): number
        set customNameVisible($$0: boolean)
        set outOfCamera(value: boolean)
        get controllingPassenger(): Internal.LivingEntity
        get remainingFireTicks(): number
        get scriptType(): Internal.ScriptType
        get forward(): Vec3d
        get maxFallDistance(): number
        get id(): number
        get ticksFrozen(): number
        get recipientsForComponentSync(): Internal.Iterable<any>
        get dynamicLightZ(): number
        get eyeY(): number
        set statusMessage(message: net.minecraft.network.chat.Component_)
        get boundingBox(): Internal.AABB
        get inWaterOrRain(): boolean
        get descending(): boolean
        get YHeadRot(): number
        get addEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>
        set owner($$0: Internal.Entity_)
        get team(): Internal.Team
        set ticksFrozen($$0: number)
        get myRidingOffset(): number
        set deltaMovement($$0: Vec3d_)
        get culled(): boolean
        get living(): boolean
        get glowing(): boolean
        get x(): number
        get vehicle(): boolean
        get leashOffset(): Vec3d
        get shot(): boolean
        get attackable(): boolean
        set isInPowderSnow($$0: boolean)
        set customName($$0: net.minecraft.network.chat.Component_)
        get teamId(): string
        get underWater(): boolean
        get customNameVisible(): boolean
        get pistonPushReaction(): Internal.PushReaction
        get luminance(): number
        get selfAndPassengers(): Internal.Stream<any>
        get deltaMovement(): Vec3d
        get motionX(): number
        get dynamicLightX(): number
        get entityData(): Internal.SynchedEntityData
        set secondsOnFire($$0: number)
        get "displayName()"(): net.minecraft.network.chat.Component
        get onRails(): boolean
        get dimensionChangingDelay(): number
        get peacefulCreature(): boolean
        set onGround($$0: boolean)
        get lastDynamicLuminance(): number
        set yaw($$0: number)
        get pickRadius(): number
        get vehicle(): Internal.Entity
        get effectiveAi(): boolean
        get stringUuid(): string
        get removed(): boolean
        set swimming($$0: boolean)
        get rotationVector(): Internal.Vec2
        get sprinting(): boolean
        get motionY(): number
        set luminance(luminance: number)
        set shiftKeyDown($$0: boolean)
        get passengers(): Internal.EntityArrayList
        get z(): number
        get server(): Internal.MinecraftServer
        get firstPassenger(): Internal.Entity
        get soundSource(): Internal.SoundSource
        set fabricBalmData(tag: Internal.CompoundTag_)
        get pose(): Internal.Pose
        get lookAngle(): Vec3d
        get motionZ(): number
        get invisible(): boolean
        set z(z: number)
        get y(): number
        get profile(): Internal.GameProfile
        set viewScale($$0: number)
        set levelCallback($$0: Internal.EntityInLevelCallback_)
        get pushedByFluid(): boolean
        get outOfCamera(): boolean
        get airSupply(): number
        get crouching(): boolean
        get player(): boolean
        get animal(): boolean
        get motionDirection(): Internal.Direction
        set y(y: number)
        get feetBlockState(): Internal.BlockState
        get fabricBalmData(): Internal.CompoundTag
        get changeListener(): Internal.EntityInLevelCallback
        get commandSenderWorld(): Internal.Level
        get owner(): Internal.Entity
        get customName(): net.minecraft.network.chat.Component
        get class(): typeof any
        get moving(): boolean
        get visuallySwimming(): boolean
        get maxAirSupply(): number
        get facing(): Internal.Direction
        get swimming(): boolean
        get boundingBoxForCulling(): Internal.AABB
        set sprinting($$0: boolean)
        get dynamicLightLevel(): Internal.Level
        set x(x: number)
        get nameTagOffsetY(): number
        get invulnerable(): boolean
        get inLava(): boolean
        get inWater(): boolean
        get portalWaitTime(): number
        get blockStateOn(): Internal.BlockState
        get fluidJumpThreshold(): number
        set airSupply($$0: number)
        get onPos(): BlockPos
        get rootVehicle(): Internal.Entity
        get ownerUUID(): Internal.UUID
        get noGravity(): boolean
        set remainingFireTicks($$0: number)
        get cachedFeetBlockState(): Internal.BlockState
        /**
         * @deprecated
        */
        get onPosLegacy(): BlockPos
        set pos($$0: Vec3d_)
        get uuid(): Internal.UUID
        set silent($$0: boolean)
        get armorSlots(): Internal.Iterable<Internal.ItemStack>
        get onPortalCooldown(): boolean
        set pitch($$0: number)
        get alwaysTicking(): boolean
        get bbWidth(): number
        set invulnerable($$0: boolean)
        get "name()"(): net.minecraft.network.chat.Component
        get ticksRequiredToFreeze(): number
        get dynamicLightPrevY(): number
        set glowing($$0: boolean)
        get alive(): boolean
        get bbHeight(): number
        get username(): string
        get tags(): Internal.Set<string>
        get pickable(): boolean
        set YHeadRot($$0: number)
        get customData(): Internal.CompoundTag
        get pickResult(): Internal.ItemStack
        get percentFrozen(): number
        get randomY(): number
        set portalCooldown($$0: number)
        get displayName(): net.minecraft.network.chat.Component
        set position(block: Internal.BlockContainerJS_)
        get dynamicLightPrevX(): number
        set pose($$0: Internal.Pose_)
        get entityType(): Internal.EntityType<any>
        get waterCreature(): boolean
        get passengersRidingOffset(): number
        get "server()"(): Internal.MinecraftServer
        get frame(): boolean
        set leftOwner(arg0: boolean)
        get pushable(): boolean
        set YBodyRot($$0: number)
        set motionY(y: number)
        set noGravity($$0: boolean)
        get effectSource(): Internal.Entity
        get indirectPassengers(): Internal.Iterable<any>
        get dynamicLightEnabled(): boolean
        get controlledByLocalInstance(): boolean
        get monster(): boolean
        set lastDynamicLuminance(luminance: number)
        set id($$0: number)
        get horizontalFacing(): Internal.Direction
        get type(): string
        get passenger(): boolean
        get viewScale(): number
        set motionX(x: number)
        get handSlots(): Internal.Iterable<Internal.ItemStack>
        get visualRotationYInDegrees(): number
        get leftOwner(): boolean
        get discrete(): boolean
        get teamColor(): number
        set nbt(nbt: Internal.CompoundTag_)
        get level(): Internal.Level
        set dynamicLightEnabled(enabled: boolean)
        set shot(arg0: boolean)
        get forcedVisible(): boolean
        get freezing(): boolean
        get fullyFrozen(): boolean
        set sharedFlagOnFire($$0: boolean)
    }
    type ShulkerBullet_ = ShulkerBullet;
    class WarpStoneItem extends Internal.Item implements Internal.IResetUseOnDamage {
        constructor(properties: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick(level: Internal.Level_, entity: Internal.LivingEntity_, itemStack: Internal.ItemStack_, remainingTicks: number): void;
        appendHoverText(stack: Internal.ItemStack_, world: Internal.Level_, list: Internal.List_<net.minecraft.network.chat.Component>, flag: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getUseAnimation(itemStack: Internal.ItemStack_): Internal.UseAnim;
        getDescriptionId(): string;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth(itemStack: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(world: Internal.Level_, player: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil(itemStack: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible(itemStack: Internal.ItemStack_): boolean;
        getUseDuration(itemStack: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem(stack: Internal.ItemStack_, world: Internal.Level_, entity: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type WarpStoneItem_ = WarpStoneItem;
    class GemOfPromiseItem$Companion {
        constructor($constructor_marker: any_)
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        register(gem: Internal.IgnitedGemItem_): void;
        get class(): typeof any
    }
    type GemOfPromiseItem$Companion_ = GemOfPromiseItem$Companion;
    interface ToFloatFunction <C> {
        abstract maxValue(): number;
        abstract apply(arg0: C): number;
        abstract minValue(): number;
        createUnlimited($$0: Internal.Float2FloatFunction_): Internal.ToFloatFunction<number>;
        comap<C2>($$0: Internal.Function_<C2, C>): Internal.ToFloatFunction<C2>;
        readonly IDENTITY: Internal.ToFloatFunction<number>;
    }
    type ToFloatFunction_<C> = ToFloatFunction<C>;
    class ConfettiPopperItem extends Internal.Item {
        constructor(properties: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.LivingEntity_, usedHand: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(level: Internal.Level_, player: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type ConfettiPopperItem_ = ConfettiPopperItem;
    interface IMixinDynamicTexture {
        abstract getPixelsKonkrete(): Internal.NativeImage;
        abstract setPixelsKonkrete(arg0: Internal.NativeImage_): void;
        get pixelsKonkrete(): Internal.NativeImage
        set pixelsKonkrete(arg0: Internal.NativeImage_)
    }
    type IMixinDynamicTexture_ = IMixinDynamicTexture;
    class CombatTracker {
        constructor($$0: Internal.LivingEntity_)
        handler$fef000$extraalchemy$onDamageDealt(damageSource: DamageSource_, damage: number, ci: Internal.CallbackInfo_): void;
        getClass(): typeof any;
        recordDamage($$0: DamageSource_, $$1: number): void;
        toString(): string;
        notifyAll(): void;
        recheckStatus(): void;
        notify(): void;
        getCombatDuration(): number;
        wait(arg0: number, arg1: number): void;
        getDeathMessage(): net.minecraft.network.chat.Component;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        get class(): typeof any
        get combatDuration(): number
        get deathMessage(): net.minecraft.network.chat.Component
        static readonly RESET_COMBAT_STATUS_TIME: (300) & (number);
        static readonly RESET_DAMAGE_STATUS_TIME: (100) & (number);
    }
    type CombatTracker_ = CombatTracker;
    interface CustomIngredient extends Internal.CustomIngredientKJS, Internal.CustomIngredientMixin {
        abstract getSerializer(): Internal.CustomIngredientSerializer<any>;
        abstract test(arg0: Internal.ItemStack_): boolean;
        kjs$canBeUsedForMatching(): boolean;
        toVanilla(): Internal.Ingredient;
        abstract getMatchingStacks(): Internal.List<Internal.ItemStack>;
        abstract requiresTesting(): boolean;
        get serializer(): Internal.CustomIngredientSerializer<any>
        get matchingStacks(): Internal.List<Internal.ItemStack>
    }
    type CustomIngredient_ = CustomIngredient;
    interface Merchant {
        abstract notifyTradeUpdated(arg0: Internal.ItemStack_): void;
        abstract notifyTrade(arg0: Internal.MerchantOffer_): void;
        abstract isClientSide(): boolean;
        abstract setTradingPlayer(arg0: Internal.Player_): void;
        abstract getTradingPlayer(): Internal.Player;
        canRestock(): boolean;
        abstract getOffers(): Internal.MerchantOffers;
        openTradingScreen($$0: Internal.Player_, $$1: net.minecraft.network.chat.Component_, $$2: number): void;
        abstract getNotifyTradeSound(): Internal.SoundEvent;
        abstract overrideXp(arg0: number): void;
        abstract overrideOffers(arg0: Internal.MerchantOffers_): void;
        abstract showProgressBar(): boolean;
        abstract getVillagerXp(): number;
        get clientSide(): boolean
        set tradingPlayer(arg0: Internal.Player_)
        get tradingPlayer(): Internal.Player
        get offers(): Internal.MerchantOffers
        get notifyTradeSound(): Internal.SoundEvent
        get villagerXp(): number
    }
    type Merchant_ = Merchant;
    interface ModifierTracking {
        getModifiers(stack: Internal.ItemStack_, type: Internal.ModifierHelperType_<any>): Internal.List<ResourceLocation>;
    }
    type ModifierTracking_ = ModifierTracking;
    interface FocusedStackProvider extends Internal.Comparable<Internal.FocusedStackProvider> {
        getPriority(): number;
        compareTo(o: Internal.FocusedStackProvider_): number;
        abstract provide(arg0: Internal.Screen_, arg1: me.shedaniel.math.Point_): Internal.CompoundEventResult<Internal.EntryStack<any>>;
        "compareTo(java.lang.Object)"(arg0: any): number;
        "compareTo(me.shedaniel.rei.api.client.registry.screen.FocusedStackProvider)"(o: Internal.FocusedStackProvider_): number;
        compareTo(arg0: any): number;
        get priority(): number
        (arg0: Internal.Screen, arg1: me.shedaniel.math.Point): Internal.CompoundEventResult_<Internal.EntryStack<any>>;
    }
    type FocusedStackProvider_ = ((arg0: Internal.Screen, arg1: me.shedaniel.math.Point)=> Internal.CompoundEventResult_<Internal.EntryStack<any>>) | FocusedStackProvider;
    class IdMapper <T> implements Internal.IdMap<T>, Internal.RemovableIdList<any> {
        constructor()
        constructor($$0: number)
        byId($$0: number): T;
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        spliterator(): Internal.Spliterator<T>;
        contains($$0: number): boolean;
        byIdOrThrow($$0: number): T;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        fabric_clear(): void;
        getId($$0: T): number;
        iterator(): Internal.Iterator<T>;
        forEach(arg0: Internal.Consumer_<T>): void;
        size(): number;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        fabric_remapId(from: number, to: number): void;
        fabric_remapIds(map: Internal.Int2IntMap_): void;
        fabric_removeId(i: number): void;
        equals(arg0: any): boolean;
        addMapping($$0: T, $$1: number): void;
        add($$0: T): void;
        fabric_remove(o: any): void;
        get class(): typeof any
    }
    type IdMapper_<T> = IdMapper<T>;
    interface TraceableEntity {
        abstract getOwner(): Internal.Entity;
        get owner(): Internal.Entity
        (): Internal.Entity_;
    }
    type TraceableEntity_ = TraceableEntity | (()=> Internal.Entity_);
    class WorldOptions {
        constructor($$0: number, $$1: boolean, $$2: boolean)
        getClass(): typeof any;
        withStructures($$0: boolean): this;
        generateBonusChest(): boolean;
        toString(): string;
        seed(): number;
        static randomSeed(): number;
        withSeed($$0: Internal.OptionalLong_): this;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        static defaultWithRandomSeed(): Internal.WorldOptions;
        hashCode(): number;
        static parseSeed($$0: string): Internal.OptionalLong;
        wait(): void;
        withBonusChest($$0: boolean): this;
        wait(arg0: number): void;
        isOldCustomizedWorld(): boolean;
        equals(arg0: any): boolean;
        generateStructures(): boolean;
        get class(): typeof any
        get oldCustomizedWorld(): boolean
        static readonly CODEC: (Internal.RecordCodecBuilder$2) & (Internal.MapCodec<Internal.WorldOptions>);
        static readonly DEMO_OPTIONS: (Internal.WorldOptions) & (Internal.WorldOptions);
    }
    type WorldOptions_ = WorldOptions;
    abstract class BlockTypeRegistry <T extends Internal.BlockType> {
        getClass(): typeof any;
        static getRegistryCodec(): Internal.Codec<Internal.BlockTypeRegistry<any>>;
        getValues(): Internal.Collection<T>;
        buildAll(): void;
        get(res: ResourceLocation_): T;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        addRemover(id: ResourceLocation_): void;
        onBlockInit(): void;
        onItemInit(): void;
        registerBlockType(newType: T): void;
        addFinder(finder: Internal.BlockType$SetFinder_<T>): void;
        addTypeTranslations(language: Internal.AfterLanguageLoadEvent_): void;
        getFinders(): Internal.Collection<Internal.BlockType$SetFinder<T>>;
        getCodec(): Internal.Codec<T>;
        abstract detectTypeFromBlock(arg0: Internal.Block_, arg1: ResourceLocation_): Optional<T>;
        priority(): number;
        toString(): string;
        getType(): T;
        notifyAll(): void;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        getFromNBT(name: string): T;
        getBlockTypeOf(itemLike: Internal.ItemLike_): T;
        hashCode(): number;
        abstract getDefaultType(): T;
        wait(): void;
        wait(arg0: number): void;
        getKey(input: T): ResourceLocation;
        typeName(): string;
        equals(arg0: any): boolean;
        get class(): typeof any
        get registryCodec(): Internal.Codec<Internal.BlockTypeRegistry<any>>
        get values(): Internal.Collection<T>
        get finders(): Internal.Collection<Internal.BlockType$SetFinder<T>>
        get codec(): Internal.Codec<T>
        get type(): T
        get defaultType(): T
    }
    type BlockTypeRegistry_<T extends Internal.BlockType> = BlockTypeRegistry<T>;
    class Creeper extends Internal.Monster implements Internal.PowerableMob, Internal.IPartyCreeper, Internal.CreeperAccessor {
        constructor($$0: Internal.EntityType_<Internal.Creeper>, $$1: Internal.Level_)
        handler$hak000$gobber2$gobberOccludeVibrationSignals(cir: Internal.CallbackInfoReturnable_<any>): void;
        handler$fed001$extraalchemy$writeNbt(tag: Internal.CompoundTag_, cb: Internal.CallbackInfo_): void;
        etf$getType(): Internal.EntityType<any>;
        getUpVector($$0: number): Vec3d;
        gameEvent($$0: Internal.GameEvent_, $$1: Internal.Entity_): void;
        static checkMobSpawnRules($$0: Internal.EntityType_<Internal.Mob>, $$1: Internal.LevelAccessor_, $$2: Internal.MobSpawnType_, $$3: BlockPos_, $$4: Internal.RandomSource_): boolean;
        setDefaultMovementSpeedMultiplier(speed: number): void;
        isSuppressingBounce(): boolean;
        setTarget($$0: Internal.LivingEntity_): void;
        handler$han001$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        setCulled(value: boolean): void;
        handler$leb003$puzzleslib$hurt(source: DamageSource_, amount: number, callback: Internal.CallbackInfoReturnable_<any>): void;
        isOnFire(): boolean;
        getPositionCodec(): Internal.VecDeltaCodec;
        setMaxUpStep($$0: number): void;
        updateFluidHeightAndDoFluidPushing($$0: Internal.TagKey_<Internal.Fluid>, $$1: number): boolean;
        convertTo<T extends Internal.Mob>($$0: Internal.EntityType_<T>, $$1: boolean): T;
        getFallFlyingTicks(): number;
        setPosition(x: number, y: number, z: number): void;
        runCommandSilent(command: string): number;
        chunkPosition(): Internal.ChunkPos;
        emf$isOnGround(): boolean;
        dropLeash($$0: boolean, $$1: boolean): void;
        gameEvent($$0: Internal.GameEvent_): void;
        setXxa($$0: number): void;
        setDelayedLeashHolderId($$0: number): void;
        isShiftKeyDown(): boolean;
        setUUID($$0: Internal.UUID_): void;
        checkBelowWorld(): void;
        supplementaries$isFestive(): boolean;
        handler$leb000$puzzleslib$startUsingItem(hand: Internal.InteractionHand_, callback: Internal.CallbackInfo_): void;
        setMotionZ(z: number): void;
        "deserializeNBT(net.minecraft.nbt.Tag)"(arg0: Internal.Tag_): void;
        canFreeze(): boolean;
        ignoreExplosion(): boolean;
        getBlockY(): number;
        getIsInsideStructureTracker(): Internal.IsInsideStructureTracker;
        setPlayerHitTimer(arg0: number): void;
        isSpectator(): boolean;
        increaseDroppedSkulls(): void;
        setMainHandItem(item: Internal.ItemStack_): void;
        removeEffectNoUpdate($$0: Internal.MobEffect_): Internal.MobEffectInstance;
        spawnAtLocation($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        getPersistentData(): Internal.CompoundTag;
        getHealth(): number;
        getMaxHealth(): number;
        emf$isGlowing(): boolean;
        setPathfindingMalus($$0: Internal.BlockPathTypes_, $$1: number): void;
        isRegisteredToWorld(): boolean;
        getRandomZ($$0: number): number;
        pehkui_getOnGround(): boolean;
        setAggressive($$0: boolean): void;
        handler$lef000$puzzleslib$checkDespawn(callback: Internal.CallbackInfo_): void;
        getFusionModel(layerIndex: number): Internal.Triple<any, any, any>;
        setRemoved($$0: Internal.Entity$RemovalReason_): void;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>, initializer: Internal.Supplier_<A>): A;
        getDistanceSq($$0: number, $$1: number, $$2: number): number;
        isInWaterRainOrBubble(): boolean;
        getRemovalReason(): Internal.Entity$RemovalReason;
        etf$getVelocity(): Vec3d;
        hex$markHurt(): void;
        resetFallDistance(): void;
        canSprint(): boolean;
        blockPosition(): BlockPos;
        setBoundingBox($$0: Internal.AABB_): void;
        isAmbientCreature(): boolean;
        setZza($$0: number): void;
        getBlock(): Internal.BlockContainerJS;
        setEquipment(slot: Internal.EquipmentSlot_, item: Internal.ItemStack_): void;
        etf$getHandItems(): Internal.Iterable<any>;
        randomTeleport($$0: number, $$1: number, $$2: number, $$3: boolean): boolean;
        getName(): net.minecraft.network.chat.Component;
        playAmbientSound(): void;
        onGround(): boolean;
        handler$leb000$puzzleslib$canBeAffected(effectInstance: Internal.MobEffectInstance_, callback: Internal.CallbackInfoReturnable_<any>): void;
        getControlledVehicle(): Internal.Entity;
        isOnSameTeam($$0: Internal.Entity_): boolean;
        getArmorValue(): number;
        tick(): void;
        localvar$lef000$puzzleslib$setTarget(entity: Internal.LivingEntity_): Internal.LivingEntity;
        getKillCredit(): Internal.LivingEntity;
        emf$isTouchingWater(): boolean;
        emf$getVariableMap(): Internal.Object2FloatOpenHashMap<any>;
        getComponentContainer(): Internal.ComponentContainer;
        hasPermissions($$0: number): boolean;
        getDynamicLightPrevZ(): number;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        pehkui_readScaleNbt(nbt: Internal.CompoundTag_): void;
        setOutOfCamera(value: boolean): void;
        static createMobAttributes(): Internal.AttributeSupplier$Builder;
        isAutoSpinAttack(): boolean;
        getRemainingFireTicks(): number;
        botania_getAmbientSound(): Internal.SoundEvent;
        onlyOpCanSetNbt(): boolean;
        tcdcommons_getCustomData(): Internal.GenericProperties<any>;
        fireImmune(): boolean;
        addMotion($$0: number, $$1: number, $$2: number): void;
        getMaxFallDistance(): number;
        isHolding($$0: Internal.Item_): boolean;
        getZ($$0: number): number;
        static areAllEffectsAmbient($$0: Internal.Collection_<Internal.MobEffectInstance>): boolean;
        doHurtTarget($$0: Internal.Entity_): boolean;
        getTicksFrozen(): number;
        wrapWithCondition$kom000$porting_lib_entity$port_lib$captureDrops(level: Internal.Level_, entity: Internal.Entity_): boolean;
        handler$lef000$puzzleslib$addAdditionalSaveData(compound: Internal.CompoundTag_, callback: Internal.CallbackInfo_): void;
        deflect(chance: number, source: Internal.Entity_): boolean;
        getRandomX($$0: number): number;
        getDynamicLightZ(): number;
        spawnAtLocation($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        pick($$0: number, $$1: number, $$2: boolean): Internal.HitResult;
        getVoicePitch(): number;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        setSleepingPos($$0: BlockPos_): void;
        changeDimension(p_20118_: Internal.ServerLevel_, teleporter: Internal.ITeleporter_): Internal.Entity;
        isDescending(): boolean;
        getAttributeBaseValue($$0: Internal.Attribute_): number;
        emf$getPitch(): number;
        sendEffectToPassengers($$0: Internal.MobEffectInstance_): void;
        getHeadRotSpeed(): number;
        getLastHurtByPlayer(): Internal.Player;
        getYHeadRot(): number;
        handler$cbi000$besmirchment$isTeammate(other: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getProjectile($$0: Internal.ItemStack_): Internal.ItemStack;
        localvar$leb000$puzzleslib$addEffect(oldEffectInstance: Internal.MobEffectInstance_, effectInstance: Internal.MobEffectInstance_, entity: Internal.Entity_): Internal.MobEffectInstance;
        static getAlpha(le: Internal.LivingEntity_, partialTicks: number): number;
        frameworkGetDataHolder(): com.mrcrayfish.framework.entity.sync.DataHolder;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        syncPacketPositionCodec($$0: number, $$1: number, $$2: number): void;
        setAbsorptionAmount($$0: number): void;
        setRecallData(pos: Internal.DimensionalPosition_): void;
        port_lib$spawnItemParticles(arg0: Internal.ItemStack_, arg1: number): void;
        shouldRenderAtSqrDistance($$0: number): boolean;
        getAttachedOrSet<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        damageSources(): Internal.DamageSources;
        removeAttached<A>(type: Internal.AttachmentType_<A>): A;
        removeAllGoals($$0: Internal.Predicate_<Internal.Goal>): void;
        swing(): void;
        recreateFromPacket($$0: Internal.ClientboundAddEntityPacket_): void;
        setDeltaMovement($$0: Vec3d_): void;
        getLeashOffset($$0: number): Vec3d;
        isBaby(): boolean;
        isCulled(): boolean;
        damageEquipment(slot: Internal.EquipmentSlot_): void;
        isGlowing(): boolean;
        getWalkTargetValue($$0: BlockPos_): number;
        canBreatheUnderwater(): boolean;
        getLeashedByEntities(): Internal.Set<any>;
        die($$0: DamageSource_): void;
        etf$getOptifineId(): number;
        removeAllEffects(): boolean;
        dynamicLightWorld(): Internal.Level;
        getLeashOffset(): Vec3d;
        hasLineOfSight($$0: Internal.Entity_): boolean;
        handler$mjn000$supplementaries$supp$addPartyCreeperData(compound: Internal.CompoundTag_, ci: Internal.CallbackInfo_): void;
        hex$getLastHurt(): number;
        onClimbable(): boolean;
        isAttackable(): boolean;
        getSlot($$0: number): Internal.SlotAccess;
        "deserializeNBT(net.minecraft.nbt.CompoundTag)"(nbt: Internal.CompoundTag_): void;
        emf$isInLava(): boolean;
        pehkui_constructScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        stopSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isUnderWater(): boolean;
        stopRiding(): void;
        getLeashHolder(): Internal.Entity;
        getX($$0: number): number;
        getSensing(): Internal.Sensing;
        localvar$kpc000$porting_lib_entity$port_lib$modifyMultiplier(multiplier: number): number;
        getLegsArmorItem(): Internal.ItemStack;
        getLuminance(): number;
        callUnsetRemoved(): void;
        captureDrops(value: Internal.Collection_<Internal.ItemEntity>): Internal.Collection<Internal.ItemEntity>;
        getSelfAndPassengers(): Internal.Stream<any>;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        handler$egi000$collective$LivingEntity_hurt(damageSource: DamageSource_, f: number, ci: Internal.CallbackInfoReturnable_<any>): void;
        getDeltaMovement(): Vec3d;
        canTakeItem($$0: Internal.ItemStack_): boolean;
        shouldDropExperience(): boolean;
        hasPassenger($$0: Internal.Entity_): boolean;
        be_getTravelerState(): Internal.TravelerState;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        getDynamicLightX(): number;
        setSecondsOnFire($$0: number): void;
        moveTo($$0: number, $$1: number, $$2: number): void;
        emf$getZ(): number;
        "getDisplayName()"(): net.minecraft.network.chat.Component;
        getLootTable(): ResourceLocation;
        getTicksUsingItem(): number;
        bettertrims$getWornMaterials(): Internal.List<any>;
        getArrowCount(): number;
        getMoveControl(): Internal.MoveControl;
        setMotion($$0: number, $$1: number, $$2: number): void;
        playSound($$0: Internal.SoundEvent_): void;
        getDefaultMovementSpeed(): number;
        handler$ikg000$lithium$tryShortcutFluidPushing(tag: Internal.TagKey_<any>, speed: number, cir: Internal.CallbackInfoReturnable_<any>, box: Internal.AABB_, x1: number, x2: number, y1: number, y2: number, z1: number, z2: number, zero: number): void;
        handler$hak000$gobber2$setFrozenTicks(frozenTicks: number, ci: Internal.CallbackInfo_): void;
        restoreFrom($$0: Internal.Entity_): void;
        isPeacefulCreature(): boolean;
        setOnGround($$0: boolean): void;
        addEffect($$0: Internal.MobEffectInstance_, $$1: Internal.Entity_): boolean;
        emf$getYaw(): number;
        ate(): void;
        setPos($$0: number, $$1: number, $$2: number): void;
        notify(): void;
        setPersistenceRequired(): void;
        getLastHurtByMobTimestamp(): number;
        getVehicle(): Internal.Entity;
        isEffectiveAi(): boolean;
        handler$kom000$porting_lib_entity$port_lib$startRiding(entity: Internal.Entity_, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        startRiding($$0: Internal.Entity_, $$1: boolean): boolean;
        getStringUuid(): string;
        setSwimming($$0: boolean): void;
        getMainArm(): Internal.HumanoidArm;
        checkSpawnRules($$0: Internal.LevelAccessor_, $$1: Internal.MobSpawnType_): boolean;
        getRotationVector(): Internal.Vec2;
        getHurtDir(): number;
        etf$getBlockY(): number;
        isSprinting(): boolean;
        isMaxGroupSizeReached($$0: number): boolean;
        getMotionY(): number;
        getOffhandItem(): Internal.ItemStack;
        canCollideWith($$0: Internal.Entity_): boolean;
        setLuminance(luminance: number): void;
        getBlockExplosionResistance($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.FluidState_, $$5: number): number;
        setLootTable(arg0: ResourceLocation_): void;
        clearSleepingPos(): void;
        canSpawnSprintParticle(): boolean;
        "moveTo(net.minecraft.core.BlockPos,float,float)"($$0: BlockPos_, $$1: number, $$2: number): void;
        hex$checkTotemDeathProtection(arg0: DamageSource_): boolean;
        getLastHurtMob(): Internal.LivingEntity;
        moveRelative($$0: number, $$1: Vec3d_): void;
        saveAsPassenger($$0: Internal.CompoundTag_): boolean;
        static gatherClosestChunks(chunks: Internal.LongSet_, x: number, y: number, z: number): void;
        handler$kom000$porting_lib_entity$afterSave(nbt: Internal.CompoundTag_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getSoundSource(): Internal.SoundSource;
        getLastDamageSource(): DamageSource;
        setNoActionTime($$0: number): void;
        setMovementSpeedAddition(speed: number): void;
        removeAfterChangingDimensions(): void;
        equipmentHasChanged($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        getPose(): Internal.Pose;
        getAttribute($$0: Internal.Attribute_): Internal.AttributeInstance;
        setPositionAndRotation($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        canBeAffected($$0: Internal.MobEffectInstance_): boolean;
        getRestrictCenter(): BlockPos;
        isLeftHanded(): boolean;
        invokeShouldDropLoot(): boolean;
        handler$kpc000$porting_lib_entity$port_lib$onFinishUsing(ci: Internal.CallbackInfo_, hand: Internal.InteractionHand_, result: Internal.ItemStack_): void;
        etf$getUuid(): Internal.UUID;
        removeVehicle(): void;
        shouldFusionRecomputeModel(layerIndex: number): boolean;
        modifyExpressionValue$zcl000$porting_lib_base$port_lib$canContinueUsing(original: boolean): boolean;
        setZ(z: number): void;
        getY(): number;
        setCurrentFuseTime(arg0: number): void;
        deserializeNBT(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        eat($$0: Internal.Level_, $$1: Internal.ItemStack_): Internal.ItemStack;
        bookshelf$makePoofParticles(): void;
        isWithinMeleeAttackRange($$0: Internal.LivingEntity_): boolean;
        setCurrentModifyFoodPowers(powers: Internal.List_<any>): void;
        static checkMonsterSpawnRules($$0: Internal.EntityType_<Internal.Monster>, $$1: Internal.ServerLevelAccessor_, $$2: Internal.MobSpawnType_, $$3: BlockPos_, $$4: Internal.RandomSource_): boolean;
        broadcastBreakEvent($$0: Internal.EquipmentSlot_): void;
        modifyExpressionValue$zhf000$additionalentityattributes$additionalEntityAttributes$modifyUpwardSwimming(original: number, fluid: Internal.TagKey_<any>): number;
        handler$nbm000$things$onShieldBlock(source: DamageSource_, cir: Internal.CallbackInfoReturnable_<any>): void;
        showVehicleHealth(): boolean;
        getDistance(pos: BlockPos_): number;
        isBlocking(): boolean;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number): void;
        removeAttribute(attribute: Internal.Attribute_, identifier: string): void;
        emf$getVelocity(): Vec3d;
        handler$lef000$puzzleslib$finalizeSpawn(level: Internal.ServerLevelAccessor_, difficulty: Internal.DifficultyInstance_, reason: Internal.MobSpawnType_, spawnData: Internal.SpawnGroupData_, dataTag: Internal.CompoundTag_, callback: Internal.CallbackInfoReturnable_<any>): void;
        etf$isBlockEntity(): boolean;
        shouldUpdateDynamicLight(): boolean;
        isPushedByFluid(): boolean;
        setOriginalFoodStack(original: Internal.ItemStack_): void;
        getArmorCoverPercentage(): number;
        handleRelativeFrictionAndCalculateMovement($$0: Vec3d_, $$1: number): Vec3d;
        turn($$0: number, $$1: number): void;
        getAirSupply(): number;
        moveTo($$0: BlockPos_, $$1: number, $$2: number): void;
        isPlayer(): boolean;
        isAnimal(): boolean;
        "handler$fgd000$fabric-dimensions-v1$getTeleportTarget"(destination: Internal.ServerLevel_, cir: Internal.CallbackInfoReturnable_<any>): void;
        canBeCollidedWith(): boolean;
        getMotionDirection(): Internal.Direction;
        asComponentProvider(): Internal.ComponentProvider;
        lavaHurt(): void;
        handleDamageEvent($$0: DamageSource_): void;
        canDropMobsSkull(): boolean;
        getFabricBalmData(): Internal.CompoundTag;
        canChangeDimensions(): boolean;
        static tickEntity(entity: Internal.Entity_): void;
        getCommandSenderWorld(): Internal.Level;
        getTotalMovementSpeed(): number;
        changeDimension($$0: Internal.ServerLevel_): Internal.Entity;
        localvar$zno000$apoli$modifyFallingVelocity(in_: number): number;
        handler$kom000$porting_lib_entity$afterLoad(nbt: Internal.CompoundTag_, ci: Internal.CallbackInfo_): void;
        pehkui_shouldIgnoreScaleNbt(): boolean;
        isMoving(): boolean;
        attack(hp: number): void;
        getAttributes(): Internal.AttributeMap;
        "hasPassenger(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.Entity>): boolean;
        botania_playHurtSound(arg0: DamageSource_): void;
        getDimensions($$0: Internal.Pose_): Internal.EntityDimensions;
        invokeGetLeashOffset(): Vec3d;
        isSwimming(): boolean;
        setSprinting($$0: boolean): void;
        mayInteract($$0: Internal.Level_, $$1: BlockPos_): boolean;
        handler$kpc000$porting_lib_entity$port_lib$attackEvent(source: DamageSource_, amount: number, cir: Internal.CallbackInfoReturnable_<any>): void;
        getDynamicLightLevel(): Internal.Level;
        setPortalCooldown(): void;
        getAttackAnim($$0: number): number;
        hex$setLastHurt(arg0: number): void;
        setX(x: number): void;
        getPortalWaitTime(): number;
        getBlockStateOn(): Internal.BlockState;
        wantsToPickUp($$0: Internal.ItemStack_): boolean;
        getItemBySlot($$0: Internal.EquipmentSlot_): Internal.ItemStack;
        getFluidHeightLoosely(tag: Internal.TagKey_<any>): number;
        getFluidJumpThreshold(): number;
        getCachedSouls(): number;
        "setPositionAndRotation(double,double,double,float,float)"(x: number, y: number, z: number, yaw: number, pitch: number): void;
        isInvisibleTo($$0: Internal.Player_): boolean;
        stopSleeping(): void;
        setAirSupply($$0: number): void;
        getOnPos(): BlockPos;
        etf$getWorld(): Internal.Level;
        isUndead(): boolean;
        static createLivingAttributes(): Internal.AttributeSupplier$Builder;
        setUseItemRemaining(arg0: number): void;
        pehkui_getScales(): Internal.Map<any, any>;
        getTargetSelector(): Internal.GoalSelector;
        setRegisteredToWorld(navigation: Internal.PathNavigation_): void;
        isSleeping(): boolean;
        stopUsingItem(): void;
        etf$getNbt(): Internal.CompoundTag;
        acceptsFailure(): boolean;
        etf$getBlockPos(): BlockPos;
        pehkui_setShouldIgnoreScaleNbt(ignore: boolean): void;
        setOnGroundWithKnownMovement($$0: boolean, $$1: Vec3d_): void;
        getFluidFallingAdjustedMovement($$0: number, $$1: boolean, $$2: Vec3d_): Vec3d;
        setOldPosAndRot(): void;
        static createMonsterAttributes(): Internal.AttributeSupplier$Builder;
        localvar$cjk000$bettertridents$doHurtTarget$modifyVariable$store(damageAmount: number, entity: Internal.Entity_): number;
        isFree($$0: number, $$1: number, $$2: number): boolean;
        getDismountPoses(): Internal.ImmutableList<Internal.Pose>;
        getLastHurtMobTimestamp(): number;
        lithiumOnEquipmentChanged(): void;
        "moveTo(double,double,double)"($$0: number, $$1: number, $$2: number): void;
        setRemainingFireTicks($$0: number): void;
        emf$age(): number;
        etf$hasCustomName(): boolean;
        /**
         * @deprecated
        */
        getOnPosLegacy(): BlockPos;
        port_lib$isJumping(): boolean;
        setPos($$0: Vec3d_): void;
        localvar$leb000$puzzleslib$knockback$2(ratioX: number): number;
        static "tickEntity(net.minecraft.world.entity.LivingEntity)"(entity: Internal.LivingEntity_): void;
        updateCachedSouls(): void;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        setCanPickUpLoot($$0: boolean): void;
        getMainHandItem(): Internal.ItemStack;
        handler$kom000$porting_lib_entity$port_lib$removeRidingEntity(ci: Internal.CallbackInfo_): void;
        setSilent($$0: boolean): void;
        captureDrops(): Internal.Collection<Internal.ItemEntity>;
        hasExactlyOnePlayerPassenger(): boolean;
        canBeSeenAsEnemy(): boolean;
        setLeftHanded($$0: boolean): void;
        getActiveEffects(): Internal.Collection<Internal.MobEffectInstance>;
        isOnPortalCooldown(): boolean;
        getSwellDir(): number;
        hurtArmor($$0: DamageSource_, $$1: number): void;
        canAttack($$0: Internal.LivingEntity_, $$1: Internal.TargetingConditions_): boolean;
        getAttributeValue($$0: Internal.Holder_<Internal.Attribute>): number;
        lambdynlights$setTrackedLitChunkPos(trackedLitChunkPos: Internal.LongSet_): void;
        fzzy_core_setModifierContainer(container: Internal.ModifierContainer_): void;
        setPitch($$0: number): void;
        setPosRaw($$0: number, $$1: number, $$2: number): void;
        handleEntityEvent($$0: number): void;
        isUsingItem(): boolean;
        isAlwaysTicking(): boolean;
        interactAt($$0: Internal.Player_, $$1: Vec3d_, $$2: Internal.InteractionHand_): Internal.InteractionResult;
        emf$getX(): number;
        puzzleslib$acceptCapturedDrops(capturedDrops: Internal.Collection_<any>): Internal.Collection<any>;
        handler$hak000$gobber2$gobberIsFireImmune(cir: Internal.CallbackInfoReturnable_<any>): void;
        lerpTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: boolean): void;
        onPassengerTurned($$0: Internal.Entity_): void;
        modifyReturnValue$zhe000$additionalentityattributes$getMaxAir(original: number): number;
        spawnAtLocation($$0: Internal.ItemLike_): Internal.ItemEntity;
        emf$hasPassengers(): boolean;
        serializeNBT(): Internal.CompoundTag;
        setAttached(type: Internal.AttachmentType_<any>, value: any): any;
        port_lib$getEntityString(): string;
        markEffectsDirty(): void;
        lithiumOnBlockCacheDeleted(): void;
        "spawnAtLocation(net.minecraft.world.level.ItemLike,int)"($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        setInvulnerable($$0: boolean): void;
        push($$0: Internal.Entity_): void;
        emf$hasVehicle(): boolean;
        maxUpStep(): number;
        getDynamicLightPrevY(): number;
        localvar$leb000$puzzleslib$hurt$1(amount: number, source: DamageSource_): number;
        setGlowing($$0: boolean): void;
        load($$0: Internal.CompoundTag_): void;
        "broadcastBreakEvent(net.minecraft.world.entity.EquipmentSlot)"($$0: Internal.EquipmentSlot_): void;
        setLeashedTo($$0: Internal.Entity_, $$1: boolean): void;
        isAlive(): boolean;
        startSleeping($$0: BlockPos_): void;
        getBbHeight(): number;
        getMeleeAttackRangeSqr($$0: Internal.LivingEntity_): number;
        handler$fed002$extraalchemy$readNbt(tag: Internal.CompoundTag_, cb: Internal.CallbackInfo_): void;
        bookshelf$getDrinkingSound(arg0: Internal.ItemStack_): Internal.SoundEvent;
        getTags(): Internal.Set<string>;
        getViewVector($$0: number): Vec3d;
        getLastAttacker(): Internal.LivingEntity;
        hasControllingPassenger(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number, $$2: number): boolean;
        absMoveTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        getLastRollTicks(): number;
        getGoalSelector(): Internal.GoalSelector;
        localvar$leb000$puzzleslib$causeFallDamage$2(damageMultiplier: number): number;
        onPathfindingStart(): void;
        handler$zzb000$porting_lib_attributes$port_lib$entityGravity(travelVector: Vec3d_, ci: Internal.CallbackInfo_): void;
        getPercentFrozen(): number;
        setPortalCooldown($$0: number): void;
        hasGlowingTag(): boolean;
        shouldBlockExplode($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: number): boolean;
        emf$isInvisible(): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        isLeashed(): boolean;
        addEffect($$0: Internal.MobEffectInstance_): boolean;
        emf$isSprinting(): boolean;
        handler$leb000$puzzleslib$knockback$0(strength: number, ratioX: number, ratioZ: number, callback: Internal.CallbackInfo_): void;
        handler$egi000$collective$LivingEntity_tick(ci: Internal.CallbackInfo_): void;
        handler$gec000$faster_entity_animations$getLeaningPitch(f: number, info: Internal.CallbackInfoReturnable_<any>): void;
        canRiderInteract(): boolean;
        getViewXRot($$0: number): number;
        handler$leb001$puzzleslib$die(damageSource: DamageSource_, callback: Internal.CallbackInfo_): void;
        fabric_getAttachments(): Internal.Map<any, any>;
        setPose($$0: Internal.Pose_): void;
        getReachDistance(): number;
        getEntityType(): Internal.EntityType<any>;
        isWaterCreature(): boolean;
        hex$playHurtSound(arg0: DamageSource_): void;
        pehkui_getScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        toString(): string;
        etf$getScoreboardTeam(): Internal.Team;
        setLastHurtByPlayer($$0: Internal.Player_): void;
        handler$ldh000$puzzleslib$removeVehicle(callback: Internal.CallbackInfo_): void;
        "getServer()"(): Internal.MinecraftServer;
        wasExperienceConsumed(): boolean;
        isPushable(): boolean;
        setYBodyRot($$0: number): void;
        foodEaten(is: Internal.ItemStack_): void;
        onClientRemoval(): void;
        getDistance(x: number, y: number, z: number): number;
        setMotionY(y: number): void;
        static createAttributes(): Internal.AttributeSupplier$Builder;
        getAttached(type: Internal.AttachmentType_<any>): any;
        setRotation(yaw: number, pitch: number): void;
        isDynamicLightEnabled(): boolean;
        handler$ldh000$puzzleslib$startRiding(vehicle: Internal.Entity_, force: boolean, callback: Internal.CallbackInfoReturnable_<any>): void;
        calculateEntityAnimation($$0: boolean): void;
        forceAddEffect($$0: Internal.MobEffectInstance_, $$1: Internal.Entity_): void;
        setChestArmorItem(item: Internal.ItemStack_): void;
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        bookshelf$getHurtSound(arg0: DamageSource_): Internal.SoundEvent;
        onAboveBubbleCol($$0: boolean): void;
        archon$setOwner(uiud: string): void;
        "playSound(net.minecraft.sounds.SoundEvent,float,float)"($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        toComponentPacket(key: Internal.ComponentKey_<any>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        isPassenger(): boolean;
        hasPose($$0: Internal.Pose_): boolean;
        supp$setSlimedTicks(newSlimedTicks: number, sync: boolean): void;
        isEyeInFluid($$0: Internal.TagKey_<Internal.Fluid>): boolean;
        isInvulnerableTo($$0: DamageSource_): boolean;
        makeStuckInBlock($$0: Internal.BlockState_, $$1: Vec3d_): void;
        getAttachedOrGet<A>(type: Internal.AttachmentType_<A>, defaultValue: Internal.Supplier_<A>): A;
        isSensitiveToWater(): boolean;
        skipAttackInteraction($$0: Internal.Entity_): boolean;
        lerpMotion($$0: number, $$1: number, $$2: number): void;
        "getAttributeValue(net.minecraft.core.Holder)"($$0: Internal.Holder_<Internal.Attribute>): number;
        shouldRender($$0: number, $$1: number, $$2: number): boolean;
        getJumpControl(): Internal.JumpControl;
        localvar$zcl000$porting_lib_base$port_lib$setSlipperiness(p: number): number;
        getFeetArmorItem(): Internal.ItemStack;
        handler$bia000$axiom$onTurn(d: number, e: number, ci: Internal.CallbackInfo_): void;
        static getViewScale(): number;
        handler$mpg000$tcdcommons$onAddStatusEffect(effect: Internal.MobEffectInstance_, source: Internal.Entity_, ci: Internal.CallbackInfoReturnable_<any>): void;
        getVisualRotationYInDegrees(): number;
        setSpeed($$0: number): void;
        requiresCustomPersistence(): boolean;
        handler$nbm000$things$onShieldHit(attacker: Internal.LivingEntity_, ci: Internal.CallbackInfo_): void;
        isDiscrete(): boolean;
        unRide(): void;
        getLevel(): Internal.Level;
        "spawnAtLocation(net.minecraft.world.item.ItemStack)"($$0: Internal.ItemStack_): Internal.ItemEntity;
        getCombatTracker(): Internal.CombatTracker;
        updateDynamicGameEventListener($$0: Internal.BiConsumer_<Internal.DynamicGameEventListener<any>, Internal.ServerLevel>): void;
        "onSyncedDataUpdated(net.minecraft.network.syncher.EntityDataAccessor)"($$0: Internal.EntityDataAccessor_<any>): void;
        emf$prevY(): number;
        isNoAi(): boolean;
        extinguishFire(): void;
        getChestArmorItem(): Internal.ItemStack;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number): void;
        port_lib$lastPos(): BlockPos;
        tell(message: net.minecraft.network.chat.Component_): void;
        closerThan($$0: Internal.Entity_, $$1: number): boolean;
        hex$getSoundVolume(): number;
        getDistanceSq(pos: BlockPos_): number;
        indicateDamage($$0: number, $$1: number): void;
        localvar$nbm000$things$waxGlandWater(j: number): number;
        canBeSeenByAnyone(): boolean;
        emf$getTypeString(): string;
        isFullyFrozen(): boolean;
        litematica_setWorld(arg0: Internal.Level_): void;
        isInWall(): boolean;
        getAllSlots(): Internal.Iterable<Internal.ItemStack>;
        handler$bfg003$artifacts$tick(ci: Internal.CallbackInfo_): void;
        remove($$0: Internal.Entity$RemovalReason_): void;
        getScale(): number;
        isSuppressingSlidingDownLadder(): boolean;
        getBlockZ(): number;
        handler$egi000$collective$LivingEntity_die(damageSource: DamageSource_, ci: Internal.CallbackInfo_): void;
        dampensVibrations(): boolean;
        hasAttached(type: Internal.AttachmentType_<any>): boolean;
        isSilent(): boolean;
        setUseItem(arg0: Internal.ItemStack_): void;
        "playSound(net.minecraft.sounds.SoundEvent)"(id: Internal.SoundEvent_): void;
        getPitch(): number;
        getPathfindingMalus($$0: Internal.BlockPathTypes_): number;
        modify$nbm000$things$waxGlandLava(speed: number): number;
        getRandom(): Internal.RandomSource;
        canReplaceEqualItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        rotate($$0: Internal.Rotation_): number;
        handler$hcn000$hexcasting$onThunderHit(entityType: Internal.EntityType_<any>, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        getPassengersAndSelf(): Internal.Stream<any>;
        handler$leb000$puzzleslib$causeFallDamage$0(distance: number, damageMultiplier: number, damageSource: DamageSource_, callback: Internal.CallbackInfoReturnable_<any>): void;
        isIgnited(): boolean;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        "getAttributeBaseValue(net.minecraft.core.Holder)"($$0: Internal.Holder_<Internal.Attribute>): number;
        method_5652($$0: Internal.CompoundTag_): void;
        clearRestriction(): void;
        redirect$jgg000$moonlight$fixSpawnAnimX(instance: Internal.Mob_, v: number): number;
        getOriginalFoodStack(): Internal.ItemStack;
        rayTrace(): Internal.RayTraceResultJS;
        alwaysAccepts(): boolean;
        "isHolding(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.ItemStack>): boolean;
        getNoActionTime(): number;
        isVisuallyCrawling(): boolean;
        isAggressive(): boolean;
        setYya($$0: number): void;
        setDropChance($$0: Internal.EquipmentSlot_, $$1: number): void;
        handler$ieb000$lambdynlights$onRemove(ci: Internal.CallbackInfo_): void;
        "broadcastBreakEvent(net.minecraft.world.InteractionHand)"($$0: Internal.InteractionHand_): void;
        port_lib$setRemovalReason(arg0: Internal.Entity$RemovalReason_): void;
        teleportRelative($$0: number, $$1: number, $$2: number): void;
        setBaby($$0: boolean): void;
        getLastHurtByMob(): Internal.LivingEntity;
        pehkui_setScaleCache(scaleCache: Internal.ScaleData_[]): void;
        isInWaterOrBubble(): boolean;
        getPortalCooldown(): number;
        getItem(): Internal.ItemStack;
        causeFallDamage($$0: number, $$1: number, $$2: DamageSource_): boolean;
        getDynamicLightChunksToRebuild(forced: boolean): Internal.LongSet;
        releaseUsingItem(): void;
        bw_getNextAirOnLand(arg0: number): number;
        getPosition($$0: number): Vec3d;
        removeFreeWill(): void;
        handler$leb000$puzzleslib$removeAllEffects(callback: Internal.CallbackInfoReturnable_<any>): void;
        removeWhenFarAway($$0: number): boolean;
        wait(arg0: number): void;
        isIgnoringBlockTriggers(): boolean;
        setRecordPlayingNearby($$0: BlockPos_, $$1: boolean): void;
        etf$getItemsEquipped(): Internal.Iterable<any>;
        getHandHoldingItemAngle($$0: Internal.Item_): Vec3d;
        hasItemInSlot($$0: Internal.EquipmentSlot_): boolean;
        distanceToSqr($$0: Vec3d_): number;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        modifyAttached<A>(type: Internal.AttachmentType_<A>, modifier: Internal.UnaryOperator_<A>): A;
        isSteppingCarefully(): boolean;
        handler$zno000$apoli$doSpiderClimbing(info: Internal.CallbackInfoReturnable_<any>): void;
        "spawnAtLocation(net.minecraft.world.item.ItemStack,float)"($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        getBlockX(): number;
        /**
         * @deprecated
        */
        getLightLevelDependentMagicValue(): number;
        isFallFlying(): boolean;
        getEncodeId(): string;
        puzzleslib$getSpawnType(): Internal.MobSpawnType;
        bettertrims$setAvoidedDamage(avoidDamage: boolean): void;
        getY($$0: number): number;
        emf$prevPitch(): number;
        getMaxHeadXRot(): number;
        getNbt(): Internal.CompoundTag;
        setInvisible($$0: boolean): void;
        etf$getArmorItems(): Internal.Iterable<any>;
        isSubmergedInLoosely(tag: Internal.TagKey_<any>): boolean;
        getEffect($$0: Internal.MobEffect_): Internal.MobEffectInstance;
        setTotalMovementSpeedMultiplier(speed: number): void;
        getDynamicLightY(): number;
        setHealth($$0: number): void;
        attack($$0: DamageSource_, $$1: number): boolean;
        onInsideBubbleColumn($$0: boolean): void;
        handler$cfa000$betterend$be_hurt(source: DamageSource_, amount: number, info: Internal.CallbackInfoReturnable_<any>): void;
        getEyePosition(): Vec3d;
        getEyeHeight(): number;
        setDiscardFriction($$0: boolean): void;
        hasPassenger($$0: Internal.Predicate_<Internal.Entity>): boolean;
        bettertridents$getLastDamageSource(): DamageSource;
        getYaw(): number;
        swing($$0: Internal.InteractionHand_, $$1: boolean): void;
        getUsedItemHand(): Internal.InteractionHand;
        setDefaultMovementSpeed(speed: number): void;
        canAttackType($$0: Internal.EntityType_<any>): boolean;
        hex$setLastDamageStamp(arg0: number): void;
        canEntityBeSeen(entity: Internal.LivingEntity_): boolean;
        modifyExpressionValue$zhf000$additionalentityattributes$additionalEntityAttributes$knockDownwards(original: number): number;
        getBrain(): Internal.Brain<any>;
        modify$bpk000$bclib$be_travel(moveDelta: Vec3d_): Vec3d;
        setCustomNameVisible($$0: boolean): void;
        isAlliedTo($$0: Internal.Team_): boolean;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>): A;
        canFireProjectileWeapon($$0: Internal.ProjectileWeaponItem_): boolean;
        getControllingPassenger(): Internal.LivingEntity;
        bw_getNextAirUnderwater(arg0: number): number;
        getScriptType(): Internal.ScriptType;
        handler$leb000$puzzleslib$releaseUsingItem(callback: Internal.CallbackInfo_): void;
        handler$cbm000$besmirchment$handleStatus(status: number, ci: Internal.CallbackInfo_): void;
        port_lib$getDeathSound(): Internal.SoundEvent;
        shouldDiscardFriction(): boolean;
        startRiding($$0: Internal.Entity_): boolean;
        saveWithoutId($$0: Internal.CompoundTag_): Internal.CompoundTag;
        getForward(): Vec3d;
        setFeetArmorItem(item: Internal.ItemStack_): void;
        getId(): number;
        pehkui_isFirstUpdate(): boolean;
        canBeHitByProjectile(): boolean;
        getRecipientsForComponentSync(): Internal.Iterable<any>;
        handler$zcl000$porting_lib_base$port_lib$onUsingTick(ci: Internal.CallbackInfo_): void;
        getEyeY(): number;
        handler$ham000$gobber2$gobberClimbing(cir: Internal.CallbackInfoReturnable_<any>): void;
        skipDropExperience(): void;
        fabric_readAttachmentsFromNbt(nbt: Internal.CompoundTag_): void;
        localvar$leb000$puzzleslib$getVisibilityPercent(value: number, lookingEntity: Internal.Entity_): number;
        getBoundingBox(): Internal.AABB;
        isInWaterOrRain(): boolean;
        handler$leb000$puzzleslib$die$1(damageSource: DamageSource_, callback: Internal.CallbackInfo_): void;
        setItemSlot($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_): void;
        equals($$0: any): boolean;
        getViewYRot($$0: number): number;
        fabric_setCustomTeleportTarget(teleportTarget: Internal.PortalInfo_): void;
        dismountsUnderwater(): boolean;
        isAffectedByPotions(): boolean;
        playerTouch($$0: Internal.Player_): void;
        addTag($$0: string): boolean;
        getEyeHeight($$0: Internal.Pose_): number;
        getAddEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>;
        callIsBeingRainedOn(): boolean;
        static getEquipmentForSlot($$0: Internal.EquipmentSlot_, $$1: number): Internal.Item;
        isWithinRestriction($$0: BlockPos_): boolean;
        getTeam(): Internal.Team;
        static of(entity: Internal.LivingEntity_): Internal.EntityProperties;
        setTicksFrozen($$0: number): void;
        getUseItem(): Internal.ItemStack;
        getMyRidingOffset(): number;
        handler$hal000$gobber2$gobberCanBreatheInWater(cir: Internal.CallbackInfoReturnable_<any>): void;
        dismountTo($$0: number, $$1: number, $$2: number): void;
        etf$getEntityKey(): string;
        etf$getPose(): Internal.Pose;
        hasCustomName(): boolean;
        getSwimAmount($$0: number): number;
        isLiving(): boolean;
        getX(): number;
        isVehicle(): boolean;
        static transfer(original: Internal.AttachmentTarget_, target: Internal.AttachmentTarget_, isDeath: boolean): void;
        bettertrims$didAvoidDamage(): boolean;
        resetDynamicLight(): void;
        handler$han000$gobber2$gobberSetTarget(target: Internal.LivingEntity_, ci: Internal.CallbackInfo_): void;
        handler$kpc001$porting_lib_entity$onJump(ci: Internal.CallbackInfo_): void;
        spawnAtLocation($$0: Internal.ItemStack_): Internal.ItemEntity;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        thunderHit($$0: Internal.ServerLevel_, $$1: Internal.LightningBolt_): void;
        handler$zcl000$porting_lib_base$port_lib$canBeAffected(effect: Internal.MobEffectInstance_, cir: Internal.CallbackInfoReturnable_<any>): void;
        setIsInPowderSnow($$0: boolean): void;
        etf$distanceTo(entity: Internal.Entity_): number;
        doEnchantDamageEffects($$0: Internal.LivingEntity_, $$1: Internal.Entity_): void;
        setCustomName($$0: net.minecraft.network.chat.Component_): void;
        lambdynlights$scheduleTrackedChunksRebuild(renderer: Internal.LevelRenderer_): void;
        handler$hak000$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        getTeamId(): string;
        setStingerCount($$0: number): void;
        getMaxHeadYRot(): number;
        isCustomNameVisible(): boolean;
        isSupportedBy($$0: BlockPos_): boolean;
        getPistonPushReaction(): Internal.PushReaction;
        lookAt($$0: Internal.EntityAnchorArgument$Anchor_, $$1: Vec3d_): void;
        handler$kpc000$porting_lib_entity$port_lib$cancelFall(fallDistance: number, multiplier: number, source: DamageSource_, cir: Internal.CallbackInfoReturnable_<any>): void;
        hurtCurrentlyUsedShield($$0: number): void;
        getLootTableSeed(): number;
        collide($$0: Vec3d_): Vec3d;
        getMotionX(): number;
        "onSyncedDataUpdated(java.util.List)"($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        canBeLeashed($$0: Internal.Player_): boolean;
        hasIndirectPassenger($$0: Internal.Entity_): boolean;
        gear_core_setActiveSets(sets: Internal.HashMap_<any, any>): void;
        getEntityData(): Internal.SynchedEntityData;
        bookshelf$getFallDamageSound(arg0: number): Internal.SoundEvent;
        handleInsidePortal($$0: BlockPos_): void;
        getPotionEffects(): Internal.EntityPotionEffectsJS;
        getLastHurtByPlayerTime(): number;
        absMoveTo($$0: number, $$1: number, $$2: number): void;
        handler$cfa000$betterend$be_canBeAffected(mobEffectInstance: Internal.MobEffectInstance_, info: Internal.CallbackInfoReturnable_<any>): void;
        isOnRails(): boolean;
        getAttachedOrThrow<A>(type: Internal.AttachmentType_<A>): A;
        getStingerCount(): number;
        markFusionRecomputeModels(): void;
        getFallSounds(): Internal.LivingEntity$Fallsounds;
        getAttributeTotalValue(attribute: Internal.Attribute_): number;
        getDimensionChangingDelay(): number;
        handler$cbi000$besmirchment$getScoreboardTeam(cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDynamicLuminance(): number;
        setYaw($$0: number): void;
        getPickRadius(): number;
        isPathFinding(): boolean;
        supp$getSlimedTicks(): number;
        isRemoved(): boolean;
        emf$isSneaking(): boolean;
        teleportToWithTicket($$0: number, $$1: number, $$2: number): void;
        setSwellDir($$0: number): void;
        spawnAnim(): void;
        getJumpBoostPower(): number;
        fillCrashReportCategory($$0: Internal.CrashReportCategory_): void;
        self(): Internal.Entity;
        refreshDimensions(): void;
        pehkui_writeScaleNbt(nbt: Internal.CompoundTag_): Internal.CompoundTag;
        bookshelf$getAmbientSound(): Internal.SoundEvent;
        "spawnAtLocation(net.minecraft.world.level.ItemLike)"($$0: Internal.ItemLike_): Internal.ItemEntity;
        "isHolding(net.minecraft.world.item.Item)"($$0: Internal.Item_): boolean;
        "getAttributeValue(net.minecraft.world.entity.ai.attributes.Attribute)"($$0: Internal.Attribute_): number;
        setShiftKeyDown($$0: boolean): void;
        getEyePosition($$0: number): Vec3d;
        getPassengers(): Internal.EntityArrayList;
        handler$ldh000$puzzleslib$spawnAtLocation(stack: Internal.ItemStack_, offsetY: number, callback: Internal.CallbackInfoReturnable_<any>, itemEntity: Internal.ItemEntity_): void;
        getZ(): number;
        bettertrims$applyCelestialToAttackCooldown(original: number): number;
        teleportTo($$0: number, $$1: number, $$2: number): void;
        handler$zbk000$porting_lib_base$port_lib$spawnSprintParticle(ci: Internal.CallbackInfo_, pos: BlockPos_, state: Internal.BlockState_): void;
        getAttributeBaseValue($$0: Internal.Holder_<Internal.Attribute>): number;
        getServer(): Internal.MinecraftServer;
        getExperienceReward(): number;
        getFirstPassenger(): Internal.Entity;
        heal($$0: number): void;
        handler$leb01a$puzzleslib$tick(callback: Internal.CallbackInfo_): void;
        setLastHurtMob($$0: Internal.Entity_): void;
        setLastHurtByMob($$0: Internal.LivingEntity_): void;
        interact($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        getDismountLocationForPassenger($$0: Internal.LivingEntity_): Vec3d;
        checkSlowFallDistance(): void;
        getLeashingEntities(): Internal.Set<any>;
        canStandOnFluid($$0: Internal.FluidState_): boolean;
        setFabricBalmData(tag: Internal.CompoundTag_): void;
        touchingUnloadedChunk(): boolean;
        modifyAttribute(attribute: Internal.Attribute_, identifier: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getLookAngle(): Vec3d;
        modifyReturnValue$zhf000$additionalentityattributes$additionalEntityAttributes$modifyJumpVelocity(original: number): number;
        getAmbientSoundInterval(): number;
        emf$isOnFire(): boolean;
        setArrowCount($$0: number): void;
        getMotionZ(): number;
        isPersistenceRequired(): boolean;
        isInvisible(): boolean;
        is($$0: Internal.Entity_): boolean;
        getBedOrientation(): Internal.Direction;
        ejectPassengers(): void;
        removeEffect($$0: Internal.MobEffect_): boolean;
        updateDynamicLightPreviousCoordinates(): void;
        getProfile(): Internal.GameProfile;
        isDeadOrDying(): boolean;
        setHeadArmorItem(item: Internal.ItemStack_): void;
        static setViewScale($$0: number): void;
        emf$isAlive(): boolean;
        take($$0: Internal.Entity_, $$1: number): void;
        setLevelCallback($$0: Internal.EntityInLevelCallback_): void;
        getLookControl(): Internal.LookControl;
        isPreventingPlayerRest($$0: Internal.Player_): boolean;
        redirect$joh000$origins$method_26317Proxy(entity: Internal.LivingEntity_, d: number, bl: boolean, vec3d: Vec3d_): Vec3d;
        playSound($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        canAttack($$0: Internal.LivingEntity_): boolean;
        getOffHandItem(): Internal.ItemStack;
        startSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isOnScoreboardTeam(teamId: string): boolean;
        startUsingItem($$0: Internal.InteractionHand_): void;
        invokePlayEquipmentBreakEffects(arg0: Internal.ItemStack_): void;
        localvar$bbb000$architectury$modifyLevelCallback_setLevelCallback(callback: Internal.EntityInLevelCallback_): Internal.EntityInLevelCallback;
        position(): Vec3d;
        setTimeout(): void;
        static getEquipmentSlotForItem($$0: Internal.ItemStack_): Internal.EquipmentSlot;
        getEquipment(slot: Internal.EquipmentSlot_): Internal.ItemStack;
        displayFireAnimation(): boolean;
        isOutOfCamera(): boolean;
        handler$mjn000$supplementaries$supp$readPartyCreeperData(compound: Internal.CompoundTag_, ci: Internal.CallbackInfo_): void;
        getRopeHoldPosition($$0: number): Vec3d;
        copyPosition($$0: Internal.Entity_): void;
        "hasPassenger(net.minecraft.world.entity.Entity)"($$0: Internal.Entity_): boolean;
        extraalchemy_spawnParticles(arg0: Internal.ItemStack_, arg1: number): void;
        etf$canBeBright(): boolean;
        isCrouching(): boolean;
        "getAttributeBaseValue(net.minecraft.world.entity.ai.attributes.Attribute)"(attribute: Internal.Attribute_): number;
        onLeaveCombat(): void;
        wrapOperation$bgd000$artifacts$travel(block: Internal.Block_, original: Internal.Operation_<any>): number;
        setY(y: number): void;
        getAttributeValue($$0: Internal.Attribute_): number;
        getFeetBlockState(): Internal.BlockState;
        archon$isOwner(player: Internal.Player_): boolean;
        isWithinRestriction(): boolean;
        getChangeListener(): Internal.EntityInLevelCallback;
        positionRider($$0: Internal.Entity_): void;
        baseTick(): void;
        broadcastToPlayer($$0: Internal.ServerPlayer_): boolean;
        setSharedFlag($$0: number, $$1: boolean): void;
        getSleepingPos(): Optional<BlockPos>;
        damageHeldItem(): void;
        getCustomName(): net.minecraft.network.chat.Component;
        getClass(): typeof any;
        isVisuallySwimming(): boolean;
        getMaxAirSupply(): number;
        handler$zcl000$porting_lib_base$port_lib$addEffect(newEffect: Internal.MobEffectInstance_, source: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>, oldEffect: Internal.MobEffectInstance_): void;
        setItemInHand($$0: Internal.InteractionHand_, $$1: Internal.ItemStack_): void;
        dynamicLightTick(): void;
        setMaxHealth(hp: number): void;
        getFacing(): Internal.Direction;
        emf$isWet(): boolean;
        isPassengerOfSameVehicle($$0: Internal.Entity_): boolean;
        getBoundingBoxForCulling(): Internal.AABB;
        getTarget(): Internal.LivingEntity;
        static collideBoundingBox(entity: Internal.Entity_, movement: Vec3d_, entityBoundingBox: Internal.AABB_, world: Internal.Level_, collisions: Internal.List_<any>): Vec3d;
        fzzy_core_getModifierContainer(): Internal.ModifierContainer;
        restrictTo($$0: BlockPos_, $$1: number): void;
        trackingPosition(): Vec3d;
        getNameTagOffsetY(): number;
        isInvulnerable(): boolean;
        isInLava(): boolean;
        isInWater(): boolean;
        awardKillScore($$0: Internal.Entity_, $$1: number, $$2: DamageSource_): void;
        finalizeSpawn($$0: Internal.ServerLevelAccessor_, $$1: Internal.DifficultyInstance_, $$2: Internal.MobSpawnType_, $$3: Internal.SpawnGroupData_, $$4: Internal.CompoundTag_): Internal.SpawnGroupData;
        localvar$leb000$puzzleslib$knockback$3(ratioZ: number): number;
        supplementaries$setFestive(festive: boolean): void;
        unsetRemoved(): void;
        pehkui_getScaleCache(): Internal.ScaleData[];
        swing($$0: Internal.InteractionHand_): void;
        hasEffect($$0: Internal.MobEffect_): boolean;
        getHeldItem(hand: Internal.InteractionHand_): Internal.ItemStack;
        setFusionModel(layerIndex: number, model: Internal.Triple_<any, any, any>): void;
        getRootVehicle(): Internal.Entity;
        onPathfindingDone(): void;
        save($$0: Internal.CompoundTag_): boolean;
        archon$setLifetime(seconds: number): void;
        modify$zhf000$additionalentityattributes$additionalEntityAttributes$waterSpeed(original: number): number;
        getLocalBoundsForPose($$0: Internal.Pose_): Internal.AABB;
        isNoGravity(): boolean;
        dodge(chance: number): boolean;
        onItemPickup($$0: Internal.ItemEntity_): void;
        hex$setLastDamageSource(arg0: DamageSource_): void;
        isPowered(): boolean;
        emf$getY(): number;
        handler$kom000$porting_lib_entity$port_lib$entityInit(entityType: Internal.EntityType_<any>, world: Internal.Level_, ci: Internal.CallbackInfo_): void;
        bookshelf$createHoverEvent(): Internal.HoverEvent;
        updateSwimming(): void;
        isHolding($$0: Internal.Predicate_<Internal.ItemStack>): boolean;
        getSpeed(): number;
        abstract getCachedFeetBlockState(): Internal.BlockState;
        shouldInformAdmins(): boolean;
        rideTick(): void;
        port_lib$onEffectRemoved(arg0: Internal.MobEffectInstance_): void;
        handler$zll000$amethyst_imbuement$onAttackWhilstStunnedNoTarget(hand: Internal.InteractionHand_, ci: Internal.CallbackInfo_): void;
        wait(): void;
        getUuid(): Internal.UUID;
        setOffHandItem(item: Internal.ItemStack_): void;
        spawn(): void;
        setNoAi($$0: boolean): void;
        teleportTo($$0: Internal.ServerLevel_, $$1: number, $$2: number, $$3: number, $$4: Internal.Set_<Internal.RelativeMovement>, $$5: number, $$6: number): boolean;
        etf$getCustomName(): net.minecraft.network.chat.Component;
        fabric_writeAttachmentsToNbt(nbt: Internal.CompoundTag_): void;
        shouldShowName(): boolean;
        getArmorSlots(): Internal.Iterable<Internal.ItemStack>;
        canPickUpLoot(): boolean;
        kill(): void;
        onEnterCombat(): void;
        updateNavigationRegistration(): void;
        animateHurt($$0: number): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        handler$kom000$porting_lib_entity$port_lib$onEntityRemove(reason: Internal.Entity$RemovalReason_, ci: Internal.CallbackInfo_): void;
        static resetForwardDirectionOfRelativePortalPosition($$0: Vec3d_): Vec3d;
        callGetEyeHeight(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        hasRestriction(): boolean;
        getHeadArmorItem(): Internal.ItemStack;
        ignite(): void;
        deserializeNBT(arg0: Internal.Tag_): void;
        getCurrentModifyFoodPowers(): Internal.List<any>;
        getBbWidth(): number;
        splitIntoDynamicLightEntries(): Internal.Stream<Internal.SpatialLookupEntry>;
        static checkAnyLightMonsterSpawnRules($$0: Internal.EntityType_<Internal.Monster>, $$1: Internal.LevelAccessor_, $$2: Internal.MobSpawnType_, $$3: BlockPos_, $$4: Internal.RandomSource_): boolean;
        wrapWithCondition$mjn000$supplementaries$supp$checkPartyCreeper(instance: Internal.Level_, source: Internal.Entity_, x: number, y: number, z: number, radius: number, explosionInteraction: Internal.Level$ExplosionInteraction_): boolean;
        addDeltaMovement($$0: Vec3d_): void;
        pehkui_setOnGround(onGround: boolean): void;
        localvar$leb000$puzzleslib$knockback$1(strength: number): number;
        bettertrims$addLateAttributes(adder: Internal.Consumer_<any>): void;
        handler$lef000$puzzleslib$readAdditionalSaveData(compound: Internal.CompoundTag_, callback: Internal.CallbackInfo_): void;
        sendLeashState(): void;
        "getName()"(): net.minecraft.network.chat.Component;
        mirror($$0: Internal.Mirror_): number;
        static port_lib$collideWithShapes(vec3: Vec3d_, aABB: Internal.AABB_, list: Internal.List_<Internal.VoxelShape>): Vec3d;
        knockback($$0: number, $$1: number, $$2: number): void;
        getTicksRequiredToFreeze(): number;
        getVisibilityPercent($$0: Internal.Entity_): number;
        getMaxSpawnClusterSize(): number;
        localvar$kpc000$porting_lib_entity$port_lib$modifyDistance(fallDistance: number): number;
        artifacts$getPocketPistonLength(): number;
        emf$prevZ(): number;
        getUsername(): string;
        move($$0: Internal.MoverType_, $$1: Vec3d_): void;
        getSwelling($$0: number): number;
        lithiumOnBlockCacheSet(newState: Internal.BlockState_): void;
        isPickable(): boolean;
        setYHeadRot($$0: number): void;
        setJumping($$0: boolean): void;
        getCustomData(): Internal.CompoundTag;
        handler$zno000$apoli$getGroup(info: Internal.CallbackInfoReturnable_<any>): void;
        getPickResult(): Internal.ItemStack;
        "getMainHandItem()"(): Internal.ItemStack;
        getAbsorptionAmount(): number;
        getRandomY(): number;
        onEffectRemoved($$0: Internal.MobEffectInstance_): void;
        getDisplayName(): net.minecraft.network.chat.Component;
        static "tickEntity(net.minecraft.world.entity.Entity)"(entity: Internal.Entity_): void;
        getMobType(): Internal.MobType;
        travel($$0: Vec3d_): void;
        getItemInHand($$0: Internal.InteractionHand_): Internal.ItemStack;
        localvar$leb000$puzzleslib$hurt$0(amount: number, source: DamageSource_): number;
        getDynamicLightPrevX(): number;
        shouldBeSaved(): boolean;
        fabric_hasPersistentAttachments(): boolean;
        method_5749($$0: Internal.CompoundTag_): void;
        hurtHelmet($$0: DamageSource_, $$1: number): void;
        removeTag($$0: string): boolean;
        isHoldingInAnyHand(i: Internal.Ingredient_): boolean;
        getFluidHeight($$0: Internal.TagKey_<Internal.Fluid>): number;
        canSpawnSoulSpeedParticle(): boolean;
        notifyAll(): void;
        aiStep(): void;
        handler$leb000$puzzleslib$removeEffect(effect: Internal.MobEffect_, callback: Internal.CallbackInfoReturnable_<any>): void;
        getPassengersRidingOffset(): number;
        setAttributeBaseValue(attribute: Internal.Attribute_, value: number): void;
        distanceToEntitySqr($$0: Internal.Entity_): number;
        isFrame(): boolean;
        broadcastBreakEvent($$0: Internal.InteractionHand_): void;
        setLegsArmorItem(item: Internal.ItemStack_): void;
        localvar$leb000$puzzleslib$causeFallDamage$1(fallDistance: number): number;
        discard(): void;
        "handler$mhe000$step-height-entity-attribute$getStepHeight"(cir: Internal.CallbackInfoReturnable_<any>): void;
        sendSystemMessage($$0: net.minecraft.network.chat.Component_): void;
        acceptsSuccess(): boolean;
        static tickEntity(entity: Internal.LivingEntity_): void;
        setNoGravity($$0: boolean): void;
        getUseItemRemainingTicks(): number;
        gear_core_getActiveSets(): Internal.HashMap<any, any>;
        getIndirectPassengers(): Internal.Iterable<any>;
        attackable(): boolean;
        createCommandSourceStack(): Internal.CommandSourceStack;
        getNavigation(): Internal.PathNavigation;
        isControlledByLocalInstance(): boolean;
        isMonster(): boolean;
        pehkui_setShouldSyncScales(sync: boolean): void;
        handler$cbm000$besmirchment$canTarget(type: Internal.EntityType_<any>, cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastClimbablePos(): Optional<BlockPos>;
        getEatingSound($$0: Internal.ItemStack_): Internal.SoundEvent;
        setLastDynamicLuminance(luminance: number): void;
        getPerceivedTargetDistanceSquareForMeleeAttack($$0: Internal.LivingEntity_): number;
        setId($$0: number): void;
        onSyncedDataUpdated($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        getHorizontalFacing(): Internal.Direction;
        getType(): string;
        isDamageSourceBlocked($$0: DamageSource_): boolean;
        getLightProbePosition($$0: number): Vec3d;
        getActiveEffectsMap(): Internal.Map<Internal.MobEffect, Internal.MobEffectInstance>;
        wrapOperation$mac000$smarterfarmers$smarterFarmers$overrideMobGriefing(instance: Internal.GameRules_, key: Internal.GameRules$Key_<any>, original: Internal.Operation_<any>): boolean;
        emf$prevX(): number;
        onEquipItem($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_, $$2: Internal.ItemStack_): void;
        static isDarkEnoughToSpawn($$0: Internal.ServerLevelAccessor_, $$1: BlockPos_, $$2: Internal.RandomSource_): boolean;
        checkDespawn(): void;
        pehkui_shouldSyncScales(): boolean;
        getWalkTargetValue($$0: BlockPos_, $$1: Internal.LevelReader_): number;
        lookAt($$0: Internal.Entity_, $$1: number, $$2: number): void;
        setHeldItem(hand: Internal.InteractionHand_, item: Internal.ItemStack_): void;
        port_lib$maybeDisableShield(arg0: Internal.Player_, arg1: Internal.ItemStack_, arg2: Internal.ItemStack_): void;
        equipItemIfPossible($$0: Internal.ItemStack_): Internal.ItemStack;
        onSyncedDataUpdated($$0: Internal.EntityDataAccessor_<any>): void;
        lerpHeadTo($$0: number, $$1: number): void;
        canDisableShield(): boolean;
        setMotionX(x: number): void;
        getHandSlots(): Internal.Iterable<Internal.ItemStack>;
        distanceToEntity($$0: Internal.Entity_): number;
        bookshelf$getDeathSound(): Internal.SoundEvent;
        wait(arg0: number, arg1: number): void;
        getTeamColor(): number;
        lithiumSetClimbingMobCachingSectionUpdateBehavior(listenForCachedBlockChanges: boolean): void;
        setNbt(nbt: Internal.CompoundTag_): void;
        lambdynlights$getTrackedLitChunkPos(): Internal.LongSet;
        checkSpawnObstruction($$0: Internal.LevelReader_): boolean;
        getRecallPosition(): Internal.DimensionalPosition;
        extinguish(): void;
        setDynamicLightEnabled(enabled: boolean): void;
        getRestrictRadius(): number;
        moveTo($$0: Vec3d_): void;
        isColliding($$0: BlockPos_, $$1: Internal.BlockState_): boolean;
        "swing(net.minecraft.world.InteractionHand)"($$0: Internal.InteractionHand_): void;
        lambdynlights$updateDynamicLight(renderer: Internal.LevelRenderer_): boolean;
        getRegisteredNavigation(): Internal.PathNavigation;
        bettertrims$isWearing(effect: Internal.TrimEffect_): boolean;
        static port_lib$collideWithShapes$porting_lib_accessors_$md$424943$0(arg0: Vec3d_, arg1: Internal.AABB_, arg2: Internal.List_<any>): Vec3d;
        isForcedVisible(): boolean;
        isInvertedHealAndHarm(): boolean;
        handler$jon000$origins$doWaterBreathing(info: Internal.CallbackInfoReturnable_<any>): void;
        canHoldItem($$0: Internal.ItemStack_): boolean;
        killedEntity($$0: Internal.ServerLevel_, $$1: Internal.LivingEntity_): boolean;
        getAttachedOrElse<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        isFreezing(): boolean;
        runCommand(command: string): number;
        hex$getDeathSound(): Internal.SoundEvent;
        setGuaranteedDrop($$0: Internal.EquipmentSlot_): void;
        setSharedFlagOnFire($$0: boolean): void;
        set defaultMovementSpeedMultiplier(speed: number)
        get suppressingBounce(): boolean
        set target($$0: Internal.LivingEntity_)
        set culled(value: boolean)
        get onFire(): boolean
        get positionCodec(): Internal.VecDeltaCodec
        set maxUpStep($$0: number)
        get fallFlyingTicks(): number
        set xxa($$0: number)
        set delayedLeashHolderId($$0: number)
        get shiftKeyDown(): boolean
        set UUID($$0: Internal.UUID_)
        set motionZ(z: number)
        get blockY(): number
        get isInsideStructureTracker(): Internal.IsInsideStructureTracker
        set playerHitTimer(arg0: number)
        get spectator(): boolean
        set mainHandItem(item: Internal.ItemStack_)
        get persistentData(): Internal.CompoundTag
        get health(): number
        get maxHealth(): number
        get registeredToWorld(): boolean
        set aggressive($$0: boolean)
        set removed($$0: Internal.Entity$RemovalReason_)
        get inWaterRainOrBubble(): boolean
        get removalReason(): Internal.Entity$RemovalReason
        set boundingBox($$0: Internal.AABB_)
        get ambientCreature(): boolean
        set zza($$0: number)
        get block(): Internal.BlockContainerJS
        get name(): net.minecraft.network.chat.Component
        get controlledVehicle(): Internal.Entity
        get armorValue(): number
        get killCredit(): Internal.LivingEntity
        get componentContainer(): Internal.ComponentContainer
        get dynamicLightPrevZ(): number
        set outOfCamera(value: boolean)
        get autoSpinAttack(): boolean
        get remainingFireTicks(): number
        get maxFallDistance(): number
        get ticksFrozen(): number
        get dynamicLightZ(): number
        get voicePitch(): number
        set statusMessage(message: net.minecraft.network.chat.Component_)
        set sleepingPos($$0: BlockPos_)
        get descending(): boolean
        get headRotSpeed(): number
        get lastHurtByPlayer(): Internal.Player
        get YHeadRot(): number
        set absorptionAmount($$0: number)
        set recallData(pos: Internal.DimensionalPosition_)
        set deltaMovement($$0: Vec3d_)
        get baby(): boolean
        get culled(): boolean
        get glowing(): boolean
        get leashedByEntities(): Internal.Set<any>
        get leashOffset(): Vec3d
        get attackable(): boolean
        get underWater(): boolean
        get leashHolder(): Internal.Entity
        get sensing(): Internal.Sensing
        get legsArmorItem(): Internal.ItemStack
        get luminance(): number
        get selfAndPassengers(): Internal.Stream<any>
        get deltaMovement(): Vec3d
        get dynamicLightX(): number
        set secondsOnFire($$0: number)
        get "displayName()"(): net.minecraft.network.chat.Component
        get lootTable(): ResourceLocation
        get ticksUsingItem(): number
        get arrowCount(): number
        get moveControl(): Internal.MoveControl
        get defaultMovementSpeed(): number
        get peacefulCreature(): boolean
        set onGround($$0: boolean)
        get lastHurtByMobTimestamp(): number
        get vehicle(): Internal.Entity
        get effectiveAi(): boolean
        get stringUuid(): string
        set swimming($$0: boolean)
        get mainArm(): Internal.HumanoidArm
        get rotationVector(): Internal.Vec2
        get hurtDir(): number
        get sprinting(): boolean
        get motionY(): number
        get offhandItem(): Internal.ItemStack
        set luminance(luminance: number)
        set lootTable(arg0: ResourceLocation_)
        get lastHurtMob(): Internal.LivingEntity
        get soundSource(): Internal.SoundSource
        get lastDamageSource(): DamageSource
        set noActionTime($$0: number)
        set movementSpeedAddition(speed: number)
        get pose(): Internal.Pose
        get restrictCenter(): BlockPos
        get leftHanded(): boolean
        set z(z: number)
        get y(): number
        set currentFuseTime(arg0: number)
        set currentModifyFoodPowers(powers: Internal.List_<any>)
        get blocking(): boolean
        get pushedByFluid(): boolean
        set originalFoodStack(original: Internal.ItemStack_)
        get armorCoverPercentage(): number
        get airSupply(): number
        get player(): boolean
        get animal(): boolean
        get motionDirection(): Internal.Direction
        get fabricBalmData(): Internal.CompoundTag
        get commandSenderWorld(): Internal.Level
        get totalMovementSpeed(): number
        get moving(): boolean
        get attributes(): Internal.AttributeMap
        get swimming(): boolean
        set sprinting($$0: boolean)
        get dynamicLightLevel(): Internal.Level
        set x(x: number)
        get portalWaitTime(): number
        get blockStateOn(): Internal.BlockState
        get fluidJumpThreshold(): number
        get cachedSouls(): number
        set airSupply($$0: number)
        get onPos(): BlockPos
        get undead(): boolean
        set useItemRemaining(arg0: number)
        get targetSelector(): Internal.GoalSelector
        set registeredToWorld(navigation: Internal.PathNavigation_)
        get sleeping(): boolean
        get dismountPoses(): Internal.ImmutableList<Internal.Pose>
        get lastHurtMobTimestamp(): number
        set remainingFireTicks($$0: number)
        /**
         * @deprecated
        */
        get onPosLegacy(): BlockPos
        set pos($$0: Vec3d_)
        set canPickUpLoot($$0: boolean)
        get mainHandItem(): Internal.ItemStack
        set silent($$0: boolean)
        set leftHanded($$0: boolean)
        get activeEffects(): Internal.Collection<Internal.MobEffectInstance>
        get onPortalCooldown(): boolean
        get swellDir(): number
        set pitch($$0: number)
        get usingItem(): boolean
        get alwaysTicking(): boolean
        set invulnerable($$0: boolean)
        get dynamicLightPrevY(): number
        set glowing($$0: boolean)
        get alive(): boolean
        get bbHeight(): number
        get tags(): Internal.Set<string>
        get lastAttacker(): Internal.LivingEntity
        get lastRollTicks(): number
        get goalSelector(): Internal.GoalSelector
        get percentFrozen(): number
        set portalCooldown($$0: number)
        set position(block: Internal.BlockContainerJS_)
        get leashed(): boolean
        set pose($$0: Internal.Pose_)
        get reachDistance(): number
        get entityType(): Internal.EntityType<any>
        get waterCreature(): boolean
        set lastHurtByPlayer($$0: Internal.Player_)
        get "server()"(): Internal.MinecraftServer
        get pushable(): boolean
        set YBodyRot($$0: number)
        set motionY(y: number)
        get dynamicLightEnabled(): boolean
        set chestArmorItem(item: Internal.ItemStack_)
        get passenger(): boolean
        get sensitiveToWater(): boolean
        get jumpControl(): Internal.JumpControl
        get feetArmorItem(): Internal.ItemStack
        get viewScale(): number
        get visualRotationYInDegrees(): number
        set speed($$0: number)
        get discrete(): boolean
        get level(): Internal.Level
        get combatTracker(): Internal.CombatTracker
        get noAi(): boolean
        get chestArmorItem(): Internal.ItemStack
        get fullyFrozen(): boolean
        get inWall(): boolean
        get allSlots(): Internal.Iterable<Internal.ItemStack>
        get scale(): number
        get suppressingSlidingDownLadder(): boolean
        get blockZ(): number
        get silent(): boolean
        set useItem(arg0: Internal.ItemStack_)
        get pitch(): number
        get random(): Internal.RandomSource
        get passengersAndSelf(): Internal.Stream<any>
        get ignited(): boolean
        get originalFoodStack(): Internal.ItemStack
        get noActionTime(): number
        get visuallyCrawling(): boolean
        get aggressive(): boolean
        set yya($$0: number)
        set baby($$0: boolean)
        get lastHurtByMob(): Internal.LivingEntity
        get inWaterOrBubble(): boolean
        get portalCooldown(): number
        get item(): Internal.ItemStack
        get ignoringBlockTriggers(): boolean
        get steppingCarefully(): boolean
        get blockX(): number
        /**
         * @deprecated
        */
        get lightLevelDependentMagicValue(): number
        get fallFlying(): boolean
        get encodeId(): string
        get maxHeadXRot(): number
        get nbt(): Internal.CompoundTag
        set invisible($$0: boolean)
        set totalMovementSpeedMultiplier(speed: number)
        get dynamicLightY(): number
        set health($$0: number)
        get eyePosition(): Vec3d
        get eyeHeight(): number
        set discardFriction($$0: boolean)
        get yaw(): number
        get usedItemHand(): Internal.InteractionHand
        set defaultMovementSpeed(speed: number)
        get brain(): Internal.Brain<any>
        set customNameVisible($$0: boolean)
        get controllingPassenger(): Internal.LivingEntity
        get scriptType(): Internal.ScriptType
        get forward(): Vec3d
        set feetArmorItem(item: Internal.ItemStack_)
        get id(): number
        get recipientsForComponentSync(): Internal.Iterable<any>
        get eyeY(): number
        get boundingBox(): Internal.AABB
        get inWaterOrRain(): boolean
        get affectedByPotions(): boolean
        get addEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>
        get team(): Internal.Team
        set ticksFrozen($$0: number)
        get useItem(): Internal.ItemStack
        get myRidingOffset(): number
        get living(): boolean
        get x(): number
        get vehicle(): boolean
        set isInPowderSnow($$0: boolean)
        set customName($$0: net.minecraft.network.chat.Component_)
        get teamId(): string
        set stingerCount($$0: number)
        get maxHeadYRot(): number
        get customNameVisible(): boolean
        get pistonPushReaction(): Internal.PushReaction
        get lootTableSeed(): number
        get motionX(): number
        get entityData(): Internal.SynchedEntityData
        get potionEffects(): Internal.EntityPotionEffectsJS
        get lastHurtByPlayerTime(): number
        get onRails(): boolean
        get stingerCount(): number
        get fallSounds(): Internal.LivingEntity$Fallsounds
        get dimensionChangingDelay(): number
        get lastDynamicLuminance(): number
        set yaw($$0: number)
        get pickRadius(): number
        get pathFinding(): boolean
        get removed(): boolean
        set swellDir($$0: number)
        get jumpBoostPower(): number
        set shiftKeyDown($$0: boolean)
        get passengers(): Internal.EntityArrayList
        get z(): number
        get server(): Internal.MinecraftServer
        get experienceReward(): number
        get firstPassenger(): Internal.Entity
        set lastHurtMob($$0: Internal.Entity_)
        set lastHurtByMob($$0: Internal.LivingEntity_)
        get leashingEntities(): Internal.Set<any>
        set fabricBalmData(tag: Internal.CompoundTag_)
        get lookAngle(): Vec3d
        get ambientSoundInterval(): number
        set arrowCount($$0: number)
        get motionZ(): number
        get persistenceRequired(): boolean
        get invisible(): boolean
        get bedOrientation(): Internal.Direction
        get profile(): Internal.GameProfile
        get deadOrDying(): boolean
        set headArmorItem(item: Internal.ItemStack_)
        set viewScale($$0: number)
        set levelCallback($$0: Internal.EntityInLevelCallback_)
        get lookControl(): Internal.LookControl
        get offHandItem(): Internal.ItemStack
        get outOfCamera(): boolean
        get crouching(): boolean
        set y(y: number)
        get feetBlockState(): Internal.BlockState
        get withinRestriction(): boolean
        get changeListener(): Internal.EntityInLevelCallback
        get sleepingPos(): Optional<BlockPos>
        get customName(): net.minecraft.network.chat.Component
        get class(): typeof any
        get visuallySwimming(): boolean
        get maxAirSupply(): number
        set maxHealth(hp: number)
        get facing(): Internal.Direction
        get boundingBoxForCulling(): Internal.AABB
        get target(): Internal.LivingEntity
        get nameTagOffsetY(): number
        get invulnerable(): boolean
        get inLava(): boolean
        get inWater(): boolean
        get rootVehicle(): Internal.Entity
        get noGravity(): boolean
        get powered(): boolean
        get speed(): number
        get cachedFeetBlockState(): Internal.BlockState
        get uuid(): Internal.UUID
        set offHandItem(item: Internal.ItemStack_)
        set noAi($$0: boolean)
        get armorSlots(): Internal.Iterable<Internal.ItemStack>
        get headArmorItem(): Internal.ItemStack
        get currentModifyFoodPowers(): Internal.List<any>
        get bbWidth(): number
        get "name()"(): net.minecraft.network.chat.Component
        get ticksRequiredToFreeze(): number
        get maxSpawnClusterSize(): number
        get username(): string
        get pickable(): boolean
        set YHeadRot($$0: number)
        set jumping($$0: boolean)
        get customData(): Internal.CompoundTag
        get pickResult(): Internal.ItemStack
        get "mainHandItem()"(): Internal.ItemStack
        get absorptionAmount(): number
        get randomY(): number
        get displayName(): net.minecraft.network.chat.Component
        get mobType(): Internal.MobType
        get dynamicLightPrevX(): number
        get passengersRidingOffset(): number
        get frame(): boolean
        set legsArmorItem(item: Internal.ItemStack_)
        set noGravity($$0: boolean)
        get useItemRemainingTicks(): number
        get indirectPassengers(): Internal.Iterable<any>
        get navigation(): Internal.PathNavigation
        get controlledByLocalInstance(): boolean
        get monster(): boolean
        get lastClimbablePos(): Optional<BlockPos>
        set lastDynamicLuminance(luminance: number)
        set id($$0: number)
        get horizontalFacing(): Internal.Direction
        get type(): string
        get activeEffectsMap(): Internal.Map<Internal.MobEffect, Internal.MobEffectInstance>
        set motionX(x: number)
        get handSlots(): Internal.Iterable<Internal.ItemStack>
        get teamColor(): number
        set nbt(nbt: Internal.CompoundTag_)
        get recallPosition(): Internal.DimensionalPosition
        set dynamicLightEnabled(enabled: boolean)
        get restrictRadius(): number
        get registeredNavigation(): Internal.PathNavigation
        get forcedVisible(): boolean
        get invertedHealAndHarm(): boolean
        get freezing(): boolean
        set guaranteedDrop($$0: Internal.EquipmentSlot_)
        set sharedFlagOnFire($$0: boolean)
        static readonly DATA_IS_POWERED: Internal.EntityDataAccessor<boolean>;
    }
    type Creeper_ = Creeper;
    interface BrewContainer {
        abstract getManaCost(arg0: Internal.Brew_, arg1: Internal.ItemStack_): number;
        abstract getItemForBrew(arg0: Internal.Brew_, arg1: Internal.ItemStack_): Internal.ItemStack;
    }
    type BrewContainer_ = BrewContainer;
    interface Int2CharFunction extends it.unimi.dsi.fastutil.Function<number, string>, Internal.IntUnaryOperator {
        andThenInt(arg0: Internal.Char2IntFunction_): Internal.Int2IntFunction;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: string): string;
        /**
         * @deprecated
        */
        "compose(java.util.function.Function)"<T>(arg0: Internal.Function_<T, number>): Internal.Function<T, string>;
        containsKey(arg0: number): boolean;
        composeLong(arg0: Internal.Long2IntFunction_): Internal.Long2CharFunction;
        /**
         * @deprecated
        */
        "getOrDefault(java.lang.Object,java.lang.Character)"(arg0: any, arg1: string): string;
        "compose(java.util.function.IntUnaryOperator)"(arg0: Internal.IntUnaryOperator_): Internal.IntUnaryOperator;
        /**
         * @deprecated
        */
        "put(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): any;
        /**
         * @deprecated
        */
        remove(arg0: any): string;
        /**
         * @deprecated
        */
        "get(java.lang.Object)"(arg0: any): string;
        "remove(int)"(arg0: number): string;
        andThenObject<T>(arg0: Internal.Char2ObjectFunction_<T>): Internal.Int2ObjectFunction<T>;
        "getOrDefault(int,char)"(arg0: number, arg1: string): string;
        compose(arg0: Internal.IntUnaryOperator_): Internal.IntUnaryOperator;
        applyAsInt(arg0: number): number;
        /**
         * @deprecated
        */
        put(arg0: number, arg1: string): string;
        /**
         * @deprecated
        */
        put(arg0: any, arg1: any): any;
        composeInt(arg0: Internal.Int2IntFunction_): this;
        composeShort(arg0: Internal.Short2IntFunction_): Internal.Short2CharFunction;
        composeObject<T>(arg0: Internal.Object2IntFunction_<T>): Internal.Object2CharFunction<T>;
        andThenByte(arg0: Internal.Char2ByteFunction_): Internal.Int2ByteFunction;
        composeDouble(arg0: Internal.Double2IntFunction_): Internal.Double2CharFunction;
        "containsKey(int)"(arg0: number): boolean;
        /**
         * @deprecated
        */
        "andThen(java.util.function.Function)"<T>(arg0: Internal.Function_<string, T>): Internal.Function<number, T>;
        /**
         * @deprecated
        */
        "remove(java.lang.Object)"(arg0: any): string;
        /**
         * @deprecated
        */
        andThen<T>(arg0: Internal.Function_<string, T>): Internal.Function<number, T>;
        /**
         * @deprecated
        */
        "containsKey(java.lang.Object)"(arg0: any): boolean;
        remove(arg0: number): string;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: any): any;
        defaultReturnValue(): string;
        composeChar(arg0: Internal.Char2IntFunction_): Internal.Char2CharFunction;
        /**
         * @deprecated
        */
        compose<T>(arg0: Internal.Function_<T, number>): Internal.Function<T, string>;
        andThenShort(arg0: Internal.Char2ShortFunction_): Internal.Int2ShortFunction;
        andThen(arg0: Internal.IntUnaryOperator_): Internal.IntUnaryOperator;
        "andThen(java.util.function.IntUnaryOperator)"(arg0: Internal.IntUnaryOperator_): Internal.IntUnaryOperator;
        composeByte(arg0: Internal.Byte2IntFunction_): Internal.Byte2CharFunction;
        /**
         * @deprecated
        */
        containsKey(arg0: any): boolean;
        /**
         * @deprecated
        */
        "getOrDefault(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): any;
        getOrDefault(arg0: number, arg1: string): string;
        defaultReturnValue(arg0: string): void;
        andThenFloat(arg0: Internal.Char2FloatFunction_): Internal.Int2FloatFunction;
        identity(): Internal.IntUnaryOperator;
        /**
         * @deprecated
        */
        get(arg0: any): string;
        apply(arg0: number): string;
        andThenChar(arg0: Internal.Char2CharFunction_): this;
        andThenReference<T>(arg0: Internal.Char2ReferenceFunction_<T>): Internal.Int2ReferenceFunction<T>;
        "put(int,char)"(arg0: number, arg1: string): string;
        abstract get(arg0: number): string;
        abstract "get(int)"(arg0: number): string;
        put(arg0: number, arg1: string): string;
        andThenDouble(arg0: Internal.Char2DoubleFunction_): Internal.Int2DoubleFunction;
        composeFloat(arg0: Internal.Float2IntFunction_): Internal.Float2CharFunction;
        size(): number;
        clear(): void;
        andThenLong(arg0: Internal.Char2LongFunction_): Internal.Int2LongFunction;
        composeReference<T>(arg0: Internal.Reference2IntFunction_<T>): Internal.Reference2CharFunction<T>;
        /**
         * @deprecated
        */
        "put(java.lang.Integer,java.lang.Character)"(arg0: number, arg1: string): string;
    }
    type Int2CharFunction_ = Int2CharFunction;
    abstract class Enchantment {
        getClass(): typeof any;
        getDamageProtection($$0: number, $$1: DamageSource_): number;
        getFullname($$0: number): net.minecraft.network.chat.Component;
        handler$dii000$botania$onEnchant(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        isCompatibleWith($$0: Internal.Enchantment_): boolean;
        getRarity(): Internal.Enchantment$Rarity;
        isTradeable(): boolean;
        isTreasureOnly(): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getId(): ResourceLocation;
        getMaxCost($$0: number): number;
        isDiscoverable(): boolean;
        getMinCost($$0: number): number;
        static byId($$0: number): Internal.Enchantment;
        getDescriptionId(): string;
        doPostHurt($$0: Internal.LivingEntity_, $$1: Internal.Entity_, $$2: number): void;
        toString(): string;
        getMaxLevel(): number;
        doPostAttack($$0: Internal.LivingEntity_, $$1: Internal.Entity_, $$2: number): void;
        notifyAll(): void;
        getSlotItems($$0: Internal.LivingEntity_): Internal.Map<Internal.EquipmentSlot, Internal.ItemStack>;
        getMinLevel(): number;
        getDamageBonus($$0: number, $$1: Internal.MobType_): number;
        hashCode(): number;
        isCurse(): boolean;
        wait(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        canEnchant($$0: Internal.ItemStack_): boolean;
        get class(): typeof any
        get rarity(): Internal.Enchantment$Rarity
        get tradeable(): boolean
        get treasureOnly(): boolean
        get id(): ResourceLocation
        get discoverable(): boolean
        get descriptionId(): string
        get maxLevel(): number
        get minLevel(): number
        get curse(): boolean
        readonly category: Internal.EnchantmentCategory;
    }
    type Enchantment_ = Special.Enchantment | Enchantment;
    class GrassBlock extends Internal.SpreadingSnowyDirtBlock implements Internal.BonemealableBlock {
        constructor($$0: Internal.BlockBehaviour$Properties_)
        /**
         * @deprecated
        */
        getOcclusionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        /**
         * @deprecated
        */
        getSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        axiom$customPickBlockStack(): Internal.ItemStack;
        getSoundType($$0: Internal.BlockState_): SoundType;
        /**
         * @deprecated
        */
        getVisualShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        static canPropagate($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        performBonemeal($$0: Internal.ServerLevel_, $$1: Internal.RandomSource_, $$2: BlockPos_, $$3: Internal.BlockState_): void;
        randomTick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        handler$efo000$collective$Block_playerDestroy(level: Internal.Level_, player: Internal.Player_, blockPos: BlockPos_, blockState: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number, $$5: number): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: Internal.BlockEntity_): void;
        static canSupportRigidBlock($$0: Internal.BlockGetter_, $$1: BlockPos_): boolean;
        static popResource($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.ItemStack_): void;
        setRandomTickCallback(callback: Internal.Consumer_<any>): void;
        getDescriptionId(): string;
        stepOn($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Entity_): void;
        fallOn($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: BlockPos_, $$3: Internal.Entity_, $$4: number): void;
        getSettings(): Internal.BlockBehaviour$Properties;
        getExplosionResistance(): number;
        asItem(): Internal.Item;
        /**
         * @deprecated
        */
        triggerEvent($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: number, $$4: number): boolean;
        getTypeData(): Internal.CompoundTag;
        setFriction(arg0: number): void;
        /**
         * @deprecated
        */
        getRenderShape($$0: Internal.BlockState_): Internal.RenderShape;
        canCull(): boolean;
        customShapeUpdate(blockState: Internal.CustomBlockState_, levelReader: Internal.LevelReader_, blockPos: BlockPos_): Internal.CustomBlockState;
        getJumpFactor(): number;
        static canBeGrass($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        getSpeedFactor(): number;
        static canSupportCenter($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        skipRendering($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getLightBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        playerDestroy($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.BlockEntity_, $$5: Internal.ItemStack_): void;
        shouldAttemptToCull(state: Internal.BlockState_): boolean;
        isPossibleToRespawnInThis($$0: Internal.BlockState_): boolean;
        getCustomStateForPlacement(blockPlaceContext: Internal.BlockPlaceContext_): Internal.CustomBlockState;
        /**
         * @deprecated
        */
        getDirectSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        getProperties(): Internal.BlockBehaviour$Properties;
        playerWillDestroy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Player_): void;
        getClass(): typeof any;
        getMaxVerticalOffset(): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.item.context.BlockPlaceContext)"($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        useShapeForLightOcclusion($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        getDrops($$0: Internal.BlockState_, $$1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getStateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>;
        /**
         * @deprecated
        */
        entityInside($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Entity_): void;
        setBlockBuilder(b: Internal.BlockBuilder_): void;
        handler$ldb000$puzzleslib$playerDestroy$0(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        setRequiresTool(v: boolean): void;
        setSpeedFactor(arg0: number): void;
        isValidBonemealTarget($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: boolean): boolean;
        axiom$getPossibleCustomStates(): Internal.List<any>;
        setExplosionResistance(arg0: number): void;
        toString(): string;
        port_lib$popExperience(arg0: Internal.ServerLevel_, arg1: BlockPos_, arg2: number): void;
        notifyAll(): void;
        getToolModifiedState(state: Internal.BlockState_, world: Internal.Level_, pos: BlockPos_, player: Internal.Player_, stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): Internal.BlockState;
        getId(): string;
        getLootTable(): ResourceLocation;
        puzzleslib$setItem(arg0: Internal.Item_): void;
        axiom$translationKey(): string;
        /**
         * @deprecated
        */
        getInteractionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        propagatesSkylightDown($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        setPlacedBy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.LivingEntity_, $$4: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        onPlace($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Block>;
        static popResourceFromFace($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.ItemStack_): void;
        getFriction(): number;
        handlePrecipitation($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Biome$Precipitation_): void;
        /**
         * @deprecated
        */
        hasAnalogOutputSignal($$0: Internal.BlockState_): boolean;
        wait(arg0: number): void;
        /**
         * @deprecated
        */
        getFluidState($$0: Internal.BlockState_): Internal.FluidState;
        handler$koh000$porting_lib_entity$getDestroySpeed(blockState: Internal.BlockState_, player: Internal.Player_, blockGetter: Internal.BlockGetter_, pos: BlockPos_, cir: Internal.CallbackInfoReturnable_<any>): void;
        /**
         * @deprecated
        */
        getAnalogOutputSignal($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): number;
        handler$efo000$collective$Block_setPlacedBy(level: Internal.Level_, blockPos: BlockPos_, blockState: Internal.BlockState_, livingEntity: Internal.LivingEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        tick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        supportsExternalFaceHiding(state: Internal.BlockState_): boolean;
        handler$ldb000$puzzleslib$playerDestroy$1(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        notify(): void;
        axiom$asItemStack(): Internal.ItemStack;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        neighborChanged($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Block_, $$4: BlockPos_, $$5: boolean): void;
        isBonemealSuccess($$0: Internal.Level_, $$1: Internal.RandomSource_, $$2: BlockPos_, $$3: Internal.BlockState_): boolean;
        handler$zhd000$additionalentityattributes$additionalEntityAttributes$saveBreakingPlayer(world: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, stack: Internal.ItemStack_, callbackInfo: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        getBlockSupportShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        canSustainPlant(state: Internal.BlockState_, world: Internal.BlockGetter_, pos: BlockPos_, facing: Internal.Direction_, plantable: Internal.IPlantable_): boolean;
        /**
         * @deprecated
        */
        isCollisionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static isFaceFull($$0: Internal.VoxelShape_, $$1: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getMenuProvider($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): Internal.MenuProvider;
        static byItem($$0: Internal.Item_): Internal.Block;
        static updateFromNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        updateIndirectNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: number, $$4: number): void;
        destroy($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): void;
        handler$fdc000$everycomp$addSimpleFastECdrops(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, cir: Internal.CallbackInfoReturnable_<any>, resId: ResourceLocation_, lootParams: Internal.LootParams_, serverLevel: Internal.ServerLevel_, lootTable: Internal.LootTable_): void;
        getToolModifiedState(state: Internal.BlockState_, context: Internal.UseOnContext_, toolAction: Internal.ToolAction_, simulate: boolean): Internal.BlockState;
        /**
         * @deprecated
        */
        use($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_, $$4: Internal.InteractionHand_, $$5: Internal.BlockHitResult_): Internal.InteractionResult;
        setLightEmission(v: number): void;
        doNormalInteractions(): boolean;
        setJumpFactor(arg0: number): void;
        /**
         * @deprecated
        */
        canSurvive($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): void;
        /**
         * @deprecated
        */
        getShadeBrightness($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        getAppearance(state: Internal.BlockState_, renderView: Internal.BlockAndTintGetter_, pos: BlockPos_, side: Internal.Direction_, sourceState: Internal.BlockState_, sourcePos: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        getCollisionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        setDestroySpeed(v: number): void;
        defaultBlockState(): Internal.BlockState;
        usesCustomShouldDrawFace(state: Internal.BlockState_): boolean;
        getStateForPlacement($$0: Internal.BlockPlaceContext_): Internal.BlockState;
        cantCullAgainst(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        arch$holder(): Internal.Holder<Internal.Block>;
        wait(): void;
        getCloneItemStack($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        hasDynamicShape(): boolean;
        getMaxHorizontalOffset(): number;
        /**
         * @deprecated
        */
        getDestroyProgress($$0: Internal.BlockState_, $$1: Internal.Player_, $$2: Internal.BlockGetter_, $$3: BlockPos_): number;
        /**
         * @deprecated
        */
        getSeed($$0: Internal.BlockState_, $$1: BlockPos_): number;
        defaultDestroyTime(): number;
        updateShape($$0: Internal.BlockState_, $$1: Internal.Direction_, $$2: Internal.BlockState_, $$3: Internal.LevelAccessor_, $$4: BlockPos_, $$5: BlockPos_): Internal.BlockState;
        dropFromExplosion($$0: Internal.Explosion_): boolean;
        isRandomlyTicking($$0: Internal.BlockState_): boolean;
        static isShapeFullBlock(shape: Internal.VoxelShape_): boolean;
        withPropertiesOf($$0: Internal.BlockState_): Internal.BlockState;
        static isExceptionForConnection($$0: Internal.BlockState_): boolean;
        setIsRandomlyTicking(arg0: boolean): void;
        hidesNeighborFace(level: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, neighborState: Internal.BlockState_, dir: Internal.Direction_): boolean;
        onTreeGrow(state: Internal.BlockState_, level: Internal.LevelReader_, placeFunction: Internal.BiConsumer_<BlockPos, Internal.BlockState>, randomSource: Internal.RandomSource_, pos: BlockPos_, config: Internal.TreeConfiguration_): boolean;
        /**
         * @deprecated
        */
        rotate($$0: Internal.BlockState_, $$1: Internal.Rotation_): Internal.BlockState;
        defaultMapColor(): Internal.MapColor;
        getStateAtViewpoint(state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_, viewpoint: Vec3d_): Internal.BlockState;
        wait(arg0: number, arg1: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.BlockGetter_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        setNameKey(arg0: string): void;
        static box($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): Internal.VoxelShape;
        /**
         * @deprecated
        */
        mirror($$0: Internal.BlockState_, $$1: Internal.Mirror_): Internal.BlockState;
        wasExploded($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Explosion_): void;
        getName(): Internal.MutableComponent;
        updateEntityAfterFallOn($$0: Internal.BlockGetter_, $$1: Internal.Entity_): void;
        animateTick($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        customShouldDrawFace(view: Internal.BlockGetter_, thisState: Internal.BlockState_, sideState: Internal.BlockState_, thisPos: BlockPos_, sidePos: BlockPos_, side: Internal.Direction_): Optional<boolean>;
        axiom$getResourceLocation(): ResourceLocation;
        arch$registryName(): ResourceLocation;
        axiom$getProperties(): Internal.Collection<any>;
        getBlockBuilder(): Internal.BlockBuilder;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        isSignalSource($$0: Internal.BlockState_): boolean;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number): void;
        /**
         * @deprecated
        */
        attack($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): void;
        /**
         * @deprecated
        */
        getShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        shouldAttemptToCull(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        onProjectileHit($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockHitResult_, $$3: Internal.Projectile_): void;
        static stateById($$0: number): Internal.BlockState;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): Internal.List<Internal.ItemStack>;
        requiredFeatures(): Internal.FeatureFlagSet;
        hashCode(): number;
        axiom$defaultCustomState(): Internal.CustomBlockState;
        setCanCull(canCull: boolean): void;
        /**
         * @deprecated
        */
        isOcclusionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static getId($$0: Internal.BlockState_): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.material.Fluid)"($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        static pushEntitiesUp($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        isPathfindable($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.PathComputationType_): boolean;
        setSoundType(arg0: SoundType_): void;
        handler$cef000$betterend$be_getDroppedStacks(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, info: Internal.CallbackInfoReturnable_<any>): void;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_): Internal.List<Internal.ItemStack>;
        /**
         * @deprecated
        */
        onRemove($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        cantCullAgainst(state: Internal.BlockState_): boolean;
        setHasCollision(arg0: boolean): void;
        static shouldRenderFace($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_, $$4: BlockPos_): boolean;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        spawnAfterBreak($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.ItemStack_, $$4: boolean): void;
        set randomTickCallback(callback: Internal.Consumer_<any>)
        get descriptionId(): string
        get settings(): Internal.BlockBehaviour$Properties
        get explosionResistance(): number
        get typeData(): Internal.CompoundTag
        set friction(arg0: number)
        get jumpFactor(): number
        get speedFactor(): number
        get properties(): Internal.BlockBehaviour$Properties
        get class(): typeof any
        get maxVerticalOffset(): number
        get stateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>
        set blockBuilder(b: Internal.BlockBuilder_)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        set speedFactor(arg0: number)
        set explosionResistance(arg0: number)
        get id(): string
        get lootTable(): ResourceLocation
        get friction(): number
        set lightEmission(v: number)
        set jumpFactor(arg0: number)
        set destroySpeed(v: number)
        get maxHorizontalOffset(): number
        set isRandomlyTicking(arg0: boolean)
        set nameKey(arg0: string)
        get name(): Internal.MutableComponent
        get blockBuilder(): Internal.BlockBuilder
        get idLocation(): ResourceLocation
        get mod(): string
        set canCull(canCull: boolean)
        set soundType(arg0: SoundType_)
        set hasCollision(arg0: boolean)
    }
    type GrassBlock_ = GrassBlock;
    class EndCaveBiome extends Internal.EndBiome {
        constructor(biomeID: Internal.ResourceKey_<Internal.Biome>, settings: Internal.BCLBiomeSettings_)
        static codecWithSettings<T extends Internal.BCLBiome, P11, P12, P13>(instance: Internal.RecordCodecBuilder$Instance_<T>, p11: Internal.RecordCodecBuilder_<T, P11>, p12: Internal.RecordCodecBuilder_<T, P12>, p13: Internal.RecordCodecBuilder_<T, P13>): Internal.Products$P13<Internal.RecordCodecBuilder$Mu<T>, number, number, number, number, boolean, Optional<ResourceLocation>, ResourceLocation, Optional<Internal.List<Internal.Climate$ParameterPoint>>, Optional<ResourceLocation>, Optional<string>, P11, P12, P13>;
        equals(key: Internal.ResourceKey_<Internal.Biome>): boolean;
        is(loc: ResourceLocation_): boolean;
        "is(net.minecraft.resources.ResourceLocation)"(loc: ResourceLocation_): boolean;
        static "findTopMaterial(net.minecraft.world.level.biome.Biome)"(biome: Internal.Biome_): Internal.BlockState;
        static findTopMaterial(biome: Internal.BCLBiome_): Internal.BlockState;
        forEachClimateParameter(consumer: Internal.Consumer_<Internal.Climate$ParameterPoint>): void;
        getCeil(pos: BlockPos_): Internal.BlockState;
        notify(): void;
        "equals(org.betterx.bclib.api.v2.levelgen.biomes.BCLBiome)"(biome: Internal.BCLBiome_): boolean;
        getCeilFeature(random: Internal.RandomSource_): Internal.Holder<Internal.ConfiguredFeature<any, any>>;
        surface(): Internal.SurfaceRuleBuilder;
        getTopMaterial(): Internal.BlockState;
        "equals(java.lang.Object)"(obj: any): boolean;
        getWall(pos: BlockPos_): Internal.BlockState;
        getParentBiome(): Internal.BCLBiome;
        generateFloorRule(): boolean;
        hasEdge(): boolean;
        static create(biomeConfig: Internal.EndBiome$Config_): Internal.EndCaveBiome;
        getBiomeKey(): Internal.ResourceKey<Internal.Biome>;
        isEdgeBiome(): boolean;
        "is(org.betterx.bclib.api.v2.levelgen.biomes.BCLBiome)"(biome: Internal.BCLBiome_): boolean;
        getID(): ResourceLocation;
        getFloorDensity(): number;
        static findUnderMaterial(biome: Internal.BCLBiome_): Internal.BlockState;
        addEdge(newEdge: Internal.BCLBiome_): Internal.BCLBiome;
        wait(): void;
        "equals(net.minecraft.resources.ResourceLocation)"(loc: ResourceLocation_): boolean;
        static createSubBiome(data: Internal.EndBiome$Config_, parentBiome: Internal.BCLBiome_): Internal.EndBiome;
        is(biome: Internal.BCLBiome_): boolean;
        static create(top: Internal.BlockState_, under: Internal.BlockState_, alt: Internal.BlockState_, genFloorRule: boolean): Internal.SurfaceMaterialProvider;
        getClass(): typeof any;
        static create(biomeConfig: Internal.EndBiome$Config_, type: Internal.BiomeAPI$BiomeType_): Internal.EndBiome;
        static codecWithSettings<T extends Internal.BCLBiome, P11>(instance: Internal.RecordCodecBuilder$Instance_<T>, p11: Internal.RecordCodecBuilder_<T, P11>): Internal.Products$P11<Internal.RecordCodecBuilder$Mu<T>, number, number, number, number, boolean, Optional<ResourceLocation>, ResourceLocation, Optional<Internal.List<Internal.Climate$ParameterPoint>>, Optional<ResourceLocation>, Optional<string>, P11>;
        isSame(biome: Internal.BCLBiome_): boolean;
        static codecWithSettings<T extends Internal.BCLBiome>(instance: Internal.RecordCodecBuilder$Instance_<T>): Internal.Products$P10<Internal.RecordCodecBuilder$Mu<T>, number, number, number, number, boolean, Optional<ResourceLocation>, ResourceLocation, Optional<Internal.List<Internal.Climate$ParameterPoint>>, Optional<ResourceLocation>, Optional<string>>;
        configGroup(): string;
        static simpleCaveBiomeCodec<T extends Internal.EndCaveBiome>(builder: Internal.Function14_<number, number, number, number, boolean, Optional<ResourceLocation>, ResourceLocation, Optional<Internal.List<Internal.Climate$ParameterPoint>>, Optional<ResourceLocation>, Optional<string>, boolean, Internal.SurfaceMaterialProvider, org.betterx.bclib.util.WeightedList<Internal.Holder<Internal.ConfiguredFeature<any, any>>>, org.betterx.bclib.util.WeightedList<Internal.Holder<Internal.ConfiguredFeature<any, any>>>, T>): Internal.Codec<T>;
        addSubBiome(biome: Internal.BCLBiome_): Internal.BCLBiome;
        "equals(net.minecraft.resources.ResourceKey)"(key: Internal.ResourceKey_<Internal.Biome>): boolean;
        wait(arg0: number, arg1: number): void;
        getCeilDensity(): number;
        getAltTopMaterial(): Internal.BlockState;
        getEdge(): Internal.BCLBiome;
        getBCLBiomeKey(): Internal.ResourceKey<Internal.BCLBiome>;
        "is(net.minecraft.resources.ResourceKey)"(key: Internal.ResourceKey_<Internal.Biome>): boolean;
        addFloorFeature(feature: Internal.Holder_<Internal.ConfiguredFeature<any, any>>, weight: number): void;
        static codecWithSettings<T extends Internal.BCLBiome, P11, P12>(instance: Internal.RecordCodecBuilder$Instance_<T>, p11: Internal.RecordCodecBuilder_<T, P11>, p12: Internal.RecordCodecBuilder_<T, P12>): Internal.Products$P12<Internal.RecordCodecBuilder$Mu<T>, number, number, number, number, boolean, Optional<ResourceLocation>, ResourceLocation, Optional<Internal.List<Internal.Climate$ParameterPoint>>, Optional<ResourceLocation>, Optional<string>, P11, P12>;
        hasParentBiome(): boolean;
        getFloorFeature(random: Internal.RandomSource_): Internal.Holder<Internal.ConfiguredFeature<any, any>>;
        forEachSubBiome(consumer: Internal.BiConsumer_<Internal.BCLBiome, number>): void;
        equals(biome: Internal.BCLBiome_): boolean;
        equals(loc: ResourceLocation_): boolean;
        static findUnderMaterial(world: Internal.WorldGenLevel_, pos: BlockPos_): Internal.BlockState;
        toString(): string;
        getUnderMaterial(): Internal.BlockState;
        notifyAll(): void;
        static findTopMaterial(world: Internal.WorldGenLevel_, pos: BlockPos_): Internal.BlockState;
        hasCaves(): boolean;
        is(key: Internal.ResourceKey_<Internal.Biome>): boolean;
        static "findTopMaterial(org.betterx.bclib.api.v2.levelgen.biomes.BCLBiome)"(biome: Internal.BCLBiome_): Internal.BlockState;
        codec(): Internal.KeyDispatchDataCodec<Internal.BCLBiome>;
        addCeilFeature(feature: Internal.Holder_<Internal.ConfiguredFeature<any, any>>, weight: number): void;
        hashCode(): number;
        static findTopMaterial(biome: Internal.Biome_): Internal.BlockState;
        wait(arg0: number): void;
        static getAllBeBiomes(): Internal.List<Internal.BCLBiome>;
        getIntendedType(): Internal.BiomeAPI$BiomeType;
        equals(obj: any): boolean;
        static codecWithSettings<T extends Internal.BCLBiome, P11, P12, P13, P14>(instance: Internal.RecordCodecBuilder$Instance_<T>, p11: Internal.RecordCodecBuilder_<T, P11>, p12: Internal.RecordCodecBuilder_<T, P12>, p13: Internal.RecordCodecBuilder_<T, P13>, p14: Internal.RecordCodecBuilder_<T, P14>): Internal.Products$P14<Internal.RecordCodecBuilder$Mu<T>, number, number, number, number, boolean, Optional<ResourceLocation>, ResourceLocation, Optional<Internal.List<Internal.Climate$ParameterPoint>>, Optional<ResourceLocation>, Optional<string>, P11, P12, P13, P14>;
        get topMaterial(): Internal.BlockState
        get parentBiome(): Internal.BCLBiome
        get biomeKey(): Internal.ResourceKey<Internal.Biome>
        get edgeBiome(): boolean
        get ID(): ResourceLocation
        get floorDensity(): number
        get class(): typeof any
        get ceilDensity(): number
        get altTopMaterial(): Internal.BlockState
        get edge(): Internal.BCLBiome
        get BCLBiomeKey(): Internal.ResourceKey<Internal.BCLBiome>
        get underMaterial(): Internal.BlockState
        get allBeBiomes(): Internal.List<Internal.BCLBiome>
        get intendedType(): Internal.BiomeAPI$BiomeType
        static readonly KEY_CODEC: Internal.KeyDispatchDataCodec<Internal.EndCaveBiome>;
        static readonly CODEC: Internal.Codec<Internal.EndCaveBiome>;
    }
    type EndCaveBiome_ = EndCaveBiome;
    class BrewingStandBlock extends Internal.BaseEntityBlock {
        constructor($$0: Internal.BlockBehaviour$Properties_)
        /**
         * @deprecated
        */
        getOcclusionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        /**
         * @deprecated
        */
        getSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        axiom$customPickBlockStack(): Internal.ItemStack;
        getSoundType($$0: Internal.BlockState_): SoundType;
        /**
         * @deprecated
        */
        getVisualShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        handler$efo000$collective$Block_playerDestroy(level: Internal.Level_, player: Internal.Player_, blockPos: BlockPos_, blockState: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number, $$5: number): void;
        /**
         * @deprecated
        */
        randomTick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: Internal.BlockEntity_): void;
        static canSupportRigidBlock($$0: Internal.BlockGetter_, $$1: BlockPos_): boolean;
        static popResource($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.ItemStack_): void;
        setRandomTickCallback(callback: Internal.Consumer_<any>): void;
        getDescriptionId(): string;
        stepOn($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Entity_): void;
        fallOn($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: BlockPos_, $$3: Internal.Entity_, $$4: number): void;
        getSettings(): Internal.BlockBehaviour$Properties;
        triggerEvent($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: number, $$4: number): boolean;
        getExplosionResistance(): number;
        asItem(): Internal.Item;
        getTypeData(): Internal.CompoundTag;
        setFriction(arg0: number): void;
        getRenderShape($$0: Internal.BlockState_): Internal.RenderShape;
        canCull(): boolean;
        customShapeUpdate(blockState: Internal.CustomBlockState_, levelReader: Internal.LevelReader_, blockPos: BlockPos_): Internal.CustomBlockState;
        getJumpFactor(): number;
        getSpeedFactor(): number;
        static canSupportCenter($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        skipRendering($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getLightBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        playerDestroy($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.BlockEntity_, $$5: Internal.ItemStack_): void;
        shouldAttemptToCull(state: Internal.BlockState_): boolean;
        isPossibleToRespawnInThis($$0: Internal.BlockState_): boolean;
        getCustomStateForPlacement(blockPlaceContext: Internal.BlockPlaceContext_): Internal.CustomBlockState;
        /**
         * @deprecated
        */
        getDirectSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        getProperties(): Internal.BlockBehaviour$Properties;
        playerWillDestroy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Player_): void;
        getClass(): typeof any;
        getMaxVerticalOffset(): number;
        newBlockEntity($$0: BlockPos_, $$1: Internal.BlockState_): Internal.BlockEntity;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.item.context.BlockPlaceContext)"($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        useShapeForLightOcclusion($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        getDrops($$0: Internal.BlockState_, $$1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getStateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>;
        /**
         * @deprecated
        */
        entityInside($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Entity_): void;
        setBlockBuilder(b: Internal.BlockBuilder_): void;
        handler$ldb000$puzzleslib$playerDestroy$0(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        setRequiresTool(v: boolean): void;
        setSpeedFactor(arg0: number): void;
        axiom$getPossibleCustomStates(): Internal.List<any>;
        setExplosionResistance(arg0: number): void;
        toString(): string;
        port_lib$popExperience(arg0: Internal.ServerLevel_, arg1: BlockPos_, arg2: number): void;
        notifyAll(): void;
        getToolModifiedState(state: Internal.BlockState_, world: Internal.Level_, pos: BlockPos_, player: Internal.Player_, stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): Internal.BlockState;
        getId(): string;
        getLootTable(): ResourceLocation;
        puzzleslib$setItem(arg0: Internal.Item_): void;
        axiom$translationKey(): string;
        /**
         * @deprecated
        */
        getInteractionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        setPlacedBy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.LivingEntity_, $$4: Internal.ItemStack_): void;
        propagatesSkylightDown($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        /**
         * @deprecated
        */
        onPlace($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Block>;
        static popResourceFromFace($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.ItemStack_): void;
        getFriction(): number;
        handlePrecipitation($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Biome$Precipitation_): void;
        hasAnalogOutputSignal($$0: Internal.BlockState_): boolean;
        wait(arg0: number): void;
        /**
         * @deprecated
        */
        getFluidState($$0: Internal.BlockState_): Internal.FluidState;
        handler$koh000$porting_lib_entity$getDestroySpeed(blockState: Internal.BlockState_, player: Internal.Player_, blockGetter: Internal.BlockGetter_, pos: BlockPos_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getAnalogOutputSignal($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): number;
        handler$efo000$collective$Block_setPlacedBy(level: Internal.Level_, blockPos: BlockPos_, blockState: Internal.BlockState_, livingEntity: Internal.LivingEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        tick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        supportsExternalFaceHiding(state: Internal.BlockState_): boolean;
        handler$ldb000$puzzleslib$playerDestroy$1(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        notify(): void;
        axiom$asItemStack(): Internal.ItemStack;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        neighborChanged($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Block_, $$4: BlockPos_, $$5: boolean): void;
        handler$zhd000$additionalentityattributes$additionalEntityAttributes$saveBreakingPlayer(world: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, stack: Internal.ItemStack_, callbackInfo: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        getBlockSupportShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        canSustainPlant(state: Internal.BlockState_, world: Internal.BlockGetter_, pos: BlockPos_, facing: Internal.Direction_, plantable: Internal.IPlantable_): boolean;
        /**
         * @deprecated
        */
        isCollisionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static isFaceFull($$0: Internal.VoxelShape_, $$1: Internal.Direction_): boolean;
        getTicker<T extends Internal.BlockEntity>($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockEntityType_<T>): Internal.BlockEntityTicker<T>;
        getMenuProvider($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): Internal.MenuProvider;
        static byItem($$0: Internal.Item_): Internal.Block;
        static updateFromNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        updateIndirectNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: number, $$4: number): void;
        destroy($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): void;
        handler$fdc000$everycomp$addSimpleFastECdrops(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, cir: Internal.CallbackInfoReturnable_<any>, resId: ResourceLocation_, lootParams: Internal.LootParams_, serverLevel: Internal.ServerLevel_, lootTable: Internal.LootTable_): void;
        getToolModifiedState(state: Internal.BlockState_, context: Internal.UseOnContext_, toolAction: Internal.ToolAction_, simulate: boolean): Internal.BlockState;
        use($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_, $$4: Internal.InteractionHand_, $$5: Internal.BlockHitResult_): Internal.InteractionResult;
        setLightEmission(v: number): void;
        doNormalInteractions(): boolean;
        setJumpFactor(arg0: number): void;
        /**
         * @deprecated
        */
        canSurvive($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): void;
        /**
         * @deprecated
        */
        getShadeBrightness($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        getAppearance(state: Internal.BlockState_, renderView: Internal.BlockAndTintGetter_, pos: BlockPos_, side: Internal.Direction_, sourceState: Internal.BlockState_, sourcePos: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        getCollisionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        setDestroySpeed(v: number): void;
        defaultBlockState(): Internal.BlockState;
        usesCustomShouldDrawFace(state: Internal.BlockState_): boolean;
        getStateForPlacement($$0: Internal.BlockPlaceContext_): Internal.BlockState;
        cantCullAgainst(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>($$0: Internal.ServerLevel_, $$1: T): Internal.GameEventListener;
        arch$holder(): Internal.Holder<Internal.Block>;
        wait(): void;
        getCloneItemStack($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        hasDynamicShape(): boolean;
        getMaxHorizontalOffset(): number;
        /**
         * @deprecated
        */
        getDestroyProgress($$0: Internal.BlockState_, $$1: Internal.Player_, $$2: Internal.BlockGetter_, $$3: BlockPos_): number;
        /**
         * @deprecated
        */
        getSeed($$0: Internal.BlockState_, $$1: BlockPos_): number;
        defaultDestroyTime(): number;
        dropFromExplosion($$0: Internal.Explosion_): boolean;
        /**
         * @deprecated
        */
        updateShape($$0: Internal.BlockState_, $$1: Internal.Direction_, $$2: Internal.BlockState_, $$3: Internal.LevelAccessor_, $$4: BlockPos_, $$5: BlockPos_): Internal.BlockState;
        isRandomlyTicking($$0: Internal.BlockState_): boolean;
        static isShapeFullBlock(shape: Internal.VoxelShape_): boolean;
        withPropertiesOf($$0: Internal.BlockState_): Internal.BlockState;
        static isExceptionForConnection($$0: Internal.BlockState_): boolean;
        setIsRandomlyTicking(arg0: boolean): void;
        hidesNeighborFace(level: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, neighborState: Internal.BlockState_, dir: Internal.Direction_): boolean;
        onTreeGrow(state: Internal.BlockState_, level: Internal.LevelReader_, placeFunction: Internal.BiConsumer_<BlockPos, Internal.BlockState>, randomSource: Internal.RandomSource_, pos: BlockPos_, config: Internal.TreeConfiguration_): boolean;
        /**
         * @deprecated
        */
        rotate($$0: Internal.BlockState_, $$1: Internal.Rotation_): Internal.BlockState;
        defaultMapColor(): Internal.MapColor;
        getStateAtViewpoint(state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_, viewpoint: Vec3d_): Internal.BlockState;
        wait(arg0: number, arg1: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.BlockGetter_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        setNameKey(arg0: string): void;
        static box($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): Internal.VoxelShape;
        /**
         * @deprecated
        */
        mirror($$0: Internal.BlockState_, $$1: Internal.Mirror_): Internal.BlockState;
        wasExploded($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Explosion_): void;
        getName(): Internal.MutableComponent;
        updateEntityAfterFallOn($$0: Internal.BlockGetter_, $$1: Internal.Entity_): void;
        animateTick($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        customShouldDrawFace(view: Internal.BlockGetter_, thisState: Internal.BlockState_, sideState: Internal.BlockState_, thisPos: BlockPos_, sidePos: BlockPos_, side: Internal.Direction_): Optional<boolean>;
        axiom$getResourceLocation(): ResourceLocation;
        arch$registryName(): ResourceLocation;
        axiom$getProperties(): Internal.Collection<any>;
        getBlockBuilder(): Internal.BlockBuilder;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        isSignalSource($$0: Internal.BlockState_): boolean;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number): void;
        /**
         * @deprecated
        */
        attack($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): void;
        getShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        shouldAttemptToCull(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        onProjectileHit($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockHitResult_, $$3: Internal.Projectile_): void;
        static stateById($$0: number): Internal.BlockState;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): Internal.List<Internal.ItemStack>;
        requiredFeatures(): Internal.FeatureFlagSet;
        hashCode(): number;
        axiom$defaultCustomState(): Internal.CustomBlockState;
        setCanCull(canCull: boolean): void;
        /**
         * @deprecated
        */
        isOcclusionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static getId($$0: Internal.BlockState_): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.material.Fluid)"($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        static pushEntitiesUp($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): Internal.BlockState;
        isPathfindable($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.PathComputationType_): boolean;
        setSoundType(arg0: SoundType_): void;
        handler$cef000$betterend$be_getDroppedStacks(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, info: Internal.CallbackInfoReturnable_<any>): void;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_): Internal.List<Internal.ItemStack>;
        onRemove($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        cantCullAgainst(state: Internal.BlockState_): boolean;
        setHasCollision(arg0: boolean): void;
        static shouldRenderFace($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_, $$4: BlockPos_): boolean;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        spawnAfterBreak($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.ItemStack_, $$4: boolean): void;
        set randomTickCallback(callback: Internal.Consumer_<any>)
        get descriptionId(): string
        get settings(): Internal.BlockBehaviour$Properties
        get explosionResistance(): number
        get typeData(): Internal.CompoundTag
        set friction(arg0: number)
        get jumpFactor(): number
        get speedFactor(): number
        get properties(): Internal.BlockBehaviour$Properties
        get class(): typeof any
        get maxVerticalOffset(): number
        get stateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>
        set blockBuilder(b: Internal.BlockBuilder_)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        set speedFactor(arg0: number)
        set explosionResistance(arg0: number)
        get id(): string
        get lootTable(): ResourceLocation
        get friction(): number
        set lightEmission(v: number)
        set jumpFactor(arg0: number)
        set destroySpeed(v: number)
        get maxHorizontalOffset(): number
        set isRandomlyTicking(arg0: boolean)
        set nameKey(arg0: string)
        get name(): Internal.MutableComponent
        get blockBuilder(): Internal.BlockBuilder
        get idLocation(): ResourceLocation
        get mod(): string
        set canCull(canCull: boolean)
        set soundType(arg0: SoundType_)
        set hasCollision(arg0: boolean)
        static readonly HAS_BOTTLE: Internal.BooleanProperty[];
    }
    type BrewingStandBlock_ = BrewingStandBlock;
    class EternalCrystalItem extends Internal.ModelProviderItem {
        constructor()
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        getItemModel(resourceLocation: ResourceLocation_): Internal.BlockModel;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type EternalCrystalItem_ = EternalCrystalItem;
    abstract class RuleTest {
        constructor()
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        abstract test(arg0: Internal.BlockState_, arg1: Internal.RandomSource_): boolean;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        static readonly CODEC: Internal.Codec<Internal.RuleTest>;
    }
    type RuleTest_ = RuleTest | BlockStatePredicate_ | any_;
    interface BlockType$SetFinder <T extends Internal.BlockType> extends Internal.Supplier<Optional<T>> {
        abstract get(): Optional<T>;
        (): Optional_<T>;
    }
    type BlockType$SetFinder_<T extends Internal.BlockType> = BlockType$SetFinder<T> | (()=> Optional_<T>);
    interface AccessorItem {
        abstract bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        (arg0: Internal.Item): void;
    }
    type AccessorItem_ = AccessorItem | ((arg0: Internal.Item)=> void);
    interface PositionSource {
        abstract getType(): Internal.PositionSourceType<any>;
        abstract getPosition(arg0: Internal.Level_): Optional<Vec3d>;
        get type(): Internal.PositionSourceType<any>
        readonly CODEC: Internal.Codec<Internal.PositionSource>;
    }
    type PositionSource_ = PositionSource;
    abstract class VarHandle implements Internal.Constable {
        weakCompareAndSet(...arg0: any[]): boolean;
        getAndBitwiseXor(...arg0: any[]): any;
        compareAndExchangeAcquire(...arg0: any[]): any;
        getAndSet(...arg0: any[]): any;
        notify(): void;
        hasInvokeExactBehavior(): boolean;
        getAndBitwiseXorAcquire(...arg0: any[]): any;
        setVolatile(...arg0: any[]): void;
        getAndAdd(...arg0: any[]): any;
        getAndBitwiseOrAcquire(...arg0: any[]): any;
        coordinateTypes(): Internal.List<typeof any>;
        static storeStoreFence(): void;
        toMethodHandle(arg0: Internal.VarHandle$AccessMode_): Internal.MethodHandle;
        setOpaque(...arg0: any[]): void;
        compareAndExchange(...arg0: any[]): any;
        getAndBitwiseAndAcquire(...arg0: any[]): any;
        varType(): typeof any;
        get(...arg0: any[]): any;
        getAndSetAcquire(...arg0: any[]): any;
        wait(): void;
        describeConstable(): Optional<Internal.VarHandle$VarHandleDesc>;
        static acquireFence(): void;
        getAndSetRelease(...arg0: any[]): any;
        weakCompareAndSetAcquire(...arg0: any[]): boolean;
        weakCompareAndSetRelease(...arg0: any[]): boolean;
        static loadLoadFence(): void;
        getAndBitwiseAnd(...arg0: any[]): any;
        getClass(): typeof any;
        set(...arg0: any[]): void;
        accessModeType(arg0: Internal.VarHandle$AccessMode_): Internal.MethodType;
        compareAndSet(...arg0: any[]): boolean;
        getAndBitwiseAndRelease(...arg0: any[]): any;
        wait(arg0: number, arg1: number): void;
        weakCompareAndSetPlain(...arg0: any[]): boolean;
        getAndBitwiseXorRelease(...arg0: any[]): any;
        getAndAddAcquire(...arg0: any[]): any;
        getAndAddRelease(...arg0: any[]): any;
        getAndBitwiseOr(...arg0: any[]): any;
        getAndBitwiseOrRelease(...arg0: any[]): any;
        static releaseFence(): void;
        static fullFence(): void;
        getAcquire(...arg0: any[]): any;
        getOpaque(...arg0: any[]): any;
        toString(): string;
        notifyAll(): void;
        compareAndExchangeRelease(...arg0: any[]): any;
        getVolatile(...arg0: any[]): any;
        abstract withInvokeBehavior(): this;
        hashCode(): number;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        abstract withInvokeExactBehavior(): this;
        isAccessModeSupported(arg0: Internal.VarHandle$AccessMode_): boolean;
        setRelease(...arg0: any[]): void;
        set "volatile"(...arg0: any[])
        set opaque(...arg0: any[])
        get class(): typeof any
        set release(...arg0: any[])
    }
    type VarHandle_ = VarHandle;
    class HeatRangerItem extends Internal.BowItem {
        constructor(settings: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        addModifierTooltip(stack: Internal.ItemStack_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_, type: Internal.ModifierHelperType_<any>): void;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        static getPowerForTime($$0: number): number;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, world: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        getDescriptionId(): string;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getAllSupportedProjectiles(): Internal.Predicate<Internal.ItemStack>;
        fzzy_core_correctSlot(slot: Internal.EquipmentSlot_): boolean;
        getCreativeTab(): string;
        postWearerHit(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        static getHeldProjectile($$0: Internal.LivingEntity_, $$1: Internal.Predicate_<Internal.ItemStack>): Internal.ItemStack;
        modifierObjectPredicate(livingEntity: Internal.LivingEntity_, stack: Internal.ItemStack_): ResourceLocation;
        getSupportedHeldProjectiles(): Internal.Predicate<Internal.ItemStack>;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        handler$mkb000$supplementaries$getAllSupportedProjectiles(cir: Internal.CallbackInfoReturnable_<any>): void;
        fzzy_core_getCorrectSlot(): Internal.EquipmentSlot;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        getDefaultProjectileRange(): number;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(world: Internal.Level_, user: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        onWearerKilledOther(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, victim: Internal.LivingEntity_, world: Internal.ServerLevel_): void;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        canBeModifiedBy(type: Internal.ModifierHelperType_<any>): boolean;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        incrementKillCount(stack: Internal.ItemStack_): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing(stack: Internal.ItemStack_, world: Internal.Level_, user: Internal.LivingEntity_, remainingUseTicks: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        defaultModifiers(type: Internal.ModifierHelperType_<any>): Internal.List<any>;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        localvar$zba000$porting_lib_base$customArrowTest(oldArrow: Internal.AbstractArrow_): Internal.AbstractArrow;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        localvar$ldd000$puzzleslib$releaseUsing(charge: number): number;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        handler$ega000$collective$use(level: Internal.Level_, player: Internal.Player_, interactionHand: Internal.InteractionHand_, cir: Internal.CallbackInfoReturnable_<any>): void;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        handler$ldd000$puzzleslib$releaseUsing(stack: Internal.ItemStack_, level: Internal.Level_, livingEntity: Internal.LivingEntity_, timeCharged: number, callback: Internal.CallbackInfo_, player: Internal.Player_, hasInfiniteAmmo: boolean, projectileStack: Internal.ItemStack_): void;
        getKillCount(stack: Internal.ItemStack_): number;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get allSupportedProjectiles(): Internal.Predicate<Internal.ItemStack>
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        get supportedHeldProjectiles(): Internal.Predicate<Internal.ItemStack>
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get defaultProjectileRange(): number
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type HeatRangerItem_ = HeatRangerItem;
    class MidasGoldSword extends Internal.SwordItem {
        constructor(material: Internal.Tier_, attackDamage: number, attackSpeed: number, settings: Internal.Item$Properties_)
        onTick(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        onWearerUse(stack: Internal.ItemStack_, world: Internal.Level_, user: Internal.Player_, hand: Internal.InteractionHand_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        addModifierTooltip(stack: Internal.ItemStack_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_, type: Internal.ModifierHelperType_<any>): void;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, world: Internal.Level_, lines: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        fzzy_core_correctSlot(slot: Internal.EquipmentSlot_): boolean;
        getCreativeTab(): string;
        postWearerHit(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        modifierObjectPredicate(livingEntity: Internal.LivingEntity_, stack: Internal.ItemStack_): ResourceLocation;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static countGold(goldCount: number): number;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        kjs$getAttributeMap(): Internal.Multimap<any, any>;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        kjs$getMutableAttributeMap(): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        fzzy_core_getCorrectSlot(): Internal.EquipmentSlot;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        onWearerKilledOther(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, victim: Internal.LivingEntity_, world: Internal.ServerLevel_): void;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        getDamage(): number;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        canBeModifiedBy(type: Internal.ModifierHelperType_<any>): boolean;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        incrementKillCount(stack: Internal.ItemStack_): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        defaultModifiers(type: Internal.ModifierHelperType_<any>): Internal.List<any>;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        port_lib$canPerformAction(stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): boolean;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        getTier(): Internal.Tier;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        static calculateSwordLevel(goldCount: number): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy(stack: Internal.ItemStack_, target: Internal.LivingEntity_, attacker: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getKillCount(stack: Internal.ItemStack_): number;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        postWearerMine(stack: Internal.ItemStack_, world: Internal.Level_, state: Internal.BlockState_, pos: BlockPos_, miner: Internal.Player_): void;
        kjs$setAttributeMap(arg0: Internal.Multimap_<any, any>): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get damage(): number
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        get tier(): Internal.Tier
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
        static readonly GOLD_FOLDED: Internal.NbtKey<number>;
        static readonly IS_GILDED: Internal.NbtKey<boolean>;
        static readonly IS_ROYAL: Internal.NbtKey<boolean>;
    }
    type MidasGoldSword_ = MidasGoldSword;
    interface WorldViewMixin extends Internal.RenderAttachedBlockView {
        abstract getBlockTint(arg0: BlockPos_, arg1: Internal.ColorResolver_): number;
        getMinSection(): number;
        abstract getShade(arg0: Internal.Direction_, arg1: boolean): number;
        abstract getBlockState(arg0: BlockPos_): Internal.BlockState;
        clipWithInteractionOverride($$0: Vec3d_, $$1: Vec3d_, $$2: BlockPos_, $$3: Internal.VoxelShape_, $$4: Internal.BlockState_): Internal.BlockHitResult;
        getSectionIndex($$0: number): number;
        getMaxSection(): number;
        getBrightness($$0: Internal.LightLayer_, $$1: BlockPos_): number;
        getMaxBuildHeight(): number;
        getBlockEntityRenderData(pos: BlockPos_): any;
        getBiomeFabric(pos: BlockPos_): Internal.Holder<Internal.Biome>;
        getLightEmission($$0: BlockPos_): number;
        getBlockFloorHeight($$0: BlockPos_): number;
        getSectionYFromSectionIndex($$0: number): number;
        create($$0: number, $$1: number): Internal.LevelHeightAccessor;
        "isOutsideBuildHeight(int)"($$0: number): boolean;
        clip($$0: Internal.ClipContext_): Internal.BlockHitResult;
        abstract getLightEngine(): Internal.LevelLightEngine;
        getBlockFloorHeight($$0: Internal.VoxelShape_, $$1: Internal.Supplier_<Internal.VoxelShape>): number;
        abstract getBlockEntity(arg0: BlockPos_): Internal.BlockEntity;
        abstract getHeight(): number;
        getRawBrightness($$0: BlockPos_, $$1: number): number;
        getBlockEntity<T extends Internal.BlockEntity>($$0: BlockPos_, $$1: Internal.BlockEntityType_<T>): Optional<T>;
        isOutsideBuildHeight($$0: BlockPos_): boolean;
        canSeeSky($$0: BlockPos_): boolean;
        isOutsideBuildHeight($$0: number): boolean;
        isBlockInLine($$0: Internal.ClipBlockStateContext_): Internal.BlockHitResult;
        abstract getFluidState(arg0: BlockPos_): Internal.FluidState;
        "isOutsideBuildHeight(net.minecraft.core.BlockPos)"($$0: BlockPos_): boolean;
        /**
         * @deprecated
        */
        getBlockEntityRenderAttachment(pos: BlockPos_): any;
        getBlockStates($$0: Internal.AABB_): Internal.Stream<Internal.BlockState>;
        getSectionsCount(): number;
        abstract getMinBuildHeight(): number;
        hasBiomes(): boolean;
        getMaxLightLevel(): number;
        getSectionIndexFromSectionY($$0: number): number;
        traverseBlocks<T, C>($$0: Vec3d_, $$1: Vec3d_, $$2: C, $$3: Internal.BiFunction_<C, BlockPos, T>, $$4: Internal.Function_<C, T>): T;
        get minSection(): number
        get maxSection(): number
        get maxBuildHeight(): number
        get lightEngine(): Internal.LevelLightEngine
        get height(): number
        get sectionsCount(): number
        get minBuildHeight(): number
        get maxLightLevel(): number
    }
    type WorldViewMixin_ = WorldViewMixin;
    interface MouseDown {
        newStream(): Internal.EventStream<Internal.MouseDown>;
        abstract onMouseDown(arg0: number, arg1: number, arg2: number): boolean;
        (arg0: number, arg1: number, arg2: number): boolean;
    }
    type MouseDown_ = ((arg0: number, arg1: number, arg2: number)=> boolean) | MouseDown;
    class EntityAnchorArgument$Anchor extends Internal.Enum<Internal.EntityAnchorArgument$Anchor> {
        static getByName($$0: string): Internal.EntityAnchorArgument$Anchor;
        getClass(): typeof any;
        static values(): Internal.EntityAnchorArgument$Anchor[];
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.EntityAnchorArgument$Anchor>>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        getDeclaringClass(): typeof Internal.EntityAnchorArgument$Anchor;
        apply($$0: Internal.Entity_): Vec3d;
        "apply(net.minecraft.world.entity.Entity)"($$0: Internal.Entity_): Vec3d;
        static valueOf($$0: string): Internal.EntityAnchorArgument$Anchor;
        "compareTo(net.minecraft.commands.arguments.EntityAnchorArgument$Anchor)"(arg0: Internal.EntityAnchorArgument$Anchor_): number;
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        toString(): string;
        notifyAll(): void;
        "apply(net.minecraft.commands.CommandSourceStack)"($$0: Internal.CommandSourceStack_): Vec3d;
        name(): string;
        compareTo(arg0: Internal.EntityAnchorArgument$Anchor_): number;
        hashCode(): number;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        "compareTo(java.lang.Object)"(arg0: any): number;
        apply($$0: Internal.CommandSourceStack_): Vec3d;
        equals(arg0: any): boolean;
        get class(): typeof any
        get declaringClass(): typeof Internal.EntityAnchorArgument$Anchor
        static readonly FEET: (Internal.EntityAnchorArgument$Anchor) & (Internal.EntityAnchorArgument$Anchor);
        static readonly EYES: (Internal.EntityAnchorArgument$Anchor) & (Internal.EntityAnchorArgument$Anchor);
    }
    type EntityAnchorArgument$Anchor_ = "eyes" | "feet" | EntityAnchorArgument$Anchor;
    class ItemMediaBattery extends Internal.ItemMediaHolder {
        constructor(pProperties: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getConsumptionPriority(stack: Internal.ItemStack_): number;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        canRecharge(stack: Internal.ItemStack_): boolean;
        appendHoverText(pStack: Internal.ItemStack_, pLevel: Internal.Level_, pTooltipComponents: Internal.List_<net.minecraft.network.chat.Component>, pIsAdvanced: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        canProvideMedia(stack: Internal.ItemStack_): boolean;
        getBarWidth(pStack: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor(pStack: Internal.ItemStack_): number;
        withdrawMedia(stack: Internal.ItemStack_, cost: number, simulate: boolean): number;
        getItem(): Internal.Item;
        getMaxMedia(stack: Internal.ItemStack_): number;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        static withMedia(stack: Internal.ItemStack_, media: number, maxMedia: number): Internal.ItemStack;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible(pStack: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMedia(stack: Internal.ItemStack_): number;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        getMediaFullness(stack: Internal.ItemStack_): number;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        insertMedia(stack: Internal.ItemStack_, amount: number, simulate: boolean): number;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setMedia(stack: Internal.ItemStack_, media: number): void;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
        static readonly MAX_MEDIA_PREDICATE: (ResourceLocation) & (ResourceLocation);
        static readonly MEDIA_PREDICATE: (ResourceLocation) & (ResourceLocation);
    }
    type ItemMediaBattery_ = ItemMediaBattery;
    interface MenuContainer {
        abstract remove(arg0: Internal.MenuComponent_): void;
        /**
         * @deprecated
        */
        abstract postEvent(arg0: Internal.Event_): boolean;
        abstract getFont(): Internal.Font;
        get font(): Internal.Font
    }
    type MenuContainer_ = MenuContainer;
    class PairCodec <F, S> implements Internal.Codec<com.mojang.datafixers.util.Pair<F, S>> {
        constructor(arg0: Internal.Codec_<F>, arg1: Internal.Codec_<S>)
        comapFlatMap<S>(arg0: Internal.Function_<com.mojang.datafixers.util.Pair<F, S>, Internal.DataResult<S>>, arg1: Internal.Function_<S, com.mojang.datafixers.util.Pair<F, S>>): Internal.Codec<S>;
        dispatchMap<E>(arg0: Internal.Function_<E, com.mojang.datafixers.util.Pair<F, S>>, arg1: Internal.Function_<com.mojang.datafixers.util.Pair<F, S>, Internal.Codec<E>>): Internal.MapCodec<E>;
        static empty<A>(): Internal.MapEncoder<A>;
        static "of(com.mojang.serialization.MapEncoder,com.mojang.serialization.MapDecoder)"<A>(arg0: Internal.MapEncoder_<A>, arg1: Internal.MapDecoder_<A>): Internal.MapCodec<A>;
        static error<A>(arg0: string): Internal.Encoder<A>;
        deprecated(arg0: number): Internal.Codec<com.mojang.datafixers.util.Pair<F, S>>;
        static unit<A>(arg0: Internal.Supplier_<A>): Internal.Codec<A>;
        orElseGet(arg0: Internal.Consumer_<string>, arg1: Internal.Supplier_<com.mojang.datafixers.util.Pair<F, S>>): Internal.Codec<com.mojang.datafixers.util.Pair<F, S>>;
        notify(): void;
        optionalFieldOf(arg0: string): Internal.MapCodec<Optional<com.mojang.datafixers.util.Pair<F, S>>>;
        static floatRange(arg0: number, arg1: number): Internal.Codec<number>;
        dispatchStable<E>(arg0: Internal.Function_<E, com.mojang.datafixers.util.Pair<F, S>>, arg1: Internal.Function_<com.mojang.datafixers.util.Pair<F, S>, Internal.Codec<E>>): Internal.Codec<E>;
        optionalFieldOf(arg0: string, arg1: com.mojang.datafixers.util.Pair_<F, S>, arg2: Internal.Lifecycle_): Internal.MapCodec<com.mojang.datafixers.util.Pair<F, S>>;
        partialDispatch<E>(arg0: string, arg1: Internal.Function_<E, Internal.DataResult<com.mojang.datafixers.util.Pair<F, S>>>, arg2: Internal.Function_<com.mojang.datafixers.util.Pair<F, S>, Internal.DataResult<Internal.Codec<E>>>): Internal.Codec<E>;
        static "of(com.mojang.serialization.Encoder,com.mojang.serialization.Decoder)"<A>(arg0: Internal.Encoder_<A>, arg1: Internal.Decoder_<A>): Internal.Codec<A>;
        static ofBoxed<A>(arg0: Internal.Decoder$Boxed_<A>): Internal.Decoder<A>;
        boxed(): Internal.Decoder$Boxed<com.mojang.datafixers.util.Pair<F, S>>;
        decode<T>(arg0: Internal.DynamicOps_<T>, arg1: T): Internal.DataResult<com.mojang.datafixers.util.Pair<com.mojang.datafixers.util.Pair<F, S>, T>>;
        "orElse(java.util.function.UnaryOperator,com.mojang.datafixers.util.Pair)"(arg0: Internal.UnaryOperator_<string>, arg1: com.mojang.datafixers.util.Pair_<F, S>): Internal.Codec<com.mojang.datafixers.util.Pair<F, S>>;
        "encode(com.mojang.datafixers.util.Pair,com.mojang.serialization.DynamicOps,java.lang.Object)"<T>(arg0: com.mojang.datafixers.util.Pair_<F, S>, arg1: Internal.DynamicOps_<T>, arg2: T): Internal.DataResult<T>;
        withLifecycle(arg0: Internal.Lifecycle_): Internal.Codec<com.mojang.datafixers.util.Pair<F, S>>;
        orElse(arg0: Internal.UnaryOperator_<string>, arg1: com.mojang.datafixers.util.Pair_<F, S>): Internal.Codec<com.mojang.datafixers.util.Pair<F, S>>;
        parse<T>(arg0: Internal.Dynamic_<T>): Internal.DataResult<com.mojang.datafixers.util.Pair<F, S>>;
        static intRange(arg0: number, arg1: number): Internal.Codec<number>;
        static unit<A>(arg0: A): Internal.Codec<A>;
        static pair<F, S>(arg0: Internal.Codec_<F>, arg1: Internal.Codec_<S>): Internal.Codec<com.mojang.datafixers.util.Pair<F, S>>;
        static either<F, S>(arg0: Internal.Codec_<F>, arg1: Internal.Codec_<S>): Internal.Codec<Internal.Either<F, S>>;
        static "unit(java.lang.Object)"<A>(arg0: A): Internal.Codec<A>;
        static checkRange<N extends number & Internal.Comparable<N>>(arg0: N, arg1: N): Internal.Function<N, Internal.DataResult<N>>;
        wait(): void;
        parse<T>(arg0: Internal.DynamicOps_<T>, arg1: T): Internal.DataResult<com.mojang.datafixers.util.Pair<F, S>>;
        optionalFieldOf(arg0: string, arg1: com.mojang.datafixers.util.Pair_<F, S>): Internal.MapCodec<com.mojang.datafixers.util.Pair<F, S>>;
        static unboundedMap<K, V>(arg0: Internal.Codec_<K>, arg1: Internal.Codec_<V>): Internal.UnboundedMapCodec<K, V>;
        dispatch<E>(arg0: string, arg1: Internal.Function_<E, com.mojang.datafixers.util.Pair<F, S>>, arg2: Internal.Function_<com.mojang.datafixers.util.Pair<F, S>, Internal.Codec<E>>): Internal.Codec<E>;
        dispatch<E>(arg0: Internal.Function_<E, com.mojang.datafixers.util.Pair<F, S>>, arg1: Internal.Function_<com.mojang.datafixers.util.Pair<F, S>, Internal.Codec<E>>): Internal.Codec<E>;
        static of<A>(arg0: Internal.Encoder_<A>, arg1: Internal.Decoder_<A>, arg2: string): Internal.Codec<A>;
        listOf(): Internal.Codec<Internal.List<com.mojang.datafixers.util.Pair<F, S>>>;
        getClass(): typeof any;
        "encode(java.lang.Object,com.mojang.serialization.DynamicOps,java.lang.Object)"(arg0: any, arg1: Internal.DynamicOps_<any>, arg2: any): Internal.DataResult<any>;
        "orElseGet(java.util.function.Consumer,java.util.function.Supplier)"(arg0: Internal.Consumer_<string>, arg1: Internal.Supplier_<com.mojang.datafixers.util.Pair<F, S>>): Internal.Codec<com.mojang.datafixers.util.Pair<F, S>>;
        stable(): Internal.Codec<com.mojang.datafixers.util.Pair<F, S>>;
        simple(): Internal.Decoder$Simple<com.mojang.datafixers.util.Pair<F, S>>;
        encodeStart<T>(arg0: Internal.DynamicOps_<T>, arg1: com.mojang.datafixers.util.Pair_<F, S>): Internal.DataResult<T>;
        static ofSimple<A>(arg0: Internal.Decoder$Simple_<A>): Internal.Decoder<A>;
        static mapEither<F, S>(arg0: Internal.MapCodec_<F>, arg1: Internal.MapCodec_<S>): Internal.MapCodec<Internal.Either<F, S>>;
        static doubleRange(arg0: number, arg1: number): Internal.Codec<number>;
        static optionalField<F>(arg0: string, arg1: Internal.Codec_<F>): Internal.MapCodec<Optional<F>>;
        static simpleMap<K, V>(arg0: Internal.Codec_<K>, arg1: Internal.Codec_<V>, arg2: Internal.Keyable_): Internal.SimpleMapCodec<K, V>;
        flatComapMap<S>(arg0: Internal.Function_<com.mojang.datafixers.util.Pair<F, S>, S>, arg1: Internal.Function_<S, Internal.DataResult<com.mojang.datafixers.util.Pair<F, S>>>): Internal.Codec<S>;
        static ofTerminal<A>(arg0: Internal.Decoder$Terminal_<A>): Internal.Decoder<A>;
        encode(arg0: any, arg1: Internal.DynamicOps_<any>, arg2: any): Internal.DataResult<any>;
        wait(arg0: number, arg1: number): void;
        dispatchMap<E>(arg0: string, arg1: Internal.Function_<E, com.mojang.datafixers.util.Pair<F, S>>, arg2: Internal.Function_<com.mojang.datafixers.util.Pair<F, S>, Internal.Codec<E>>): Internal.MapCodec<E>;
        mapResult(arg0: Internal.Codec$ResultFunction_<com.mojang.datafixers.util.Pair<F, S>>): Internal.Codec<com.mojang.datafixers.util.Pair<F, S>>;
        static list<E>(arg0: Internal.Codec_<E>): Internal.Codec<Internal.List<E>>;
        promotePartial(arg0: Internal.Consumer_<any>): Internal.Decoder<any>;
        orElseGet(arg0: Internal.UnaryOperator_<string>, arg1: Internal.Supplier_<com.mojang.datafixers.util.Pair<F, S>>): Internal.Codec<com.mojang.datafixers.util.Pair<F, S>>;
        optionalFieldOf(arg0: string, arg1: Internal.Lifecycle_, arg2: com.mojang.datafixers.util.Pair_<F, S>, arg3: Internal.Lifecycle_): Internal.MapCodec<com.mojang.datafixers.util.Pair<F, S>>;
        comap<B>(arg0: Internal.Function_<B, com.mojang.datafixers.util.Pair<F, S>>): Internal.Encoder<B>;
        static of<A>(arg0: Internal.MapEncoder_<A>, arg1: Internal.MapDecoder_<A>): Internal.MapCodec<A>;
        static "unit(java.util.function.Supplier)"<A>(arg0: Internal.Supplier_<A>): Internal.Codec<A>;
        toString(): string;
        orElse(arg0: com.mojang.datafixers.util.Pair_<F, S>): Internal.Codec<com.mojang.datafixers.util.Pair<F, S>>;
        static of<A>(arg0: Internal.Encoder_<A>, arg1: Internal.Decoder_<A>): Internal.Codec<A>;
        notifyAll(): void;
        xmap<S>(arg0: Internal.Function_<com.mojang.datafixers.util.Pair<F, S>, S>, arg1: Internal.Function_<S, com.mojang.datafixers.util.Pair<F, S>>): Internal.Codec<S>;
        decode<T>(arg0: Internal.Dynamic_<T>): Internal.DataResult<com.mojang.datafixers.util.Pair<com.mojang.datafixers.util.Pair<F, S>, T>>;
        orElseGet(arg0: Internal.Supplier_<com.mojang.datafixers.util.Pair<F, S>>): Internal.Codec<com.mojang.datafixers.util.Pair<F, S>>;
        encode<T>(arg0: com.mojang.datafixers.util.Pair_<F, S>, arg1: Internal.DynamicOps_<T>, arg2: T): Internal.DataResult<T>;
        static compoundList<K, V>(arg0: Internal.Codec_<K>, arg1: Internal.Codec_<V>): Internal.Codec<Internal.List<com.mojang.datafixers.util.Pair<K, V>>>;
        static of<A>(arg0: Internal.MapEncoder_<A>, arg1: Internal.MapDecoder_<A>, arg2: Internal.Supplier_<string>): Internal.MapCodec<A>;
        orElse(arg0: Internal.Consumer_<string>, arg1: com.mojang.datafixers.util.Pair_<F, S>): Internal.Codec<com.mojang.datafixers.util.Pair<F, S>>;
        terminal(): Internal.Decoder$Terminal<com.mojang.datafixers.util.Pair<F, S>>;
        hashCode(): number;
        "orElse(java.util.function.Consumer,com.mojang.datafixers.util.Pair)"(arg0: Internal.Consumer_<string>, arg1: com.mojang.datafixers.util.Pair_<F, S>): Internal.Codec<com.mojang.datafixers.util.Pair<F, S>>;
        wait(arg0: number): void;
        static "of(com.mojang.serialization.MapEncoder,com.mojang.serialization.MapDecoder,java.util.function.Supplier)"<A>(arg0: Internal.MapEncoder_<A>, arg1: Internal.MapDecoder_<A>, arg2: Internal.Supplier_<string>): Internal.MapCodec<A>;
        fieldOf(arg0: string): Internal.MapCodec<com.mojang.datafixers.util.Pair<F, S>>;
        flatXmap<S>(arg0: Internal.Function_<com.mojang.datafixers.util.Pair<F, S>, Internal.DataResult<S>>, arg1: Internal.Function_<S, Internal.DataResult<com.mojang.datafixers.util.Pair<F, S>>>): Internal.Codec<S>;
        static "of(com.mojang.serialization.Encoder,com.mojang.serialization.Decoder,java.lang.String)"<A>(arg0: Internal.Encoder_<A>, arg1: Internal.Decoder_<A>, arg2: string): Internal.Codec<A>;
        flatMap<B>(arg0: Internal.Function_<com.mojang.datafixers.util.Pair<F, S>, Internal.DataResult<B>>): Internal.Decoder<B>;
        equals(arg0: any): boolean;
        static mapPair<F, S>(arg0: Internal.MapCodec_<F>, arg1: Internal.MapCodec_<S>): Internal.MapCodec<com.mojang.datafixers.util.Pair<F, S>>;
        map<B>(arg0: Internal.Function_<com.mojang.datafixers.util.Pair<F, S>, B>): Internal.Decoder<B>;
        "orElseGet(java.util.function.UnaryOperator,java.util.function.Supplier)"(arg0: Internal.UnaryOperator_<string>, arg1: Internal.Supplier_<com.mojang.datafixers.util.Pair<F, S>>): Internal.Codec<com.mojang.datafixers.util.Pair<F, S>>;
        flatComap<B>(arg0: Internal.Function_<B, Internal.DataResult<com.mojang.datafixers.util.Pair<F, S>>>): Internal.Encoder<B>;
        get class(): typeof any
    }
    type PairCodec_<F, S> = PairCodec<F, S>;
    interface JadeBeforeRenderCallback {
        abstract beforeRender(arg0: Internal.ITooltip_, arg1: Internal.Rect2i_, arg2: Internal.GuiGraphics_, arg3: Internal.Accessor_<any>, arg4: Internal.JadeBeforeRenderCallback$ColorSetting_): boolean;
        (arg0: Internal.ITooltip, arg1: Internal.Rect2i, arg2: Internal.GuiGraphics, arg3: Internal.Accessor<any>, arg4: Internal.JadeBeforeRenderCallback$ColorSetting): boolean;
    }
    type JadeBeforeRenderCallback_ = JadeBeforeRenderCallback | ((arg0: Internal.ITooltip, arg1: Internal.Rect2i, arg2: Internal.GuiGraphics, arg3: Internal.Accessor<any>, arg4: Internal.JadeBeforeRenderCallback$ColorSetting)=> boolean);
    class ItemUpgradeIllumination extends Internal.ItemUpgrade {
        constructor(properties: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        getAllowMultiple(): boolean;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(itemStack: Internal.ItemStack_, world: Internal.Level_, list: Internal.List_<net.minecraft.network.chat.Component>, advanced: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        setAllowMultiple(allow: boolean): void;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        getUpgradeGroup(): number;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        getDescription(): net.minecraft.network.chat.Component;
        asIngredient(): Internal.Ingredient;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        isEnabled(): boolean;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        doesSneakBypassUse(stack: Internal.ItemStack_, level: Internal.LevelReader_, pos: BlockPos_, player: Internal.Player_): boolean;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get allowMultiple(): boolean
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        set allowMultiple(allow: boolean)
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        get upgradeGroup(): number
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        get enabled(): boolean
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type ItemUpgradeIllumination_ = ItemUpgradeIllumination;
    interface GuiEventListener extends Internal.TabOrderedElement {
        charTyped($$0: string, $$1: number): boolean;
        abstract isFocused(): boolean;
        abstract setFocused(arg0: boolean): void;
        mouseReleased($$0: number, $$1: number, $$2: number): boolean;
        getTabOrderGroup(): number;
        mouseScrolled($$0: number, $$1: number, $$2: number): boolean;
        keyReleased($$0: number, $$1: number, $$2: number): boolean;
        mouseClicked($$0: number, $$1: number, $$2: number): boolean;
        keyPressed($$0: number, $$1: number, $$2: number): boolean;
        getCurrentFocusPath(): Internal.ComponentPath;
        mouseDragged($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): boolean;
        mouseMoved($$0: number, $$1: number): void;
        getRectangle(): Internal.ScreenRectangle;
        isMouseOver($$0: number, $$1: number): boolean;
        nextFocusPath($$0: Internal.FocusNavigationEvent_): Internal.ComponentPath;
        get focused(): boolean
        set focused(arg0: boolean)
        get tabOrderGroup(): number
        get currentFocusPath(): Internal.ComponentPath
        get rectangle(): Internal.ScreenRectangle
        readonly DOUBLE_CLICK_THRESHOLD_MS: (250) & (number);
    }
    type GuiEventListener_ = GuiEventListener;
    interface IAsyncChunkStorage {
        abstract getNbtAtAsync(arg0: Internal.ChunkPos_): Internal.CompletableFuture<Optional<Internal.CompoundTag>>;
        (arg0: Internal.ChunkPos): Internal.CompletableFuture_<Optional<Internal.CompoundTag>>;
    }
    type IAsyncChunkStorage_ = IAsyncChunkStorage | ((arg0: Internal.ChunkPos)=> Internal.CompletableFuture_<Optional<Internal.CompoundTag>>);
    class CaveVinesBlock extends Internal.GrowingPlantHeadBlock implements Internal.CaveVines, Internal.BonemealableBlock {
        constructor($$0: Internal.BlockBehaviour$Properties_)
        /**
         * @deprecated
        */
        getOcclusionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        /**
         * @deprecated
        */
        getSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        axiom$customPickBlockStack(): Internal.ItemStack;
        getSoundType($$0: Internal.BlockState_): SoundType;
        /**
         * @deprecated
        */
        getVisualShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        performBonemeal($$0: Internal.ServerLevel_, $$1: Internal.RandomSource_, $$2: BlockPos_, $$3: Internal.BlockState_): void;
        randomTick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        handler$efo000$collective$Block_playerDestroy(level: Internal.Level_, player: Internal.Player_, blockPos: BlockPos_, blockState: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number, $$5: number): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: Internal.BlockEntity_): void;
        static canSupportRigidBlock($$0: Internal.BlockGetter_, $$1: BlockPos_): boolean;
        getMaxAgeState($$0: Internal.BlockState_): Internal.BlockState;
        static popResource($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.ItemStack_): void;
        setRandomTickCallback(callback: Internal.Consumer_<any>): void;
        getDescriptionId(): string;
        stepOn($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Entity_): void;
        fallOn($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: BlockPos_, $$3: Internal.Entity_, $$4: number): void;
        getSettings(): Internal.BlockBehaviour$Properties;
        getExplosionResistance(): number;
        asItem(): Internal.Item;
        /**
         * @deprecated
        */
        triggerEvent($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: number, $$4: number): boolean;
        getTypeData(): Internal.CompoundTag;
        setFriction(arg0: number): void;
        /**
         * @deprecated
        */
        getRenderShape($$0: Internal.BlockState_): Internal.RenderShape;
        canCull(): boolean;
        customShapeUpdate(blockState: Internal.CustomBlockState_, levelReader: Internal.LevelReader_, blockPos: BlockPos_): Internal.CustomBlockState;
        getJumpFactor(): number;
        getSpeedFactor(): number;
        static canSupportCenter($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        skipRendering($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getLightBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        playerDestroy($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.BlockEntity_, $$5: Internal.ItemStack_): void;
        shouldAttemptToCull(state: Internal.BlockState_): boolean;
        isPossibleToRespawnInThis($$0: Internal.BlockState_): boolean;
        getCustomStateForPlacement(blockPlaceContext: Internal.BlockPlaceContext_): Internal.CustomBlockState;
        /**
         * @deprecated
        */
        getDirectSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        getProperties(): Internal.BlockBehaviour$Properties;
        playerWillDestroy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Player_): void;
        getStateForPlacement($$0: Internal.LevelAccessor_): Internal.BlockState;
        getClass(): typeof any;
        getMaxVerticalOffset(): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.item.context.BlockPlaceContext)"($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        useShapeForLightOcclusion($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        getDrops($$0: Internal.BlockState_, $$1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getStateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>;
        /**
         * @deprecated
        */
        entityInside($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Entity_): void;
        setBlockBuilder(b: Internal.BlockBuilder_): void;
        handler$ldb000$puzzleslib$playerDestroy$0(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        setRequiresTool(v: boolean): void;
        setSpeedFactor(arg0: number): void;
        isValidBonemealTarget($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: boolean): boolean;
        isMaxAge($$0: Internal.BlockState_): boolean;
        axiom$getPossibleCustomStates(): Internal.List<any>;
        setExplosionResistance(arg0: number): void;
        toString(): string;
        static emission($$0: number): Internal.ToIntFunction<Internal.BlockState>;
        port_lib$popExperience(arg0: Internal.ServerLevel_, arg1: BlockPos_, arg2: number): void;
        notifyAll(): void;
        static use($$0: Internal.Entity_, $$1: Internal.BlockState_, $$2: Internal.Level_, $$3: BlockPos_): Internal.InteractionResult;
        getToolModifiedState(state: Internal.BlockState_, world: Internal.Level_, pos: BlockPos_, player: Internal.Player_, stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): Internal.BlockState;
        getId(): string;
        getLootTable(): ResourceLocation;
        puzzleslib$setItem(arg0: Internal.Item_): void;
        axiom$translationKey(): string;
        /**
         * @deprecated
        */
        getInteractionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        propagatesSkylightDown($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        setPlacedBy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.LivingEntity_, $$4: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        onPlace($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        static hasGlowBerries($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Block>;
        static popResourceFromFace($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.ItemStack_): void;
        getFriction(): number;
        handlePrecipitation($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Biome$Precipitation_): void;
        /**
         * @deprecated
        */
        hasAnalogOutputSignal($$0: Internal.BlockState_): boolean;
        wait(arg0: number): void;
        /**
         * @deprecated
        */
        getFluidState($$0: Internal.BlockState_): Internal.FluidState;
        handler$koh000$porting_lib_entity$getDestroySpeed(blockState: Internal.BlockState_, player: Internal.Player_, blockGetter: Internal.BlockGetter_, pos: BlockPos_, cir: Internal.CallbackInfoReturnable_<any>): void;
        /**
         * @deprecated
        */
        getAnalogOutputSignal($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): number;
        handler$efo000$collective$Block_setPlacedBy(level: Internal.Level_, blockPos: BlockPos_, blockState: Internal.BlockState_, livingEntity: Internal.LivingEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        tick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        supportsExternalFaceHiding(state: Internal.BlockState_): boolean;
        "getStateForPlacement(net.minecraft.world.level.LevelAccessor)"($$0: Internal.LevelAccessor_): Internal.BlockState;
        handler$ldb000$puzzleslib$playerDestroy$1(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        notify(): void;
        axiom$asItemStack(): Internal.ItemStack;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        neighborChanged($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Block_, $$4: BlockPos_, $$5: boolean): void;
        isBonemealSuccess($$0: Internal.Level_, $$1: Internal.RandomSource_, $$2: BlockPos_, $$3: Internal.BlockState_): boolean;
        handler$zhd000$additionalentityattributes$additionalEntityAttributes$saveBreakingPlayer(world: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, stack: Internal.ItemStack_, callbackInfo: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        getBlockSupportShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        canSustainPlant(state: Internal.BlockState_, world: Internal.BlockGetter_, pos: BlockPos_, facing: Internal.Direction_, plantable: Internal.IPlantable_): boolean;
        /**
         * @deprecated
        */
        isCollisionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static isFaceFull($$0: Internal.VoxelShape_, $$1: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getMenuProvider($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): Internal.MenuProvider;
        static byItem($$0: Internal.Item_): Internal.Block;
        static updateFromNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        updateIndirectNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: number, $$4: number): void;
        destroy($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): void;
        handler$fdc000$everycomp$addSimpleFastECdrops(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, cir: Internal.CallbackInfoReturnable_<any>, resId: ResourceLocation_, lootParams: Internal.LootParams_, serverLevel: Internal.ServerLevel_, lootTable: Internal.LootTable_): void;
        getToolModifiedState(state: Internal.BlockState_, context: Internal.UseOnContext_, toolAction: Internal.ToolAction_, simulate: boolean): Internal.BlockState;
        use($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_, $$4: Internal.InteractionHand_, $$5: Internal.BlockHitResult_): Internal.InteractionResult;
        setLightEmission(v: number): void;
        doNormalInteractions(): boolean;
        setJumpFactor(arg0: number): void;
        canSurvive($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): void;
        /**
         * @deprecated
        */
        getShadeBrightness($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        getAppearance(state: Internal.BlockState_, renderView: Internal.BlockAndTintGetter_, pos: BlockPos_, side: Internal.Direction_, sourceState: Internal.BlockState_, sourcePos: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        getCollisionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        setDestroySpeed(v: number): void;
        defaultBlockState(): Internal.BlockState;
        usesCustomShouldDrawFace(state: Internal.BlockState_): boolean;
        getStateForPlacement($$0: Internal.BlockPlaceContext_): Internal.BlockState;
        cantCullAgainst(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        arch$holder(): Internal.Holder<Internal.Block>;
        wait(): void;
        getCloneItemStack($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        hasDynamicShape(): boolean;
        getMaxHorizontalOffset(): number;
        /**
         * @deprecated
        */
        getDestroyProgress($$0: Internal.BlockState_, $$1: Internal.Player_, $$2: Internal.BlockGetter_, $$3: BlockPos_): number;
        /**
         * @deprecated
        */
        getSeed($$0: Internal.BlockState_, $$1: BlockPos_): number;
        defaultDestroyTime(): number;
        updateShape($$0: Internal.BlockState_, $$1: Internal.Direction_, $$2: Internal.BlockState_, $$3: Internal.LevelAccessor_, $$4: BlockPos_, $$5: BlockPos_): Internal.BlockState;
        dropFromExplosion($$0: Internal.Explosion_): boolean;
        isRandomlyTicking($$0: Internal.BlockState_): boolean;
        static isShapeFullBlock(shape: Internal.VoxelShape_): boolean;
        withPropertiesOf($$0: Internal.BlockState_): Internal.BlockState;
        static isExceptionForConnection($$0: Internal.BlockState_): boolean;
        setIsRandomlyTicking(arg0: boolean): void;
        hidesNeighborFace(level: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, neighborState: Internal.BlockState_, dir: Internal.Direction_): boolean;
        onTreeGrow(state: Internal.BlockState_, level: Internal.LevelReader_, placeFunction: Internal.BiConsumer_<BlockPos, Internal.BlockState>, randomSource: Internal.RandomSource_, pos: BlockPos_, config: Internal.TreeConfiguration_): boolean;
        /**
         * @deprecated
        */
        rotate($$0: Internal.BlockState_, $$1: Internal.Rotation_): Internal.BlockState;
        defaultMapColor(): Internal.MapColor;
        getStateAtViewpoint(state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_, viewpoint: Vec3d_): Internal.BlockState;
        wait(arg0: number, arg1: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.BlockGetter_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        setNameKey(arg0: string): void;
        "getStateForPlacement(net.minecraft.world.item.context.BlockPlaceContext)"($$0: Internal.BlockPlaceContext_): Internal.BlockState;
        static box($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): Internal.VoxelShape;
        /**
         * @deprecated
        */
        mirror($$0: Internal.BlockState_, $$1: Internal.Mirror_): Internal.BlockState;
        wasExploded($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Explosion_): void;
        getName(): Internal.MutableComponent;
        updateEntityAfterFallOn($$0: Internal.BlockGetter_, $$1: Internal.Entity_): void;
        animateTick($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        customShouldDrawFace(view: Internal.BlockGetter_, thisState: Internal.BlockState_, sideState: Internal.BlockState_, thisPos: BlockPos_, sidePos: BlockPos_, side: Internal.Direction_): Optional<boolean>;
        axiom$getResourceLocation(): ResourceLocation;
        arch$registryName(): ResourceLocation;
        axiom$getProperties(): Internal.Collection<any>;
        getBlockBuilder(): Internal.BlockBuilder;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        isSignalSource($$0: Internal.BlockState_): boolean;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number): void;
        /**
         * @deprecated
        */
        attack($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): void;
        getShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        shouldAttemptToCull(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        onProjectileHit($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockHitResult_, $$3: Internal.Projectile_): void;
        static stateById($$0: number): Internal.BlockState;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): Internal.List<Internal.ItemStack>;
        requiredFeatures(): Internal.FeatureFlagSet;
        hashCode(): number;
        axiom$defaultCustomState(): Internal.CustomBlockState;
        setCanCull(canCull: boolean): void;
        /**
         * @deprecated
        */
        isOcclusionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static getId($$0: Internal.BlockState_): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.material.Fluid)"($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        static pushEntitiesUp($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        isPathfindable($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.PathComputationType_): boolean;
        setSoundType(arg0: SoundType_): void;
        handler$cef000$betterend$be_getDroppedStacks(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, info: Internal.CallbackInfoReturnable_<any>): void;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_): Internal.List<Internal.ItemStack>;
        /**
         * @deprecated
        */
        onRemove($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        cantCullAgainst(state: Internal.BlockState_): boolean;
        setHasCollision(arg0: boolean): void;
        static shouldRenderFace($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_, $$4: BlockPos_): boolean;
        equals(arg0: any): boolean;
        handler$eid000$collective$GrowingPlantHeadBlock_randomTick(blockState: Internal.BlockState_, serverLevel: Internal.ServerLevel_, blockPos: BlockPos_, randomSource: Internal.RandomSource_, ci: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        spawnAfterBreak($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.ItemStack_, $$4: boolean): void;
        set randomTickCallback(callback: Internal.Consumer_<any>)
        get descriptionId(): string
        get settings(): Internal.BlockBehaviour$Properties
        get explosionResistance(): number
        get typeData(): Internal.CompoundTag
        set friction(arg0: number)
        get jumpFactor(): number
        get speedFactor(): number
        get properties(): Internal.BlockBehaviour$Properties
        get class(): typeof any
        get maxVerticalOffset(): number
        get stateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>
        set blockBuilder(b: Internal.BlockBuilder_)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        set speedFactor(arg0: number)
        set explosionResistance(arg0: number)
        get id(): string
        get lootTable(): ResourceLocation
        get friction(): number
        set lightEmission(v: number)
        set jumpFactor(arg0: number)
        set destroySpeed(v: number)
        get maxHorizontalOffset(): number
        set isRandomlyTicking(arg0: boolean)
        set nameKey(arg0: string)
        get name(): Internal.MutableComponent
        get blockBuilder(): Internal.BlockBuilder
        get idLocation(): ResourceLocation
        get mod(): string
        set canCull(canCull: boolean)
        set soundType(arg0: SoundType_)
        set hasCollision(arg0: boolean)
    }
    type CaveVinesBlock_ = CaveVinesBlock;
    class SnowyDirtBlock extends Internal.Block {
        constructor($$0: Internal.BlockBehaviour$Properties_)
        /**
         * @deprecated
        */
        getOcclusionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        /**
         * @deprecated
        */
        getSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        axiom$customPickBlockStack(): Internal.ItemStack;
        getSoundType($$0: Internal.BlockState_): SoundType;
        /**
         * @deprecated
        */
        getVisualShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        handler$efo000$collective$Block_playerDestroy(level: Internal.Level_, player: Internal.Player_, blockPos: BlockPos_, blockState: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number, $$5: number): void;
        /**
         * @deprecated
        */
        randomTick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: Internal.BlockEntity_): void;
        static canSupportRigidBlock($$0: Internal.BlockGetter_, $$1: BlockPos_): boolean;
        static popResource($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.ItemStack_): void;
        setRandomTickCallback(callback: Internal.Consumer_<any>): void;
        getDescriptionId(): string;
        stepOn($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Entity_): void;
        fallOn($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: BlockPos_, $$3: Internal.Entity_, $$4: number): void;
        getSettings(): Internal.BlockBehaviour$Properties;
        getExplosionResistance(): number;
        asItem(): Internal.Item;
        /**
         * @deprecated
        */
        triggerEvent($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: number, $$4: number): boolean;
        getTypeData(): Internal.CompoundTag;
        setFriction(arg0: number): void;
        /**
         * @deprecated
        */
        getRenderShape($$0: Internal.BlockState_): Internal.RenderShape;
        canCull(): boolean;
        customShapeUpdate(blockState: Internal.CustomBlockState_, levelReader: Internal.LevelReader_, blockPos: BlockPos_): Internal.CustomBlockState;
        getJumpFactor(): number;
        getSpeedFactor(): number;
        static canSupportCenter($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        skipRendering($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getLightBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        playerDestroy($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.BlockEntity_, $$5: Internal.ItemStack_): void;
        shouldAttemptToCull(state: Internal.BlockState_): boolean;
        isPossibleToRespawnInThis($$0: Internal.BlockState_): boolean;
        getCustomStateForPlacement(blockPlaceContext: Internal.BlockPlaceContext_): Internal.CustomBlockState;
        /**
         * @deprecated
        */
        getDirectSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        getProperties(): Internal.BlockBehaviour$Properties;
        playerWillDestroy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Player_): void;
        getClass(): typeof any;
        getMaxVerticalOffset(): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.item.context.BlockPlaceContext)"($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        useShapeForLightOcclusion($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        getDrops($$0: Internal.BlockState_, $$1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getStateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>;
        /**
         * @deprecated
        */
        entityInside($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Entity_): void;
        setBlockBuilder(b: Internal.BlockBuilder_): void;
        handler$ldb000$puzzleslib$playerDestroy$0(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        setRequiresTool(v: boolean): void;
        setSpeedFactor(arg0: number): void;
        axiom$getPossibleCustomStates(): Internal.List<any>;
        setExplosionResistance(arg0: number): void;
        toString(): string;
        port_lib$popExperience(arg0: Internal.ServerLevel_, arg1: BlockPos_, arg2: number): void;
        notifyAll(): void;
        getToolModifiedState(state: Internal.BlockState_, world: Internal.Level_, pos: BlockPos_, player: Internal.Player_, stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): Internal.BlockState;
        getId(): string;
        getLootTable(): ResourceLocation;
        puzzleslib$setItem(arg0: Internal.Item_): void;
        axiom$translationKey(): string;
        /**
         * @deprecated
        */
        getInteractionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        propagatesSkylightDown($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        setPlacedBy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.LivingEntity_, $$4: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        onPlace($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Block>;
        static popResourceFromFace($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.ItemStack_): void;
        getFriction(): number;
        handlePrecipitation($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Biome$Precipitation_): void;
        /**
         * @deprecated
        */
        hasAnalogOutputSignal($$0: Internal.BlockState_): boolean;
        wait(arg0: number): void;
        /**
         * @deprecated
        */
        getFluidState($$0: Internal.BlockState_): Internal.FluidState;
        handler$koh000$porting_lib_entity$getDestroySpeed(blockState: Internal.BlockState_, player: Internal.Player_, blockGetter: Internal.BlockGetter_, pos: BlockPos_, cir: Internal.CallbackInfoReturnable_<any>): void;
        /**
         * @deprecated
        */
        getAnalogOutputSignal($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): number;
        handler$efo000$collective$Block_setPlacedBy(level: Internal.Level_, blockPos: BlockPos_, blockState: Internal.BlockState_, livingEntity: Internal.LivingEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        tick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        supportsExternalFaceHiding(state: Internal.BlockState_): boolean;
        handler$ldb000$puzzleslib$playerDestroy$1(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        notify(): void;
        axiom$asItemStack(): Internal.ItemStack;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        neighborChanged($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Block_, $$4: BlockPos_, $$5: boolean): void;
        handler$zhd000$additionalentityattributes$additionalEntityAttributes$saveBreakingPlayer(world: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, stack: Internal.ItemStack_, callbackInfo: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        getBlockSupportShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        canSustainPlant(state: Internal.BlockState_, world: Internal.BlockGetter_, pos: BlockPos_, facing: Internal.Direction_, plantable: Internal.IPlantable_): boolean;
        /**
         * @deprecated
        */
        isCollisionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static isFaceFull($$0: Internal.VoxelShape_, $$1: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getMenuProvider($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): Internal.MenuProvider;
        static byItem($$0: Internal.Item_): Internal.Block;
        static updateFromNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        updateIndirectNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: number, $$4: number): void;
        destroy($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): void;
        handler$fdc000$everycomp$addSimpleFastECdrops(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, cir: Internal.CallbackInfoReturnable_<any>, resId: ResourceLocation_, lootParams: Internal.LootParams_, serverLevel: Internal.ServerLevel_, lootTable: Internal.LootTable_): void;
        getToolModifiedState(state: Internal.BlockState_, context: Internal.UseOnContext_, toolAction: Internal.ToolAction_, simulate: boolean): Internal.BlockState;
        /**
         * @deprecated
        */
        use($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_, $$4: Internal.InteractionHand_, $$5: Internal.BlockHitResult_): Internal.InteractionResult;
        setLightEmission(v: number): void;
        doNormalInteractions(): boolean;
        setJumpFactor(arg0: number): void;
        /**
         * @deprecated
        */
        canSurvive($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): void;
        /**
         * @deprecated
        */
        getShadeBrightness($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        getAppearance(state: Internal.BlockState_, renderView: Internal.BlockAndTintGetter_, pos: BlockPos_, side: Internal.Direction_, sourceState: Internal.BlockState_, sourcePos: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        getCollisionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        setDestroySpeed(v: number): void;
        defaultBlockState(): Internal.BlockState;
        usesCustomShouldDrawFace(state: Internal.BlockState_): boolean;
        getStateForPlacement($$0: Internal.BlockPlaceContext_): Internal.BlockState;
        cantCullAgainst(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        arch$holder(): Internal.Holder<Internal.Block>;
        wait(): void;
        getCloneItemStack($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        hasDynamicShape(): boolean;
        getMaxHorizontalOffset(): number;
        /**
         * @deprecated
        */
        getDestroyProgress($$0: Internal.BlockState_, $$1: Internal.Player_, $$2: Internal.BlockGetter_, $$3: BlockPos_): number;
        /**
         * @deprecated
        */
        getSeed($$0: Internal.BlockState_, $$1: BlockPos_): number;
        defaultDestroyTime(): number;
        updateShape($$0: Internal.BlockState_, $$1: Internal.Direction_, $$2: Internal.BlockState_, $$3: Internal.LevelAccessor_, $$4: BlockPos_, $$5: BlockPos_): Internal.BlockState;
        dropFromExplosion($$0: Internal.Explosion_): boolean;
        isRandomlyTicking($$0: Internal.BlockState_): boolean;
        static isShapeFullBlock(shape: Internal.VoxelShape_): boolean;
        withPropertiesOf($$0: Internal.BlockState_): Internal.BlockState;
        static isExceptionForConnection($$0: Internal.BlockState_): boolean;
        setIsRandomlyTicking(arg0: boolean): void;
        hidesNeighborFace(level: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, neighborState: Internal.BlockState_, dir: Internal.Direction_): boolean;
        onTreeGrow(state: Internal.BlockState_, level: Internal.LevelReader_, placeFunction: Internal.BiConsumer_<BlockPos, Internal.BlockState>, randomSource: Internal.RandomSource_, pos: BlockPos_, config: Internal.TreeConfiguration_): boolean;
        /**
         * @deprecated
        */
        rotate($$0: Internal.BlockState_, $$1: Internal.Rotation_): Internal.BlockState;
        defaultMapColor(): Internal.MapColor;
        getStateAtViewpoint(state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_, viewpoint: Vec3d_): Internal.BlockState;
        wait(arg0: number, arg1: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.BlockGetter_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        setNameKey(arg0: string): void;
        static box($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): Internal.VoxelShape;
        /**
         * @deprecated
        */
        mirror($$0: Internal.BlockState_, $$1: Internal.Mirror_): Internal.BlockState;
        wasExploded($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Explosion_): void;
        getName(): Internal.MutableComponent;
        updateEntityAfterFallOn($$0: Internal.BlockGetter_, $$1: Internal.Entity_): void;
        animateTick($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        customShouldDrawFace(view: Internal.BlockGetter_, thisState: Internal.BlockState_, sideState: Internal.BlockState_, thisPos: BlockPos_, sidePos: BlockPos_, side: Internal.Direction_): Optional<boolean>;
        axiom$getResourceLocation(): ResourceLocation;
        arch$registryName(): ResourceLocation;
        axiom$getProperties(): Internal.Collection<any>;
        getBlockBuilder(): Internal.BlockBuilder;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        isSignalSource($$0: Internal.BlockState_): boolean;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number): void;
        /**
         * @deprecated
        */
        attack($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): void;
        /**
         * @deprecated
        */
        getShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        shouldAttemptToCull(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        onProjectileHit($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockHitResult_, $$3: Internal.Projectile_): void;
        static stateById($$0: number): Internal.BlockState;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): Internal.List<Internal.ItemStack>;
        requiredFeatures(): Internal.FeatureFlagSet;
        hashCode(): number;
        axiom$defaultCustomState(): Internal.CustomBlockState;
        setCanCull(canCull: boolean): void;
        /**
         * @deprecated
        */
        isOcclusionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static getId($$0: Internal.BlockState_): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.material.Fluid)"($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        static pushEntitiesUp($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        isPathfindable($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.PathComputationType_): boolean;
        setSoundType(arg0: SoundType_): void;
        handler$cef000$betterend$be_getDroppedStacks(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, info: Internal.CallbackInfoReturnable_<any>): void;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_): Internal.List<Internal.ItemStack>;
        /**
         * @deprecated
        */
        onRemove($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        cantCullAgainst(state: Internal.BlockState_): boolean;
        setHasCollision(arg0: boolean): void;
        static shouldRenderFace($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_, $$4: BlockPos_): boolean;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        spawnAfterBreak($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.ItemStack_, $$4: boolean): void;
        set randomTickCallback(callback: Internal.Consumer_<any>)
        get descriptionId(): string
        get settings(): Internal.BlockBehaviour$Properties
        get explosionResistance(): number
        get typeData(): Internal.CompoundTag
        set friction(arg0: number)
        get jumpFactor(): number
        get speedFactor(): number
        get properties(): Internal.BlockBehaviour$Properties
        get class(): typeof any
        get maxVerticalOffset(): number
        get stateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>
        set blockBuilder(b: Internal.BlockBuilder_)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        set speedFactor(arg0: number)
        set explosionResistance(arg0: number)
        get id(): string
        get lootTable(): ResourceLocation
        get friction(): number
        set lightEmission(v: number)
        set jumpFactor(arg0: number)
        set destroySpeed(v: number)
        get maxHorizontalOffset(): number
        set isRandomlyTicking(arg0: boolean)
        set nameKey(arg0: string)
        get name(): Internal.MutableComponent
        get blockBuilder(): Internal.BlockBuilder
        get idLocation(): ResourceLocation
        get mod(): string
        set canCull(canCull: boolean)
        set soundType(arg0: SoundType_)
        set hasCollision(arg0: boolean)
        static readonly SNOWY: (Internal.BooleanProperty) & (Internal.BooleanProperty);
    }
    type SnowyDirtBlock_ = SnowyDirtBlock;
    class NoiseStripFeature extends Feature<Internal.NoiseStripConfig> {
        constructor(codec: Internal.Codec_<Internal.NoiseStripConfig>)
        place($$0: Internal.NoiseStripConfig_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        getClass(): typeof any;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.NoiseStripConfig, Feature<Internal.NoiseStripConfig>>>;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        place(featurePlaceContext: Internal.FeaturePlaceContext_<Internal.NoiseStripConfig>): boolean;
        wait(): void;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        get class(): typeof any
    }
    type NoiseStripFeature_ = NoiseStripFeature;
    /**
     * @deprecated
     * This class is marked to be removed in future!
    */
    interface DumpHandler <T extends Internal.AbstractContainerMenu, D extends me.shedaniel.rei.api.common.display.Display> {
        getOccupiedSlotWithRoomForStack(stack: Internal.ItemStack_, inventoryStacks: Internal.Iterable_<me.shedaniel.rei.api.common.transfer.info.stack.SlotAccessor>): me.shedaniel.rei.api.common.transfer.info.stack.SlotAccessor;
        getEmptySlot(inventoryStacks: Internal.Iterable_<me.shedaniel.rei.api.common.transfer.info.stack.SlotAccessor>): me.shedaniel.rei.api.common.transfer.info.stack.SlotAccessor;
        canStackAddMore(existingStack: Internal.ItemStack_, stack: Internal.ItemStack_): boolean;
        abstract dump(arg0: Internal.MenuInfoContext_<T, any, D>, arg1: Internal.ItemStack_): boolean;
        (arg0: Internal.MenuInfoContext<T, any, D>, arg1: Internal.ItemStack): boolean;
    }
    type DumpHandler_<T extends Internal.AbstractContainerMenu, D extends me.shedaniel.rei.api.common.display.Display> = DumpHandler<T, D> | ((arg0: Internal.MenuInfoContext<T, any, D>, arg1: Internal.ItemStack)=> boolean);
    class Display$ItemDisplay$ItemRenderState extends Internal.Record {
        constructor($$0: Internal.ItemStack_, $$1: Internal.ItemDisplayContext_)
        getClass(): typeof any;
        itemTransform(): Internal.ItemDisplayContext;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals($$0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        itemStack(): Internal.ItemStack;
        get class(): typeof any
    }
    type Display$ItemDisplay$ItemRenderState_ = Display$ItemDisplay$ItemRenderState;
    class FallenTreeConfiguration implements Internal.FeatureConfiguration {
        constructor(stump: Internal.BlockStateProvider_, log: Internal.BlockStateProvider_, leaves: Internal.BlockStateProvider_, minSize: number, sizeVar: number, hasLeaves: boolean)
        getClass(): typeof any;
        hashCode(): number;
        getFeatures(): Internal.Stream<Internal.ConfiguredFeature<any, any>>;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        get features(): Internal.Stream<Internal.ConfiguredFeature<any, any>>
        readonly sizeVariation: number;
        readonly hasLeaves: boolean;
        readonly foliageProvider: Internal.BlockStateProvider;
        static readonly CODEC: Internal.Codec<Internal.FallenTreeConfiguration>;
        readonly trunkProvider: Internal.BlockStateProvider;
        readonly stumpProvider: Internal.BlockStateProvider;
        readonly minimumSize: number;
    }
    type FallenTreeConfiguration_ = FallenTreeConfiguration;
    abstract class SpecialFlowerBlockEntity extends Internal.BlockEntity implements Internal.FloatingFlowerProvider {
        constructor(type: Internal.BlockEntityType_<any>, pos: BlockPos_, state: Internal.BlockState_)
        handler$efn000$collective$setLevel(level: Internal.Level_, ci: Internal.CallbackInfo_): void;
        emf$hasVehicle(): boolean;
        method_11007(cmp: Internal.CompoundTag_): void;
        etf$getType(): Internal.EntityType<any>;
        emf$getVelocity(): Vec3d;
        getSecondaryRadius(): Internal.RadiusDescriptor;
        etf$isBlockEntity(): boolean;
        /**
         * @deprecated
        */
        setBlockState($$0: Internal.BlockState_): void;
        hasAttached(type: Internal.AttachmentType_<any>): boolean;
        load(cmp: Internal.CompoundTag_): void;
        setChanged(): void;
        setCulled(value: boolean): void;
        saveWithoutMetadata(): Internal.CompoundTag;
        setTimeout(): void;
        getAttachedOrSet<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        removeAttached<A>(type: Internal.AttachmentType_<A>): A;
        isOutOfCamera(): boolean;
        isFloating(): boolean;
        emf$prevZ(): number;
        etf$canBeBright(): boolean;
        setRemoved(): void;
        asComponentProvider(): Internal.ComponentProvider;
        emf$isOnGround(): boolean;
        abstract getRadius(): Internal.RadiusDescriptor;
        handler$efn000$collective$setRemoved(ci: Internal.CallbackInfo_): void;
        etf$getEntityKey(): string;
        etf$getPose(): Internal.Pose;
        isCulled(): boolean;
        isOnSpecialSoil(): boolean;
        readFromPacketNBT(cmp: Internal.CompoundTag_): void;
        getType(): Internal.BlockEntityType<any>;
        static transfer(original: Internal.AttachmentTarget_, target: Internal.AttachmentTarget_, isDeath: boolean): void;
        etf$getOptifineId(): number;
        getCustomData(): Internal.CompoundTag;
        getClass(): typeof any;
        emf$isInvisible(): boolean;
        static getPosFromTag($$0: Internal.CompoundTag_): BlockPos;
        etf$distanceTo(entity: Internal.Entity_): number;
        emf$isSprinting(): boolean;
        hasAnyComparatorNearby(): boolean;
        saveToItem($$0: Internal.ItemStack_): void;
        invokeWriteNbt(arg0: Internal.CompoundTag_): void;
        "deserializeNBT(net.minecraft.nbt.CompoundTag)"(nbt: Internal.CompoundTag_): void;
        static addEntityType($$0: Internal.CompoundTag_, $$1: Internal.BlockEntityType_<any>): void;
        emf$isInLava(): boolean;
        "deserializeNBT(net.minecraft.nbt.Tag)"(arg0: Internal.Tag_): void;
        onComparatorAdded(direction: Internal.Direction_, offset: number): void;
        getUpdatePacket(): Internal.Packet<Internal.ClientGamePacketListener>;
        fabric_hasPersistentAttachments(): boolean;
        clearRemoved(): void;
        emf$isWet(): boolean;
        owo$setCachedState(arg0: Internal.BlockState_): void;
        fabric_getAttachments(): Internal.Map<any, any>;
        sync(): void;
        toString(): string;
        triggerEvent($$0: number, $$1: number): boolean;
        emf$isGlowing(): boolean;
        hasLevel(): boolean;
        notifyAll(): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        etf$getScoreboardTeam(): Internal.Team;
        emf$getZ(): number;
        emitParticle(options: Internal.ParticleOptions_, xOffset: number, yOffset: number, zOffset: number, xSpeed: number, ySpeed: number, zSpeed: number): void;
        setPlacedBy(level: Internal.Level_, pos: BlockPos_, state: Internal.BlockState_, placer: Internal.LivingEntity_, stack: Internal.ItemStack_): void;
        writeToPacketNBT(cmp: Internal.CompoundTag_): void;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>, initializer: Internal.Supplier_<A>): A;
        static commonTick(level: Internal.Level_, worldPosition: BlockPos_, state: Internal.BlockState_, self: Internal.SpecialFlowerBlockEntity_): void;
        wait(arg0: number): void;
        etf$getItemsEquipped(): Internal.Iterable<any>;
        getAttachedOrThrow<A>(type: Internal.AttachmentType_<A>): A;
        etf$getVelocity(): Vec3d;
        getAttached(type: Internal.AttachmentType_<any>): any;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        etf$getWorld(): Internal.Level;
        getUpdateTag(): Internal.CompoundTag;
        getRenderAttachmentData(): any;
        emf$getYaw(): number;
        modifyAttached<A>(type: Internal.AttachmentType_<A>, modifier: Internal.UnaryOperator_<A>): A;
        setLevel($$0: Internal.Level_): void;
        notify(): void;
        getModulatedDelay(): number;
        isOvergrowthAffected(): boolean;
        getBlockPos(): BlockPos;
        isRemoved(): boolean;
        etf$getNbt(): Internal.CompoundTag;
        emf$isSneaking(): boolean;
        etf$getBlockPos(): BlockPos;
        onLoad(): void;
        fillCrashReportCategory($$0: Internal.CrashReportCategory_): void;
        emf$prevPitch(): number;
        etf$getBlockY(): number;
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        etf$getHandItems(): Internal.Iterable<any>;
        etf$getArmorItems(): Internal.Iterable<any>;
        emf$getY(): number;
        invalidateCaps(): void;
        emf$prevX(): number;
        getBlockState(): Internal.BlockState;
        handler$zzl000$porting_lib_base$port_lib$invalidate(ci: Internal.CallbackInfo_): void;
        toComponentPacket(key: Internal.ComponentKey_<any>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        setFloating(floating: boolean): void;
        getAttachedOrGet<A>(type: Internal.AttachmentType_<A>, defaultValue: Internal.Supplier_<A>): A;
        emf$age(): number;
        etf$hasCustomName(): boolean;
        static loadStatic($$0: BlockPos_, $$1: Internal.BlockState_, $$2: Internal.CompoundTag_): Internal.BlockEntity;
        wait(): void;
        emf$isTouchingWater(): boolean;
        emf$getVariableMap(): Internal.Object2FloatOpenHashMap<any>;
        getComponentContainer(): Internal.ComponentContainer;
        getComparatorSignal(): number;
        etf$getCustomName(): net.minecraft.network.chat.Component;
        fabric_writeAttachmentsToNbt(nbt: Internal.CompoundTag_): void;
        saveWithId(): Internal.CompoundTag;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>): A;
        setOutOfCamera(value: boolean): void;
        wait(arg0: number, arg1: number): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        getLevel(): Internal.Level;
        onlyOpCanSetNbt(): boolean;
        port_lib$saveMetadata(arg0: Internal.CompoundTag_): void;
        serializeNBT(): Internal.Tag;
        getEffectivePos(): BlockPos;
        saveWithFullMetadata(): Internal.CompoundTag;
        emf$prevY(): number;
        emf$getX(): number;
        deserializeNBT(arg0: Internal.Tag_): void;
        emf$isOnFire(): boolean;
        etf$getUuid(): Internal.UUID;
        getRecipientsForComponentSync(): Internal.Iterable<any>;
        deserializeNBT(state: Internal.BlockState_, nbt: Internal.CompoundTag_): void;
        isForcedVisible(): boolean;
        emf$hasPassengers(): boolean;
        setAttached(type: Internal.AttachmentType_<any>, value: any): any;
        deserializeNBT(nbt: Internal.CompoundTag_): void;
        fabric_readAttachmentsFromNbt(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        emf$getTypeString(): string;
        getAttachedOrElse<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        getRenderData(): any;
        emf$getPitch(): number;
        getFloatingData(): Internal.FloatingFlower;
        emf$isAlive(): boolean;
        equals(arg0: any): boolean;
        get secondaryRadius(): Internal.RadiusDescriptor
        /**
         * @deprecated
        */
        set blockState($$0: Internal.BlockState_)
        set culled(value: boolean)
        get outOfCamera(): boolean
        get floating(): boolean
        get radius(): Internal.RadiusDescriptor
        get culled(): boolean
        get onSpecialSoil(): boolean
        get type(): Internal.BlockEntityType<any>
        get customData(): Internal.CompoundTag
        get class(): typeof any
        get updatePacket(): Internal.Packet<Internal.ClientGamePacketListener>
        get updateTag(): Internal.CompoundTag
        get renderAttachmentData(): any
        set level($$0: Internal.Level_)
        get modulatedDelay(): number
        get overgrowthAffected(): boolean
        get blockPos(): BlockPos
        get removed(): boolean
        get blockState(): Internal.BlockState
        set floating(floating: boolean)
        get componentContainer(): Internal.ComponentContainer
        get comparatorSignal(): number
        set outOfCamera(value: boolean)
        get level(): Internal.Level
        get effectivePos(): BlockPos
        get recipientsForComponentSync(): Internal.Iterable<any>
        get forcedVisible(): boolean
        get renderData(): any
        get floatingData(): Internal.FloatingFlower
        overgrowthBoost: boolean;
        static readonly MYCELIUM_DELAY: (10) & (number);
        static readonly TAG_TICKS_EXISTED: ("ticksExisted") & (string);
        ticksExisted: number;
        static readonly PODZOL_DELAY: (5) & (number);
        overgrowth: boolean;
    }
    type SpecialFlowerBlockEntity_ = SpecialFlowerBlockEntity;
    class FluidComponents$1 implements Internal.RecipeComponent<Internal.InputFluid> {
        isInput(recipe: Internal.RecipeJS_, value: Internal.InputFluid_, match: Internal.ReplacementMatch_): boolean;
        getClass(): typeof any;
        write(recipe: Internal.RecipeJS_, value: Internal.InputFluid_): Internal.JsonElement;
        asMap<K>(key: Internal.RecipeComponent_<K>): Internal.RecipeComponent<Internal.TinyMap<K, Internal.InputFluid>>;
        or<O>(other: Internal.RecipeComponent_<O>): Internal.OrRecipeComponent<Internal.InputFluid, O>;
        write(arg0: Internal.RecipeJS_, arg1: any): Internal.JsonElement;
        replaceInput(recipe: Internal.RecipeJS_, original: Internal.InputFluid_, match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): Internal.InputFluid;
        readFromJson(recipe: Internal.RecipeJS_, cv: Internal.RecipeComponentValue_<Internal.InputFluid>, json: Internal.JsonObject_): void;
        "isInput(dev.latvian.mods.kubejs.recipe.RecipeJS,dev.latvian.mods.kubejs.fluid.InputFluid,dev.latvian.mods.kubejs.recipe.ReplacementMatch)"(recipe: Internal.RecipeJS_, value: Internal.InputFluid_, match: Internal.ReplacementMatch_): boolean;
        role(): Internal.ComponentRole;
        /**
         * Returns a new RecipeComponent that applies the mappingFrom function after the component writes to json, before that json is saved
        */
        mapOut(mappingFrom: Internal.UnaryOperator_<Internal.JsonElement>): Internal.MappingRecipeComponent<Internal.InputFluid>;
        notify(): void;
        componentClass(): typeof any;
        wait(arg0: number, arg1: number): void;
        asPatternKey(): Internal.RecipeComponent<Internal.TinyMap<string, Internal.InputFluid>>;
        constructorDescription(ctx: Internal.DescriptionContext_): Internal.TypeDescJS;
        componentType(): string;
        checkEmpty(arg0: Internal.RecipeKey_<any>, arg1: any): string;
        checkEmpty(key: Internal.RecipeKey_<Internal.InputFluid>, value: Internal.InputFluid_): string;
        static builder(): Internal.RecipeComponentBuilder;
        toString(): string;
        orSelf(): Internal.RecipeComponent<Internal.InputFluid>;
        hasPriority(recipe: Internal.RecipeJS_, from: any): boolean;
        notifyAll(): void;
        /**
         * Returns a new RecipeComponent that applies the mappingTo function to the input before it is passed to this component to be read
        */
        mapIn(mappingTo: Internal.UnaryOperator_<any>): Internal.MappingRecipeComponent<Internal.InputFluid>;
        and<O>(other: Internal.RecipeComponent_<O>): Internal.AndRecipeComponent<Internal.InputFluid, O>;
        checkValueHasChanged(oldValue: Internal.InputFluid_, newValue: Internal.InputFluid_): boolean;
        isOutput(recipe: Internal.RecipeJS_, value: Internal.InputFluid_, match: Internal.ReplacementMatch_): boolean;
        static builder(...key: Internal.RecipeKey_<any>[]): Internal.RecipeComponentBuilder;
        /**
         * Returns a new RecipeComponent that applies the mappingTo function to the input before it is passed to this component to be read, and the mappingFrom function after the component writes to json, before that json is saved
        */
        map(mappingTo: Internal.UnaryOperator_<any>, mappingFrom: Internal.UnaryOperator_<Internal.JsonElement>): Internal.MappingRecipeComponent<Internal.InputFluid>;
        read(arg0: Internal.RecipeJS_, arg1: any): any;
        "checkEmpty(dev.latvian.mods.kubejs.recipe.RecipeKey,java.lang.Object)"(arg0: Internal.RecipeKey_<any>, arg1: any): string;
        "checkEmpty(dev.latvian.mods.kubejs.recipe.RecipeKey,dev.latvian.mods.kubejs.fluid.InputFluid)"(key: Internal.RecipeKey_<Internal.InputFluid>, value: Internal.InputFluid_): string;
        hashCode(): number;
        "isInput(dev.latvian.mods.kubejs.recipe.RecipeJS,java.lang.Object,dev.latvian.mods.kubejs.recipe.ReplacementMatch)"(arg0: Internal.RecipeJS_, arg1: any, arg2: Internal.ReplacementMatch_): boolean;
        /**
         * Returns a new RecipeComponent that maps the keys in a JsonObject according to the provided map, both before the json gets passed to the component and after the component returns a written json object.
         * The mappings should be provided in the format `{recipe: "component"}` where recipe is the key as in the recipe, and component is the key as how the RecipeComponent expects it.
         * Any keys not included in the provided map will be ignored, and any keys in the provided map that are not in either the input object or output object will be ignored.
         * Note that if the input or output is not a JsonObject (ie its an ItemStack, or it is a JsonPrimitive) then that will pass through this without being modified.
         * If you wish to handle those situations use the actual map function
        */
        simpleMap(mappings: any): Internal.SimpleMappingRecipeComponent<Internal.InputFluid>;
        asArrayOrSelf(): Internal.ArrayRecipeComponent<Internal.InputFluid>;
        wait(): void;
        replaceOutput(recipe: Internal.RecipeJS_, original: Internal.InputFluid_, match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): Internal.InputFluid;
        wait(arg0: number): void;
        "write(dev.latvian.mods.kubejs.recipe.RecipeJS,java.lang.Object)"(arg0: Internal.RecipeJS_, arg1: any): Internal.JsonElement;
        asArray(): Internal.ArrayRecipeComponent<Internal.InputFluid>;
        writeToJson(recipe: Internal.RecipeJS_, cv: Internal.RecipeComponentValue_<Internal.InputFluid>, json: Internal.JsonObject_): void;
        readFromMap(recipe: Internal.RecipeJS_, cv: Internal.RecipeComponentValue_<Internal.InputFluid>, map: Internal.Map_<any, any>): void;
        isInput(arg0: Internal.RecipeJS_, arg1: any, arg2: Internal.ReplacementMatch_): boolean;
        key(name: string): Internal.RecipeKey<Internal.InputFluid>;
        equals(arg0: any): boolean;
        "write(dev.latvian.mods.kubejs.recipe.RecipeJS,dev.latvian.mods.kubejs.fluid.InputFluid)"(recipe: Internal.RecipeJS_, value: Internal.InputFluid_): Internal.JsonElement;
        get class(): typeof any
    }
    type FluidComponents$1_ = FluidComponents$1;
    class LlamaSpit extends Internal.Projectile {
        constructor($$0: Internal.EntityType_<Internal.LlamaSpit>, $$1: Internal.Level_)
        constructor($$0: Internal.Level_, $$1: Internal.Llama_)
        litematica_setWorld(arg0: Internal.Level_): void;
        handler$hak000$gobber2$gobberOccludeVibrationSignals(cir: Internal.CallbackInfoReturnable_<any>): void;
        isInWall(): boolean;
        etf$getType(): Internal.EntityType<any>;
        getAllSlots(): Internal.Iterable<Internal.ItemStack>;
        getUpVector($$0: number): Vec3d;
        gameEvent($$0: Internal.GameEvent_, $$1: Internal.Entity_): void;
        remove($$0: Internal.Entity$RemovalReason_): void;
        getBlockZ(): number;
        isSuppressingBounce(): boolean;
        dampensVibrations(): boolean;
        hasAttached(type: Internal.AttachmentType_<any>): boolean;
        isSilent(): boolean;
        "playSound(net.minecraft.sounds.SoundEvent)"(id: Internal.SoundEvent_): void;
        setCulled(value: boolean): void;
        getPitch(): number;
        isOnFire(): boolean;
        rotate($$0: Internal.Rotation_): number;
        getPositionCodec(): Internal.VecDeltaCodec;
        getPassengersAndSelf(): Internal.Stream<any>;
        setMaxUpStep($$0: number): void;
        updateFluidHeightAndDoFluidPushing($$0: Internal.TagKey_<Internal.Fluid>, $$1: number): boolean;
        setPosition(x: number, y: number, z: number): void;
        runCommandSilent(command: string): number;
        chunkPosition(): Internal.ChunkPos;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        emf$isOnGround(): boolean;
        gameEvent($$0: Internal.GameEvent_): void;
        alwaysAccepts(): boolean;
        isShiftKeyDown(): boolean;
        setUUID($$0: Internal.UUID_): void;
        checkBelowWorld(): void;
        isVisuallyCrawling(): boolean;
        setMotionZ(z: number): void;
        handler$ieb000$lambdynlights$onRemove(ci: Internal.CallbackInfo_): void;
        "deserializeNBT(net.minecraft.nbt.Tag)"(arg0: Internal.Tag_): void;
        canFreeze(): boolean;
        ignoreExplosion(): boolean;
        port_lib$setRemovalReason(arg0: Internal.Entity$RemovalReason_): void;
        teleportRelative($$0: number, $$1: number, $$2: number): void;
        getBlockY(): number;
        getIsInsideStructureTracker(): Internal.IsInsideStructureTracker;
        isSpectator(): boolean;
        pehkui_setScaleCache(scaleCache: Internal.ScaleData_[]): void;
        isInWaterOrBubble(): boolean;
        spawnAtLocation($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        getPersistentData(): Internal.CompoundTag;
        getPortalCooldown(): number;
        emf$isGlowing(): boolean;
        getItem(): Internal.ItemStack;
        getRandomZ($$0: number): number;
        pehkui_getOnGround(): boolean;
        causeFallDamage($$0: number, $$1: number, $$2: DamageSource_): boolean;
        getFusionModel(layerIndex: number): Internal.Triple<any, any, any>;
        getDynamicLightChunksToRebuild(forced: boolean): Internal.LongSet;
        getPosition($$0: number): Vec3d;
        setRemoved($$0: Internal.Entity$RemovalReason_): void;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>, initializer: Internal.Supplier_<A>): A;
        getDistanceSq($$0: number, $$1: number, $$2: number): number;
        isInWaterRainOrBubble(): boolean;
        getRemovalReason(): Internal.Entity$RemovalReason;
        wait(arg0: number): void;
        isIgnoringBlockTriggers(): boolean;
        etf$getItemsEquipped(): Internal.Iterable<any>;
        getHandHoldingItemAngle($$0: Internal.Item_): Vec3d;
        etf$getVelocity(): Vec3d;
        hex$markHurt(): void;
        distanceToSqr($$0: Vec3d_): number;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        resetFallDistance(): void;
        canSprint(): boolean;
        modifyAttached<A>(type: Internal.AttachmentType_<A>, modifier: Internal.UnaryOperator_<A>): A;
        blockPosition(): BlockPos;
        isSteppingCarefully(): boolean;
        setBoundingBox($$0: Internal.AABB_): void;
        isAmbientCreature(): boolean;
        "spawnAtLocation(net.minecraft.world.item.ItemStack,float)"($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        getBlockX(): number;
        /**
         * @deprecated
        */
        getLightLevelDependentMagicValue(): number;
        getEncodeId(): string;
        getY($$0: number): number;
        emf$prevPitch(): number;
        getBlock(): Internal.BlockContainerJS;
        getNbt(): Internal.CompoundTag;
        etf$getHandItems(): Internal.Iterable<any>;
        setInvisible($$0: boolean): void;
        etf$getArmorItems(): Internal.Iterable<any>;
        getName(): net.minecraft.network.chat.Component;
        isSubmergedInLoosely(tag: Internal.TagKey_<any>): boolean;
        onGround(): boolean;
        getDynamicLightY(): number;
        getControlledVehicle(): Internal.Entity;
        isOnSameTeam($$0: Internal.Entity_): boolean;
        onInsideBubbleColumn($$0: boolean): void;
        attack($$0: DamageSource_, $$1: number): boolean;
        tick(): void;
        getEyePosition(): Vec3d;
        getEyeHeight(): number;
        hasPassenger($$0: Internal.Predicate_<Internal.Entity>): boolean;
        getYaw(): number;
        emf$isTouchingWater(): boolean;
        emf$getVariableMap(): Internal.Object2FloatOpenHashMap<any>;
        getComponentContainer(): Internal.ComponentContainer;
        hasPermissions($$0: number): boolean;
        getDynamicLightPrevZ(): number;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        pehkui_readScaleNbt(nbt: Internal.CompoundTag_): void;
        setCustomNameVisible($$0: boolean): void;
        isAlliedTo($$0: Internal.Team_): boolean;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>): A;
        setOutOfCamera(value: boolean): void;
        getControllingPassenger(): Internal.LivingEntity;
        getRemainingFireTicks(): number;
        getScriptType(): Internal.ScriptType;
        onlyOpCanSetNbt(): boolean;
        startRiding($$0: Internal.Entity_): boolean;
        saveWithoutId($$0: Internal.CompoundTag_): Internal.CompoundTag;
        getForward(): Vec3d;
        tcdcommons_getCustomData(): Internal.GenericProperties<any>;
        fireImmune(): boolean;
        addMotion($$0: number, $$1: number, $$2: number): void;
        getMaxFallDistance(): number;
        getZ($$0: number): number;
        getId(): number;
        pehkui_isFirstUpdate(): boolean;
        canBeHitByProjectile(): boolean;
        getTicksFrozen(): number;
        wrapWithCondition$kom000$porting_lib_entity$port_lib$captureDrops(level: Internal.Level_, entity: Internal.Entity_): boolean;
        getRecipientsForComponentSync(): Internal.Iterable<any>;
        getRandomX($$0: number): number;
        getDynamicLightZ(): number;
        getEyeY(): number;
        spawnAtLocation($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        pick($$0: number, $$1: number, $$2: boolean): Internal.HitResult;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        fabric_readAttachmentsFromNbt(nbt: Internal.CompoundTag_): void;
        getBoundingBox(): Internal.AABB;
        changeDimension(p_20118_: Internal.ServerLevel_, teleporter: Internal.ITeleporter_): Internal.Entity;
        isInWaterOrRain(): boolean;
        isDescending(): boolean;
        emf$getPitch(): number;
        setItemSlot($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_): void;
        getYHeadRot(): number;
        handler$cbi000$besmirchment$isTeammate(other: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>): void;
        equals($$0: any): boolean;
        getViewYRot($$0: number): number;
        fabric_setCustomTeleportTarget(teleportTarget: Internal.PortalInfo_): void;
        dismountsUnderwater(): boolean;
        frameworkGetDataHolder(): com.mrcrayfish.framework.entity.sync.DataHolder;
        playerTouch($$0: Internal.Player_): void;
        addTag($$0: string): boolean;
        getAddEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>;
        getEyeHeight($$0: Internal.Pose_): number;
        syncPacketPositionCodec($$0: number, $$1: number, $$2: number): void;
        setOwner($$0: Internal.Entity_): void;
        callIsBeingRainedOn(): boolean;
        getTeam(): Internal.Team;
        shouldRenderAtSqrDistance($$0: number): boolean;
        getAttachedOrSet<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        damageSources(): Internal.DamageSources;
        removeAttached<A>(type: Internal.AttachmentType_<A>): A;
        setTicksFrozen($$0: number): void;
        recreateFromPacket($$0: Internal.ClientboundAddEntityPacket_): void;
        getMyRidingOffset(): number;
        dismountTo($$0: number, $$1: number, $$2: number): void;
        bettertrims$getDeflected(): boolean;
        setDeltaMovement($$0: Vec3d_): void;
        getLeashOffset($$0: number): Vec3d;
        etf$getEntityKey(): string;
        etf$getPose(): Internal.Pose;
        hasCustomName(): boolean;
        captureDrops(): Internal.Collection<any>;
        isCulled(): boolean;
        isLiving(): boolean;
        isGlowing(): boolean;
        getX(): number;
        isVehicle(): boolean;
        static transfer(original: Internal.AttachmentTarget_, target: Internal.AttachmentTarget_, isDeath: boolean): void;
        etf$getOptifineId(): number;
        dynamicLightWorld(): Internal.Level;
        getLeashOffset(): Vec3d;
        resetDynamicLight(): void;
        isShot(): boolean;
        isAttackable(): boolean;
        spawnAtLocation($$0: Internal.ItemStack_): Internal.ItemEntity;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        thunderHit($$0: Internal.ServerLevel_, $$1: Internal.LightningBolt_): void;
        setIsInPowderSnow($$0: boolean): void;
        etf$distanceTo(entity: Internal.Entity_): number;
        doEnchantDamageEffects($$0: Internal.LivingEntity_, $$1: Internal.Entity_): void;
        setCustomName($$0: net.minecraft.network.chat.Component_): void;
        getSlot($$0: number): Internal.SlotAccess;
        lambdynlights$scheduleTrackedChunksRebuild(renderer: Internal.LevelRenderer_): void;
        "deserializeNBT(net.minecraft.nbt.CompoundTag)"(nbt: Internal.CompoundTag_): void;
        emf$isInLava(): boolean;
        pehkui_constructScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        handler$hak000$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        getTeamId(): string;
        stopSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isUnderWater(): boolean;
        stopRiding(): void;
        isCustomNameVisible(): boolean;
        isSupportedBy($$0: BlockPos_): boolean;
        getPistonPushReaction(): Internal.PushReaction;
        getX($$0: number): number;
        lookAt($$0: Internal.EntityAnchorArgument$Anchor_, $$1: Vec3d_): void;
        getLuminance(): number;
        callUnsetRemoved(): void;
        getSelfAndPassengers(): Internal.Stream<any>;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        getDeltaMovement(): Vec3d;
        collide($$0: Vec3d_): Vec3d;
        getMotionX(): number;
        "onSyncedDataUpdated(java.util.List)"($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        shoot($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        hasPassenger($$0: Internal.Entity_): boolean;
        be_getTravelerState(): Internal.TravelerState;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        hasIndirectPassenger($$0: Internal.Entity_): boolean;
        getDynamicLightX(): number;
        getEntityData(): Internal.SynchedEntityData;
        setSecondsOnFire($$0: number): void;
        moveTo($$0: number, $$1: number, $$2: number): void;
        emf$getZ(): number;
        "getDisplayName()"(): net.minecraft.network.chat.Component;
        handleInsidePortal($$0: BlockPos_): void;
        setMotion($$0: number, $$1: number, $$2: number): void;
        playSound($$0: Internal.SoundEvent_): void;
        absMoveTo($$0: number, $$1: number, $$2: number): void;
        isOnRails(): boolean;
        getAttachedOrThrow<A>(type: Internal.AttachmentType_<A>): A;
        handler$ikg000$lithium$tryShortcutFluidPushing(tag: Internal.TagKey_<any>, speed: number, cir: Internal.CallbackInfoReturnable_<any>, box: Internal.AABB_, x1: number, x2: number, y1: number, y2: number, z1: number, z2: number, zero: number): void;
        handler$hak000$gobber2$setFrozenTicks(frozenTicks: number, ci: Internal.CallbackInfo_): void;
        restoreFrom($$0: Internal.Entity_): void;
        markFusionRecomputeModels(): void;
        getDimensionChangingDelay(): number;
        isPeacefulCreature(): boolean;
        setOnGround($$0: boolean): void;
        emf$getYaw(): number;
        handler$cbi000$besmirchment$getScoreboardTeam(cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDynamicLuminance(): number;
        setPos($$0: number, $$1: number, $$2: number): void;
        setYaw($$0: number): void;
        getPickRadius(): number;
        notify(): void;
        getVehicle(): Internal.Entity;
        isEffectiveAi(): boolean;
        handler$kom000$porting_lib_entity$port_lib$startRiding(entity: Internal.Entity_, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        startRiding($$0: Internal.Entity_, $$1: boolean): boolean;
        getStringUuid(): string;
        isRemoved(): boolean;
        emf$isSneaking(): boolean;
        setSwimming($$0: boolean): void;
        teleportToWithTicket($$0: number, $$1: number, $$2: number): void;
        fillCrashReportCategory($$0: Internal.CrashReportCategory_): void;
        getRotationVector(): Internal.Vec2;
        refreshDimensions(): void;
        pehkui_writeScaleNbt(nbt: Internal.CompoundTag_): Internal.CompoundTag;
        self(): Internal.Entity;
        etf$getBlockY(): number;
        isSprinting(): boolean;
        "spawnAtLocation(net.minecraft.world.level.ItemLike)"($$0: Internal.ItemLike_): Internal.ItemEntity;
        getMotionY(): number;
        canCollideWith($$0: Internal.Entity_): boolean;
        setLuminance(luminance: number): void;
        setShiftKeyDown($$0: boolean): void;
        getEyePosition($$0: number): Vec3d;
        getPassengers(): Internal.EntityArrayList;
        getBlockExplosionResistance($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.FluidState_, $$5: number): number;
        handler$ldh000$puzzleslib$spawnAtLocation(stack: Internal.ItemStack_, offsetY: number, callback: Internal.CallbackInfoReturnable_<any>, itemEntity: Internal.ItemEntity_): void;
        getZ(): number;
        canSpawnSprintParticle(): boolean;
        "moveTo(net.minecraft.core.BlockPos,float,float)"($$0: BlockPos_, $$1: number, $$2: number): void;
        teleportTo($$0: number, $$1: number, $$2: number): void;
        shootFromRotation($$0: Internal.Entity_, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): void;
        handler$zbk000$porting_lib_base$port_lib$spawnSprintParticle(ci: Internal.CallbackInfo_, pos: BlockPos_, state: Internal.BlockState_): void;
        getServer(): Internal.MinecraftServer;
        moveRelative($$0: number, $$1: Vec3d_): void;
        getFirstPassenger(): Internal.Entity;
        saveAsPassenger($$0: Internal.CompoundTag_): boolean;
        static gatherClosestChunks(chunks: Internal.LongSet_, x: number, y: number, z: number): void;
        handler$kom000$porting_lib_entity$afterSave(nbt: Internal.CompoundTag_, cir: Internal.CallbackInfoReturnable_<any>): void;
        interact($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        getDismountLocationForPassenger($$0: Internal.LivingEntity_): Vec3d;
        checkLeftOwner(): boolean;
        checkSlowFallDistance(): void;
        getSoundSource(): Internal.SoundSource;
        setFabricBalmData(tag: Internal.CompoundTag_): void;
        removeAfterChangingDimensions(): void;
        getPose(): Internal.Pose;
        touchingUnloadedChunk(): boolean;
        getLookAngle(): Vec3d;
        setPositionAndRotation($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        emf$isOnFire(): boolean;
        getMotionZ(): number;
        etf$getUuid(): Internal.UUID;
        removeVehicle(): void;
        isInvisible(): boolean;
        shouldFusionRecomputeModel(layerIndex: number): boolean;
        is($$0: Internal.Entity_): boolean;
        setZ(z: number): void;
        ejectPassengers(): void;
        getY(): number;
        deserializeNBT(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        updateDynamicLightPreviousCoordinates(): void;
        getProfile(): Internal.GameProfile;
        static setViewScale($$0: number): void;
        emf$isAlive(): boolean;
        setLevelCallback($$0: Internal.EntityInLevelCallback_): void;
        showVehicleHealth(): boolean;
        getDistance(pos: BlockPos_): number;
        playSound($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        emf$getVelocity(): Vec3d;
        etf$isBlockEntity(): boolean;
        shouldUpdateDynamicLight(): boolean;
        startSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isOnScoreboardTeam(teamId: string): boolean;
        isPushedByFluid(): boolean;
        localvar$bbb000$architectury$modifyLevelCallback_setLevelCallback(callback: Internal.EntityInLevelCallback_): Internal.EntityInLevelCallback;
        position(): Vec3d;
        setTimeout(): void;
        displayFireAnimation(): boolean;
        turn($$0: number, $$1: number): void;
        isOutOfCamera(): boolean;
        getAirSupply(): number;
        getRopeHoldPosition($$0: number): Vec3d;
        copyPosition($$0: Internal.Entity_): void;
        "hasPassenger(net.minecraft.world.entity.Entity)"($$0: Internal.Entity_): boolean;
        etf$canBeBright(): boolean;
        isCrouching(): boolean;
        moveTo($$0: BlockPos_, $$1: number, $$2: number): void;
        isPlayer(): boolean;
        isAnimal(): boolean;
        "handler$fgd000$fabric-dimensions-v1$getTeleportTarget"(destination: Internal.ServerLevel_, cir: Internal.CallbackInfoReturnable_<any>): void;
        canBeCollidedWith(): boolean;
        getMotionDirection(): Internal.Direction;
        asComponentProvider(): Internal.ComponentProvider;
        setY(y: number): void;
        getFeetBlockState(): Internal.BlockState;
        lavaHurt(): void;
        handleDamageEvent($$0: DamageSource_): void;
        getFabricBalmData(): Internal.CompoundTag;
        canChangeDimensions(): boolean;
        getChangeListener(): Internal.EntityInLevelCallback;
        static tickEntity(entity: Internal.Entity_): void;
        getCommandSenderWorld(): Internal.Level;
        positionRider($$0: Internal.Entity_): void;
        baseTick(): void;
        broadcastToPlayer($$0: Internal.ServerPlayer_): boolean;
        changeDimension($$0: Internal.ServerLevel_): Internal.Entity;
        setSharedFlag($$0: number, $$1: boolean): void;
        getOwner(): Internal.Entity;
        handler$kom000$porting_lib_entity$afterLoad(nbt: Internal.CompoundTag_, ci: Internal.CallbackInfo_): void;
        getCustomName(): net.minecraft.network.chat.Component;
        getClass(): typeof any;
        pehkui_shouldIgnoreScaleNbt(): boolean;
        isMoving(): boolean;
        isVisuallySwimming(): boolean;
        getMaxAirSupply(): number;
        attack(hp: number): void;
        dynamicLightTick(): void;
        getFacing(): Internal.Direction;
        emf$isWet(): boolean;
        "hasPassenger(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.Entity>): boolean;
        getDimensions($$0: Internal.Pose_): Internal.EntityDimensions;
        isPassengerOfSameVehicle($$0: Internal.Entity_): boolean;
        invokeGetLeashOffset(): Vec3d;
        isSwimming(): boolean;
        getBoundingBoxForCulling(): Internal.AABB;
        mayInteract($$0: Internal.Level_, $$1: BlockPos_): boolean;
        static collideBoundingBox(entity: Internal.Entity_, movement: Vec3d_, entityBoundingBox: Internal.AABB_, world: Internal.Level_, collisions: Internal.List_<any>): Vec3d;
        setSprinting($$0: boolean): void;
        getDynamicLightLevel(): Internal.Level;
        setPortalCooldown(): void;
        setX(x: number): void;
        trackingPosition(): Vec3d;
        getNameTagOffsetY(): number;
        isInvulnerable(): boolean;
        isInLava(): boolean;
        isInWater(): boolean;
        getPortalWaitTime(): number;
        awardKillScore($$0: Internal.Entity_, $$1: number, $$2: DamageSource_): void;
        getBlockStateOn(): Internal.BlockState;
        getFluidHeightLoosely(tag: Internal.TagKey_<any>): number;
        getFluidJumpThreshold(): number;
        unsetRemoved(): void;
        "setPositionAndRotation(double,double,double,float,float)"($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        isInvisibleTo($$0: Internal.Player_): boolean;
        pehkui_getScaleCache(): Internal.ScaleData[];
        setFusionModel(layerIndex: number, model: Internal.Triple_<any, any, any>): void;
        setAirSupply($$0: number): void;
        getOnPos(): BlockPos;
        getRootVehicle(): Internal.Entity;
        getOwnerUUID(): Internal.UUID;
        etf$getWorld(): Internal.Level;
        save($$0: Internal.CompoundTag_): boolean;
        pehkui_getScales(): Internal.Map<any, any>;
        isNoGravity(): boolean;
        etf$getNbt(): Internal.CompoundTag;
        acceptsFailure(): boolean;
        etf$getBlockPos(): BlockPos;
        pehkui_setShouldIgnoreScaleNbt(ignore: boolean): void;
        setOnGroundWithKnownMovement($$0: boolean, $$1: Vec3d_): void;
        setOldPosAndRot(): void;
        bettertrims$setDeflected(deflected: boolean): void;
        emf$getY(): number;
        handler$kom000$porting_lib_entity$port_lib$entityInit(entityType: Internal.EntityType_<any>, world: Internal.Level_, ci: Internal.CallbackInfo_): void;
        bookshelf$createHoverEvent(): Internal.HoverEvent;
        isFree($$0: number, $$1: number, $$2: number): boolean;
        updateSwimming(): void;
        "moveTo(double,double,double)"($$0: number, $$1: number, $$2: number): void;
        setRemainingFireTicks($$0: number): void;
        getCachedFeetBlockState(): Internal.BlockState;
        shouldInformAdmins(): boolean;
        rideTick(): void;
        emf$age(): number;
        etf$hasCustomName(): boolean;
        /**
         * @deprecated
        */
        getOnPosLegacy(): BlockPos;
        setPos($$0: Vec3d_): void;
        wait(): void;
        getUuid(): Internal.UUID;
        spawn(): void;
        teleportTo($$0: Internal.ServerLevel_, $$1: number, $$2: number, $$3: number, $$4: Internal.Set_<Internal.RelativeMovement>, $$5: number, $$6: number): boolean;
        handler$kom000$porting_lib_entity$port_lib$removeRidingEntity(ci: Internal.CallbackInfo_): void;
        etf$getCustomName(): net.minecraft.network.chat.Component;
        captureDrops(value: Internal.Collection_<any>): Internal.Collection<any>;
        fabric_writeAttachmentsToNbt(nbt: Internal.CompoundTag_): void;
        shouldShowName(): boolean;
        setSilent($$0: boolean): void;
        getArmorSlots(): Internal.Iterable<Internal.ItemStack>;
        hasExactlyOnePlayerPassenger(): boolean;
        kill(): void;
        isOnPortalCooldown(): boolean;
        animateHurt($$0: number): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        handler$kom000$porting_lib_entity$port_lib$onEntityRemove(reason: Internal.Entity$RemovalReason_, ci: Internal.CallbackInfo_): void;
        lambdynlights$setTrackedLitChunkPos(trackedLitChunkPos: Internal.LongSet_): void;
        callGetEyeHeight(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        setPitch($$0: number): void;
        setPosRaw($$0: number, $$1: number, $$2: number): void;
        handleEntityEvent($$0: number): void;
        isAlwaysTicking(): boolean;
        interactAt($$0: Internal.Player_, $$1: Vec3d_, $$2: Internal.InteractionHand_): Internal.InteractionResult;
        emf$getX(): number;
        deserializeNBT(arg0: Internal.Tag_): void;
        puzzleslib$acceptCapturedDrops(capturedDrops: Internal.Collection_<any>): Internal.Collection<any>;
        handler$hak000$gobber2$gobberIsFireImmune(cir: Internal.CallbackInfoReturnable_<any>): void;
        lerpTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: boolean): void;
        onPassengerTurned($$0: Internal.Entity_): void;
        modifyReturnValue$zhe000$additionalentityattributes$getMaxAir(original: number): number;
        method_7488(hitResult: Internal.HitResult_): void;
        spawnAtLocation($$0: Internal.ItemLike_): Internal.ItemEntity;
        emf$hasPassengers(): boolean;
        serializeNBT(): Internal.CompoundTag;
        setAttached(type: Internal.AttachmentType_<any>, value: any): any;
        getBbWidth(): number;
        splitIntoDynamicLightEntries(): Internal.Stream<Internal.SpatialLookupEntry>;
        port_lib$getEntityString(): string;
        addDeltaMovement($$0: Vec3d_): void;
        pehkui_setOnGround(onGround: boolean): void;
        lithiumOnBlockCacheDeleted(): void;
        "spawnAtLocation(net.minecraft.world.level.ItemLike,int)"($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        setInvulnerable($$0: boolean): void;
        "getName()"(): net.minecraft.network.chat.Component;
        push($$0: Internal.Entity_): void;
        emf$hasVehicle(): boolean;
        mirror($$0: Internal.Mirror_): number;
        static port_lib$collideWithShapes(vec3: Vec3d_, aABB: Internal.AABB_, list: Internal.List_<Internal.VoxelShape>): Vec3d;
        getTicksRequiredToFreeze(): number;
        getDynamicLightPrevY(): number;
        maxUpStep(): number;
        setGlowing($$0: boolean): void;
        load($$0: Internal.CompoundTag_): void;
        isAlive(): boolean;
        emf$prevZ(): number;
        getBbHeight(): number;
        getUsername(): string;
        move($$0: Internal.MoverType_, $$1: Vec3d_): void;
        getTags(): Internal.Set<string>;
        getViewVector($$0: number): Vec3d;
        lithiumOnBlockCacheSet(newState: Internal.BlockState_): void;
        isPickable(): boolean;
        setYHeadRot($$0: number): void;
        hasControllingPassenger(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number, $$2: number): boolean;
        absMoveTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        getCustomData(): Internal.CompoundTag;
        getPickResult(): Internal.ItemStack;
        getPercentFrozen(): number;
        getRandomY(): number;
        setPortalCooldown($$0: number): void;
        getDisplayName(): net.minecraft.network.chat.Component;
        hasGlowingTag(): boolean;
        shouldBlockExplode($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: number): boolean;
        emf$isInvisible(): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        emf$isSprinting(): boolean;
        getDynamicLightPrevX(): number;
        shouldBeSaved(): boolean;
        fabric_hasPersistentAttachments(): boolean;
        getViewXRot($$0: number): number;
        canRiderInteract(): boolean;
        fabric_getAttachments(): Internal.Map<any, any>;
        removeTag($$0: string): boolean;
        setPose($$0: Internal.Pose_): void;
        getFluidHeight($$0: Internal.TagKey_<Internal.Fluid>): number;
        getEntityType(): Internal.EntityType<any>;
        isWaterCreature(): boolean;
        pehkui_getScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        toString(): string;
        notifyAll(): void;
        getPassengersRidingOffset(): number;
        etf$getScoreboardTeam(): Internal.Team;
        distanceToEntitySqr($$0: Internal.Entity_): number;
        handler$ldh000$puzzleslib$removeVehicle(callback: Internal.CallbackInfo_): void;
        "getServer()"(): Internal.MinecraftServer;
        isFrame(): boolean;
        setLeftOwner(arg0: boolean): void;
        isPushable(): boolean;
        setYBodyRot($$0: number): void;
        discard(): void;
        onClientRemoval(): void;
        "handler$mhe000$step-height-entity-attribute$getStepHeight"(cir: Internal.CallbackInfoReturnable_<any>): void;
        sendSystemMessage($$0: net.minecraft.network.chat.Component_): void;
        acceptsSuccess(): boolean;
        getDistance(x: number, y: number, z: number): number;
        setMotionY(y: number): void;
        setNoGravity($$0: boolean): void;
        getEffectSource(): Internal.Entity;
        getAttached(type: Internal.AttachmentType_<any>): any;
        getIndirectPassengers(): Internal.Iterable<any>;
        setRotation(yaw: number, pitch: number): void;
        isDynamicLightEnabled(): boolean;
        handler$ldh000$puzzleslib$startRiding(vehicle: Internal.Entity_, force: boolean, callback: Internal.CallbackInfoReturnable_<any>): void;
        createCommandSourceStack(): Internal.CommandSourceStack;
        isControlledByLocalInstance(): boolean;
        isMonster(): boolean;
        pehkui_setShouldSyncScales(sync: boolean): void;
        setLastDynamicLuminance(luminance: number): void;
        setId($$0: number): void;
        onSyncedDataUpdated($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        getHorizontalFacing(): Internal.Direction;
        getType(): string;
        getLightProbePosition($$0: number): Vec3d;
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        onAboveBubbleCol($$0: boolean): void;
        emf$prevX(): number;
        "playSound(net.minecraft.sounds.SoundEvent,float,float)"(id: Internal.SoundEvent_, volume: number, pitch: number): void;
        toComponentPacket(key: Internal.ComponentKey_<any>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        isPassenger(): boolean;
        hasPose($$0: Internal.Pose_): boolean;
        checkDespawn(): void;
        pehkui_shouldSyncScales(): boolean;
        isEyeInFluid($$0: Internal.TagKey_<Internal.Fluid>): boolean;
        isInvulnerableTo($$0: DamageSource_): boolean;
        makeStuckInBlock($$0: Internal.BlockState_, $$1: Vec3d_): void;
        getAttachedOrGet<A>(type: Internal.AttachmentType_<A>, defaultValue: Internal.Supplier_<A>): A;
        skipAttackInteraction($$0: Internal.Entity_): boolean;
        lerpMotion($$0: number, $$1: number, $$2: number): void;
        shouldRender($$0: number, $$1: number, $$2: number): boolean;
        onSyncedDataUpdated($$0: Internal.EntityDataAccessor_<any>): void;
        lerpHeadTo($$0: number, $$1: number): void;
        handler$bia000$axiom$onTurn(d: number, e: number, ci: Internal.CallbackInfo_): void;
        static getViewScale(): number;
        setMotionX(x: number): void;
        getHandSlots(): Internal.Iterable<Internal.ItemStack>;
        distanceToEntity($$0: Internal.Entity_): number;
        getVisualRotationYInDegrees(): number;
        isLeftOwner(): boolean;
        wait(arg0: number, arg1: number): void;
        isDiscrete(): boolean;
        getTeamColor(): number;
        setNbt(nbt: Internal.CompoundTag_): void;
        lithiumSetClimbingMobCachingSectionUpdateBehavior(listening: boolean): void;
        unRide(): void;
        getLevel(): Internal.Level;
        "spawnAtLocation(net.minecraft.world.item.ItemStack)"($$0: Internal.ItemStack_): Internal.ItemEntity;
        lambdynlights$getTrackedLitChunkPos(): Internal.LongSet;
        extinguish(): void;
        setDynamicLightEnabled(enabled: boolean): void;
        updateDynamicGameEventListener($$0: Internal.BiConsumer_<Internal.DynamicGameEventListener<any>, Internal.ServerLevel>): void;
        moveTo($$0: Vec3d_): void;
        isColliding($$0: BlockPos_, $$1: Internal.BlockState_): boolean;
        "onSyncedDataUpdated(net.minecraft.network.syncher.EntityDataAccessor)"($$0: Internal.EntityDataAccessor_<any>): void;
        emf$prevY(): number;
        extinguishFire(): void;
        lambdynlights$updateDynamicLight(renderer: Internal.LevelRenderer_): boolean;
        setShot(arg0: boolean): void;
        tell(message: net.minecraft.network.chat.Component_): void;
        static port_lib$collideWithShapes$porting_lib_accessors_$md$424943$0(arg0: Vec3d_, arg1: Internal.AABB_, arg2: Internal.List_<any>): Vec3d;
        isForcedVisible(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number): boolean;
        getDistanceSq(pos: BlockPos_): number;
        emf$getTypeString(): string;
        killedEntity($$0: Internal.ServerLevel_, $$1: Internal.LivingEntity_): boolean;
        getAttachedOrElse<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        isFreezing(): boolean;
        isFullyFrozen(): boolean;
        runCommand(command: string): number;
        setSharedFlagOnFire($$0: boolean): void;
        get inWall(): boolean
        get allSlots(): Internal.Iterable<Internal.ItemStack>
        get blockZ(): number
        get suppressingBounce(): boolean
        get silent(): boolean
        set culled(value: boolean)
        get pitch(): number
        get onFire(): boolean
        get positionCodec(): Internal.VecDeltaCodec
        get passengersAndSelf(): Internal.Stream<any>
        set maxUpStep($$0: number)
        get shiftKeyDown(): boolean
        set UUID($$0: Internal.UUID_)
        get visuallyCrawling(): boolean
        set motionZ(z: number)
        get blockY(): number
        get isInsideStructureTracker(): Internal.IsInsideStructureTracker
        get spectator(): boolean
        get inWaterOrBubble(): boolean
        get persistentData(): Internal.CompoundTag
        get portalCooldown(): number
        get item(): Internal.ItemStack
        set removed($$0: Internal.Entity$RemovalReason_)
        get inWaterRainOrBubble(): boolean
        get removalReason(): Internal.Entity$RemovalReason
        get ignoringBlockTriggers(): boolean
        get steppingCarefully(): boolean
        set boundingBox($$0: Internal.AABB_)
        get ambientCreature(): boolean
        get blockX(): number
        /**
         * @deprecated
        */
        get lightLevelDependentMagicValue(): number
        get encodeId(): string
        get block(): Internal.BlockContainerJS
        get nbt(): Internal.CompoundTag
        set invisible($$0: boolean)
        get name(): net.minecraft.network.chat.Component
        get dynamicLightY(): number
        get controlledVehicle(): Internal.Entity
        get eyePosition(): Vec3d
        get eyeHeight(): number
        get yaw(): number
        get componentContainer(): Internal.ComponentContainer
        get dynamicLightPrevZ(): number
        set customNameVisible($$0: boolean)
        set outOfCamera(value: boolean)
        get controllingPassenger(): Internal.LivingEntity
        get remainingFireTicks(): number
        get scriptType(): Internal.ScriptType
        get forward(): Vec3d
        get maxFallDistance(): number
        get id(): number
        get ticksFrozen(): number
        get recipientsForComponentSync(): Internal.Iterable<any>
        get dynamicLightZ(): number
        get eyeY(): number
        set statusMessage(message: net.minecraft.network.chat.Component_)
        get boundingBox(): Internal.AABB
        get inWaterOrRain(): boolean
        get descending(): boolean
        get YHeadRot(): number
        get addEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>
        set owner($$0: Internal.Entity_)
        get team(): Internal.Team
        set ticksFrozen($$0: number)
        get myRidingOffset(): number
        set deltaMovement($$0: Vec3d_)
        get culled(): boolean
        get living(): boolean
        get glowing(): boolean
        get x(): number
        get vehicle(): boolean
        get leashOffset(): Vec3d
        get shot(): boolean
        get attackable(): boolean
        set isInPowderSnow($$0: boolean)
        set customName($$0: net.minecraft.network.chat.Component_)
        get teamId(): string
        get underWater(): boolean
        get customNameVisible(): boolean
        get pistonPushReaction(): Internal.PushReaction
        get luminance(): number
        get selfAndPassengers(): Internal.Stream<any>
        get deltaMovement(): Vec3d
        get motionX(): number
        get dynamicLightX(): number
        get entityData(): Internal.SynchedEntityData
        set secondsOnFire($$0: number)
        get "displayName()"(): net.minecraft.network.chat.Component
        get onRails(): boolean
        get dimensionChangingDelay(): number
        get peacefulCreature(): boolean
        set onGround($$0: boolean)
        get lastDynamicLuminance(): number
        set yaw($$0: number)
        get pickRadius(): number
        get vehicle(): Internal.Entity
        get effectiveAi(): boolean
        get stringUuid(): string
        get removed(): boolean
        set swimming($$0: boolean)
        get rotationVector(): Internal.Vec2
        get sprinting(): boolean
        get motionY(): number
        set luminance(luminance: number)
        set shiftKeyDown($$0: boolean)
        get passengers(): Internal.EntityArrayList
        get z(): number
        get server(): Internal.MinecraftServer
        get firstPassenger(): Internal.Entity
        get soundSource(): Internal.SoundSource
        set fabricBalmData(tag: Internal.CompoundTag_)
        get pose(): Internal.Pose
        get lookAngle(): Vec3d
        get motionZ(): number
        get invisible(): boolean
        set z(z: number)
        get y(): number
        get profile(): Internal.GameProfile
        set viewScale($$0: number)
        set levelCallback($$0: Internal.EntityInLevelCallback_)
        get pushedByFluid(): boolean
        get outOfCamera(): boolean
        get airSupply(): number
        get crouching(): boolean
        get player(): boolean
        get animal(): boolean
        get motionDirection(): Internal.Direction
        set y(y: number)
        get feetBlockState(): Internal.BlockState
        get fabricBalmData(): Internal.CompoundTag
        get changeListener(): Internal.EntityInLevelCallback
        get commandSenderWorld(): Internal.Level
        get owner(): Internal.Entity
        get customName(): net.minecraft.network.chat.Component
        get class(): typeof any
        get moving(): boolean
        get visuallySwimming(): boolean
        get maxAirSupply(): number
        get facing(): Internal.Direction
        get swimming(): boolean
        get boundingBoxForCulling(): Internal.AABB
        set sprinting($$0: boolean)
        get dynamicLightLevel(): Internal.Level
        set x(x: number)
        get nameTagOffsetY(): number
        get invulnerable(): boolean
        get inLava(): boolean
        get inWater(): boolean
        get portalWaitTime(): number
        get blockStateOn(): Internal.BlockState
        get fluidJumpThreshold(): number
        set airSupply($$0: number)
        get onPos(): BlockPos
        get rootVehicle(): Internal.Entity
        get ownerUUID(): Internal.UUID
        get noGravity(): boolean
        set remainingFireTicks($$0: number)
        get cachedFeetBlockState(): Internal.BlockState
        /**
         * @deprecated
        */
        get onPosLegacy(): BlockPos
        set pos($$0: Vec3d_)
        get uuid(): Internal.UUID
        set silent($$0: boolean)
        get armorSlots(): Internal.Iterable<Internal.ItemStack>
        get onPortalCooldown(): boolean
        set pitch($$0: number)
        get alwaysTicking(): boolean
        get bbWidth(): number
        set invulnerable($$0: boolean)
        get "name()"(): net.minecraft.network.chat.Component
        get ticksRequiredToFreeze(): number
        get dynamicLightPrevY(): number
        set glowing($$0: boolean)
        get alive(): boolean
        get bbHeight(): number
        get username(): string
        get tags(): Internal.Set<string>
        get pickable(): boolean
        set YHeadRot($$0: number)
        get customData(): Internal.CompoundTag
        get pickResult(): Internal.ItemStack
        get percentFrozen(): number
        get randomY(): number
        set portalCooldown($$0: number)
        get displayName(): net.minecraft.network.chat.Component
        set position(block: Internal.BlockContainerJS_)
        get dynamicLightPrevX(): number
        set pose($$0: Internal.Pose_)
        get entityType(): Internal.EntityType<any>
        get waterCreature(): boolean
        get passengersRidingOffset(): number
        get "server()"(): Internal.MinecraftServer
        get frame(): boolean
        set leftOwner(arg0: boolean)
        get pushable(): boolean
        set YBodyRot($$0: number)
        set motionY(y: number)
        set noGravity($$0: boolean)
        get effectSource(): Internal.Entity
        get indirectPassengers(): Internal.Iterable<any>
        get dynamicLightEnabled(): boolean
        get controlledByLocalInstance(): boolean
        get monster(): boolean
        set lastDynamicLuminance(luminance: number)
        set id($$0: number)
        get horizontalFacing(): Internal.Direction
        get type(): string
        get passenger(): boolean
        get viewScale(): number
        set motionX(x: number)
        get handSlots(): Internal.Iterable<Internal.ItemStack>
        get visualRotationYInDegrees(): number
        get leftOwner(): boolean
        get discrete(): boolean
        get teamColor(): number
        set nbt(nbt: Internal.CompoundTag_)
        get level(): Internal.Level
        set dynamicLightEnabled(enabled: boolean)
        set shot(arg0: boolean)
        get forcedVisible(): boolean
        get freezing(): boolean
        get fullyFrozen(): boolean
        set sharedFlagOnFire($$0: boolean)
    }
    type LlamaSpit_ = LlamaSpit;
    interface PoolSubpageMetric {
        abstract elementSize(): number;
        abstract numAvailable(): number;
        abstract pageSize(): number;
        abstract maxNumElements(): number;
    }
    type PoolSubpageMetric_ = PoolSubpageMetric;
    class InSquarePlacement extends Internal.PlacementModifier {
        constructor()
        getClass(): typeof any;
        static spread(): Internal.InSquarePlacement;
        hashCode(): number;
        toString(): string;
        getPositions($$0: Internal.PlacementContext_, $$1: Internal.RandomSource_, $$2: BlockPos_): Internal.Stream<BlockPos>;
        wait(): void;
        type(): Internal.PlacementModifierType<any>;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        static readonly CODEC: Internal.Codec<Internal.InSquarePlacement>;
    }
    type InSquarePlacement_ = InSquarePlacement;
    interface Boolean2LongFunction extends it.unimi.dsi.fastutil.Function<boolean, number> {
        composeInt(arg0: Internal.Int2BooleanFunction_): Internal.Int2LongFunction;
        /**
         * @deprecated
        */
        andThen<T>(arg0: Internal.Function_<number, T>): Internal.Function<boolean, T>;
        /**
         * @deprecated
        */
        "put(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): any;
        /**
         * @deprecated
        */
        "get(java.lang.Object)"(arg0: any): number;
        /**
         * @deprecated
        */
        remove(arg0: any): number;
        composeLong(arg0: Internal.Long2BooleanFunction_): Internal.Long2LongFunction;
        composeChar(arg0: Internal.Char2BooleanFunction_): Internal.Char2LongFunction;
        andThenByte(arg0: Internal.Long2ByteFunction_): Internal.Boolean2ByteFunction;
        /**
         * @deprecated
        */
        put(arg0: any, arg1: any): any;
        andThenDouble(arg0: Internal.Long2DoubleFunction_): Internal.Boolean2DoubleFunction;
        composeFloat(arg0: Internal.Float2BooleanFunction_): Internal.Float2LongFunction;
        andThenReference<T>(arg0: Internal.Long2ReferenceFunction_<T>): Internal.Boolean2ReferenceFunction<T>;
        andThenFloat(arg0: Internal.Long2FloatFunction_): Internal.Boolean2FloatFunction;
        composeByte(arg0: Internal.Byte2BooleanFunction_): Internal.Byte2LongFunction;
        remove(arg0: boolean): number;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: number): number;
        andThenInt(arg0: Internal.Long2IntFunction_): Internal.Boolean2IntFunction;
        composeShort(arg0: Internal.Short2BooleanFunction_): Internal.Short2LongFunction;
        abstract "get(boolean)"(arg0: boolean): number;
        andThenLong(arg0: Internal.Long2LongFunction_): this;
        apply(arg0: boolean): number;
        /**
         * @deprecated
        */
        "getOrDefault(java.lang.Object,java.lang.Long)"(arg0: any, arg1: number): number;
        identity<T>(): Internal.Function<T, T>;
        /**
         * @deprecated
        */
        "remove(java.lang.Object)"(arg0: any): number;
        /**
         * @deprecated
        */
        "containsKey(java.lang.Object)"(arg0: any): boolean;
        getOrDefault(arg0: boolean, arg1: number): number;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: any): any;
        abstract get(arg0: boolean): number;
        "remove(boolean)"(arg0: boolean): number;
        /**
         * @deprecated
        */
        get(arg0: any): number;
        /**
         * @deprecated
        */
        containsKey(arg0: any): boolean;
        /**
         * @deprecated
        */
        "getOrDefault(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): any;
        andThenChar(arg0: Internal.Long2CharFunction_): Internal.Boolean2CharFunction;
        /**
         * @deprecated
        */
        compose<T>(arg0: Internal.Function_<T, boolean>): Internal.Function<T, number>;
        "containsKey(boolean)"(arg0: boolean): boolean;
        "getOrDefault(boolean,long)"(arg0: boolean, arg1: number): number;
        defaultReturnValue(): number;
        composeObject<T>(arg0: Internal.Object2BooleanFunction_<T>): Internal.Object2LongFunction<T>;
        composeDouble(arg0: Internal.Double2BooleanFunction_): Internal.Double2LongFunction;
        containsKey(arg0: boolean): boolean;
        andThenShort(arg0: Internal.Long2ShortFunction_): Internal.Boolean2ShortFunction;
        size(): number;
        andThenObject<T>(arg0: Internal.Long2ObjectFunction_<T>): Internal.Boolean2ObjectFunction<T>;
        clear(): void;
        "put(boolean,long)"(arg0: boolean, arg1: number): number;
        put(arg0: boolean, arg1: number): number;
        /**
         * @deprecated
        */
        "put(java.lang.Boolean,java.lang.Long)"(arg0: boolean, arg1: number): number;
        composeReference<T>(arg0: Internal.Reference2BooleanFunction_<T>): Internal.Reference2LongFunction<T>;
        /**
         * @deprecated
        */
        put(arg0: boolean, arg1: number): number;
        defaultReturnValue(arg0: number): void;
    }
    type Boolean2LongFunction_ = Boolean2LongFunction;
    class ScaffoldingBlockItem extends Internal.BlockItem {
        constructor($$0: Internal.Block_, $$1: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        static setBlockEntityData($$0: Internal.ItemStack_, $$1: Internal.BlockEntityType_<any>, $$2: Internal.CompoundTag_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        abstract moonlight$addAdditionalBehavior(arg0: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        modifyReturnValue$bkb000$axiom$canPlace(canPlace: boolean, blockPlaceContext: Internal.BlockPlaceContext_): boolean;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        abstract moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        handler$mpi000$tcdcommons$onPlace(context: Internal.BlockPlaceContext_, ci: Internal.CallbackInfoReturnable_<any>): void;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        abstract moonlight$setClientAnimationExtension(arg0: any): void;
        abstract moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        wrapOperation$bkb000$axiom$place$getPlacementState(instance: Internal.BlockItem_, blockPlaceContext: Internal.BlockPlaceContext_, original: Internal.Operation_<any>): Internal.BlockState;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        static getBlockEntityData($$0: Internal.ItemStack_): Internal.CompoundTag;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        removeFromBlockToItemMap(blockToItemMap: Internal.Map_<Internal.Block, Internal.Item>, itemIn: Internal.Item_): void;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        static updateCustomBlockEntityTag($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.ItemStack_): boolean;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        place($$0: Internal.BlockPlaceContext_): Internal.InteractionResult;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        getBlock(): Internal.Block;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        updatePlacementContext($$0: Internal.BlockPlaceContext_): Internal.BlockPlaceContext;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        registerBlocks($$0: Internal.Map_<Internal.Block, Internal.Item>, $$1: Internal.Item_): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        puzzleslib$setBlock(arg0: Internal.Block_): void;
        wrapOperation$bkb000$axiom$place$updatePlacementContext(instance: Internal.BlockItem_, blockPlaceContext: Internal.BlockPlaceContext_, original: Internal.Operation_<any>): Internal.BlockPlaceContext;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        get block(): Internal.Block
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type ScaffoldingBlockItem_ = ScaffoldingBlockItem;
    class LivingEntity$Fallsounds extends Internal.Record {
        constructor($$0: Internal.SoundEvent_, $$1: Internal.SoundEvent_)
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        small(): Internal.SoundEvent;
        big(): Internal.SoundEvent;
        equals($$0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
    }
    type LivingEntity$Fallsounds_ = LivingEntity$Fallsounds;
    class MenuType <T extends Internal.AbstractContainerMenu> implements Internal.FeatureElement, Internal.MenuTypeAccessor<any> {
        constructor($$0: Internal.MenuType$MenuSupplier_<T>, $$1: Internal.FeatureFlagSet_)
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        create($$0: number, $$1: Internal.Inventory_): T;
        requiredFeatures(): Internal.FeatureFlagSet;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        getConstructor(): Internal.MenuType$MenuSupplier<any>;
        equals(arg0: any): boolean;
        get class(): typeof any
        get "constructor"(): Internal.MenuType$MenuSupplier<any>
        static readonly MERCHANT: Internal.MenuType<Internal.MerchantMenu>;
        static readonly CARTOGRAPHY_TABLE: Internal.MenuType<Internal.CartographyTableMenu>;
        static readonly SMOKER: Internal.MenuType<Internal.SmokerMenu>;
        static readonly GENERIC_9x6: Internal.MenuType<Internal.ChestMenu>;
        static readonly ANVIL: Internal.MenuType<Internal.AnvilMenu>;
        static readonly GENERIC_9x4: Internal.MenuType<Internal.ChestMenu>;
        static readonly BEACON: Internal.MenuType<Internal.BeaconMenu>;
        static readonly LOOM: Internal.MenuType<Internal.LoomMenu>;
        static readonly STONECUTTER: Internal.MenuType<Internal.StonecutterMenu>;
        static readonly GENERIC_9x5: Internal.MenuType<Internal.ChestMenu>;
        static readonly LECTERN: Internal.MenuType<Internal.LecternMenu>;
        static readonly SHULKER_BOX: Internal.MenuType<Internal.ShulkerBoxMenu>;
        static readonly CRAFTING: Internal.MenuType<Internal.CraftingMenu>;
        static readonly SMITHING: Internal.MenuType<Internal.SmithingMenu>;
        static readonly ENCHANTMENT: Internal.MenuType<Internal.EnchantmentMenu>;
        static readonly GENERIC_9x2: Internal.MenuType<Internal.ChestMenu>;
        static readonly GENERIC_3x3: Internal.MenuType<Internal.DispenserMenu>;
        static readonly FURNACE: Internal.MenuType<Internal.FurnaceMenu>;
        static readonly GENERIC_9x3: Internal.MenuType<Internal.ChestMenu>;
        static readonly GRINDSTONE: Internal.MenuType<Internal.GrindstoneMenu>;
        static readonly GENERIC_9x1: Internal.MenuType<Internal.ChestMenu>;
        static readonly BREWING_STAND: Internal.MenuType<Internal.BrewingStandMenu>;
        static readonly HOPPER: Internal.MenuType<Internal.HopperMenu>;
        static readonly BLAST_FURNACE: Internal.MenuType<Internal.BlastFurnaceMenu>;
    }
    type MenuType_<T extends Internal.AbstractContainerMenu> = Special.Menu | MenuType<T>;
}
declare namespace io.github.fabricators_of_create.porting_lib.extensions.extensions {
    interface MobEffectExtensions {
        getCurativeItems(): Internal.List<Internal.ItemStack>;
        getSortOrder(potionEffect: Internal.MobEffectInstance_): number;
        get curativeItems(): Internal.List<Internal.ItemStack>
    }
    type MobEffectExtensions_ = MobEffectExtensions;
}
declare namespace io.github.fabricators_of_create.porting_lib.tool.extensions {
    interface ItemStackExtensions {
        canPerformAction(toolAction: Internal.ToolAction_): boolean;
    }
    type ItemStackExtensions_ = ItemStackExtensions;
}
declare namespace vazkii.patchouli.client.book {
    class BookCategory extends Internal.AbstractReadStateHolder implements Internal.Comparable<vazkii.patchouli.client.book.BookCategory> {
        constructor(root: Internal.JsonObject_, id: ResourceLocation_, book: Internal.Book_)
        getClass(): typeof any;
        addEntry(entry: Internal.BookEntry_): void;
        build(builder: Internal.BookContentsBuilder_): void;
        isSecret(): boolean;
        markReadStateDirty(): void;
        getDescription(): string;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        canAdd(): boolean;
        addChildCategory(category: vazkii.patchouli.client.book.BookCategory_): void;
        getId(): ResourceLocation;
        isRootCategory(): boolean;
        getName(): Internal.MutableComponent;
        "compareTo(vazkii.patchouli.client.book.BookCategory)"(o: vazkii.patchouli.client.book.BookCategory_): number;
        updateLockStatus(rootOnly: boolean): void;
        toString(): string;
        compareTo(o: vazkii.patchouli.client.book.BookCategory_): number;
        notifyAll(): void;
        shouldHide(): boolean;
        getEntries(): Internal.List<Internal.BookEntry>;
        getBook(): Internal.Book;
        getIcon(): Internal.BookIcon;
        isLocked(): boolean;
        getParentCategory(): this;
        hashCode(): number;
        wait(): void;
        getReadState(): vazkii.patchouli.client.book.EntryDisplayState;
        wait(arg0: number): void;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        static mostImportantState(stream: Internal.Stream_<vazkii.patchouli.client.book.EntryDisplayState>): vazkii.patchouli.client.book.EntryDisplayState;
        get class(): typeof any
        get secret(): boolean
        get description(): string
        get id(): ResourceLocation
        get rootCategory(): boolean
        get name(): Internal.MutableComponent
        get entries(): Internal.List<Internal.BookEntry>
        get book(): Internal.Book
        get icon(): Internal.BookIcon
        get locked(): boolean
        get parentCategory(): vazkii.patchouli.client.book.BookCategory
        get readState(): vazkii.patchouli.client.book.EntryDisplayState
    }
    type BookCategory_ = BookCategory;
}
declare namespace lilypuree.decorative_blocks.mixin {
    interface ItemAccessor {
        getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
    }
    type ItemAccessor_ = ItemAccessor;
}
declare namespace net.irisshaders.iris.mixin.rendertype {
    interface RenderStateShardAccessor {
        getTranslucentTransparency(): Internal.RenderStateShard$TransparencyStateShard;
        abstract getName(): string;
        get translucentTransparency(): Internal.RenderStateShard$TransparencyStateShard
        get name(): string
        (): string;
    }
    type RenderStateShardAccessor_ = RenderStateShardAccessor | (()=> string);
}
declare namespace net.irisshaders.iris.texture {
    interface SpriteContentsExtension {
        abstract getCreatedTicker(): Internal.SpriteContents$Ticker;
        get createdTicker(): Internal.SpriteContents$Ticker
        (): Internal.SpriteContents$Ticker_;
    }
    type SpriteContentsExtension_ = SpriteContentsExtension | (()=> Internal.SpriteContents$Ticker_);
}
declare namespace fuzs.betteranimationscollection.mixin.client.accessor {
    interface AgeableListModelAccessor {
        abstract setBabyYHeadOffset(arg0: number): void;
        abstract setBabyZHeadOffset(arg0: number): void;
        set babyYHeadOffset(arg0: number)
        set babyZHeadOffset(arg0: number)
    }
    type AgeableListModelAccessor_ = AgeableListModelAccessor;
}
declare namespace io.wispforest.owo.mixin.ui.layers {
    interface HandledScreenAccessor {
        abstract owo$getRootX(): number;
        abstract owo$getRootY(): number;
    }
    type HandledScreenAccessor_ = HandledScreenAccessor;
}
