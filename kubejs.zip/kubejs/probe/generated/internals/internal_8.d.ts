/// <reference path="./internal_*.d.ts" />
declare namespace Internal {
    class MinecartHopper extends Internal.AbstractMinecartContainer implements Internal.Hopper {
        constructor($$0: Internal.Level_, $$1: number, $$2: number, $$3: number)
        constructor($$0: Internal.EntityType_<Internal.MinecartHopper>, $$1: Internal.Level_)
        stopOpen($$0: Internal.Player_): void;
        litematica_setWorld(arg0: Internal.Level_): void;
        handler$hak000$gobber2$gobberOccludeVibrationSignals(cir: Internal.CallbackInfoReturnable_<any>): void;
        isInWall(): boolean;
        etf$getType(): Internal.EntityType<any>;
        getAllSlots(): Internal.Iterable<Internal.ItemStack>;
        addChestVehicleSaveData($$0: Internal.CompoundTag_): void;
        isChestVehicleEmpty(): boolean;
        getUpVector($$0: number): Vec3d;
        getPos($$0: number, $$1: number, $$2: number): Vec3d;
        gameEvent($$0: Internal.GameEvent_, $$1: Internal.Entity_): void;
        remove($$0: Internal.Entity$RemovalReason_): void;
        clear(ingredient: Internal.Ingredient_): void;
        find(): number;
        hasAnyOf($$0: Internal.Set_<Internal.Item>): boolean;
        getBlockZ(): number;
        isSuppressingBounce(): boolean;
        setHurtTime($$0: number): void;
        dampensVibrations(): boolean;
        hasAttached(type: Internal.AttachmentType_<any>): boolean;
        isSilent(): boolean;
        "playSound(net.minecraft.sounds.SoundEvent)"($$0: Internal.SoundEvent_): void;
        setCulled(value: boolean): void;
        getPitch(): number;
        isOnFire(): boolean;
        rotate($$0: Internal.Rotation_): number;
        getPositionCodec(): Internal.VecDeltaCodec;
        "setChanged()"(): void;
        getPassengersAndSelf(): Internal.Stream<any>;
        setMaxUpStep($$0: number): void;
        updateFluidHeightAndDoFluidPushing($$0: Internal.TagKey_<Internal.Fluid>, $$1: number): boolean;
        setPosition(x: number, y: number, z: number): void;
        runCommandSilent(command: string): number;
        chunkPosition(): Internal.ChunkPos;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        emf$isOnGround(): boolean;
        gameEvent($$0: Internal.GameEvent_): void;
        getSuckShape(): Internal.VoxelShape;
        alwaysAccepts(): boolean;
        isShiftKeyDown(): boolean;
        setUUID($$0: Internal.UUID_): void;
        checkBelowWorld(): void;
        isVisuallyCrawling(): boolean;
        getLevelY(): number;
        chestVehicleDestroyed($$0: DamageSource_, $$1: Internal.Level_, $$2: Internal.Entity_): void;
        setMotionZ(z: number): void;
        abstract getDropItem(): Internal.Item;
        countItem($$0: Internal.Item_): number;
        handler$ieb000$lambdynlights$onRemove(ci: Internal.CallbackInfo_): void;
        "deserializeNBT(net.minecraft.nbt.Tag)"(arg0: Internal.Tag_): void;
        canPlaceItem($$0: number, $$1: Internal.ItemStack_): boolean;
        canFreeze(): boolean;
        ignoreExplosion(): boolean;
        port_lib$setRemovalReason(arg0: Internal.Entity$RemovalReason_): void;
        teleportRelative($$0: number, $$1: number, $$2: number): void;
        getBlockY(): number;
        getIsInsideStructureTracker(): Internal.IsInsideStructureTracker;
        isSpectator(): boolean;
        pehkui_setScaleCache(scaleCache: Internal.ScaleData_[]): void;
        isInWaterOrBubble(): boolean;
        spawnAtLocation($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        getPersistentData(): Internal.CompoundTag;
        getPortalCooldown(): number;
        emf$isGlowing(): boolean;
        getItem(): Internal.ItemStack;
        getRandomZ($$0: number): number;
        pehkui_getOnGround(): boolean;
        causeFallDamage($$0: number, $$1: number, $$2: DamageSource_): boolean;
        getFusionModel(layerIndex: number): Internal.Triple<any, any, any>;
        getDynamicLightChunksToRebuild(forced: boolean): Internal.LongSet;
        getPosition($$0: number): Vec3d;
        setRemoved($$0: Internal.Entity$RemovalReason_): void;
        insertItem(slot: number, stack: Internal.ItemStack_, simulate: boolean): Internal.ItemStack;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>, initializer: Internal.Supplier_<A>): A;
        getDistanceSq($$0: number, $$1: number, $$2: number): number;
        isInWaterRainOrBubble(): boolean;
        getRemovalReason(): Internal.Entity$RemovalReason;
        wait(arg0: number): void;
        method_17357($$0: number, $$1: Internal.Inventory_): Internal.AbstractContainerMenu;
        isIgnoringBlockTriggers(): boolean;
        getDamage(): number;
        etf$getItemsEquipped(): Internal.Iterable<any>;
        getHandHoldingItemAngle($$0: Internal.Item_): Vec3d;
        etf$getVelocity(): Vec3d;
        getLevelZ(): number;
        getPosOffs($$0: number, $$1: number, $$2: number, $$3: number): Vec3d;
        hex$markHurt(): void;
        distanceToSqr($$0: Vec3d_): number;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        resetFallDistance(): void;
        canSprint(): boolean;
        modifyAttached<A>(type: Internal.AttachmentType_<A>, modifier: Internal.UnaryOperator_<A>): A;
        blockPosition(): BlockPos;
        isSteppingCarefully(): boolean;
        setBoundingBox($$0: Internal.AABB_): void;
        isAmbientCreature(): boolean;
        "spawnAtLocation(net.minecraft.world.item.ItemStack,float)"($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        getDisplayBlockState(): Internal.BlockState;
        getBlockX(): number;
        /**
         * @deprecated
        */
        getLightLevelDependentMagicValue(): number;
        getEncodeId(): string;
        getY($$0: number): number;
        interactWithContainerVehicle($$0: Internal.Player_): Internal.InteractionResult;
        emf$prevPitch(): number;
        getBlock(): Internal.BlockContainerJS;
        getNbt(): Internal.CompoundTag;
        etf$getHandItems(): Internal.Iterable<any>;
        setInvisible($$0: boolean): void;
        etf$getArmorItems(): Internal.Iterable<any>;
        getName(): net.minecraft.network.chat.Component;
        getSlotLimit(slot: number): number;
        isSubmergedInLoosely(tag: Internal.TagKey_<any>): boolean;
        onGround(): boolean;
        getDynamicLightY(): number;
        getControlledVehicle(): Internal.Entity;
        removeItemNoUpdate($$0: number): Internal.ItemStack;
        clearChestVehicleContent(): void;
        isOnSameTeam($$0: Internal.Entity_): boolean;
        attack($$0: DamageSource_, $$1: number): boolean;
        onInsideBubbleColumn($$0: boolean): void;
        tick(): void;
        invokeGetMaxOffRailSpeed(): number;
        getEyePosition(): Vec3d;
        getEyeHeight(): number;
        hasPassenger($$0: Internal.Predicate_<Internal.Entity>): boolean;
        getYaw(): number;
        emf$isTouchingWater(): boolean;
        emf$getVariableMap(): Internal.Object2FloatOpenHashMap<any>;
        getComponentContainer(): Internal.ComponentContainer;
        hasPermissions($$0: number): boolean;
        getDynamicLightPrevZ(): number;
        count(): number;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        pehkui_readScaleNbt(nbt: Internal.CompoundTag_): void;
        setCustomNameVisible($$0: boolean): void;
        isAlliedTo($$0: Internal.Team_): boolean;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>): A;
        setOutOfCamera(value: boolean): void;
        getControllingPassenger(): Internal.LivingEntity;
        getRemainingFireTicks(): number;
        getScriptType(): Internal.ScriptType;
        onlyOpCanSetNbt(): boolean;
        extractItem(slot: number, amount: number, simulate: boolean): Internal.ItemStack;
        startRiding($$0: Internal.Entity_): boolean;
        saveWithoutId($$0: Internal.CompoundTag_): Internal.CompoundTag;
        getForward(): Vec3d;
        tcdcommons_getCustomData(): Internal.GenericProperties<any>;
        fireImmune(): boolean;
        addMotion($$0: number, $$1: number, $$2: number): void;
        canReceiveTransferCooldown(): boolean;
        getMaxFallDistance(): number;
        getZ($$0: number): number;
        getId(): number;
        pehkui_isFirstUpdate(): boolean;
        canBeHitByProjectile(): boolean;
        getTicksFrozen(): number;
        wrapWithCondition$kom000$porting_lib_entity$port_lib$captureDrops(level: Internal.Level_, entity: Internal.Entity_): boolean;
        getAllItems(): Internal.List<Internal.ItemStack>;
        getRecipientsForComponentSync(): Internal.Iterable<any>;
        getRandomX($$0: number): number;
        getDynamicLightZ(): number;
        getEyeY(): number;
        spawnAtLocation($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        pick($$0: number, $$1: number, $$2: boolean): Internal.HitResult;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        fabric_readAttachmentsFromNbt(nbt: Internal.CompoundTag_): void;
        getBoundingBox(): Internal.AABB;
        changeDimension(p_20118_: Internal.ServerLevel_, teleporter: Internal.ITeleporter_): Internal.Entity;
        isInWaterOrRain(): boolean;
        isDescending(): boolean;
        isMutable(): boolean;
        emf$getPitch(): number;
        setItemSlot($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_): void;
        getYHeadRot(): number;
        handler$cbi000$besmirchment$isTeammate(other: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>): void;
        equals($$0: any): boolean;
        getViewYRot($$0: number): number;
        fabric_setCustomTeleportTarget(teleportTarget: Internal.PortalInfo_): void;
        dismountsUnderwater(): boolean;
        frameworkGetDataHolder(): com.mrcrayfish.framework.entity.sync.DataHolder;
        playerTouch($$0: Internal.Player_): void;
        addTag($$0: string): boolean;
        getEyeHeight($$0: Internal.Pose_): number;
        getAddEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>;
        syncPacketPositionCodec($$0: number, $$1: number, $$2: number): void;
        callIsBeingRainedOn(): boolean;
        setDamage($$0: number): void;
        getDisplayOffset(): number;
        getTeam(): Internal.Team;
        isChestVehicleStillValid($$0: Internal.Player_): boolean;
        shouldRenderAtSqrDistance($$0: number): boolean;
        getAttachedOrSet<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        damageSources(): Internal.DamageSources;
        removeAttached<A>(type: Internal.AttachmentType_<A>): A;
        hasAnyMatching($$0: Internal.Predicate_<Internal.ItemStack>): boolean;
        setTicksFrozen($$0: number): void;
        recreateFromPacket($$0: Internal.ClientboundAddEntityPacket_): void;
        getWidth(): number;
        getMyRidingOffset(): number;
        dismountTo($$0: number, $$1: number, $$2: number): void;
        setDeltaMovement($$0: Vec3d_): void;
        getLeashOffset($$0: number): Vec3d;
        etf$getEntityKey(): string;
        etf$getPose(): Internal.Pose;
        hasCustomName(): boolean;
        captureDrops(): Internal.Collection<any>;
        isCulled(): boolean;
        isLiving(): boolean;
        isGlowing(): boolean;
        getX(): number;
        isVehicle(): boolean;
        static transfer(original: Internal.AttachmentTarget_, target: Internal.AttachmentTarget_, isDeath: boolean): void;
        etf$getOptifineId(): number;
        dynamicLightWorld(): Internal.Level;
        getLeashOffset(): Vec3d;
        resetDynamicLight(): void;
        isAttackable(): boolean;
        spawnAtLocation($$0: Internal.ItemStack_): Internal.ItemEntity;
        getMaxSpeedOnRail(): number;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        thunderHit($$0: Internal.ServerLevel_, $$1: Internal.LightningBolt_): void;
        setIsInPowderSnow($$0: boolean): void;
        etf$distanceTo(entity: Internal.Entity_): number;
        doEnchantDamageEffects($$0: Internal.LivingEntity_, $$1: Internal.Entity_): void;
        setCustomName($$0: net.minecraft.network.chat.Component_): void;
        getSlot($$0: number): Internal.SlotAccess;
        lambdynlights$scheduleTrackedChunksRebuild(renderer: Internal.LevelRenderer_): void;
        "deserializeNBT(net.minecraft.nbt.CompoundTag)"(nbt: Internal.CompoundTag_): void;
        emf$isInLava(): boolean;
        pehkui_constructScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        startOpen($$0: Internal.Player_): void;
        handler$hak000$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        getItemStacks(): Internal.NonNullList<Internal.ItemStack>;
        getTeamId(): string;
        removeChestVehicleItem($$0: number, $$1: number): Internal.ItemStack;
        stopSeenByPlayer($$0: Internal.ServerPlayer_): void;
        getChestVehicleItem($$0: number): Internal.ItemStack;
        isUnderWater(): boolean;
        stopRiding(): void;
        shouldCloseCurrentScreen(): boolean;
        isCustomNameVisible(): boolean;
        isSupportedBy($$0: BlockPos_): boolean;
        getPistonPushReaction(): Internal.PushReaction;
        getX($$0: number): number;
        lookAt($$0: Internal.EntityAnchorArgument$Anchor_, $$1: Vec3d_): void;
        getLuminance(): number;
        callUnsetRemoved(): void;
        getSelfAndPassengers(): Internal.Stream<any>;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        getLootTableSeed(): number;
        removeChestVehicleItemNoUpdate($$0: number): Internal.ItemStack;
        getDeltaMovement(): Vec3d;
        countNonEmpty(): number;
        collide($$0: Vec3d_): Vec3d;
        getMotionX(): number;
        "onSyncedDataUpdated(java.util.List)"($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        hasPassenger($$0: Internal.Entity_): boolean;
        be_getTravelerState(): Internal.TravelerState;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        hasIndirectPassenger($$0: Internal.Entity_): boolean;
        getDynamicLightX(): number;
        getEntityData(): Internal.SynchedEntityData;
        setSecondsOnFire($$0: number): void;
        moveTo($$0: number, $$1: number, $$2: number): void;
        generateLootLithium(): void;
        emf$getZ(): number;
        abstract "getDisplayName()"(): net.minecraft.network.chat.Component;
        getLootTable(): ResourceLocation;
        handleInsidePortal($$0: BlockPos_): void;
        setMotion($$0: number, $$1: number, $$2: number): void;
        playSound($$0: Internal.SoundEvent_): void;
        absMoveTo($$0: number, $$1: number, $$2: number): void;
        isOnRails(): boolean;
        getAttachedOrThrow<A>(type: Internal.AttachmentType_<A>): A;
        handler$ikg000$lithium$tryShortcutFluidPushing(tag: Internal.TagKey_<any>, speed: number, cir: Internal.CallbackInfoReturnable_<any>, box: Internal.AABB_, x1: number, x2: number, y1: number, y2: number, z1: number, z2: number, zero: number): void;
        handler$hak000$gobber2$setFrozenTicks(frozenTicks: number, ci: Internal.CallbackInfo_): void;
        restoreFrom($$0: Internal.Entity_): void;
        markFusionRecomputeModels(): void;
        getDimensionChangingDelay(): number;
        isPeacefulCreature(): boolean;
        setOnGround($$0: boolean): void;
        emf$getYaw(): number;
        handler$cbi000$besmirchment$getScoreboardTeam(cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDynamicLuminance(): number;
        setPos($$0: number, $$1: number, $$2: number): void;
        setYaw($$0: number): void;
        setStackInSlot(slot: number, stack: Internal.ItemStack_): void;
        getPickRadius(): number;
        notify(): void;
        getVehicle(): Internal.Entity;
        isEffectiveAi(): boolean;
        handler$kom000$porting_lib_entity$port_lib$startRiding(entity: Internal.Entity_, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        startRiding($$0: Internal.Entity_, $$1: boolean): boolean;
        getStringUuid(): string;
        abstract isRemoved(): boolean;
        emf$isSneaking(): boolean;
        setSwimming($$0: boolean): void;
        teleportToWithTicket($$0: number, $$1: number, $$2: number): void;
        getContainerSize(): number;
        fillCrashReportCategory($$0: Internal.CrashReportCategory_): void;
        getRotationVector(): Internal.Vec2;
        refreshDimensions(): void;
        pehkui_writeScaleNbt(nbt: Internal.CompoundTag_): Internal.CompoundTag;
        etf$getBlockY(): number;
        isSprinting(): boolean;
        "spawnAtLocation(net.minecraft.world.level.ItemLike)"($$0: Internal.ItemLike_): Internal.ItemEntity;
        getMotionY(): number;
        canCollideWith($$0: Internal.Entity_): boolean;
        setLuminance(luminance: number): void;
        setShiftKeyDown($$0: boolean): void;
        getEyePosition($$0: number): Vec3d;
        getPassengers(): Internal.EntityArrayList;
        getBlockExplosionResistance($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.FluidState_, $$5: number): number;
        static stillValidBlockEntity($$0: Internal.BlockEntity_, $$1: Internal.Player_): boolean;
        handler$ldh000$puzzleslib$spawnAtLocation(stack: Internal.ItemStack_, offsetY: number, callback: Internal.CallbackInfoReturnable_<any>, itemEntity: Internal.ItemEntity_): void;
        port_lib$getMaxSpeed(): number;
        setLootTable($$0: ResourceLocation_): void;
        getZ(): number;
        canSpawnSprintParticle(): boolean;
        "moveTo(net.minecraft.core.BlockPos,float,float)"($$0: BlockPos_, $$1: number, $$2: number): void;
        teleportTo($$0: number, $$1: number, $$2: number): void;
        handler$zbk000$porting_lib_base$port_lib$spawnSprintParticle(ci: Internal.CallbackInfo_, pos: BlockPos_, state: Internal.BlockState_): void;
        getServer(): Internal.MinecraftServer;
        moveRelative($$0: number, $$1: Vec3d_): void;
        setLootTable($$0: ResourceLocation_, $$1: number): void;
        count(ingredient: Internal.Ingredient_): number;
        getFirstPassenger(): Internal.Entity;
        saveAsPassenger($$0: Internal.CompoundTag_): boolean;
        static gatherClosestChunks(chunks: Internal.LongSet_, x: number, y: number, z: number): void;
        interact($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        handler$kom000$porting_lib_entity$afterSave(nbt: Internal.CompoundTag_, cir: Internal.CallbackInfoReturnable_<any>): void;
        setHurtDir($$0: number): void;
        getDismountLocationForPassenger($$0: Internal.LivingEntity_): Vec3d;
        isEnabled(): boolean;
        checkSlowFallDistance(): void;
        getSoundSource(): Internal.SoundSource;
        setFabricBalmData(tag: Internal.CompoundTag_): void;
        removeAfterChangingDimensions(): void;
        getPose(): Internal.Pose;
        static stillValidBlockEntity($$0: Internal.BlockEntity_, $$1: Internal.Player_, $$2: number): boolean;
        touchingUnloadedChunk(): boolean;
        getHurtDir(): number;
        getLookAngle(): Vec3d;
        setPositionAndRotation($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        asContainer(): net.minecraft.world.Container;
        emf$isOnFire(): boolean;
        getMotionZ(): number;
        etf$getUuid(): Internal.UUID;
        removeVehicle(): void;
        isInvisible(): boolean;
        shouldFusionRecomputeModel(layerIndex: number): boolean;
        is($$0: Internal.Entity_): boolean;
        setZ(z: number): void;
        stillValid($$0: Internal.Player_): boolean;
        ejectPassengers(): void;
        getY(): number;
        deserializeNBT(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        updateDynamicLightPreviousCoordinates(): void;
        getProfile(): Internal.GameProfile;
        static setViewScale($$0: number): void;
        emf$isAlive(): boolean;
        setLevelCallback($$0: Internal.EntityInLevelCallback_): void;
        showVehicleHealth(): boolean;
        getDistance(pos: BlockPos_): number;
        playSound($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        emf$getVelocity(): Vec3d;
        setCustomDisplay($$0: boolean): void;
        getCurrentRailPos(): BlockPos;
        etf$isBlockEntity(): boolean;
        removeItem($$0: number, $$1: number): Internal.ItemStack;
        shouldUpdateDynamicLight(): boolean;
        startSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isOnScoreboardTeam(teamId: string): boolean;
        isPushedByFluid(): boolean;
        localvar$bbb000$architectury$modifyLevelCallback_setLevelCallback(callback: Internal.EntityInLevelCallback_): Internal.EntityInLevelCallback;
        abstract position(): Vec3d;
        setTimeout(): void;
        displayFireAnimation(): boolean;
        turn($$0: number, $$1: number): void;
        isOutOfCamera(): boolean;
        getAirSupply(): number;
        setInventoryLithium(arg0: Internal.NonNullList_<any>): void;
        getRopeHoldPosition($$0: number): Vec3d;
        copyPosition($$0: Internal.Entity_): void;
        "hasPassenger(net.minecraft.world.entity.Entity)"($$0: Internal.Entity_): boolean;
        getInventoryLithium(): Internal.NonNullList<any>;
        etf$canBeBright(): boolean;
        isCrouching(): boolean;
        moveTo($$0: BlockPos_, $$1: number, $$2: number): void;
        isPlayer(): boolean;
        isAnimal(): boolean;
        getMotionDirection(): Internal.Direction;
        "handler$fgd000$fabric-dimensions-v1$getTeleportTarget"(destination: Internal.ServerLevel_, cir: Internal.CallbackInfoReturnable_<any>): void;
        canBeCollidedWith(): boolean;
        asComponentProvider(): Internal.ComponentProvider;
        setY(y: number): void;
        getFeetBlockState(): Internal.BlockState;
        lavaHurt(): void;
        handleDamageEvent($$0: DamageSource_): void;
        getFabricBalmData(): Internal.CompoundTag;
        canChangeDimensions(): boolean;
        getChangeListener(): Internal.EntityInLevelCallback;
        static tickEntity(entity: Internal.Entity_): void;
        getCommandSenderWorld(): Internal.Level;
        positionRider($$0: Internal.Entity_): void;
        baseTick(): void;
        broadcastToPlayer($$0: Internal.ServerPlayer_): boolean;
        changeDimension($$0: Internal.ServerLevel_): Internal.Entity;
        setSharedFlag($$0: number, $$1: boolean): void;
        clearItemStacks(): void;
        handler$kom000$porting_lib_entity$afterLoad(nbt: Internal.CompoundTag_, ci: Internal.CallbackInfo_): void;
        isItemValid(slot: number, stack: Internal.ItemStack_): boolean;
        getCustomName(): net.minecraft.network.chat.Component;
        getClass(): typeof any;
        pehkui_shouldIgnoreScaleNbt(): boolean;
        isMoving(): boolean;
        isVisuallySwimming(): boolean;
        getMaxAirSupply(): number;
        attack(hp: number): void;
        createMenu($$0: number, $$1: Internal.Inventory_, $$2: Internal.Player_): Internal.AbstractContainerMenu;
        dynamicLightTick(): void;
        getFacing(): Internal.Direction;
        emf$isWet(): boolean;
        hasCustomDisplay(): boolean;
        "hasPassenger(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.Entity>): boolean;
        getDimensions($$0: Internal.Pose_): Internal.EntityDimensions;
        getHeight(): number;
        isPassengerOfSameVehicle($$0: Internal.Entity_): boolean;
        invokeGetLeashOffset(): Vec3d;
        getBoundingBoxForCulling(): Internal.AABB;
        isSwimming(): boolean;
        mayInteract($$0: Internal.Level_, $$1: BlockPos_): boolean;
        static collideBoundingBox(entity: Internal.Entity_, movement: Vec3d_, entityBoundingBox: Internal.AABB_, world: Internal.Level_, collisions: Internal.List_<any>): Vec3d;
        setSprinting($$0: boolean): void;
        getDynamicLightLevel(): Internal.Level;
        setPortalCooldown(): void;
        setX(x: number): void;
        trackingPosition(): Vec3d;
        getNameTagOffsetY(): number;
        setDisplayOffset($$0: number): void;
        canTakeItem($$0: net.minecraft.world.Container_, $$1: number, $$2: Internal.ItemStack_): boolean;
        isInvulnerable(): boolean;
        isInLava(): boolean;
        isInWater(): boolean;
        getPortalWaitTime(): number;
        awardKillScore($$0: Internal.Entity_, $$1: number, $$2: DamageSource_): void;
        getBlockStateOn(): Internal.BlockState;
        getFluidHeightLoosely(tag: Internal.TagKey_<any>): number;
        getFluidJumpThreshold(): number;
        clear(): void;
        unsetRemoved(): void;
        "setPositionAndRotation(double,double,double,float,float)"($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        self(): net.minecraft.world.Container;
        isInvisibleTo($$0: Internal.Player_): boolean;
        pehkui_getScaleCache(): Internal.ScaleData[];
        setFusionModel(layerIndex: number, model: Internal.Triple_<any, any, any>): void;
        setAirSupply($$0: number): void;
        getOnPos(): BlockPos;
        getRootVehicle(): Internal.Entity;
        etf$getWorld(): Internal.Level;
        save($$0: Internal.CompoundTag_): boolean;
        pehkui_getScales(): Internal.Map<any, any>;
        isNoGravity(): boolean;
        getDefaultDisplayOffset(): number;
        getSlots(): number;
        etf$getNbt(): Internal.CompoundTag;
        acceptsFailure(): boolean;
        etf$getBlockPos(): BlockPos;
        pehkui_setShouldIgnoreScaleNbt(ignore: boolean): void;
        setOnGroundWithKnownMovement($$0: boolean, $$1: Vec3d_): void;
        setItem($$0: number, $$1: Internal.ItemStack_): void;
        setOldPosAndRot(): void;
        emf$getY(): number;
        handler$kom000$porting_lib_entity$port_lib$entityInit(entityType: Internal.EntityType_<any>, world: Internal.Level_, ci: Internal.CallbackInfo_): void;
        bookshelf$createHoverEvent(): Internal.HoverEvent;
        isFree($$0: number, $$1: number, $$2: number): boolean;
        updateSwimming(): void;
        "moveTo(double,double,double)"($$0: number, $$1: number, $$2: number): void;
        setRemainingFireTicks($$0: number): void;
        getCachedFeetBlockState(): Internal.BlockState;
        shouldInformAdmins(): boolean;
        rideTick(): void;
        emf$age(): number;
        etf$hasCustomName(): boolean;
        /**
         * @deprecated
        */
        getOnPosLegacy(): BlockPos;
        setPos($$0: Vec3d_): void;
        wait(): void;
        getUuid(): Internal.UUID;
        spawn(): void;
        teleportTo($$0: Internal.ServerLevel_, $$1: number, $$2: number, $$3: number, $$4: Internal.Set_<Internal.RelativeMovement>, $$5: number, $$6: number): boolean;
        handler$kom000$porting_lib_entity$port_lib$removeRidingEntity(ci: Internal.CallbackInfo_): void;
        etf$getCustomName(): net.minecraft.network.chat.Component;
        captureDrops(value: Internal.Collection_<any>): Internal.Collection<any>;
        fabric_writeAttachmentsToNbt(nbt: Internal.CompoundTag_): void;
        shouldShowName(): boolean;
        setSilent($$0: boolean): void;
        getArmorSlots(): Internal.Iterable<Internal.ItemStack>;
        hasExactlyOnePlayerPassenger(): boolean;
        kill(): void;
        isOnPortalCooldown(): boolean;
        abstract isEmpty(): boolean;
        animateHurt($$0: number): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        handler$kom000$porting_lib_entity$port_lib$onEntityRemove(reason: Internal.Entity$RemovalReason_, ci: Internal.CallbackInfo_): void;
        lambdynlights$setTrackedLitChunkPos(trackedLitChunkPos: Internal.LongSet_): void;
        static createMinecart($$0: Internal.Level_, $$1: number, $$2: number, $$3: number, $$4: Internal.AbstractMinecart$Type_): Internal.AbstractMinecart;
        getBlock(level: Internal.Level_): Internal.BlockContainerJS;
        callGetEyeHeight(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        setPitch($$0: number): void;
        setPosRaw($$0: number, $$1: number, $$2: number): void;
        handleEntityEvent($$0: number): void;
        isAlwaysTicking(): boolean;
        interactAt($$0: Internal.Player_, $$1: Vec3d_, $$2: Internal.InteractionHand_): Internal.InteractionResult;
        emf$getX(): number;
        deserializeNBT(arg0: Internal.Tag_): void;
        puzzleslib$acceptCapturedDrops(capturedDrops: Internal.Collection_<any>): Internal.Collection<any>;
        handler$hak000$gobber2$gobberIsFireImmune(cir: Internal.CallbackInfoReturnable_<any>): void;
        lerpTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: boolean): void;
        onPassengerTurned($$0: Internal.Entity_): void;
        modifyReturnValue$zhe000$additionalentityattributes$getMaxAir(original: number): number;
        spawnAtLocation($$0: Internal.ItemLike_): Internal.ItemEntity;
        insertItem(stack: Internal.ItemStack_, simulate: boolean): Internal.ItemStack;
        emf$hasPassengers(): boolean;
        serializeNBT(): Internal.CompoundTag;
        setAttached(type: Internal.AttachmentType_<any>, value: any): any;
        getBbWidth(): number;
        splitIntoDynamicLightEntries(): Internal.Stream<Internal.SpatialLookupEntry>;
        setChestVehicleItem($$0: number, $$1: Internal.ItemStack_): void;
        port_lib$getEntityString(): string;
        addDeltaMovement($$0: Vec3d_): void;
        pehkui_setOnGround(onGround: boolean): void;
        lithiumOnBlockCacheDeleted(): void;
        find(ingredient: Internal.Ingredient_): number;
        "spawnAtLocation(net.minecraft.world.level.ItemLike,int)"($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        setInvulnerable($$0: boolean): void;
        "getName()"(): net.minecraft.network.chat.Component;
        push($$0: Internal.Entity_): void;
        emf$hasVehicle(): boolean;
        mirror($$0: Internal.Mirror_): number;
        activateMinecart($$0: number, $$1: number, $$2: number, $$3: boolean): void;
        setEnabled($$0: boolean): void;
        static port_lib$collideWithShapes(vec3: Vec3d_, aABB: Internal.AABB_, list: Internal.List_<Internal.VoxelShape>): Vec3d;
        getTicksRequiredToFreeze(): number;
        getDynamicLightPrevY(): number;
        maxUpStep(): number;
        setGlowing($$0: boolean): void;
        load($$0: Internal.CompoundTag_): void;
        setChanged(): void;
        isAlive(): boolean;
        emf$prevZ(): number;
        getBbHeight(): number;
        getUsername(): string;
        move($$0: Internal.MoverType_, $$1: Vec3d_): void;
        "isEmpty()"(): boolean;
        getTags(): Internal.Set<string>;
        getViewVector($$0: number): Vec3d;
        lithiumOnBlockCacheSet(newState: Internal.BlockState_): void;
        isPickable(): boolean;
        setYHeadRot($$0: number): void;
        getMinecartType(): Internal.AbstractMinecart$Type;
        hasControllingPassenger(): boolean;
        moveMinecartOnRail(pos: BlockPos_): void;
        closerThan($$0: Internal.Entity_, $$1: number, $$2: number): boolean;
        absMoveTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        getCustomData(): Internal.CompoundTag;
        getItem($$0: number): Internal.ItemStack;
        getPickResult(): Internal.ItemStack;
        getPercentFrozen(): number;
        getRandomY(): number;
        setPortalCooldown($$0: number): void;
        abstract getDisplayName(): net.minecraft.network.chat.Component;
        hasGlowingTag(): boolean;
        shouldBlockExplode($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: number): boolean;
        emf$isInvisible(): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        emf$isSprinting(): boolean;
        getDynamicLightPrevX(): number;
        shouldBeSaved(): boolean;
        fabric_hasPersistentAttachments(): boolean;
        getViewXRot($$0: number): number;
        canRiderInteract(): boolean;
        destroy($$0: DamageSource_): void;
        fabric_getAttachments(): Internal.Map<any, any>;
        removeTag($$0: string): boolean;
        setPose($$0: Internal.Pose_): void;
        getFluidHeight($$0: Internal.TagKey_<Internal.Fluid>): number;
        getEntityType(): Internal.EntityType<any>;
        isWaterCreature(): boolean;
        pehkui_getScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        toString(): string;
        notifyAll(): void;
        getPassengersRidingOffset(): number;
        etf$getScoreboardTeam(): Internal.Team;
        distanceToEntitySqr($$0: Internal.Entity_): number;
        handler$ldh000$puzzleslib$removeVehicle(callback: Internal.CallbackInfo_): void;
        "getServer()"(): Internal.MinecraftServer;
        isFrame(): boolean;
        isPushable(): boolean;
        setYBodyRot($$0: number): void;
        discard(): void;
        onClientRemoval(): void;
        "handler$mhe000$step-height-entity-attribute$getStepHeight"(cir: Internal.CallbackInfoReturnable_<any>): void;
        sendSystemMessage($$0: net.minecraft.network.chat.Component_): void;
        acceptsSuccess(): boolean;
        clearContent(): void;
        countNonEmpty(ingredient: Internal.Ingredient_): number;
        getDistance(x: number, y: number, z: number): number;
        setMotionY(y: number): void;
        setNoGravity($$0: boolean): void;
        static tryClear($$0: any): void;
        getAttached(type: Internal.AttachmentType_<any>): any;
        getIndirectPassengers(): Internal.Iterable<any>;
        setRotation(yaw: number, pitch: number): void;
        setLootTableSeed($$0: number): void;
        isDynamicLightEnabled(): boolean;
        handler$ldh000$puzzleslib$startRiding(vehicle: Internal.Entity_, force: boolean, callback: Internal.CallbackInfoReturnable_<any>): void;
        createCommandSourceStack(): Internal.CommandSourceStack;
        isControlledByLocalInstance(): boolean;
        isMonster(): boolean;
        pehkui_setShouldSyncScales(sync: boolean): void;
        setLastDynamicLuminance(luminance: number): void;
        setId($$0: number): void;
        onSyncedDataUpdated($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        getHorizontalFacing(): Internal.Direction;
        getType(): string;
        getLightProbePosition($$0: number): Vec3d;
        getDefaultDisplayBlockState(): Internal.BlockState;
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        onAboveBubbleCol($$0: boolean): void;
        emf$prevX(): number;
        "playSound(net.minecraft.sounds.SoundEvent,float,float)"($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        toComponentPacket(key: Internal.ComponentKey_<any>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        getMaxStackSize(): number;
        isPassenger(): boolean;
        hasPose($$0: Internal.Pose_): boolean;
        checkDespawn(): void;
        pehkui_shouldSyncScales(): boolean;
        isEyeInFluid($$0: Internal.TagKey_<Internal.Fluid>): boolean;
        isInvulnerableTo($$0: DamageSource_): boolean;
        makeStuckInBlock($$0: Internal.BlockState_, $$1: Vec3d_): void;
        getAttachedOrGet<A>(type: Internal.AttachmentType_<A>, defaultValue: Internal.Supplier_<A>): A;
        skipAttackInteraction($$0: Internal.Entity_): boolean;
        lerpMotion($$0: number, $$1: number, $$2: number): void;
        shouldRender($$0: number, $$1: number, $$2: number): boolean;
        onSyncedDataUpdated($$0: Internal.EntityDataAccessor_<any>): void;
        getHurtTime(): number;
        lerpHeadTo($$0: number, $$1: number): void;
        unpackChestVehicleLootTable($$0: Internal.Player_): void;
        getChestVehicleSlot($$0: number): Internal.SlotAccess;
        handler$bia000$axiom$onTurn(d: number, e: number, ci: Internal.CallbackInfo_): void;
        static getViewScale(): number;
        setMotionX(x: number): void;
        getHandSlots(): Internal.Iterable<Internal.ItemStack>;
        distanceToEntity($$0: Internal.Entity_): number;
        setTransferCooldown(currentTime: number): void;
        getVisualRotationYInDegrees(): number;
        wait(arg0: number, arg1: number): void;
        isDiscrete(): boolean;
        getTeamColor(): number;
        setNbt(nbt: Internal.CompoundTag_): void;
        lithiumSetClimbingMobCachingSectionUpdateBehavior(listening: boolean): void;
        unRide(): void;
        getLevel(): Internal.Level;
        "spawnAtLocation(net.minecraft.world.item.ItemStack)"($$0: Internal.ItemStack_): Internal.ItemEntity;
        lambdynlights$getTrackedLitChunkPos(): Internal.LongSet;
        extinguish(): void;
        suckInItems(): boolean;
        setDynamicLightEnabled(enabled: boolean): void;
        getStackInSlot(slot: number): Internal.ItemStack;
        readChestVehicleSaveData($$0: Internal.CompoundTag_): void;
        updateDynamicGameEventListener($$0: Internal.BiConsumer_<Internal.DynamicGameEventListener<any>, Internal.ServerLevel>): void;
        moveTo($$0: Vec3d_): void;
        isColliding($$0: BlockPos_, $$1: Internal.BlockState_): boolean;
        "onSyncedDataUpdated(net.minecraft.network.syncher.EntityDataAccessor)"($$0: Internal.EntityDataAccessor_<any>): void;
        emf$prevY(): number;
        extinguishFire(): void;
        lambdynlights$updateDynamicLight(renderer: Internal.LevelRenderer_): boolean;
        tell(message: net.minecraft.network.chat.Component_): void;
        static port_lib$collideWithShapes$porting_lib_accessors_$md$424943$0(arg0: Vec3d_, arg1: Internal.AABB_, arg2: Internal.List_<any>): Vec3d;
        isForcedVisible(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number): boolean;
        getDistanceSq(pos: BlockPos_): number;
        emf$getTypeString(): string;
        killedEntity($$0: Internal.ServerLevel_, $$1: Internal.LivingEntity_): boolean;
        getAttachedOrElse<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        isFreezing(): boolean;
        getLevelX(): number;
        invokeWillHitBlockAt(arg0: BlockPos_): boolean;
        isFullyFrozen(): boolean;
        runCommand(command: string): number;
        setDisplayBlockState($$0: Internal.BlockState_): void;
        setSharedFlagOnFire($$0: boolean): void;
        get inWall(): boolean
        get allSlots(): Internal.Iterable<Internal.ItemStack>
        get chestVehicleEmpty(): boolean
        get blockZ(): number
        get suppressingBounce(): boolean
        set hurtTime($$0: number)
        get silent(): boolean
        set culled(value: boolean)
        get pitch(): number
        get onFire(): boolean
        get positionCodec(): Internal.VecDeltaCodec
        get passengersAndSelf(): Internal.Stream<any>
        set maxUpStep($$0: number)
        get suckShape(): Internal.VoxelShape
        get shiftKeyDown(): boolean
        set UUID($$0: Internal.UUID_)
        get visuallyCrawling(): boolean
        get levelY(): number
        set motionZ(z: number)
        get dropItem(): Internal.Item
        get blockY(): number
        get isInsideStructureTracker(): Internal.IsInsideStructureTracker
        get spectator(): boolean
        get inWaterOrBubble(): boolean
        get persistentData(): Internal.CompoundTag
        get portalCooldown(): number
        get item(): Internal.ItemStack
        set removed($$0: Internal.Entity$RemovalReason_)
        get inWaterRainOrBubble(): boolean
        get removalReason(): Internal.Entity$RemovalReason
        get ignoringBlockTriggers(): boolean
        get damage(): number
        get levelZ(): number
        get steppingCarefully(): boolean
        set boundingBox($$0: Internal.AABB_)
        get ambientCreature(): boolean
        get displayBlockState(): Internal.BlockState
        get blockX(): number
        /**
         * @deprecated
        */
        get lightLevelDependentMagicValue(): number
        get encodeId(): string
        get block(): Internal.BlockContainerJS
        get nbt(): Internal.CompoundTag
        set invisible($$0: boolean)
        get name(): net.minecraft.network.chat.Component
        get dynamicLightY(): number
        get controlledVehicle(): Internal.Entity
        get eyePosition(): Vec3d
        get eyeHeight(): number
        get yaw(): number
        get componentContainer(): Internal.ComponentContainer
        get dynamicLightPrevZ(): number
        set customNameVisible($$0: boolean)
        set outOfCamera(value: boolean)
        get controllingPassenger(): Internal.LivingEntity
        get remainingFireTicks(): number
        get scriptType(): Internal.ScriptType
        get forward(): Vec3d
        get maxFallDistance(): number
        get id(): number
        get ticksFrozen(): number
        get allItems(): Internal.List<Internal.ItemStack>
        get recipientsForComponentSync(): Internal.Iterable<any>
        get dynamicLightZ(): number
        get eyeY(): number
        set statusMessage(message: net.minecraft.network.chat.Component_)
        get boundingBox(): Internal.AABB
        get inWaterOrRain(): boolean
        get descending(): boolean
        get mutable(): boolean
        get YHeadRot(): number
        get addEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>
        set damage($$0: number)
        get displayOffset(): number
        get team(): Internal.Team
        set ticksFrozen($$0: number)
        get width(): number
        get myRidingOffset(): number
        set deltaMovement($$0: Vec3d_)
        get culled(): boolean
        get living(): boolean
        get glowing(): boolean
        get x(): number
        get vehicle(): boolean
        get leashOffset(): Vec3d
        get attackable(): boolean
        get maxSpeedOnRail(): number
        set isInPowderSnow($$0: boolean)
        set customName($$0: net.minecraft.network.chat.Component_)
        get itemStacks(): Internal.NonNullList<Internal.ItemStack>
        get teamId(): string
        get underWater(): boolean
        get customNameVisible(): boolean
        get pistonPushReaction(): Internal.PushReaction
        get luminance(): number
        get selfAndPassengers(): Internal.Stream<any>
        get lootTableSeed(): number
        get deltaMovement(): Vec3d
        get motionX(): number
        get dynamicLightX(): number
        get entityData(): Internal.SynchedEntityData
        set secondsOnFire($$0: number)
        get "displayName()"(): net.minecraft.network.chat.Component
        get lootTable(): ResourceLocation
        get onRails(): boolean
        get dimensionChangingDelay(): number
        get peacefulCreature(): boolean
        set onGround($$0: boolean)
        get lastDynamicLuminance(): number
        set yaw($$0: number)
        get pickRadius(): number
        get vehicle(): Internal.Entity
        get effectiveAi(): boolean
        get stringUuid(): string
        get removed(): boolean
        set swimming($$0: boolean)
        get containerSize(): number
        get rotationVector(): Internal.Vec2
        get sprinting(): boolean
        get motionY(): number
        set luminance(luminance: number)
        set shiftKeyDown($$0: boolean)
        get passengers(): Internal.EntityArrayList
        set lootTable($$0: ResourceLocation_)
        get z(): number
        get server(): Internal.MinecraftServer
        get firstPassenger(): Internal.Entity
        set hurtDir($$0: number)
        get enabled(): boolean
        get soundSource(): Internal.SoundSource
        set fabricBalmData(tag: Internal.CompoundTag_)
        get pose(): Internal.Pose
        get hurtDir(): number
        get lookAngle(): Vec3d
        get motionZ(): number
        get invisible(): boolean
        set z(z: number)
        get y(): number
        get profile(): Internal.GameProfile
        set viewScale($$0: number)
        set levelCallback($$0: Internal.EntityInLevelCallback_)
        set customDisplay($$0: boolean)
        get currentRailPos(): BlockPos
        get pushedByFluid(): boolean
        get outOfCamera(): boolean
        get airSupply(): number
        set inventoryLithium(arg0: Internal.NonNullList_<any>)
        get inventoryLithium(): Internal.NonNullList<any>
        get crouching(): boolean
        get player(): boolean
        get animal(): boolean
        get motionDirection(): Internal.Direction
        set y(y: number)
        get feetBlockState(): Internal.BlockState
        get fabricBalmData(): Internal.CompoundTag
        get changeListener(): Internal.EntityInLevelCallback
        get commandSenderWorld(): Internal.Level
        get customName(): net.minecraft.network.chat.Component
        get class(): typeof any
        get moving(): boolean
        get visuallySwimming(): boolean
        get maxAirSupply(): number
        get facing(): Internal.Direction
        get height(): number
        get boundingBoxForCulling(): Internal.AABB
        get swimming(): boolean
        set sprinting($$0: boolean)
        get dynamicLightLevel(): Internal.Level
        set x(x: number)
        get nameTagOffsetY(): number
        set displayOffset($$0: number)
        get invulnerable(): boolean
        get inLava(): boolean
        get inWater(): boolean
        get portalWaitTime(): number
        get blockStateOn(): Internal.BlockState
        get fluidJumpThreshold(): number
        set airSupply($$0: number)
        get onPos(): BlockPos
        get rootVehicle(): Internal.Entity
        get noGravity(): boolean
        get defaultDisplayOffset(): number
        get slots(): number
        set remainingFireTicks($$0: number)
        get cachedFeetBlockState(): Internal.BlockState
        /**
         * @deprecated
        */
        get onPosLegacy(): BlockPos
        set pos($$0: Vec3d_)
        get uuid(): Internal.UUID
        set silent($$0: boolean)
        get armorSlots(): Internal.Iterable<Internal.ItemStack>
        get onPortalCooldown(): boolean
        get empty(): boolean
        set pitch($$0: number)
        get alwaysTicking(): boolean
        get bbWidth(): number
        set invulnerable($$0: boolean)
        get "name()"(): net.minecraft.network.chat.Component
        set enabled($$0: boolean)
        get ticksRequiredToFreeze(): number
        get dynamicLightPrevY(): number
        set glowing($$0: boolean)
        get alive(): boolean
        get bbHeight(): number
        get username(): string
        get "empty()"(): boolean
        get tags(): Internal.Set<string>
        get pickable(): boolean
        set YHeadRot($$0: number)
        get minecartType(): Internal.AbstractMinecart$Type
        get customData(): Internal.CompoundTag
        get pickResult(): Internal.ItemStack
        get percentFrozen(): number
        get randomY(): number
        set portalCooldown($$0: number)
        get displayName(): net.minecraft.network.chat.Component
        set position(block: Internal.BlockContainerJS_)
        get dynamicLightPrevX(): number
        set pose($$0: Internal.Pose_)
        get entityType(): Internal.EntityType<any>
        get waterCreature(): boolean
        get passengersRidingOffset(): number
        get "server()"(): Internal.MinecraftServer
        get frame(): boolean
        get pushable(): boolean
        set YBodyRot($$0: number)
        set motionY(y: number)
        set noGravity($$0: boolean)
        get indirectPassengers(): Internal.Iterable<any>
        set lootTableSeed($$0: number)
        get dynamicLightEnabled(): boolean
        get controlledByLocalInstance(): boolean
        get monster(): boolean
        set lastDynamicLuminance(luminance: number)
        set id($$0: number)
        get horizontalFacing(): Internal.Direction
        get type(): string
        get defaultDisplayBlockState(): Internal.BlockState
        get maxStackSize(): number
        get passenger(): boolean
        get hurtTime(): number
        get viewScale(): number
        set motionX(x: number)
        get handSlots(): Internal.Iterable<Internal.ItemStack>
        set transferCooldown(currentTime: number)
        get visualRotationYInDegrees(): number
        get discrete(): boolean
        get teamColor(): number
        set nbt(nbt: Internal.CompoundTag_)
        get level(): Internal.Level
        set dynamicLightEnabled(enabled: boolean)
        get forcedVisible(): boolean
        get freezing(): boolean
        get levelX(): number
        get fullyFrozen(): boolean
        set displayBlockState($$0: Internal.BlockState_)
        set sharedFlagOnFire($$0: boolean)
    }
    type MinecartHopper_ = MinecartHopper;
    class RandomSequences extends Internal.SavedData {
        constructor($$0: number)
        getClass(): typeof any;
        get($$0: ResourceLocation_): Internal.RandomSource;
        toString(): string;
        notifyAll(): void;
        isDirty(): boolean;
        notify(): void;
        "save(java.io.File)"($$0: Internal.File_): void;
        save($$0: Internal.CompoundTag_): Internal.CompoundTag;
        save($$0: Internal.File_): void;
        wait(arg0: number, arg1: number): void;
        setDirty(): void;
        hashCode(): number;
        static load($$0: number, $$1: Internal.CompoundTag_): Internal.RandomSequences;
        wait(): void;
        wait(arg0: number): void;
        setDirty($$0: boolean): void;
        equals(arg0: any): boolean;
        "save(net.minecraft.nbt.CompoundTag)"($$0: Internal.CompoundTag_): Internal.CompoundTag;
        get class(): typeof any
        get dirty(): boolean
        set dirty($$0: boolean)
    }
    type RandomSequences_ = RandomSequences;
    interface TemporalField {
        abstract range(): Internal.ValueRange;
        abstract isTimeBased(): boolean;
        abstract toString(): string;
        abstract rangeRefinedBy(arg0: Internal.TemporalAccessor_): Internal.ValueRange;
        abstract isSupportedBy(arg0: Internal.TemporalAccessor_): boolean;
        getDisplayName(arg0: Internal.Locale_): string;
        abstract isDateBased(): boolean;
        resolve(arg0: Internal.Map_<Internal.TemporalField, number>, arg1: Internal.TemporalAccessor_, arg2: Internal.ResolverStyle_): Internal.TemporalAccessor;
        abstract adjustInto<R extends Internal.Temporal>(arg0: R, arg1: number): R;
        abstract getBaseUnit(): Internal.TemporalUnit;
        abstract getRangeUnit(): Internal.TemporalUnit;
        abstract getFrom(arg0: Internal.TemporalAccessor_): number;
        get timeBased(): boolean
        get dateBased(): boolean
        get baseUnit(): Internal.TemporalUnit
        get rangeUnit(): Internal.TemporalUnit
    }
    type TemporalField_ = TemporalField;
    interface SoundInstance extends Internal.SoundInstanceMixin, Internal.FabricSoundInstance {
        getAudioStream(loader: Internal.SoundBufferLibrary_, id: ResourceLocation_, repeatInstantly: boolean): Internal.CompletableFuture<Internal.AudioStream>;
        abstract getAttenuation(): Internal.SoundInstance$Attenuation;
        abstract getLocation(): ResourceLocation;
        abstract getSource(): Internal.SoundSource;
        abstract resolve(arg0: Internal.SoundManager_): Internal.WeighedSoundEvents;
        canStartSilent(): boolean;
        abstract getDelay(): number;
        canPlaySound(): boolean;
        abstract getX(): number;
        abstract isLooping(): boolean;
        abstract getVolume(): number;
        abstract getY(): number;
        abstract getZ(): number;
        abstract getPitch(): number;
        abstract getSound(): Internal.Sound;
        abstract isRelative(): boolean;
        createUnseededRandom(): Internal.RandomSource;
        get attenuation(): Internal.SoundInstance$Attenuation
        get location(): ResourceLocation
        get source(): Internal.SoundSource
        get delay(): number
        get x(): number
        get looping(): boolean
        get volume(): number
        get y(): number
        get z(): number
        get pitch(): number
        get sound(): Internal.Sound
        get relative(): boolean
    }
    type SoundInstance_ = SoundInstance;
    class EntityArgument$Info implements Internal.ArgumentTypeInfo<Internal.EntityArgument, Internal.EntityArgument$Info$Template> {
        constructor()
        getClass(): typeof any;
        deserializeFromNetwork($$0: Internal.FriendlyByteBuf_): Internal.EntityArgument$Info$Template;
        "serializeToNetwork(net.minecraft.commands.arguments.EntityArgument$Info$Template,net.minecraft.network.FriendlyByteBuf)"($$0: Internal.EntityArgument$Info$Template_, $$1: Internal.FriendlyByteBuf_): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        "serializeToJson(net.minecraft.commands.arguments.EntityArgument$Info$Template,com.google.gson.JsonObject)"($$0: Internal.EntityArgument$Info$Template_, $$1: Internal.JsonObject_): void;
        unpack($$0: Internal.EntityArgument_): Internal.EntityArgument$Info$Template;
        serializeToJson($$0: Internal.EntityArgument$Info$Template_, $$1: Internal.JsonObject_): void;
        "deserializeFromNetwork(net.minecraft.network.FriendlyByteBuf)"($$0: Internal.FriendlyByteBuf_): Internal.EntityArgument$Info$Template;
        serializeToJson(arg0: Internal.ArgumentTypeInfo$Template_<any>, arg1: Internal.JsonObject_): void;
        deserializeFromNetwork(arg0: Internal.FriendlyByteBuf_): Internal.ArgumentTypeInfo$Template<any>;
        toString(): string;
        notifyAll(): void;
        "deserializeFromNetwork(net.minecraft.network.FriendlyByteBuf)"(arg0: Internal.FriendlyByteBuf_): Internal.ArgumentTypeInfo$Template<any>;
        "unpack(com.mojang.brigadier.arguments.ArgumentType)"(arg0: Internal.ArgumentType_<any>): Internal.ArgumentTypeInfo$Template<any>;
        unpack(arg0: Internal.ArgumentType_<any>): Internal.ArgumentTypeInfo$Template<any>;
        hashCode(): number;
        "unpack(net.minecraft.commands.arguments.EntityArgument)"($$0: Internal.EntityArgument_): Internal.EntityArgument$Info$Template;
        wait(): void;
        wait(arg0: number): void;
        serializeToNetwork(arg0: Internal.ArgumentTypeInfo$Template_<any>, arg1: Internal.FriendlyByteBuf_): void;
        "serializeToNetwork(net.minecraft.commands.synchronization.ArgumentTypeInfo$Template,net.minecraft.network.FriendlyByteBuf)"(arg0: Internal.ArgumentTypeInfo$Template_<any>, arg1: Internal.FriendlyByteBuf_): void;
        equals(arg0: any): boolean;
        "serializeToJson(net.minecraft.commands.synchronization.ArgumentTypeInfo$Template,com.google.gson.JsonObject)"(arg0: Internal.ArgumentTypeInfo$Template_<any>, arg1: Internal.JsonObject_): void;
        serializeToNetwork($$0: Internal.EntityArgument$Info$Template_, $$1: Internal.FriendlyByteBuf_): void;
        get class(): typeof any
    }
    type EntityArgument$Info_ = EntityArgument$Info;
    class DesertRuinFeature extends Feature<Internal.NoneFeatureConfiguration> {
        constructor(pCodec: Internal.Codec_<Internal.NoneFeatureConfiguration>)
        getClass(): typeof any;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        place($$0: Internal.NoneFeatureConfiguration_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        place(pContext: Internal.FeaturePlaceContext_<Internal.NoneFeatureConfiguration>): boolean;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.NoneFeatureConfiguration, Feature<Internal.NoneFeatureConfiguration>>>;
        get class(): typeof any
    }
    type DesertRuinFeature_ = DesertRuinFeature;
    interface TomeEffect <T, R> {
        withCooldown<T, R>(effect: Internal.TomeEffect_<T, R>, cooldown: number): this;
        withExpCost<T, R>(effect: Internal.TomeEffect_<T, R>, pointCost: number): this;
        abstract apply(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.InteractionHand_, arg3: T): R;
        (arg0: Internal.ItemStack, arg1: Internal.Player, arg2: Internal.InteractionHand, arg3: T): R;
    }
    type TomeEffect_<T, R> = ((arg0: Internal.ItemStack, arg1: Internal.Player, arg2: Internal.InteractionHand, arg3: T)=> R) | TomeEffect<T, R>;
    interface ArgumentSignatures$Signer {
        abstract sign(arg0: string): Internal.MessageSignature;
        (arg0: string): Internal.MessageSignature_;
    }
    type ArgumentSignatures$Signer_ = ((arg0: string)=> Internal.MessageSignature_) | ArgumentSignatures$Signer;
    class CraftyCratePattern extends Internal.Enum<Internal.CraftyCratePattern> implements Internal.StringRepresentable {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        static values(): Internal.CraftyCratePattern[];
        static fromEnumWithMapping<E extends Internal.Enum<E> & Internal.StringRepresentable>($$0: Internal.Supplier_<E[]>, $$1: Internal.Function_<string, string>): Internal.StringRepresentable$EnumCodec<E>;
        toString(): string;
        getSerializedName(): string;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        name(): string;
        getDeclaringClass(): typeof Internal.CraftyCratePattern;
        "compareTo(vazkii.botania.api.state.enums.CraftyCratePattern)"(arg0: Internal.CraftyCratePattern_): number;
        hashCode(): number;
        static keys($$0: Internal.StringRepresentable_[]): Internal.Keyable;
        static fromEnum<E extends Internal.Enum<E> & Internal.StringRepresentable>($$0: Internal.Supplier_<E[]>): Internal.StringRepresentable$EnumCodec<E>;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        compareTo(arg0: Internal.CraftyCratePattern_): number;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        static valueOf(name: string): Internal.CraftyCratePattern;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.CraftyCratePattern>>;
        get class(): typeof any
        get serializedName(): string
        get declaringClass(): typeof Internal.CraftyCratePattern
        static readonly CRAFTY_3_2: (Internal.CraftyCratePattern) & (Internal.CraftyCratePattern);
        readonly openSlots: Internal.List<boolean>;
        static readonly CRAFTY_2_3: (Internal.CraftyCratePattern) & (Internal.CraftyCratePattern);
        static readonly NONE: (Internal.CraftyCratePattern) & (Internal.CraftyCratePattern);
        static readonly CRAFTY_DONUT: (Internal.CraftyCratePattern) & (Internal.CraftyCratePattern);
        static readonly CRAFTY_2_2: (Internal.CraftyCratePattern) & (Internal.CraftyCratePattern);
        static readonly CRAFTY_1_3: (Internal.CraftyCratePattern) & (Internal.CraftyCratePattern);
        static readonly CRAFTY_1_2: (Internal.CraftyCratePattern) & (Internal.CraftyCratePattern);
        static readonly CRAFTY_2_1: (Internal.CraftyCratePattern) & (Internal.CraftyCratePattern);
        static readonly CRAFTY_3_1: (Internal.CraftyCratePattern) & (Internal.CraftyCratePattern);
        static readonly CRAFTY_1_1: (Internal.CraftyCratePattern) & (Internal.CraftyCratePattern);
    }
    type CraftyCratePattern_ = CraftyCratePattern | "crafty_1_1" | "crafty_1_2" | "crafty_2_1" | "crafty_2_2" | "crafty_1_3" | "crafty_3_1" | "crafty_2_3" | "crafty_3_2" | "none" | "crafty_donut";
    interface MapDecorationType <D extends Internal.CustomMapDecoration, M extends Internal.MapBlockMarker<D>> {
        abstract loadDecorationFromBuffer(arg0: Internal.FriendlyByteBuf_): D;
        abstract isFromWorld(): boolean;
        abstract createEmptyMarker(): M;
        abstract loadMarkerFromNBT(arg0: Internal.CompoundTag_): M;
        getAssociatedStructure(): Optional<Internal.HolderSet<Internal.Structure>>;
        abstract getWorldMarkerFromWorld(arg0: Internal.BlockGetter_, arg1: BlockPos_): M;
        getDefaultMapColor(): number;
        getCustomFactoryID(): ResourceLocation;
        get fromWorld(): boolean
        get associatedStructure(): Optional<Internal.HolderSet<Internal.Structure>>
        get defaultMapColor(): number
        get customFactoryID(): ResourceLocation
    }
    type MapDecorationType_<D extends Internal.CustomMapDecoration, M extends Internal.MapBlockMarker<D>> = Special.MapMarkers | MapDecorationType<D, M>;
    interface ToDoubleFunction <T> {
        abstract applyAsDouble(arg0: T): number;
        (arg0: T): number;
    }
    type ToDoubleFunction_<T> = ToDoubleFunction<T> | ((arg0: T)=> number);
    class PistonBaseBlock extends Internal.DirectionalBlock implements Internal.PistonBaseBlockAccessor {
        constructor($$0: boolean, $$1: Internal.BlockBehaviour$Properties_)
        /**
         * @deprecated
        */
        getOcclusionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        /**
         * @deprecated
        */
        getSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        axiom$customPickBlockStack(): Internal.ItemStack;
        getSoundType($$0: Internal.BlockState_): SoundType;
        /**
         * @deprecated
        */
        getVisualShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        handler$egm000$collective$triggerEvent_default(blockState: Internal.BlockState_, level: Internal.Level_, blockPos: BlockPos_, i: number, j: number, cir: Internal.CallbackInfoReturnable_<any>): void;
        handler$efo000$collective$Block_playerDestroy(level: Internal.Level_, player: Internal.Player_, blockPos: BlockPos_, blockState: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number, $$5: number): void;
        /**
         * @deprecated
        */
        randomTick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: Internal.BlockEntity_): void;
        static canSupportRigidBlock($$0: Internal.BlockGetter_, $$1: BlockPos_): boolean;
        static popResource($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.ItemStack_): void;
        setRandomTickCallback(callback: Internal.Consumer_<any>): void;
        getDescriptionId(): string;
        stepOn($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Entity_): void;
        fallOn($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: BlockPos_, $$3: Internal.Entity_, $$4: number): void;
        getSettings(): Internal.BlockBehaviour$Properties;
        triggerEvent($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: number, $$4: number): boolean;
        getExplosionResistance(): number;
        asItem(): Internal.Item;
        getTypeData(): Internal.CompoundTag;
        setFriction(arg0: number): void;
        /**
         * @deprecated
        */
        getRenderShape($$0: Internal.BlockState_): Internal.RenderShape;
        handler$gli000$ftbchunks$onMoveBlocks(level: Internal.Level_, blockPos: BlockPos_, direction: Internal.Direction_, extending: boolean, cir: Internal.CallbackInfoReturnable_<any>, pistonStructureResolver: Internal.PistonStructureResolver_): void;
        canCull(): boolean;
        customShapeUpdate(blockState: Internal.CustomBlockState_, levelReader: Internal.LevelReader_, blockPos: BlockPos_): Internal.CustomBlockState;
        getJumpFactor(): number;
        getSpeedFactor(): number;
        static canSupportCenter($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        skipRendering($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getLightBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        playerDestroy($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.BlockEntity_, $$5: Internal.ItemStack_): void;
        shouldAttemptToCull(state: Internal.BlockState_): boolean;
        isPossibleToRespawnInThis($$0: Internal.BlockState_): boolean;
        getCustomStateForPlacement(blockPlaceContext: Internal.BlockPlaceContext_): Internal.CustomBlockState;
        /**
         * @deprecated
        */
        getDirectSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        getProperties(): Internal.BlockBehaviour$Properties;
        playerWillDestroy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Player_): void;
        getClass(): typeof any;
        getMaxVerticalOffset(): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.item.context.BlockPlaceContext)"($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        useShapeForLightOcclusion($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        getDrops($$0: Internal.BlockState_, $$1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getStateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>;
        /**
         * @deprecated
        */
        entityInside($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Entity_): void;
        setBlockBuilder(b: Internal.BlockBuilder_): void;
        handler$ldb000$puzzleslib$playerDestroy$0(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        setRequiresTool(v: boolean): void;
        setSpeedFactor(arg0: number): void;
        axiom$getPossibleCustomStates(): Internal.List<any>;
        setExplosionResistance(arg0: number): void;
        toString(): string;
        port_lib$popExperience(arg0: Internal.ServerLevel_, arg1: BlockPos_, arg2: number): void;
        notifyAll(): void;
        getToolModifiedState(state: Internal.BlockState_, world: Internal.Level_, pos: BlockPos_, player: Internal.Player_, stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): Internal.BlockState;
        getId(): string;
        getLootTable(): ResourceLocation;
        puzzleslib$setItem(arg0: Internal.Item_): void;
        axiom$translationKey(): string;
        /**
         * @deprecated
        */
        getInteractionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        setPlacedBy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.LivingEntity_, $$4: Internal.ItemStack_): void;
        onPlace($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        propagatesSkylightDown($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Block>;
        static popResourceFromFace($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.ItemStack_): void;
        getFriction(): number;
        handlePrecipitation($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Biome$Precipitation_): void;
        /**
         * @deprecated
        */
        hasAnalogOutputSignal($$0: Internal.BlockState_): boolean;
        wait(arg0: number): void;
        /**
         * @deprecated
        */
        getFluidState($$0: Internal.BlockState_): Internal.FluidState;
        handler$koh000$porting_lib_entity$getDestroySpeed(blockState: Internal.BlockState_, player: Internal.Player_, blockGetter: Internal.BlockGetter_, pos: BlockPos_, cir: Internal.CallbackInfoReturnable_<any>): void;
        /**
         * @deprecated
        */
        getAnalogOutputSignal($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): number;
        handler$efo000$collective$Block_setPlacedBy(level: Internal.Level_, blockPos: BlockPos_, blockState: Internal.BlockState_, livingEntity: Internal.LivingEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static isPushable($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Direction_, $$4: boolean, $$5: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        tick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        supportsExternalFaceHiding(state: Internal.BlockState_): boolean;
        handler$ldb000$puzzleslib$playerDestroy$1(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        notify(): void;
        axiom$asItemStack(): Internal.ItemStack;
        neighborChanged($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Block_, $$4: BlockPos_, $$5: boolean): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): void;
        handler$zhd000$additionalentityattributes$additionalEntityAttributes$saveBreakingPlayer(world: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, stack: Internal.ItemStack_, callbackInfo: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        getBlockSupportShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        canSustainPlant(state: Internal.BlockState_, world: Internal.BlockGetter_, pos: BlockPos_, facing: Internal.Direction_, plantable: Internal.IPlantable_): boolean;
        /**
         * @deprecated
        */
        isCollisionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static isFaceFull($$0: Internal.VoxelShape_, $$1: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getMenuProvider($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): Internal.MenuProvider;
        static byItem($$0: Internal.Item_): Internal.Block;
        static updateFromNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        updateIndirectNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: number, $$4: number): void;
        destroy($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): void;
        handler$fdc000$everycomp$addSimpleFastECdrops(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, cir: Internal.CallbackInfoReturnable_<any>, resId: ResourceLocation_, lootParams: Internal.LootParams_, serverLevel: Internal.ServerLevel_, lootTable: Internal.LootTable_): void;
        getToolModifiedState(state: Internal.BlockState_, context: Internal.UseOnContext_, toolAction: Internal.ToolAction_, simulate: boolean): Internal.BlockState;
        /**
         * @deprecated
        */
        use($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_, $$4: Internal.InteractionHand_, $$5: Internal.BlockHitResult_): Internal.InteractionResult;
        setLightEmission(v: number): void;
        doNormalInteractions(): boolean;
        setJumpFactor(arg0: number): void;
        /**
         * @deprecated
        */
        canSurvive($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): void;
        /**
         * @deprecated
        */
        getShadeBrightness($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        getAppearance(state: Internal.BlockState_, renderView: Internal.BlockAndTintGetter_, pos: BlockPos_, side: Internal.Direction_, sourceState: Internal.BlockState_, sourcePos: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        getCollisionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        setDestroySpeed(v: number): void;
        defaultBlockState(): Internal.BlockState;
        usesCustomShouldDrawFace(state: Internal.BlockState_): boolean;
        getStateForPlacement($$0: Internal.BlockPlaceContext_): Internal.BlockState;
        cantCullAgainst(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        arch$holder(): Internal.Holder<Internal.Block>;
        wait(): void;
        getCloneItemStack($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        hasDynamicShape(): boolean;
        getMaxHorizontalOffset(): number;
        /**
         * @deprecated
        */
        getDestroyProgress($$0: Internal.BlockState_, $$1: Internal.Player_, $$2: Internal.BlockGetter_, $$3: BlockPos_): number;
        /**
         * @deprecated
        */
        getSeed($$0: Internal.BlockState_, $$1: BlockPos_): number;
        defaultDestroyTime(): number;
        dropFromExplosion($$0: Internal.Explosion_): boolean;
        /**
         * @deprecated
        */
        updateShape($$0: Internal.BlockState_, $$1: Internal.Direction_, $$2: Internal.BlockState_, $$3: Internal.LevelAccessor_, $$4: BlockPos_, $$5: BlockPos_): Internal.BlockState;
        isRandomlyTicking($$0: Internal.BlockState_): boolean;
        static isShapeFullBlock(shape: Internal.VoxelShape_): boolean;
        withPropertiesOf($$0: Internal.BlockState_): Internal.BlockState;
        static isExceptionForConnection($$0: Internal.BlockState_): boolean;
        setIsRandomlyTicking(arg0: boolean): void;
        rotate($$0: Internal.BlockState_, $$1: Internal.Rotation_): Internal.BlockState;
        hidesNeighborFace(level: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, neighborState: Internal.BlockState_, dir: Internal.Direction_): boolean;
        onTreeGrow(state: Internal.BlockState_, level: Internal.LevelReader_, placeFunction: Internal.BiConsumer_<BlockPos, Internal.BlockState>, randomSource: Internal.RandomSource_, pos: BlockPos_, config: Internal.TreeConfiguration_): boolean;
        botania_moveBlocks(arg0: Internal.Level_, arg1: BlockPos_, arg2: Internal.Direction_, arg3: boolean): boolean;
        defaultMapColor(): Internal.MapColor;
        getStateAtViewpoint(state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_, viewpoint: Vec3d_): Internal.BlockState;
        wait(arg0: number, arg1: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.BlockGetter_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        setNameKey(arg0: string): void;
        static box($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): Internal.VoxelShape;
        mirror($$0: Internal.BlockState_, $$1: Internal.Mirror_): Internal.BlockState;
        wasExploded($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Explosion_): void;
        getName(): Internal.MutableComponent;
        updateEntityAfterFallOn($$0: Internal.BlockGetter_, $$1: Internal.Entity_): void;
        animateTick($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        customShouldDrawFace(view: Internal.BlockGetter_, thisState: Internal.BlockState_, sideState: Internal.BlockState_, thisPos: BlockPos_, sidePos: BlockPos_, side: Internal.Direction_): Optional<boolean>;
        axiom$getResourceLocation(): ResourceLocation;
        arch$registryName(): ResourceLocation;
        axiom$getProperties(): Internal.Collection<any>;
        getBlockBuilder(): Internal.BlockBuilder;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        isSignalSource($$0: Internal.BlockState_): boolean;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number): void;
        /**
         * @deprecated
        */
        attack($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): void;
        getShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        shouldAttemptToCull(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        handler$egm000$collective$triggerEvent_extended(blockState: Internal.BlockState_, level: Internal.Level_, blockPos: BlockPos_, i: number, j: number, cir: Internal.CallbackInfoReturnable_<any>): void;
        /**
         * @deprecated
        */
        onProjectileHit($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockHitResult_, $$3: Internal.Projectile_): void;
        static stateById($$0: number): Internal.BlockState;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): Internal.List<Internal.ItemStack>;
        requiredFeatures(): Internal.FeatureFlagSet;
        hashCode(): number;
        axiom$defaultCustomState(): Internal.CustomBlockState;
        setCanCull(canCull: boolean): void;
        /**
         * @deprecated
        */
        isOcclusionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static getId($$0: Internal.BlockState_): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.material.Fluid)"($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        static pushEntitiesUp($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): Internal.BlockState;
        isPathfindable($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.PathComputationType_): boolean;
        setSoundType(arg0: SoundType_): void;
        handler$cef000$betterend$be_getDroppedStacks(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, info: Internal.CallbackInfoReturnable_<any>): void;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_): Internal.List<Internal.ItemStack>;
        /**
         * @deprecated
        */
        onRemove($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        cantCullAgainst(state: Internal.BlockState_): boolean;
        setHasCollision(arg0: boolean): void;
        static shouldRenderFace($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_, $$4: BlockPos_): boolean;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        spawnAfterBreak($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.ItemStack_, $$4: boolean): void;
        set randomTickCallback(callback: Internal.Consumer_<any>)
        get descriptionId(): string
        get settings(): Internal.BlockBehaviour$Properties
        get explosionResistance(): number
        get typeData(): Internal.CompoundTag
        set friction(arg0: number)
        get jumpFactor(): number
        get speedFactor(): number
        get properties(): Internal.BlockBehaviour$Properties
        get class(): typeof any
        get maxVerticalOffset(): number
        get stateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>
        set blockBuilder(b: Internal.BlockBuilder_)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        set speedFactor(arg0: number)
        set explosionResistance(arg0: number)
        get id(): string
        get lootTable(): ResourceLocation
        get friction(): number
        set lightEmission(v: number)
        set jumpFactor(arg0: number)
        set destroySpeed(v: number)
        get maxHorizontalOffset(): number
        set isRandomlyTicking(arg0: boolean)
        set nameKey(arg0: string)
        get name(): Internal.MutableComponent
        get blockBuilder(): Internal.BlockBuilder
        get idLocation(): ResourceLocation
        get mod(): string
        set canCull(canCull: boolean)
        set soundType(arg0: SoundType_)
        set hasCollision(arg0: boolean)
        static readonly TRIGGER_DROP: (2) & (number);
        static readonly TRIGGER_EXTEND: (0) & (number);
        static readonly EXTENDED: (Internal.BooleanProperty) & (Internal.BooleanProperty);
        static readonly PLATFORM_THICKNESS: (4.0) & (number);
        static readonly TRIGGER_CONTRACT: (1) & (number);
    }
    type PistonBaseBlock_ = PistonBaseBlock;
    class StalactiteFeature extends Feature<Internal.StalactiteFeatureConfig> {
        constructor()
        getClass(): typeof any;
        place(featureConfig: Internal.FeaturePlaceContext_<Internal.StalactiteFeatureConfig>): boolean;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        place($$0: Internal.StalactiteFeatureConfig_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.StalactiteFeatureConfig, Feature<Internal.StalactiteFeatureConfig>>>;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        get class(): typeof any
    }
    type StalactiteFeature_ = StalactiteFeature;
    class AzaleaFlowerPatchFeature extends Feature<Internal.AzaleaFlowerPatchConfig> {
        constructor(codec: Internal.Codec_<Internal.AzaleaFlowerPatchConfig>)
        getClass(): typeof any;
        toString(): string;
        place(featurePlaceContext: Internal.FeaturePlaceContext_<Internal.AzaleaFlowerPatchConfig>): boolean;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        place($$0: Internal.AzaleaFlowerPatchConfig_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.AzaleaFlowerPatchConfig, Feature<Internal.AzaleaFlowerPatchConfig>>>;
        wait(): void;
        matchesBlock(state: Internal.BlockState_): boolean;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        get class(): typeof any
    }
    type AzaleaFlowerPatchFeature_ = AzaleaFlowerPatchFeature;
    abstract class WallScatterFeature <FC extends Internal.ScatterFeatureConfig> extends Feature<FC> {
        constructor(codec: Internal.Codec_<FC>)
        getClass(): typeof any;
        place($$0: FC, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        toString(): string;
        place(featureConfig: Internal.FeaturePlaceContext_<FC>): boolean;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        notify(): void;
        abstract generate(arg0: FC, arg1: Internal.WorldGenLevel_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: Internal.Direction_): void;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<FC, Feature<FC>>>;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        wait(): void;
        abstract canGenerate(arg0: FC, arg1: Internal.WorldGenLevel_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: Internal.Direction_): boolean;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        get class(): typeof any
    }
    type WallScatterFeature_<FC extends Internal.ScatterFeatureConfig> = WallScatterFeature<FC>;
    class DustParticleOptions extends Internal.DustParticleOptionsBase {
        constructor($$0: Vec3f_, $$1: number)
        getClass(): typeof any;
        static "readVector3f(net.minecraft.network.FriendlyByteBuf)"($$0: Internal.FriendlyByteBuf_): Vec3f;
        toString(): string;
        static "readVector3f(com.mojang.brigadier.StringReader)"($$0: Internal.StringReader_): Vec3f;
        notifyAll(): void;
        writeToNetwork($$0: Internal.FriendlyByteBuf_): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getScale(): number;
        static readVector3f($$0: Internal.StringReader_): Vec3f;
        hashCode(): number;
        static readVector3f($$0: Internal.FriendlyByteBuf_): Vec3f;
        getColor(): Vec3f;
        wait(): void;
        writeToString(): string;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        getType(): Internal.ParticleType<Internal.DustParticleOptions>;
        get class(): typeof any
        get scale(): number
        get color(): Vec3f
        get type(): Internal.ParticleType<Internal.DustParticleOptions>
        static readonly DESERIALIZER: Internal.ParticleOptions$Deserializer<Internal.DustParticleOptions>;
        static readonly REDSTONE: (Internal.DustParticleOptions) & (Internal.DustParticleOptions);
        static readonly REDSTONE_PARTICLE_COLOR: (Vec3f) & (Vec3f);
        static readonly CODEC: Internal.Codec<Internal.DustParticleOptions>;
    }
    type DustParticleOptions_ = DustParticleOptions;
    class ClientboundSetTitleTextPacket implements Internal.Packet<Internal.ClientGamePacketListener> {
        constructor($$0: net.minecraft.network.chat.Component_)
        constructor($$0: Internal.FriendlyByteBuf_)
        handle(arg0: Internal.PacketListener_): void;
        getClass(): typeof any;
        write($$0: Internal.FriendlyByteBuf_): void;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        isSkippable(): boolean;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        wait(): void;
        getText(): net.minecraft.network.chat.Component;
        handle($$0: Internal.ClientGamePacketListener_): void;
        wait(arg0: number): void;
        "handle(net.minecraft.network.protocol.game.ClientGamePacketListener)"($$0: Internal.ClientGamePacketListener_): void;
        equals(arg0: any): boolean;
        "handle(net.minecraft.network.PacketListener)"(arg0: Internal.PacketListener_): void;
        get class(): typeof any
        get skippable(): boolean
        get text(): net.minecraft.network.chat.Component
    }
    type ClientboundSetTitleTextPacket_ = ClientboundSetTitleTextPacket;
    interface BakedOpacity {
        hasTextureTranslucency(state: Internal.BlockState_, direction: Internal.Direction_): boolean;
        setCullingShape(cullingShape: Internal.VoxelShape_): void;
        resetTranslucencyCache(): void;
        canSetCullingShape(): boolean;
        hasTextureTranslucency(): boolean;
        /**
         * @deprecated
        */
        getModels(): Internal.List<Internal.BakedModel>;
        getCullingShape(state: Internal.BlockState_): Internal.VoxelShape;
        hasTextureTranslucency(state: Internal.BlockState_): boolean;
        set cullingShape(cullingShape: Internal.VoxelShape_)
        /**
         * @deprecated
        */
        get models(): Internal.List<Internal.BakedModel>
    }
    type BakedOpacity_ = BakedOpacity;
    interface Script {
        abstract exec(arg0: Internal.Context_, arg1: Internal.Scriptable_): any;
        (arg0: Internal.Context, arg1: Internal.Scriptable): any;
    }
    type Script_ = Script | ((arg0: Internal.Context, arg1: Internal.Scriptable)=> any);
    class GingerbreadCookieDoughStarItem extends Internal.Item {
        constructor()
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(itemstack: Internal.ItemStack_, world: Internal.Level_, list: Internal.List_<net.minecraft.network.chat.Component>, flag: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration(itemstack: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type GingerbreadCookieDoughStarItem_ = GingerbreadCookieDoughStarItem;
    class CastingEnvironment$HeldItemInfo extends Internal.Record {
        constructor(stack: Internal.ItemStack_, hand: Internal.InteractionHand_)
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        component1(): Internal.ItemStack;
        notify(): void;
        component2(): Internal.InteractionHand;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        hand(): Internal.InteractionHand;
        wait(): void;
        wait(arg0: number): void;
        stack(): Internal.ItemStack;
        equals(o: any): boolean;
        get class(): typeof any
    }
    type CastingEnvironment$HeldItemInfo_ = CastingEnvironment$HeldItemInfo;
    class AttributedCharacterIterator$Attribute implements Internal.Serializable {
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        static readonly LANGUAGE: (Internal.AttributedCharacterIterator$Attribute) & (Internal.AttributedCharacterIterator$Attribute);
        static readonly READING: (Internal.AttributedCharacterIterator$Attribute) & (Internal.AttributedCharacterIterator$Attribute);
        static readonly INPUT_METHOD_SEGMENT: (Internal.AttributedCharacterIterator$Attribute) & (Internal.AttributedCharacterIterator$Attribute);
    }
    type AttributedCharacterIterator$Attribute_ = AttributedCharacterIterator$Attribute;
    abstract class Calendar implements Internal.Cloneable, Internal.Comparable<Internal.Calendar>, Internal.Serializable {
        getWeekYear(): number;
        getDisplayNames(arg0: number, arg1: number, arg2: Internal.Locale_): Internal.Map<string, number>;
        abstract "roll(int,boolean)"(arg0: number, arg1: boolean): void;
        toInstant(): Internal.Instant;
        abstract getMinimum(arg0: number): number;
        set(arg0: number, arg1: number, arg2: number): void;
        static getAvailableLocales(): Internal.Locale[];
        notify(): void;
        setFirstDayOfWeek(arg0: number): void;
        compareTo(arg0: any): number;
        getTimeInMillis(): number;
        "roll(int,int)"(arg0: number, arg1: number): void;
        static getInstance(arg0: Internal.Locale_): Internal.Calendar;
        clear(arg0: number): void;
        abstract getGreatestMinimum(arg0: number): number;
        getMinimalDaysInFirstWeek(): number;
        "compareTo(java.util.Calendar)"(arg0: Internal.Calendar_): number;
        setTime(arg0: Internal.Date_): void;
        roll(arg0: number, arg1: number): void;
        wait(): void;
        set(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number): void;
        "compareTo(java.lang.Object)"(arg0: any): number;
        setLenient(arg0: boolean): void;
        clone(): any;
        getClass(): typeof any;
        static "getInstance(java.util.Locale)"(arg0: Internal.Locale_): Internal.Calendar;
        static getInstance(arg0: Internal.TimeZone_, arg1: Internal.Locale_): Internal.Calendar;
        setWeekDate(arg0: number, arg1: number, arg2: number): void;
        set(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): void;
        isSet(arg0: number): boolean;
        compareTo(arg0: Internal.Calendar_): number;
        wait(arg0: number, arg1: number): void;
        getCalendarType(): string;
        static getInstance(): Internal.Calendar;
        setMinimalDaysInFirstWeek(arg0: number): void;
        abstract add(arg0: number, arg1: number): void;
        set(arg0: number, arg1: number): void;
        isLenient(): boolean;
        abstract getLeastMaximum(arg0: number): number;
        isWeekDateSupported(): boolean;
        static "getInstance(java.util.TimeZone)"(arg0: Internal.TimeZone_): Internal.Calendar;
        getWeeksInWeekYear(): number;
        getDisplayName(arg0: number, arg1: number, arg2: Internal.Locale_): string;
        getTime(): Internal.Date;
        toString(): string;
        setTimeInMillis(arg0: number): void;
        notifyAll(): void;
        abstract roll(arg0: number, arg1: boolean): void;
        after(arg0: any): boolean;
        abstract getMaximum(arg0: number): number;
        hashCode(): number;
        static getInstance(arg0: Internal.TimeZone_): Internal.Calendar;
        clear(): void;
        getTimeZone(): Internal.TimeZone;
        setTimeZone(arg0: Internal.TimeZone_): void;
        getFirstDayOfWeek(): number;
        static getAvailableCalendarTypes(): Internal.Set<string>;
        wait(arg0: number): void;
        getActualMinimum(arg0: number): number;
        get(arg0: number): number;
        getActualMaximum(arg0: number): number;
        equals(arg0: any): boolean;
        before(arg0: any): boolean;
        get weekYear(): number
        get availableLocales(): Internal.Locale[]
        set firstDayOfWeek(arg0: number)
        get timeInMillis(): number
        get minimalDaysInFirstWeek(): number
        set time(arg0: Internal.Date_)
        set lenient(arg0: boolean)
        get class(): typeof any
        get calendarType(): string
        get instance(): Internal.Calendar
        set minimalDaysInFirstWeek(arg0: number)
        get lenient(): boolean
        get weekDateSupported(): boolean
        get weeksInWeekYear(): number
        get time(): Internal.Date
        set timeInMillis(arg0: number)
        get timeZone(): Internal.TimeZone
        set timeZone(arg0: Internal.TimeZone_)
        get firstDayOfWeek(): number
        get availableCalendarTypes(): Internal.Set<string>
        static readonly OCTOBER: (9) & (number);
        static readonly LONG: (2) & (number);
        static readonly TUESDAY: (3) & (number);
        static readonly AM_PM: (9) & (number);
        static readonly MONTH: (2) & (number);
        static readonly JULY: (6) & (number);
        static readonly MAY: (4) & (number);
        static readonly UNDECIMBER: (12) & (number);
        static readonly FEBRUARY: (1) & (number);
        static readonly WEEK_OF_MONTH: (4) & (number);
        static readonly DST_OFFSET: (16) & (number);
        static readonly WEDNESDAY: (4) & (number);
        static readonly NOVEMBER: (10) & (number);
        static readonly LONG_STANDALONE: (32770) & (number);
        static readonly SHORT_STANDALONE: (32769) & (number);
        static readonly AM: (0) & (number);
        static readonly HOUR_OF_DAY: (11) & (number);
        static readonly ALL_STYLES: (0) & (number);
        static readonly MARCH: (2) & (number);
        static readonly SATURDAY: (7) & (number);
        static readonly SHORT_FORMAT: (1) & (number);
        static readonly JANUARY: (0) & (number);
        static readonly NARROW_FORMAT: (4) & (number);
        static readonly FIELD_COUNT: (17) & (number);
        static readonly ERA: (0) & (number);
        static readonly YEAR: (1) & (number);
        static readonly DAY_OF_WEEK_IN_MONTH: (8) & (number);
        static readonly MILLISECOND: (14) & (number);
        static readonly WEEK_OF_YEAR: (3) & (number);
        static readonly AUGUST: (7) & (number);
        static readonly DATE: (5) & (number);
        static readonly MONDAY: (2) & (number);
        static readonly SHORT: (1) & (number);
        static readonly LONG_FORMAT: (2) & (number);
        static readonly APRIL: (3) & (number);
        static readonly FRIDAY: (6) & (number);
        static readonly NARROW_STANDALONE: (32772) & (number);
        static readonly SECOND: (13) & (number);
        static readonly ZONE_OFFSET: (15) & (number);
        static readonly SUNDAY: (1) & (number);
        static readonly DAY_OF_MONTH: (5) & (number);
        static readonly DAY_OF_YEAR: (6) & (number);
        static readonly THURSDAY: (5) & (number);
        static readonly PM: (1) & (number);
        static readonly JUNE: (5) & (number);
        static readonly HOUR: (10) & (number);
        static readonly DECEMBER: (11) & (number);
        static readonly SEPTEMBER: (8) & (number);
        static readonly MINUTE: (12) & (number);
        static readonly DAY_OF_WEEK: (7) & (number);
    }
    type Calendar_ = Calendar;
    abstract class BlockBuilder extends Internal.BuilderBase<Internal.Block> {
        constructor(i: ResourceLocation_)
        /**
         * Bounces entities that land on this block by bounciness * their fall velocity.
         * Do not make bounciness negative, as that is a recipe for a long and laggy trip to the void
        */
        bounciness(bounciness: number): this;
        /**
         * Note block instrument.
        */
        instrument(i: Internal.NoteBlockInstrument_): this;
        "transformObject(net.minecraft.world.level.block.Block)"(obj: Internal.Block_): Internal.Block;
        createAdditionalObjects(): void;
        /**
         * Set what happens when an entity falls on the block. Do not use this for moving them, use bounce instead!
        */
        fallenOn(callbackJS: Internal.Consumer_<Internal.EntityFallenOnBlockCallbackJS>): this;
        /**
         * Tags the item with the given tag.
        */
        tagItem(tag: ResourceLocation_): this;
        /**
         * Sets the translation key for this object, e.g. `block.minecraft.stone`.
        */
        translationKey(key: string): Internal.BuilderBase<Internal.Block>;
        /**
         * Set the block's model.
        */
        model(m: string): this;
        sandSoundType(): this;
        getTranslationKeyGroup(): string;
        /**
         * Set the shape of the block.
        */
        box(x0: number, y0: number, z0: number, x1: number, y1: number, z1: number): this;
        notify(): void;
        get(): Internal.Block;
        /**
         * Makes the block a redstone conductor.
        */
        redstoneConductor(b: boolean): this;
        noSoundType(): this;
        /**
         * Modifies the block's item representation.
        */
        item(i: Internal.Consumer_<Internal.BlockItemBuilder>): this;
        getRegistryType(): Internal.RegistryInfo<any>;
        /**
         * Set the default state of the block.
        */
        defaultState(callbackJS: Internal.Consumer_<Internal.BlockStateModifyCallbackJS>): this;
        /**
         * Set what happens when an entity steps on the block
         * This is called every tick for every entity standing on the block, so be careful what you do here.
        */
        steppedOn(callbackJS: Internal.Consumer_<Internal.EntitySteppedOnBlockCallbackJS>): this;
        textureAll(tex: Special.Texture): this;
        /**
         * Makes displayName() override language files.
        */
        formattedDisplayName(): Internal.BuilderBase<Internal.Block>;
        /**
         * Helper method for setting the render type of the block to `translucent` correctly.
        */
        defaultTranslucent(): this;
        /**
         * Sets the block's map color dynamically per block state. If unset, defaults to NONE.
        */
        dynamicMapColor(m: Internal.Function_<Internal.BlockState, any>): this;
        /**
         * Tags both the block and the item with the given tag.
        */
        tagBoth(tag: ResourceLocation_): this;
        /**
         * Makes the block unbreakable.
        */
        unbreakable(): this;
        /**
         * Makes the block view blocking.
        */
        viewBlocking(b: boolean): this;
        /**
         * Add a blockstate property to the block.
         * 
         * For example, facing, lit, etc.
        */
        property(property: Internal.Property_<any>): this;
        /**
         * Sets the blast resistance of the block. Defaults to 3.
        */
        resistance(r: number): this;
        gravelSoundType(): this;
        getBuilderTranslationKey(): string;
        /**
         * Set the shape of the block.
        */
        box(x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, scale16: boolean): this;
        /**
         * Set the callback for determining the blocks state when placed.
        */
        placementState(callbackJS: Internal.Consumer_<Internal.BlockStateModifyPlacementCallbackJS>): this;
        /**
         * Set if the block can be replaced by something else.
        */
        canBeReplaced(callbackJS: Internal.Predicate_<Internal.CanBeReplacedCallbackJS>): this;
        /**
         * Sets random tick callback for this black.
        */
        randomTick(randomTickCallback: Internal.Consumer_<Internal.RandomTickCallbackJS>): this;
        wait(): void;
        /**
         * Set how this block reacts after an explosion. Note the block has already been destroyed at this point
        */
        exploded(callbackJS: Internal.Consumer_<Internal.BlockExplodedCallbackJS>): this;
        /**
         * Sets the light level of the block. Defaults to 0 (no light).
        */
        lightLevel(light: number): this;
        /**
         * Combined method of formattedDisplayName().displayName(name).
        */
        formattedDisplayName(name: net.minecraft.network.chat.Component_): Internal.BuilderBase<Internal.Block>;
        /**
         * Sets the display name for this object, e.g. `Stone`.
         * 
         * This will be overridden by a lang file if it exists.
        */
        displayName(name: net.minecraft.network.chat.Component_): Internal.BuilderBase<Internal.Block>;
        /**
         * Makes the block not be solid.
        */
        notSolid(): this;
        /**
         * Sets the block's map color. Defaults to NONE.
        */
        mapColor(m: Internal.MapColor_): this;
        static createShape(boxes: Internal.List_<Internal.AABB>): Internal.VoxelShape;
        generateLang(lang: Internal.LangEventJS_): void;
        /**
         * Sets the render type of the block. Can be `cutout`, `cutout_mipped`, `translucent`, or `basic`.
        */
        renderType(l: string): this;
        /**
         * Clears all drops for the block.
        */
        noDrops(): this;
        getClass(): typeof any;
        stoneSoundType(): this;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        setWaterlogged(waterlogged: boolean): this;
        grassSoundType(): this;
        createProperties(): Internal.BlockBehaviour$Properties;
        /**
         * Makes the block can be waterlogged.
        */
        waterlogged(): this;
        /**
         * Sets the block's sound type. Defaults to wood.
        */
        soundType(m: SoundType_): this;
        "transformObject(java.lang.Object)"(arg0: any): any;
        wait(arg0: number, arg1: number): void;
        /**
         * Set the callback used for determining how the block rotates
        */
        rotateState(callbackJS: Internal.Consumer_<Internal.BlockStateRotateCallbackJS>): this;
        /**
         * Set how high you can jump on the block.
        */
        jumpFactor(f: number): this;
        /**
         * Set the callback used for right-clicking on the block
        */
        rightClick(callbackJS: Internal.Consumer_<Internal.BlockRightClickedEventJS>): this;
        /**
         * Set the color of a specific layer of the block.
        */
        color(color: Internal.BlockTintFunction_): this;
        /**
         * Makes the block require a tool to have drops when broken.
        */
        requiresTool(f: boolean): this;
        generateDataJsons(generator: Internal.DataJsonGenerator_): void;
        textureSide(direction: Internal.Direction_, tex: Special.Texture): this;
        texture(id: string, tex: Special.Texture): this;
        /**
         * Checks if the block can be waterlogged.
        */
        canBeWaterlogged(): boolean;
        /**
         * Tags both the block and the item with the given tag.
        */
        tag(arg0: ResourceLocation_): Internal.BuilderBase<any>;
        /**
         * Sets the hardness of the block. Defaults to 1.5.
         * 
         * Setting this to -1 will make the block unbreakable like bedrock.
        */
        hardness(h: number): this;
        glassSoundType(): this;
        /**
         * Creates a Block Entity for this block
        */
        blockEntity(callback: Internal.Consumer_<Internal.BlockEntityInfo>): this;
        /**
         * Set the block to have no corresponding item.
        */
        noItem(): this;
        transformObject(arg0: any): any;
        abstract createObject(): Internal.Block;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        getWaterlogged(): boolean;
        /**
         * Set the callback used for determining how the block is mirrored
        */
        mirrorState(callbackJS: Internal.Consumer_<Internal.BlockStateMirrorCallbackJS>): this;
        /**
         * Set how slippery the block is.
        */
        slipperiness(f: number): this;
        /**
         * Tags the block with the given tag.
        */
        tagBlock(tag: ResourceLocation_): this;
        toString(): string;
        /**
         * Sets the opacity of the block. Opaque blocks do not let light through.
        */
        opaque(o: boolean): this;
        woodSoundType(): this;
        notifyAll(): void;
        /**
         * Makes mobs not spawn on the block.
        */
        noValidSpawns(b: boolean): this;
        material(material: string): this;
        transformObject(obj: Internal.Block_): Internal.Block;
        /**
         * Makes the block transparent.
        */
        transparent(b: boolean): this;
        /**
         * Helper method for setting the render type of the block to `cutout` correctly.
        */
        defaultCutout(): this;
        /**
         * Sets the block should be a full block or not, like cactus or doors.
        */
        fullBlock(f: boolean): this;
        /**
         * Makes the block not collide with entities.
        */
        noCollision(): this;
        hashCode(): number;
        /**
         * Set how this block bounces/moves entities that land on top of this. Do not use this to modify the block, use fallOn instead!
         * Use ctx.bounce(height) or ctx.setVelocity(x, y, z) to change the entities velocity.
        */
        afterFallenOn(callbackJS: Internal.Consumer_<Internal.AfterEntityFallenOnBlockCallbackJS>): this;
        /**
         * Makes the block suffocating.
        */
        suffocating(b: boolean): this;
        /**
         * Set the color of a specific layer of the block.
        */
        color(index: number, color: Internal.BlockTintFunction_): this;
        wait(arg0: number): void;
        /**
         * Set how fast you can walk on the block.
         * 
         * Any value above 1 will make you walk insanely fast as your speed is multiplied by this value each tick.
         * 
         * Recommended values are between 0.1 and 1, useful for mimicking soul sand or ice.
        */
        speedFactor(f: number): this;
        /**
         * Makes the block require a tool to have drops when broken.
        */
        requiresTool(): this;
        equals(arg0: any): boolean;
        cropSoundType(): this;
        newID(pre: string, post: string): ResourceLocation;
        generateAssetJsons(generator: Internal.AssetJsonGenerator_): void;
        get translationKeyGroup(): string
        get registryType(): Internal.RegistryInfo<any>
        get builderTranslationKey(): string
        get class(): typeof any
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        set waterlogged(waterlogged: boolean)
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        get waterlogged(): boolean
        lootTable: Internal.Consumer<Internal.LootBuilder>;
        blockstateJson: Internal.JsonObject;
        modelJson: Internal.JsonObject;
        randomTickCallback: Internal.Consumer<Internal.RandomTickCallbackJS>;
    }
    type BlockBuilder_ = BlockBuilder;
    class AttributeInstance {
        constructor($$0: Internal.Attribute_, $$1: Internal.Consumer_<Internal.AttributeInstance>)
        getClass(): typeof any;
        getModifiers(): Internal.Set<Internal.AttributeModifier>;
        hasModifier($$0: Internal.AttributeModifier_): boolean;
        removeModifier($$0: Internal.UUID_): void;
        notify(): void;
        getModifiers($$0: Internal.AttributeModifier$Operation_): Internal.Set<Internal.AttributeModifier>;
        wait(arg0: number, arg1: number): void;
        getBaseValue(): number;
        load($$0: Internal.CompoundTag_): void;
        getModifier($$0: Internal.UUID_): Internal.AttributeModifier;
        addPermanentModifier($$0: Internal.AttributeModifier_): void;
        save(): Internal.CompoundTag;
        removeModifier($$0: Internal.AttributeModifier_): void;
        setBaseValue($$0: number): void;
        toString(): string;
        notifyAll(): void;
        removeModifiers(): void;
        getAttribute(): Internal.Attribute;
        hashCode(): number;
        addTransientModifier($$0: Internal.AttributeModifier_): void;
        replaceFrom($$0: Internal.AttributeInstance_): void;
        wait(): void;
        wait(arg0: number): void;
        removePermanentModifier($$0: Internal.UUID_): boolean;
        getValue(): number;
        equals(arg0: any): boolean;
        "removeModifier(java.util.UUID)"($$0: Internal.UUID_): void;
        "removeModifier(net.minecraft.world.entity.ai.attributes.AttributeModifier)"($$0: Internal.AttributeModifier_): void;
        get class(): typeof any
        get modifiers(): Internal.Set<Internal.AttributeModifier>
        get baseValue(): number
        set baseValue($$0: number)
        get attribute(): Internal.Attribute
        get value(): number
    }
    type AttributeInstance_ = AttributeInstance;
    class TransactionContext$Result extends Internal.Enum<Internal.TransactionContext$Result> {
        static values(): Internal.TransactionContext$Result[];
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        toString(): string;
        compareTo(arg0: Internal.TransactionContext$Result_): number;
        notifyAll(): void;
        "compareTo(net.fabricmc.fabric.api.transfer.v1.transaction.TransactionContext$Result)"(arg0: Internal.TransactionContext$Result_): number;
        wasCommitted(): boolean;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.TransactionContext$Result>>;
        getDeclaringClass(): typeof Internal.TransactionContext$Result;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        name(): string;
        hashCode(): number;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        static valueOf(name: string): Internal.TransactionContext$Result;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        wasAborted(): boolean;
        get class(): typeof any
        get declaringClass(): typeof Internal.TransactionContext$Result
        static readonly COMMITTED: (Internal.TransactionContext$Result) & (Internal.TransactionContext$Result);
        static readonly ABORTED: (Internal.TransactionContext$Result) & (Internal.TransactionContext$Result);
    }
    type TransactionContext$Result_ = TransactionContext$Result | "committed" | "aborted";
    class RopeItem extends Internal.BlockItem {
        constructor(block: Internal.Block_, properties: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        static setBlockEntityData($$0: Internal.ItemStack_, $$1: Internal.BlockEntityType_<any>, $$2: Internal.CompoundTag_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        abstract moonlight$addAdditionalBehavior(arg0: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        modifyReturnValue$bkb000$axiom$canPlace(canPlace: boolean, blockPlaceContext: Internal.BlockPlaceContext_): boolean;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        abstract moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        handler$mpi000$tcdcommons$onPlace(context: Internal.BlockPlaceContext_, ci: Internal.CallbackInfoReturnable_<any>): void;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        abstract moonlight$setClientAnimationExtension(arg0: any): void;
        abstract moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        wrapOperation$bkb000$axiom$place$getPlacementState(instance: Internal.BlockItem_, blockPlaceContext: Internal.BlockPlaceContext_, original: Internal.Operation_<any>): Internal.BlockState;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        static getBlockEntityData($$0: Internal.ItemStack_): Internal.CompoundTag;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        removeFromBlockToItemMap(blockToItemMap: Internal.Map_<Internal.Block, Internal.Item>, itemIn: Internal.Item_): void;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        static updateCustomBlockEntityTag($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.ItemStack_): boolean;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        place(context: Internal.BlockPlaceContext_): Internal.InteractionResult;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        getBlock(): Internal.Block;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        updatePlacementContext($$0: Internal.BlockPlaceContext_): Internal.BlockPlaceContext;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        registerBlocks($$0: Internal.Map_<Internal.Block, Internal.Item>, $$1: Internal.Item_): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        puzzleslib$setBlock(arg0: Internal.Block_): void;
        wrapOperation$bkb000$axiom$place$updatePlacementContext(instance: Internal.BlockItem_, blockPlaceContext: Internal.BlockPlaceContext_, original: Internal.Operation_<any>): Internal.BlockPlaceContext;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        get block(): Internal.Block
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type RopeItem_ = RopeItem;
    interface ScheduledExecutorService extends Internal.ExecutorService {
        abstract scheduleAtFixedRate(arg0: Internal.Runnable_, arg1: number, arg2: number, arg3: Internal.TimeUnit_): Internal.ScheduledFuture<any>;
        abstract invokeAny<T>(arg0: Internal.Collection_<Internal.Callable<T>>, arg1: number, arg2: Internal.TimeUnit_): T;
        abstract invokeAll<T>(arg0: Internal.Collection_<Internal.Callable<T>>, arg1: number, arg2: Internal.TimeUnit_): Internal.List<Internal.Future<T>>;
        abstract "submit(java.lang.Runnable)"(arg0: Internal.Runnable_): Internal.Future<any>;
        abstract isShutdown(): boolean;
        abstract "schedule(java.util.concurrent.Callable,long,java.util.concurrent.TimeUnit)"<V>(arg0: Internal.Callable_<V>, arg1: number, arg2: Internal.TimeUnit_): Internal.ScheduledFuture<V>;
        abstract submit<T>(arg0: Internal.Callable_<T>): Internal.Future<T>;
        abstract shutdownNow(): Internal.List<Internal.Runnable>;
        abstract "schedule(java.lang.Runnable,long,java.util.concurrent.TimeUnit)"(arg0: Internal.Runnable_, arg1: number, arg2: Internal.TimeUnit_): Internal.ScheduledFuture<any>;
        abstract invokeAll<T>(arg0: Internal.Collection_<Internal.Callable<T>>): Internal.List<Internal.Future<T>>;
        abstract schedule(arg0: Internal.Runnable_, arg1: number, arg2: Internal.TimeUnit_): Internal.ScheduledFuture<any>;
        abstract "submit(java.util.concurrent.Callable)"<T>(arg0: Internal.Callable_<T>): Internal.Future<T>;
        abstract scheduleWithFixedDelay(arg0: Internal.Runnable_, arg1: number, arg2: number, arg3: Internal.TimeUnit_): Internal.ScheduledFuture<any>;
        abstract shutdown(): void;
        abstract awaitTermination(arg0: number, arg1: Internal.TimeUnit_): boolean;
        abstract schedule<V>(arg0: Internal.Callable_<V>, arg1: number, arg2: Internal.TimeUnit_): Internal.ScheduledFuture<V>;
        abstract submit<T>(arg0: Internal.Runnable_, arg1: T): Internal.Future<T>;
        abstract invokeAny<T>(arg0: Internal.Collection_<Internal.Callable<T>>): T;
        abstract submit(arg0: Internal.Runnable_): Internal.Future<any>;
        abstract execute(arg0: Internal.Runnable_): void;
        abstract isTerminated(): boolean;
        get shutdown(): boolean
        get terminated(): boolean
    }
    type ScheduledExecutorService_ = ScheduledExecutorService;
    class Logger extends Internal.AbstractLogger implements org.apache.logging.log4j.util.Supplier<Internal.LoggerConfig> {
        fatal(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        "error(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.MessageSupplier,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        info(message: string, p0: any, p1: any, p2: any, p3: any): void;
        "fatal(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.MessageSupplier,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        fatal(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,org.apache.logging.log4j.message.Message)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: Internal.Message_): void;
        fatal(marker: org.apache.logging.log4j.Marker_, message: string): void;
        log(level: org.apache.logging.log4j.Level_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        "debug(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.MessageSupplier,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any): void;
        error(messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        fatal(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        "warn(java.lang.String,java.lang.Throwable)"(message: string, throwable: Internal.Throwable_): void;
        traceEntry(message: Internal.Message_): Internal.EntryMessage;
        "trace(org.apache.logging.log4j.Marker,java.lang.CharSequence,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        "warn(org.apache.logging.log4j.Marker,org.apache.logging.log4j.message.Message,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_, throwable: Internal.Throwable_): void;
        "debug(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any): void;
        "warn(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        isEnabled(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any): boolean;
        log(level: org.apache.logging.log4j.Level_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        fatal(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        fatal(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        log(level: org.apache.logging.log4j.Level_, message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        info(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        removeAppender(appender: Internal.Appender_): void;
        "log(org.apache.logging.log4j.Level,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(level: org.apache.logging.log4j.Level_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        info(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any): void;
        error(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        error(message: string, p0: any, p1: any): void;
        error(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any): void;
        info(message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        "warn(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        "debug(org.apache.logging.log4j.Marker,java.lang.CharSequence)"(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_): void;
        debug(message: string, p0: any): void;
        warn(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        info(message: string, p0: any, p1: any): void;
        isEnabled(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, ...params: any[]): boolean;
        "info(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any): void;
        atDebug(): Internal.LogBuilder;
        error(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        fatal(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_, throwable: Internal.Throwable_): void;
        "error(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object[])"(marker: org.apache.logging.log4j.Marker_, message: string, ...params: any[]): void;
        "log(org.apache.logging.log4j.Level,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(level: org.apache.logging.log4j.Level_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): void;
        warn(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        "fatal(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        catching(throwable: Internal.Throwable_): void;
        debug(marker: org.apache.logging.log4j.Marker_, message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        info(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any): void;
        trace(message: any): void;
        "trace(org.apache.logging.log4j.util.Supplier)"(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        trace(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        "trace(java.lang.String,java.lang.Object[])"(message: string, ...params: any[]): void;
        "traceExit(org.apache.logging.log4j.message.EntryMessage)"(message: Internal.EntryMessage_): void;
        "debug(java.lang.CharSequence)"(message: Internal.CharSequence_): void;
        warn(message: string, p0: any, p1: any): void;
        isEnabled(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, t: Internal.Throwable_): boolean;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.MessageSupplier,java.lang.Throwable)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        "fatal(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        "info(org.apache.logging.log4j.message.Message)"(message: Internal.Message_): void;
        "fatal(java.lang.String,java.lang.Object[])"(message: string, ...params: any[]): void;
        warn(message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        "trace(java.lang.Object,java.lang.Throwable)"(message: any, throwable: Internal.Throwable_): void;
        warn(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_): void;
        "warn(org.apache.logging.log4j.util.Supplier)"(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        "traceEntry(org.apache.logging.log4j.message.Message)"(message: Internal.Message_): Internal.EntryMessage;
        "info(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        traceExit(): void;
        "info(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        "warn(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.MessageSupplier,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        getFilters(): Internal.Iterator<Internal.Filter>;
        warn(marker: org.apache.logging.log4j.Marker_, message: any, throwable: Internal.Throwable_): void;
        "debug(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        error(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        debug(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_): void;
        error(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): void;
        /**
         * @deprecated
        */
        exit<R>(result: R): R;
        "error(org.apache.logging.log4j.Marker,java.lang.String,org.apache.logging.log4j.util.Supplier[])"(marker: org.apache.logging.log4j.Marker_, message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        "log(org.apache.logging.log4j.Level,java.lang.Object)"(level: org.apache.logging.log4j.Level_, message: any): void;
        error(message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        info(messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        "fatal(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        error(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_): void;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: any): void;
        logIfEnabled(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: Internal.Message_, throwable: Internal.Throwable_): void;
        "trace(org.apache.logging.log4j.Marker,java.lang.CharSequence)"(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_): void;
        "log(org.apache.logging.log4j.Level,java.lang.String,java.lang.Object[])"(level: org.apache.logging.log4j.Level_, message: string, ...params: any[]): void;
        "fatal(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any): void;
        debug(marker: org.apache.logging.log4j.Marker_, message: any, throwable: Internal.Throwable_): void;
        "trace(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        info(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        "trace(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.Supplier,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        warn(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.util.Supplier)"(level: org.apache.logging.log4j.Level_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        fatal(message: Internal.Message_): void;
        info(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        debug(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        "fatal(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        logIfEnabled(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, ...params: any[]): void;
        "info(org.apache.logging.log4j.Marker,java.lang.CharSequence)"(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_): void;
        logIfEnabled(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, throwable: Internal.Throwable_): void;
        "warn(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.Supplier,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        "trace(org.apache.logging.log4j.message.Message)"(message: Internal.Message_): void;
        trace(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        debug(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        "error(org.apache.logging.log4j.Marker,java.lang.Object,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: any, throwable: Internal.Throwable_): void;
        "debug(org.apache.logging.log4j.util.MessageSupplier)"(messageSupplier: Internal.MessageSupplier_): void;
        isEnabled(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): boolean;
        error(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        isTraceEnabled(): boolean;
        "logIfEnabled(java.lang.String,org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.Supplier,java.lang.Throwable)"(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        "warn(java.lang.String,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any): void;
        error(marker: org.apache.logging.log4j.Marker_, message: any): void;
        log(level: org.apache.logging.log4j.Level_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        "warn(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any): void;
        "error(java.lang.String,org.apache.logging.log4j.util.Supplier[])"(message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        "error(java.lang.CharSequence)"(message: Internal.CharSequence_): void;
        traceEntry(): Internal.EntryMessage;
        "warn(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        trace(message: Internal.Message_, throwable: Internal.Throwable_): void;
        "log(org.apache.logging.log4j.Level,java.lang.String)"(level: org.apache.logging.log4j.Level_, message: string): void;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_): void;
        "error(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: string, throwable: Internal.Throwable_): void;
        logIfEnabled(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        log(level: org.apache.logging.log4j.Level_, message: string, throwable: Internal.Throwable_): void;
        isEnabled(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string): boolean;
        "fatal(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.Supplier)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        "fatal(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.Supplier,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        trace(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any): void;
        debug(message: string): void;
        "fatal(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: string, throwable: Internal.Throwable_): void;
        "fatal(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        trace(message: Internal.Message_): void;
        notify(): void;
        warn(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        warn(marker: org.apache.logging.log4j.Marker_, message: string, p0: any): void;
        "isEnabled(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any): boolean;
        "trace(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any): void;
        "warn(org.apache.logging.log4j.message.Message)"(message: Internal.Message_): void;
        info(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_): void;
        "trace(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        traceEntry(...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): Internal.EntryMessage;
        trace(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        error(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        error(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        "info(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any): void;
        trace(marker: org.apache.logging.log4j.Marker_, message: string): void;
        warn(message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        "error(org.apache.logging.log4j.message.Message)"(message: Internal.Message_): void;
        "fatal(org.apache.logging.log4j.util.Supplier)"(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        "trace(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        "error(org.apache.logging.log4j.message.Message,java.lang.Throwable)"(message: Internal.Message_, throwable: Internal.Throwable_): void;
        getAppenders(): Internal.Map<string, Internal.Appender>;
        info(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): void;
        "warn(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.MessageSupplier)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_): void;
        debug(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        isEnabled(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any): boolean;
        warn(message: string): void;
        log(level: org.apache.logging.log4j.Level_, message: string, p0: any, p1: any, p2: any, p3: any): void;
        info(marker: org.apache.logging.log4j.Marker_, message: any, throwable: Internal.Throwable_): void;
        "debug(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any): void;
        "trace(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        error(message: any, throwable: Internal.Throwable_): void;
        "trace(java.lang.String,org.apache.logging.log4j.util.Supplier[])"(message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        "error(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any): void;
        trace(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        info(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_): void;
        "fatal(org.apache.logging.log4j.Marker,java.lang.String)"(marker: org.apache.logging.log4j.Marker_, message: string): void;
        fatal(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any): void;
        trace(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        debug(message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        "error(org.apache.logging.log4j.Marker,java.lang.CharSequence)"(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_): void;
        "warn(java.lang.Object,java.lang.Throwable)"(message: any, throwable: Internal.Throwable_): void;
        fatal(message: Internal.Message_, throwable: Internal.Throwable_): void;
        setAdditive(additive: boolean): void;
        error(marker: org.apache.logging.log4j.Marker_, message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        hashCode(): number;
        isEnabled(level: org.apache.logging.log4j.Level_): boolean;
        "log(org.apache.logging.log4j.Level,java.lang.String,java.lang.Throwable)"(level: org.apache.logging.log4j.Level_, message: string, throwable: Internal.Throwable_): void;
        "debug(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: string, throwable: Internal.Throwable_): void;
        isEnabled(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_): boolean;
        debug(marker: org.apache.logging.log4j.Marker_, message: string, p0: any): void;
        "fatal(java.lang.CharSequence,java.lang.Throwable)"(message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        "log(org.apache.logging.log4j.Level,java.lang.String,java.lang.Object)"(level: org.apache.logging.log4j.Level_, message: string, p0: any): void;
        "log(org.apache.logging.log4j.Level,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(level: org.apache.logging.log4j.Level_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        warn(message: string, p0: any, p1: any, p2: any, p3: any): void;
        warn(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_): void;
        "debug(java.lang.String,java.lang.Object)"(message: string, p0: any): void;
        error(marker: org.apache.logging.log4j.Marker_, message: string, ...params: any[]): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        "fatal(java.lang.CharSequence)"(message: Internal.CharSequence_): void;
        error(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_): void;
        "debug(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.MessageSupplier)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_): void;
        warn(message: string, throwable: Internal.Throwable_): void;
        atFatal(): Internal.LogBuilder;
        warn(marker: org.apache.logging.log4j.Marker_, message: string, throwable: Internal.Throwable_): void;
        debug(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        "warn(org.apache.logging.log4j.Marker,java.lang.CharSequence)"(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_): void;
        info(message: string, p0: any): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.util.MessageSupplier)"(level: org.apache.logging.log4j.Level_, messageSupplier: Internal.MessageSupplier_): void;
        "info(org.apache.logging.log4j.message.Message,java.lang.Throwable)"(message: Internal.Message_, throwable: Internal.Throwable_): void;
        fatal(marker: org.apache.logging.log4j.Marker_, message: string, throwable: Internal.Throwable_): void;
        info(marker: org.apache.logging.log4j.Marker_, message: string, p0: any): void;
        "log(org.apache.logging.log4j.Level,java.lang.CharSequence,java.lang.Throwable)"(level: org.apache.logging.log4j.Level_, message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        warn(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.Supplier)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        "warn(org.apache.logging.log4j.message.Message,java.lang.Throwable)"(message: Internal.Message_, throwable: Internal.Throwable_): void;
        fatal(message: string, ...params: any[]): void;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): void;
        "trace(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any): void;
        "error(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): void;
        debug(message: string, p0: any, p1: any): void;
        info(message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        "debug(org.apache.logging.log4j.Marker,java.lang.Object,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: any, throwable: Internal.Throwable_): void;
        "trace(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: string, throwable: Internal.Throwable_): void;
        throwing<T extends Internal.Throwable>(throwable: T): T;
        "error(java.lang.CharSequence,java.lang.Throwable)"(message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        trace(marker: org.apache.logging.log4j.Marker_, message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        isErrorEnabled(): boolean;
        logIfEnabled(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        debug(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        "trace(org.apache.logging.log4j.util.MessageSupplier)"(messageSupplier: Internal.MessageSupplier_): void;
        log(level: org.apache.logging.log4j.Level_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        fatal(messageSupplier: Internal.MessageSupplier_): void;
        fatal(marker: org.apache.logging.log4j.Marker_, message: string, p0: any): void;
        "info(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any): void;
        warn(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        isFatalEnabled(marker: org.apache.logging.log4j.Marker_): boolean;
        "debug(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        "error(org.apache.logging.log4j.Marker,org.apache.logging.log4j.message.Message)"(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.MessageSupplier)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_): void;
        isInfoEnabled(): boolean;
        isInfoEnabled(marker: org.apache.logging.log4j.Marker_): boolean;
        info(messageSupplier: Internal.MessageSupplier_): void;
        trace(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any): void;
        "fatal(org.apache.logging.log4j.Marker,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: any): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.Object,java.lang.Throwable)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: any, throwable: Internal.Throwable_): void;
        isEnabled(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_, t: Internal.Throwable_): boolean;
        fatal(message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        trace(message: string, ...params: any[]): void;
        fatal(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        debug(message: Internal.Message_): void;
        getParent(): this;
        warn(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        error(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        warn(messageSupplier: Internal.MessageSupplier_): void;
        warn(message: string, p0: any): void;
        "error(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        atTrace(): Internal.LogBuilder;
        info(message: string): void;
        "warn(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any): void;
        "warn(org.apache.logging.log4j.Marker,java.lang.String,org.apache.logging.log4j.util.Supplier[])"(marker: org.apache.logging.log4j.Marker_, message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        setLevel(level: org.apache.logging.log4j.Level_): void;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: any, throwable: Internal.Throwable_): void;
        "error(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any): void;
        isDebugEnabled(marker: org.apache.logging.log4j.Marker_): boolean;
        "debug(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        "trace(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        trace(message: string): void;
        warn(marker: org.apache.logging.log4j.Marker_, message: any): void;
        "debug(java.lang.String,java.lang.Throwable)"(message: string, throwable: Internal.Throwable_): void;
        "info(java.lang.String,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any): void;
        "warn(java.lang.Object)"(message: any): void;
        debug(marker: org.apache.logging.log4j.Marker_, message: string): void;
        "debug(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        trace(message: string, p0: any, p1: any, p2: any): void;
        warn(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        trace(marker: org.apache.logging.log4j.Marker_, message: string, p0: any): void;
        debug(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        "warn(java.lang.String)"(message: string): void;
        debug(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        "trace(java.lang.Object)"(message: any): void;
        "trace(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any): void;
        log(level: org.apache.logging.log4j.Level_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        "fatal(java.lang.Object,java.lang.Throwable)"(message: any, throwable: Internal.Throwable_): void;
        error(message: string, p0: any): void;
        "debug(org.apache.logging.log4j.Marker,java.lang.CharSequence,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        debug(marker: org.apache.logging.log4j.Marker_, message: any): void;
        "warn(java.lang.String,org.apache.logging.log4j.util.Supplier[])"(message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        "debug(org.apache.logging.log4j.Marker,org.apache.logging.log4j.message.Message)"(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_): void;
        fatal(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_): void;
        trace(message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        fatal(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        "debug(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        "isEnabled(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.String,java.lang.Throwable)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, t: Internal.Throwable_): boolean;
        fatal(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        warn(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_): void;
        "warn(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.Supplier)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        "fatal(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object[])"(marker: org.apache.logging.log4j.Marker_, message: string, ...params: any[]): void;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any): void;
        error(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): void;
        "fatal(org.apache.logging.log4j.message.Message)"(message: Internal.Message_): void;
        debug(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        logIfEnabled(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        "warn(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        "traceExit(java.lang.String,java.lang.Object)"<R>(format: string, result: R): R;
        "info(org.apache.logging.log4j.Marker,java.lang.String,org.apache.logging.log4j.util.Supplier[])"(marker: org.apache.logging.log4j.Marker_, message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        "debug(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object[])"(marker: org.apache.logging.log4j.Marker_, message: string, ...params: any[]): void;
        fatal(message: string): void;
        "logIfEnabled(java.lang.String,org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.String,org.apache.logging.log4j.util.Supplier[])"(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        debug(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        "fatal(java.lang.String,java.lang.Object)"(message: string, p0: any): void;
        static getRecursionDepth(): number;
        "info(java.lang.String,java.lang.Throwable)"(message: string, throwable: Internal.Throwable_): void;
        "debug(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any): void;
        isEnabled(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): boolean;
        "log(org.apache.logging.log4j.Level,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object)"(level: org.apache.logging.log4j.Level_, message: string, p0: any, p1: any, p2: any): void;
        trace(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): void;
        "traceEntry(java.lang.String,java.lang.Object[])"(format: string, ...params: any[]): Internal.EntryMessage;
        "isEnabled(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.CharSequence,java.lang.Throwable)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_, t: Internal.Throwable_): boolean;
        "trace(org.apache.logging.log4j.Marker,java.lang.String,org.apache.logging.log4j.util.Supplier[])"(marker: org.apache.logging.log4j.Marker_, message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        "trace(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.MessageSupplier,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        log(level: org.apache.logging.log4j.Level_, message: string, p0: any, p1: any): void;
        "debug(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.Supplier)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        isTraceEnabled(marker: org.apache.logging.log4j.Marker_): boolean;
        warn(message: Internal.Message_): void;
        info(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        debug(message: Internal.Message_, throwable: Internal.Throwable_): void;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any): void;
        logIfEnabled(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        "fatal(org.apache.logging.log4j.Marker,java.lang.CharSequence,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        info(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        toString(): string;
        fatal(message: Internal.CharSequence_): void;
        "info(org.apache.logging.log4j.util.Supplier,java.lang.Throwable)"(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        "logIfEnabled(java.lang.String,org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.Object,java.lang.Throwable)"(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: any, throwable: Internal.Throwable_): void;
        info(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        "debug(java.lang.String,java.lang.Object[])"(message: string, ...params: any[]): void;
        error(message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        "fatal(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        error(marker: org.apache.logging.log4j.Marker_, message: any, throwable: Internal.Throwable_): void;
        isEnabled(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any): boolean;
        isEnabled(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): boolean;
        "isEnabled(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object[])"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, ...params: any[]): boolean;
        /**
         * @deprecated
        */
        entry(): void;
        logIfEnabled(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        log(level: org.apache.logging.log4j.Level_, message: any, throwable: Internal.Throwable_): void;
        warn(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        isEnabled(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any): boolean;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, ...params: any[]): void;
        fatal(message: string, p0: any, p1: any, p2: any, p3: any): void;
        warn(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any): void;
        "fatal(org.apache.logging.log4j.Marker,org.apache.logging.log4j.message.Message)"(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_): void;
        info(message: Internal.Message_): void;
        "debug(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any): void;
        info(marker: org.apache.logging.log4j.Marker_, message: string, throwable: Internal.Throwable_): void;
        trace(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        info(marker: org.apache.logging.log4j.Marker_, message: string): void;
        trace(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        "error(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any): void;
        "warn(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        "info(org.apache.logging.log4j.Marker,java.lang.String)"(marker: org.apache.logging.log4j.Marker_, message: string): void;
        info(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_): void;
        debug(messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        info(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        "debug(org.apache.logging.log4j.Marker,java.lang.String)"(marker: org.apache.logging.log4j.Marker_, message: string): void;
        "logIfEnabled(java.lang.String,org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.MessageSupplier,java.lang.Throwable)"(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        log(level: org.apache.logging.log4j.Level_, message: string, ...params: any[]): void;
        "fatal(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any): void;
        "info(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any): void;
        error(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        "info(org.apache.logging.log4j.Marker,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: any): void;
        "fatal(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any): void;
        "warn(java.lang.CharSequence)"(message: Internal.CharSequence_): void;
        "fatal(org.apache.logging.log4j.Marker,java.lang.String,org.apache.logging.log4j.util.Supplier[])"(marker: org.apache.logging.log4j.Marker_, message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        debug(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any): void;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        info(marker: org.apache.logging.log4j.Marker_, message: any): void;
        info(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        "error(java.lang.String,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any): void;
        "warn(org.apache.logging.log4j.Marker,org.apache.logging.log4j.message.Message)"(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_): void;
        "error(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.MessageSupplier)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_): void;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        "info(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object[])"(marker: org.apache.logging.log4j.Marker_, message: string, ...params: any[]): void;
        "info(org.apache.logging.log4j.Marker,org.apache.logging.log4j.message.Message,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_, throwable: Internal.Throwable_): void;
        "info(org.apache.logging.log4j.Marker,java.lang.CharSequence,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        logIfEnabled(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): void;
        "warn(org.apache.logging.log4j.util.Supplier,java.lang.Throwable)"(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        warn(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        "debug(org.apache.logging.log4j.Marker,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: any): void;
        debug(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        "error(java.lang.Object,java.lang.Throwable)"(message: any, throwable: Internal.Throwable_): void;
        fatal(message: any): void;
        info(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        "fatal(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any): void;
        logMessage(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: Internal.Message_, t: Internal.Throwable_): void;
        trace(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_, throwable: Internal.Throwable_): void;
        trace(message: Internal.CharSequence_): void;
        warn(messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        "debug(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        error(message: string, throwable: Internal.Throwable_): void;
        error(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.String,org.apache.logging.log4j.util.Supplier[])"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        "warn(java.lang.CharSequence,java.lang.Throwable)"(message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        error(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any): void;
        warn(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        "info(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.Supplier)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        "trace(org.apache.logging.log4j.util.MessageSupplier,java.lang.Throwable)"(messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        getLevel(): org.apache.logging.log4j.Level;
        "fatal(java.lang.String,java.lang.Throwable)"(message: string, throwable: Internal.Throwable_): void;
        "warn(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        warn(message: Internal.Message_, throwable: Internal.Throwable_): void;
        printf(level: org.apache.logging.log4j.Level_, format: string, ...params: any[]): void;
        error(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        isEnabled(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any): boolean;
        "debug(org.apache.logging.log4j.util.Supplier)"(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        "error(java.lang.String,java.lang.Object[])"(message: string, ...params: any[]): void;
        catching(level: org.apache.logging.log4j.Level_, throwable: Internal.Throwable_): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        error(marker: org.apache.logging.log4j.Marker_, message: string): void;
        filterCount(): number;
        "warn(org.apache.logging.log4j.util.MessageSupplier,java.lang.Throwable)"(messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any): void;
        fatal(messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        info(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        "log(org.apache.logging.log4j.Level,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(level: org.apache.logging.log4j.Level_, message: string, p0: any, p1: any, p2: any, p3: any): void;
        warn(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_, throwable: Internal.Throwable_): void;
        "warn(org.apache.logging.log4j.Marker,java.lang.Object,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: any, throwable: Internal.Throwable_): void;
        debug(messageSupplier: Internal.MessageSupplier_): void;
        "debug(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.String)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string): void;
        info(message: any): void;
        trace(message: string, p0: any, p1: any, p2: any, p3: any): void;
        "fatal(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        trace(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        "traceExit(org.apache.logging.log4j.message.EntryMessage,java.lang.Object)"<R>(message: Internal.EntryMessage_, result: R): R;
        log(level: org.apache.logging.log4j.Level_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        error(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        "debug(org.apache.logging.log4j.message.Message)"(message: Internal.Message_): void;
        trace(message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        fatal(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any): void;
        "log(org.apache.logging.log4j.Level,java.lang.Object,java.lang.Throwable)"(level: org.apache.logging.log4j.Level_, message: any, throwable: Internal.Throwable_): void;
        error(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        getName(): string;
        "trace(org.apache.logging.log4j.util.Supplier,java.lang.Throwable)"(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        "fatal(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.MessageSupplier)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_): void;
        fatal(message: string, p0: any, p1: any): void;
        log(level: org.apache.logging.log4j.Level_, message: any): void;
        warn(marker: org.apache.logging.log4j.Marker_, message: string): void;
        debug(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any): void;
        debug(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): void;
        error(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_, throwable: Internal.Throwable_): void;
        fatal(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        isAdditive(): boolean;
        "trace(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        wait(arg0: number): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any): void;
        "info(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        "trace(org.apache.logging.log4j.Marker,java.lang.Object,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: any, throwable: Internal.Throwable_): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.String,java.lang.Throwable)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, throwable: Internal.Throwable_): void;
        "warn(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        /**
         * @deprecated
        */
        exit(): void;
        logIfEnabled(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any): void;
        warn(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        "fatal(java.lang.String)"(message: string): void;
        "error(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any): void;
        "trace(java.lang.String)"(message: string): void;
        logMessage(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, fqcn: string, location: Internal.StackTraceElement_, message: Internal.Message_, throwable: Internal.Throwable_): void;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, throwable: Internal.Throwable_): void;
        "debug(org.apache.logging.log4j.message.Message,java.lang.Throwable)"(message: Internal.Message_, throwable: Internal.Throwable_): void;
        "info(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        info(message: Internal.Message_, throwable: Internal.Throwable_): void;
        fatal(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): void;
        "error(org.apache.logging.log4j.Marker,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: any): void;
        trace(messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        debug(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_): void;
        fatal(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        "fatal(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        "fatal(org.apache.logging.log4j.util.Supplier,java.lang.Throwable)"(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        warn(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any): void;
        traceExit<R>(message: Internal.EntryMessage_, result: R): R;
        trace(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        "isEnabled(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,org.apache.logging.log4j.message.Message,java.lang.Throwable)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: Internal.Message_, t: Internal.Throwable_): boolean;
        "info(java.lang.CharSequence)"(message: Internal.CharSequence_): void;
        log(level: org.apache.logging.log4j.Level_, message: string, p0: any, p1: any, p2: any): void;
        warn(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        logIfEnabled(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: any, throwable: Internal.Throwable_): void;
        warn(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        addFilter(filter: Internal.Filter_): void;
        fatal(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_): void;
        fatal(message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        trace(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any): void;
        "debug(org.apache.logging.log4j.Marker,java.lang.String,org.apache.logging.log4j.util.Supplier[])"(marker: org.apache.logging.log4j.Marker_, message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        getContext(): Internal.LoggerContext;
        debug(marker: org.apache.logging.log4j.Marker_, message: string, throwable: Internal.Throwable_): void;
        "warn(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): void;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string): void;
        "warn(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object[])"(marker: org.apache.logging.log4j.Marker_, message: string, ...params: any[]): void;
        addAppender(appender: Internal.Appender_): void;
        "info(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: string, throwable: Internal.Throwable_): void;
        "trace(java.lang.String,java.lang.Object)"(message: string, p0: any): void;
        equals(o: any): boolean;
        traceExit<R>(result: R): R;
        "error(org.apache.logging.log4j.Marker,java.lang.CharSequence,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        "warn(org.apache.logging.log4j.util.MessageSupplier)"(messageSupplier: Internal.MessageSupplier_): void;
        error(message: Internal.Message_): void;
        logIfEnabled(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any): void;
        "error(org.apache.logging.log4j.Marker,org.apache.logging.log4j.message.Message,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_, throwable: Internal.Throwable_): void;
        "info(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): void;
        logIfEnabled(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        logIfEnabled(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.util.Supplier,java.lang.Throwable)"(level: org.apache.logging.log4j.Level_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        "fatal(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any): void;
        trace(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        warn(message: Internal.CharSequence_): void;
        "error(org.apache.logging.log4j.util.Supplier,java.lang.Throwable)"(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        "debug(org.apache.logging.log4j.Marker,org.apache.logging.log4j.message.Message,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_, throwable: Internal.Throwable_): void;
        "info(java.lang.String)"(message: string): void;
        "warn(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        trace(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        "warn(java.lang.String,java.lang.Object[])"(message: string, ...params: any[]): void;
        fatal(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        warn(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): void;
        "warn(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any): void;
        "logIfEnabled(java.lang.String,org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object[])"(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, ...params: any[]): void;
        trace(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        fatal(marker: org.apache.logging.log4j.Marker_, message: any): void;
        get(): any;
        atWarn(): Internal.LogBuilder;
        "info(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.Object)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: any): void;
        isWarnEnabled(marker: org.apache.logging.log4j.Marker_): boolean;
        debug(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_): void;
        isEnabled(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: any, t: Internal.Throwable_): boolean;
        "warn(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any): void;
        "info(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.MessageSupplier)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_): void;
        "info(org.apache.logging.log4j.util.MessageSupplier,java.lang.Throwable)"(messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        "fatal(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        "error(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        "error(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        trace(message: any, throwable: Internal.Throwable_): void;
        "error(java.lang.String)"(message: string): void;
        "error(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        debug(message: string, throwable: Internal.Throwable_): void;
        debug(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        static checkMessageFactory(logger: Internal.ExtendedLogger_, messageFactory: Internal.MessageFactory_): void;
        "fatal(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): void;
        atLevel(level: org.apache.logging.log4j.Level_): Internal.LogBuilder;
        "fatal(java.lang.Object)"(message: any): void;
        "fatal(org.apache.logging.log4j.message.Message,java.lang.Throwable)"(message: Internal.Message_, throwable: Internal.Throwable_): void;
        trace(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        "traceEntry(java.lang.String,org.apache.logging.log4j.util.Supplier[])"(format: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): Internal.EntryMessage;
        debug(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        trace(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_): void;
        "trace(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): void;
        traceExit<R>(format: string, result: R): R;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any): void;
        "debug(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        "trace(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.MessageSupplier)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.CharSequence)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_): void;
        "error(org.apache.logging.log4j.Marker,java.lang.String)"(marker: org.apache.logging.log4j.Marker_, message: string): void;
        "log(org.apache.logging.log4j.Level,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(level: org.apache.logging.log4j.Level_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        trace(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        atInfo(): Internal.LogBuilder;
        "traceExit(java.lang.Object)"<R>(result: R): R;
        fatal(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        "warn(org.apache.logging.log4j.Marker,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: any): void;
        "info(java.lang.String,java.lang.Object[])"(message: string, ...params: any[]): void;
        info(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_, throwable: Internal.Throwable_): void;
        "fatal(org.apache.logging.log4j.util.MessageSupplier)"(messageSupplier: Internal.MessageSupplier_): void;
        "error(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.Supplier)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        info(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        warn(message: any): void;
        "info(org.apache.logging.log4j.util.MessageSupplier)"(messageSupplier: Internal.MessageSupplier_): void;
        fatal(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        warn(message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        debug(marker: org.apache.logging.log4j.Marker_, message: string, ...params: any[]): void;
        logIfEnabled(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        info(message: Internal.CharSequence_): void;
        warn(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        fatal(message: string, p0: any, p1: any, p2: any): void;
        trace(messageSupplier: Internal.MessageSupplier_): void;
        "fatal(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any): void;
        warn(marker: org.apache.logging.log4j.Marker_, message: string, ...params: any[]): void;
        "error(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any): void;
        debug(message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        logIfEnabled(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any): void;
        traceExit(message: Internal.EntryMessage_): void;
        fatal(marker: org.apache.logging.log4j.Marker_, message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        log(level: org.apache.logging.log4j.Level_, message: Internal.CharSequence_): void;
        "info(java.lang.String,org.apache.logging.log4j.util.Supplier[])"(message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        error(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any): void;
        "error(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        trace(marker: org.apache.logging.log4j.Marker_, message: string, throwable: Internal.Throwable_): void;
        error(message: Internal.Message_, throwable: Internal.Throwable_): void;
        info(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        "trace(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.Supplier)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        trace(marker: org.apache.logging.log4j.Marker_, message: any): void;
        fatal(message: any, throwable: Internal.Throwable_): void;
        "debug(java.lang.Object,java.lang.Throwable)"(message: any, throwable: Internal.Throwable_): void;
        log(level: org.apache.logging.log4j.Level_, message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        "debug(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        "fatal(java.lang.String,org.apache.logging.log4j.util.Supplier[])"(message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        "error(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any): void;
        "log(org.apache.logging.log4j.Level,java.lang.String,org.apache.logging.log4j.util.Supplier[])"(level: org.apache.logging.log4j.Level_, message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        "trace(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any): void;
        "fatal(org.apache.logging.log4j.Marker,java.lang.CharSequence)"(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_): void;
        "error(java.lang.Object)"(message: any): void;
        error(message: string, ...params: any[]): void;
        "info(java.lang.Object)"(message: any): void;
        "info(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        debug(message: string, p0: any, p1: any, p2: any, p3: any): void;
        "info(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.MessageSupplier,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        fatal(marker: org.apache.logging.log4j.Marker_, message: string, ...params: any[]): void;
        fatal(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_): void;
        info(marker: org.apache.logging.log4j.Marker_, message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        "log(org.apache.logging.log4j.Level,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(level: org.apache.logging.log4j.Level_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        "trace(java.lang.CharSequence,java.lang.Throwable)"(message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        "debug(java.lang.CharSequence,java.lang.Throwable)"(message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        error(marker: org.apache.logging.log4j.Marker_, message: string, throwable: Internal.Throwable_): void;
        "debug(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any): void;
        "error(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        "warn(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any): void;
        "info(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        "warn(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any): void;
        getClass(): typeof any;
        trace(message: string, p0: any): void;
        debug(message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        getMessageFactory<MF extends Internal.MessageFactory>(): MF;
        error(message: string, p0: any, p1: any, p2: any): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.CharSequence,java.lang.Throwable)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        error(messageSupplier: Internal.MessageSupplier_): void;
        warn(message: string, ...params: any[]): void;
        "trace(org.apache.logging.log4j.Marker,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: any): void;
        throwing<T extends Internal.Throwable>(level: org.apache.logging.log4j.Level_, throwable: T): T;
        error(marker: org.apache.logging.log4j.Marker_, message: string, p0: any): void;
        "log(org.apache.logging.log4j.Level,java.lang.String,java.lang.Object,java.lang.Object)"(level: org.apache.logging.log4j.Level_, message: string, p0: any, p1: any): void;
        logIfEnabled(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any): void;
        debug(message: any): void;
        info(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any): void;
        "trace(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        info(message: string, ...params: any[]): void;
        isErrorEnabled(marker: org.apache.logging.log4j.Marker_): boolean;
        "log(org.apache.logging.log4j.Level,java.lang.CharSequence)"(level: org.apache.logging.log4j.Level_, message: Internal.CharSequence_): void;
        error(message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        "warn(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: string, throwable: Internal.Throwable_): void;
        log(level: org.apache.logging.log4j.Level_, message: string): void;
        "error(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        trace(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): void;
        log(level: org.apache.logging.log4j.Level_, message: string, p0: any): void;
        "info(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any): void;
        traceEntry(format: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): Internal.EntryMessage;
        trace(marker: org.apache.logging.log4j.Marker_, message: string, ...params: any[]): void;
        debug(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        "debug(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any): void;
        debug(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any): void;
        info(message: string, throwable: Internal.Throwable_): void;
        error(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        fatal(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        "error(java.lang.String,java.lang.Object)"(message: string, p0: any): void;
        isFatalEnabled(): boolean;
        "error(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        "fatal(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        isEnabled(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: Internal.Message_, t: Internal.Throwable_): boolean;
        "trace(org.apache.logging.log4j.Marker,org.apache.logging.log4j.message.Message,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_, throwable: Internal.Throwable_): void;
        "warn(org.apache.logging.log4j.Marker,java.lang.String)"(marker: org.apache.logging.log4j.Marker_, message: string): void;
        debug(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        "debug(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: Internal.Message_, throwable: Internal.Throwable_): void;
        wait(): void;
        "info(org.apache.logging.log4j.Marker,org.apache.logging.log4j.message.Message)"(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_): void;
        info(message: any, throwable: Internal.Throwable_): void;
        isDebugEnabled(): boolean;
        "error(org.apache.logging.log4j.util.MessageSupplier,java.lang.Throwable)"(messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        trace(message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        "traceExit(org.apache.logging.log4j.message.Message,java.lang.Object)"<R>(message: Internal.Message_, result: R): R;
        "fatal(org.apache.logging.log4j.util.MessageSupplier,java.lang.Throwable)"(messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        traceEntry(format: string, ...params: any[]): Internal.EntryMessage;
        logIfEnabled(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        "fatal(org.apache.logging.log4j.Marker,java.lang.Object,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: any, throwable: Internal.Throwable_): void;
        error(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.Supplier,java.lang.Throwable)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        debug(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): void;
        "trace(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        atError(): Internal.LogBuilder;
        "debug(java.lang.Object)"(message: any): void;
        debug(message: Internal.CharSequence_): void;
        "traceEntry(org.apache.logging.log4j.util.Supplier[])"(...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): Internal.EntryMessage;
        "logIfEnabled(java.lang.String,org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.CharSequence,java.lang.Throwable)"(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        info(message: string, p0: any, p1: any, p2: any): void;
        "fatal(java.lang.String,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any): void;
        fatal(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): void;
        info(marker: org.apache.logging.log4j.Marker_, message: string, ...params: any[]): void;
        isEnabled(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): boolean;
        debug(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_, throwable: Internal.Throwable_): void;
        log(level: org.apache.logging.log4j.Level_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): void;
        "trace(org.apache.logging.log4j.Marker,java.lang.String)"(marker: org.apache.logging.log4j.Marker_, message: string): void;
        error(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        entry(...params: any[]): void;
        error(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        fatal(message: string, p0: any): void;
        error(message: string): void;
        info(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        "trace(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object[])"(marker: org.apache.logging.log4j.Marker_, message: string, ...params: any[]): void;
        trace(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        printf(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, format: string, ...params: any[]): void;
        "warn(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        always(): Internal.LogBuilder;
        "trace(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any): void;
        "logIfEnabled(java.lang.String,org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object)"(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.message.Message)"(level: org.apache.logging.log4j.Level_, message: Internal.Message_): void;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        "debug(java.lang.String,org.apache.logging.log4j.util.Supplier[])"(message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        "trace(org.apache.logging.log4j.Marker,org.apache.logging.log4j.message.Message)"(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_): void;
        info(message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        logIfEnabled(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        info(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        "info(java.lang.Object,java.lang.Throwable)"(message: any, throwable: Internal.Throwable_): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,org.apache.logging.log4j.message.Message,java.lang.Throwable)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: Internal.Message_, throwable: Internal.Throwable_): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.message.Message,java.lang.Throwable)"(level: org.apache.logging.log4j.Level_, message: Internal.Message_, throwable: Internal.Throwable_): void;
        "info(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any): void;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_): void;
        "info(org.apache.logging.log4j.util.Supplier)"(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        "error(java.lang.String,java.lang.Throwable)"(message: string, throwable: Internal.Throwable_): void;
        fatal(marker: org.apache.logging.log4j.Marker_, message: any, throwable: Internal.Throwable_): void;
        isWarnEnabled(): boolean;
        "trace(java.lang.String,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object[])"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, ...params: any[]): void;
        "debug(org.apache.logging.log4j.util.Supplier,java.lang.Throwable)"(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        "trace(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        debug(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        "warn(java.lang.String,java.lang.Object)"(message: string, p0: any): void;
        "error(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.Supplier,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        error(message: Internal.CharSequence_): void;
        log(level: org.apache.logging.log4j.Level_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        notifyAll(): void;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: Internal.Message_): void;
        warn(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        "error(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        "error(org.apache.logging.log4j.util.Supplier)"(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>): void;
        "debug(java.lang.String,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any): void;
        fatal(message: string, p0: any, p1: any, p2: any, p3: any, p4: any): void;
        "debug(java.lang.String)"(message: string): void;
        trace(message: string, throwable: Internal.Throwable_): void;
        log(level: org.apache.logging.log4j.Level_, message: Internal.Message_, throwable: Internal.Throwable_): void;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        "log(org.apache.logging.log4j.Level,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(level: org.apache.logging.log4j.Level_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        "info(java.lang.String,java.lang.Object)"(message: string, p0: any): void;
        "info(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        "error(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): void;
        "trace(org.apache.logging.log4j.message.Message,java.lang.Throwable)"(message: Internal.Message_, throwable: Internal.Throwable_): void;
        "isEnabled(org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.Object,java.lang.Throwable)"(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: any, t: Internal.Throwable_): boolean;
        warn(message: string, p0: any, p1: any, p2: any): void;
        "info(java.lang.CharSequence,java.lang.Throwable)"(message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        warn(marker: org.apache.logging.log4j.Marker_, message: string, ...paramSuppliers: org.apache.logging.log4j.util.Supplier_<any>[]): void;
        info(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any, p9: any): void;
        traceExit<R>(message: Internal.Message_, result: R): R;
        "logIfEnabled(java.lang.String,org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,java.lang.String,java.lang.Throwable)"(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, throwable: Internal.Throwable_): void;
        "debug(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        debug(message: string, ...params: any[]): void;
        "log(org.apache.logging.log4j.Level,org.apache.logging.log4j.util.MessageSupplier,java.lang.Throwable)"(level: org.apache.logging.log4j.Level_, messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        "debug(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.Supplier,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        log(level: org.apache.logging.log4j.Level_, messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        trace(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_): void;
        warn(message: any, throwable: Internal.Throwable_): void;
        "info(org.apache.logging.log4j.Marker,java.lang.Object,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: any, throwable: Internal.Throwable_): void;
        "error(org.apache.logging.log4j.util.MessageSupplier)"(messageSupplier: Internal.MessageSupplier_): void;
        "trace(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        trace(marker: org.apache.logging.log4j.Marker_, messageSupplier: Internal.MessageSupplier_): void;
        info(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any): void;
        debug(message: any, throwable: Internal.Throwable_): void;
        warn(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any): void;
        "logIfEnabled(java.lang.String,org.apache.logging.log4j.Level,org.apache.logging.log4j.Marker,org.apache.logging.log4j.message.Message,java.lang.Throwable)"(fqcn: string, level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: Internal.Message_, throwable: Internal.Throwable_): void;
        "warn(org.apache.logging.log4j.Marker,java.lang.CharSequence,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        fatal(marker: org.apache.logging.log4j.Marker_, message: Internal.CharSequence_, throwable: Internal.Throwable_): void;
        log(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any): void;
        error(message: string, p0: any, p1: any, p2: any, p3: any): void;
        "info(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any): void;
        trace(message: string, p0: any, p1: any): void;
        "trace(java.lang.CharSequence)"(message: Internal.CharSequence_): void;
        log(level: org.apache.logging.log4j.Level_, messageSupplier: Internal.MessageSupplier_): void;
        wait(arg0: number, arg1: number): void;
        fatal(messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        "warn(org.apache.logging.log4j.Marker,java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any): void;
        "debug(org.apache.logging.log4j.util.MessageSupplier,java.lang.Throwable)"(messageSupplier: Internal.MessageSupplier_, throwable: Internal.Throwable_): void;
        "trace(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any): void;
        "fatal(org.apache.logging.log4j.Marker,org.apache.logging.log4j.message.Message,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, message: Internal.Message_, throwable: Internal.Throwable_): void;
        isEnabled(level: org.apache.logging.log4j.Level_, marker: org.apache.logging.log4j.Marker_, message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any): boolean;
        "info(org.apache.logging.log4j.Marker,org.apache.logging.log4j.util.Supplier,java.lang.Throwable)"(marker: org.apache.logging.log4j.Marker_, messageSupplier: org.apache.logging.log4j.util.Supplier_<any>, throwable: Internal.Throwable_): void;
        debug(message: string, p0: any, p1: any, p2: any): void;
        "trace(java.lang.String,java.lang.Throwable)"(message: string, throwable: Internal.Throwable_): void;
        trace(marker: org.apache.logging.log4j.Marker_, message: any, throwable: Internal.Throwable_): void;
        fatal(message: string, throwable: Internal.Throwable_): void;
        log(level: org.apache.logging.log4j.Level_, message: Internal.Message_): void;
        "info(java.lang.String,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object)"(message: string, p0: any, p1: any, p2: any, p3: any, p4: any, p5: any, p6: any, p7: any, p8: any): void;
        error(message: any): void;
        get filters(): Internal.Iterator<Internal.Filter>
        get traceEnabled(): boolean
        get appenders(): Internal.Map<string, Internal.Appender>
        set additive(additive: boolean)
        get errorEnabled(): boolean
        get infoEnabled(): boolean
        get parent(): Internal.Logger
        set level(level: org.apache.logging.log4j.Level_)
        get recursionDepth(): number
        get level(): org.apache.logging.log4j.Level
        get name(): string
        get additive(): boolean
        get context(): Internal.LoggerContext
        get class(): typeof any
        get messageFactory(): MF
        get fatalEnabled(): boolean
        get debugEnabled(): boolean
        get warnEnabled(): boolean
    }
    type Logger_ = Logger;
    class Display$TextDisplay extends Internal.Display {
        constructor($$0: Internal.EntityType_<any>, $$1: Internal.Level_)
        litematica_setWorld(arg0: Internal.Level_): void;
        handler$hak000$gobber2$gobberOccludeVibrationSignals(cir: Internal.CallbackInfoReturnable_<any>): void;
        isInWall(): boolean;
        etf$getType(): Internal.EntityType<any>;
        getAllSlots(): Internal.Iterable<Internal.ItemStack>;
        getUpVector($$0: number): Vec3d;
        gameEvent($$0: Internal.GameEvent_, $$1: Internal.Entity_): void;
        remove($$0: Internal.Entity$RemovalReason_): void;
        getBlockZ(): number;
        isSuppressingBounce(): boolean;
        dampensVibrations(): boolean;
        hasAttached(type: Internal.AttachmentType_<any>): boolean;
        isSilent(): boolean;
        "playSound(net.minecraft.sounds.SoundEvent)"(id: Internal.SoundEvent_): void;
        setCulled(value: boolean): void;
        getPitch(): number;
        isOnFire(): boolean;
        rotate($$0: Internal.Rotation_): number;
        getPositionCodec(): Internal.VecDeltaCodec;
        getPassengersAndSelf(): Internal.Stream<any>;
        setMaxUpStep($$0: number): void;
        updateFluidHeightAndDoFluidPushing($$0: Internal.TagKey_<Internal.Fluid>, $$1: number): boolean;
        setPosition(x: number, y: number, z: number): void;
        runCommandSilent(command: string): number;
        chunkPosition(): Internal.ChunkPos;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        emf$isOnGround(): boolean;
        gameEvent($$0: Internal.GameEvent_): void;
        alwaysAccepts(): boolean;
        isShiftKeyDown(): boolean;
        setUUID($$0: Internal.UUID_): void;
        checkBelowWorld(): void;
        isVisuallyCrawling(): boolean;
        setMotionZ(z: number): void;
        handler$ieb000$lambdynlights$onRemove(ci: Internal.CallbackInfo_): void;
        "deserializeNBT(net.minecraft.nbt.Tag)"(arg0: Internal.Tag_): void;
        canFreeze(): boolean;
        ignoreExplosion(): boolean;
        port_lib$setRemovalReason(arg0: Internal.Entity$RemovalReason_): void;
        teleportRelative($$0: number, $$1: number, $$2: number): void;
        getBlockY(): number;
        getIsInsideStructureTracker(): Internal.IsInsideStructureTracker;
        isSpectator(): boolean;
        pehkui_setScaleCache(scaleCache: Internal.ScaleData_[]): void;
        isInWaterOrBubble(): boolean;
        spawnAtLocation($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        getPersistentData(): Internal.CompoundTag;
        getPortalCooldown(): number;
        emf$isGlowing(): boolean;
        getItem(): Internal.ItemStack;
        getRandomZ($$0: number): number;
        pehkui_getOnGround(): boolean;
        causeFallDamage($$0: number, $$1: number, $$2: DamageSource_): boolean;
        getFusionModel(layerIndex: number): Internal.Triple<any, any, any>;
        getDynamicLightChunksToRebuild(forced: boolean): Internal.LongSet;
        getPosition($$0: number): Vec3d;
        setRemoved($$0: Internal.Entity$RemovalReason_): void;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>, initializer: Internal.Supplier_<A>): A;
        getDistanceSq($$0: number, $$1: number, $$2: number): number;
        isInWaterRainOrBubble(): boolean;
        getRemovalReason(): Internal.Entity$RemovalReason;
        wait(arg0: number): void;
        isIgnoringBlockTriggers(): boolean;
        etf$getItemsEquipped(): Internal.Iterable<any>;
        getHandHoldingItemAngle($$0: Internal.Item_): Vec3d;
        etf$getVelocity(): Vec3d;
        hex$markHurt(): void;
        distanceToSqr($$0: Vec3d_): number;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        resetFallDistance(): void;
        canSprint(): boolean;
        modifyAttached<A>(type: Internal.AttachmentType_<A>, modifier: Internal.UnaryOperator_<A>): A;
        blockPosition(): BlockPos;
        isSteppingCarefully(): boolean;
        setBoundingBox($$0: Internal.AABB_): void;
        isAmbientCreature(): boolean;
        "spawnAtLocation(net.minecraft.world.item.ItemStack,float)"($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        getBlockX(): number;
        /**
         * @deprecated
        */
        getLightLevelDependentMagicValue(): number;
        getEncodeId(): string;
        getY($$0: number): number;
        emf$prevPitch(): number;
        getBlock(): Internal.BlockContainerJS;
        getNbt(): Internal.CompoundTag;
        etf$getHandItems(): Internal.Iterable<any>;
        setInvisible($$0: boolean): void;
        etf$getArmorItems(): Internal.Iterable<any>;
        getName(): net.minecraft.network.chat.Component;
        isSubmergedInLoosely(tag: Internal.TagKey_<any>): boolean;
        onGround(): boolean;
        getDynamicLightY(): number;
        getControlledVehicle(): Internal.Entity;
        isOnSameTeam($$0: Internal.Entity_): boolean;
        onInsideBubbleColumn($$0: boolean): void;
        attack($$0: DamageSource_, $$1: number): boolean;
        tick(): void;
        getEyePosition(): Vec3d;
        getEyeHeight(): number;
        hasPassenger($$0: Internal.Predicate_<Internal.Entity>): boolean;
        getYaw(): number;
        emf$isTouchingWater(): boolean;
        emf$getVariableMap(): Internal.Object2FloatOpenHashMap<any>;
        getComponentContainer(): Internal.ComponentContainer;
        hasPermissions($$0: number): boolean;
        getDynamicLightPrevZ(): number;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        pehkui_readScaleNbt(nbt: Internal.CompoundTag_): void;
        setCustomNameVisible($$0: boolean): void;
        isAlliedTo($$0: Internal.Team_): boolean;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>): A;
        setOutOfCamera(value: boolean): void;
        getControllingPassenger(): Internal.LivingEntity;
        getRemainingFireTicks(): number;
        getScriptType(): Internal.ScriptType;
        onlyOpCanSetNbt(): boolean;
        startRiding($$0: Internal.Entity_): boolean;
        saveWithoutId($$0: Internal.CompoundTag_): Internal.CompoundTag;
        getForward(): Vec3d;
        tcdcommons_getCustomData(): Internal.GenericProperties<any>;
        fireImmune(): boolean;
        addMotion($$0: number, $$1: number, $$2: number): void;
        getMaxFallDistance(): number;
        getZ($$0: number): number;
        getId(): number;
        pehkui_isFirstUpdate(): boolean;
        canBeHitByProjectile(): boolean;
        getTicksFrozen(): number;
        wrapWithCondition$kom000$porting_lib_entity$port_lib$captureDrops(level: Internal.Level_, entity: Internal.Entity_): boolean;
        getRecipientsForComponentSync(): Internal.Iterable<any>;
        getRandomX($$0: number): number;
        getDynamicLightZ(): number;
        getEyeY(): number;
        spawnAtLocation($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        pick($$0: number, $$1: number, $$2: boolean): Internal.HitResult;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        fabric_readAttachmentsFromNbt(nbt: Internal.CompoundTag_): void;
        getBoundingBox(): Internal.AABB;
        changeDimension(p_20118_: Internal.ServerLevel_, teleporter: Internal.ITeleporter_): Internal.Entity;
        isInWaterOrRain(): boolean;
        isDescending(): boolean;
        emf$getPitch(): number;
        cacheDisplay($$0: Internal.Display$TextDisplay$LineSplitter_): Internal.Display$TextDisplay$CachedInfo;
        setItemSlot($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_): void;
        getYHeadRot(): number;
        handler$cbi000$besmirchment$isTeammate(other: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>): void;
        equals($$0: any): boolean;
        getViewYRot($$0: number): number;
        fabric_setCustomTeleportTarget(teleportTarget: Internal.PortalInfo_): void;
        dismountsUnderwater(): boolean;
        frameworkGetDataHolder(): com.mrcrayfish.framework.entity.sync.DataHolder;
        playerTouch($$0: Internal.Player_): void;
        addTag($$0: string): boolean;
        getAddEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>;
        getEyeHeight($$0: Internal.Pose_): number;
        syncPacketPositionCodec($$0: number, $$1: number, $$2: number): void;
        callIsBeingRainedOn(): boolean;
        getTeam(): Internal.Team;
        setTransformation($$0: Internal.Transformation_): void;
        shouldRenderAtSqrDistance($$0: number): boolean;
        getAttachedOrSet<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        damageSources(): Internal.DamageSources;
        removeAttached<A>(type: Internal.AttachmentType_<A>): A;
        setTicksFrozen($$0: number): void;
        recreateFromPacket($$0: Internal.ClientboundAddEntityPacket_): void;
        getMyRidingOffset(): number;
        dismountTo($$0: number, $$1: number, $$2: number): void;
        setDeltaMovement($$0: Vec3d_): void;
        getLeashOffset($$0: number): Vec3d;
        etf$getEntityKey(): string;
        etf$getPose(): Internal.Pose;
        hasCustomName(): boolean;
        captureDrops(): Internal.Collection<any>;
        isCulled(): boolean;
        isLiving(): boolean;
        isGlowing(): boolean;
        getX(): number;
        isVehicle(): boolean;
        static transfer(original: Internal.AttachmentTarget_, target: Internal.AttachmentTarget_, isDeath: boolean): void;
        textRenderState(): Internal.Display$TextDisplay$TextRenderState;
        etf$getOptifineId(): number;
        dynamicLightWorld(): Internal.Level;
        getLeashOffset(): Vec3d;
        resetDynamicLight(): void;
        isAttackable(): boolean;
        setText($$0: net.minecraft.network.chat.Component_): void;
        spawnAtLocation($$0: Internal.ItemStack_): Internal.ItemEntity;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        thunderHit($$0: Internal.ServerLevel_, $$1: Internal.LightningBolt_): void;
        setIsInPowderSnow($$0: boolean): void;
        etf$distanceTo(entity: Internal.Entity_): number;
        doEnchantDamageEffects($$0: Internal.LivingEntity_, $$1: Internal.Entity_): void;
        setCustomName($$0: net.minecraft.network.chat.Component_): void;
        getSlot($$0: number): Internal.SlotAccess;
        lambdynlights$scheduleTrackedChunksRebuild(renderer: Internal.LevelRenderer_): void;
        "deserializeNBT(net.minecraft.nbt.CompoundTag)"(nbt: Internal.CompoundTag_): void;
        emf$isInLava(): boolean;
        pehkui_constructScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        handler$hak000$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        getTeamId(): string;
        stopSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isUnderWater(): boolean;
        stopRiding(): void;
        isCustomNameVisible(): boolean;
        isSupportedBy($$0: BlockPos_): boolean;
        getPistonPushReaction(): Internal.PushReaction;
        getX($$0: number): number;
        lookAt($$0: Internal.EntityAnchorArgument$Anchor_, $$1: Vec3d_): void;
        getLuminance(): number;
        callUnsetRemoved(): void;
        getSelfAndPassengers(): Internal.Stream<any>;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        getDeltaMovement(): Vec3d;
        collide($$0: Vec3d_): Vec3d;
        getMotionX(): number;
        "onSyncedDataUpdated(java.util.List)"($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        hasPassenger($$0: Internal.Entity_): boolean;
        be_getTravelerState(): Internal.TravelerState;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        hasIndirectPassenger($$0: Internal.Entity_): boolean;
        getDynamicLightX(): number;
        getEntityData(): Internal.SynchedEntityData;
        setSecondsOnFire($$0: number): void;
        moveTo($$0: number, $$1: number, $$2: number): void;
        emf$getZ(): number;
        "getDisplayName()"(): net.minecraft.network.chat.Component;
        handleInsidePortal($$0: BlockPos_): void;
        setMotion($$0: number, $$1: number, $$2: number): void;
        playSound($$0: Internal.SoundEvent_): void;
        absMoveTo($$0: number, $$1: number, $$2: number): void;
        isOnRails(): boolean;
        getAttachedOrThrow<A>(type: Internal.AttachmentType_<A>): A;
        handler$ikg000$lithium$tryShortcutFluidPushing(tag: Internal.TagKey_<any>, speed: number, cir: Internal.CallbackInfoReturnable_<any>, box: Internal.AABB_, x1: number, x2: number, y1: number, y2: number, z1: number, z2: number, zero: number): void;
        handler$hak000$gobber2$setFrozenTicks(frozenTicks: number, ci: Internal.CallbackInfo_): void;
        restoreFrom($$0: Internal.Entity_): void;
        markFusionRecomputeModels(): void;
        getDimensionChangingDelay(): number;
        isPeacefulCreature(): boolean;
        setOnGround($$0: boolean): void;
        emf$getYaw(): number;
        handler$cbi000$besmirchment$getScoreboardTeam(cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDynamicLuminance(): number;
        setPos($$0: number, $$1: number, $$2: number): void;
        setYaw($$0: number): void;
        getPickRadius(): number;
        notify(): void;
        getVehicle(): Internal.Entity;
        isEffectiveAi(): boolean;
        handler$kom000$porting_lib_entity$port_lib$startRiding(entity: Internal.Entity_, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        startRiding($$0: Internal.Entity_, $$1: boolean): boolean;
        setBillboardConstraints($$0: Internal.Display$BillboardConstraints_): void;
        getStringUuid(): string;
        isRemoved(): boolean;
        emf$isSneaking(): boolean;
        setSwimming($$0: boolean): void;
        teleportToWithTicket($$0: number, $$1: number, $$2: number): void;
        fillCrashReportCategory($$0: Internal.CrashReportCategory_): void;
        getRotationVector(): Internal.Vec2;
        refreshDimensions(): void;
        pehkui_writeScaleNbt(nbt: Internal.CompoundTag_): Internal.CompoundTag;
        self(): Internal.Entity;
        etf$getBlockY(): number;
        isSprinting(): boolean;
        "spawnAtLocation(net.minecraft.world.level.ItemLike)"($$0: Internal.ItemLike_): Internal.ItemEntity;
        static getAlign($$0: number): Internal.Display$TextDisplay$Align;
        getMotionY(): number;
        canCollideWith($$0: Internal.Entity_): boolean;
        setLuminance(luminance: number): void;
        setShiftKeyDown($$0: boolean): void;
        getEyePosition($$0: number): Vec3d;
        getPassengers(): Internal.EntityArrayList;
        getBlockExplosionResistance($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.FluidState_, $$5: number): number;
        handler$ldh000$puzzleslib$spawnAtLocation(stack: Internal.ItemStack_, offsetY: number, callback: Internal.CallbackInfoReturnable_<any>, itemEntity: Internal.ItemEntity_): void;
        getZ(): number;
        canSpawnSprintParticle(): boolean;
        "moveTo(net.minecraft.core.BlockPos,float,float)"($$0: BlockPos_, $$1: number, $$2: number): void;
        teleportTo($$0: number, $$1: number, $$2: number): void;
        handler$zbk000$porting_lib_base$port_lib$spawnSprintParticle(ci: Internal.CallbackInfo_, pos: BlockPos_, state: Internal.BlockState_): void;
        getServer(): Internal.MinecraftServer;
        moveRelative($$0: number, $$1: Vec3d_): void;
        getFirstPassenger(): Internal.Entity;
        saveAsPassenger($$0: Internal.CompoundTag_): boolean;
        static gatherClosestChunks(chunks: Internal.LongSet_, x: number, y: number, z: number): void;
        handler$kom000$porting_lib_entity$afterSave(nbt: Internal.CompoundTag_, cir: Internal.CallbackInfoReturnable_<any>): void;
        interact($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        getDismountLocationForPassenger($$0: Internal.LivingEntity_): Vec3d;
        checkSlowFallDistance(): void;
        getSoundSource(): Internal.SoundSource;
        setFabricBalmData(tag: Internal.CompoundTag_): void;
        removeAfterChangingDimensions(): void;
        getPose(): Internal.Pose;
        touchingUnloadedChunk(): boolean;
        getLookAngle(): Vec3d;
        setPositionAndRotation($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        emf$isOnFire(): boolean;
        getMotionZ(): number;
        etf$getUuid(): Internal.UUID;
        removeVehicle(): void;
        isInvisible(): boolean;
        shouldFusionRecomputeModel(layerIndex: number): boolean;
        is($$0: Internal.Entity_): boolean;
        orientation(): Quaternionf;
        setZ(z: number): void;
        ejectPassengers(): void;
        getY(): number;
        deserializeNBT(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        updateDynamicLightPreviousCoordinates(): void;
        getProfile(): Internal.GameProfile;
        static setViewScale($$0: number): void;
        emf$isAlive(): boolean;
        setLevelCallback($$0: Internal.EntityInLevelCallback_): void;
        showVehicleHealth(): boolean;
        getDistance(pos: BlockPos_): number;
        playSound($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        emf$getVelocity(): Vec3d;
        etf$isBlockEntity(): boolean;
        shouldUpdateDynamicLight(): boolean;
        static getDataTransformationInterpolationDurationId(): Internal.EntityDataAccessor<number>;
        startSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isOnScoreboardTeam(teamId: string): boolean;
        isPushedByFluid(): boolean;
        localvar$bbb000$architectury$modifyLevelCallback_setLevelCallback(callback: Internal.EntityInLevelCallback_): Internal.EntityInLevelCallback;
        position(): Vec3d;
        setTimeout(): void;
        displayFireAnimation(): boolean;
        turn($$0: number, $$1: number): void;
        isOutOfCamera(): boolean;
        getAirSupply(): number;
        getRopeHoldPosition($$0: number): Vec3d;
        copyPosition($$0: Internal.Entity_): void;
        "hasPassenger(net.minecraft.world.entity.Entity)"($$0: Internal.Entity_): boolean;
        etf$canBeBright(): boolean;
        isCrouching(): boolean;
        moveTo($$0: BlockPos_, $$1: number, $$2: number): void;
        isPlayer(): boolean;
        isAnimal(): boolean;
        "handler$fgd000$fabric-dimensions-v1$getTeleportTarget"(destination: Internal.ServerLevel_, cir: Internal.CallbackInfoReturnable_<any>): void;
        canBeCollidedWith(): boolean;
        getMotionDirection(): Internal.Direction;
        asComponentProvider(): Internal.ComponentProvider;
        setY(y: number): void;
        getFeetBlockState(): Internal.BlockState;
        lavaHurt(): void;
        handleDamageEvent($$0: DamageSource_): void;
        setViewRange($$0: number): void;
        getFabricBalmData(): Internal.CompoundTag;
        canChangeDimensions(): boolean;
        getChangeListener(): Internal.EntityInLevelCallback;
        static tickEntity(entity: Internal.Entity_): void;
        getCommandSenderWorld(): Internal.Level;
        positionRider($$0: Internal.Entity_): void;
        baseTick(): void;
        broadcastToPlayer($$0: Internal.ServerPlayer_): boolean;
        changeDimension($$0: Internal.ServerLevel_): Internal.Entity;
        setSharedFlag($$0: number, $$1: boolean): void;
        handler$kom000$porting_lib_entity$afterLoad(nbt: Internal.CompoundTag_, ci: Internal.CallbackInfo_): void;
        getCustomName(): net.minecraft.network.chat.Component;
        getClass(): typeof any;
        pehkui_shouldIgnoreScaleNbt(): boolean;
        isMoving(): boolean;
        isVisuallySwimming(): boolean;
        getMaxAirSupply(): number;
        attack(hp: number): void;
        dynamicLightTick(): void;
        getFacing(): Internal.Direction;
        emf$isWet(): boolean;
        "hasPassenger(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.Entity>): boolean;
        getDimensions($$0: Internal.Pose_): Internal.EntityDimensions;
        isPassengerOfSameVehicle($$0: Internal.Entity_): boolean;
        invokeGetLeashOffset(): Vec3d;
        getBoundingBoxForCulling(): Internal.AABB;
        isSwimming(): boolean;
        mayInteract($$0: Internal.Level_, $$1: BlockPos_): boolean;
        static collideBoundingBox(entity: Internal.Entity_, movement: Vec3d_, entityBoundingBox: Internal.AABB_, world: Internal.Level_, collisions: Internal.List_<any>): Vec3d;
        setSprinting($$0: boolean): void;
        getDynamicLightLevel(): Internal.Level;
        setPortalCooldown(): void;
        setX(x: number): void;
        trackingPosition(): Vec3d;
        getNameTagOffsetY(): number;
        isInvulnerable(): boolean;
        isInLava(): boolean;
        isInWater(): boolean;
        getPortalWaitTime(): number;
        awardKillScore($$0: Internal.Entity_, $$1: number, $$2: DamageSource_): void;
        getBlockStateOn(): Internal.BlockState;
        getFluidHeightLoosely(tag: Internal.TagKey_<any>): number;
        getFluidJumpThreshold(): number;
        unsetRemoved(): void;
        "setPositionAndRotation(double,double,double,float,float)"($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        isInvisibleTo($$0: Internal.Player_): boolean;
        pehkui_getScaleCache(): Internal.ScaleData[];
        setFusionModel(layerIndex: number, model: Internal.Triple_<any, any, any>): void;
        setAirSupply($$0: number): void;
        renderState(): Internal.Display$RenderState;
        getOnPos(): BlockPos;
        getRootVehicle(): Internal.Entity;
        etf$getWorld(): Internal.Level;
        save($$0: Internal.CompoundTag_): boolean;
        pehkui_getScales(): Internal.Map<any, any>;
        isNoGravity(): boolean;
        etf$getNbt(): Internal.CompoundTag;
        acceptsFailure(): boolean;
        etf$getBlockPos(): BlockPos;
        pehkui_setShouldIgnoreScaleNbt(ignore: boolean): void;
        setOnGroundWithKnownMovement($$0: boolean, $$1: Vec3d_): void;
        setOldPosAndRot(): void;
        emf$getY(): number;
        handler$kom000$porting_lib_entity$port_lib$entityInit(entityType: Internal.EntityType_<any>, world: Internal.Level_, ci: Internal.CallbackInfo_): void;
        bookshelf$createHoverEvent(): Internal.HoverEvent;
        isFree($$0: number, $$1: number, $$2: number): boolean;
        updateSwimming(): void;
        "moveTo(double,double,double)"($$0: number, $$1: number, $$2: number): void;
        setRemainingFireTicks($$0: number): void;
        getCachedFeetBlockState(): Internal.BlockState;
        shouldInformAdmins(): boolean;
        rideTick(): void;
        emf$age(): number;
        etf$hasCustomName(): boolean;
        /**
         * @deprecated
        */
        getOnPosLegacy(): BlockPos;
        setPos($$0: Vec3d_): void;
        wait(): void;
        getUuid(): Internal.UUID;
        spawn(): void;
        teleportTo($$0: Internal.ServerLevel_, $$1: number, $$2: number, $$3: number, $$4: Internal.Set_<Internal.RelativeMovement>, $$5: number, $$6: number): boolean;
        handler$kom000$porting_lib_entity$port_lib$removeRidingEntity(ci: Internal.CallbackInfo_): void;
        etf$getCustomName(): net.minecraft.network.chat.Component;
        captureDrops(value: Internal.Collection_<any>): Internal.Collection<any>;
        fabric_writeAttachmentsToNbt(nbt: Internal.CompoundTag_): void;
        shouldShowName(): boolean;
        setSilent($$0: boolean): void;
        getArmorSlots(): Internal.Iterable<Internal.ItemStack>;
        hasExactlyOnePlayerPassenger(): boolean;
        kill(): void;
        isOnPortalCooldown(): boolean;
        animateHurt($$0: number): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        handler$kom000$porting_lib_entity$port_lib$onEntityRemove(reason: Internal.Entity$RemovalReason_, ci: Internal.CallbackInfo_): void;
        lambdynlights$setTrackedLitChunkPos(trackedLitChunkPos: Internal.LongSet_): void;
        setPitch($$0: number): void;
        callGetEyeHeight(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        setPosRaw($$0: number, $$1: number, $$2: number): void;
        handleEntityEvent($$0: number): void;
        isAlwaysTicking(): boolean;
        interactAt($$0: Internal.Player_, $$1: Vec3d_, $$2: Internal.InteractionHand_): Internal.InteractionResult;
        emf$getX(): number;
        deserializeNBT(arg0: Internal.Tag_): void;
        puzzleslib$acceptCapturedDrops(capturedDrops: Internal.Collection_<any>): Internal.Collection<any>;
        handler$hak000$gobber2$gobberIsFireImmune(cir: Internal.CallbackInfoReturnable_<any>): void;
        lerpTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: boolean): void;
        onPassengerTurned($$0: Internal.Entity_): void;
        modifyReturnValue$zhe000$additionalentityattributes$getMaxAir(original: number): number;
        spawnAtLocation($$0: Internal.ItemLike_): Internal.ItemEntity;
        emf$hasPassengers(): boolean;
        serializeNBT(): Internal.CompoundTag;
        setAttached(type: Internal.AttachmentType_<any>, value: any): any;
        getBbWidth(): number;
        splitIntoDynamicLightEntries(): Internal.Stream<Internal.SpatialLookupEntry>;
        port_lib$getEntityString(): string;
        addDeltaMovement($$0: Vec3d_): void;
        pehkui_setOnGround(onGround: boolean): void;
        lithiumOnBlockCacheDeleted(): void;
        static getDataTransformationInterpolationDurationId$axiom_$md$424943$0(): Internal.EntityDataAccessor<any>;
        "spawnAtLocation(net.minecraft.world.level.ItemLike,int)"($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        setInvulnerable($$0: boolean): void;
        "getName()"(): net.minecraft.network.chat.Component;
        push($$0: Internal.Entity_): void;
        emf$hasVehicle(): boolean;
        mirror($$0: Internal.Mirror_): number;
        static port_lib$collideWithShapes(vec3: Vec3d_, aABB: Internal.AABB_, list: Internal.List_<Internal.VoxelShape>): Vec3d;
        getTicksRequiredToFreeze(): number;
        getDynamicLightPrevY(): number;
        maxUpStep(): number;
        setGlowing($$0: boolean): void;
        load($$0: Internal.CompoundTag_): void;
        isAlive(): boolean;
        emf$prevZ(): number;
        getBbHeight(): number;
        getUsername(): string;
        calculateInterpolationProgress($$0: number): number;
        move($$0: Internal.MoverType_, $$1: Vec3d_): void;
        getTags(): Internal.Set<string>;
        getViewVector($$0: number): Vec3d;
        lithiumOnBlockCacheSet(newState: Internal.BlockState_): void;
        isPickable(): boolean;
        setYHeadRot($$0: number): void;
        hasControllingPassenger(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number, $$2: number): boolean;
        absMoveTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        getCustomData(): Internal.CompoundTag;
        getPickResult(): Internal.ItemStack;
        getPercentFrozen(): number;
        getRandomY(): number;
        setPortalCooldown($$0: number): void;
        getDisplayName(): net.minecraft.network.chat.Component;
        hasGlowingTag(): boolean;
        shouldBlockExplode($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: number): boolean;
        emf$isInvisible(): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        emf$isSprinting(): boolean;
        getDynamicLightPrevX(): number;
        shouldBeSaved(): boolean;
        fabric_hasPersistentAttachments(): boolean;
        getViewXRot($$0: number): number;
        canRiderInteract(): boolean;
        fabric_getAttachments(): Internal.Map<any, any>;
        removeTag($$0: string): boolean;
        setPose($$0: Internal.Pose_): void;
        getFluidHeight($$0: Internal.TagKey_<Internal.Fluid>): number;
        getPackedBrightnessOverride(): number;
        getEntityType(): Internal.EntityType<any>;
        isWaterCreature(): boolean;
        pehkui_getScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        toString(): string;
        notifyAll(): void;
        getPassengersRidingOffset(): number;
        etf$getScoreboardTeam(): Internal.Team;
        distanceToEntitySqr($$0: Internal.Entity_): number;
        handler$ldh000$puzzleslib$removeVehicle(callback: Internal.CallbackInfo_): void;
        "getServer()"(): Internal.MinecraftServer;
        isFrame(): boolean;
        isPushable(): boolean;
        setYBodyRot($$0: number): void;
        discard(): void;
        onClientRemoval(): void;
        "handler$mhe000$step-height-entity-attribute$getStepHeight"(cir: Internal.CallbackInfoReturnable_<any>): void;
        sendSystemMessage($$0: net.minecraft.network.chat.Component_): void;
        acceptsSuccess(): boolean;
        getDistance(x: number, y: number, z: number): number;
        setMotionY(y: number): void;
        setNoGravity($$0: boolean): void;
        getAttached(type: Internal.AttachmentType_<any>): any;
        getIndirectPassengers(): Internal.Iterable<any>;
        setRotation(yaw: number, pitch: number): void;
        isDynamicLightEnabled(): boolean;
        handler$ldh000$puzzleslib$startRiding(vehicle: Internal.Entity_, force: boolean, callback: Internal.CallbackInfoReturnable_<any>): void;
        createCommandSourceStack(): Internal.CommandSourceStack;
        isControlledByLocalInstance(): boolean;
        isMonster(): boolean;
        pehkui_setShouldSyncScales(sync: boolean): void;
        setLastDynamicLuminance(luminance: number): void;
        setId($$0: number): void;
        onSyncedDataUpdated($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        getHorizontalFacing(): Internal.Direction;
        getType(): string;
        getLightProbePosition($$0: number): Vec3d;
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        onAboveBubbleCol($$0: boolean): void;
        emf$prevX(): number;
        "playSound(net.minecraft.sounds.SoundEvent,float,float)"($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        toComponentPacket(key: Internal.ComponentKey_<any>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        isPassenger(): boolean;
        hasPose($$0: Internal.Pose_): boolean;
        checkDespawn(): void;
        pehkui_shouldSyncScales(): boolean;
        isEyeInFluid($$0: Internal.TagKey_<Internal.Fluid>): boolean;
        isInvulnerableTo($$0: DamageSource_): boolean;
        makeStuckInBlock($$0: Internal.BlockState_, $$1: Vec3d_): void;
        getAttachedOrGet<A>(type: Internal.AttachmentType_<A>, defaultValue: Internal.Supplier_<A>): A;
        skipAttackInteraction($$0: Internal.Entity_): boolean;
        lerpMotion($$0: number, $$1: number, $$2: number): void;
        shouldRender($$0: number, $$1: number, $$2: number): boolean;
        onSyncedDataUpdated($$0: Internal.EntityDataAccessor_<any>): void;
        lerpHeadTo($$0: number, $$1: number): void;
        handler$bia000$axiom$onTurn(d: number, e: number, ci: Internal.CallbackInfo_): void;
        static getViewScale(): number;
        setMotionX(x: number): void;
        getHandSlots(): Internal.Iterable<Internal.ItemStack>;
        distanceToEntity($$0: Internal.Entity_): number;
        getVisualRotationYInDegrees(): number;
        wait(arg0: number, arg1: number): void;
        getTeamColor(): number;
        isDiscrete(): boolean;
        setNbt(nbt: Internal.CompoundTag_): void;
        lithiumSetClimbingMobCachingSectionUpdateBehavior(listening: boolean): void;
        unRide(): void;
        getLevel(): Internal.Level;
        "spawnAtLocation(net.minecraft.world.item.ItemStack)"($$0: Internal.ItemStack_): Internal.ItemEntity;
        lambdynlights$getTrackedLitChunkPos(): Internal.LongSet;
        extinguish(): void;
        setDynamicLightEnabled(enabled: boolean): void;
        updateDynamicGameEventListener($$0: Internal.BiConsumer_<Internal.DynamicGameEventListener<any>, Internal.ServerLevel>): void;
        moveTo($$0: Vec3d_): void;
        isColliding($$0: BlockPos_, $$1: Internal.BlockState_): boolean;
        "onSyncedDataUpdated(net.minecraft.network.syncher.EntityDataAccessor)"($$0: Internal.EntityDataAccessor_<any>): void;
        emf$prevY(): number;
        extinguishFire(): void;
        lambdynlights$updateDynamicLight(renderer: Internal.LevelRenderer_): boolean;
        tell(message: net.minecraft.network.chat.Component_): void;
        static port_lib$collideWithShapes$porting_lib_accessors_$md$424943$0(arg0: Vec3d_, arg1: Internal.AABB_, arg2: Internal.List_<any>): Vec3d;
        isForcedVisible(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number): boolean;
        getDistanceSq(pos: BlockPos_): number;
        emf$getTypeString(): string;
        killedEntity($$0: Internal.ServerLevel_, $$1: Internal.LivingEntity_): boolean;
        getAttachedOrElse<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        isFreezing(): boolean;
        isFullyFrozen(): boolean;
        runCommand(command: string): number;
        setSharedFlagOnFire($$0: boolean): void;
        get inWall(): boolean
        get allSlots(): Internal.Iterable<Internal.ItemStack>
        get blockZ(): number
        get suppressingBounce(): boolean
        get silent(): boolean
        set culled(value: boolean)
        get pitch(): number
        get onFire(): boolean
        get positionCodec(): Internal.VecDeltaCodec
        get passengersAndSelf(): Internal.Stream<any>
        set maxUpStep($$0: number)
        get shiftKeyDown(): boolean
        set UUID($$0: Internal.UUID_)
        get visuallyCrawling(): boolean
        set motionZ(z: number)
        get blockY(): number
        get isInsideStructureTracker(): Internal.IsInsideStructureTracker
        get spectator(): boolean
        get inWaterOrBubble(): boolean
        get persistentData(): Internal.CompoundTag
        get portalCooldown(): number
        get item(): Internal.ItemStack
        set removed($$0: Internal.Entity$RemovalReason_)
        get inWaterRainOrBubble(): boolean
        get removalReason(): Internal.Entity$RemovalReason
        get ignoringBlockTriggers(): boolean
        get steppingCarefully(): boolean
        set boundingBox($$0: Internal.AABB_)
        get ambientCreature(): boolean
        get blockX(): number
        /**
         * @deprecated
        */
        get lightLevelDependentMagicValue(): number
        get encodeId(): string
        get block(): Internal.BlockContainerJS
        get nbt(): Internal.CompoundTag
        set invisible($$0: boolean)
        get name(): net.minecraft.network.chat.Component
        get dynamicLightY(): number
        get controlledVehicle(): Internal.Entity
        get eyePosition(): Vec3d
        get eyeHeight(): number
        get yaw(): number
        get componentContainer(): Internal.ComponentContainer
        get dynamicLightPrevZ(): number
        set customNameVisible($$0: boolean)
        set outOfCamera(value: boolean)
        get controllingPassenger(): Internal.LivingEntity
        get remainingFireTicks(): number
        get scriptType(): Internal.ScriptType
        get forward(): Vec3d
        get maxFallDistance(): number
        get id(): number
        get ticksFrozen(): number
        get recipientsForComponentSync(): Internal.Iterable<any>
        get dynamicLightZ(): number
        get eyeY(): number
        set statusMessage(message: net.minecraft.network.chat.Component_)
        get boundingBox(): Internal.AABB
        get inWaterOrRain(): boolean
        get descending(): boolean
        get YHeadRot(): number
        get addEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>
        get team(): Internal.Team
        set transformation($$0: Internal.Transformation_)
        set ticksFrozen($$0: number)
        get myRidingOffset(): number
        set deltaMovement($$0: Vec3d_)
        get culled(): boolean
        get living(): boolean
        get glowing(): boolean
        get x(): number
        get vehicle(): boolean
        get leashOffset(): Vec3d
        get attackable(): boolean
        set text($$0: net.minecraft.network.chat.Component_)
        set isInPowderSnow($$0: boolean)
        set customName($$0: net.minecraft.network.chat.Component_)
        get teamId(): string
        get underWater(): boolean
        get customNameVisible(): boolean
        get pistonPushReaction(): Internal.PushReaction
        get luminance(): number
        get selfAndPassengers(): Internal.Stream<any>
        get deltaMovement(): Vec3d
        get motionX(): number
        get dynamicLightX(): number
        get entityData(): Internal.SynchedEntityData
        set secondsOnFire($$0: number)
        get "displayName()"(): net.minecraft.network.chat.Component
        get onRails(): boolean
        get dimensionChangingDelay(): number
        get peacefulCreature(): boolean
        set onGround($$0: boolean)
        get lastDynamicLuminance(): number
        set yaw($$0: number)
        get pickRadius(): number
        get vehicle(): Internal.Entity
        get effectiveAi(): boolean
        set billboardConstraints($$0: Internal.Display$BillboardConstraints_)
        get stringUuid(): string
        get removed(): boolean
        set swimming($$0: boolean)
        get rotationVector(): Internal.Vec2
        get sprinting(): boolean
        get motionY(): number
        set luminance(luminance: number)
        set shiftKeyDown($$0: boolean)
        get passengers(): Internal.EntityArrayList
        get z(): number
        get server(): Internal.MinecraftServer
        get firstPassenger(): Internal.Entity
        get soundSource(): Internal.SoundSource
        set fabricBalmData(tag: Internal.CompoundTag_)
        get pose(): Internal.Pose
        get lookAngle(): Vec3d
        get motionZ(): number
        get invisible(): boolean
        set z(z: number)
        get y(): number
        get profile(): Internal.GameProfile
        set viewScale($$0: number)
        set levelCallback($$0: Internal.EntityInLevelCallback_)
        get dataTransformationInterpolationDurationId(): Internal.EntityDataAccessor<number>
        get pushedByFluid(): boolean
        get outOfCamera(): boolean
        get airSupply(): number
        get crouching(): boolean
        get player(): boolean
        get animal(): boolean
        get motionDirection(): Internal.Direction
        set y(y: number)
        get feetBlockState(): Internal.BlockState
        set viewRange($$0: number)
        get fabricBalmData(): Internal.CompoundTag
        get changeListener(): Internal.EntityInLevelCallback
        get commandSenderWorld(): Internal.Level
        get customName(): net.minecraft.network.chat.Component
        get class(): typeof any
        get moving(): boolean
        get visuallySwimming(): boolean
        get maxAirSupply(): number
        get facing(): Internal.Direction
        get boundingBoxForCulling(): Internal.AABB
        get swimming(): boolean
        set sprinting($$0: boolean)
        get dynamicLightLevel(): Internal.Level
        set x(x: number)
        get nameTagOffsetY(): number
        get invulnerable(): boolean
        get inLava(): boolean
        get inWater(): boolean
        get portalWaitTime(): number
        get blockStateOn(): Internal.BlockState
        get fluidJumpThreshold(): number
        set airSupply($$0: number)
        get onPos(): BlockPos
        get rootVehicle(): Internal.Entity
        get noGravity(): boolean
        set remainingFireTicks($$0: number)
        get cachedFeetBlockState(): Internal.BlockState
        /**
         * @deprecated
        */
        get onPosLegacy(): BlockPos
        set pos($$0: Vec3d_)
        get uuid(): Internal.UUID
        set silent($$0: boolean)
        get armorSlots(): Internal.Iterable<Internal.ItemStack>
        get onPortalCooldown(): boolean
        set pitch($$0: number)
        get alwaysTicking(): boolean
        get bbWidth(): number
        get dataTransformationInterpolationDurationId$axiom_$md$424943$0(): Internal.EntityDataAccessor<any>
        set invulnerable($$0: boolean)
        get "name()"(): net.minecraft.network.chat.Component
        get ticksRequiredToFreeze(): number
        get dynamicLightPrevY(): number
        set glowing($$0: boolean)
        get alive(): boolean
        get bbHeight(): number
        get username(): string
        get tags(): Internal.Set<string>
        get pickable(): boolean
        set YHeadRot($$0: number)
        get customData(): Internal.CompoundTag
        get pickResult(): Internal.ItemStack
        get percentFrozen(): number
        get randomY(): number
        set portalCooldown($$0: number)
        get displayName(): net.minecraft.network.chat.Component
        set position(block: Internal.BlockContainerJS_)
        get dynamicLightPrevX(): number
        set pose($$0: Internal.Pose_)
        get packedBrightnessOverride(): number
        get entityType(): Internal.EntityType<any>
        get waterCreature(): boolean
        get passengersRidingOffset(): number
        get "server()"(): Internal.MinecraftServer
        get frame(): boolean
        get pushable(): boolean
        set YBodyRot($$0: number)
        set motionY(y: number)
        set noGravity($$0: boolean)
        get indirectPassengers(): Internal.Iterable<any>
        get dynamicLightEnabled(): boolean
        get controlledByLocalInstance(): boolean
        get monster(): boolean
        set lastDynamicLuminance(luminance: number)
        set id($$0: number)
        get horizontalFacing(): Internal.Direction
        get type(): string
        get passenger(): boolean
        get viewScale(): number
        set motionX(x: number)
        get handSlots(): Internal.Iterable<Internal.ItemStack>
        get visualRotationYInDegrees(): number
        get teamColor(): number
        get discrete(): boolean
        set nbt(nbt: Internal.CompoundTag_)
        get level(): Internal.Level
        set dynamicLightEnabled(enabled: boolean)
        get forcedVisible(): boolean
        get freezing(): boolean
        get fullyFrozen(): boolean
        set sharedFlagOnFire($$0: boolean)
        static readonly DATA_TEXT_ID: Internal.EntityDataAccessor<net.minecraft.network.chat.Component>;
        static readonly DATA_LINE_WIDTH_ID: Internal.EntityDataAccessor<number>;
        static readonly FLAG_SEE_THROUGH: (2) & (number);
        static readonly TAG_TEXT: ("text") & (string);
        static readonly INITIAL_BACKGROUND: (1073741824) & (number);
        static readonly DATA_STYLE_FLAGS_ID: Internal.EntityDataAccessor<number>;
        static readonly FLAG_SHADOW: (1) & (number);
        static readonly FLAG_ALIGN_LEFT: (8) & (number);
        static readonly FLAG_ALIGN_RIGHT: (16) & (number);
        static readonly DATA_BACKGROUND_COLOR_ID: Internal.EntityDataAccessor<number>;
        static readonly FLAG_USE_DEFAULT_BACKGROUND: (4) & (number);
        static readonly DATA_TEXT_OPACITY_ID: Internal.EntityDataAccessor<number>;
    }
    type Display$TextDisplay_ = Display$TextDisplay;
    class BlockDestructionProgress implements Internal.Comparable<Internal.BlockDestructionProgress> {
        constructor($$0: number, $$1: BlockPos_)
        getProgress(): number;
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        "compareTo(net.minecraft.server.level.BlockDestructionProgress)"($$0: Internal.BlockDestructionProgress_): number;
        setProgress($$0: number): void;
        compareTo(arg0: any): number;
        getUpdatedRenderTick(): number;
        getPos(): BlockPos;
        hashCode(): number;
        wait(): void;
        compareTo($$0: Internal.BlockDestructionProgress_): number;
        wait(arg0: number): void;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals($$0: any): boolean;
        updateTick($$0: number): void;
        getId(): number;
        get progress(): number
        get class(): typeof any
        set progress($$0: number)
        get updatedRenderTick(): number
        get pos(): BlockPos
        get id(): number
    }
    type BlockDestructionProgress_ = BlockDestructionProgress;
    interface BlockAndTintGetter extends Internal.BlockGetter {
        abstract getBlockTint(arg0: BlockPos_, arg1: Internal.ColorResolver_): number;
        getMinSection(): number;
        abstract getShade(arg0: Internal.Direction_, arg1: boolean): number;
        abstract getBlockState(arg0: BlockPos_): Internal.BlockState;
        clipWithInteractionOverride($$0: Vec3d_, $$1: Vec3d_, $$2: BlockPos_, $$3: Internal.VoxelShape_, $$4: Internal.BlockState_): Internal.BlockHitResult;
        getSectionIndex($$0: number): number;
        getMaxSection(): number;
        getBrightness($$0: Internal.LightLayer_, $$1: BlockPos_): number;
        getMaxBuildHeight(): number;
        getBlockEntityRenderData(pos: BlockPos_): any;
        getBiomeFabric(pos: BlockPos_): Internal.Holder<Internal.Biome>;
        getLightEmission($$0: BlockPos_): number;
        getBlockFloorHeight($$0: BlockPos_): number;
        getSectionYFromSectionIndex($$0: number): number;
        create($$0: number, $$1: number): Internal.LevelHeightAccessor;
        "isOutsideBuildHeight(int)"($$0: number): boolean;
        clip($$0: Internal.ClipContext_): Internal.BlockHitResult;
        abstract getLightEngine(): Internal.LevelLightEngine;
        getBlockFloorHeight($$0: Internal.VoxelShape_, $$1: Internal.Supplier_<Internal.VoxelShape>): number;
        abstract getBlockEntity(arg0: BlockPos_): Internal.BlockEntity;
        abstract getHeight(): number;
        getRawBrightness($$0: BlockPos_, $$1: number): number;
        getBlockEntity<T extends Internal.BlockEntity>($$0: BlockPos_, $$1: Internal.BlockEntityType_<T>): Optional<T>;
        isOutsideBuildHeight($$0: BlockPos_): boolean;
        canSeeSky($$0: BlockPos_): boolean;
        isOutsideBuildHeight($$0: number): boolean;
        isBlockInLine($$0: Internal.ClipBlockStateContext_): Internal.BlockHitResult;
        abstract getFluidState(arg0: BlockPos_): Internal.FluidState;
        "isOutsideBuildHeight(net.minecraft.core.BlockPos)"($$0: BlockPos_): boolean;
        getBlockStates($$0: Internal.AABB_): Internal.Stream<Internal.BlockState>;
        getSectionsCount(): number;
        abstract getMinBuildHeight(): number;
        hasBiomes(): boolean;
        getMaxLightLevel(): number;
        getSectionIndexFromSectionY($$0: number): number;
        traverseBlocks<T, C>($$0: Vec3d_, $$1: Vec3d_, $$2: C, $$3: Internal.BiFunction_<C, BlockPos, T>, $$4: Internal.Function_<C, T>): T;
        get minSection(): number
        get maxSection(): number
        get maxBuildHeight(): number
        get lightEngine(): Internal.LevelLightEngine
        get height(): number
        get sectionsCount(): number
        get minBuildHeight(): number
        get maxLightLevel(): number
    }
    type BlockAndTintGetter_ = BlockAndTintGetter;
    class DrinkableItem extends vectorwing.farmersdelight.common.item.ConsumableItem {
        constructor(properties: Internal.Item$Properties_, hasFoodEffectTooltip: boolean)
        constructor(properties: Internal.Item$Properties_)
        constructor(properties: Internal.Item$Properties_, hasPotionEffectTooltip: boolean, hasCustomTooltip: boolean)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, level: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, isAdvanced: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getUseAnimation(stack: Internal.ItemStack_): Internal.UseAnim;
        getDescriptionId(): string;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(level: Internal.Level_, player: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        affectConsumer(stack: Internal.ItemStack_, level: Internal.Level_, consumer: Internal.LivingEntity_): void;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration(stack: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem(stack: Internal.ItemStack_, level: Internal.Level_, consumer: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type DrinkableItem_ = DrinkableItem;
    interface BiomeData {
        abstract codec(): Internal.KeyDispatchDataCodec<Internal.BCLBiome>;
        (): Internal.KeyDispatchDataCodec_<Internal.BCLBiome>;
        readonly CODEC: Internal.Codec<Internal.BCLBiome>;
    }
    type BiomeData_ = (()=> Internal.KeyDispatchDataCodec_<Internal.BCLBiome>) | BiomeData;
    class AttributeModifier$Operation extends Internal.Enum<Internal.AttributeModifier$Operation> {
        static valueOf($$0: string): Internal.AttributeModifier$Operation;
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        getDeclaringClass(): typeof Internal.AttributeModifier$Operation;
        static fromValue($$0: number): Internal.AttributeModifier$Operation;
        toString(): string;
        notifyAll(): void;
        "compareTo(net.minecraft.world.entity.ai.attributes.AttributeModifier$Operation)"(arg0: Internal.AttributeModifier$Operation_): number;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        toValue(): number;
        name(): string;
        hashCode(): number;
        ordinal(): number;
        wait(): void;
        compareTo(arg0: Internal.AttributeModifier$Operation_): number;
        wait(arg0: number): void;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.AttributeModifier$Operation>>;
        static values(): Internal.AttributeModifier$Operation[];
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        get class(): typeof any
        get declaringClass(): typeof Internal.AttributeModifier$Operation
        static readonly MULTIPLY_BASE: (Internal.AttributeModifier$Operation) & (Internal.AttributeModifier$Operation);
        static readonly MULTIPLY_TOTAL: (Internal.AttributeModifier$Operation) & (Internal.AttributeModifier$Operation);
        static readonly ADDITION: (Internal.AttributeModifier$Operation) & (Internal.AttributeModifier$Operation);
    }
    type AttributeModifier$Operation_ = "addition" | AttributeModifier$Operation | "multiply_total" | "multiply_base";
    class ObjectStartedEvent$TaskEvent extends Internal.ObjectStartedEvent<Internal.Task> {
        constructor(d: Internal.QuestProgressEventData_<Internal.Task>)
        getObject(): Internal.Task;
        getClass(): typeof any;
        getTime(): Internal.Date;
        toString(): string;
        getNotifiedPlayers(): Internal.List<Internal.ServerPlayer>;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getOnlineMembers(): Internal.List<Internal.ServerPlayer>;
        hashCode(): number;
        isCancelable(): boolean;
        wait(): void;
        wait(arg0: number): void;
        getData(): Internal.TeamData;
        equals(arg0: any): boolean;
        getTask(): Internal.Task;
        get object(): Internal.Task
        get class(): typeof any
        get time(): Internal.Date
        get notifiedPlayers(): Internal.List<Internal.ServerPlayer>
        get onlineMembers(): Internal.List<Internal.ServerPlayer>
        get cancelable(): boolean
        get data(): Internal.TeamData
        get task(): Internal.Task
    }
    type ObjectStartedEvent$TaskEvent_ = ObjectStartedEvent$TaskEvent;
    class ComplexItem extends Internal.Item {
        constructor($$0: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        isComplex(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getUpdatePacket($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): Internal.Packet<any>;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type ComplexItem_ = ComplexItem;
    interface AnimationMetadataSectionAccessor {
        abstract setFrameWidth(arg0: number): void;
        abstract setFrameHeight(arg0: number): void;
        abstract getFrameHeight(): number;
        abstract getFrameWidth(): number;
        set frameWidth(arg0: number)
        set frameHeight(arg0: number)
        get frameHeight(): number
        get frameWidth(): number
    }
    type AnimationMetadataSectionAccessor_ = AnimationMetadataSectionAccessor;
    abstract class AbstractMinecart extends Internal.Entity implements Internal.AbstractMinecartAccessor, Internal.MinecartEntityAccessor, Internal.AbstractMinecartExtensions {
        litematica_setWorld(arg0: Internal.Level_): void;
        handler$hak000$gobber2$gobberOccludeVibrationSignals(cir: Internal.CallbackInfoReturnable_<any>): void;
        isInWall(): boolean;
        etf$getType(): Internal.EntityType<any>;
        getAllSlots(): Internal.Iterable<Internal.ItemStack>;
        getUpVector($$0: number): Vec3d;
        getPos($$0: number, $$1: number, $$2: number): Vec3d;
        gameEvent($$0: Internal.GameEvent_, $$1: Internal.Entity_): void;
        remove($$0: Internal.Entity$RemovalReason_): void;
        getBlockZ(): number;
        isSuppressingBounce(): boolean;
        setHurtTime($$0: number): void;
        dampensVibrations(): boolean;
        hasAttached(type: Internal.AttachmentType_<any>): boolean;
        isSilent(): boolean;
        "playSound(net.minecraft.sounds.SoundEvent)"($$0: Internal.SoundEvent_): void;
        setCulled(value: boolean): void;
        getPitch(): number;
        isOnFire(): boolean;
        rotate($$0: Internal.Rotation_): number;
        getPositionCodec(): Internal.VecDeltaCodec;
        getPassengersAndSelf(): Internal.Stream<any>;
        setMaxUpStep($$0: number): void;
        updateFluidHeightAndDoFluidPushing($$0: Internal.TagKey_<Internal.Fluid>, $$1: number): boolean;
        setPosition(x: number, y: number, z: number): void;
        runCommandSilent(command: string): number;
        chunkPosition(): Internal.ChunkPos;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        emf$isOnGround(): boolean;
        gameEvent($$0: Internal.GameEvent_): void;
        alwaysAccepts(): boolean;
        isShiftKeyDown(): boolean;
        setUUID($$0: Internal.UUID_): void;
        checkBelowWorld(): void;
        isVisuallyCrawling(): boolean;
        setMotionZ(z: number): void;
        abstract getDropItem(): Internal.Item;
        handler$ieb000$lambdynlights$onRemove(ci: Internal.CallbackInfo_): void;
        "deserializeNBT(net.minecraft.nbt.Tag)"(arg0: Internal.Tag_): void;
        canFreeze(): boolean;
        ignoreExplosion(): boolean;
        port_lib$setRemovalReason(arg0: Internal.Entity$RemovalReason_): void;
        teleportRelative($$0: number, $$1: number, $$2: number): void;
        getBlockY(): number;
        getIsInsideStructureTracker(): Internal.IsInsideStructureTracker;
        isSpectator(): boolean;
        pehkui_setScaleCache(scaleCache: Internal.ScaleData_[]): void;
        isInWaterOrBubble(): boolean;
        spawnAtLocation($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        getPersistentData(): Internal.CompoundTag;
        getPortalCooldown(): number;
        emf$isGlowing(): boolean;
        getItem(): Internal.ItemStack;
        getRandomZ($$0: number): number;
        pehkui_getOnGround(): boolean;
        causeFallDamage($$0: number, $$1: number, $$2: DamageSource_): boolean;
        getFusionModel(layerIndex: number): Internal.Triple<any, any, any>;
        getDynamicLightChunksToRebuild(forced: boolean): Internal.LongSet;
        getPosition($$0: number): Vec3d;
        setRemoved($$0: Internal.Entity$RemovalReason_): void;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>, initializer: Internal.Supplier_<A>): A;
        getDistanceSq($$0: number, $$1: number, $$2: number): number;
        isInWaterRainOrBubble(): boolean;
        getRemovalReason(): Internal.Entity$RemovalReason;
        wait(arg0: number): void;
        isIgnoringBlockTriggers(): boolean;
        getDamage(): number;
        etf$getItemsEquipped(): Internal.Iterable<any>;
        getHandHoldingItemAngle($$0: Internal.Item_): Vec3d;
        etf$getVelocity(): Vec3d;
        getPosOffs($$0: number, $$1: number, $$2: number, $$3: number): Vec3d;
        hex$markHurt(): void;
        distanceToSqr($$0: Vec3d_): number;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        resetFallDistance(): void;
        canSprint(): boolean;
        modifyAttached<A>(type: Internal.AttachmentType_<A>, modifier: Internal.UnaryOperator_<A>): A;
        blockPosition(): BlockPos;
        isSteppingCarefully(): boolean;
        setBoundingBox($$0: Internal.AABB_): void;
        isAmbientCreature(): boolean;
        "spawnAtLocation(net.minecraft.world.item.ItemStack,float)"($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        getDisplayBlockState(): Internal.BlockState;
        getBlockX(): number;
        /**
         * @deprecated
        */
        getLightLevelDependentMagicValue(): number;
        getEncodeId(): string;
        getY($$0: number): number;
        emf$prevPitch(): number;
        getBlock(): Internal.BlockContainerJS;
        getNbt(): Internal.CompoundTag;
        etf$getHandItems(): Internal.Iterable<any>;
        setInvisible($$0: boolean): void;
        etf$getArmorItems(): Internal.Iterable<any>;
        getName(): net.minecraft.network.chat.Component;
        isSubmergedInLoosely(tag: Internal.TagKey_<any>): boolean;
        onGround(): boolean;
        getDynamicLightY(): number;
        getControlledVehicle(): Internal.Entity;
        isOnSameTeam($$0: Internal.Entity_): boolean;
        attack($$0: DamageSource_, $$1: number): boolean;
        onInsideBubbleColumn($$0: boolean): void;
        tick(): void;
        invokeGetMaxOffRailSpeed(): number;
        getEyePosition(): Vec3d;
        getEyeHeight(): number;
        hasPassenger($$0: Internal.Predicate_<Internal.Entity>): boolean;
        getYaw(): number;
        emf$isTouchingWater(): boolean;
        emf$getVariableMap(): Internal.Object2FloatOpenHashMap<any>;
        getComponentContainer(): Internal.ComponentContainer;
        hasPermissions($$0: number): boolean;
        getDynamicLightPrevZ(): number;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        pehkui_readScaleNbt(nbt: Internal.CompoundTag_): void;
        setCustomNameVisible($$0: boolean): void;
        isAlliedTo($$0: Internal.Team_): boolean;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>): A;
        setOutOfCamera(value: boolean): void;
        getControllingPassenger(): Internal.LivingEntity;
        getRemainingFireTicks(): number;
        getScriptType(): Internal.ScriptType;
        onlyOpCanSetNbt(): boolean;
        startRiding($$0: Internal.Entity_): boolean;
        saveWithoutId($$0: Internal.CompoundTag_): Internal.CompoundTag;
        getForward(): Vec3d;
        tcdcommons_getCustomData(): Internal.GenericProperties<any>;
        fireImmune(): boolean;
        addMotion($$0: number, $$1: number, $$2: number): void;
        getMaxFallDistance(): number;
        getZ($$0: number): number;
        getId(): number;
        pehkui_isFirstUpdate(): boolean;
        canBeHitByProjectile(): boolean;
        getTicksFrozen(): number;
        wrapWithCondition$kom000$porting_lib_entity$port_lib$captureDrops(level: Internal.Level_, entity: Internal.Entity_): boolean;
        getRecipientsForComponentSync(): Internal.Iterable<any>;
        getRandomX($$0: number): number;
        getDynamicLightZ(): number;
        getEyeY(): number;
        spawnAtLocation($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        pick($$0: number, $$1: number, $$2: boolean): Internal.HitResult;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        fabric_readAttachmentsFromNbt(nbt: Internal.CompoundTag_): void;
        getBoundingBox(): Internal.AABB;
        changeDimension(p_20118_: Internal.ServerLevel_, teleporter: Internal.ITeleporter_): Internal.Entity;
        isInWaterOrRain(): boolean;
        isDescending(): boolean;
        emf$getPitch(): number;
        setItemSlot($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_): void;
        getYHeadRot(): number;
        handler$cbi000$besmirchment$isTeammate(other: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>): void;
        equals($$0: any): boolean;
        getViewYRot($$0: number): number;
        fabric_setCustomTeleportTarget(teleportTarget: Internal.PortalInfo_): void;
        dismountsUnderwater(): boolean;
        frameworkGetDataHolder(): com.mrcrayfish.framework.entity.sync.DataHolder;
        playerTouch($$0: Internal.Player_): void;
        addTag($$0: string): boolean;
        getEyeHeight($$0: Internal.Pose_): number;
        getAddEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>;
        syncPacketPositionCodec($$0: number, $$1: number, $$2: number): void;
        callIsBeingRainedOn(): boolean;
        setDamage($$0: number): void;
        getDisplayOffset(): number;
        getTeam(): Internal.Team;
        shouldRenderAtSqrDistance($$0: number): boolean;
        getAttachedOrSet<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        damageSources(): Internal.DamageSources;
        removeAttached<A>(type: Internal.AttachmentType_<A>): A;
        setTicksFrozen($$0: number): void;
        recreateFromPacket($$0: Internal.ClientboundAddEntityPacket_): void;
        getMyRidingOffset(): number;
        dismountTo($$0: number, $$1: number, $$2: number): void;
        setDeltaMovement($$0: Vec3d_): void;
        getLeashOffset($$0: number): Vec3d;
        etf$getEntityKey(): string;
        etf$getPose(): Internal.Pose;
        hasCustomName(): boolean;
        captureDrops(): Internal.Collection<any>;
        isCulled(): boolean;
        isLiving(): boolean;
        isGlowing(): boolean;
        getX(): number;
        isVehicle(): boolean;
        static transfer(original: Internal.AttachmentTarget_, target: Internal.AttachmentTarget_, isDeath: boolean): void;
        etf$getOptifineId(): number;
        dynamicLightWorld(): Internal.Level;
        getLeashOffset(): Vec3d;
        resetDynamicLight(): void;
        isAttackable(): boolean;
        spawnAtLocation($$0: Internal.ItemStack_): Internal.ItemEntity;
        getMaxSpeedOnRail(): number;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        thunderHit($$0: Internal.ServerLevel_, $$1: Internal.LightningBolt_): void;
        setIsInPowderSnow($$0: boolean): void;
        etf$distanceTo(entity: Internal.Entity_): number;
        doEnchantDamageEffects($$0: Internal.LivingEntity_, $$1: Internal.Entity_): void;
        setCustomName($$0: net.minecraft.network.chat.Component_): void;
        getSlot($$0: number): Internal.SlotAccess;
        lambdynlights$scheduleTrackedChunksRebuild(renderer: Internal.LevelRenderer_): void;
        "deserializeNBT(net.minecraft.nbt.CompoundTag)"(nbt: Internal.CompoundTag_): void;
        emf$isInLava(): boolean;
        pehkui_constructScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        handler$hak000$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        getTeamId(): string;
        stopSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isUnderWater(): boolean;
        stopRiding(): void;
        isCustomNameVisible(): boolean;
        isSupportedBy($$0: BlockPos_): boolean;
        getPistonPushReaction(): Internal.PushReaction;
        getX($$0: number): number;
        lookAt($$0: Internal.EntityAnchorArgument$Anchor_, $$1: Vec3d_): void;
        getLuminance(): number;
        callUnsetRemoved(): void;
        getSelfAndPassengers(): Internal.Stream<any>;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        getDeltaMovement(): Vec3d;
        collide($$0: Vec3d_): Vec3d;
        getMotionX(): number;
        "onSyncedDataUpdated(java.util.List)"($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        hasPassenger($$0: Internal.Entity_): boolean;
        be_getTravelerState(): Internal.TravelerState;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        hasIndirectPassenger($$0: Internal.Entity_): boolean;
        getDynamicLightX(): number;
        getEntityData(): Internal.SynchedEntityData;
        setSecondsOnFire($$0: number): void;
        moveTo($$0: number, $$1: number, $$2: number): void;
        emf$getZ(): number;
        "getDisplayName()"(): net.minecraft.network.chat.Component;
        handleInsidePortal($$0: BlockPos_): void;
        setMotion($$0: number, $$1: number, $$2: number): void;
        playSound($$0: Internal.SoundEvent_): void;
        absMoveTo($$0: number, $$1: number, $$2: number): void;
        isOnRails(): boolean;
        getAttachedOrThrow<A>(type: Internal.AttachmentType_<A>): A;
        handler$ikg000$lithium$tryShortcutFluidPushing(tag: Internal.TagKey_<any>, speed: number, cir: Internal.CallbackInfoReturnable_<any>, box: Internal.AABB_, x1: number, x2: number, y1: number, y2: number, z1: number, z2: number, zero: number): void;
        handler$hak000$gobber2$setFrozenTicks(frozenTicks: number, ci: Internal.CallbackInfo_): void;
        restoreFrom($$0: Internal.Entity_): void;
        markFusionRecomputeModels(): void;
        getDimensionChangingDelay(): number;
        isPeacefulCreature(): boolean;
        setOnGround($$0: boolean): void;
        emf$getYaw(): number;
        handler$cbi000$besmirchment$getScoreboardTeam(cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDynamicLuminance(): number;
        setPos($$0: number, $$1: number, $$2: number): void;
        setYaw($$0: number): void;
        getPickRadius(): number;
        notify(): void;
        getVehicle(): Internal.Entity;
        isEffectiveAi(): boolean;
        handler$kom000$porting_lib_entity$port_lib$startRiding(entity: Internal.Entity_, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        startRiding($$0: Internal.Entity_, $$1: boolean): boolean;
        getStringUuid(): string;
        isRemoved(): boolean;
        emf$isSneaking(): boolean;
        setSwimming($$0: boolean): void;
        teleportToWithTicket($$0: number, $$1: number, $$2: number): void;
        fillCrashReportCategory($$0: Internal.CrashReportCategory_): void;
        getRotationVector(): Internal.Vec2;
        refreshDimensions(): void;
        pehkui_writeScaleNbt(nbt: Internal.CompoundTag_): Internal.CompoundTag;
        self(): Internal.Entity;
        etf$getBlockY(): number;
        isSprinting(): boolean;
        "spawnAtLocation(net.minecraft.world.level.ItemLike)"($$0: Internal.ItemLike_): Internal.ItemEntity;
        getMotionY(): number;
        canCollideWith($$0: Internal.Entity_): boolean;
        setLuminance(luminance: number): void;
        setShiftKeyDown($$0: boolean): void;
        getEyePosition($$0: number): Vec3d;
        getPassengers(): Internal.EntityArrayList;
        getBlockExplosionResistance($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.FluidState_, $$5: number): number;
        handler$ldh000$puzzleslib$spawnAtLocation(stack: Internal.ItemStack_, offsetY: number, callback: Internal.CallbackInfoReturnable_<any>, itemEntity: Internal.ItemEntity_): void;
        port_lib$getMaxSpeed(): number;
        getZ(): number;
        canSpawnSprintParticle(): boolean;
        "moveTo(net.minecraft.core.BlockPos,float,float)"($$0: BlockPos_, $$1: number, $$2: number): void;
        teleportTo($$0: number, $$1: number, $$2: number): void;
        handler$zbk000$porting_lib_base$port_lib$spawnSprintParticle(ci: Internal.CallbackInfo_, pos: BlockPos_, state: Internal.BlockState_): void;
        getServer(): Internal.MinecraftServer;
        moveRelative($$0: number, $$1: Vec3d_): void;
        getFirstPassenger(): Internal.Entity;
        saveAsPassenger($$0: Internal.CompoundTag_): boolean;
        static gatherClosestChunks(chunks: Internal.LongSet_, x: number, y: number, z: number): void;
        handler$kom000$porting_lib_entity$afterSave(nbt: Internal.CompoundTag_, cir: Internal.CallbackInfoReturnable_<any>): void;
        interact($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        setHurtDir($$0: number): void;
        getDismountLocationForPassenger($$0: Internal.LivingEntity_): Vec3d;
        checkSlowFallDistance(): void;
        getSoundSource(): Internal.SoundSource;
        setFabricBalmData(tag: Internal.CompoundTag_): void;
        removeAfterChangingDimensions(): void;
        getPose(): Internal.Pose;
        touchingUnloadedChunk(): boolean;
        getHurtDir(): number;
        getLookAngle(): Vec3d;
        setPositionAndRotation($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        emf$isOnFire(): boolean;
        getMotionZ(): number;
        etf$getUuid(): Internal.UUID;
        removeVehicle(): void;
        isInvisible(): boolean;
        shouldFusionRecomputeModel(layerIndex: number): boolean;
        is($$0: Internal.Entity_): boolean;
        setZ(z: number): void;
        ejectPassengers(): void;
        getY(): number;
        deserializeNBT(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        updateDynamicLightPreviousCoordinates(): void;
        getProfile(): Internal.GameProfile;
        static setViewScale($$0: number): void;
        emf$isAlive(): boolean;
        setLevelCallback($$0: Internal.EntityInLevelCallback_): void;
        showVehicleHealth(): boolean;
        getDistance(pos: BlockPos_): number;
        playSound($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        emf$getVelocity(): Vec3d;
        setCustomDisplay($$0: boolean): void;
        getCurrentRailPos(): BlockPos;
        etf$isBlockEntity(): boolean;
        shouldUpdateDynamicLight(): boolean;
        startSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isOnScoreboardTeam(teamId: string): boolean;
        isPushedByFluid(): boolean;
        localvar$bbb000$architectury$modifyLevelCallback_setLevelCallback(callback: Internal.EntityInLevelCallback_): Internal.EntityInLevelCallback;
        position(): Vec3d;
        setTimeout(): void;
        displayFireAnimation(): boolean;
        turn($$0: number, $$1: number): void;
        isOutOfCamera(): boolean;
        getAirSupply(): number;
        getRopeHoldPosition($$0: number): Vec3d;
        copyPosition($$0: Internal.Entity_): void;
        "hasPassenger(net.minecraft.world.entity.Entity)"($$0: Internal.Entity_): boolean;
        etf$canBeBright(): boolean;
        isCrouching(): boolean;
        moveTo($$0: BlockPos_, $$1: number, $$2: number): void;
        isPlayer(): boolean;
        isAnimal(): boolean;
        getMotionDirection(): Internal.Direction;
        "handler$fgd000$fabric-dimensions-v1$getTeleportTarget"(destination: Internal.ServerLevel_, cir: Internal.CallbackInfoReturnable_<any>): void;
        canBeCollidedWith(): boolean;
        asComponentProvider(): Internal.ComponentProvider;
        setY(y: number): void;
        getFeetBlockState(): Internal.BlockState;
        lavaHurt(): void;
        handleDamageEvent($$0: DamageSource_): void;
        getFabricBalmData(): Internal.CompoundTag;
        canChangeDimensions(): boolean;
        getChangeListener(): Internal.EntityInLevelCallback;
        static tickEntity(entity: Internal.Entity_): void;
        getCommandSenderWorld(): Internal.Level;
        positionRider($$0: Internal.Entity_): void;
        baseTick(): void;
        broadcastToPlayer($$0: Internal.ServerPlayer_): boolean;
        changeDimension($$0: Internal.ServerLevel_): Internal.Entity;
        setSharedFlag($$0: number, $$1: boolean): void;
        handler$kom000$porting_lib_entity$afterLoad(nbt: Internal.CompoundTag_, ci: Internal.CallbackInfo_): void;
        getCustomName(): net.minecraft.network.chat.Component;
        getClass(): typeof any;
        pehkui_shouldIgnoreScaleNbt(): boolean;
        isMoving(): boolean;
        isVisuallySwimming(): boolean;
        getMaxAirSupply(): number;
        attack(hp: number): void;
        dynamicLightTick(): void;
        getFacing(): Internal.Direction;
        emf$isWet(): boolean;
        hasCustomDisplay(): boolean;
        "hasPassenger(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.Entity>): boolean;
        getDimensions($$0: Internal.Pose_): Internal.EntityDimensions;
        isPassengerOfSameVehicle($$0: Internal.Entity_): boolean;
        invokeGetLeashOffset(): Vec3d;
        getBoundingBoxForCulling(): Internal.AABB;
        isSwimming(): boolean;
        mayInteract($$0: Internal.Level_, $$1: BlockPos_): boolean;
        static collideBoundingBox(entity: Internal.Entity_, movement: Vec3d_, entityBoundingBox: Internal.AABB_, world: Internal.Level_, collisions: Internal.List_<any>): Vec3d;
        setSprinting($$0: boolean): void;
        getDynamicLightLevel(): Internal.Level;
        setPortalCooldown(): void;
        setX(x: number): void;
        trackingPosition(): Vec3d;
        getNameTagOffsetY(): number;
        setDisplayOffset($$0: number): void;
        isInvulnerable(): boolean;
        isInLava(): boolean;
        isInWater(): boolean;
        getPortalWaitTime(): number;
        awardKillScore($$0: Internal.Entity_, $$1: number, $$2: DamageSource_): void;
        getBlockStateOn(): Internal.BlockState;
        getFluidHeightLoosely(tag: Internal.TagKey_<any>): number;
        getFluidJumpThreshold(): number;
        unsetRemoved(): void;
        "setPositionAndRotation(double,double,double,float,float)"(x: number, y: number, z: number, yaw: number, pitch: number): void;
        isInvisibleTo($$0: Internal.Player_): boolean;
        pehkui_getScaleCache(): Internal.ScaleData[];
        setFusionModel(layerIndex: number, model: Internal.Triple_<any, any, any>): void;
        setAirSupply($$0: number): void;
        getOnPos(): BlockPos;
        getRootVehicle(): Internal.Entity;
        etf$getWorld(): Internal.Level;
        save($$0: Internal.CompoundTag_): boolean;
        pehkui_getScales(): Internal.Map<any, any>;
        isNoGravity(): boolean;
        getDefaultDisplayOffset(): number;
        etf$getNbt(): Internal.CompoundTag;
        acceptsFailure(): boolean;
        etf$getBlockPos(): BlockPos;
        pehkui_setShouldIgnoreScaleNbt(ignore: boolean): void;
        setOnGroundWithKnownMovement($$0: boolean, $$1: Vec3d_): void;
        setOldPosAndRot(): void;
        emf$getY(): number;
        handler$kom000$porting_lib_entity$port_lib$entityInit(entityType: Internal.EntityType_<any>, world: Internal.Level_, ci: Internal.CallbackInfo_): void;
        bookshelf$createHoverEvent(): Internal.HoverEvent;
        isFree($$0: number, $$1: number, $$2: number): boolean;
        updateSwimming(): void;
        "moveTo(double,double,double)"($$0: number, $$1: number, $$2: number): void;
        setRemainingFireTicks($$0: number): void;
        getCachedFeetBlockState(): Internal.BlockState;
        shouldInformAdmins(): boolean;
        rideTick(): void;
        emf$age(): number;
        etf$hasCustomName(): boolean;
        /**
         * @deprecated
        */
        getOnPosLegacy(): BlockPos;
        setPos($$0: Vec3d_): void;
        wait(): void;
        getUuid(): Internal.UUID;
        spawn(): void;
        teleportTo($$0: Internal.ServerLevel_, $$1: number, $$2: number, $$3: number, $$4: Internal.Set_<Internal.RelativeMovement>, $$5: number, $$6: number): boolean;
        handler$kom000$porting_lib_entity$port_lib$removeRidingEntity(ci: Internal.CallbackInfo_): void;
        etf$getCustomName(): net.minecraft.network.chat.Component;
        captureDrops(value: Internal.Collection_<any>): Internal.Collection<any>;
        fabric_writeAttachmentsToNbt(nbt: Internal.CompoundTag_): void;
        shouldShowName(): boolean;
        setSilent($$0: boolean): void;
        getArmorSlots(): Internal.Iterable<Internal.ItemStack>;
        hasExactlyOnePlayerPassenger(): boolean;
        kill(): void;
        isOnPortalCooldown(): boolean;
        animateHurt($$0: number): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        handler$kom000$porting_lib_entity$port_lib$onEntityRemove(reason: Internal.Entity$RemovalReason_, ci: Internal.CallbackInfo_): void;
        lambdynlights$setTrackedLitChunkPos(trackedLitChunkPos: Internal.LongSet_): void;
        static createMinecart($$0: Internal.Level_, $$1: number, $$2: number, $$3: number, $$4: Internal.AbstractMinecart$Type_): Internal.AbstractMinecart;
        callGetEyeHeight(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        setPitch($$0: number): void;
        setPosRaw($$0: number, $$1: number, $$2: number): void;
        handleEntityEvent($$0: number): void;
        isAlwaysTicking(): boolean;
        interactAt($$0: Internal.Player_, $$1: Vec3d_, $$2: Internal.InteractionHand_): Internal.InteractionResult;
        emf$getX(): number;
        deserializeNBT(arg0: Internal.Tag_): void;
        puzzleslib$acceptCapturedDrops(capturedDrops: Internal.Collection_<any>): Internal.Collection<any>;
        handler$hak000$gobber2$gobberIsFireImmune(cir: Internal.CallbackInfoReturnable_<any>): void;
        lerpTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: boolean): void;
        onPassengerTurned($$0: Internal.Entity_): void;
        modifyReturnValue$zhe000$additionalentityattributes$getMaxAir(original: number): number;
        spawnAtLocation($$0: Internal.ItemLike_): Internal.ItemEntity;
        emf$hasPassengers(): boolean;
        serializeNBT(): Internal.CompoundTag;
        setAttached(type: Internal.AttachmentType_<any>, value: any): any;
        getBbWidth(): number;
        splitIntoDynamicLightEntries(): Internal.Stream<Internal.SpatialLookupEntry>;
        port_lib$getEntityString(): string;
        addDeltaMovement($$0: Vec3d_): void;
        pehkui_setOnGround(onGround: boolean): void;
        lithiumOnBlockCacheDeleted(): void;
        "spawnAtLocation(net.minecraft.world.level.ItemLike,int)"($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        setInvulnerable($$0: boolean): void;
        "getName()"(): net.minecraft.network.chat.Component;
        push($$0: Internal.Entity_): void;
        emf$hasVehicle(): boolean;
        mirror($$0: Internal.Mirror_): number;
        activateMinecart($$0: number, $$1: number, $$2: number, $$3: boolean): void;
        static port_lib$collideWithShapes(vec3: Vec3d_, aABB: Internal.AABB_, list: Internal.List_<Internal.VoxelShape>): Vec3d;
        getTicksRequiredToFreeze(): number;
        getDynamicLightPrevY(): number;
        maxUpStep(): number;
        setGlowing($$0: boolean): void;
        load($$0: Internal.CompoundTag_): void;
        isAlive(): boolean;
        emf$prevZ(): number;
        getBbHeight(): number;
        getUsername(): string;
        move($$0: Internal.MoverType_, $$1: Vec3d_): void;
        getTags(): Internal.Set<string>;
        getViewVector($$0: number): Vec3d;
        lithiumOnBlockCacheSet(newState: Internal.BlockState_): void;
        isPickable(): boolean;
        setYHeadRot($$0: number): void;
        abstract getMinecartType(): Internal.AbstractMinecart$Type;
        hasControllingPassenger(): boolean;
        moveMinecartOnRail(pos: BlockPos_): void;
        closerThan($$0: Internal.Entity_, $$1: number, $$2: number): boolean;
        absMoveTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        getCustomData(): Internal.CompoundTag;
        getPickResult(): Internal.ItemStack;
        getPercentFrozen(): number;
        getRandomY(): number;
        setPortalCooldown($$0: number): void;
        getDisplayName(): net.minecraft.network.chat.Component;
        hasGlowingTag(): boolean;
        shouldBlockExplode($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: number): boolean;
        emf$isInvisible(): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        emf$isSprinting(): boolean;
        getDynamicLightPrevX(): number;
        shouldBeSaved(): boolean;
        fabric_hasPersistentAttachments(): boolean;
        getViewXRot($$0: number): number;
        canRiderInteract(): boolean;
        destroy($$0: DamageSource_): void;
        fabric_getAttachments(): Internal.Map<any, any>;
        removeTag($$0: string): boolean;
        setPose($$0: Internal.Pose_): void;
        getFluidHeight($$0: Internal.TagKey_<Internal.Fluid>): number;
        getEntityType(): Internal.EntityType<any>;
        isWaterCreature(): boolean;
        pehkui_getScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        toString(): string;
        notifyAll(): void;
        getPassengersRidingOffset(): number;
        etf$getScoreboardTeam(): Internal.Team;
        distanceToEntitySqr($$0: Internal.Entity_): number;
        handler$ldh000$puzzleslib$removeVehicle(callback: Internal.CallbackInfo_): void;
        "getServer()"(): Internal.MinecraftServer;
        isFrame(): boolean;
        isPushable(): boolean;
        setYBodyRot($$0: number): void;
        discard(): void;
        onClientRemoval(): void;
        "handler$mhe000$step-height-entity-attribute$getStepHeight"(cir: Internal.CallbackInfoReturnable_<any>): void;
        sendSystemMessage($$0: net.minecraft.network.chat.Component_): void;
        acceptsSuccess(): boolean;
        getDistance(x: number, y: number, z: number): number;
        setMotionY(y: number): void;
        setNoGravity($$0: boolean): void;
        getAttached(type: Internal.AttachmentType_<any>): any;
        getIndirectPassengers(): Internal.Iterable<any>;
        setRotation(yaw: number, pitch: number): void;
        isDynamicLightEnabled(): boolean;
        handler$ldh000$puzzleslib$startRiding(vehicle: Internal.Entity_, force: boolean, callback: Internal.CallbackInfoReturnable_<any>): void;
        createCommandSourceStack(): Internal.CommandSourceStack;
        isControlledByLocalInstance(): boolean;
        isMonster(): boolean;
        pehkui_setShouldSyncScales(sync: boolean): void;
        setLastDynamicLuminance(luminance: number): void;
        setId($$0: number): void;
        onSyncedDataUpdated($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        getHorizontalFacing(): Internal.Direction;
        getType(): string;
        getLightProbePosition($$0: number): Vec3d;
        getDefaultDisplayBlockState(): Internal.BlockState;
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        onAboveBubbleCol($$0: boolean): void;
        emf$prevX(): number;
        "playSound(net.minecraft.sounds.SoundEvent,float,float)"($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        toComponentPacket(key: Internal.ComponentKey_<any>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        isPassenger(): boolean;
        hasPose($$0: Internal.Pose_): boolean;
        checkDespawn(): void;
        pehkui_shouldSyncScales(): boolean;
        isEyeInFluid($$0: Internal.TagKey_<Internal.Fluid>): boolean;
        isInvulnerableTo($$0: DamageSource_): boolean;
        makeStuckInBlock($$0: Internal.BlockState_, $$1: Vec3d_): void;
        getAttachedOrGet<A>(type: Internal.AttachmentType_<A>, defaultValue: Internal.Supplier_<A>): A;
        skipAttackInteraction($$0: Internal.Entity_): boolean;
        lerpMotion($$0: number, $$1: number, $$2: number): void;
        shouldRender($$0: number, $$1: number, $$2: number): boolean;
        onSyncedDataUpdated($$0: Internal.EntityDataAccessor_<any>): void;
        getHurtTime(): number;
        lerpHeadTo($$0: number, $$1: number): void;
        handler$bia000$axiom$onTurn(d: number, e: number, ci: Internal.CallbackInfo_): void;
        static getViewScale(): number;
        setMotionX(x: number): void;
        getHandSlots(): Internal.Iterable<Internal.ItemStack>;
        distanceToEntity($$0: Internal.Entity_): number;
        getVisualRotationYInDegrees(): number;
        wait(arg0: number, arg1: number): void;
        isDiscrete(): boolean;
        getTeamColor(): number;
        setNbt(nbt: Internal.CompoundTag_): void;
        lithiumSetClimbingMobCachingSectionUpdateBehavior(listening: boolean): void;
        unRide(): void;
        getLevel(): Internal.Level;
        "spawnAtLocation(net.minecraft.world.item.ItemStack)"($$0: Internal.ItemStack_): Internal.ItemEntity;
        lambdynlights$getTrackedLitChunkPos(): Internal.LongSet;
        extinguish(): void;
        setDynamicLightEnabled(enabled: boolean): void;
        updateDynamicGameEventListener($$0: Internal.BiConsumer_<Internal.DynamicGameEventListener<any>, Internal.ServerLevel>): void;
        moveTo($$0: Vec3d_): void;
        isColliding($$0: BlockPos_, $$1: Internal.BlockState_): boolean;
        "onSyncedDataUpdated(net.minecraft.network.syncher.EntityDataAccessor)"($$0: Internal.EntityDataAccessor_<any>): void;
        emf$prevY(): number;
        extinguishFire(): void;
        lambdynlights$updateDynamicLight(renderer: Internal.LevelRenderer_): boolean;
        tell(message: net.minecraft.network.chat.Component_): void;
        static port_lib$collideWithShapes$porting_lib_accessors_$md$424943$0(arg0: Vec3d_, arg1: Internal.AABB_, arg2: Internal.List_<any>): Vec3d;
        isForcedVisible(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number): boolean;
        getDistanceSq(pos: BlockPos_): number;
        emf$getTypeString(): string;
        killedEntity($$0: Internal.ServerLevel_, $$1: Internal.LivingEntity_): boolean;
        getAttachedOrElse<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        isFreezing(): boolean;
        invokeWillHitBlockAt(arg0: BlockPos_): boolean;
        isFullyFrozen(): boolean;
        runCommand(command: string): number;
        setDisplayBlockState($$0: Internal.BlockState_): void;
        setSharedFlagOnFire($$0: boolean): void;
        get inWall(): boolean
        get allSlots(): Internal.Iterable<Internal.ItemStack>
        get blockZ(): number
        get suppressingBounce(): boolean
        set hurtTime($$0: number)
        get silent(): boolean
        set culled(value: boolean)
        get pitch(): number
        get onFire(): boolean
        get positionCodec(): Internal.VecDeltaCodec
        get passengersAndSelf(): Internal.Stream<any>
        set maxUpStep($$0: number)
        get shiftKeyDown(): boolean
        set UUID($$0: Internal.UUID_)
        get visuallyCrawling(): boolean
        set motionZ(z: number)
        get dropItem(): Internal.Item
        get blockY(): number
        get isInsideStructureTracker(): Internal.IsInsideStructureTracker
        get spectator(): boolean
        get inWaterOrBubble(): boolean
        get persistentData(): Internal.CompoundTag
        get portalCooldown(): number
        get item(): Internal.ItemStack
        set removed($$0: Internal.Entity$RemovalReason_)
        get inWaterRainOrBubble(): boolean
        get removalReason(): Internal.Entity$RemovalReason
        get ignoringBlockTriggers(): boolean
        get damage(): number
        get steppingCarefully(): boolean
        set boundingBox($$0: Internal.AABB_)
        get ambientCreature(): boolean
        get displayBlockState(): Internal.BlockState
        get blockX(): number
        /**
         * @deprecated
        */
        get lightLevelDependentMagicValue(): number
        get encodeId(): string
        get block(): Internal.BlockContainerJS
        get nbt(): Internal.CompoundTag
        set invisible($$0: boolean)
        get name(): net.minecraft.network.chat.Component
        get dynamicLightY(): number
        get controlledVehicle(): Internal.Entity
        get eyePosition(): Vec3d
        get eyeHeight(): number
        get yaw(): number
        get componentContainer(): Internal.ComponentContainer
        get dynamicLightPrevZ(): number
        set customNameVisible($$0: boolean)
        set outOfCamera(value: boolean)
        get controllingPassenger(): Internal.LivingEntity
        get remainingFireTicks(): number
        get scriptType(): Internal.ScriptType
        get forward(): Vec3d
        get maxFallDistance(): number
        get id(): number
        get ticksFrozen(): number
        get recipientsForComponentSync(): Internal.Iterable<any>
        get dynamicLightZ(): number
        get eyeY(): number
        set statusMessage(message: net.minecraft.network.chat.Component_)
        get boundingBox(): Internal.AABB
        get inWaterOrRain(): boolean
        get descending(): boolean
        get YHeadRot(): number
        get addEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>
        set damage($$0: number)
        get displayOffset(): number
        get team(): Internal.Team
        set ticksFrozen($$0: number)
        get myRidingOffset(): number
        set deltaMovement($$0: Vec3d_)
        get culled(): boolean
        get living(): boolean
        get glowing(): boolean
        get x(): number
        get vehicle(): boolean
        get leashOffset(): Vec3d
        get attackable(): boolean
        get maxSpeedOnRail(): number
        set isInPowderSnow($$0: boolean)
        set customName($$0: net.minecraft.network.chat.Component_)
        get teamId(): string
        get underWater(): boolean
        get customNameVisible(): boolean
        get pistonPushReaction(): Internal.PushReaction
        get luminance(): number
        get selfAndPassengers(): Internal.Stream<any>
        get deltaMovement(): Vec3d
        get motionX(): number
        get dynamicLightX(): number
        get entityData(): Internal.SynchedEntityData
        set secondsOnFire($$0: number)
        get "displayName()"(): net.minecraft.network.chat.Component
        get onRails(): boolean
        get dimensionChangingDelay(): number
        get peacefulCreature(): boolean
        set onGround($$0: boolean)
        get lastDynamicLuminance(): number
        set yaw($$0: number)
        get pickRadius(): number
        get vehicle(): Internal.Entity
        get effectiveAi(): boolean
        get stringUuid(): string
        get removed(): boolean
        set swimming($$0: boolean)
        get rotationVector(): Internal.Vec2
        get sprinting(): boolean
        get motionY(): number
        set luminance(luminance: number)
        set shiftKeyDown($$0: boolean)
        get passengers(): Internal.EntityArrayList
        get z(): number
        get server(): Internal.MinecraftServer
        get firstPassenger(): Internal.Entity
        set hurtDir($$0: number)
        get soundSource(): Internal.SoundSource
        set fabricBalmData(tag: Internal.CompoundTag_)
        get pose(): Internal.Pose
        get hurtDir(): number
        get lookAngle(): Vec3d
        get motionZ(): number
        get invisible(): boolean
        set z(z: number)
        get y(): number
        get profile(): Internal.GameProfile
        set viewScale($$0: number)
        set levelCallback($$0: Internal.EntityInLevelCallback_)
        set customDisplay($$0: boolean)
        get currentRailPos(): BlockPos
        get pushedByFluid(): boolean
        get outOfCamera(): boolean
        get airSupply(): number
        get crouching(): boolean
        get player(): boolean
        get animal(): boolean
        get motionDirection(): Internal.Direction
        set y(y: number)
        get feetBlockState(): Internal.BlockState
        get fabricBalmData(): Internal.CompoundTag
        get changeListener(): Internal.EntityInLevelCallback
        get commandSenderWorld(): Internal.Level
        get customName(): net.minecraft.network.chat.Component
        get class(): typeof any
        get moving(): boolean
        get visuallySwimming(): boolean
        get maxAirSupply(): number
        get facing(): Internal.Direction
        get boundingBoxForCulling(): Internal.AABB
        get swimming(): boolean
        set sprinting($$0: boolean)
        get dynamicLightLevel(): Internal.Level
        set x(x: number)
        get nameTagOffsetY(): number
        set displayOffset($$0: number)
        get invulnerable(): boolean
        get inLava(): boolean
        get inWater(): boolean
        get portalWaitTime(): number
        get blockStateOn(): Internal.BlockState
        get fluidJumpThreshold(): number
        set airSupply($$0: number)
        get onPos(): BlockPos
        get rootVehicle(): Internal.Entity
        get noGravity(): boolean
        get defaultDisplayOffset(): number
        set remainingFireTicks($$0: number)
        get cachedFeetBlockState(): Internal.BlockState
        /**
         * @deprecated
        */
        get onPosLegacy(): BlockPos
        set pos($$0: Vec3d_)
        get uuid(): Internal.UUID
        set silent($$0: boolean)
        get armorSlots(): Internal.Iterable<Internal.ItemStack>
        get onPortalCooldown(): boolean
        set pitch($$0: number)
        get alwaysTicking(): boolean
        get bbWidth(): number
        set invulnerable($$0: boolean)
        get "name()"(): net.minecraft.network.chat.Component
        get ticksRequiredToFreeze(): number
        get dynamicLightPrevY(): number
        set glowing($$0: boolean)
        get alive(): boolean
        get bbHeight(): number
        get username(): string
        get tags(): Internal.Set<string>
        get pickable(): boolean
        set YHeadRot($$0: number)
        get minecartType(): Internal.AbstractMinecart$Type
        get customData(): Internal.CompoundTag
        get pickResult(): Internal.ItemStack
        get percentFrozen(): number
        get randomY(): number
        set portalCooldown($$0: number)
        get displayName(): net.minecraft.network.chat.Component
        set position(block: Internal.BlockContainerJS_)
        get dynamicLightPrevX(): number
        set pose($$0: Internal.Pose_)
        get entityType(): Internal.EntityType<any>
        get waterCreature(): boolean
        get passengersRidingOffset(): number
        get "server()"(): Internal.MinecraftServer
        get frame(): boolean
        get pushable(): boolean
        set YBodyRot($$0: number)
        set motionY(y: number)
        set noGravity($$0: boolean)
        get indirectPassengers(): Internal.Iterable<any>
        get dynamicLightEnabled(): boolean
        get controlledByLocalInstance(): boolean
        get monster(): boolean
        set lastDynamicLuminance(luminance: number)
        set id($$0: number)
        get horizontalFacing(): Internal.Direction
        get type(): string
        get defaultDisplayBlockState(): Internal.BlockState
        get passenger(): boolean
        get hurtTime(): number
        get viewScale(): number
        set motionX(x: number)
        get handSlots(): Internal.Iterable<Internal.ItemStack>
        get visualRotationYInDegrees(): number
        get discrete(): boolean
        get teamColor(): number
        set nbt(nbt: Internal.CompoundTag_)
        get level(): Internal.Level
        set dynamicLightEnabled(enabled: boolean)
        get forcedVisible(): boolean
        get freezing(): boolean
        get fullyFrozen(): boolean
        set displayBlockState($$0: Internal.BlockState_)
        set sharedFlagOnFire($$0: boolean)
    }
    type AbstractMinecart_ = AbstractMinecart;
    interface CreativeModeTabKJS {
        abstract kjs$setIcon(arg0: Internal.ItemStack_): void;
        abstract kjs$setDisplayName(arg0: net.minecraft.network.chat.Component_): void;
    }
    type CreativeModeTabKJS_ = CreativeModeTabKJS;
    interface Watcher {
        abstract getLastModified(): number;
        abstract getListeners(): Internal.List<Internal.ConfigurationListener>;
        abstract modified(): void;
        abstract isModified(): boolean;
        abstract getSource(): Internal.Source;
        abstract newWatcher(reconfigurable: Internal.Reconfigurable_, listeners: Internal.List_<Internal.ConfigurationListener>, lastModifiedMillis: number): this;
        abstract watching(source: Internal.Source_): void;
        get lastModified(): number
        get listeners(): Internal.List<Internal.ConfigurationListener>
        get modified(): boolean
        get source(): Internal.Source
        readonly CATEGORY: ("Watcher") & (string);
        readonly ELEMENT_TYPE: ("watcher") & (string);
    }
    type Watcher_ = Watcher;
    class ChatLog {
        constructor($$0: number)
        getClass(): typeof any;
        end(): number;
        start(): number;
        toString(): string;
        notifyAll(): void;
        static codec($$0: number): Internal.Codec<Internal.ChatLog>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        lookup($$0: number): Internal.LoggedChatEvent;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        push($$0: Internal.LoggedChatEvent_): void;
        equals(arg0: any): boolean;
        get class(): typeof any
    }
    type ChatLog_ = ChatLog;
    interface EffectsProperties {
        abstract getWaterColor(): number;
        abstract getAmbientLoopSound(): Optional<Internal.Holder<Internal.SoundEvent>>;
        abstract getGrassColorModifier(): Internal.BiomeSpecialEffects$GrassColorModifier;
        abstract getBackgroundMusic(): Optional<Internal.Music>;
        abstract getAmbientAdditionsSound(): Optional<Internal.AmbientAdditionsSettings>;
        abstract getFoliageColorOverride(): Internal.OptionalInt;
        abstract getAmbientMoodSound(): Optional<Internal.AmbientMoodSettings>;
        abstract getWaterFogColor(): number;
        abstract getFogColor(): number;
        abstract getAmbientParticle(): Optional<Internal.AmbientParticleSettings>;
        abstract getSkyColor(): number;
        abstract getGrassColorOverride(): Internal.OptionalInt;
        get waterColor(): number
        get ambientLoopSound(): Optional<Internal.Holder<Internal.SoundEvent>>
        get grassColorModifier(): Internal.BiomeSpecialEffects$GrassColorModifier
        get backgroundMusic(): Optional<Internal.Music>
        get ambientAdditionsSound(): Optional<Internal.AmbientAdditionsSettings>
        get foliageColorOverride(): Internal.OptionalInt
        get ambientMoodSound(): Optional<Internal.AmbientMoodSettings>
        get waterFogColor(): number
        get fogColor(): number
        get ambientParticle(): Optional<Internal.AmbientParticleSettings>
        get skyColor(): number
        get grassColorOverride(): Internal.OptionalInt
    }
    type EffectsProperties_ = EffectsProperties;
    interface WorldCreationContext$OptionsModifier extends Internal.UnaryOperator<Internal.WorldOptions> {
        identity<T>(): Internal.UnaryOperator<T>;
        abstract apply(arg0: Internal.WorldOptions_): Internal.WorldOptions;
        andThen<V>(arg0: Internal.Function_<Internal.WorldOptions, V>): Internal.Function<Internal.WorldOptions, V>;
        compose<V>(arg0: Internal.Function_<V, Internal.WorldOptions>): Internal.Function<V, Internal.WorldOptions>;
        (arg0: Internal.WorldOptions): Internal.WorldOptions_;
    }
    type WorldCreationContext$OptionsModifier_ = ((arg0: Internal.WorldOptions)=> Internal.WorldOptions_) | WorldCreationContext$OptionsModifier;
    class Weight {
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        static of($$0: number): Internal.Weight;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals($$0: any): boolean;
        notify(): void;
        asInt(): number;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        static readonly CODEC: Internal.Codec<Internal.Weight>;
    }
    type Weight_ = Weight;
    interface WorldlyContainerHolder {
        abstract getContainer(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_): Internal.WorldlyContainer;
        (arg0: Internal.BlockState, arg1: Internal.LevelAccessor, arg2: BlockPos): Internal.WorldlyContainer_;
    }
    type WorldlyContainerHolder_ = WorldlyContainerHolder | ((arg0: Internal.BlockState, arg1: Internal.LevelAccessor, arg2: BlockPos)=> Internal.WorldlyContainer_);
    class ClientChunkCache$Storage {
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        inRange($$0: number, $$1: number): boolean;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        chunks: Internal.AtomicReferenceArray<Internal.LevelChunk>;
    }
    type ClientChunkCache$Storage_ = ClientChunkCache$Storage;
    class OwoUIAdapter <R extends Internal.ParentComponent> implements Internal.NarratableEntry, Internal.GuiEventListener, Internal.Renderable {
        charTyped(chr: string, modifiers: number): boolean;
        getClass(): typeof any;
        isFocused(): boolean;
        y(): number;
        setFocused(focused: boolean): void;
        x(): number;
        static create<R extends Internal.ParentComponent>(screen: Internal.Screen_, rootComponentMaker: Internal.BiFunction_<Internal.Sizing, Internal.Sizing, R>): Internal.OwoUIAdapter<R>;
        isActive(): boolean;
        getTabOrderGroup(): number;
        mouseScrolled(mouseX: number, mouseY: number, amount: number): boolean;
        mouseClicked(mouseX: number, mouseY: number, button: number): boolean;
        keyReleased($$0: number, $$1: number, $$2: number): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        static isRendering(): boolean;
        static createWithoutScreen<R extends Internal.ParentComponent>(x: number, y: number, width: number, height: number, rootComponentMaker: Internal.BiFunction_<Internal.Sizing, Internal.Sizing, R>): Internal.OwoUIAdapter<R>;
        mouseDragged(mouseX: number, mouseY: number, button: number, deltaX: number, deltaY: number): boolean;
        mouseMoved($$0: number, $$1: number): void;
        getRectangle(): Internal.ScreenRectangle;
        toggleInspector(): boolean;
        nextFocusPath($$0: Internal.FocusNavigationEvent_): Internal.ComponentPath;
        inflateAndMount(): void;
        toString(): string;
        narrationPriority(): Internal.NarratableEntry$NarrationPriority;
        notifyAll(): void;
        height(): number;
        mouseReleased(mouseX: number, mouseY: number, button: number): boolean;
        keyPressed(keyCode: number, scanCode: number, modifiers: number): boolean;
        hashCode(): number;
        getCurrentFocusPath(): Internal.ComponentPath;
        updateNarration(builder: Internal.NarrationElementOutput_): void;
        toggleGlobalInspector(): boolean;
        wait(): void;
        wait(arg0: number): void;
        render(context: Internal.GuiGraphics_, mouseX: number, mouseY: number, partialTicks: number): void;
        width(): number;
        dispose(): void;
        equals(arg0: any): boolean;
        moveAndResize(x: number, y: number, width: number, height: number): void;
        isMouseOver(mouseX: number, mouseY: number): boolean;
        get class(): typeof any
        get focused(): boolean
        set focused(focused: boolean)
        get active(): boolean
        get tabOrderGroup(): number
        get rendering(): boolean
        get rectangle(): Internal.ScreenRectangle
        get currentFocusPath(): Internal.ComponentPath
        globalInspector: boolean;
        readonly rootComponent: R;
        readonly cursorAdapter: Internal.CursorAdapter;
        inspectorZOffset: number;
        enableInspector: boolean;
    }
    type OwoUIAdapter_<R extends Internal.ParentComponent> = OwoUIAdapter<R>;
    interface InstantSource {
        tick(arg0: Internal.InstantSource_, arg1: Duration_): this;
        offset(arg0: Internal.InstantSource_, arg1: Duration_): this;
        fixed(arg0: Internal.Instant_): this;
        abstract instant(): Internal.Instant;
        system(): this;
        withZone(arg0: Internal.ZoneId_): Internal.Clock;
        millis(): number;
        (): Internal.Instant_;
    }
    type InstantSource_ = InstantSource | (()=> Internal.Instant_);
    interface CorporeaNode {
        abstract getPos(): BlockPos;
        abstract getWorld(): Internal.Level;
        abstract getSpark(): Internal.CorporeaSpark;
        abstract countItems(arg0: Internal.CorporeaRequest_): Internal.List<Internal.ItemStack>;
        abstract extractItems(arg0: Internal.CorporeaRequest_): Internal.List<Internal.ItemStack>;
        get pos(): BlockPos
        get world(): Internal.Level
        get spark(): Internal.CorporeaSpark
    }
    type CorporeaNode_ = CorporeaNode;
    class OreConfig extends Internal.Record implements Internal.FeatureConfiguration {
        constructor(size: number, targets: Internal.List_<Internal.OreConfig$Target>)
        getClass(): typeof any;
        hashCode(): number;
        size(): number;
        targets(): Internal.List<Internal.OreConfig$Target>;
        getFeatures(): Internal.Stream<Internal.ConfiguredFeature<any, any>>;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(o: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        get features(): Internal.Stream<Internal.ConfiguredFeature<any, any>>
        static readonly CODEC: Internal.Codec<Internal.OreConfig>;
    }
    type OreConfig_ = OreConfig;
    class BasicHoeItem extends Internal.DiggerItem {
        constructor(material: Internal.Tier_, attackDamage: number, attackSpeed: number, settings: Internal.Item$Properties_)
        onTick(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        bclib_getBlockTag(): Internal.TagKey<any>;
        onWearerUse(stack: Internal.ItemStack_, world: Internal.Level_, user: Internal.Player_, hand: Internal.InteractionHand_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        addModifierTooltip(stack: Internal.ItemStack_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_, type: Internal.ModifierHelperType_<any>): void;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        fzzy_core_correctSlot(slot: Internal.EquipmentSlot_): boolean;
        getCreativeTab(): string;
        postWearerHit(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        modifierObjectPredicate(livingEntity: Internal.LivingEntity_, stack: Internal.ItemStack_): ResourceLocation;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        kjs$getAttributeMap(): Internal.Multimap<any, any>;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        kjs$getMutableAttributeMap(): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        useOn(context: Internal.UseOnContext_): Internal.InteractionResult;
        fzzy_core_getCorrectSlot(): Internal.EquipmentSlot;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        onWearerKilledOther(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, victim: Internal.LivingEntity_, world: Internal.ServerLevel_): void;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        static createTillAndDropAction(result: Internal.BlockState_, droppedItem: Internal.ItemLike_): Internal.Consumer<Internal.UseOnContext>;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        static canTillFarmland(context: Internal.UseOnContext_): boolean;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        canBeModifiedBy(type: Internal.ModifierHelperType_<any>): boolean;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        getAttackDamage(): number;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        incrementKillCount(stack: Internal.ItemStack_): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        defaultModifiers(type: Internal.ModifierHelperType_<any>): Internal.List<any>;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        static createTillAction(result: Internal.BlockState_): Internal.Consumer<Internal.UseOnContext>;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        getTier(): Internal.Tier;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getKillCount(stack: Internal.ItemStack_): number;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        postWearerMine(stack: Internal.ItemStack_, world: Internal.Level_, state: Internal.BlockState_, pos: BlockPos_, miner: Internal.Player_): void;
        kjs$setAttributeMap(arg0: Internal.Multimap_<any, any>): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        get attackDamage(): number
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        get tier(): Internal.Tier
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type BasicHoeItem_ = BasicHoeItem;
    class TidesingerCoralRecipe implements Internal.SmithingRecipe {
        constructor(base: Internal.Ingredient_, addition: Internal.Ingredient_, template: Internal.Ingredient_, result: Internal.ItemStack_, id: ResourceLocation_)
        getClass(): typeof any;
        getGroup(): string;
        getToastSymbol(): Internal.ItemStack;
        getSchema(): Internal.RecipeSchema;
        isBaseIngredient(stack: Internal.ItemStack_): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getSerializer(): Internal.RecipeSerializer<any>;
        assemble(inventory: net.minecraft.world.Container_, registryManager: Internal.RegistryAccess_): Internal.ItemStack;
        getId(): ResourceLocation;
        matches(inventory: net.minecraft.world.Container_, world: Internal.Level_): boolean;
        getMod(): string;
        isIn(tag: ResourceLocation_): boolean;
        getRemainingItems($$0: net.minecraft.world.Container_): Internal.NonNullList<Internal.ItemStack>;
        getIngredients(): Internal.NonNullList<Internal.Ingredient>;
        handler$bpa000$bclib$bcl_getRemainingItems(container: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>): void;
        isSpecial(): boolean;
        hasOutput(match: Internal.ReplacementMatch_): boolean;
        getResultItem(registryManager: Internal.RegistryAccess_): Internal.ItemStack;
        toString(): string;
        notifyAll(): void;
        canCraftInDimensions($$0: number, $$1: number): boolean;
        showNotification(): boolean;
        replaceInput(match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): boolean;
        getType(): ResourceLocation;
        setGroup(group: string): void;
        isTemplateIngredient(stack: Internal.ItemStack_): boolean;
        hashCode(): number;
        "handler$fie000$fabric-item-api-v1$captureStack"(inventory: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>, defaultedList: Internal.NonNullList_<any>, i: number): void;
        getOrCreateId(): ResourceLocation;
        hasInput(match: Internal.ReplacementMatch_): boolean;
        wait(): void;
        isIncomplete(): boolean;
        wait(arg0: number): void;
        isAdditionIngredient(stack: Internal.ItemStack_): boolean;
        replaceOutput(match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): boolean;
        equals(arg0: any): boolean;
        get class(): typeof any
        get group(): string
        get toastSymbol(): Internal.ItemStack
        get schema(): Internal.RecipeSchema
        get serializer(): Internal.RecipeSerializer<any>
        get id(): ResourceLocation
        get mod(): string
        get ingredients(): Internal.NonNullList<Internal.Ingredient>
        get special(): boolean
        get type(): ResourceLocation
        set group(group: string)
        get orCreateId(): ResourceLocation
        get incomplete(): boolean
        readonly result: Internal.ItemStack;
        readonly addition: Internal.Ingredient;
        readonly template: Internal.Ingredient;
        readonly id: ResourceLocation;
        readonly base: Internal.Ingredient;
    }
    type TidesingerCoralRecipe_ = TidesingerCoralRecipe;
    class TreeAxeEnd extends Internal.TreeAxe {
        constructor(material: Internal.Tier_, attackDamage: number, attackSpeed: number, settings: Internal.Item$Properties_)
        onTick(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        bclib_getBlockTag(): Internal.TagKey<any>;
        onWearerUse(stack: Internal.ItemStack_, world: Internal.Level_, user: Internal.Player_, hand: Internal.InteractionHand_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        static "setStrippedBlocks$fabric-content-registries-v0_$md$424943$2"(arg0: Internal.Map_<any, any>): void;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        addModifierTooltip(stack: Internal.ItemStack_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_, type: Internal.ModifierHelperType_<any>): void;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy(stack: Internal.ItemStack_, world: Internal.Level_, player: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(itemStack: Internal.ItemStack_, world: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, tooltipContext: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        static setStrippedBlocks(strippedBlocks: Internal.Map_<Internal.Block, Internal.Block>): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        porting_lib$getStripped(arg0: Internal.BlockState_): Optional<any>;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        fzzy_core_correctSlot(slot: Internal.EquipmentSlot_): boolean;
        getCreativeTab(): string;
        postWearerHit(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        modifierObjectPredicate(livingEntity: Internal.LivingEntity_, stack: Internal.ItemStack_): ResourceLocation;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        static getStrippedBlocks(): Internal.Map<Internal.Block, Internal.Block>;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        kjs$getAttributeMap(): Internal.Multimap<any, any>;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        kjs$getMutableAttributeMap(): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        useOn(context: Internal.UseOnContext_): Internal.InteractionResult;
        fzzy_core_getCorrectSlot(): Internal.EquipmentSlot;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(world: Internal.Level_, player: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        onWearerKilledOther(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, victim: Internal.LivingEntity_, world: Internal.ServerLevel_): void;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        static "getStrippedBlocks$fabric-content-registries-v0_$md$424943$1"(): Internal.Map<any, any>;
        static processList(world: Internal.Level_, player: Internal.Player_): void;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        invokeGetStrippedState(arg0: Internal.BlockState_): Optional<any>;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        canBeModifiedBy(type: Internal.ModifierHelperType_<any>): boolean;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        getAttackDamage(): number;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        incrementKillCount(stack: Internal.ItemStack_): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        static calcRay(worldIn: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        setAttackSpeed(attackSpeed: number): void;
        static attemptBreakNeighbors(world: Internal.Level_, pos: BlockPos_, player: Internal.Player_, checkHarvestLevel: boolean): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        defaultModifiers(type: Internal.ModifierHelperType_<any>): Internal.List<any>;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        port_lib$canPerformAction(stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): boolean;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        static attemptBreak(world: Internal.Level_, pos: BlockPos_, player: Internal.Player_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        getTier(): Internal.Tier;
        mineBlock(stack: Internal.ItemStack_, world: Internal.Level_, state: Internal.BlockState_, pos: BlockPos_, entity: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        static getStrippedBlocks$amethyst_imbuement_$md$424943$0(): Internal.Map<any, any>;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getKillCount(stack: Internal.ItemStack_): number;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        postWearerMine(stack: Internal.ItemStack_, world: Internal.Level_, state: Internal.BlockState_, pos: BlockPos_, miner: Internal.Player_): void;
        kjs$setAttributeMap(arg0: Internal.Multimap_<any, any>): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        set "strippedBlocks$fabric-content-registries-v0_$md$424943$2"(arg0: Internal.Map_<any, any>)
        get fireResistant(): boolean
        get complex(): boolean
        set strippedBlocks(strippedBlocks: Internal.Map_<Internal.Block, Internal.Block>)
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get strippedBlocks(): Internal.Map<Internal.Block, Internal.Block>
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get "strippedBlocks$fabric-content-registries-v0_$md$424943$1"(): Internal.Map<any, any>
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        get attackDamage(): number
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        get tier(): Internal.Tier
        set nameKey(arg0: string)
        get strippedBlocks$amethyst_imbuement_$md$424943$0(): Internal.Map<any, any>
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type TreeAxeEnd_ = TreeAxeEnd;
    class IllnessFortune extends Internal.Fortune {
        constructor(positive: boolean)
        tick(world: Internal.ServerLevel_, target: Internal.Player_): boolean;
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        finish(world: Internal.ServerLevel_, target: Internal.Player_): boolean;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
    }
    type IllnessFortune_ = IllnessFortune;
    class ProtoChunkTicks <T> implements Internal.TickContainerAccess<T>, Internal.SerializableTickContainer<T>, Internal.ISimpleTickScheduler<any> {
        constructor()
        getClass(): typeof any;
        count(): number;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        scheduledTicks(): Internal.List<Internal.SavedTick<T>>;
        hashCode(): number;
        static load<T>($$0: Internal.ListTag_, $$1: Internal.Function_<string, Optional<T>>, $$2: Internal.ChunkPos_): Internal.ProtoChunkTicks<T>;
        schedule($$0: Internal.ScheduledTick_<T>): void;
        wait(): void;
        wait(arg0: number): void;
        getScheduledTicks(): Internal.List<any>;
        hasScheduledTick($$0: BlockPos_, $$1: T): boolean;
        equals(arg0: any): boolean;
        save($$0: number, $$1: Internal.Function_<T, string>): Internal.Tag;
        get class(): typeof any
        get scheduledTicks(): Internal.List<any>
    }
    type ProtoChunkTicks_<T> = ProtoChunkTicks<T>;
    class GameRules$Category extends Internal.Enum<Internal.GameRules$Category> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        "compareTo(net.minecraft.world.level.GameRules$Category)"(arg0: Internal.GameRules$Category_): number;
        toString(): string;
        static valueOf($$0: string): Internal.GameRules$Category;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        name(): string;
        getDeclaringClass(): typeof Internal.GameRules$Category;
        hashCode(): number;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.GameRules$Category>>;
        getDescriptionId(): string;
        static values(): Internal.GameRules$Category[];
        compareTo(arg0: Internal.GameRules$Category_): number;
        get class(): typeof any
        get declaringClass(): typeof Internal.GameRules$Category
        get descriptionId(): string
        static readonly CHAT: (Internal.GameRules$Category) & (Internal.GameRules$Category);
        static readonly MISC: (Internal.GameRules$Category) & (Internal.GameRules$Category);
        static readonly DROPS: (Internal.GameRules$Category) & (Internal.GameRules$Category);
        static readonly UPDATES: (Internal.GameRules$Category) & (Internal.GameRules$Category);
        static readonly PLAYER: (Internal.GameRules$Category) & (Internal.GameRules$Category);
        static readonly MOBS: (Internal.GameRules$Category) & (Internal.GameRules$Category);
        static readonly SPAWNING: (Internal.GameRules$Category) & (Internal.GameRules$Category);
    }
    type GameRules$Category_ = "chat" | "updates" | "misc" | "drops" | "player" | "mobs" | "spawning" | GameRules$Category;
    class StrongNBTFilterItem extends Internal.StringValueFilterItem {
        constructor()
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, world: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, flag: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getDisplayItemStacks(filter: Internal.ItemStack_, list: Internal.List_<Internal.ItemStack>): void;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        setValue(filter: Internal.ItemStack_, v: string): void;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        getValue(filter: Internal.ItemStack_): string;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(world: Internal.Level_, player: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        filterItem(filter: Internal.ItemStack_, item: Internal.Item_): boolean;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        getValueVariants(stack: Internal.ItemStack_): Internal.Collection<Internal.StringValueFilterVariant>;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        addInfo(filter: Internal.ItemStack_, info: Internal.FilterInfo_, expanded: boolean): void;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        resetFilterData(filter: Internal.ItemStack_): void;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        filter(filter: Internal.ItemStack_, stack: Internal.ItemStack_): boolean;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        createData(stack: Internal.ItemStack_): Internal.StringValueData<any>;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        getHelpKey(): string;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getStringValueData<T extends Internal.StringValueData<any>>(filter: Internal.ItemStack_): T;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick(stack: Internal.ItemStack_, level: Internal.Level_, entity: Internal.Entity_, i: number, bl: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        clearFilterCache(filter: Internal.ItemStack_): void;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        get helpKey(): string
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type StrongNBTFilterItem_ = StrongNBTFilterItem;
    class UniversalAttractorItem extends Internal.WearableArtifactItem {
        constructor()
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        static setActivated(stack: Internal.ItemStack_, active: boolean): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        static isActivated(stack: Internal.ItemStack_): boolean;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, world: Internal.Level_, tooltipList: Internal.List_<net.minecraft.network.chat.Component>, flags: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        isOnCooldown(entity: Internal.LivingEntity_): boolean;
        addCooldown(entity: Internal.LivingEntity_, ticks: number): void;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        getFortuneLevel(): number;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        wornTick(entity: Internal.LivingEntity_, stack: Internal.ItemStack_): void;
        getLootingLevel(): number;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        makesPiglinsNeutral(): boolean;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        onUnequip(entity: Internal.LivingEntity_, stack: Internal.ItemStack_): void;
        isEquippedBy(entity: Internal.LivingEntity_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        toggleItem(player: Internal.ServerPlayer_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        addAttributeModifier(attributeModifier: Internal.ArtifactAttributeModifier_): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        getEquipSound(): Internal.SoundEvent;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canWalkOnPowderedSnow(): boolean;
        use(level: Internal.Level_, user: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<any>;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        getAttributeModifiers(): Internal.List<Internal.ArtifactAttributeModifier>;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        hasNonCosmeticEffects(): boolean;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        findAllEquippedBy(entity: Internal.LivingEntity_): Internal.Stream<Internal.ItemStack>;
        isCosmetic(): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        onEquip(entity: Internal.LivingEntity_, stack: Internal.ItemStack_): void;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe(slotStack: Internal.ItemStack_, holdingStack: Internal.ItemStack_, slot: Internal.Slot_, clickAction: Internal.ClickAction_, player: Internal.Player_, slotAccess: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        get fortuneLevel(): number
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        get lootingLevel(): number
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get equipSound(): Internal.SoundEvent
        get maxStackSize(): number
        get attributeModifiers(): Internal.List<Internal.ArtifactAttributeModifier>
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get cosmetic(): boolean
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type UniversalAttractorItem_ = UniversalAttractorItem;
    interface MouseDrag {
        newStream(): Internal.EventStream<Internal.MouseDrag>;
        abstract onMouseDrag(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number): boolean;
        (arg0: number, arg1: number, arg2: number, arg3: number, arg4: number): boolean;
    }
    type MouseDrag_ = MouseDrag | ((arg0: number, arg1: number, arg2: number, arg3: number, arg4: number)=> boolean);
    interface IExtendedGuiGraphics {
        abstract setCurrentTooltipStack(arg0: Internal.ItemStack_): void;
        abstract getCurrentTooltipStack(): Internal.ItemStack;
        set currentTooltipStack(arg0: Internal.ItemStack_)
        get currentTooltipStack(): Internal.ItemStack
    }
    type IExtendedGuiGraphics_ = IExtendedGuiGraphics;
    class BaseBrewItem extends Internal.Item implements Internal.BrewItem, Internal.CustomCreativeTabContents {
        constructor(builder: Internal.Item$Properties_, swigs: number, drinkSpeed: number, baseItem: Internal.Supplier_<Internal.Item>)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        getSwigs(): number;
        setSwigsLeft(stack: Internal.ItemStack_, swigs: number): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, world: Internal.Level_, list: Internal.List_<net.minecraft.network.chat.Component>, flags: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getUseAnimation(stack: Internal.ItemStack_): Internal.UseAnim;
        getDescriptionId(): string;
        getBrew(stack: Internal.ItemStack_): Internal.Brew;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        static "setBrew(net.minecraft.world.item.ItemStack,vazkii.botania.api.brew.Brew)"(stack: Internal.ItemStack_, brew: Internal.Brew_): void;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        static setBrew(stack: Internal.ItemStack_, brew: ResourceLocation_): void;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        static setBrew(stack: Internal.ItemStack_, brew: Internal.Brew_): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getSubtype(stack: Internal.ItemStack_): string;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(world: Internal.Level_, player: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        getBaseStack(): Internal.ItemStack;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        static addPotionTooltip(list: Internal.List_<Internal.MobEffectInstance>, lores: Internal.List_<net.minecraft.network.chat.Component>, durationFactor: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration(stack: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        getSwigsLeft(stack: Internal.ItemStack_): number;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem(stack: Internal.ItemStack_, world: Internal.Level_, living: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        static "setBrew(net.minecraft.world.item.ItemStack,net.minecraft.resources.ResourceLocation)"(stack: Internal.ItemStack_, brew: ResourceLocation_): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName(stack: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        addToCreativeTab(me: Internal.Item_, output: Internal.CreativeModeTab$Output_): void;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get swigs(): number
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        get baseStack(): Internal.ItemStack
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type BaseBrewItem_ = BaseBrewItem;
    interface PlacementModifierType <P extends Internal.PlacementModifier> {
        abstract codec(): Internal.Codec<P>;
        (): Internal.Codec_<P>;
        readonly SURFACE_RELATIVE_THRESHOLD_FILTER: Internal.PlacementModifierType<Internal.SurfaceRelativeThresholdFilter>;
        readonly IN_SQUARE: Internal.PlacementModifierType<Internal.InSquarePlacement>;
        readonly HEIGHTMAP: Internal.PlacementModifierType<Internal.HeightmapPlacement>;
        readonly HEIGHT_RANGE: Internal.PlacementModifierType<Internal.HeightRangePlacement>;
        readonly BIOME_FILTER: Internal.PlacementModifierType<net.minecraft.world.level.levelgen.placement.BiomeFilter>;
        readonly RANDOM_OFFSET: Internal.PlacementModifierType<Internal.RandomOffsetPlacement>;
        readonly BLOCK_PREDICATE_FILTER: Internal.PlacementModifierType<Internal.BlockPredicateFilter>;
        readonly CARVING_MASK_PLACEMENT: Internal.PlacementModifierType<Internal.CarvingMaskPlacement>;
        readonly NOISE_BASED_COUNT: Internal.PlacementModifierType<Internal.NoiseBasedCountPlacement>;
        readonly ENVIRONMENT_SCAN: Internal.PlacementModifierType<Internal.EnvironmentScanPlacement>;
        readonly SURFACE_WATER_DEPTH_FILTER: Internal.PlacementModifierType<Internal.SurfaceWaterDepthFilter>;
        readonly COUNT_ON_EVERY_LAYER: Internal.PlacementModifierType<Internal.CountOnEveryLayerPlacement>;
        readonly COUNT: Internal.PlacementModifierType<Internal.CountPlacement>;
        readonly NOISE_THRESHOLD_COUNT: Internal.PlacementModifierType<Internal.NoiseThresholdCountPlacement>;
        readonly RARITY_FILTER: Internal.PlacementModifierType<Internal.RarityFilter>;
    }
    type PlacementModifierType_<P extends Internal.PlacementModifier> = (()=> Internal.Codec_<P>) | PlacementModifierType<P> | Special.PlacementModifierType;
    class FoodProvider {
        getClass(): typeof any;
        consume(player: Internal.Player_, world: Internal.Level_, nbtApplier: Internal.Consumer_<Internal.ItemStack>): boolean;
        toString(): string;
        notifyAll(): void;
        isEmpty(): boolean;
        getDivider(): number;
        getFood(): Internal.Item;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        static create(item: Internal.Item_, divider: number): Internal.FoodProvider;
        wait(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        get class(): typeof any
        get empty(): boolean
        get divider(): number
        get food(): Internal.Item
        static readonly CUSTOM_PROVIDERS: ({[key: Internal.SuspiciousStewItem]: any, [key: Internal.MilkBucketItem]: any, [key: Internal.AirItem]: Internal.FoodProvider, [key: Internal.ExperienceBottleItem]: any}) & (Internal.Map<Internal.Item, Internal.FoodProvider>);
        static readonly CODEC: Internal.Codec<Internal.FoodProvider>;
        static readonly EMPTY: (Internal.FoodProvider) & (Internal.FoodProvider);
    }
    type FoodProvider_ = FoodProvider;
    class MutableObject <T> implements Internal.Mutable<T>, Internal.Serializable {
        constructor()
        constructor(arg0: T)
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        setValue(arg0: T): void;
        wait(): void;
        getValue(): T;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        set value(arg0: T)
        get value(): T
    }
    type MutableObject_<T> = MutableObject<T>;
    interface LongToDoubleFunction {
        abstract applyAsDouble(arg0: number): number;
        (arg0: number): number;
    }
    type LongToDoubleFunction_ = ((arg0: number)=> number) | LongToDoubleFunction;
    interface Object2FloatMap$Entry <K> extends Internal.Map$Entry<K, number> {
        abstract getKey(): K;
        abstract setValue(arg0: number): number;
        /**
         * @deprecated
        */
        setValue(arg0: number): number;
        comparingByKey<K, V>(arg0: Comparator_<K>): Comparator<Internal.Map$Entry<K, V>>;
        abstract "setValue(float)"(arg0: number): number;
        /**
         * @deprecated
        */
        setValue(arg0: any): any;
        /**
         * @deprecated
        */
        getValue(): any;
        comparingByValue<K, V extends Internal.Comparable<any>>(): Comparator<Internal.Map$Entry<K, V>>;
        /**
         * @deprecated
        */
        "setValue(java.lang.Float)"(arg0: number): number;
        abstract hashCode(): number;
        copyOf<K, V>(arg0: Internal.Map$Entry_<K, V>): Internal.Map$Entry<K, V>;
        comparingByKey<K extends Internal.Comparable<any>, V>(): Comparator<Internal.Map$Entry<K, V>>;
        /**
         * @deprecated
        */
        "setValue(java.lang.Object)"(arg0: any): any;
        comparingByValue<K, V>(arg0: Comparator_<V>): Comparator<Internal.Map$Entry<K, V>>;
        abstract equals(arg0: any): boolean;
        abstract getFloatValue(): number;
        get key(): K
        set value(arg0: number)
        /**
         * @deprecated
        */
        set value(arg0: number)
        set "value(float)"(arg0: number)
        /**
         * @deprecated
        */
        set value(arg0: any)
        /**
         * @deprecated
        */
        get value(): any
        /**
         * @deprecated
        */
        set "value(java.lang.Float)"(arg0: number)
        /**
         * @deprecated
        */
        set "value(java.lang.Object)"(arg0: any)
        get floatValue(): number
    }
    type Object2FloatMap$Entry_<K> = Object2FloatMap$Entry<K>;
    class EnderPackItem extends Internal.Item {
        constructor(settings: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(itemStack: Internal.ItemStack_, world: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, tooltipContext: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(world: Internal.Level_, player: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
        static readonly TITLE: (Internal.MutableComponent) & (net.minecraft.network.chat.Component);
    }
    type EnderPackItem_ = EnderPackItem;
    class ItemTome extends Internal.Item {
        constructor()
        constructor(userEffect: Internal.TomeEffect_<Internal.Player, Internal.InteractionResultHolder<Internal.ItemStack>>, entityEffect: Internal.TomeEffect_<Internal.Entity, Internal.InteractionResult>, blockEffect: Internal.TomeEffect_<BlockPos, Internal.InteractionResult>)
        constructor(userEffect: Internal.TomeEffect_<Internal.Player, Internal.InteractionResultHolder<Internal.ItemStack>>, entityEffect: Internal.TomeEffect_<Internal.Entity, Internal.InteractionResult>, blockEffect: Internal.TomeEffect_<BlockPos, Internal.InteractionResult>, properties: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        withEntityEffect(entityEffect: Internal.TomeEffect_<Internal.Entity, Internal.InteractionResult>): this;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity(stack: Internal.ItemStack_, user: Internal.Player_, target: Internal.LivingEntity_, hand: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn(context: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(world: Internal.Level_, player: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        withUserEffect(userEffect: Internal.TomeEffect_<Internal.Player, Internal.InteractionResultHolder<Internal.ItemStack>>): this;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        withBlockEffect(blockEffect: Internal.TomeEffect_<BlockPos, Internal.InteractionResult>): this;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type ItemTome_ = ItemTome;
    class InlineStyle$ISComponent <C> extends Internal.Record {
        constructor(id: string, codec: Internal.Codec_<C>, defaultValue: C)
        constructor(id: string, codec: Internal.Codec_<C>, defaultValue: C, merger: Internal.BiFunction_<C, C, C>)
        getClass(): typeof any;
        codec(): Internal.Codec<C>;
        merger(): Internal.BiFunction<C, C, C>;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        id(): string;
        defaultValue(): C;
        wait(): void;
        wait(arg0: number): void;
        equals(o: any): boolean;
        get class(): typeof any
        static ALL_COMPS: ({"glowy": Internal.InlineStyle$ISComponent<any>, "glowyparent": Internal.InlineStyle$ISComponent<any>, "inlinedata": Internal.InlineStyle$ISComponent<any>, "hidden": Internal.InlineStyle$ISComponent<any>, "size": Internal.InlineStyle$ISComponent<any>}) & (Internal.Map<string, Internal.InlineStyle$ISComponent<any>>);
    }
    type InlineStyle$ISComponent_<C> = InlineStyle$ISComponent<C>;
    class BSMObjects$1 extends Internal.BlockItem {
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        static setBlockEntityData($$0: Internal.ItemStack_, $$1: Internal.BlockEntityType_<any>, $$2: Internal.CompoundTag_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        abstract moonlight$addAdditionalBehavior(arg0: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy(stack: Internal.ItemStack_, world: Internal.Level_, player: Internal.Player_): void;
        isComplex(): boolean;
        modifyReturnValue$bkb000$axiom$canPlace(canPlace: boolean, blockPlaceContext: Internal.BlockPlaceContext_): boolean;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        abstract moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        handler$mpi000$tcdcommons$onPlace(context: Internal.BlockPlaceContext_, ci: Internal.CallbackInfoReturnable_<any>): void;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        abstract moonlight$setClientAnimationExtension(arg0: any): void;
        abstract moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        wrapOperation$bkb000$axiom$place$getPlacementState(instance: Internal.BlockItem_, blockPlaceContext: Internal.BlockPlaceContext_, original: Internal.Operation_<any>): Internal.BlockState;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        static getBlockEntityData($$0: Internal.ItemStack_): Internal.CompoundTag;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        removeFromBlockToItemMap(blockToItemMap: Internal.Map_<Internal.Block, Internal.Item>, itemIn: Internal.Item_): void;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        static updateCustomBlockEntityTag($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.ItemStack_): boolean;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        place($$0: Internal.BlockPlaceContext_): Internal.InteractionResult;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        getBlock(): Internal.Block;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        updatePlacementContext($$0: Internal.BlockPlaceContext_): Internal.BlockPlaceContext;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        registerBlocks($$0: Internal.Map_<Internal.Block, Internal.Item>, $$1: Internal.Item_): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        puzzleslib$setBlock(arg0: Internal.Block_): void;
        wrapOperation$bkb000$axiom$place$updatePlacementContext(instance: Internal.BlockItem_, blockPlaceContext: Internal.BlockPlaceContext_, original: Internal.Operation_<any>): Internal.BlockPlaceContext;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        get block(): Internal.Block
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type BSMObjects$1_ = BSMObjects$1;
    class StringConfig extends Internal.ConfigFromString<string> {
        constructor()
        constructor(p: Internal.Pattern_)
        compareTo(o: Internal.ConfigValue_<string>): number;
        onClicked(clicked: dev.ftb.mods.ftblibrary.ui.Widget_, button: Internal.MouseButton_, callback: Internal.ConfigCallback_): void;
        getTooltip(): string;
        notify(): void;
        compareTo(arg0: any): number;
        copy(value: string): string;
        "getColor(java.lang.Object)"(arg0: any): Internal.Color4I;
        init(group: Internal.ConfigGroup_, id: string, value: string, setter: Internal.Consumer_<string>, defaultValue: string): Internal.ConfigValue<string>;
        getStringForGUI(): net.minecraft.network.chat.Component;
        applyValue(): void;
        getValue(): string;
        "compareTo(dev.ftb.mods.ftblibrary.config.ConfigValue)"(o: Internal.ConfigValue_<string>): number;
        getStringFromValue(v: string): string;
        setNameKey(key: string): Internal.ConfigValue<string>;
        canScroll(): boolean;
        getColor(arg0: any): Internal.Color4I;
        getIcon(v: string): Internal.Icon;
        getDefaultValue(): string;
        setValue(value: string): void;
        wait(): void;
        getNameKey(): string;
        "compareTo(java.lang.Object)"(arg0: any): number;
        scrollValue(currentValue: string, forward: boolean): Optional<string>;
        setCanEdit(e: boolean): Internal.ConfigValue<string>;
        setIcon(i: Internal.Icon_): Internal.ConfigValue<string>;
        getClass(): typeof any;
        addInfo(list: Internal.TooltipList_): void;
        wait(arg0: number, arg1: number): void;
        setOrder(o: number): Internal.ConfigValue<string>;
        setDefaultValue(defaultValue: string): void;
        getIcon(): Internal.Icon;
        getName(): string;
        getGroup(): Internal.ConfigGroup;
        getStringForGUI(arg0: any): net.minecraft.network.chat.Component;
        getColor(): Internal.Color4I;
        "getStringForGUI(java.lang.Object)"(arg0: any): net.minecraft.network.chat.Component;
        getPath(): string;
        setCurrentValue(v: string): boolean;
        parse(callback: Internal.Consumer_<string>, string: string): boolean;
        toString(): string;
        isEqual(v1: string, v2: string): boolean;
        notifyAll(): void;
        static info(key: string, value: any): net.minecraft.network.chat.Component;
        getColor(v: string): Internal.Color4I;
        hashCode(): number;
        getStringForGUI(v: string): net.minecraft.network.chat.Component;
        "getStringForGUI(java.lang.String)"(v: string): net.minecraft.network.chat.Component;
        wait(arg0: number): void;
        getCanEdit(): boolean;
        "getColor(java.lang.String)"(v: string): Internal.Color4I;
        equals(arg0: any): boolean;
        get tooltip(): string
        get stringForGUI(): net.minecraft.network.chat.Component
        get value(): string
        set nameKey(key: string)
        get defaultValue(): string
        set value(value: string)
        get nameKey(): string
        set canEdit(e: boolean)
        set icon(i: Internal.Icon_)
        get class(): typeof any
        set order(o: number)
        set defaultValue(defaultValue: string)
        get icon(): Internal.Icon
        get name(): string
        get group(): Internal.ConfigGroup
        get color(): Internal.Color4I
        get path(): string
        set currentValue(v: string)
        get canEdit(): boolean
        static readonly COLOR: (Internal.Color4I) & (Internal.Color4I);
        readonly pattern: Internal.Pattern;
    }
    type StringConfig_ = StringConfig;
    class HolderSet$Direct <T> extends Internal.HolderSet$ListBacked<T> {
        getClass(): typeof any;
        unwrapKey(): Optional<Internal.TagKey<T>>;
        /**
         * @deprecated
        */
        static emptyNamed<T>($$0: Internal.HolderOwner_<T>, $$1: Internal.TagKey_<T>): Internal.HolderSet$Named<T>;
        static "direct(java.util.function.Function,java.util.List)"<E, T>($$0: Internal.Function_<E, Internal.Holder<T>>, $$1: Internal.List_<E>): Internal.HolderSet$Direct<T>;
        notify(): void;
        stream(): Internal.Stream<Internal.Holder<T>>;
        wait(arg0: number, arg1: number): void;
        static "direct(net.minecraft.core.Holder[])"<T>(...$$0: Internal.Holder_<T>[]): Internal.HolderSet$Direct<T>;
        contains($$0: Internal.Holder_<T>): boolean;
        static direct<T>(...$$0: Internal.Holder_<T>[]): Internal.HolderSet$Direct<T>;
        getRandomElement($$0: Internal.RandomSource_): Optional<Internal.Holder<T>>;
        unwrap(): Internal.Either<Internal.TagKey<T>, Internal.List<Internal.Holder<T>>>;
        iterator(): Internal.Iterator<Internal.Holder<T>>;
        toString(): string;
        get($$0: number): Internal.Holder<T>;
        notifyAll(): void;
        spliterator(): Internal.Spliterator<Internal.Holder<T>>;
        static "direct(java.util.function.Function,java.lang.Object[])"<E, T>($$0: Internal.Function_<E, Internal.Holder<T>>, ...$$1: E[]): Internal.HolderSet$Direct<T>;
        canSerializeIn($$0: Internal.HolderOwner_<T>): boolean;
        size(): number;
        static direct<E, T>($$0: Internal.Function_<E, Internal.Holder<T>>, ...$$1: E[]): Internal.HolderSet$Direct<T>;
        hashCode(): number;
        forEach(arg0: Internal.Consumer_<Internal.Holder<T>>): void;
        static direct<T>($$0: Internal.List_<Internal.Holder<T>>): Internal.HolderSet$Direct<T>;
        wait(): void;
        wait(arg0: number): void;
        static "direct(java.util.List)"<T>($$0: Internal.List_<Internal.Holder<T>>): Internal.HolderSet$Direct<T>;
        static direct<E, T>($$0: Internal.Function_<E, Internal.Holder<T>>, $$1: Internal.List_<E>): Internal.HolderSet$Direct<T>;
        equals(arg0: any): boolean;
        get class(): typeof any
    }
    type HolderSet$Direct_<T> = HolderSet$Direct<T>;
    interface RecipeHolder {
        setRecipeUsed($$0: Internal.Level_, $$1: Internal.ServerPlayer_, $$2: Internal.Recipe_<any>): boolean;
        abstract getRecipeUsed(): Internal.Recipe<any>;
        abstract setRecipeUsed(arg0: Internal.Recipe_<any>): void;
        awardUsedRecipes($$0: Internal.Player_, $$1: Internal.List_<Internal.ItemStack>): void;
        get recipeUsed(): Internal.Recipe<any>
        set recipeUsed(arg0: Internal.Recipe_<any>)
    }
    type RecipeHolder_ = RecipeHolder;
    class SusRecipe$Serializer implements Internal.RecipeSerializer<Internal.SusRecipe> {
        constructor()
        getClass(): typeof any;
        "fromNetwork(net.minecraft.resources.ResourceLocation,net.minecraft.network.FriendlyByteBuf)"(arg0: ResourceLocation_, arg1: Internal.FriendlyByteBuf_): Internal.Recipe<any>;
        toString(): string;
        "toNetwork(net.minecraft.network.FriendlyByteBuf,net.minecraft.world.item.crafting.Recipe)"(arg0: Internal.FriendlyByteBuf_, arg1: Internal.Recipe_<any>): void;
        fromJson(recipeId: ResourceLocation_, json: Internal.JsonObject_): Internal.SusRecipe;
        toNetwork(buffer: Internal.FriendlyByteBuf_, recipe: Internal.SusRecipe_): void;
        notifyAll(): void;
        "toNetwork(net.minecraft.network.FriendlyByteBuf,net.mehvahdjukaar.supplementaries.common.items.crafting.SusRecipe)"(buffer: Internal.FriendlyByteBuf_, recipe: Internal.SusRecipe_): void;
        toNetwork(arg0: Internal.FriendlyByteBuf_, arg1: Internal.Recipe_<any>): void;
        notify(): void;
        "fromJson(net.minecraft.resources.ResourceLocation,com.google.gson.JsonObject)"(arg0: ResourceLocation_, arg1: Internal.JsonObject_): Internal.Recipe<any>;
        fromNetwork(recipeId: ResourceLocation_, buffer: Internal.FriendlyByteBuf_): Internal.SusRecipe;
        wait(arg0: number, arg1: number): void;
        "fromNetwork(net.minecraft.resources.ResourceLocation,net.minecraft.network.FriendlyByteBuf)"(recipeId: ResourceLocation_, buffer: Internal.FriendlyByteBuf_): Internal.SusRecipe;
        static register<S extends Internal.RecipeSerializer<T>, T extends Internal.Recipe<any>>($$0: string, $$1: S): S;
        hashCode(): number;
        fromJson(arg0: ResourceLocation_, arg1: Internal.JsonObject_): Internal.Recipe<any>;
        wait(): void;
        wait(arg0: number): void;
        "fromJson(net.minecraft.resources.ResourceLocation,com.google.gson.JsonObject)"(recipeId: ResourceLocation_, json: Internal.JsonObject_): Internal.SusRecipe;
        equals(arg0: any): boolean;
        fromNetwork(arg0: ResourceLocation_, arg1: Internal.FriendlyByteBuf_): Internal.Recipe<any>;
        get class(): typeof any
    }
    type SusRecipe$Serializer_ = SusRecipe$Serializer;
    interface LogEventFactory extends Internal.LocationAwareLogEventFactory {
        abstract createEvent(loggerName: string, marker: org.apache.logging.log4j.Marker_, fqcn: string, level: org.apache.logging.log4j.Level_, data: Internal.Message_, properties: Internal.List_<org.apache.logging.log4j.core.config.Property>, t: Internal.Throwable_): Internal.LogEvent;
        createEvent(loggerName: string, marker: org.apache.logging.log4j.Marker_, fqcn: string, location: Internal.StackTraceElement_, level: org.apache.logging.log4j.Level_, data: Internal.Message_, properties: Internal.List_<org.apache.logging.log4j.core.config.Property>, t: Internal.Throwable_): Internal.LogEvent;
        (loggerName: string, marker: org.apache.logging.log4j.Marker, fqcn: string, level: org.apache.logging.log4j.Level, data: Internal.Message, properties: Internal.List<org.apache.logging.log4j.core.config.Property>, t: Internal.Throwable): Internal.LogEvent_;
    }
    type LogEventFactory_ = ((loggerName: string, marker: org.apache.logging.log4j.Marker, fqcn: string, level: org.apache.logging.log4j.Level, data: Internal.Message, properties: Internal.List<org.apache.logging.log4j.core.config.Property>, t: Internal.Throwable)=> Internal.LogEvent_) | LogEventFactory;
    interface AccessorPlayer {
        abstract darkutils$setSleepTimer(arg0: number): void;
        abstract darkutils$setEnchantmentSeed(arg0: number): void;
    }
    type AccessorPlayer_ = AccessorPlayer;
    interface IChunkStatus {
        abstract calculateReducedTaskRadius(): void;
        abstract getReducedTaskRadius(): number;
        get reducedTaskRadius(): number
    }
    type IChunkStatus_ = IChunkStatus;
    interface ModifyLootAction$Callback {
        abstract modify(arg0: Internal.ItemStack_): Internal.ItemStack;
        (arg0: Internal.ItemStack): Internal.ItemStack_;
    }
    type ModifyLootAction$Callback_ = ((arg0: Internal.ItemStack)=> Internal.ItemStack_) | ModifyLootAction$Callback;
    class Float3ArgumentInfo$Template implements Internal.ArgumentTypeInfo$Template<Internal.Float3ArgumentType> {
        getClass(): typeof any;
        instantiate(arg0: Internal.CommandBuildContext_): Internal.ArgumentType<any>;
        "instantiate(net.minecraft.commands.CommandBuildContext)"(commandBuildContext: Internal.CommandBuildContext_): Internal.Float3ArgumentType;
        type(): Internal.ArgumentTypeInfo<Internal.Float3ArgumentType, any>;
        toString(): string;
        notifyAll(): void;
        instantiate(commandBuildContext: Internal.CommandBuildContext_): Internal.Float3ArgumentType;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        "instantiate(net.minecraft.commands.CommandBuildContext)"(arg0: Internal.CommandBuildContext_): Internal.ArgumentType<any>;
        equals(arg0: any): boolean;
        get class(): typeof any
    }
    type Float3ArgumentInfo$Template_ = Float3ArgumentInfo$Template;
    class AdvancementList {
        constructor()
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        add($$0: Internal.Map_<ResourceLocation, Internal.Advancement$Builder>): void;
        wait(arg0: number, arg1: number): void;
        get($$0: ResourceLocation_): Internal.Advancement;
        getAllAdvancements(): Internal.Collection<Internal.Advancement>;
        remove($$0: Internal.Set_<ResourceLocation>): void;
        hashCode(): number;
        setListener($$0: Internal.AdvancementList$Listener_): void;
        getRoots(): Internal.Iterable<Internal.Advancement>;
        wait(): void;
        clear(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        get class(): typeof any
        get allAdvancements(): Internal.Collection<Internal.Advancement>
        set listener($$0: Internal.AdvancementList$Listener_)
        get roots(): Internal.Iterable<Internal.Advancement>
    }
    type AdvancementList_ = AdvancementList;
    interface RefreshableSearchTree <T> extends Internal.SearchTree<T> {
        empty<T>(): this;
        abstract search(arg0: string): Internal.List<T>;
        refresh(): void;
        (arg0: string): Internal.List_<T>;
    }
    type RefreshableSearchTree_<T> = ((arg0: string)=> Internal.List_<T>) | RefreshableSearchTree<T>;
    abstract class Invokable <T, R> implements Internal.Member, Internal.AnnotatedElement {
        abstract isVarArgs(): boolean;
        "returning(com.google.common.reflect.TypeToken)"<R1 extends R>(arg0: Internal.TypeToken_<R1>): Internal.Invokable<T, R1>;
        getModifiers(): number;
        notify(): void;
        getAnnotation<A extends Internal.Annotation>(arg0: A): A;
        abstract isOverridable(): boolean;
        returning<R1 extends R>(arg0: Internal.TypeToken_<R1>): Internal.Invokable<T, R1>;
        isPublic(): boolean;
        trySetAccessible(): boolean;
        getParameters(): Internal.ImmutableList<Internal.Parameter>;
        static "from(java.lang.reflect.Constructor)"<T>(arg0: Internal.Constructor_<T>): Internal.Invokable<T, T>;
        isPackagePrivate(): boolean;
        getReturnType(): Internal.TypeToken<R>;
        wait(): void;
        isAccessible(): boolean;
        isFinal(): boolean;
        getClass(): typeof any;
        getOwnerType(): Internal.TypeToken<T>;
        getDeclaredAnnotationsByType<T extends Internal.Annotation>(arg0: T): T[];
        getDeclaringClass(): T;
        wait(arg0: number, arg1: number): void;
        abstract getAnnotatedReturnType(): Internal.AnnotatedType;
        "returning(java.lang.Class)"<R1 extends R>(arg0: R1): Internal.Invokable<T, R1>;
        getName(): string;
        isPrivate(): boolean;
        isStatic(): boolean;
        getDeclaredAnnotations(): Internal.Annotation[];
        isAnnotationPresent(arg0: typeof Internal.Annotation): boolean;
        static from(arg0: Internal.Method_): Internal.Invokable<any, any>;
        setAccessible(arg0: boolean): void;
        getAnnotationsByType<T extends Internal.Annotation>(arg0: T): T[];
        getDeclaredAnnotation<T extends Internal.Annotation>(arg0: T): T;
        toString(): string;
        isAbstract(): boolean;
        isNative(): boolean;
        notifyAll(): void;
        isSynthetic(): boolean;
        static from<T>(arg0: Internal.Constructor_<T>): Internal.Invokable<T, T>;
        isSynchronized(): boolean;
        getExceptionTypes(): Internal.ImmutableList<Internal.TypeToken<Internal.Throwable>>;
        invoke(arg0: T, ...arg1: any[]): R;
        hashCode(): number;
        static "from(java.lang.reflect.Method)"(arg0: Internal.Method_): Internal.Invokable<any, any>;
        isProtected(): boolean;
        wait(arg0: number): void;
        getAnnotations(): Internal.Annotation[];
        equals(arg0: any): boolean;
        abstract getTypeParameters(): any[];
        returning<R1 extends R>(arg0: R1): Internal.Invokable<T, R1>;
        get varArgs(): boolean
        get modifiers(): number
        get overridable(): boolean
        get "public"(): boolean
        get parameters(): Internal.ImmutableList<Internal.Parameter>
        get packagePrivate(): boolean
        get returnType(): Internal.TypeToken<R>
        get accessible(): boolean
        get "final"(): boolean
        get class(): typeof any
        get ownerType(): Internal.TypeToken<T>
        get declaringClass(): T
        get annotatedReturnType(): Internal.AnnotatedType
        get name(): string
        get "private"(): boolean
        get "static"(): boolean
        get declaredAnnotations(): Internal.Annotation[]
        set accessible(arg0: boolean)
        get "abstract"(): boolean
        get "native"(): boolean
        get synthetic(): boolean
        get "synchronized"(): boolean
        get exceptionTypes(): Internal.ImmutableList<Internal.TypeToken<Internal.Throwable>>
        get "protected"(): boolean
        get annotations(): Internal.Annotation[]
        get typeParameters(): any[]
    }
    type Invokable_<T, R> = Invokable<T, R>;
    class ReplaceSphereConfiguration implements Internal.FeatureConfiguration {
        constructor($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.IntProvider_)
        getClass(): typeof any;
        radius(): Internal.IntProvider;
        hashCode(): number;
        getFeatures(): Internal.Stream<Internal.ConfiguredFeature<any, any>>;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        get features(): Internal.Stream<Internal.ConfiguredFeature<any, any>>
        static readonly CODEC: Internal.Codec<Internal.ReplaceSphereConfiguration>;
        readonly targetState: Internal.BlockState;
        readonly replaceState: Internal.BlockState;
    }
    type ReplaceSphereConfiguration_ = ReplaceSphereConfiguration;
    class TreeShrubFeature extends Feature<Internal.RuTreeConfiguration> {
        constructor(codec: Internal.Codec_<Internal.RuTreeConfiguration>)
        placeRoot(level: Internal.LevelAccessor_, pos: BlockPos_, randomSource: Internal.RandomSource_, treeConfiguration: Internal.RuTreeConfiguration_): void;
        place(context: Internal.FeaturePlaceContext_<Internal.RuTreeConfiguration>): boolean;
        getClass(): typeof any;
        static isReplaceableDirtBlock(state: Internal.BlockState_): boolean;
        placeLeavesBlob(level: Internal.LevelAccessor_, pos: BlockPos_, randomSource: Internal.RandomSource_, treeConfiguration: Internal.RuTreeConfiguration_): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        checkReplaceable(level: Internal.LevelAccessor_, pos: BlockPos_): boolean;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        static isReplaceableBlock(state: Internal.BlockState_): boolean;
        static isDirt($$0: Internal.BlockState_): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        place($$0: Internal.RuTreeConfiguration_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        static isReplaceableDirt(reader: Internal.LevelSimulatedReader_, pos: BlockPos_): boolean;
        toString(): string;
        placeLeavesBlock(level: Internal.LevelAccessor_, pos: BlockPos_, randomSource: Internal.RandomSource_, treeConfiguration: Internal.RuTreeConfiguration_): boolean;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        placeLog(level: Internal.LevelAccessor_, pos: BlockPos_, randomSource: Internal.RandomSource_, treeConfiguration: Internal.RuTreeConfiguration_): boolean;
        hashCode(): number;
        static isReplaceable(reader: Internal.LevelSimulatedReader_, pos: BlockPos_): boolean;
        wait(): void;
        wait(arg0: number): void;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.RuTreeConfiguration, Feature<Internal.RuTreeConfiguration>>>;
        equals(arg0: any): boolean;
        get class(): typeof any
    }
    type TreeShrubFeature_ = TreeShrubFeature;
    class GrassSeedsItem extends Internal.Item implements Internal.FloatingFlowerVariant {
        constructor(type: Internal.FloatingFlower$IslandType_, props: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        static getColor(type: Internal.FloatingFlower$IslandType_): number;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn(ctx: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        static onTickEnd(world: Internal.ServerLevel_): void;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        static extractB(color: number): number;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        static extractR(color: number): number;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        static spawnParticles(world: Internal.Level_, pos: BlockPos_, r: number, g: number, b: number): void;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        applySeeds(world: Internal.Level_, pos: BlockPos_, stack: Internal.ItemStack_): Internal.InteractionResult;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        getIslandType(stack: Internal.ItemStack_): Internal.FloatingFlower$IslandType;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        static extractG(color: number): number;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type GrassSeedsItem_ = GrassSeedsItem;
    class TooltipBlockItem extends Internal.BlockItem {
        constructor(block: Internal.Block_, tooltip: net.minecraft.network.chat.Component_, properties: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        static setBlockEntityData($$0: Internal.ItemStack_, $$1: Internal.BlockEntityType_<any>, $$2: Internal.CompoundTag_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        abstract moonlight$addAdditionalBehavior(arg0: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        modifyReturnValue$bkb000$axiom$canPlace(canPlace: boolean, blockPlaceContext: Internal.BlockPlaceContext_): boolean;
        appendHoverText(stack: Internal.ItemStack_, level: Internal.Level_, tooltipComponents: Internal.List_<net.minecraft.network.chat.Component>, isAdvanced: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        abstract moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        handler$mpi000$tcdcommons$onPlace(context: Internal.BlockPlaceContext_, ci: Internal.CallbackInfoReturnable_<any>): void;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        abstract moonlight$setClientAnimationExtension(arg0: any): void;
        abstract moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        wrapOperation$bkb000$axiom$place$getPlacementState(instance: Internal.BlockItem_, blockPlaceContext: Internal.BlockPlaceContext_, original: Internal.Operation_<any>): Internal.BlockState;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        static getBlockEntityData($$0: Internal.ItemStack_): Internal.CompoundTag;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        removeFromBlockToItemMap(blockToItemMap: Internal.Map_<Internal.Block, Internal.Item>, itemIn: Internal.Item_): void;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        static updateCustomBlockEntityTag($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.ItemStack_): boolean;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        place($$0: Internal.BlockPlaceContext_): Internal.InteractionResult;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        getBlock(): Internal.Block;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        updatePlacementContext($$0: Internal.BlockPlaceContext_): Internal.BlockPlaceContext;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        registerBlocks($$0: Internal.Map_<Internal.Block, Internal.Item>, $$1: Internal.Item_): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        puzzleslib$setBlock(arg0: Internal.Block_): void;
        wrapOperation$bkb000$axiom$place$updatePlacementContext(instance: Internal.BlockItem_, blockPlaceContext: Internal.BlockPlaceContext_, original: Internal.Operation_<any>): Internal.BlockPlaceContext;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        get block(): Internal.Block
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type TooltipBlockItem_ = TooltipBlockItem;
    interface ManaPool extends Internal.ManaReceiver {
        abstract getMaxMana(): number;
        abstract getColor(): Optional<Internal.DyeColor>;
        abstract receiveMana(arg0: number): void;
        abstract isFull(): boolean;
        abstract getManaReceiverPos(): BlockPos;
        abstract setColor(arg0: Optional_<Internal.DyeColor>): void;
        abstract isOutputtingPower(): boolean;
        abstract getCurrentMana(): number;
        abstract canReceiveManaFromBursts(): boolean;
        abstract getManaReceiverLevel(): Internal.Level;
        get maxMana(): number
        get color(): Optional<Internal.DyeColor>
        get full(): boolean
        get manaReceiverPos(): BlockPos
        set color(arg0: Optional_<Internal.DyeColor>)
        get outputtingPower(): boolean
        get currentMana(): number
        get manaReceiverLevel(): Internal.Level
    }
    type ManaPool_ = ManaPool;
    class VariantBlockStateGenerator {
        constructor()
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        variant(key: string, consumer: Internal.Consumer_<Internal.VariantBlockStateGenerator$Variant>): void;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        simpleVariant(key: string, model: string): void;
        equals(arg0: any): boolean;
        notify(): void;
        toJson(): Internal.JsonObject;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
    }
    type VariantBlockStateGenerator_ = VariantBlockStateGenerator;
    class WDAGenericStructures extends Internal.Structure {
        constructor(config: Internal.Structure$StructureSettings_, startPool: Internal.Holder_<Internal.StructureTemplatePool>, startJigsawName: Optional_<ResourceLocation>, size: number, startHeight: Internal.HeightProvider_, projectStartToHeightmap: Optional_<Internal.Heightmap$Types>, maxDistanceFromCenter: number)
        static simpleCodec<S extends Internal.Structure>($$0: Internal.Function_<Internal.Structure$StructureSettings, S>): Internal.Codec<S>;
        getClass(): typeof any;
        generate($$0: Internal.RegistryAccess_, $$1: Internal.ChunkGenerator_, $$2: Internal.BiomeSource_, $$3: Internal.RandomState_, $$4: Internal.StructureTemplateManager_, $$5: number, $$6: Internal.ChunkPos_, $$7: number, $$8: Internal.LevelHeightAccessor_, $$9: Internal.Predicate_<Internal.Holder<Internal.Biome>>): Internal.StructureStart;
        toString(): string;
        biomes(): Internal.HolderSet<Internal.Biome>;
        findValidGenerationPoint($$0: Internal.Structure$GenerationContext_): Optional<Internal.Structure$GenerationStub>;
        spawnOverrides(): Internal.Map<Internal.MobCategory, Internal.StructureSpawnOverride>;
        step(): Internal.GenerationStep$Decoration;
        notifyAll(): void;
        notify(): void;
        terrainAdaptation(): Internal.TerrainAdjustment;
        wait(arg0: number, arg1: number): void;
        adjustBoundingBox($$0: Internal.BoundingBox_): Internal.BoundingBox;
        hashCode(): number;
        type(): Internal.StructureType<any>;
        static settingsCodec<S extends Internal.Structure>($$0: Internal.RecordCodecBuilder$Instance_<S>): Internal.RecordCodecBuilder<S, Internal.Structure$StructureSettings>;
        method_38676(context: Internal.Structure$GenerationContext_): Optional<Internal.Structure$GenerationStub>;
        structurify$setStructureIdentifier(structureSetIdentifier: ResourceLocation_): void;
        wait(): void;
        structurify$getStructureIdentifier(): ResourceLocation;
        wait(arg0: number): void;
        afterPlace($$0: Internal.WorldGenLevel_, $$1: Internal.StructureManager_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: Internal.BoundingBox_, $$5: Internal.ChunkPos_, $$6: Internal.PiecesContainer_): void;
        equals(arg0: any): boolean;
        setStructureBiomes(newBiomes: Internal.HolderSet_<any>): void;
        get class(): typeof any
        set tingsCodec($$0: Internal.RecordCodecBuilder$Instance_<S>)
        set structureBiomes(newBiomes: Internal.HolderSet_<any>)
        static readonly CODEC: Internal.Codec<Internal.WDAGenericStructures>;
    }
    type WDAGenericStructures_ = WDAGenericStructures;
    class RitualRecipe implements Internal.Recipe<net.minecraft.world.Container> {
        constructor(identifier: ResourceLocation_, input: Internal.NonNullList_<Internal.Ingredient>, inner: string, outer: string, ritualFunction: Internal.RitualFunction_, cost: number, runningTime: number)
        static matches(inv: net.minecraft.world.Container_, input: Internal.NonNullList_<Internal.Ingredient>): boolean;
        getClass(): typeof any;
        getGroup(): string;
        getToastSymbol(): Internal.ItemStack;
        getSchema(): Internal.RecipeSchema;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        static "matches(net.minecraft.world.Container,net.minecraft.core.NonNullList)"(inv: net.minecraft.world.Container_, input: Internal.NonNullList_<Internal.Ingredient>): boolean;
        getSerializer(): Internal.RecipeSerializer<any>;
        assemble(inventory: net.minecraft.world.Container_, registryManager: Internal.RegistryAccess_): Internal.ItemStack;
        getId(): ResourceLocation;
        matches(inv: net.minecraft.world.Container_, world: Internal.Level_): boolean;
        getMod(): string;
        isIn(tag: ResourceLocation_): boolean;
        getRemainingItems($$0: net.minecraft.world.Container_): Internal.NonNullList<Internal.ItemStack>;
        getIngredients(): Internal.NonNullList<Internal.Ingredient>;
        handler$bpa000$bclib$bcl_getRemainingItems(container: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>): void;
        isSpecial(): boolean;
        hasOutput(match: Internal.ReplacementMatch_): boolean;
        getResultItem(registryManager: Internal.RegistryAccess_): Internal.ItemStack;
        toString(): string;
        notifyAll(): void;
        canCraftInDimensions(width: number, height: number): boolean;
        "matches(net.minecraft.world.Container,net.minecraft.world.level.Level)"(inv: net.minecraft.world.Container_, world: Internal.Level_): boolean;
        showNotification(): boolean;
        replaceInput(match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): boolean;
        getType(): ResourceLocation;
        setGroup(group: string): void;
        "handler$fie000$fabric-item-api-v1$captureStack"(inventory: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>, defaultedList: Internal.NonNullList_<any>, i: number): void;
        hashCode(): number;
        getOrCreateId(): ResourceLocation;
        hasInput(match: Internal.ReplacementMatch_): boolean;
        wait(): void;
        isIncomplete(): boolean;
        wait(arg0: number): void;
        replaceOutput(match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): boolean;
        equals(arg0: any): boolean;
        get class(): typeof any
        get group(): string
        get toastSymbol(): Internal.ItemStack
        get schema(): Internal.RecipeSchema
        get serializer(): Internal.RecipeSerializer<any>
        get id(): ResourceLocation
        get mod(): string
        get ingredients(): Internal.NonNullList<Internal.Ingredient>
        get special(): boolean
        get type(): ResourceLocation
        set group(group: string)
        get orCreateId(): ResourceLocation
        get incomplete(): boolean
        readonly inner: string;
        readonly ritualFunction: Internal.RitualFunction;
        readonly outer: string;
        readonly runningTime: number;
        readonly input: Internal.NonNullList<Internal.Ingredient>;
        readonly cost: number;
    }
    type RitualRecipe_ = RitualRecipe;
    class Tristate extends Internal.Enum<Internal.Tristate> {
        static read(buffer: Internal.FriendlyByteBuf_): Internal.Tristate;
        getClass(): typeof any;
        static valueOf(name: string): Internal.Tristate;
        static read(nbt: Internal.CompoundTag_, key: string): Internal.Tristate;
        "compareTo(dev.ftb.mods.ftblibrary.config.Tristate)"(arg0: Internal.Tristate_): number;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        compareTo(arg0: Internal.Tristate_): number;
        get(def: boolean): boolean;
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        write(buffer: Internal.FriendlyByteBuf_): void;
        toString(): string;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.Tristate>>;
        isTrue(): boolean;
        notifyAll(): void;
        isFalse(): boolean;
        isDefault(): boolean;
        write(nbt: Internal.CompoundTag_, key: string): void;
        name(): string;
        hashCode(): number;
        ordinal(): number;
        wait(): void;
        static values(): Internal.Tristate[];
        wait(arg0: number): void;
        getOpposite(): this;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        getDeclaringClass(): typeof Internal.Tristate;
        get class(): typeof any
        get "true"(): boolean
        get "false"(): boolean
        get "default"(): boolean
        get opposite(): Internal.Tristate
        get declaringClass(): typeof Internal.Tristate
        static readonly VALUES: Internal.Tristate[];
        readonly name: string;
        static readonly FALSE: (Internal.Tristate) & (Internal.Tristate);
        static readonly DEFAULT: (Internal.Tristate) & (Internal.Tristate);
        readonly result: Internal.InteractionResult;
        readonly color: Internal.Color4I;
        readonly displayName: string;
        static readonly TRUE: (Internal.Tristate) & (Internal.Tristate);
        static readonly NAME_MAP: Internal.NameMap<Internal.Tristate>;
        readonly icon: Internal.Icon;
    }
    type Tristate_ = Tristate | "false" | "default" | "true";
    class RenderChunkRegion implements Internal.BlockAndTintGetter, Internal.RenderAttachedBlockView, Internal.RenderDataMapConsumer {
        getClass(): typeof any;
        getBlockTint($$0: BlockPos_, $$1: Internal.ColorResolver_): number;
        getMinSection(): number;
        getBlockState($$0: BlockPos_): Internal.BlockState;
        getShade($$0: Internal.Direction_, $$1: boolean): number;
        clipWithInteractionOverride($$0: Vec3d_, $$1: Vec3d_, $$2: BlockPos_, $$3: Internal.VoxelShape_, $$4: Internal.BlockState_): Internal.BlockHitResult;
        getSectionIndex($$0: number): number;
        getMaxSection(): number;
        getBrightness($$0: Internal.LightLayer_, $$1: BlockPos_): number;
        notify(): void;
        getMaxBuildHeight(): number;
        getBlockEntityRenderData(pos: BlockPos_): any;
        wait(arg0: number, arg1: number): void;
        getLightEmission($$0: BlockPos_): number;
        getBlockFloorHeight($$0: BlockPos_): number;
        getSectionYFromSectionIndex($$0: number): number;
        static create($$0: number, $$1: number): Internal.LevelHeightAccessor;
        "isOutsideBuildHeight(int)"($$0: number): boolean;
        clip($$0: Internal.ClipContext_): Internal.BlockHitResult;
        getLightEngine(): Internal.LevelLightEngine;
        getBlockFloorHeight($$0: Internal.VoxelShape_, $$1: Internal.Supplier_<Internal.VoxelShape>): number;
        getBlockEntity($$0: BlockPos_): Internal.BlockEntity;
        getHeight(): number;
        getRawBrightness($$0: BlockPos_, $$1: number): number;
        getBlockEntity<T extends Internal.BlockEntity>($$0: BlockPos_, $$1: Internal.BlockEntityType_<T>): Optional<T>;
        isOutsideBuildHeight($$0: BlockPos_): boolean;
        canSeeSky($$0: BlockPos_): boolean;
        toString(): string;
        isOutsideBuildHeight($$0: number): boolean;
        isBlockInLine($$0: Internal.ClipBlockStateContext_): Internal.BlockHitResult;
        getFluidState($$0: BlockPos_): Internal.FluidState;
        notifyAll(): void;
        "isOutsideBuildHeight(net.minecraft.core.BlockPos)"($$0: BlockPos_): boolean;
        /**
         * @deprecated
        */
        getBlockEntityRenderAttachment(pos: BlockPos_): any;
        getBlockStates($$0: Internal.AABB_): Internal.Stream<Internal.BlockState>;
        fabric_acceptRenderDataMap(renderDataMap: Internal.Long2ObjectMap_<any>): void;
        hashCode(): number;
        getMinBuildHeight(): number;
        getSectionsCount(): number;
        wait(): void;
        wait(arg0: number): void;
        hasBiomes(): boolean;
        getMaxLightLevel(): number;
        getSectionIndexFromSectionY($$0: number): number;
        getBiomeFabric(pos: BlockPos_): Internal.Holder<any>;
        equals(arg0: any): boolean;
        static traverseBlocks<T, C>($$0: Vec3d_, $$1: Vec3d_, $$2: C, $$3: Internal.BiFunction_<C, BlockPos, T>, $$4: Internal.Function_<C, T>): T;
        get class(): typeof any
        get minSection(): number
        get maxSection(): number
        get maxBuildHeight(): number
        get lightEngine(): Internal.LevelLightEngine
        get height(): number
        get minBuildHeight(): number
        get sectionsCount(): number
        get maxLightLevel(): number
    }
    type RenderChunkRegion_ = RenderChunkRegion;
    class LucisFeature extends Internal.ContextFeature<Internal.NoneFeatureConfiguration> implements Internal.UserGrowableFeature<Internal.NoneFeatureConfiguration> {
        constructor()
        getClass(): typeof any;
        grow(arg0: Internal.ServerLevelAccessor_, arg1: BlockPos_, arg2: Internal.RandomSource_, arg3: Internal.FeatureConfiguration_): boolean;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        "grow(net.minecraft.world.level.ServerLevelAccessor,net.minecraft.core.BlockPos,net.minecraft.util.RandomSource,net.minecraft.world.level.levelgen.feature.configurations.FeatureConfiguration)"(arg0: Internal.ServerLevelAccessor_, arg1: BlockPos_, arg2: Internal.RandomSource_, arg3: Internal.FeatureConfiguration_): boolean;
        place($$0: Internal.NoneFeatureConfiguration_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        place(ctx: Internal.FeaturePlaceContext_<Internal.NoneFeatureConfiguration>): boolean;
        grow(level: Internal.ServerLevelAccessor_, pos: BlockPos_, random: Internal.RandomSource_, configuration: Internal.NoneFeatureConfiguration_): boolean;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.NoneFeatureConfiguration, Feature<Internal.NoneFeatureConfiguration>>>;
        "grow(net.minecraft.world.level.ServerLevelAccessor,net.minecraft.core.BlockPos,net.minecraft.util.RandomSource,net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration)"(level: Internal.ServerLevelAccessor_, pos: BlockPos_, random: Internal.RandomSource_, configuration: Internal.NoneFeatureConfiguration_): boolean;
        get class(): typeof any
    }
    type LucisFeature_ = LucisFeature;
    interface SparkEntity {
        abstract getAttachPos(): BlockPos;
        abstract getNetwork(): Internal.DyeColor;
        entity(): Internal.Entity;
        abstract setNetwork(arg0: Internal.DyeColor_): void;
        get attachPos(): BlockPos
        get network(): Internal.DyeColor
        set network(arg0: Internal.DyeColor_)
    }
    type SparkEntity_ = SparkEntity;
    class BlockElementFace {
        constructor($$0: Internal.Direction_, $$1: number, $$2: string, $$3: Internal.BlockFaceUV_)
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        readonly texture: string;
        readonly tintIndex: number;
        readonly uv: Internal.BlockFaceUV;
        readonly cullForDirection: Internal.Direction;
        static readonly NO_TINT: (-1) & (number);
    }
    type BlockElementFace_ = BlockElementFace;
    interface ScreenRegistry extends Internal.Reloadable<Internal.REIClientPlugin> {
        acceptPlugin(plugin: Internal.REIClientPlugin_): void;
        abstract "registerDraggableStackVisitor(me.shedaniel.rei.api.client.gui.drag.DraggableStackVisitor)"<T extends Internal.Screen>(arg0: Internal.DraggableStackVisitor_<T>): void;
        abstract evaluateClickArea<T extends Internal.Screen>(arg0: T, arg1: Internal.ClickArea$ClickAreaContext_<T>): Internal.List<Internal.ClickArea$Result>;
        acceptPlugin(plugin: Internal.REIClientPlugin_, stage: Internal.ReloadStage_): void;
        afterReloadablePlugin(stage: Internal.ReloadStage_, other: Internal.Reloadable_<Internal.REIClientPlugin>, plugin: Internal.REIClientPlugin_): void;
        "registerDraggableComponentProvider(me.shedaniel.rei.api.client.gui.drag.component.DraggableComponentProviderWidget)"<T extends Internal.Screen, A>(provider: Internal.DraggableComponentProviderWidget_<A>): void;
        abstract registerDecider(arg0: Internal.OverlayDecider_): void;
        abstract registerDraggableStackVisitor<T extends Internal.Screen>(arg0: Internal.DraggableStackVisitor_<T>): void;
        registerDraggableStackProvider<T extends Internal.Screen>(priority: number, provider: Internal.DraggableStackProviderWidget_): void;
        isConcurrent(): boolean;
        abstract getScreenBounds<T extends Internal.Screen>(arg0: T): me.shedaniel.math.Rectangle;
        postStage(stage: Internal.ReloadStage_): void;
        abstract registerDraggableStackProvider<T extends Internal.Screen>(arg0: Internal.DraggableStackProvider_<T>): void;
        getClickAreaTooltips<T extends Internal.Screen>(screenClass: T, context: Internal.ClickArea$ClickAreaContext_<T>): Internal.List<net.minecraft.network.chat.Component>;
        abstract "registerDraggableComponentProvider(me.shedaniel.rei.api.client.gui.drag.component.DraggableComponentProvider)"<T extends Internal.Screen, A>(arg0: Internal.DraggableComponentProvider_<T, A>): void;
        abstract getFocusedStack<T extends Internal.Screen>(arg0: T, arg1: me.shedaniel.math.Point_): Internal.EntryStack<any>;
        "registerDraggableStackProvider(me.shedaniel.rei.api.client.gui.drag.DraggableStackProviderWidget)"<T extends Internal.Screen>(provider: Internal.DraggableStackProviderWidget_): void;
        endReload(stage: Internal.ReloadStage_): void;
        abstract getDraggableComponentProviders(): Internal.Iterable<Internal.DraggableComponentProvider<Internal.Screen, any>>;
        abstract registerFocusedStack(arg0: Internal.FocusedStackProvider_): void;
        preStage(stage: Internal.ReloadStage_): void;
        endReload(): void;
        abstract getDeciders<R extends Internal.Screen>(arg0: R): Internal.List<Internal.OverlayDecider>;
        registerDraggableComponentVisitor<T extends Internal.Screen>(visitor: Internal.DraggableComponentVisitorWidget_): void;
        abstract registerContainerClickArea<C extends Internal.AbstractContainerMenu, T extends Internal.AbstractContainerScreen<C>>(arg0: Internal.SimpleClickArea_<T>, arg1: T, ...arg2: Internal.CategoryIdentifier_<any>[]): void;
        executeClickArea<T extends Internal.Screen>(screenClass: T, context: Internal.ClickArea$ClickAreaContext_<T>): boolean;
        startReload(stage: Internal.ReloadStage_): void;
        abstract "registerDraggableComponentVisitor(me.shedaniel.rei.api.client.gui.drag.component.DraggableComponentVisitor)"<T extends Internal.Screen>(arg0: Internal.DraggableComponentVisitor_<T>): void;
        getInstance(): this;
        registerDraggableComponentProvider<T extends Internal.Screen, A>(provider: Internal.DraggableComponentProviderWidget_<A>): void;
        registerDraggableStackProvider<T extends Internal.Screen>(provider: Internal.DraggableStackProviderWidget_): void;
        abstract getOverlayBounds<T extends Internal.Screen>(arg0: Internal.DisplayPanelLocation_, arg1: T): me.shedaniel.math.Rectangle;
        abstract registerClickArea<T extends Internal.Screen>(arg0: T, arg1: Internal.ClickArea_<T>): void;
        registerClickArea<T extends Internal.Screen>(area: Internal.SimpleClickArea_<T>, screenClass: T, ...categories: Internal.CategoryIdentifier_<any>[]): void;
        registerDraggableComponentProvider<T extends Internal.Screen, A>(priority: number, provider: Internal.DraggableComponentProviderWidget_<A>): void;
        "registerContainerClickArea(me.shedaniel.math.Rectangle,java.lang.Class,me.shedaniel.rei.api.common.category.CategoryIdentifier[])"<C extends Internal.AbstractContainerMenu, T extends Internal.AbstractContainerScreen<C>>(area: me.shedaniel.math.Rectangle_, screenClass: T, ...categories: Internal.CategoryIdentifier_<any>[]): void;
        "registerDraggableStackVisitor(me.shedaniel.rei.api.client.gui.drag.DraggableStackVisitorWidget)"<T extends Internal.Screen>(visitor: Internal.DraggableStackVisitorWidget_): void;
        abstract "registerDraggableStackProvider(me.shedaniel.rei.api.client.gui.drag.DraggableStackProvider)"<T extends Internal.Screen>(arg0: Internal.DraggableStackProvider_<T>): void;
        abstract getDraggableComponentVisitors(): Internal.Iterable<Internal.DraggableComponentVisitor<Internal.Screen>>;
        getStage(): Internal.ReloadStage;
        abstract exclusionZones(): Internal.ExclusionZones;
        abstract "registerContainerClickArea(me.shedaniel.rei.api.client.registry.screen.SimpleClickArea,java.lang.Class,me.shedaniel.rei.api.common.category.CategoryIdentifier[])"<C extends Internal.AbstractContainerMenu, T extends Internal.AbstractContainerScreen<C>>(arg0: Internal.SimpleClickArea_<T>, arg1: T, ...arg2: Internal.CategoryIdentifier_<any>[]): void;
        registerDraggableStackVisitor<T extends Internal.Screen>(priority: number, visitor: Internal.DraggableStackVisitorWidget_): void;
        afterReloadable(stage: Internal.ReloadStage_, other: Internal.Reloadable_<Internal.REIClientPlugin>): void;
        registerDraggableStackVisitor<T extends Internal.Screen>(visitor: Internal.DraggableStackVisitorWidget_): void;
        abstract getDeciders(): Internal.List<Internal.OverlayDecider>;
        abstract registerDraggableComponentVisitor<T extends Internal.Screen>(arg0: Internal.DraggableComponentVisitor_<T>): void;
        beforeReloadable(stage: Internal.ReloadStage_, other: Internal.Reloadable_<Internal.REIClientPlugin>): void;
        abstract startReload(): void;
        "registerDraggableComponentVisitor(me.shedaniel.rei.api.client.gui.drag.component.DraggableComponentVisitorWidget)"<T extends Internal.Screen>(visitor: Internal.DraggableComponentVisitorWidget_): void;
        /**
         * @deprecated
        */
        handleClickArea<T extends Internal.Screen>(screenClass: T, context: Internal.ClickArea$ClickAreaContext_<T>): Internal.Set<Internal.CategoryIdentifier<any>>;
        registerDraggableComponentVisitor<T extends Internal.Screen>(priority: number, visitor: Internal.DraggableComponentVisitorWidget_): void;
        abstract registerDraggableComponentProvider<T extends Internal.Screen, A>(arg0: Internal.DraggableComponentProvider_<T, A>): void;
        beforeReloadablePlugin(stage: Internal.ReloadStage_, other: Internal.Reloadable_<Internal.REIClientPlugin>, plugin: Internal.REIClientPlugin_): void;
        registerContainerClickArea<C extends Internal.AbstractContainerMenu, T extends Internal.AbstractContainerScreen<C>>(area: me.shedaniel.math.Rectangle_, screenClass: T, ...categories: Internal.CategoryIdentifier_<any>[]): void;
        get concurrent(): boolean
        get draggableComponentProviders(): Internal.Iterable<Internal.DraggableComponentProvider<Internal.Screen, any>>
        get instance(): Internal.ScreenRegistry
        get draggableComponentVisitors(): Internal.Iterable<Internal.DraggableComponentVisitor<Internal.Screen>>
        get stage(): Internal.ReloadStage
        get deciders(): Internal.List<Internal.OverlayDecider>
    }
    type ScreenRegistry_ = ScreenRegistry;
    class SoulTomeItem extends Internal.Item {
        constructor(summon: Internal.Summon_, settings: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, world: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        getSummon(): Internal.Summon;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        get summon(): Internal.Summon
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type SoulTomeItem_ = SoulTomeItem;
    interface AccessItemRenderer {
        abstract indium$renderBakedItemModel(arg0: Internal.BakedModel_, arg1: Internal.ItemStack_, arg2: number, arg3: number, arg4: Internal.PoseStack_, arg5: Internal.VertexConsumer_): void;
        (arg0: Internal.BakedModel, arg1: Internal.ItemStack, arg2: number, arg3: number, arg4: Internal.PoseStack, arg5: Internal.VertexConsumer): void;
    }
    type AccessItemRenderer_ = ((arg0: Internal.BakedModel, arg1: Internal.ItemStack, arg2: number, arg3: number, arg4: Internal.PoseStack, arg5: Internal.VertexConsumer)=> void) | AccessItemRenderer;
    class SoulSandBlock extends Internal.Block {
        constructor($$0: Internal.BlockBehaviour$Properties_)
        /**
         * @deprecated
        */
        getOcclusionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        /**
         * @deprecated
        */
        getSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        axiom$customPickBlockStack(): Internal.ItemStack;
        getSoundType($$0: Internal.BlockState_): SoundType;
        getVisualShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        handler$efo000$collective$Block_playerDestroy(level: Internal.Level_, player: Internal.Player_, blockPos: BlockPos_, blockState: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number, $$5: number): void;
        /**
         * @deprecated
        */
        randomTick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: Internal.BlockEntity_): void;
        static canSupportRigidBlock($$0: Internal.BlockGetter_, $$1: BlockPos_): boolean;
        static popResource($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.ItemStack_): void;
        setRandomTickCallback(callback: Internal.Consumer_<any>): void;
        getDescriptionId(): string;
        stepOn($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Entity_): void;
        fallOn($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: BlockPos_, $$3: Internal.Entity_, $$4: number): void;
        getSettings(): Internal.BlockBehaviour$Properties;
        getExplosionResistance(): number;
        asItem(): Internal.Item;
        /**
         * @deprecated
        */
        triggerEvent($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: number, $$4: number): boolean;
        getTypeData(): Internal.CompoundTag;
        setFriction(arg0: number): void;
        /**
         * @deprecated
        */
        getRenderShape($$0: Internal.BlockState_): Internal.RenderShape;
        canCull(): boolean;
        customShapeUpdate(blockState: Internal.CustomBlockState_, levelReader: Internal.LevelReader_, blockPos: BlockPos_): Internal.CustomBlockState;
        getJumpFactor(): number;
        getSpeedFactor(): number;
        static canSupportCenter($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        skipRendering($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getLightBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        playerDestroy($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.BlockEntity_, $$5: Internal.ItemStack_): void;
        shouldAttemptToCull(state: Internal.BlockState_): boolean;
        isPossibleToRespawnInThis($$0: Internal.BlockState_): boolean;
        getCustomStateForPlacement(blockPlaceContext: Internal.BlockPlaceContext_): Internal.CustomBlockState;
        /**
         * @deprecated
        */
        getDirectSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        getProperties(): Internal.BlockBehaviour$Properties;
        playerWillDestroy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Player_): void;
        getClass(): typeof any;
        getMaxVerticalOffset(): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.item.context.BlockPlaceContext)"($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        useShapeForLightOcclusion($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        getDrops($$0: Internal.BlockState_, $$1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getStateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>;
        /**
         * @deprecated
        */
        entityInside($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Entity_): void;
        setBlockBuilder(b: Internal.BlockBuilder_): void;
        handler$ldb000$puzzleslib$playerDestroy$0(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        setRequiresTool(v: boolean): void;
        setSpeedFactor(arg0: number): void;
        axiom$getPossibleCustomStates(): Internal.List<any>;
        setExplosionResistance(arg0: number): void;
        toString(): string;
        port_lib$popExperience(arg0: Internal.ServerLevel_, arg1: BlockPos_, arg2: number): void;
        notifyAll(): void;
        getToolModifiedState(state: Internal.BlockState_, world: Internal.Level_, pos: BlockPos_, player: Internal.Player_, stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): Internal.BlockState;
        getId(): string;
        getLootTable(): ResourceLocation;
        puzzleslib$setItem(arg0: Internal.Item_): void;
        axiom$translationKey(): string;
        /**
         * @deprecated
        */
        getInteractionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        onPlace($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        propagatesSkylightDown($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        setPlacedBy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.LivingEntity_, $$4: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Block>;
        static popResourceFromFace($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.ItemStack_): void;
        getFriction(): number;
        handlePrecipitation($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Biome$Precipitation_): void;
        /**
         * @deprecated
        */
        hasAnalogOutputSignal($$0: Internal.BlockState_): boolean;
        wait(arg0: number): void;
        /**
         * @deprecated
        */
        getFluidState($$0: Internal.BlockState_): Internal.FluidState;
        handler$koh000$porting_lib_entity$getDestroySpeed(blockState: Internal.BlockState_, player: Internal.Player_, blockGetter: Internal.BlockGetter_, pos: BlockPos_, cir: Internal.CallbackInfoReturnable_<any>): void;
        /**
         * @deprecated
        */
        getAnalogOutputSignal($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): number;
        handler$efo000$collective$Block_setPlacedBy(level: Internal.Level_, blockPos: BlockPos_, blockState: Internal.BlockState_, livingEntity: Internal.LivingEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        tick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        supportsExternalFaceHiding(state: Internal.BlockState_): boolean;
        handler$ldb000$puzzleslib$playerDestroy$1(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        notify(): void;
        axiom$asItemStack(): Internal.ItemStack;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        neighborChanged($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Block_, $$4: BlockPos_, $$5: boolean): void;
        getBlockSupportShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        handler$zhd000$additionalentityattributes$additionalEntityAttributes$saveBreakingPlayer(world: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, stack: Internal.ItemStack_, callbackInfo: Internal.CallbackInfo_): void;
        canSustainPlant(state: Internal.BlockState_, world: Internal.BlockGetter_, pos: BlockPos_, facing: Internal.Direction_, plantable: Internal.IPlantable_): boolean;
        /**
         * @deprecated
        */
        isCollisionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static isFaceFull($$0: Internal.VoxelShape_, $$1: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getMenuProvider($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): Internal.MenuProvider;
        static byItem($$0: Internal.Item_): Internal.Block;
        static updateFromNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        updateIndirectNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: number, $$4: number): void;
        destroy($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): void;
        handler$fdc000$everycomp$addSimpleFastECdrops(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, cir: Internal.CallbackInfoReturnable_<any>, resId: ResourceLocation_, lootParams: Internal.LootParams_, serverLevel: Internal.ServerLevel_, lootTable: Internal.LootTable_): void;
        getToolModifiedState(state: Internal.BlockState_, context: Internal.UseOnContext_, toolAction: Internal.ToolAction_, simulate: boolean): Internal.BlockState;
        /**
         * @deprecated
        */
        use($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_, $$4: Internal.InteractionHand_, $$5: Internal.BlockHitResult_): Internal.InteractionResult;
        setLightEmission(v: number): void;
        doNormalInteractions(): boolean;
        setJumpFactor(arg0: number): void;
        /**
         * @deprecated
        */
        canSurvive($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        getShadeBrightness($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): void;
        getAppearance(state: Internal.BlockState_, renderView: Internal.BlockAndTintGetter_, pos: BlockPos_, side: Internal.Direction_, sourceState: Internal.BlockState_, sourcePos: BlockPos_): Internal.BlockState;
        getCollisionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        setDestroySpeed(v: number): void;
        defaultBlockState(): Internal.BlockState;
        usesCustomShouldDrawFace(state: Internal.BlockState_): boolean;
        getStateForPlacement($$0: Internal.BlockPlaceContext_): Internal.BlockState;
        cantCullAgainst(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        arch$holder(): Internal.Holder<Internal.Block>;
        wait(): void;
        getCloneItemStack($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        hasDynamicShape(): boolean;
        getMaxHorizontalOffset(): number;
        /**
         * @deprecated
        */
        getDestroyProgress($$0: Internal.BlockState_, $$1: Internal.Player_, $$2: Internal.BlockGetter_, $$3: BlockPos_): number;
        /**
         * @deprecated
        */
        getSeed($$0: Internal.BlockState_, $$1: BlockPos_): number;
        defaultDestroyTime(): number;
        updateShape($$0: Internal.BlockState_, $$1: Internal.Direction_, $$2: Internal.BlockState_, $$3: Internal.LevelAccessor_, $$4: BlockPos_, $$5: BlockPos_): Internal.BlockState;
        dropFromExplosion($$0: Internal.Explosion_): boolean;
        isRandomlyTicking($$0: Internal.BlockState_): boolean;
        static isShapeFullBlock(shape: Internal.VoxelShape_): boolean;
        withPropertiesOf($$0: Internal.BlockState_): Internal.BlockState;
        static isExceptionForConnection($$0: Internal.BlockState_): boolean;
        setIsRandomlyTicking(arg0: boolean): void;
        hidesNeighborFace(level: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, neighborState: Internal.BlockState_, dir: Internal.Direction_): boolean;
        onTreeGrow(state: Internal.BlockState_, level: Internal.LevelReader_, placeFunction: Internal.BiConsumer_<BlockPos, Internal.BlockState>, randomSource: Internal.RandomSource_, pos: BlockPos_, config: Internal.TreeConfiguration_): boolean;
        /**
         * @deprecated
        */
        rotate($$0: Internal.BlockState_, $$1: Internal.Rotation_): Internal.BlockState;
        defaultMapColor(): Internal.MapColor;
        getStateAtViewpoint(state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_, viewpoint: Vec3d_): Internal.BlockState;
        wait(arg0: number, arg1: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.BlockGetter_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        setNameKey(arg0: string): void;
        static box($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): Internal.VoxelShape;
        /**
         * @deprecated
        */
        mirror($$0: Internal.BlockState_, $$1: Internal.Mirror_): Internal.BlockState;
        wasExploded($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Explosion_): void;
        getName(): Internal.MutableComponent;
        updateEntityAfterFallOn($$0: Internal.BlockGetter_, $$1: Internal.Entity_): void;
        animateTick($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        customShouldDrawFace(view: Internal.BlockGetter_, thisState: Internal.BlockState_, sideState: Internal.BlockState_, thisPos: BlockPos_, sidePos: BlockPos_, side: Internal.Direction_): Optional<boolean>;
        axiom$getResourceLocation(): ResourceLocation;
        arch$registryName(): ResourceLocation;
        axiom$getProperties(): Internal.Collection<any>;
        getBlockBuilder(): Internal.BlockBuilder;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        isSignalSource($$0: Internal.BlockState_): boolean;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number): void;
        /**
         * @deprecated
        */
        attack($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): void;
        /**
         * @deprecated
        */
        getShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        shouldAttemptToCull(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        onProjectileHit($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockHitResult_, $$3: Internal.Projectile_): void;
        static stateById($$0: number): Internal.BlockState;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): Internal.List<Internal.ItemStack>;
        requiredFeatures(): Internal.FeatureFlagSet;
        hashCode(): number;
        axiom$defaultCustomState(): Internal.CustomBlockState;
        setCanCull(canCull: boolean): void;
        /**
         * @deprecated
        */
        isOcclusionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static getId($$0: Internal.BlockState_): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.material.Fluid)"($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        static pushEntitiesUp($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): Internal.BlockState;
        isPathfindable($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.PathComputationType_): boolean;
        setSoundType(arg0: SoundType_): void;
        handler$cef000$betterend$be_getDroppedStacks(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, info: Internal.CallbackInfoReturnable_<any>): void;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_): Internal.List<Internal.ItemStack>;
        /**
         * @deprecated
        */
        onRemove($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        cantCullAgainst(state: Internal.BlockState_): boolean;
        setHasCollision(arg0: boolean): void;
        static shouldRenderFace($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_, $$4: BlockPos_): boolean;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        spawnAfterBreak($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.ItemStack_, $$4: boolean): void;
        set randomTickCallback(callback: Internal.Consumer_<any>)
        get descriptionId(): string
        get settings(): Internal.BlockBehaviour$Properties
        get explosionResistance(): number
        get typeData(): Internal.CompoundTag
        set friction(arg0: number)
        get jumpFactor(): number
        get speedFactor(): number
        get properties(): Internal.BlockBehaviour$Properties
        get class(): typeof any
        get maxVerticalOffset(): number
        get stateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>
        set blockBuilder(b: Internal.BlockBuilder_)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        set speedFactor(arg0: number)
        set explosionResistance(arg0: number)
        get id(): string
        get lootTable(): ResourceLocation
        get friction(): number
        set lightEmission(v: number)
        set jumpFactor(arg0: number)
        set destroySpeed(v: number)
        get maxHorizontalOffset(): number
        set isRandomlyTicking(arg0: boolean)
        set nameKey(arg0: string)
        get name(): Internal.MutableComponent
        get blockBuilder(): Internal.BlockBuilder
        get idLocation(): ResourceLocation
        get mod(): string
        set canCull(canCull: boolean)
        set soundType(arg0: SoundType_)
        set hasCollision(arg0: boolean)
    }
    type SoulSandBlock_ = SoulSandBlock;
    class GroupedLootAction extends Internal.CompositeLootAction {
        constructor(numberProvider: Internal.NumberProvider_, handlers: Internal.Collection_<Internal.ILootHandler>)
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        applyLootHandler(context: Internal.LootContext_, loot: Internal.List_<Internal.ItemStack>): boolean;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
    }
    type GroupedLootAction_ = GroupedLootAction;
    class Locale$Category extends Internal.Enum<Internal.Locale$Category> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        "compareTo(java.util.Locale$Category)"(arg0: Internal.Locale$Category_): number;
        static values(): Internal.Locale$Category[];
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        name(): string;
        hashCode(): number;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.Locale$Category>>;
        getDeclaringClass(): typeof Internal.Locale$Category;
        static valueOf(arg0: string): Internal.Locale$Category;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        compareTo(arg0: Internal.Locale$Category_): number;
        get class(): typeof any
        get declaringClass(): typeof Internal.Locale$Category
        static readonly FORMAT: (Internal.Locale$Category) & (Internal.Locale$Category);
        static readonly DISPLAY: (Internal.Locale$Category) & (Internal.Locale$Category);
    }
    type Locale$Category_ = Locale$Category | "display" | "format";
    class PlayerModelPart extends Internal.Enum<Internal.PlayerModelPart> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        static valueOf($$0: string): Internal.PlayerModelPart;
        getName(): net.minecraft.network.chat.Component;
        toString(): string;
        notifyAll(): void;
        getMask(): number;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.PlayerModelPart>>;
        getId(): string;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        name(): string;
        "compareTo(net.minecraft.world.entity.player.PlayerModelPart)"(arg0: Internal.PlayerModelPart_): number;
        hashCode(): number;
        getBit(): number;
        static values(): Internal.PlayerModelPart[];
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        compareTo(arg0: Internal.PlayerModelPart_): number;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        getDeclaringClass(): typeof Internal.PlayerModelPart;
        get class(): typeof any
        get name(): net.minecraft.network.chat.Component
        get mask(): number
        get id(): string
        get bit(): number
        get declaringClass(): typeof Internal.PlayerModelPart
        static readonly CAPE: (Internal.PlayerModelPart) & (Internal.PlayerModelPart);
        static readonly LEFT_SLEEVE: (Internal.PlayerModelPart) & (Internal.PlayerModelPart);
        static readonly RIGHT_PANTS_LEG: (Internal.PlayerModelPart) & (Internal.PlayerModelPart);
        static readonly LEFT_PANTS_LEG: (Internal.PlayerModelPart) & (Internal.PlayerModelPart);
        static readonly RIGHT_SLEEVE: (Internal.PlayerModelPart) & (Internal.PlayerModelPart);
        static readonly JACKET: (Internal.PlayerModelPart) & (Internal.PlayerModelPart);
        static readonly HAT: (Internal.PlayerModelPart) & (Internal.PlayerModelPart);
    }
    type PlayerModelPart_ = "jacket" | "hat" | "right_sleeve" | "cape" | "right_pants_leg" | "left_sleeve" | "left_pants_leg" | PlayerModelPart;
    class MedallionSuffering extends Internal.BaseMedallion {
        constructor(settings: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(itemStack: Internal.ItemStack_, world: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, tooltipContext: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick(stack: Internal.ItemStack_, world: Internal.Level_, entity: Internal.Entity_, slot: number, selected: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type MedallionSuffering_ = MedallionSuffering;
    class WitherSkullBlock extends Internal.SkullBlock {
        constructor($$0: Internal.BlockBehaviour$Properties_)
        getOcclusionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        /**
         * @deprecated
        */
        getSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        axiom$customPickBlockStack(): Internal.ItemStack;
        getSoundType($$0: Internal.BlockState_): SoundType;
        /**
         * @deprecated
        */
        getVisualShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        handler$efo000$collective$Block_playerDestroy(level: Internal.Level_, player: Internal.Player_, blockPos: BlockPos_, blockState: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number, $$5: number): void;
        /**
         * @deprecated
        */
        randomTick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: Internal.BlockEntity_): void;
        static canSupportRigidBlock($$0: Internal.BlockGetter_, $$1: BlockPos_): boolean;
        static popResource($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.ItemStack_): void;
        setRandomTickCallback(callback: Internal.Consumer_<any>): void;
        getDescriptionId(): string;
        stepOn($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Entity_): void;
        static checkSpawn($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.SkullBlockEntity_): void;
        fallOn($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: BlockPos_, $$3: Internal.Entity_, $$4: number): void;
        getSettings(): Internal.BlockBehaviour$Properties;
        triggerEvent($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: number, $$4: number): boolean;
        getExplosionResistance(): number;
        asItem(): Internal.Item;
        getTypeData(): Internal.CompoundTag;
        setFriction(arg0: number): void;
        getRenderShape($$0: Internal.BlockState_): Internal.RenderShape;
        canCull(): boolean;
        customShapeUpdate(blockState: Internal.CustomBlockState_, levelReader: Internal.LevelReader_, blockPos: BlockPos_): Internal.CustomBlockState;
        getJumpFactor(): number;
        getSpeedFactor(): number;
        static canSupportCenter($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        skipRendering($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getLightBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        playerDestroy($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.BlockEntity_, $$5: Internal.ItemStack_): void;
        shouldAttemptToCull(state: Internal.BlockState_): boolean;
        isPossibleToRespawnInThis($$0: Internal.BlockState_): boolean;
        getCustomStateForPlacement(blockPlaceContext: Internal.BlockPlaceContext_): Internal.CustomBlockState;
        /**
         * @deprecated
        */
        getDirectSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        getProperties(): Internal.BlockBehaviour$Properties;
        playerWillDestroy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Player_): void;
        getClass(): typeof any;
        getMaxVerticalOffset(): number;
        newBlockEntity($$0: BlockPos_, $$1: Internal.BlockState_): Internal.BlockEntity;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.item.context.BlockPlaceContext)"($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        static get($$0: Internal.ItemStack_): Internal.Equipable;
        /**
         * @deprecated
        */
        useShapeForLightOcclusion($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        getDrops($$0: Internal.BlockState_, $$1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getStateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>;
        /**
         * @deprecated
        */
        entityInside($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Entity_): void;
        setBlockBuilder(b: Internal.BlockBuilder_): void;
        handler$ldb000$puzzleslib$playerDestroy$0(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        setRequiresTool(v: boolean): void;
        setSpeedFactor(arg0: number): void;
        axiom$getPossibleCustomStates(): Internal.List<any>;
        getEquipmentSlot(): Internal.EquipmentSlot;
        setExplosionResistance(arg0: number): void;
        toString(): string;
        port_lib$popExperience(arg0: Internal.ServerLevel_, arg1: BlockPos_, arg2: number): void;
        notifyAll(): void;
        getToolModifiedState(state: Internal.BlockState_, world: Internal.Level_, pos: BlockPos_, player: Internal.Player_, stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): Internal.BlockState;
        getId(): string;
        getLootTable(): ResourceLocation;
        puzzleslib$setItem(arg0: Internal.Item_): void;
        axiom$translationKey(): string;
        /**
         * @deprecated
        */
        getInteractionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        setPlacedBy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.LivingEntity_, $$4: Internal.ItemStack_): void;
        propagatesSkylightDown($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        /**
         * @deprecated
        */
        onPlace($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        static canSpawnMob($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.ItemStack_): boolean;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Block>;
        static popResourceFromFace($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.ItemStack_): void;
        getFriction(): number;
        handlePrecipitation($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Biome$Precipitation_): void;
        /**
         * @deprecated
        */
        hasAnalogOutputSignal($$0: Internal.BlockState_): boolean;
        wait(arg0: number): void;
        /**
         * @deprecated
        */
        getFluidState($$0: Internal.BlockState_): Internal.FluidState;
        handler$koh000$porting_lib_entity$getDestroySpeed(blockState: Internal.BlockState_, player: Internal.Player_, blockGetter: Internal.BlockGetter_, pos: BlockPos_, cir: Internal.CallbackInfoReturnable_<any>): void;
        /**
         * @deprecated
        */
        getAnalogOutputSignal($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): number;
        handler$efo000$collective$Block_setPlacedBy(level: Internal.Level_, blockPos: BlockPos_, blockState: Internal.BlockState_, livingEntity: Internal.LivingEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        tick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        supportsExternalFaceHiding(state: Internal.BlockState_): boolean;
        handler$ldb000$puzzleslib$playerDestroy$1(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        notify(): void;
        axiom$asItemStack(): Internal.ItemStack;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        neighborChanged($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Block_, $$4: BlockPos_, $$5: boolean): void;
        handler$zhd000$additionalentityattributes$additionalEntityAttributes$saveBreakingPlayer(world: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, stack: Internal.ItemStack_, callbackInfo: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        getBlockSupportShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        canSustainPlant(state: Internal.BlockState_, world: Internal.BlockGetter_, pos: BlockPos_, facing: Internal.Direction_, plantable: Internal.IPlantable_): boolean;
        /**
         * @deprecated
        */
        isCollisionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static isFaceFull($$0: Internal.VoxelShape_, $$1: Internal.Direction_): boolean;
        getTicker<T extends Internal.BlockEntity>($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockEntityType_<T>): Internal.BlockEntityTicker<T>;
        getMenuProvider($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): Internal.MenuProvider;
        static byItem($$0: Internal.Item_): Internal.Block;
        static updateFromNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        updateIndirectNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: number, $$4: number): void;
        destroy($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): void;
        handler$fdc000$everycomp$addSimpleFastECdrops(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, cir: Internal.CallbackInfoReturnable_<any>, resId: ResourceLocation_, lootParams: Internal.LootParams_, serverLevel: Internal.ServerLevel_, lootTable: Internal.LootTable_): void;
        getToolModifiedState(state: Internal.BlockState_, context: Internal.UseOnContext_, toolAction: Internal.ToolAction_, simulate: boolean): Internal.BlockState;
        /**
         * @deprecated
        */
        use($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_, $$4: Internal.InteractionHand_, $$5: Internal.BlockHitResult_): Internal.InteractionResult;
        setLightEmission(v: number): void;
        getEquipSound(): Internal.SoundEvent;
        doNormalInteractions(): boolean;
        setJumpFactor(arg0: number): void;
        /**
         * @deprecated
        */
        canSurvive($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): void;
        /**
         * @deprecated
        */
        getShadeBrightness($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        getAppearance(state: Internal.BlockState_, renderView: Internal.BlockAndTintGetter_, pos: BlockPos_, side: Internal.Direction_, sourceState: Internal.BlockState_, sourcePos: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        getCollisionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        setDestroySpeed(v: number): void;
        defaultBlockState(): Internal.BlockState;
        usesCustomShouldDrawFace(state: Internal.BlockState_): boolean;
        getStateForPlacement($$0: Internal.BlockPlaceContext_): Internal.BlockState;
        cantCullAgainst(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        getType(): Internal.SkullBlock$Type;
        getListener<T extends Internal.BlockEntity>($$0: Internal.ServerLevel_, $$1: T): Internal.GameEventListener;
        arch$holder(): Internal.Holder<Internal.Block>;
        wait(): void;
        getCloneItemStack($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        hasDynamicShape(): boolean;
        getMaxHorizontalOffset(): number;
        /**
         * @deprecated
        */
        getDestroyProgress($$0: Internal.BlockState_, $$1: Internal.Player_, $$2: Internal.BlockGetter_, $$3: BlockPos_): number;
        /**
         * @deprecated
        */
        getSeed($$0: Internal.BlockState_, $$1: BlockPos_): number;
        defaultDestroyTime(): number;
        dropFromExplosion($$0: Internal.Explosion_): boolean;
        /**
         * @deprecated
        */
        updateShape($$0: Internal.BlockState_, $$1: Internal.Direction_, $$2: Internal.BlockState_, $$3: Internal.LevelAccessor_, $$4: BlockPos_, $$5: BlockPos_): Internal.BlockState;
        isRandomlyTicking($$0: Internal.BlockState_): boolean;
        static isShapeFullBlock(shape: Internal.VoxelShape_): boolean;
        withPropertiesOf($$0: Internal.BlockState_): Internal.BlockState;
        static isExceptionForConnection($$0: Internal.BlockState_): boolean;
        setIsRandomlyTicking(arg0: boolean): void;
        rotate($$0: Internal.BlockState_, $$1: Internal.Rotation_): Internal.BlockState;
        hidesNeighborFace(level: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, neighborState: Internal.BlockState_, dir: Internal.Direction_): boolean;
        onTreeGrow(state: Internal.BlockState_, level: Internal.LevelReader_, placeFunction: Internal.BiConsumer_<BlockPos, Internal.BlockState>, randomSource: Internal.RandomSource_, pos: BlockPos_, config: Internal.TreeConfiguration_): boolean;
        defaultMapColor(): Internal.MapColor;
        getStateAtViewpoint(state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_, viewpoint: Vec3d_): Internal.BlockState;
        wait(arg0: number, arg1: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.BlockGetter_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        setNameKey(arg0: string): void;
        static box($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): Internal.VoxelShape;
        mirror($$0: Internal.BlockState_, $$1: Internal.Mirror_): Internal.BlockState;
        wasExploded($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Explosion_): void;
        getName(): Internal.MutableComponent;
        updateEntityAfterFallOn($$0: Internal.BlockGetter_, $$1: Internal.Entity_): void;
        animateTick($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        customShouldDrawFace(view: Internal.BlockGetter_, thisState: Internal.BlockState_, sideState: Internal.BlockState_, thisPos: BlockPos_, sidePos: BlockPos_, side: Internal.Direction_): Optional<boolean>;
        axiom$getResourceLocation(): ResourceLocation;
        arch$registryName(): ResourceLocation;
        axiom$getProperties(): Internal.Collection<any>;
        getBlockBuilder(): Internal.BlockBuilder;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        isSignalSource($$0: Internal.BlockState_): boolean;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number): void;
        /**
         * @deprecated
        */
        attack($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): void;
        getShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        shouldAttemptToCull(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        onProjectileHit($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockHitResult_, $$3: Internal.Projectile_): void;
        static stateById($$0: number): Internal.BlockState;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): Internal.List<Internal.ItemStack>;
        requiredFeatures(): Internal.FeatureFlagSet;
        hashCode(): number;
        axiom$defaultCustomState(): Internal.CustomBlockState;
        setCanCull(canCull: boolean): void;
        /**
         * @deprecated
        */
        isOcclusionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static getId($$0: Internal.BlockState_): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.material.Fluid)"($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        static pushEntitiesUp($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): Internal.BlockState;
        isPathfindable($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.PathComputationType_): boolean;
        setSoundType(arg0: SoundType_): void;
        handler$cef000$betterend$be_getDroppedStacks(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, info: Internal.CallbackInfoReturnable_<any>): void;
        swapWithEquipmentSlot($$0: Internal.Item_, $$1: Internal.Level_, $$2: Internal.Player_, $$3: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_): Internal.List<Internal.ItemStack>;
        /**
         * @deprecated
        */
        onRemove($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        cantCullAgainst(state: Internal.BlockState_): boolean;
        setHasCollision(arg0: boolean): void;
        static shouldRenderFace($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_, $$4: BlockPos_): boolean;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        spawnAfterBreak($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.ItemStack_, $$4: boolean): void;
        set randomTickCallback(callback: Internal.Consumer_<any>)
        get descriptionId(): string
        get settings(): Internal.BlockBehaviour$Properties
        get explosionResistance(): number
        get typeData(): Internal.CompoundTag
        set friction(arg0: number)
        get jumpFactor(): number
        get speedFactor(): number
        get properties(): Internal.BlockBehaviour$Properties
        get class(): typeof any
        get maxVerticalOffset(): number
        get stateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>
        set blockBuilder(b: Internal.BlockBuilder_)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        set speedFactor(arg0: number)
        get equipmentSlot(): Internal.EquipmentSlot
        set explosionResistance(arg0: number)
        get id(): string
        get lootTable(): ResourceLocation
        get friction(): number
        set lightEmission(v: number)
        get equipSound(): Internal.SoundEvent
        set jumpFactor(arg0: number)
        set destroySpeed(v: number)
        get type(): Internal.SkullBlock$Type
        get maxHorizontalOffset(): number
        set isRandomlyTicking(arg0: boolean)
        set nameKey(arg0: string)
        get name(): Internal.MutableComponent
        get blockBuilder(): Internal.BlockBuilder
        get idLocation(): ResourceLocation
        get mod(): string
        set canCull(canCull: boolean)
        set soundType(arg0: SoundType_)
        set hasCollision(arg0: boolean)
    }
    type WitherSkullBlock_ = WitherSkullBlock;
    interface RecipeManagerContext <P extends Internal.REIPlugin<any>> extends Internal.Reloadable<P> {
        postStage(stage: Internal.ReloadStage_): void;
        acceptPlugin(plugin: P): void;
        byId(tag: Internal.CompoundTag_, key: string): Internal.Recipe<any>;
        endReload(): void;
        abstract getAllSortedRecipes(): Internal.List<Internal.Recipe<any>>;
        getStage(): Internal.ReloadStage;
        afterReloadable(stage: Internal.ReloadStage_, other: Internal.Reloadable_<P>): void;
        startReload(stage: Internal.ReloadStage_): void;
        afterReloadablePlugin(stage: Internal.ReloadStage_, other: Internal.Reloadable_<P>, plugin: P): void;
        abstract getRecipeManager(): Internal.RecipeManager;
        endReload(stage: Internal.ReloadStage_): void;
        beforeReloadablePlugin(stage: Internal.ReloadStage_, other: Internal.Reloadable_<P>, plugin: P): void;
        abstract startReload(): void;
        preStage(stage: Internal.ReloadStage_): void;
        acceptPlugin(plugin: P, stage: Internal.ReloadStage_): void;
        byId(location: ResourceLocation_): Internal.Recipe<any>;
        beforeReloadable(stage: Internal.ReloadStage_, other: Internal.Reloadable_<P>): void;
        getInstance(): Internal.RecipeManagerContext<Internal.REIPlugin<any>>;
        isConcurrent(): boolean;
        get allSortedRecipes(): Internal.List<Internal.Recipe<any>>
        get stage(): Internal.ReloadStage
        get recipeManager(): Internal.RecipeManager
        get instance(): Internal.RecipeManagerContext<Internal.REIPlugin<any>>
        get concurrent(): boolean
    }
    type RecipeManagerContext_<P extends Internal.REIPlugin<any>> = RecipeManagerContext<P>;
    class Package extends Internal.NamedPackage implements Internal.AnnotatedElement {
        getClass(): typeof any;
        getSpecificationVendor(): string;
        getSpecificationVersion(): string;
        /**
         * @deprecated
        */
        static getPackage(arg0: string): Internal.Package;
        static getPackages(): Internal.Package[];
        notify(): void;
        isCompatibleWith(arg0: string): boolean;
        wait(arg0: number, arg1: number): void;
        getAnnotation<A extends Internal.Annotation>(arg0: A): A;
        getImplementationVendor(): string;
        getName(): string;
        isSealed(arg0: Internal.URL_): boolean;
        isSealed(): boolean;
        getDeclaredAnnotations(): Internal.Annotation[];
        isAnnotationPresent(arg0: typeof Internal.Annotation): boolean;
        getDeclaredAnnotationsByType<A extends Internal.Annotation>(arg0: A): A[];
        getImplementationTitle(): string;
        toString(): string;
        notifyAll(): void;
        getImplementationVersion(): string;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        getAnnotations(): Internal.Annotation[];
        getDeclaredAnnotation<A extends Internal.Annotation>(arg0: A): A;
        getAnnotationsByType<A extends Internal.Annotation>(arg0: A): A[];
        getSpecificationTitle(): string;
        equals(arg0: any): boolean;
        get class(): typeof any
        get specificationVendor(): string
        get specificationVersion(): string
        get packages(): Internal.Package[]
        get implementationVendor(): string
        get name(): string
        get sealed(): boolean
        get declaredAnnotations(): Internal.Annotation[]
        get implementationTitle(): string
        get implementationVersion(): string
        get annotations(): Internal.Annotation[]
        get specificationTitle(): string
    }
    type Package_ = Package;
    class WorldDimensions$Complete extends Internal.Record {
        constructor($$0: Internal.Registry_<Internal.LevelStem>, $$1: Internal.PrimaryLevelData$SpecialWorldProperty_)
        getClass(): typeof any;
        dimensionsRegistryAccess(): Internal.RegistryAccess$Frozen;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        dimensions(): Internal.Registry<Internal.LevelStem>;
        lifecycle(): Internal.Lifecycle;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        equals($$0: any): boolean;
        specialWorldProperty(): Internal.PrimaryLevelData$SpecialWorldProperty;
        get class(): typeof any
    }
    type WorldDimensions$Complete_ = WorldDimensions$Complete;
    class EntityHitResult extends Internal.HitResult {
        constructor($$0: Internal.Entity_, $$1: Vec3d_)
        constructor($$0: Internal.Entity_)
        getClass(): typeof any;
        distanceTo($$0: Internal.Entity_): number;
        toString(): string;
        notifyAll(): void;
        getLocation(): Vec3d;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        getEntity(): Internal.Entity;
        wait(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        getType(): Internal.HitResult$Type;
        get class(): typeof any
        get location(): Vec3d
        get entity(): Internal.Entity
        get type(): Internal.HitResult$Type
    }
    type EntityHitResult_ = EntityHitResult;
    class ClientboundHurtAnimationPacket extends Internal.Record implements Internal.Packet<Internal.ClientGamePacketListener> {
        constructor($$0: Internal.FriendlyByteBuf_)
        constructor($$0: number, $$1: number)
        constructor($$0: Internal.LivingEntity_)
        handle(arg0: Internal.PacketListener_): void;
        getClass(): typeof any;
        write($$0: Internal.FriendlyByteBuf_): void;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        isSkippable(): boolean;
        wait(arg0: number, arg1: number): void;
        yaw(): number;
        hashCode(): number;
        id(): number;
        wait(): void;
        handle($$0: Internal.ClientGamePacketListener_): void;
        wait(arg0: number): void;
        "handle(net.minecraft.network.protocol.game.ClientGamePacketListener)"($$0: Internal.ClientGamePacketListener_): void;
        equals($$0: any): boolean;
        "handle(net.minecraft.network.PacketListener)"(arg0: Internal.PacketListener_): void;
        get class(): typeof any
        get skippable(): boolean
    }
    type ClientboundHurtAnimationPacket_ = ClientboundHurtAnimationPacket;
    class ClientboundAnimatePacket implements Internal.Packet<Internal.ClientGamePacketListener> {
        constructor($$0: Internal.FriendlyByteBuf_)
        constructor($$0: Internal.Entity_, $$1: number)
        handle(arg0: Internal.PacketListener_): void;
        getClass(): typeof any;
        write($$0: Internal.FriendlyByteBuf_): void;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        isSkippable(): boolean;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        wait(): void;
        handle($$0: Internal.ClientGamePacketListener_): void;
        wait(arg0: number): void;
        "handle(net.minecraft.network.protocol.game.ClientGamePacketListener)"($$0: Internal.ClientGamePacketListener_): void;
        equals(arg0: any): boolean;
        getAction(): number;
        "handle(net.minecraft.network.PacketListener)"(arg0: Internal.PacketListener_): void;
        getId(): number;
        get class(): typeof any
        get skippable(): boolean
        get action(): number
        get id(): number
        static readonly WAKE_UP: (2) & (number);
        static readonly SWING_OFF_HAND: (3) & (number);
        static readonly MAGIC_CRITICAL_HIT: (5) & (number);
        static readonly SWING_MAIN_HAND: (0) & (number);
        static readonly CRITICAL_HIT: (4) & (number);
    }
    type ClientboundAnimatePacket_ = ClientboundAnimatePacket;
    abstract class PlayerEventJS extends Internal.LivingEntityEventJS {
        constructor()
        getClass(): typeof any;
        /**
         * Stops the event with default exit value. Execution will be stopped **immediately**.
         * 
         * `exit` denotes a `default` outcome.
        */
        exit(): any;
        /**
         * Cancels the event with the given exit value. Execution will be stopped **immediately**.
         * 
         * `cancel` denotes a `false` outcome.
        */
        cancel(value: any): any;
        toString(): string;
        /**
         * Removes the specified game stage from the player
        */
        removeGameStage(stage: string): void;
        notifyAll(): void;
        abstract getEntity(): Internal.Player;
        /**
         * Stops the event with the given exit value. Execution will be stopped **immediately**.
         * 
         * `exit` denotes a `default` outcome.
        */
        exit(value: any): any;
        notify(): void;
        /**
         * Adds the specified game stage to the player
        */
        addGameStage(stage: string): void;
        wait(arg0: number, arg1: number): void;
        getLevel(): Internal.Level;
        /**
         * Stops the event with the given exit value. Execution will be stopped **immediately**.
         * 
         * `success` denotes a `true` outcome.
        */
        success(value: any): any;
        hashCode(): number;
        wait(): void;
        /**
         * Cancels the event with default exit value. Execution will be stopped **immediately**.
         * 
         * `cancel` denotes a `false` outcome.
        */
        cancel(): any;
        wait(arg0: number): void;
        getPlayer(): Internal.Player;
        /**
         * Stops the event with default exit value. Execution will be stopped **immediately**.
         * 
         * `success` denotes a `true` outcome.
        */
        success(): any;
        equals(arg0: any): boolean;
        /**
         * Checks if the player has the specified game stage
        */
        hasGameStage(stage: string): boolean;
        getServer(): Internal.MinecraftServer;
        get class(): typeof any
        get entity(): Internal.Player
        get level(): Internal.Level
        get player(): Internal.Player
        get server(): Internal.MinecraftServer
    }
    type PlayerEventJS_ = PlayerEventJS;
    interface LocalIntRef {
        abstract set(arg0: number): void;
        abstract get(): number;
    }
    type LocalIntRef_ = LocalIntRef;
    interface Consumer <T> {
        andThen(arg0: Internal.Consumer_<T>): this;
        abstract accept(arg0: T): void;
        (arg0: T): void;
    }
    type Consumer_<T> = ((arg0: T)=> void) | Consumer<T>;
    interface Filterable extends Internal.LifeCycle {
        abstract removeFilter(filter: Internal.Filter_): void;
        abstract getFilter(): Internal.Filter;
        abstract start(): void;
        abstract getState(): Internal.LifeCycle$State;
        abstract hasFilter(): boolean;
        abstract isStopped(): boolean;
        abstract isFiltered(event: Internal.LogEvent_): boolean;
        abstract stop(): void;
        abstract addFilter(filter: Internal.Filter_): void;
        abstract isStarted(): boolean;
        abstract initialize(): void;
        get filter(): Internal.Filter
        get state(): Internal.LifeCycle$State
        get stopped(): boolean
        get started(): boolean
    }
    type Filterable_ = Filterable;
    class BlockStateModifyCallbackJS {
        constructor(state: Internal.BlockState_)
        /**
         * Checks if this block has the specified property
        */
        hasProperty<T extends Internal.Comparable<T>>(property: Internal.Property_<T>): boolean;
        getClass(): typeof any;
        /**
         * Sets the value of the specified enum property
        */
        "set(net.minecraft.world.level.block.state.properties.EnumProperty,java.lang.String)"<T extends Internal.Enum<T> & Internal.StringRepresentable>(property: Internal.EnumProperty_<T>, value: string): this;
        /**
         * Get a map of this blocks properties to it's value
        */
        getValues(): Internal.ImmutableMap<Internal.Property<any>, Internal.Comparable<any>>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        /**
         * Gets the value of the passed in property
        */
        getValue<T extends Internal.Comparable<T>>(property: Internal.Property_<T>): T;
        /**
         * Sets the value of the specified boolean property
        */
        set(property: Internal.BooleanProperty_, value: boolean): this;
        /**
         * Cycles the property
        */
        cycle<T extends Internal.Comparable<T>>(property: Internal.Property_<T>): this;
        /**
         * Rotate the block using the specified Rotation
        */
        rotate(rotation: Internal.Rotation_): this;
        /**
         * Sets the value of the specified integer property
        */
        set(property: Internal.IntegerProperty_, value: number): this;
        /**
         * Updates the shape of this block. Mostly used in waterloggable blocks to update the water flow
        */
        updateShape(direction: Internal.Direction_, blockState: Internal.BlockState_, levelAccessor: Internal.LevelAccessor_, blockPos: BlockPos_, blockPos2: BlockPos_): this;
        /**
         * Gets the state. If it has been modified, gets the new state
        */
        getState(): Internal.BlockState;
        /**
         * Sets the value of the specified integer property
        */
        "set(net.minecraft.world.level.block.state.properties.IntegerProperty,java.lang.Integer)"(property: Internal.IntegerProperty_, value: number): this;
        /**
         * Mirror the block using the specified Mirror
        */
        mirror(mirror: Internal.Mirror_): this;
        toString(): string;
        notifyAll(): void;
        /**
         * Gets the value of the pased in property
        */
        get<T extends Internal.Comparable<T>>(property: Internal.Property_<T>): T;
        /**
         * Sets the value of the specified property
        */
        setValue<T extends Internal.Comparable<T>, V extends T>(property: Internal.Property_<T>, comparable: V): this;
        /**
         * Sets the value of the specified boolean property
        */
        "set(net.minecraft.world.level.block.state.properties.BooleanProperty,boolean)"(property: Internal.BooleanProperty_, value: boolean): this;
        populateNeighbours(map: Internal.Map_<Internal.Map<Internal.Property<any>, Internal.Comparable<any>>, Internal.BlockState>): this;
        /**
         * Sets the value of the specified enum property
        */
        set<T extends Internal.Enum<T> & Internal.StringRepresentable>(property: Internal.EnumProperty_<T>, value: string): this;
        hashCode(): number;
        /**
         * Get the properties this block has that can be changed
        */
        getProperties(): Internal.Collection<Internal.Property<any>>;
        wait(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        /**
         * Gets the value of the passed in property as an Optional. If the property does not exist in this block the Optional will be empty
        */
        getOptionalValue<T extends Internal.Comparable<T>>(property: Internal.Property_<T>): Optional<T>;
        get class(): typeof any
        /**
         * Get a map of this blocks properties to it's value
        */
        get values(): Internal.ImmutableMap<Internal.Property<any>, Internal.Comparable<any>>
        /**
         * Gets the state. If it has been modified, gets the new state
        */
        get state(): Internal.BlockState
        /**
         * Get the properties this block has that can be changed
        */
        get properties(): Internal.Collection<Internal.Property<any>>
    }
    type BlockStateModifyCallbackJS_ = BlockStateModifyCallbackJS;
    abstract class ConcurrentHashMap$CollectionView <K, V, E> implements Internal.Collection<E>, Internal.Serializable {
        getClass(): typeof any;
        abstract add(arg0: E): boolean;
        parallelStream(): Internal.Stream<E>;
        isEmpty(): boolean;
        notify(): void;
        getMap(): Internal.ConcurrentHashMap<K, V>;
        wait(arg0: number, arg1: number): void;
        retainAll(arg0: Internal.Collection_<any>): boolean;
        containsAll(arg0: Internal.Collection_<any>): boolean;
        toArray<T>(arg0: Internal.IntFunction_<T[]>): T[];
        abstract contains(arg0: any): boolean;
        abstract addAll(arg0: Internal.Collection_<E>): boolean;
        toString(): string;
        forEach(arg0: Internal.Consumer_<E>): void;
        notifyAll(): void;
        toArray<T>(arg0: T[]): T[];
        "toArray(java.lang.Object[])"<T>(arg0: T[]): T[];
        abstract remove(arg0: any): boolean;
        "toArray(java.util.function.IntFunction)"<T>(arg0: Internal.IntFunction_<T[]>): T[];
        toArray(): any[];
        abstract iterator(): Internal.Iterator<E>;
        size(): number;
        abstract hashCode(): number;
        stream(): Internal.Stream<E>;
        removeAll(arg0: Internal.Collection_<any>): boolean;
        wait(): void;
        clear(): void;
        removeIf(arg0: Internal.Predicate_<E>): boolean;
        wait(arg0: number): void;
        spliterator(): Internal.Spliterator<E>;
        abstract equals(arg0: any): boolean;
        get class(): typeof any
        get empty(): boolean
        get map(): Internal.ConcurrentHashMap<K, V>
    }
    type ConcurrentHashMap$CollectionView_<K, V, E> = ConcurrentHashMap$CollectionView<K, V, E>;
    class DateTimeFormatter {
        static ofPattern(arg0: string, arg1: Internal.Locale_): Internal.DateTimeFormatter;
        getClass(): typeof any;
        withChronology(arg0: Internal.Chronology_): this;
        parse(arg0: Internal.CharSequence_): Internal.TemporalAccessor;
        static parsedExcessDays(): Internal.TemporalQuery<Internal.Period>;
        parse<T>(arg0: Internal.CharSequence_, arg1: Internal.TemporalQuery_<T>): T;
        parse(arg0: Internal.CharSequence_, arg1: Internal.ParsePosition_): Internal.TemporalAccessor;
        "withResolverFields(java.time.temporal.TemporalField[])"(...arg0: Internal.TemporalField_[]): this;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        localizedBy(arg0: Internal.Locale_): this;
        "withResolverFields(java.util.Set)"(arg0: Internal.Set_<Internal.TemporalField>): this;
        getZone(): Internal.ZoneId;
        withResolverStyle(arg0: Internal.ResolverStyle_): this;
        parseBest(arg0: Internal.CharSequence_, ...arg1: Internal.TemporalQuery_<any>[]): Internal.TemporalAccessor;
        toFormat(arg0: Internal.TemporalQuery_<any>): Internal.Format;
        static ofLocalizedDate(arg0: Internal.FormatStyle_): Internal.DateTimeFormatter;
        static parsedLeapSecond(): Internal.TemporalQuery<boolean>;
        formatTo(arg0: Internal.TemporalAccessor_, arg1: Internal.Appendable_): void;
        static ofLocalizedDateTime(arg0: Internal.FormatStyle_, arg1: Internal.FormatStyle_): Internal.DateTimeFormatter;
        withResolverFields(...arg0: Internal.TemporalField_[]): this;
        withDecimalStyle(arg0: Internal.DecimalStyle_): this;
        getChronology(): Internal.Chronology;
        toString(): string;
        toFormat(): Internal.Format;
        withResolverFields(arg0: Internal.Set_<Internal.TemporalField>): this;
        withLocale(arg0: Internal.Locale_): this;
        notifyAll(): void;
        getResolverStyle(): Internal.ResolverStyle;
        static ofPattern(arg0: string): Internal.DateTimeFormatter;
        static ofLocalizedDateTime(arg0: Internal.FormatStyle_): Internal.DateTimeFormatter;
        parseUnresolved(arg0: Internal.CharSequence_, arg1: Internal.ParsePosition_): Internal.TemporalAccessor;
        getResolverFields(): Internal.Set<Internal.TemporalField>;
        format(arg0: Internal.TemporalAccessor_): string;
        withZone(arg0: Internal.ZoneId_): this;
        hashCode(): number;
        getLocale(): Internal.Locale;
        "parse(java.lang.CharSequence,java.time.temporal.TemporalQuery)"<T>(arg0: Internal.CharSequence_, arg1: Internal.TemporalQuery_<T>): T;
        wait(): void;
        getDecimalStyle(): Internal.DecimalStyle;
        wait(arg0: number): void;
        "parse(java.lang.CharSequence,java.text.ParsePosition)"(arg0: Internal.CharSequence_, arg1: Internal.ParsePosition_): Internal.TemporalAccessor;
        equals(arg0: any): boolean;
        static ofLocalizedTime(arg0: Internal.FormatStyle_): Internal.DateTimeFormatter;
        get class(): typeof any
        get zone(): Internal.ZoneId
        get chronology(): Internal.Chronology
        get resolverStyle(): Internal.ResolverStyle
        get resolverFields(): Internal.Set<Internal.TemporalField>
        get locale(): Internal.Locale
        get decimalStyle(): Internal.DecimalStyle
        static readonly ISO_DATE: (Internal.DateTimeFormatter) & (Internal.DateTimeFormatter);
        static readonly ISO_WEEK_DATE: (Internal.DateTimeFormatter) & (Internal.DateTimeFormatter);
        static readonly ISO_OFFSET_DATE_TIME: (Internal.DateTimeFormatter) & (Internal.DateTimeFormatter);
        static readonly ISO_TIME: (Internal.DateTimeFormatter) & (Internal.DateTimeFormatter);
        static readonly ISO_ORDINAL_DATE: (Internal.DateTimeFormatter) & (Internal.DateTimeFormatter);
        static readonly ISO_OFFSET_TIME: (Internal.DateTimeFormatter) & (Internal.DateTimeFormatter);
        static readonly ISO_LOCAL_DATE_TIME: (Internal.DateTimeFormatter) & (Internal.DateTimeFormatter);
        static readonly ISO_OFFSET_DATE: (Internal.DateTimeFormatter) & (Internal.DateTimeFormatter);
        static readonly BASIC_ISO_DATE: (Internal.DateTimeFormatter) & (Internal.DateTimeFormatter);
        static readonly ISO_INSTANT: (Internal.DateTimeFormatter) & (Internal.DateTimeFormatter);
        static readonly ISO_LOCAL_DATE: (Internal.DateTimeFormatter) & (Internal.DateTimeFormatter);
        static readonly RFC_1123_DATE_TIME: (Internal.DateTimeFormatter) & (Internal.DateTimeFormatter);
        static readonly ISO_LOCAL_TIME: (Internal.DateTimeFormatter) & (Internal.DateTimeFormatter);
        static readonly ISO_DATE_TIME: (Internal.DateTimeFormatter) & (Internal.DateTimeFormatter);
        static readonly ISO_ZONED_DATE_TIME: (Internal.DateTimeFormatter) & (Internal.DateTimeFormatter);
    }
    type DateTimeFormatter_ = DateTimeFormatter;
    class DirectionProperty extends Internal.EnumProperty<Internal.Direction> {
        static create<T extends Internal.Enum<T> & Internal.StringRepresentable>($$0: string, $$1: T): Internal.EnumProperty<T>;
        getClass(): typeof any;
        static create<T extends Internal.Enum<T> & Internal.StringRepresentable>($$0: string, $$1: T, $$2: Internal.Predicate_<T>): Internal.EnumProperty<T>;
        getName($$0: Internal.Direction_): string;
        static "create(java.lang.String,java.util.function.Predicate)"(name: string, filter: Internal.Predicate_<any>): Internal.DirectionProperty;
        generateHashCode(): number;
        static create($$0: string): Internal.DirectionProperty;
        value($$0: Internal.StateHolder_<any, any>): Internal.Property$Value<Internal.Direction>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        static "create(java.lang.String,net.minecraft.core.Direction[])"($$0: string, ...$$1: Internal.Direction_[]): Internal.DirectionProperty;
        static "create(java.lang.String,java.lang.Class,java.lang.Object[])"<T extends Internal.Enum<T> & Internal.StringRepresentable>($$0: string, $$1: T, ...$$2: T[]): Internal.EnumProperty<T>;
        static create($$0: string, $$1: Internal.Collection_<Internal.Direction>): Internal.DirectionProperty;
        codec(): Internal.Codec<Internal.Direction>;
        getValue($$0: string): Optional<Internal.Direction>;
        getName(): string;
        "getName(java.lang.Comparable)"(arg0: Internal.Comparable_<any>): string;
        getAllValues(): Internal.Stream<Internal.Property$Value<Internal.Direction>>;
        static create<T extends Internal.Enum<T> & Internal.StringRepresentable>($$0: string, $$1: T, ...$$2: T[]): Internal.EnumProperty<T>;
        static create($$0: string, ...$$1: Internal.Direction_[]): Internal.DirectionProperty;
        getPossibleValues(): Internal.Collection<Internal.Direction>;
        static "create(java.lang.String,java.lang.Class,java.util.function.Predicate)"<T extends Internal.Enum<T> & Internal.StringRepresentable>($$0: string, $$1: T, $$2: Internal.Predicate_<T>): Internal.EnumProperty<T>;
        getValueClass(): typeof Internal.Direction;
        static create(name: string, filter: Internal.Predicate_<any>): Internal.DirectionProperty;
        toString(): string;
        valueCodec(): Internal.Codec<Internal.Property$Value<Internal.Direction>>;
        notifyAll(): void;
        static "create(java.lang.String,java.lang.Class,java.util.Collection)"<T extends Internal.Enum<T> & Internal.StringRepresentable>($$0: string, $$1: T, $$2: Internal.Collection_<T>): Internal.EnumProperty<T>;
        static create<T extends Internal.Enum<T> & Internal.StringRepresentable>($$0: string, $$1: T, $$2: Internal.Collection_<T>): Internal.EnumProperty<T>;
        getName(arg0: Internal.Comparable_<any>): string;
        parseValue<U, S extends Internal.StateHolder<any, S>>($$0: Internal.DynamicOps_<U>, $$1: S, $$2: U): Internal.DataResult<S>;
        "value(net.minecraft.core.Direction)"($$0: Internal.Direction_): Internal.Property$Value<Internal.Direction>;
        hashCode(): number;
        static "create(java.lang.String,java.util.Collection)"($$0: string, $$1: Internal.Collection_<Internal.Direction>): Internal.DirectionProperty;
        "getName(net.minecraft.core.Direction)"($$0: Internal.Direction_): string;
        static "create(java.lang.String,java.lang.Class)"<T extends Internal.Enum<T> & Internal.StringRepresentable>($$0: string, $$1: T): Internal.EnumProperty<T>;
        wait(): void;
        value($$0: Internal.Direction_): Internal.Property$Value<Internal.Direction>;
        wait(arg0: number): void;
        equals($$0: any): boolean;
        "value(net.minecraft.world.level.block.state.StateHolder)"($$0: Internal.StateHolder_<any, any>): Internal.Property$Value<Internal.Direction>;
        get class(): typeof any
        get name(): string
        get allValues(): Internal.Stream<Internal.Property$Value<Internal.Direction>>
        get possibleValues(): Internal.Collection<Internal.Direction>
        get valueClass(): typeof Internal.Direction
    }
    type DirectionProperty_ = DirectionProperty;
    interface ReplacementMatch {
        of(o: any): this;
        readonly NONE: Internal.ReplacementMatch;
    }
    type ReplacementMatch_ = ReplacementMatch | any_;
    interface SimpleOptionAccessor <T> {
        abstract setCodec(arg0: Internal.Codec_<T>): void;
        set codec(arg0: Internal.Codec_<T>)
        (arg0: Internal.Codec<T>): void;
    }
    type SimpleOptionAccessor_<T> = ((arg0: Internal.Codec<T>)=> void) | SimpleOptionAccessor<T>;
    interface BonemealableBlock {
        abstract isBonemealSuccess(arg0: Internal.Level_, arg1: Internal.RandomSource_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        abstract performBonemeal(arg0: Internal.ServerLevel_, arg1: Internal.RandomSource_, arg2: BlockPos_, arg3: Internal.BlockState_): void;
        abstract isValidBonemealTarget(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: boolean): boolean;
    }
    type BonemealableBlock_ = BonemealableBlock;
    interface ChunkTrackerHolder {
        get(world: Internal.ClientLevel_): me.jellysquid.mods.sodium.client.render.chunk.map.ChunkTracker;
        abstract sodium$getTracker(): me.jellysquid.mods.sodium.client.render.chunk.map.ChunkTracker;
        (): me.jellysquid.mods.sodium.client.render.chunk.map.ChunkTracker_;
    }
    type ChunkTrackerHolder_ = ChunkTrackerHolder | (()=> me.jellysquid.mods.sodium.client.render.chunk.map.ChunkTracker_);
    class KeyPair implements Internal.Serializable {
        constructor(arg0: Internal.PublicKey_, arg1: Internal.PrivateKey_)
        getClass(): typeof any;
        hashCode(): number;
        getPublic(): Internal.PublicKey;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getPrivate(): Internal.PrivateKey;
        get class(): typeof any
        get "public"(): Internal.PublicKey
        get "private"(): Internal.PrivateKey
    }
    type KeyPair_ = KeyPair;
    class ShimmeringArmorItem extends Internal.ArmorItem implements me.fzzyhmstrs.fzzy_core.mana_util.ManaItem {
        constructor(material: Internal.ArmorMaterial_, type: Internal.ArmorItem$Type_, settings: Internal.Item$Properties_)
        onTick(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        getType(): Internal.ArmorItem$Type;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        addModifierTooltip(stack: Internal.ItemStack_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_, type: Internal.ModifierHelperType_<any>): void;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        setAttributeModifiers(arg0: Internal.Multimap_<any, any>): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        checkCanUse(stack: Internal.ItemStack_, world: Internal.Level_, entity: Internal.LivingEntity_, amount: number, message: net.minecraft.network.chat.Component_): boolean;
        moonlight$getClientAnimationExtension(): any;
        fzzy_core_correctSlot(slot: Internal.EquipmentSlot_): boolean;
        getCreativeTab(): string;
        static checkCanUse$default(arg0: me.fzzyhmstrs.fzzy_core.mana_util.ManaItem_, arg1: Internal.ItemStack_, arg2: Internal.Level_, arg3: Internal.LivingEntity_, arg4: number, arg5: net.minecraft.network.chat.Component_, arg6: number, arg7: any): boolean;
        postWearerHit(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        modifierObjectPredicate(livingEntity: Internal.LivingEntity_, stack: Internal.ItemStack_): ResourceLocation;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        static burnOutHandler$default(arg0: me.fzzyhmstrs.fzzy_core.mana_util.ManaItem_, arg1: Internal.ItemStack_, arg2: Internal.Enchantment_, arg3: Internal.LivingEntity_, arg4: net.minecraft.network.chat.Component_, arg5: number, arg6: any): void;
        healDamage(amount: number, stack: Internal.ItemStack_): number;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        static get($$0: Internal.ItemStack_): Internal.Equipable;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        kjs$getAttributeMap(): Internal.Multimap<any, any>;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getDefense(): number;
        kjs$getMutableAttributeMap(): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        getModifiers(stack: Internal.ItemStack_, type: Internal.ModifierHelperType_<any>): Internal.List<ResourceLocation>;
        fzzy_core_getCorrectSlot(): Internal.EquipmentSlot;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static access$getAttributeModifiers$s830519506($this: Internal.ShimmeringArmorItem_, slot: Internal.EquipmentSlot_): Internal.Multimap<any, any>;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        getEquipmentSlot(): Internal.EquipmentSlot;
        onWearerKilledOther(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, victim: Internal.LivingEntity_, world: Internal.ServerLevel_): void;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        canBeModifiedBy(type: Internal.ModifierHelperType_<any>): boolean;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        static dispenseArmor($$0: Internal.BlockSource_, $$1: Internal.ItemStack_): boolean;
        getMaterial(): Internal.ArmorMaterial;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        incrementKillCount(stack: Internal.ItemStack_): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        static access$burnOutHandler$jd($this: me.fzzyhmstrs.fzzy_core.mana_util.ManaItem_, stack: Internal.ItemStack_, aug: Internal.Enchantment_, entity: Internal.LivingEntity_, message: net.minecraft.network.chat.Component_): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        getEquipSound(): Internal.SoundEvent;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        defaultModifiers(type: Internal.ModifierHelperType_<any>): Internal.List<any>;
        static access$healDamage$jd($this: me.fzzyhmstrs.fzzy_core.mana_util.ManaItem_, amount: number, stack: Internal.ItemStack_): number;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        static access$manaDamage$jd($this: me.fzzyhmstrs.fzzy_core.mana_util.ManaItem_, stack: Internal.ItemStack_, world: Internal.Level_, entity: Internal.LivingEntity_, amount: number, message: net.minecraft.network.chat.Component_, unbreakingFlag: boolean): boolean;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        static access$checkCanUse$jd($this: me.fzzyhmstrs.fzzy_core.mana_util.ManaItem_, stack: Internal.ItemStack_, world: Internal.Level_, entity: Internal.LivingEntity_, amount: number, message: net.minecraft.network.chat.Component_): boolean;
        setFireResistant(arg0: boolean): void;
        manaDamage(stack: Internal.ItemStack_, world: Internal.Level_, entity: Internal.LivingEntity_, amount: number, message: net.minecraft.network.chat.Component_, unbreakingFlag: boolean): boolean;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        onAttack(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, attacker: Internal.LivingEntity_, source: DamageSource_, amount: number): number;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers(slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        getToughness(): number;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        static manaDamage$default(arg0: me.fzzyhmstrs.fzzy_core.mana_util.ManaItem_, arg1: Internal.ItemStack_, arg2: Internal.Level_, arg3: Internal.LivingEntity_, arg4: number, arg5: net.minecraft.network.chat.Component_, arg6: boolean, arg7: number, arg8: any): boolean;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        burnOutHandler(stack: Internal.ItemStack_, aug: Internal.Enchantment_, entity: Internal.LivingEntity_, message: net.minecraft.network.chat.Component_): void;
        static access$getMODIFIERS$p($this: Internal.ShimmeringArmorItem_): Internal.EnumMap<any, any>;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick(stack: Internal.ItemStack_, world: Internal.Level_, entity: Internal.Entity_, slot: number, selected: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getKillCount(stack: Internal.ItemStack_): number;
        getTypeItemStackKey(): Internal.ItemStackKey;
        onWearerDamaged(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, attacker: Internal.LivingEntity_, source: DamageSource_, amount: number): number;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        getRepairTime(): number;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        postWearerMine(stack: Internal.ItemStack_, world: Internal.Level_, state: Internal.BlockState_, pos: BlockPos_, miner: Internal.Player_): void;
        kjs$setAttributeMap(arg0: Internal.Multimap_<any, any>): void;
        swapWithEquipmentSlot($$0: Internal.Item_, $$1: Internal.Level_, $$2: Internal.Player_, $$3: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get type(): Internal.ArmorItem$Type
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        set attributeModifiers(arg0: Internal.Multimap_<any, any>)
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        get defense(): number
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get equipmentSlot(): Internal.EquipmentSlot
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        get material(): Internal.ArmorMaterial
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get equipSound(): Internal.SoundEvent
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get toughness(): number
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        get repairTime(): number
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type ShimmeringArmorItem_ = ShimmeringArmorItem;
    interface IEMFModel {
        abstract emf$getEMFRootModel(): Internal.EMFModelPartRoot;
        abstract emf$isEMFModel(): boolean;
    }
    type IEMFModel_ = IEMFModel;
    class BlazingGemItem extends Internal.IgnitedGemItem {
        constructor(settings: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        giveTooltipHint(nbt: Internal.CompoundTag_, stack: Internal.ItemStack_, tooltip: Internal.List_<net.minecraft.network.chat.Component>): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        blazingGemCheck(stack: Internal.ItemStack_, inventory: Internal.Inventory_, player: Internal.LivingEntity_, damageSource: DamageSource_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        getModifier(): ResourceLocation;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        get modifier(): ResourceLocation
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type BlazingGemItem_ = BlazingGemItem;
}
declare namespace com.supermartijn642.fusion.api.util {
    interface Serializer <T> {
        abstract deserialize(json: Internal.JsonObject_): T;
        abstract serialize(data: T): Internal.JsonObject;
    }
    type Serializer_<T> = Serializer<T>;
}
