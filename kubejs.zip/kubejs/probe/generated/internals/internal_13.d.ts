/// <reference path="./internal_*.d.ts" />
declare namespace net.fabricmc.fabric.mixin.transfer {
    interface BucketItemAccessor {
        abstract fabric_getFluid(): Internal.Fluid;
        (): Internal.Fluid_;
    }
    type BucketItemAccessor_ = (()=> Internal.Fluid_) | BucketItemAccessor;
}
declare namespace vazkii.botania.mixin {
    interface DispenserBlockAccessor {
        getDispenserRegistry(): Internal.Map<Internal.Item, Internal.DispenseItemBehavior>;
        get dispenserRegistry(): Internal.Map<Internal.Item, Internal.DispenseItemBehavior>
    }
    type DispenserBlockAccessor_ = DispenserBlockAccessor;
}
declare namespace me.fzzyhmstrs.fzzy_core.registry.variant {
    class Variant {
        constructor(texture: ResourceLocation_)
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        getTexture(): ResourceLocation;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        get texture(): ResourceLocation
    }
    type Variant_ = Variant | Special.ChorseVariants;
}
declare namespace Internal {
    class ElvenTradeRecipe$Serializer implements Internal.RecipeSerializer<vazkii.botania.common.crafting.ElvenTradeRecipe> {
        constructor()
        getClass(): typeof any;
        toNetwork(buf: Internal.FriendlyByteBuf_, recipe: vazkii.botania.common.crafting.ElvenTradeRecipe_): void;
        "toNetwork(net.minecraft.network.FriendlyByteBuf,vazkii.botania.common.crafting.ElvenTradeRecipe)"(buf: Internal.FriendlyByteBuf_, recipe: vazkii.botania.common.crafting.ElvenTradeRecipe_): void;
        "fromNetwork(net.minecraft.resources.ResourceLocation,net.minecraft.network.FriendlyByteBuf)"(arg0: ResourceLocation_, arg1: Internal.FriendlyByteBuf_): Internal.Recipe<any>;
        fromJson(id: ResourceLocation_, json: Internal.JsonObject_): vazkii.botania.common.crafting.ElvenTradeRecipe;
        toString(): string;
        "toNetwork(net.minecraft.network.FriendlyByteBuf,net.minecraft.world.item.crafting.Recipe)"(arg0: Internal.FriendlyByteBuf_, arg1: Internal.Recipe_<any>): void;
        notifyAll(): void;
        "fromJson(net.minecraft.resources.ResourceLocation,com.google.gson.JsonObject)"(id: ResourceLocation_, json: Internal.JsonObject_): vazkii.botania.common.crafting.ElvenTradeRecipe;
        toNetwork(arg0: Internal.FriendlyByteBuf_, arg1: Internal.Recipe_<any>): void;
        notify(): void;
        "fromJson(net.minecraft.resources.ResourceLocation,com.google.gson.JsonObject)"(arg0: ResourceLocation_, arg1: Internal.JsonObject_): Internal.Recipe<any>;
        wait(arg0: number, arg1: number): void;
        static register<S extends Internal.RecipeSerializer<T>, T extends Internal.Recipe<any>>($$0: string, $$1: S): S;
        hashCode(): number;
        fromJson(arg0: ResourceLocation_, arg1: Internal.JsonObject_): Internal.Recipe<any>;
        fromNetwork(id: ResourceLocation_, buf: Internal.FriendlyByteBuf_): vazkii.botania.common.crafting.ElvenTradeRecipe;
        wait(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        "fromNetwork(net.minecraft.resources.ResourceLocation,net.minecraft.network.FriendlyByteBuf)"(id: ResourceLocation_, buf: Internal.FriendlyByteBuf_): vazkii.botania.common.crafting.ElvenTradeRecipe;
        fromNetwork(arg0: ResourceLocation_, arg1: Internal.FriendlyByteBuf_): Internal.Recipe<any>;
        get class(): typeof any
    }
    type ElvenTradeRecipe$Serializer_ = ElvenTradeRecipe$Serializer;
    class ItemPriorityKey extends Internal.ItemKey {
        constructor(level: number, nextLevel: number, properties: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, worldIn: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, flagIn: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        getDescription(): net.minecraft.network.chat.Component;
        asIngredient(): Internal.Ingredient;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn(context: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(level: Internal.Level_, player: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        getNextKey(): this;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock(state: Internal.BlockState_, worldIn: Internal.Level_, pos: BlockPos_, player: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        get nextKey(): Internal.ItemPriorityKey
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type ItemPriorityKey_ = ItemPriorityKey;
    interface IMixinBossHealthOverlay {
        abstract get_events_FancyMenu(): Internal.Map<Internal.UUID, Internal.LerpingBossEvent>;
        get _events_FancyMenu(): Internal.Map<Internal.UUID, Internal.LerpingBossEvent>
        (): Internal.Map_<Internal.UUID, Internal.LerpingBossEvent>;
    }
    type IMixinBossHealthOverlay_ = (()=> Internal.Map_<Internal.UUID, Internal.LerpingBossEvent>) | IMixinBossHealthOverlay;
    class WorldTemplatePaginatedList extends Internal.ValueObject {
        constructor()
        constructor($$0: number)
        getClass(): typeof any;
        isLastPage(): boolean;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        static parse($$0: string): Internal.WorldTemplatePaginatedList;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        get lastPage(): boolean
        templates: Internal.List<Internal.WorldTemplate>;
        page: number;
        size: number;
        total: number;
    }
    type WorldTemplatePaginatedList_ = WorldTemplatePaginatedList;
    interface LocalRef <T> {
        abstract get(): T;
        abstract set(arg0: T): void;
    }
    type LocalRef_<T> = LocalRef<T>;
    class BlockSourceImpl implements Internal.BlockSource {
        constructor($$0: Internal.ServerLevel_, $$1: BlockPos_)
        getClass(): typeof any;
        getLevel(): Internal.ServerLevel;
        toString(): string;
        getEntity<T extends Internal.BlockEntity>(): T;
        getBlockState(): Internal.BlockState;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getPos(): BlockPos;
        z(): number;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        y(): number;
        x(): number;
        get class(): typeof any
        get level(): Internal.ServerLevel
        get entity(): T
        get blockState(): Internal.BlockState
        get pos(): BlockPos
    }
    type BlockSourceImpl_ = BlockSourceImpl;
    abstract class PropertyValue <T extends Internal.PropertyValue<T, J>, J> extends Internal.AbstractProperty<T> {
        constructor()
        constructor(value: J)
        getClass(): typeof any;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        fulfillsConditions(): boolean;
        deserialize(object: Internal.JsonObject_): void;
        abstract deserializeValue(value: Internal.JsonElement_): J;
        abstract serializeValue(): Internal.JsonElement;
        merge(other: T): T;
        static addValueTransformer<T extends Internal.PropertyValue<T, J>, J>(clazz: J, constructor_: Internal.Function_<J, Internal.PropertyValue<T, J>>): void;
        applyProperties(): T;
        toString(): string;
        static init(): void;
        abstract copy(): T;
        notifyAll(): void;
        serialize(): Internal.JsonObject;
        isHidden(): boolean;
        findPropertiesOf<E extends Internal.AbstractProperty<any>>(property: E): Internal.List<E>;
        findProperty<P extends Internal.AbstractProperty<P>>(property: P): Optional<P>;
        hashCode(): number;
        findProperties(predicate: Internal.Predicate_<Internal.AbstractProperty<any>>): Internal.List<Internal.AbstractProperty<any>>;
        addPropertyJson(json: Internal.JsonObject_): Internal.AbstractDocumentBase<T>;
        wait(): void;
        wait(arg0: number): void;
        getValue(): J;
        equals(o: any): boolean;
        hasProperty<P extends Internal.AbstractProperty<P>>(property: P): boolean;
        get class(): typeof any
        get hidden(): boolean
        get value(): J
        static VALUES_REGISTRY: ({[key: typeof any]: any, [key: typeof any]: any, [key: typeof any]: any, [key: typeof any]: any, [key: typeof any]: any, [key: typeof any]: any, [key: typeof any]: any}) & (Internal.Map<typeof any, Internal.Function<any, Internal.PropertyValue<any, any>>>);
    }
    type PropertyValue_<T extends Internal.PropertyValue<T, J>, J> = PropertyValue<T, J>;
    class BookTemplate {
        constructor()
        getClass(): typeof any;
        toString(): string;
        static registerComponent(name: ResourceLocation_, clazz: typeof Internal.TemplateComponent): void;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        mouseClicked(page: vazkii.patchouli.client.book.BookPage_, mouseX: number, mouseY: number, mouseButton: number): boolean;
        static createTemplate(book: Internal.Book_, builder: Internal.BookContentsBuilder_, type: string, inclusion: Internal.TemplateInclusion_): Internal.BookTemplate;
        hashCode(): number;
        render(graphics: Internal.GuiGraphics_, page: vazkii.patchouli.client.book.BookPage_, mouseX: number, mouseY: number, pticks: number): void;
        onDisplayed(page: vazkii.patchouli.client.book.BookPage_, parent: Internal.GuiBookEntry_, left: number, top: number): void;
        wait(): void;
        build(builder: Internal.BookContentsBuilder_, page: vazkii.patchouli.client.book.BookPage_, entry: Internal.BookEntry_, pageNum: number): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        compile(level: Internal.Level_, builder: Internal.BookContentsBuilder_, variables: Internal.IVariableProvider_): void;
        get class(): typeof any
        static readonly componentTypes: ({[key: ResourceLocation]: typeof any, [key: ResourceLocation]: typeof any, [key: ResourceLocation]: typeof any, [key: ResourceLocation]: typeof any, [key: ResourceLocation]: typeof any, [key: ResourceLocation]: typeof any, [key: ResourceLocation]: typeof any, [key: ResourceLocation]: typeof any, [key: ResourceLocation]: typeof any}) & (Internal.HashMap<ResourceLocation, typeof Internal.TemplateComponent>);
    }
    type BookTemplate_ = BookTemplate;
    class ThrowablePotionItem extends Internal.PotionItem {
        constructor($$0: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        getDescriptionId(): string;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        handler$nbo000$things$consume(stack: Internal.ItemStack_, world: Internal.Level_, user: Internal.LivingEntity_, cir: Internal.CallbackInfoReturnable_<any>): void;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type ThrowablePotionItem_ = ThrowablePotionItem;
    class WeightedEntry$Wrapper <T> implements Internal.WeightedEntry {
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        static wrap<T>($$0: T, $$1: number): Internal.WeightedEntry$Wrapper<T>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        static codec<E>($$0: Internal.Codec_<E>): Internal.Codec<Internal.WeightedEntry$Wrapper<E>>;
        hashCode(): number;
        wait(): void;
        getWeight(): Internal.Weight;
        getData(): T;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        get class(): typeof any
        get weight(): Internal.Weight
        get data(): T
    }
    type WeightedEntry$Wrapper_<T> = WeightedEntry$Wrapper<T>;
    class RootCommandNode <S> extends Internal.CommandNode<S> {
        constructor()
        getClass(): typeof any;
        getRelevantNodes(arg0: Internal.StringReader_): Internal.Collection<Internal.CommandNode<S>>;
        parse(arg0: Internal.StringReader_, arg1: Internal.CommandContextBuilder_<S>): void;
        canUse(arg0: S): boolean;
        listSuggestions(arg0: Internal.CommandContext_<S>, arg1: Internal.SuggestionsBuilder_): Internal.CompletableFuture<Internal.Suggestions>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        "compareTo(com.mojang.brigadier.tree.CommandNode)"(arg0: Internal.CommandNode_<S>): number;
        compareTo(arg0: any): number;
        getRedirectModifier(): Internal.RedirectModifier<S>;
        isValidInput(arg0: string): boolean;
        getRequirement(): Internal.Predicate<S>;
        getExamples(): Internal.Collection<string>;
        addChild(arg0: Internal.CommandNode_<S>): void;
        getName(): string;
        getRedirect(): Internal.CommandNode<S>;
        findAmbiguities(arg0: Internal.AmbiguityConsumer_<S>): void;
        getChildren(): Internal.Collection<Internal.CommandNode<S>>;
        toString(): string;
        createBuilder(): Internal.ArgumentBuilder<S, any>;
        notifyAll(): void;
        getUsageText(): string;
        hashCode(): number;
        wait(): void;
        compareTo(arg0: Internal.CommandNode_<S>): number;
        wait(arg0: number): void;
        isFork(): boolean;
        getChild(arg0: string): Internal.CommandNode<S>;
        getCommand(): Internal.Command<S>;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        get class(): typeof any
        get redirectModifier(): Internal.RedirectModifier<S>
        get requirement(): Internal.Predicate<S>
        get examples(): Internal.Collection<string>
        get name(): string
        get redirect(): Internal.CommandNode<S>
        get children(): Internal.Collection<Internal.CommandNode<S>>
        get usageText(): string
        get fork(): boolean
        get command(): Internal.Command<S>
    }
    type RootCommandNode_<S> = RootCommandNode<S>;
    interface BooleanConsumer {
        abstract accept(arg0: boolean): void;
        (arg0: boolean): void;
    }
    type BooleanConsumer_ = ((arg0: boolean)=> void) | BooleanConsumer;
    class GingerbreadManBaseItem extends Internal.Item {
        constructor()
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(itemstack: Internal.ItemStack_, world: Internal.Level_, list: Internal.List_<net.minecraft.network.chat.Component>, flag: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration(itemstack: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type GingerbreadManBaseItem_ = GingerbreadManBaseItem;
    class WaterlilyBlock extends Internal.BushBlock {
        constructor($$0: Internal.BlockBehaviour$Properties_)
        /**
         * @deprecated
        */
        getOcclusionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        /**
         * @deprecated
        */
        getSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        axiom$customPickBlockStack(): Internal.ItemStack;
        getSoundType($$0: Internal.BlockState_): SoundType;
        /**
         * @deprecated
        */
        getVisualShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        handler$efo000$collective$Block_playerDestroy(level: Internal.Level_, player: Internal.Player_, blockPos: BlockPos_, blockState: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number, $$5: number): void;
        /**
         * @deprecated
        */
        randomTick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: Internal.BlockEntity_): void;
        static canSupportRigidBlock($$0: Internal.BlockGetter_, $$1: BlockPos_): boolean;
        static popResource($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.ItemStack_): void;
        setRandomTickCallback(callback: Internal.Consumer_<any>): void;
        getDescriptionId(): string;
        stepOn($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Entity_): void;
        fallOn($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: BlockPos_, $$3: Internal.Entity_, $$4: number): void;
        getSettings(): Internal.BlockBehaviour$Properties;
        getExplosionResistance(): number;
        asItem(): Internal.Item;
        /**
         * @deprecated
        */
        triggerEvent($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: number, $$4: number): boolean;
        getTypeData(): Internal.CompoundTag;
        setFriction(arg0: number): void;
        /**
         * @deprecated
        */
        getRenderShape($$0: Internal.BlockState_): Internal.RenderShape;
        canCull(): boolean;
        customShapeUpdate(blockState: Internal.CustomBlockState_, levelReader: Internal.LevelReader_, blockPos: BlockPos_): Internal.CustomBlockState;
        getJumpFactor(): number;
        getSpeedFactor(): number;
        static canSupportCenter($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        skipRendering($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getLightBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        playerDestroy($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.BlockEntity_, $$5: Internal.ItemStack_): void;
        shouldAttemptToCull(state: Internal.BlockState_): boolean;
        isPossibleToRespawnInThis($$0: Internal.BlockState_): boolean;
        getCustomStateForPlacement(blockPlaceContext: Internal.BlockPlaceContext_): Internal.CustomBlockState;
        /**
         * @deprecated
        */
        getDirectSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        getProperties(): Internal.BlockBehaviour$Properties;
        playerWillDestroy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Player_): void;
        getClass(): typeof any;
        getMaxVerticalOffset(): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.item.context.BlockPlaceContext)"($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        useShapeForLightOcclusion($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        getDrops($$0: Internal.BlockState_, $$1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getStateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>;
        entityInside($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Entity_): void;
        setBlockBuilder(b: Internal.BlockBuilder_): void;
        handler$ldb000$puzzleslib$playerDestroy$0(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        setRequiresTool(v: boolean): void;
        setSpeedFactor(arg0: number): void;
        axiom$getPossibleCustomStates(): Internal.List<any>;
        getPlant(world: Internal.BlockGetter_, pos: BlockPos_): Internal.BlockState;
        setExplosionResistance(arg0: number): void;
        toString(): string;
        port_lib$popExperience(arg0: Internal.ServerLevel_, arg1: BlockPos_, arg2: number): void;
        notifyAll(): void;
        getToolModifiedState(state: Internal.BlockState_, world: Internal.Level_, pos: BlockPos_, player: Internal.Player_, stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): Internal.BlockState;
        getId(): string;
        getLootTable(): ResourceLocation;
        puzzleslib$setItem(arg0: Internal.Item_): void;
        axiom$translationKey(): string;
        /**
         * @deprecated
        */
        getInteractionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        propagatesSkylightDown($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        setPlacedBy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.LivingEntity_, $$4: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        onPlace($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Block>;
        static popResourceFromFace($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.ItemStack_): void;
        getFriction(): number;
        handlePrecipitation($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Biome$Precipitation_): void;
        /**
         * @deprecated
        */
        hasAnalogOutputSignal($$0: Internal.BlockState_): boolean;
        wait(arg0: number): void;
        /**
         * @deprecated
        */
        getFluidState($$0: Internal.BlockState_): Internal.FluidState;
        handler$koh000$porting_lib_entity$getDestroySpeed(blockState: Internal.BlockState_, player: Internal.Player_, blockGetter: Internal.BlockGetter_, pos: BlockPos_, cir: Internal.CallbackInfoReturnable_<any>): void;
        /**
         * @deprecated
        */
        getAnalogOutputSignal($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): number;
        handler$efo000$collective$Block_setPlacedBy(level: Internal.Level_, blockPos: BlockPos_, blockState: Internal.BlockState_, livingEntity: Internal.LivingEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        tick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        supportsExternalFaceHiding(state: Internal.BlockState_): boolean;
        handler$ldb000$puzzleslib$playerDestroy$1(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        notify(): void;
        axiom$asItemStack(): Internal.ItemStack;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        neighborChanged($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Block_, $$4: BlockPos_, $$5: boolean): void;
        handler$zhd000$additionalentityattributes$additionalEntityAttributes$saveBreakingPlayer(world: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, stack: Internal.ItemStack_, callbackInfo: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        getBlockSupportShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        canSustainPlant(state: Internal.BlockState_, world: Internal.BlockGetter_, pos: BlockPos_, facing: Internal.Direction_, plantable: Internal.IPlantable_): boolean;
        /**
         * @deprecated
        */
        isCollisionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static isFaceFull($$0: Internal.VoxelShape_, $$1: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getMenuProvider($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): Internal.MenuProvider;
        static byItem($$0: Internal.Item_): Internal.Block;
        static updateFromNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        updateIndirectNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: number, $$4: number): void;
        destroy($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): void;
        handler$fdc000$everycomp$addSimpleFastECdrops(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, cir: Internal.CallbackInfoReturnable_<any>, resId: ResourceLocation_, lootParams: Internal.LootParams_, serverLevel: Internal.ServerLevel_, lootTable: Internal.LootTable_): void;
        getToolModifiedState(state: Internal.BlockState_, context: Internal.UseOnContext_, toolAction: Internal.ToolAction_, simulate: boolean): Internal.BlockState;
        /**
         * @deprecated
        */
        use($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_, $$4: Internal.InteractionHand_, $$5: Internal.BlockHitResult_): Internal.InteractionResult;
        setLightEmission(v: number): void;
        doNormalInteractions(): boolean;
        setJumpFactor(arg0: number): void;
        canSurvive($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): void;
        /**
         * @deprecated
        */
        getShadeBrightness($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        getAppearance(state: Internal.BlockState_, renderView: Internal.BlockAndTintGetter_, pos: BlockPos_, side: Internal.Direction_, sourceState: Internal.BlockState_, sourcePos: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        getCollisionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        setDestroySpeed(v: number): void;
        defaultBlockState(): Internal.BlockState;
        usesCustomShouldDrawFace(state: Internal.BlockState_): boolean;
        getStateForPlacement($$0: Internal.BlockPlaceContext_): Internal.BlockState;
        cantCullAgainst(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        mayPlaceOn($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        arch$holder(): Internal.Holder<Internal.Block>;
        wait(): void;
        getCloneItemStack($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        hasDynamicShape(): boolean;
        getMaxHorizontalOffset(): number;
        /**
         * @deprecated
        */
        getDestroyProgress($$0: Internal.BlockState_, $$1: Internal.Player_, $$2: Internal.BlockGetter_, $$3: BlockPos_): number;
        /**
         * @deprecated
        */
        getSeed($$0: Internal.BlockState_, $$1: BlockPos_): number;
        defaultDestroyTime(): number;
        updateShape($$0: Internal.BlockState_, $$1: Internal.Direction_, $$2: Internal.BlockState_, $$3: Internal.LevelAccessor_, $$4: BlockPos_, $$5: BlockPos_): Internal.BlockState;
        dropFromExplosion($$0: Internal.Explosion_): boolean;
        getPlantType(world: Internal.BlockGetter_, pos: BlockPos_): Internal.PlantType;
        isRandomlyTicking($$0: Internal.BlockState_): boolean;
        static isShapeFullBlock(shape: Internal.VoxelShape_): boolean;
        withPropertiesOf($$0: Internal.BlockState_): Internal.BlockState;
        static isExceptionForConnection($$0: Internal.BlockState_): boolean;
        setIsRandomlyTicking(arg0: boolean): void;
        hidesNeighborFace(level: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, neighborState: Internal.BlockState_, dir: Internal.Direction_): boolean;
        onTreeGrow(state: Internal.BlockState_, level: Internal.LevelReader_, placeFunction: Internal.BiConsumer_<BlockPos, Internal.BlockState>, randomSource: Internal.RandomSource_, pos: BlockPos_, config: Internal.TreeConfiguration_): boolean;
        /**
         * @deprecated
        */
        rotate($$0: Internal.BlockState_, $$1: Internal.Rotation_): Internal.BlockState;
        defaultMapColor(): Internal.MapColor;
        getStateAtViewpoint(state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_, viewpoint: Vec3d_): Internal.BlockState;
        wait(arg0: number, arg1: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.BlockGetter_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        setNameKey(arg0: string): void;
        static box($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): Internal.VoxelShape;
        /**
         * @deprecated
        */
        mirror($$0: Internal.BlockState_, $$1: Internal.Mirror_): Internal.BlockState;
        wasExploded($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Explosion_): void;
        getName(): Internal.MutableComponent;
        updateEntityAfterFallOn($$0: Internal.BlockGetter_, $$1: Internal.Entity_): void;
        modifyReturnValue$mio000$supplementaries$mayPlaceOn(original: boolean, state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_): boolean;
        animateTick($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        customShouldDrawFace(view: Internal.BlockGetter_, thisState: Internal.BlockState_, sideState: Internal.BlockState_, thisPos: BlockPos_, sidePos: BlockPos_, side: Internal.Direction_): Optional<boolean>;
        axiom$getResourceLocation(): ResourceLocation;
        arch$registryName(): ResourceLocation;
        axiom$getProperties(): Internal.Collection<any>;
        getBlockBuilder(): Internal.BlockBuilder;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        isSignalSource($$0: Internal.BlockState_): boolean;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number): void;
        /**
         * @deprecated
        */
        attack($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): void;
        getShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        shouldAttemptToCull(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        onProjectileHit($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockHitResult_, $$3: Internal.Projectile_): void;
        static stateById($$0: number): Internal.BlockState;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): Internal.List<Internal.ItemStack>;
        requiredFeatures(): Internal.FeatureFlagSet;
        hashCode(): number;
        axiom$defaultCustomState(): Internal.CustomBlockState;
        setCanCull(canCull: boolean): void;
        /**
         * @deprecated
        */
        isOcclusionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static getId($$0: Internal.BlockState_): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.material.Fluid)"($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        static pushEntitiesUp($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): Internal.BlockState;
        isPathfindable($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.PathComputationType_): boolean;
        setSoundType(arg0: SoundType_): void;
        handler$cef000$betterend$be_getDroppedStacks(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, info: Internal.CallbackInfoReturnable_<any>): void;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_): Internal.List<Internal.ItemStack>;
        /**
         * @deprecated
        */
        onRemove($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        cantCullAgainst(state: Internal.BlockState_): boolean;
        setHasCollision(arg0: boolean): void;
        static shouldRenderFace($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_, $$4: BlockPos_): boolean;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        spawnAfterBreak($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.ItemStack_, $$4: boolean): void;
        set randomTickCallback(callback: Internal.Consumer_<any>)
        get descriptionId(): string
        get settings(): Internal.BlockBehaviour$Properties
        get explosionResistance(): number
        get typeData(): Internal.CompoundTag
        set friction(arg0: number)
        get jumpFactor(): number
        get speedFactor(): number
        get properties(): Internal.BlockBehaviour$Properties
        get class(): typeof any
        get maxVerticalOffset(): number
        get stateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>
        set blockBuilder(b: Internal.BlockBuilder_)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        set speedFactor(arg0: number)
        set explosionResistance(arg0: number)
        get id(): string
        get lootTable(): ResourceLocation
        get friction(): number
        set lightEmission(v: number)
        set jumpFactor(arg0: number)
        set destroySpeed(v: number)
        get maxHorizontalOffset(): number
        set isRandomlyTicking(arg0: boolean)
        set nameKey(arg0: string)
        get name(): Internal.MutableComponent
        get blockBuilder(): Internal.BlockBuilder
        get idLocation(): ResourceLocation
        get mod(): string
        set canCull(canCull: boolean)
        set soundType(arg0: SoundType_)
        set hasCollision(arg0: boolean)
    }
    type WaterlilyBlock_ = WaterlilyBlock;
    class FogType extends Internal.Enum<Internal.FogType> {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        toString(): string;
        static values(): Internal.FogType[];
        notifyAll(): void;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.FogType>>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        name(): string;
        hashCode(): number;
        ordinal(): number;
        wait(): void;
        "compareTo(net.minecraft.world.level.material.FogType)"(arg0: Internal.FogType_): number;
        wait(arg0: number): void;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        static valueOf($$0: string): Internal.FogType;
        compareTo(arg0: Internal.FogType_): number;
        getDeclaringClass(): typeof Internal.FogType;
        get class(): typeof any
        get declaringClass(): typeof Internal.FogType
        static readonly LAVA: (Internal.FogType) & (Internal.FogType);
        static readonly POWDER_SNOW: (Internal.FogType) & (Internal.FogType);
        static readonly WATER: (Internal.FogType) & (Internal.FogType);
        static readonly NONE: (Internal.FogType) & (Internal.FogType);
    }
    type FogType_ = "powder_snow" | "lava" | FogType | "water" | "none";
    class TippedRuniteArrowItem extends Internal.TippedArrowItem {
        constructor(settings: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        createArrow(world: Internal.Level_, stack: Internal.ItemStack_, shooter: Internal.LivingEntity_): Internal.AbstractArrow;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId(stack: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type TippedRuniteArrowItem_ = TippedRuniteArrowItem;
    interface IMixinSoundEngine {
        abstract getLoadedMelody(): boolean;
        get loadedMelody(): boolean
        (): boolean;
    }
    type IMixinSoundEngine_ = IMixinSoundEngine | (()=> boolean);
    interface IExtendedNoiseGeneratorSettings {
        abstract setRegionType(arg0: Internal.RegionType_): void;
        abstract getRegionType(): Internal.RegionType;
        set regionType(arg0: Internal.RegionType_)
        get regionType(): Internal.RegionType
    }
    type IExtendedNoiseGeneratorSettings_ = IExtendedNoiseGeneratorSettings;
    class BottleItem extends Internal.Item {
        constructor($$0: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type BottleItem_ = BottleItem;
    interface ManaProficiencyArmor {
        shouldGiveProficiency(armorStack: Internal.ItemStack_, slot: Internal.EquipmentSlot_, player: Internal.Player_, rod: Internal.ItemStack_): boolean;
    }
    type ManaProficiencyArmor_ = ManaProficiencyArmor;
    interface Blaze3dRenderTargetExt {
        abstract iris$getColorBufferVersion(): number;
        abstract iris$getDepthBufferVersion(): number;
    }
    type Blaze3dRenderTargetExt_ = Blaze3dRenderTargetExt;
    interface Scriptable extends Internal.IdEnumerationIterator {
        abstract "delete(dev.latvian.mods.rhino.Context,int)"(arg0: Internal.Context_, arg1: number): void;
        abstract hasInstance(arg0: Internal.Context_, arg1: Internal.Scriptable_): boolean;
        abstract "get(dev.latvian.mods.rhino.Context,java.lang.String,dev.latvian.mods.rhino.Scriptable)"(arg0: Internal.Context_, arg1: string, arg2: Internal.Scriptable_): any;
        abstract get(arg0: Internal.Context_, arg1: number, arg2: Internal.Scriptable_): any;
        abstract put(arg0: Internal.Context_, arg1: number, arg2: Internal.Scriptable_, arg3: any): void;
        abstract getClassName(): string;
        abstract "delete"(arg0: Internal.Context_, arg1: string): void;
        abstract "has(dev.latvian.mods.rhino.Context,java.lang.String,dev.latvian.mods.rhino.Scriptable)"(arg0: Internal.Context_, arg1: string, arg2: Internal.Scriptable_): boolean;
        abstract "delete"(arg0: Internal.Context_, arg1: number): void;
        abstract setParentScope(arg0: Internal.Scriptable_): void;
        abstract "put(dev.latvian.mods.rhino.Context,java.lang.String,dev.latvian.mods.rhino.Scriptable,java.lang.Object)"(arg0: Internal.Context_, arg1: string, arg2: Internal.Scriptable_, arg3: any): void;
        abstract has(arg0: Internal.Context_, arg1: string, arg2: Internal.Scriptable_): boolean;
        abstract getDefaultValue(arg0: Internal.Context_, arg1: typeof any): any;
        abstract has(arg0: Internal.Context_, arg1: number, arg2: Internal.Scriptable_): boolean;
        getTypeOf(): Internal.MemberType;
        abstract getIds(arg0: Internal.Context_): any[];
        abstract getPrototype(arg0: Internal.Context_): this;
        abstract get(arg0: Internal.Context_, arg1: string, arg2: Internal.Scriptable_): any;
        abstract getParentScope(): this;
        abstract "put(dev.latvian.mods.rhino.Context,int,dev.latvian.mods.rhino.Scriptable,java.lang.Object)"(arg0: Internal.Context_, arg1: number, arg2: Internal.Scriptable_, arg3: any): void;
        getAllIds(cx: Internal.Context_): any[];
        enumerationIteratorHasNext(cx: Internal.Context_, currentId: Internal.Consumer_<any>): boolean;
        abstract "delete(dev.latvian.mods.rhino.Context,java.lang.String)"(arg0: Internal.Context_, arg1: string): void;
        abstract "get(dev.latvian.mods.rhino.Context,int,dev.latvian.mods.rhino.Scriptable)"(arg0: Internal.Context_, arg1: number, arg2: Internal.Scriptable_): any;
        enumerationIteratorNext(cx: Internal.Context_, currentId: Internal.Consumer_<any>): boolean;
        abstract "has(dev.latvian.mods.rhino.Context,int,dev.latvian.mods.rhino.Scriptable)"(arg0: Internal.Context_, arg1: number, arg2: Internal.Scriptable_): boolean;
        abstract setPrototype(arg0: Internal.Scriptable_): void;
        abstract put(arg0: Internal.Context_, arg1: string, arg2: Internal.Scriptable_, arg3: any): void;
        get className(): string
        set parentScope(arg0: Internal.Scriptable_)
        get typeOf(): Internal.MemberType
        get parentScope(): Internal.Scriptable
        set prototype(arg0: Internal.Scriptable_)
        readonly NOT_FOUND: (Internal.UniqueTag) & (any);
    }
    type Scriptable_ = Scriptable;
    class NarrationThunk <T> {
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        static from($$0: net.minecraft.network.chat.Component_): Internal.NarrationThunk<any>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        static from($$0: Internal.List_<net.minecraft.network.chat.Component>): Internal.NarrationThunk<any>;
        hashCode(): number;
        getText($$0: Internal.Consumer_<string>): void;
        static from($$0: string): Internal.NarrationThunk<any>;
        wait(): void;
        wait(arg0: number): void;
        static "from(java.util.List)"($$0: Internal.List_<net.minecraft.network.chat.Component>): Internal.NarrationThunk<any>;
        equals($$0: any): boolean;
        static "from(java.lang.String)"($$0: string): Internal.NarrationThunk<any>;
        static "from(net.minecraft.network.chat.Component)"($$0: net.minecraft.network.chat.Component_): Internal.NarrationThunk<any>;
        get class(): typeof any
        static readonly EMPTY: Internal.NarrationThunk<any>;
    }
    type NarrationThunk_<T> = NarrationThunk<T>;
    class JsonArray extends Internal.JsonElement implements Internal.Iterable<Internal.JsonElement> {
        constructor()
        constructor(arg0: number)
        asList(): Internal.List<Internal.JsonElement>;
        "add(com.google.gson.JsonElement)"(arg0: Internal.JsonElement_): void;
        add(arg0: number): void;
        notify(): void;
        contains(arg0: Internal.JsonElement_): boolean;
        getAsLong(): number;
        isJsonArray(): boolean;
        add(arg0: Internal.JsonElement_): void;
        remove(arg0: number): Internal.JsonElement;
        add(arg0: string): void;
        forEach(arg0: Internal.Consumer_<Internal.JsonElement>): void;
        /**
         * @deprecated
        */
        getAsCharacter(): string;
        getAsByte(): number;
        "add(java.lang.Boolean)"(arg0: boolean): void;
        wait(): void;
        add(arg0: string): void;
        getAsShort(): number;
        add(arg0: boolean): void;
        getClass(): typeof any;
        iterator(): Internal.Iterator<Internal.JsonElement>;
        getAsBigDecimal(): Internal.BigDecimal;
        spliterator(): Internal.Spliterator<Internal.JsonElement>;
        isEmpty(): boolean;
        wait(arg0: number, arg1: number): void;
        getAsJsonPrimitive(): Internal.JsonPrimitive;
        getAsFloat(): number;
        remove(arg0: Internal.JsonElement_): boolean;
        isJsonObject(): boolean;
        getAsJsonArray(): this;
        "add(java.lang.Character)"(arg0: string): void;
        deepCopy(): Internal.JsonElement;
        getAsBoolean(): boolean;
        "remove(com.google.gson.JsonElement)"(arg0: Internal.JsonElement_): boolean;
        "add(java.lang.String)"(arg0: string): void;
        isJsonNull(): boolean;
        isJsonPrimitive(): boolean;
        toString(): string;
        "remove(int)"(arg0: number): Internal.JsonElement;
        notifyAll(): void;
        "add(java.lang.Number)"(arg0: number): void;
        getAsBigInteger(): Internal.BigInteger;
        set(arg0: number, arg1: Internal.JsonElement_): Internal.JsonElement;
        getAsDouble(): number;
        hashCode(): number;
        size(): number;
        getAsString(): string;
        getAsInt(): number;
        getAsNumber(): number;
        addAll(arg0: Internal.JsonArray_): void;
        get(arg0: number): Internal.JsonElement;
        getAsJsonObject(): Internal.JsonObject;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        getAsJsonNull(): Internal.JsonNull;
        get asLong(): number
        get jsonArray(): boolean
        /**
         * @deprecated
        */
        get asCharacter(): string
        get asByte(): number
        get asShort(): number
        get class(): typeof any
        get asBigDecimal(): Internal.BigDecimal
        get empty(): boolean
        get asJsonPrimitive(): Internal.JsonPrimitive
        get asFloat(): number
        get jsonObject(): boolean
        get asJsonArray(): Internal.JsonArray
        get asBoolean(): boolean
        get jsonNull(): boolean
        get jsonPrimitive(): boolean
        get asBigInteger(): Internal.BigInteger
        get asDouble(): number
        get asString(): string
        get asInt(): number
        get asNumber(): number
        get asJsonObject(): Internal.JsonObject
        get asJsonNull(): Internal.JsonNull
    }
    type JsonArray_ = JsonArray;
    class DeadBushBlock extends Internal.BushBlock implements Internal.IShearable {
        constructor($$0: Internal.BlockBehaviour$Properties_)
        /**
         * @deprecated
        */
        getOcclusionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        isShearable(item: Internal.ItemStack_, world: Internal.Level_, pos: BlockPos_): boolean;
        /**
         * @deprecated
        */
        getSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        axiom$customPickBlockStack(): Internal.ItemStack;
        getSoundType($$0: Internal.BlockState_): SoundType;
        /**
         * @deprecated
        */
        getVisualShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        handler$efo000$collective$Block_playerDestroy(level: Internal.Level_, player: Internal.Player_, blockPos: BlockPos_, blockState: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number, $$5: number): void;
        /**
         * @deprecated
        */
        randomTick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: Internal.BlockEntity_): void;
        static canSupportRigidBlock($$0: Internal.BlockGetter_, $$1: BlockPos_): boolean;
        static popResource($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.ItemStack_): void;
        setRandomTickCallback(callback: Internal.Consumer_<any>): void;
        getDescriptionId(): string;
        stepOn($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Entity_): void;
        fallOn($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: BlockPos_, $$3: Internal.Entity_, $$4: number): void;
        getSettings(): Internal.BlockBehaviour$Properties;
        getExplosionResistance(): number;
        asItem(): Internal.Item;
        /**
         * @deprecated
        */
        triggerEvent($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: number, $$4: number): boolean;
        getTypeData(): Internal.CompoundTag;
        setFriction(arg0: number): void;
        /**
         * @deprecated
        */
        getRenderShape($$0: Internal.BlockState_): Internal.RenderShape;
        canCull(): boolean;
        customShapeUpdate(blockState: Internal.CustomBlockState_, levelReader: Internal.LevelReader_, blockPos: BlockPos_): Internal.CustomBlockState;
        getJumpFactor(): number;
        getSpeedFactor(): number;
        static canSupportCenter($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.Direction_): boolean;
        onSheared(player: Internal.Player_, item: Internal.ItemStack_, world: Internal.Level_, pos: BlockPos_, fortune: number): Internal.List<Internal.ItemStack>;
        /**
         * @deprecated
        */
        skipRendering($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getLightBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        playerDestroy($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.BlockEntity_, $$5: Internal.ItemStack_): void;
        shouldAttemptToCull(state: Internal.BlockState_): boolean;
        isPossibleToRespawnInThis($$0: Internal.BlockState_): boolean;
        getCustomStateForPlacement(blockPlaceContext: Internal.BlockPlaceContext_): Internal.CustomBlockState;
        /**
         * @deprecated
        */
        getDirectSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        getProperties(): Internal.BlockBehaviour$Properties;
        playerWillDestroy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Player_): void;
        getClass(): typeof any;
        getMaxVerticalOffset(): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.item.context.BlockPlaceContext)"($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        useShapeForLightOcclusion($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        getDrops($$0: Internal.BlockState_, $$1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getStateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>;
        /**
         * @deprecated
        */
        entityInside($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Entity_): void;
        setBlockBuilder(b: Internal.BlockBuilder_): void;
        handler$ldb000$puzzleslib$playerDestroy$0(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        setRequiresTool(v: boolean): void;
        setSpeedFactor(arg0: number): void;
        axiom$getPossibleCustomStates(): Internal.List<any>;
        getPlant(world: Internal.BlockGetter_, pos: BlockPos_): Internal.BlockState;
        setExplosionResistance(arg0: number): void;
        toString(): string;
        port_lib$popExperience(arg0: Internal.ServerLevel_, arg1: BlockPos_, arg2: number): void;
        notifyAll(): void;
        getToolModifiedState(state: Internal.BlockState_, world: Internal.Level_, pos: BlockPos_, player: Internal.Player_, stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): Internal.BlockState;
        getId(): string;
        getLootTable(): ResourceLocation;
        puzzleslib$setItem(arg0: Internal.Item_): void;
        axiom$translationKey(): string;
        /**
         * @deprecated
        */
        getInteractionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        propagatesSkylightDown($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        setPlacedBy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.LivingEntity_, $$4: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        onPlace($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Block>;
        static popResourceFromFace($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.ItemStack_): void;
        getFriction(): number;
        handlePrecipitation($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Biome$Precipitation_): void;
        /**
         * @deprecated
        */
        hasAnalogOutputSignal($$0: Internal.BlockState_): boolean;
        wait(arg0: number): void;
        /**
         * @deprecated
        */
        getFluidState($$0: Internal.BlockState_): Internal.FluidState;
        handler$koh000$porting_lib_entity$getDestroySpeed(blockState: Internal.BlockState_, player: Internal.Player_, blockGetter: Internal.BlockGetter_, pos: BlockPos_, cir: Internal.CallbackInfoReturnable_<any>): void;
        /**
         * @deprecated
        */
        getAnalogOutputSignal($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): number;
        handler$efo000$collective$Block_setPlacedBy(level: Internal.Level_, blockPos: BlockPos_, blockState: Internal.BlockState_, livingEntity: Internal.LivingEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        tick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        supportsExternalFaceHiding(state: Internal.BlockState_): boolean;
        handler$ldb000$puzzleslib$playerDestroy$1(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        notify(): void;
        axiom$asItemStack(): Internal.ItemStack;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        neighborChanged($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Block_, $$4: BlockPos_, $$5: boolean): void;
        handler$zhd000$additionalentityattributes$additionalEntityAttributes$saveBreakingPlayer(world: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, stack: Internal.ItemStack_, callbackInfo: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        getBlockSupportShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        canSustainPlant(state: Internal.BlockState_, world: Internal.BlockGetter_, pos: BlockPos_, facing: Internal.Direction_, plantable: Internal.IPlantable_): boolean;
        /**
         * @deprecated
        */
        isCollisionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static isFaceFull($$0: Internal.VoxelShape_, $$1: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getMenuProvider($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): Internal.MenuProvider;
        static byItem($$0: Internal.Item_): Internal.Block;
        static updateFromNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        updateIndirectNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: number, $$4: number): void;
        destroy($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): void;
        handler$fdc000$everycomp$addSimpleFastECdrops(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, cir: Internal.CallbackInfoReturnable_<any>, resId: ResourceLocation_, lootParams: Internal.LootParams_, serverLevel: Internal.ServerLevel_, lootTable: Internal.LootTable_): void;
        getToolModifiedState(state: Internal.BlockState_, context: Internal.UseOnContext_, toolAction: Internal.ToolAction_, simulate: boolean): Internal.BlockState;
        /**
         * @deprecated
        */
        use($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_, $$4: Internal.InteractionHand_, $$5: Internal.BlockHitResult_): Internal.InteractionResult;
        setLightEmission(v: number): void;
        doNormalInteractions(): boolean;
        setJumpFactor(arg0: number): void;
        canSurvive($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): void;
        /**
         * @deprecated
        */
        getShadeBrightness($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        getAppearance(state: Internal.BlockState_, renderView: Internal.BlockAndTintGetter_, pos: BlockPos_, side: Internal.Direction_, sourceState: Internal.BlockState_, sourcePos: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        getCollisionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        setDestroySpeed(v: number): void;
        defaultBlockState(): Internal.BlockState;
        usesCustomShouldDrawFace(state: Internal.BlockState_): boolean;
        getStateForPlacement($$0: Internal.BlockPlaceContext_): Internal.BlockState;
        cantCullAgainst(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        mayPlaceOn($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        arch$holder(): Internal.Holder<Internal.Block>;
        wait(): void;
        getCloneItemStack($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        hasDynamicShape(): boolean;
        getMaxHorizontalOffset(): number;
        /**
         * @deprecated
        */
        getDestroyProgress($$0: Internal.BlockState_, $$1: Internal.Player_, $$2: Internal.BlockGetter_, $$3: BlockPos_): number;
        /**
         * @deprecated
        */
        getSeed($$0: Internal.BlockState_, $$1: BlockPos_): number;
        defaultDestroyTime(): number;
        updateShape($$0: Internal.BlockState_, $$1: Internal.Direction_, $$2: Internal.BlockState_, $$3: Internal.LevelAccessor_, $$4: BlockPos_, $$5: BlockPos_): Internal.BlockState;
        dropFromExplosion($$0: Internal.Explosion_): boolean;
        getPlantType(world: Internal.BlockGetter_, pos: BlockPos_): Internal.PlantType;
        isRandomlyTicking($$0: Internal.BlockState_): boolean;
        static isShapeFullBlock(shape: Internal.VoxelShape_): boolean;
        withPropertiesOf($$0: Internal.BlockState_): Internal.BlockState;
        static isExceptionForConnection($$0: Internal.BlockState_): boolean;
        setIsRandomlyTicking(arg0: boolean): void;
        hidesNeighborFace(level: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, neighborState: Internal.BlockState_, dir: Internal.Direction_): boolean;
        onTreeGrow(state: Internal.BlockState_, level: Internal.LevelReader_, placeFunction: Internal.BiConsumer_<BlockPos, Internal.BlockState>, randomSource: Internal.RandomSource_, pos: BlockPos_, config: Internal.TreeConfiguration_): boolean;
        /**
         * @deprecated
        */
        rotate($$0: Internal.BlockState_, $$1: Internal.Rotation_): Internal.BlockState;
        defaultMapColor(): Internal.MapColor;
        getStateAtViewpoint(state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_, viewpoint: Vec3d_): Internal.BlockState;
        wait(arg0: number, arg1: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.BlockGetter_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        setNameKey(arg0: string): void;
        static box($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): Internal.VoxelShape;
        /**
         * @deprecated
        */
        mirror($$0: Internal.BlockState_, $$1: Internal.Mirror_): Internal.BlockState;
        wasExploded($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Explosion_): void;
        getName(): Internal.MutableComponent;
        updateEntityAfterFallOn($$0: Internal.BlockGetter_, $$1: Internal.Entity_): void;
        modifyReturnValue$mio000$supplementaries$mayPlaceOn(original: boolean, state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_): boolean;
        animateTick($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        customShouldDrawFace(view: Internal.BlockGetter_, thisState: Internal.BlockState_, sideState: Internal.BlockState_, thisPos: BlockPos_, sidePos: BlockPos_, side: Internal.Direction_): Optional<boolean>;
        axiom$getResourceLocation(): ResourceLocation;
        arch$registryName(): ResourceLocation;
        axiom$getProperties(): Internal.Collection<any>;
        getBlockBuilder(): Internal.BlockBuilder;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        isSignalSource($$0: Internal.BlockState_): boolean;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number): void;
        /**
         * @deprecated
        */
        attack($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): void;
        getShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        shouldAttemptToCull(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        onProjectileHit($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockHitResult_, $$3: Internal.Projectile_): void;
        static stateById($$0: number): Internal.BlockState;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): Internal.List<Internal.ItemStack>;
        requiredFeatures(): Internal.FeatureFlagSet;
        hashCode(): number;
        axiom$defaultCustomState(): Internal.CustomBlockState;
        setCanCull(canCull: boolean): void;
        /**
         * @deprecated
        */
        isOcclusionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static getId($$0: Internal.BlockState_): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.material.Fluid)"($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        static pushEntitiesUp($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): Internal.BlockState;
        isPathfindable($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.PathComputationType_): boolean;
        setSoundType(arg0: SoundType_): void;
        handler$cef000$betterend$be_getDroppedStacks(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, info: Internal.CallbackInfoReturnable_<any>): void;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_): Internal.List<Internal.ItemStack>;
        /**
         * @deprecated
        */
        onRemove($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        cantCullAgainst(state: Internal.BlockState_): boolean;
        setHasCollision(arg0: boolean): void;
        static shouldRenderFace($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_, $$4: BlockPos_): boolean;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        spawnAfterBreak($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.ItemStack_, $$4: boolean): void;
        set randomTickCallback(callback: Internal.Consumer_<any>)
        get descriptionId(): string
        get settings(): Internal.BlockBehaviour$Properties
        get explosionResistance(): number
        get typeData(): Internal.CompoundTag
        set friction(arg0: number)
        get jumpFactor(): number
        get speedFactor(): number
        get properties(): Internal.BlockBehaviour$Properties
        get class(): typeof any
        get maxVerticalOffset(): number
        get stateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>
        set blockBuilder(b: Internal.BlockBuilder_)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        set speedFactor(arg0: number)
        set explosionResistance(arg0: number)
        get id(): string
        get lootTable(): ResourceLocation
        get friction(): number
        set lightEmission(v: number)
        set jumpFactor(arg0: number)
        set destroySpeed(v: number)
        get maxHorizontalOffset(): number
        set isRandomlyTicking(arg0: boolean)
        set nameKey(arg0: string)
        get name(): Internal.MutableComponent
        get blockBuilder(): Internal.BlockBuilder
        get idLocation(): ResourceLocation
        get mod(): string
        set canCull(canCull: boolean)
        set soundType(arg0: SoundType_)
        set hasCollision(arg0: boolean)
    }
    type DeadBushBlock_ = DeadBushBlock;
    interface ServerPlayerAccessor {
        abstract invokeInitMenu(arg0: Internal.AbstractContainerMenu_): void;
        abstract invokeNextContainerCounter(): void;
        abstract getContainerCounter(): number;
        get containerCounter(): number
    }
    type ServerPlayerAccessor_ = ServerPlayerAccessor;
    interface MenuProvider extends Internal.NamedScreenHandlerFactoryMixin, Internal.FabricScreenHandlerFactory, Internal.MenuConstructor {
        abstract getDisplayName(): net.minecraft.network.chat.Component;
        shouldCloseCurrentScreen(): boolean;
        abstract createMenu(arg0: number, arg1: Internal.Inventory_, arg2: Internal.Player_): Internal.AbstractContainerMenu;
        get displayName(): net.minecraft.network.chat.Component
    }
    type MenuProvider_ = MenuProvider;
    class AlloyForgeRecipeSerializer implements Internal.RecipeSerializer<Internal.AlloyForgeRecipe> {
        constructor()
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        "read(net.minecraft.resources.ResourceLocation,net.minecraft.network.FriendlyByteBuf)"(id: ResourceLocation_, buf: Internal.FriendlyByteBuf_): Internal.AlloyForgeRecipe;
        write(buf: Internal.FriendlyByteBuf_, recipe: Internal.AlloyForgeRecipe_): void;
        toNetwork(arg0: Internal.FriendlyByteBuf_, arg1: Internal.Recipe_<any>): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        static register<S extends Internal.RecipeSerializer<T>, T extends Internal.Recipe<any>>($$0: string, $$1: S): S;
        hashCode(): number;
        fromJson(arg0: ResourceLocation_, arg1: Internal.JsonObject_): Internal.Recipe<any>;
        wait(): void;
        "read(net.minecraft.resources.ResourceLocation,com.google.gson.JsonObject)"(id: ResourceLocation_, json: Internal.JsonObject_): Internal.AlloyForgeRecipe;
        read(id: ResourceLocation_, json: Internal.JsonObject_): Internal.AlloyForgeRecipe;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        read(id: ResourceLocation_, buf: Internal.FriendlyByteBuf_): Internal.AlloyForgeRecipe;
        fromNetwork(arg0: ResourceLocation_, arg1: Internal.FriendlyByteBuf_): Internal.Recipe<any>;
        get class(): typeof any
        static readonly INSTANCE: (Internal.AlloyForgeRecipeSerializer) & (Internal.AlloyForgeRecipeSerializer);
    }
    type AlloyForgeRecipeSerializer_ = AlloyForgeRecipeSerializer;
    class ShapedRecipe implements Internal.AccessorShapedRecipe, Internal.CraftingRecipe {
        constructor($$0: ResourceLocation_, $$1: string, $$2: Internal.CraftingBookCategory_, $$3: number, $$4: number, $$5: Internal.NonNullList_<Internal.Ingredient>, $$6: Internal.ItemStack_)
        constructor($$0: ResourceLocation_, $$1: string, $$2: Internal.CraftingBookCategory_, $$3: number, $$4: number, $$5: Internal.NonNullList_<Internal.Ingredient>, $$6: Internal.ItemStack_, $$7: boolean)
        getGroup(): string;
        static dissolvePattern$bookshelf_$md$424943$3(arg0: string[], arg1: Internal.Map_<any, any>, arg2: number, arg3: number): Internal.NonNullList<any>;
        getToastSymbol(): Internal.ItemStack;
        "matches(net.minecraft.world.inventory.CraftingContainer,net.minecraft.world.level.Level)"($$0: Internal.CraftingContainer_, $$1: Internal.Level_): boolean;
        static keyFromJson$bookshelf_$md$424943$0(arg0: Internal.JsonObject_): Internal.Map<any, any>;
        notify(): void;
        getRemainingItems($$0: Internal.CraftingContainer_): Internal.NonNullList<Internal.ItemStack>;
        assemble($$0: Internal.CraftingContainer_, $$1: Internal.RegistryAccess_): Internal.ItemStack;
        getId(): ResourceLocation;
        isIn(tag: ResourceLocation_): boolean;
        handler$bpa000$bclib$bcl_getRemainingItems(container: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>): void;
        static bookshelf$dissolvePattern(pattern: string[], ingredients: Internal.Map_<string, Internal.Ingredient>, width: number, height: number): Internal.NonNullList<Internal.Ingredient>;
        isSpecial(): boolean;
        getWidth(): number;
        "assemble(net.minecraft.world.inventory.CraftingContainer,net.minecraft.core.RegistryAccess)"($$0: Internal.CraftingContainer_, $$1: Internal.RegistryAccess_): Internal.ItemStack;
        canCraftInDimensions($$0: number, $$1: number): boolean;
        showNotification(): boolean;
        replaceInput(match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): boolean;
        static itemStackFromJson($$0: Internal.JsonObject_): Internal.ItemStack;
        getType(): ResourceLocation;
        static dissolvePattern($$0: string[], $$1: Internal.Map_<string, Internal.Ingredient>, $$2: number, $$3: number): Internal.NonNullList<Internal.Ingredient>;
        "handler$fie000$fabric-item-api-v1$captureStack"(inventory: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>, defaultedList: Internal.NonNullList_<any>, i: number): void;
        wait(): void;
        isIncomplete(): boolean;
        matches($$0: Internal.CraftingContainer_, $$1: number, $$2: number, $$3: boolean): boolean;
        getClass(): typeof any;
        static keyFromJson($$0: Internal.JsonObject_): Internal.Map<string, Internal.Ingredient>;
        matches($$0: Internal.CraftingContainer_, $$1: Internal.Level_): boolean;
        getSchema(): Internal.RecipeSchema;
        "assemble(net.minecraft.world.Container,net.minecraft.core.RegistryAccess)"(arg0: net.minecraft.world.Container_, arg1: Internal.RegistryAccess_): Internal.ItemStack;
        wait(arg0: number, arg1: number): void;
        category(): Internal.CraftingBookCategory;
        static shrink$bookshelf_$md$424943$1(...arg0: string[]): string[];
        getSerializer(): Internal.RecipeSerializer<any>;
        assemble(arg0: net.minecraft.world.Container_, arg1: Internal.RegistryAccess_): Internal.ItemStack;
        static bookshelf$shrink(...pattern: string[]): string[];
        static bookshelf$keyFromJson($$0: Internal.JsonObject_): Internal.Map<string, Internal.Ingredient>;
        matches(arg0: net.minecraft.world.Container_, arg1: Internal.Level_): boolean;
        getHeight(): number;
        getMod(): string;
        getIngredients(): Internal.NonNullList<Internal.Ingredient>;
        hasOutput(match: Internal.ReplacementMatch_): boolean;
        getResultItem($$0: Internal.RegistryAccess_): Internal.ItemStack;
        toString(): string;
        notifyAll(): void;
        "matches(net.minecraft.world.Container,net.minecraft.world.level.Level)"(arg0: net.minecraft.world.Container_, arg1: Internal.Level_): boolean;
        static patternFromJson($$0: Internal.JsonArray_): string[];
        static shrink(...$$0: string[]): string[];
        setGroup(group: string): void;
        static itemFromJson($$0: Internal.JsonObject_): Internal.Item;
        static bookshelf$patternFromJson(json: Internal.JsonArray_): string[];
        hashCode(): number;
        getOrCreateId(): ResourceLocation;
        hasInput(match: Internal.ReplacementMatch_): boolean;
        static patternFromJson$bookshelf_$md$424943$2(arg0: Internal.JsonArray_): string[];
        wait(arg0: number): void;
        replaceOutput(match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): boolean;
        equals(arg0: any): boolean;
        get group(): string
        get toastSymbol(): Internal.ItemStack
        get id(): ResourceLocation
        get special(): boolean
        get width(): number
        get type(): ResourceLocation
        get incomplete(): boolean
        get class(): typeof any
        get schema(): Internal.RecipeSchema
        get serializer(): Internal.RecipeSerializer<any>
        get height(): number
        get mod(): string
        get ingredients(): Internal.NonNullList<Internal.Ingredient>
        set group(group: string)
        get orCreateId(): ResourceLocation
        readonly width: number;
        readonly height: number;
        readonly result: Internal.ItemStack;
    }
    type ShapedRecipe_ = ShapedRecipe;
    class FeatureSizeType <P extends Internal.FeatureSize> {
        getClass(): typeof any;
        codec(): Internal.Codec<P>;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        static readonly THREE_LAYERS_FEATURE_SIZE: Internal.FeatureSizeType<Internal.ThreeLayersFeatureSize>;
        static readonly TWO_LAYERS_FEATURE_SIZE: Internal.FeatureSizeType<Internal.TwoLayersFeatureSize>;
    }
    type FeatureSizeType_<P extends Internal.FeatureSize> = FeatureSizeType<P> | Special.FeatureSizeType;
    class PinkinatorItem extends Internal.Item {
        constructor(builder: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, world: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, flags: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(world: Internal.Level_, player: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type PinkinatorItem_ = PinkinatorItem;
    class LootDataType <T> {
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        deserialize($$0: ResourceLocation_, $$1: Internal.JsonElement_): Optional<T>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        wait(): void;
        static values(): Internal.Stream<Internal.LootDataType<any>>;
        runValidation($$0: Internal.ValidationContext_, $$1: Internal.LootDataId_<T>, $$2: T): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        directory(): string;
        parser(): Internal.Gson;
        get class(): typeof any
        static readonly MODIFIER: Internal.LootDataType<Internal.LootItemFunction>;
        static readonly PREDICATE: Internal.LootDataType<Internal.LootItemCondition>;
        static readonly TABLE: Internal.LootDataType<Internal.LootTable>;
    }
    type LootDataType_<T> = LootDataType<T>;
    /**
     * @deprecated
     * This class is marked to be removed in future!
    */
    class ConsumableItem extends vectorwing.farmersdelight.common.item.ConsumableItem {
        constructor(properties: Internal.Item$Properties_)
        constructor(properties: Internal.Item$Properties_, hasFoodEffectTooltip: boolean)
        constructor(properties: Internal.Item$Properties_, hasFoodEffectTooltip: boolean, hasCustomTooltip: boolean)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, level: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, isAdvanced: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        affectConsumer(stack: Internal.ItemStack_, level: Internal.Level_, consumer: Internal.LivingEntity_): void;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem(stack: Internal.ItemStack_, level: Internal.Level_, consumer: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type ConsumableItem_ = ConsumableItem;
    class OrechidRecipe$Serializer implements Internal.RecipeSerializer<Internal.OrechidRecipe> {
        constructor()
        getClass(): typeof any;
        fromJson(recipeId: ResourceLocation_, json: Internal.JsonObject_): Internal.OrechidRecipe;
        "fromNetwork(net.minecraft.resources.ResourceLocation,net.minecraft.network.FriendlyByteBuf)"(arg0: ResourceLocation_, arg1: Internal.FriendlyByteBuf_): Internal.Recipe<any>;
        toString(): string;
        "toNetwork(net.minecraft.network.FriendlyByteBuf,net.minecraft.world.item.crafting.Recipe)"(arg0: Internal.FriendlyByteBuf_, arg1: Internal.Recipe_<any>): void;
        "toNetwork(net.minecraft.network.FriendlyByteBuf,vazkii.botania.common.crafting.OrechidRecipe)"(buffer: Internal.FriendlyByteBuf_, recipe: Internal.OrechidRecipe_): void;
        notifyAll(): void;
        "fromNetwork(net.minecraft.resources.ResourceLocation,net.minecraft.network.FriendlyByteBuf)"(recipeId: ResourceLocation_, buffer: Internal.FriendlyByteBuf_): Internal.OrechidRecipe;
        toNetwork(arg0: Internal.FriendlyByteBuf_, arg1: Internal.Recipe_<any>): void;
        notify(): void;
        "fromJson(net.minecraft.resources.ResourceLocation,com.google.gson.JsonObject)"(arg0: ResourceLocation_, arg1: Internal.JsonObject_): Internal.Recipe<any>;
        wait(arg0: number, arg1: number): void;
        "fromJson(net.minecraft.resources.ResourceLocation,com.google.gson.JsonObject)"(recipeId: ResourceLocation_, json: Internal.JsonObject_): Internal.OrechidRecipe;
        static register<S extends Internal.RecipeSerializer<T>, T extends Internal.Recipe<any>>($$0: string, $$1: S): S;
        hashCode(): number;
        toNetwork(buffer: Internal.FriendlyByteBuf_, recipe: Internal.OrechidRecipe_): void;
        fromJson(arg0: ResourceLocation_, arg1: Internal.JsonObject_): Internal.Recipe<any>;
        fromNetwork(recipeId: ResourceLocation_, buffer: Internal.FriendlyByteBuf_): Internal.OrechidRecipe;
        wait(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        fromNetwork(arg0: ResourceLocation_, arg1: Internal.FriendlyByteBuf_): Internal.Recipe<any>;
        get class(): typeof any
    }
    type OrechidRecipe$Serializer_ = OrechidRecipe$Serializer;
    interface DynamicLightSource {
        gatherClosestChunks(chunks: Internal.LongSet_, x: number, y: number, z: number): void;
        abstract getDynamicLightChunksToRebuild(arg0: boolean): Internal.LongSet;
        abstract splitIntoDynamicLightEntries(): Internal.Stream<Internal.SpatialLookupEntry>;
    }
    type DynamicLightSource_ = DynamicLightSource;
    class ModifyWakeUpPositionEventJS extends Internal.LivingEntityEventJS {
        constructor(entity: Internal.LivingEntity_, sleepingPos: BlockPos_, bedState: Internal.BlockState_, wakeUpPos: Vec3d_)
        getClass(): typeof any;
        /**
         * Stops the event with default exit value. Execution will be stopped **immediately**.
         * 
         * `exit` denotes a `default` outcome.
        */
        exit(): any;
        /**
         * Cancels the event with the given exit value. Execution will be stopped **immediately**.
         * 
         * `cancel` denotes a `false` outcome.
        */
        cancel(value: any): any;
        setWakeUpPos(block: Internal.BlockContainerJS_): void;
        static handler(entity: Internal.LivingEntity_, sleepingPos: BlockPos_, bedState: Internal.BlockState_, wakeUpPos: Vec3d_): Vec3d;
        getSleepPos(): Internal.BlockContainerJS;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getLevel(): Internal.Level;
        "setWakeUpPos(dev.latvian.mods.kubejs.level.BlockContainerJS)"(block: Internal.BlockContainerJS_): void;
        getPlayer(): Internal.Player;
        "setWakeUpPos(net.minecraft.world.phys.Vec3)"(wakeUpPos: Vec3d_): void;
        toString(): string;
        setWakeUpPos(wakeUpPos: Vec3d_): void;
        getWakeUpPos(): Vec3d;
        setWakeUpPos(x: number, y: number, z: number): void;
        notifyAll(): void;
        /**
         * Stops the event with the given exit value. Execution will be stopped **immediately**.
         * 
         * `exit` denotes a `default` outcome.
        */
        exit(value: any): any;
        /**
         * Stops the event with the given exit value. Execution will be stopped **immediately**.
         * 
         * `success` denotes a `true` outcome.
        */
        success(value: any): any;
        hashCode(): number;
        getEntity(): Internal.Entity;
        getBedState(): Internal.BlockState;
        wait(): void;
        /**
         * Cancels the event with default exit value. Execution will be stopped **immediately**.
         * 
         * `cancel` denotes a `false` outcome.
        */
        cancel(): any;
        wait(arg0: number): void;
        /**
         * Stops the event with default exit value. Execution will be stopped **immediately**.
         * 
         * `success` denotes a `true` outcome.
        */
        success(): any;
        equals(arg0: any): boolean;
        getServer(): Internal.MinecraftServer;
        getSleepingPos(): BlockPos;
        get class(): typeof any
        set wakeUpPos(block: Internal.BlockContainerJS_)
        get sleepPos(): Internal.BlockContainerJS
        get level(): Internal.Level
        set "wakeUpPos(dev.latvian.mods.kubejs.level.BlockContainerJS)"(block: Internal.BlockContainerJS_)
        get player(): Internal.Player
        set "wakeUpPos(net.minecraft.world.phys.Vec3)"(wakeUpPos: Vec3d_)
        set wakeUpPos(wakeUpPos: Vec3d_)
        get wakeUpPos(): Vec3d
        get entity(): Internal.Entity
        get bedState(): Internal.BlockState
        get server(): Internal.MinecraftServer
        get sleepingPos(): BlockPos
    }
    type ModifyWakeUpPositionEventJS_ = ModifyWakeUpPositionEventJS;
    class BannerBlock extends Internal.AbstractBannerBlock {
        constructor($$0: Internal.DyeColor_, $$1: Internal.BlockBehaviour$Properties_)
        /**
         * @deprecated
        */
        getOcclusionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        /**
         * @deprecated
        */
        getSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        axiom$customPickBlockStack(): Internal.ItemStack;
        getSoundType($$0: Internal.BlockState_): SoundType;
        /**
         * @deprecated
        */
        getVisualShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        handler$efo000$collective$Block_playerDestroy(level: Internal.Level_, player: Internal.Player_, blockPos: BlockPos_, blockState: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number, $$5: number): void;
        /**
         * @deprecated
        */
        randomTick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: Internal.BlockEntity_): void;
        static canSupportRigidBlock($$0: Internal.BlockGetter_, $$1: BlockPos_): boolean;
        static popResource($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.ItemStack_): void;
        setRandomTickCallback(callback: Internal.Consumer_<any>): void;
        getDescriptionId(): string;
        stepOn($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Entity_): void;
        fallOn($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: BlockPos_, $$3: Internal.Entity_, $$4: number): void;
        getColor(): Internal.DyeColor;
        getSettings(): Internal.BlockBehaviour$Properties;
        triggerEvent($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: number, $$4: number): boolean;
        getExplosionResistance(): number;
        asItem(): Internal.Item;
        getTypeData(): Internal.CompoundTag;
        setFriction(arg0: number): void;
        getRenderShape($$0: Internal.BlockState_): Internal.RenderShape;
        canCull(): boolean;
        customShapeUpdate(blockState: Internal.CustomBlockState_, levelReader: Internal.LevelReader_, blockPos: BlockPos_): Internal.CustomBlockState;
        getJumpFactor(): number;
        getSpeedFactor(): number;
        static canSupportCenter($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        skipRendering($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getLightBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        isPossibleToRespawnInThis($$0: Internal.BlockState_): boolean;
        playerDestroy($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.BlockEntity_, $$5: Internal.ItemStack_): void;
        shouldAttemptToCull(state: Internal.BlockState_): boolean;
        getCustomStateForPlacement(blockPlaceContext: Internal.BlockPlaceContext_): Internal.CustomBlockState;
        /**
         * @deprecated
        */
        getDirectSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        getProperties(): Internal.BlockBehaviour$Properties;
        playerWillDestroy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Player_): void;
        getClass(): typeof any;
        getMaxVerticalOffset(): number;
        newBlockEntity($$0: BlockPos_, $$1: Internal.BlockState_): Internal.BlockEntity;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.item.context.BlockPlaceContext)"($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        useShapeForLightOcclusion($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        getDrops($$0: Internal.BlockState_, $$1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getStateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>;
        /**
         * @deprecated
        */
        entityInside($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Entity_): void;
        setBlockBuilder(b: Internal.BlockBuilder_): void;
        handler$ldb000$puzzleslib$playerDestroy$0(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        setRequiresTool(v: boolean): void;
        setSpeedFactor(arg0: number): void;
        axiom$getPossibleCustomStates(): Internal.List<any>;
        setExplosionResistance(arg0: number): void;
        toString(): string;
        port_lib$popExperience(arg0: Internal.ServerLevel_, arg1: BlockPos_, arg2: number): void;
        notifyAll(): void;
        getToolModifiedState(state: Internal.BlockState_, world: Internal.Level_, pos: BlockPos_, player: Internal.Player_, stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): Internal.BlockState;
        getId(): string;
        getLootTable(): ResourceLocation;
        puzzleslib$setItem(arg0: Internal.Item_): void;
        axiom$translationKey(): string;
        /**
         * @deprecated
        */
        getInteractionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        setPlacedBy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.LivingEntity_, $$4: Internal.ItemStack_): void;
        propagatesSkylightDown($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        /**
         * @deprecated
        */
        onPlace($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Block>;
        static popResourceFromFace($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.ItemStack_): void;
        getFriction(): number;
        handlePrecipitation($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Biome$Precipitation_): void;
        /**
         * @deprecated
        */
        hasAnalogOutputSignal($$0: Internal.BlockState_): boolean;
        wait(arg0: number): void;
        /**
         * @deprecated
        */
        getFluidState($$0: Internal.BlockState_): Internal.FluidState;
        handler$koh000$porting_lib_entity$getDestroySpeed(blockState: Internal.BlockState_, player: Internal.Player_, blockGetter: Internal.BlockGetter_, pos: BlockPos_, cir: Internal.CallbackInfoReturnable_<any>): void;
        /**
         * @deprecated
        */
        getAnalogOutputSignal($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): number;
        static byColor($$0: Internal.DyeColor_): Internal.Block;
        handler$efo000$collective$Block_setPlacedBy(level: Internal.Level_, blockPos: BlockPos_, blockState: Internal.BlockState_, livingEntity: Internal.LivingEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        tick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        supportsExternalFaceHiding(state: Internal.BlockState_): boolean;
        handler$ldb000$puzzleslib$playerDestroy$1(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        notify(): void;
        axiom$asItemStack(): Internal.ItemStack;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        neighborChanged($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Block_, $$4: BlockPos_, $$5: boolean): void;
        handler$zhd000$additionalentityattributes$additionalEntityAttributes$saveBreakingPlayer(world: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, stack: Internal.ItemStack_, callbackInfo: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        getBlockSupportShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        canSustainPlant(state: Internal.BlockState_, world: Internal.BlockGetter_, pos: BlockPos_, facing: Internal.Direction_, plantable: Internal.IPlantable_): boolean;
        /**
         * @deprecated
        */
        isCollisionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static isFaceFull($$0: Internal.VoxelShape_, $$1: Internal.Direction_): boolean;
        getMenuProvider($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): Internal.MenuProvider;
        getTicker<T extends Internal.BlockEntity>($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockEntityType_<T>): Internal.BlockEntityTicker<T>;
        static byItem($$0: Internal.Item_): Internal.Block;
        static updateFromNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        updateIndirectNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: number, $$4: number): void;
        destroy($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): void;
        handler$fdc000$everycomp$addSimpleFastECdrops(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, cir: Internal.CallbackInfoReturnable_<any>, resId: ResourceLocation_, lootParams: Internal.LootParams_, serverLevel: Internal.ServerLevel_, lootTable: Internal.LootTable_): void;
        getToolModifiedState(state: Internal.BlockState_, context: Internal.UseOnContext_, toolAction: Internal.ToolAction_, simulate: boolean): Internal.BlockState;
        /**
         * @deprecated
        */
        use($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_, $$4: Internal.InteractionHand_, $$5: Internal.BlockHitResult_): Internal.InteractionResult;
        setLightEmission(v: number): void;
        doNormalInteractions(): boolean;
        setJumpFactor(arg0: number): void;
        canSurvive($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): void;
        /**
         * @deprecated
        */
        getShadeBrightness($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        getAppearance(state: Internal.BlockState_, renderView: Internal.BlockAndTintGetter_, pos: BlockPos_, side: Internal.Direction_, sourceState: Internal.BlockState_, sourcePos: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        getCollisionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        setDestroySpeed(v: number): void;
        defaultBlockState(): Internal.BlockState;
        usesCustomShouldDrawFace(state: Internal.BlockState_): boolean;
        getStateForPlacement($$0: Internal.BlockPlaceContext_): Internal.BlockState;
        cantCullAgainst(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>($$0: Internal.ServerLevel_, $$1: T): Internal.GameEventListener;
        arch$holder(): Internal.Holder<Internal.Block>;
        wait(): void;
        getCloneItemStack($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        hasDynamicShape(): boolean;
        getMaxHorizontalOffset(): number;
        /**
         * @deprecated
        */
        getDestroyProgress($$0: Internal.BlockState_, $$1: Internal.Player_, $$2: Internal.BlockGetter_, $$3: BlockPos_): number;
        /**
         * @deprecated
        */
        getSeed($$0: Internal.BlockState_, $$1: BlockPos_): number;
        defaultDestroyTime(): number;
        updateShape($$0: Internal.BlockState_, $$1: Internal.Direction_, $$2: Internal.BlockState_, $$3: Internal.LevelAccessor_, $$4: BlockPos_, $$5: BlockPos_): Internal.BlockState;
        dropFromExplosion($$0: Internal.Explosion_): boolean;
        isRandomlyTicking($$0: Internal.BlockState_): boolean;
        static isShapeFullBlock(shape: Internal.VoxelShape_): boolean;
        withPropertiesOf($$0: Internal.BlockState_): Internal.BlockState;
        static isExceptionForConnection($$0: Internal.BlockState_): boolean;
        setIsRandomlyTicking(arg0: boolean): void;
        rotate($$0: Internal.BlockState_, $$1: Internal.Rotation_): Internal.BlockState;
        hidesNeighborFace(level: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, neighborState: Internal.BlockState_, dir: Internal.Direction_): boolean;
        onTreeGrow(state: Internal.BlockState_, level: Internal.LevelReader_, placeFunction: Internal.BiConsumer_<BlockPos, Internal.BlockState>, randomSource: Internal.RandomSource_, pos: BlockPos_, config: Internal.TreeConfiguration_): boolean;
        defaultMapColor(): Internal.MapColor;
        getStateAtViewpoint(state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_, viewpoint: Vec3d_): Internal.BlockState;
        wait(arg0: number, arg1: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.BlockGetter_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        setNameKey(arg0: string): void;
        static box($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): Internal.VoxelShape;
        mirror($$0: Internal.BlockState_, $$1: Internal.Mirror_): Internal.BlockState;
        wasExploded($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Explosion_): void;
        getName(): Internal.MutableComponent;
        updateEntityAfterFallOn($$0: Internal.BlockGetter_, $$1: Internal.Entity_): void;
        animateTick($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        customShouldDrawFace(view: Internal.BlockGetter_, thisState: Internal.BlockState_, sideState: Internal.BlockState_, thisPos: BlockPos_, sidePos: BlockPos_, side: Internal.Direction_): Optional<boolean>;
        axiom$getResourceLocation(): ResourceLocation;
        arch$registryName(): ResourceLocation;
        axiom$getProperties(): Internal.Collection<any>;
        getBlockBuilder(): Internal.BlockBuilder;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        isSignalSource($$0: Internal.BlockState_): boolean;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number): void;
        /**
         * @deprecated
        */
        attack($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): void;
        getShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        shouldAttemptToCull(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        onProjectileHit($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockHitResult_, $$3: Internal.Projectile_): void;
        static stateById($$0: number): Internal.BlockState;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): Internal.List<Internal.ItemStack>;
        requiredFeatures(): Internal.FeatureFlagSet;
        hashCode(): number;
        axiom$defaultCustomState(): Internal.CustomBlockState;
        setCanCull(canCull: boolean): void;
        /**
         * @deprecated
        */
        isOcclusionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static getId($$0: Internal.BlockState_): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.material.Fluid)"($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        static pushEntitiesUp($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        isPathfindable($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.PathComputationType_): boolean;
        setSoundType(arg0: SoundType_): void;
        handler$cef000$betterend$be_getDroppedStacks(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, info: Internal.CallbackInfoReturnable_<any>): void;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_): Internal.List<Internal.ItemStack>;
        /**
         * @deprecated
        */
        onRemove($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        cantCullAgainst(state: Internal.BlockState_): boolean;
        setHasCollision(arg0: boolean): void;
        static shouldRenderFace($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_, $$4: BlockPos_): boolean;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        spawnAfterBreak($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.ItemStack_, $$4: boolean): void;
        set randomTickCallback(callback: Internal.Consumer_<any>)
        get descriptionId(): string
        get color(): Internal.DyeColor
        get settings(): Internal.BlockBehaviour$Properties
        get explosionResistance(): number
        get typeData(): Internal.CompoundTag
        set friction(arg0: number)
        get jumpFactor(): number
        get speedFactor(): number
        get properties(): Internal.BlockBehaviour$Properties
        get class(): typeof any
        get maxVerticalOffset(): number
        get stateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>
        set blockBuilder(b: Internal.BlockBuilder_)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        set speedFactor(arg0: number)
        set explosionResistance(arg0: number)
        get id(): string
        get lootTable(): ResourceLocation
        get friction(): number
        set lightEmission(v: number)
        set jumpFactor(arg0: number)
        set destroySpeed(v: number)
        get maxHorizontalOffset(): number
        set isRandomlyTicking(arg0: boolean)
        set nameKey(arg0: string)
        get name(): Internal.MutableComponent
        get blockBuilder(): Internal.BlockBuilder
        get idLocation(): ResourceLocation
        get mod(): string
        set canCull(canCull: boolean)
        set soundType(arg0: SoundType_)
        set hasCollision(arg0: boolean)
        static readonly ROTATION: (Internal.IntegerProperty) & (Internal.IntegerProperty);
    }
    type BannerBlock_ = BannerBlock;
    interface TeamPropertyCollection {
        abstract read(arg0: Internal.FriendlyByteBuf_): void;
        abstract copy(): this;
        abstract write(arg0: Internal.FriendlyByteBuf_): void;
        abstract forEach<T>(arg0: Internal.BiConsumer_<Internal.TeamProperty<T>, Internal.TeamPropertyValue<T>>): void;
        abstract get<T>(arg0: Internal.TeamProperty_<T>): T;
        abstract updateFrom(arg0: Internal.TeamPropertyCollection_): void;
        abstract set<T>(arg0: Internal.TeamProperty_<T>, arg1: T): void;
    }
    type TeamPropertyCollection_ = TeamPropertyCollection;
    class CastingImage$ParenthesizedIota$Companion {
        constructor($constructor_marker: any_)
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
    }
    type CastingImage$ParenthesizedIota$Companion_ = CastingImage$ParenthesizedIota$Companion;
    interface Callable <V> {
        abstract call(): V;
        (): V;
    }
    type Callable_<V> = Callable<V> | (()=> V);
    class FenceBlock extends Internal.CrossCollisionBlock {
        constructor($$0: Internal.BlockBehaviour$Properties_)
        getOcclusionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        /**
         * @deprecated
        */
        getSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getPickupSound(): Optional<Internal.SoundEvent>;
        axiom$customPickBlockStack(): Internal.ItemStack;
        getSoundType($$0: Internal.BlockState_): SoundType;
        getVisualShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        handler$efo000$collective$Block_playerDestroy(level: Internal.Level_, player: Internal.Player_, blockPos: BlockPos_, blockState: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number, $$5: number): void;
        /**
         * @deprecated
        */
        randomTick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: Internal.BlockEntity_): void;
        static canSupportRigidBlock($$0: Internal.BlockGetter_, $$1: BlockPos_): boolean;
        static popResource($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.ItemStack_): void;
        setRandomTickCallback(callback: Internal.Consumer_<any>): void;
        getDescriptionId(): string;
        stepOn($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Entity_): void;
        fallOn($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: BlockPos_, $$3: Internal.Entity_, $$4: number): void;
        getSettings(): Internal.BlockBehaviour$Properties;
        getExplosionResistance(): number;
        asItem(): Internal.Item;
        /**
         * @deprecated
        */
        triggerEvent($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: number, $$4: number): boolean;
        getTypeData(): Internal.CompoundTag;
        setFriction(arg0: number): void;
        /**
         * @deprecated
        */
        getRenderShape($$0: Internal.BlockState_): Internal.RenderShape;
        canCull(): boolean;
        customShapeUpdate(blockState: Internal.CustomBlockState_, levelReader: Internal.LevelReader_, blockPos: BlockPos_): Internal.CustomBlockState;
        getJumpFactor(): number;
        getSpeedFactor(): number;
        static canSupportCenter($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        skipRendering($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getLightBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        playerDestroy($$0: Internal.Level_, $$1: Internal.Player_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.BlockEntity_, $$5: Internal.ItemStack_): void;
        shouldAttemptToCull(state: Internal.BlockState_): boolean;
        isPossibleToRespawnInThis($$0: Internal.BlockState_): boolean;
        getCustomStateForPlacement(blockPlaceContext: Internal.BlockPlaceContext_): Internal.CustomBlockState;
        /**
         * @deprecated
        */
        getDirectSignal($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_): number;
        getProperties(): Internal.BlockBehaviour$Properties;
        playerWillDestroy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Player_): void;
        getClass(): typeof any;
        getMaxVerticalOffset(): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.item.context.BlockPlaceContext)"($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        useShapeForLightOcclusion($$0: Internal.BlockState_): boolean;
        /**
         * @deprecated
        */
        getDrops($$0: Internal.BlockState_, $$1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getStateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>;
        pickupBlock($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        /**
         * @deprecated
        */
        entityInside($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Entity_): void;
        setBlockBuilder(b: Internal.BlockBuilder_): void;
        handler$ldb000$puzzleslib$playerDestroy$0(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        connectsTo($$0: Internal.BlockState_, $$1: boolean, $$2: Internal.Direction_): boolean;
        setRequiresTool(v: boolean): void;
        setSpeedFactor(arg0: number): void;
        axiom$getPossibleCustomStates(): Internal.List<any>;
        setExplosionResistance(arg0: number): void;
        toString(): string;
        port_lib$popExperience(arg0: Internal.ServerLevel_, arg1: BlockPos_, arg2: number): void;
        notifyAll(): void;
        getToolModifiedState(state: Internal.BlockState_, world: Internal.Level_, pos: BlockPos_, player: Internal.Player_, stack: Internal.ItemStack_, toolAction: Internal.ToolAction_): Internal.BlockState;
        getId(): string;
        getLootTable(): ResourceLocation;
        puzzleslib$setItem(arg0: Internal.Item_): void;
        axiom$translationKey(): string;
        /**
         * @deprecated
        */
        getInteractionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        propagatesSkylightDown($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        setPlacedBy($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.LivingEntity_, $$4: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        onPlace($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Block>;
        static popResourceFromFace($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.ItemStack_): void;
        getFriction(): number;
        handlePrecipitation($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Biome$Precipitation_): void;
        /**
         * @deprecated
        */
        hasAnalogOutputSignal($$0: Internal.BlockState_): boolean;
        wait(arg0: number): void;
        getFluidState($$0: Internal.BlockState_): Internal.FluidState;
        handler$koh000$porting_lib_entity$getDestroySpeed(blockState: Internal.BlockState_, player: Internal.Player_, blockGetter: Internal.BlockGetter_, pos: BlockPos_, cir: Internal.CallbackInfoReturnable_<any>): void;
        /**
         * @deprecated
        */
        getAnalogOutputSignal($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): number;
        handler$efo000$collective$Block_setPlacedBy(level: Internal.Level_, blockPos: BlockPos_, blockState: Internal.BlockState_, livingEntity: Internal.LivingEntity_, itemStack: Internal.ItemStack_, ci: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        tick($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        supportsExternalFaceHiding(state: Internal.BlockState_): boolean;
        handler$ldb000$puzzleslib$playerDestroy$1(level: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, itemInHand: Internal.ItemStack_, callback: Internal.CallbackInfo_): void;
        notify(): void;
        axiom$asItemStack(): Internal.ItemStack;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): void;
        /**
         * @deprecated
        */
        neighborChanged($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Block_, $$4: BlockPos_, $$5: boolean): void;
        handler$zhd000$additionalentityattributes$additionalEntityAttributes$saveBreakingPlayer(world: Internal.Level_, player: Internal.Player_, pos: BlockPos_, state: Internal.BlockState_, blockEntity: Internal.BlockEntity_, stack: Internal.ItemStack_, callbackInfo: Internal.CallbackInfo_): void;
        /**
         * @deprecated
        */
        getBlockSupportShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): Internal.VoxelShape;
        canSustainPlant(state: Internal.BlockState_, world: Internal.BlockGetter_, pos: BlockPos_, facing: Internal.Direction_, plantable: Internal.IPlantable_): boolean;
        /**
         * @deprecated
        */
        isCollisionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static isFaceFull($$0: Internal.VoxelShape_, $$1: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        getMenuProvider($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): Internal.MenuProvider;
        static byItem($$0: Internal.Item_): Internal.Block;
        static updateFromNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_): Internal.BlockState;
        /**
         * @deprecated
        */
        updateIndirectNeighbourShapes($$0: Internal.BlockState_, $$1: Internal.LevelAccessor_, $$2: BlockPos_, $$3: number, $$4: number): void;
        destroy($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_): void;
        handler$fdc000$everycomp$addSimpleFastECdrops(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, cir: Internal.CallbackInfoReturnable_<any>, resId: ResourceLocation_, lootParams: Internal.LootParams_, serverLevel: Internal.ServerLevel_, lootTable: Internal.LootTable_): void;
        getToolModifiedState(state: Internal.BlockState_, context: Internal.UseOnContext_, toolAction: Internal.ToolAction_, simulate: boolean): Internal.BlockState;
        use($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_, $$4: Internal.InteractionHand_, $$5: Internal.BlockHitResult_): Internal.InteractionResult;
        setLightEmission(v: number): void;
        doNormalInteractions(): boolean;
        setJumpFactor(arg0: number): void;
        /**
         * @deprecated
        */
        canSurvive($$0: Internal.BlockState_, $$1: Internal.LevelReader_, $$2: BlockPos_): boolean;
        static dropResources($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_): void;
        /**
         * @deprecated
        */
        getShadeBrightness($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): number;
        getAppearance(state: Internal.BlockState_, renderView: Internal.BlockAndTintGetter_, pos: BlockPos_, side: Internal.Direction_, sourceState: Internal.BlockState_, sourcePos: BlockPos_): Internal.BlockState;
        getCollisionShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        setDestroySpeed(v: number): void;
        defaultBlockState(): Internal.BlockState;
        usesCustomShouldDrawFace(state: Internal.BlockState_): boolean;
        getStateForPlacement($$0: Internal.BlockPlaceContext_): Internal.BlockState;
        cantCullAgainst(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        placeLiquid($$0: Internal.LevelAccessor_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.FluidState_): boolean;
        arch$holder(): Internal.Holder<Internal.Block>;
        wait(): void;
        getCloneItemStack($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_): Internal.ItemStack;
        hasDynamicShape(): boolean;
        getMaxHorizontalOffset(): number;
        /**
         * @deprecated
        */
        getDestroyProgress($$0: Internal.BlockState_, $$1: Internal.Player_, $$2: Internal.BlockGetter_, $$3: BlockPos_): number;
        /**
         * @deprecated
        */
        getSeed($$0: Internal.BlockState_, $$1: BlockPos_): number;
        defaultDestroyTime(): number;
        updateShape($$0: Internal.BlockState_, $$1: Internal.Direction_, $$2: Internal.BlockState_, $$3: Internal.LevelAccessor_, $$4: BlockPos_, $$5: BlockPos_): Internal.BlockState;
        dropFromExplosion($$0: Internal.Explosion_): boolean;
        isRandomlyTicking($$0: Internal.BlockState_): boolean;
        static isShapeFullBlock(shape: Internal.VoxelShape_): boolean;
        withPropertiesOf($$0: Internal.BlockState_): Internal.BlockState;
        static isExceptionForConnection($$0: Internal.BlockState_): boolean;
        setIsRandomlyTicking(arg0: boolean): void;
        canPlaceLiquid($$0: Internal.BlockGetter_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.Fluid_): boolean;
        rotate($$0: Internal.BlockState_, $$1: Internal.Rotation_): Internal.BlockState;
        hidesNeighborFace(level: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, neighborState: Internal.BlockState_, dir: Internal.Direction_): boolean;
        onTreeGrow(state: Internal.BlockState_, level: Internal.LevelReader_, placeFunction: Internal.BiConsumer_<BlockPos, Internal.BlockState>, randomSource: Internal.RandomSource_, pos: BlockPos_, config: Internal.TreeConfiguration_): boolean;
        defaultMapColor(): Internal.MapColor;
        getStateAtViewpoint(state: Internal.BlockState_, level: Internal.BlockGetter_, pos: BlockPos_, viewpoint: Vec3d_): Internal.BlockState;
        wait(arg0: number, arg1: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.BlockGetter_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        setNameKey(arg0: string): void;
        static box($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number): Internal.VoxelShape;
        mirror($$0: Internal.BlockState_, $$1: Internal.Mirror_): Internal.BlockState;
        wasExploded($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Explosion_): void;
        getName(): Internal.MutableComponent;
        updateEntityAfterFallOn($$0: Internal.BlockGetter_, $$1: Internal.Entity_): void;
        animateTick($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.RandomSource_): void;
        customShouldDrawFace(view: Internal.BlockGetter_, thisState: Internal.BlockState_, sideState: Internal.BlockState_, thisPos: BlockPos_, sidePos: BlockPos_, side: Internal.Direction_): Optional<boolean>;
        axiom$getResourceLocation(): ResourceLocation;
        arch$registryName(): ResourceLocation;
        axiom$getProperties(): Internal.Collection<any>;
        getBlockBuilder(): Internal.BlockBuilder;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        canBeReplaced($$0: Internal.BlockState_, $$1: Internal.BlockPlaceContext_): boolean;
        /**
         * @deprecated
        */
        isSignalSource($$0: Internal.BlockState_): boolean;
        static updateOrDestroy($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_, $$4: number): void;
        /**
         * @deprecated
        */
        attack($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): void;
        getShape($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.CollisionContext_): Internal.VoxelShape;
        shouldAttemptToCull(state: Internal.BlockState_, side: Internal.Direction_): boolean;
        /**
         * @deprecated
        */
        onProjectileHit($$0: Internal.Level_, $$1: Internal.BlockState_, $$2: Internal.BlockHitResult_, $$3: Internal.Projectile_): void;
        static stateById($$0: number): Internal.BlockState;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_, $$4: Internal.Entity_, $$5: Internal.ItemStack_): Internal.List<Internal.ItemStack>;
        requiredFeatures(): Internal.FeatureFlagSet;
        hashCode(): number;
        axiom$defaultCustomState(): Internal.CustomBlockState;
        setCanCull(canCull: boolean): void;
        /**
         * @deprecated
        */
        isOcclusionShapeFullBlock($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_): boolean;
        static getId($$0: Internal.BlockState_): number;
        /**
         * @deprecated
        */
        "canBeReplaced(net.minecraft.world.level.block.state.BlockState,net.minecraft.world.level.material.Fluid)"($$0: Internal.BlockState_, $$1: Internal.Fluid_): boolean;
        static pushEntitiesUp($$0: Internal.BlockState_, $$1: Internal.BlockState_, $$2: Internal.LevelAccessor_, $$3: BlockPos_): Internal.BlockState;
        isPathfindable($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.PathComputationType_): boolean;
        setSoundType(arg0: SoundType_): void;
        handler$cef000$betterend$be_getDroppedStacks(state: Internal.BlockState_, builder: Internal.LootParams$Builder_, info: Internal.CallbackInfoReturnable_<any>): void;
        static getDrops($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.BlockEntity_): Internal.List<Internal.ItemStack>;
        /**
         * @deprecated
        */
        onRemove($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: boolean): void;
        cantCullAgainst(state: Internal.BlockState_): boolean;
        setHasCollision(arg0: boolean): void;
        static shouldRenderFace($$0: Internal.BlockState_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.Direction_, $$4: BlockPos_): boolean;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        spawnAfterBreak($$0: Internal.BlockState_, $$1: Internal.ServerLevel_, $$2: BlockPos_, $$3: Internal.ItemStack_, $$4: boolean): void;
        get pickupSound(): Optional<Internal.SoundEvent>
        set randomTickCallback(callback: Internal.Consumer_<any>)
        get descriptionId(): string
        get settings(): Internal.BlockBehaviour$Properties
        get explosionResistance(): number
        get typeData(): Internal.CompoundTag
        set friction(arg0: number)
        get jumpFactor(): number
        get speedFactor(): number
        get properties(): Internal.BlockBehaviour$Properties
        get class(): typeof any
        get maxVerticalOffset(): number
        get stateDefinition(): Internal.StateDefinition<Internal.Block, Internal.BlockState>
        set blockBuilder(b: Internal.BlockBuilder_)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        set speedFactor(arg0: number)
        set explosionResistance(arg0: number)
        get id(): string
        get lootTable(): ResourceLocation
        get friction(): number
        set lightEmission(v: number)
        set jumpFactor(arg0: number)
        set destroySpeed(v: number)
        get maxHorizontalOffset(): number
        set isRandomlyTicking(arg0: boolean)
        set nameKey(arg0: string)
        get name(): Internal.MutableComponent
        get blockBuilder(): Internal.BlockBuilder
        get idLocation(): ResourceLocation
        get mod(): string
        set canCull(canCull: boolean)
        set soundType(arg0: SoundType_)
        set hasCollision(arg0: boolean)
    }
    type FenceBlock_ = FenceBlock;
    class ArrayList <E> extends Internal.AbstractList<E> implements Internal.RandomAccess, Internal.Cloneable, Internal.List<E>, Internal.Serializable {
        constructor()
        constructor(arg0: Internal.Collection_<E>)
        constructor(arg0: number)
        static of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E): Internal.List<E>;
        static copyOf<E>(arg0: Internal.Collection_<E>): Internal.List<E>;
        static of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E, arg8: E): Internal.List<E>;
        sort(arg0: Comparator_<E>): void;
        notify(): void;
        static of<E>(arg0: E): Internal.List<E>;
        static of<E>(): Internal.List<E>;
        retainAll(arg0: Internal.Collection_<any>): boolean;
        "remove(int)"(arg0: number): E;
        toArray<T>(arg0: Internal.IntFunction_<T[]>): T[];
        addAll(arg0: number, arg1: Internal.Collection_<E>): boolean;
        addAll(arg0: Internal.Collection_<E>): boolean;
        static of<E>(arg0: E, arg1: E, arg2: E): Internal.List<E>;
        subList(arg0: number, arg1: number): Internal.List<E>;
        indexOf(arg0: any): number;
        trimToSize(): void;
        add(arg0: number, arg1: E): void;
        forEach(arg0: Internal.Consumer_<E>): void;
        toArray<T>(arg0: T[]): T[];
        remove(arg0: any): boolean;
        "remove(java.lang.Object)"(arg0: any): boolean;
        listIterator(arg0: number): Internal.ListIterator<E>;
        iterator(): Internal.Iterator<E>;
        static of<E>(arg0: E, arg1: E): Internal.List<E>;
        stream(): Internal.Stream<E>;
        ensureCapacity(arg0: number): void;
        removeAll(arg0: Internal.Collection_<any>): boolean;
        wait(): void;
        removeIf(arg0: Internal.Predicate_<E>): boolean;
        static of<E>(arg0: E, arg1: E, arg2: E, arg3: E): Internal.List<E>;
        static "of(java.lang.Object[])"<E>(...arg0: E[]): Internal.List<E>;
        lastIndexOf(arg0: any): number;
        clone(): any;
        getClass(): typeof any;
        get(arg0: number): E;
        add(arg0: E): boolean;
        listIterator(): Internal.ListIterator<E>;
        static of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E): Internal.List<E>;
        parallelStream(): Internal.Stream<E>;
        isEmpty(): boolean;
        wait(arg0: number, arg1: number): void;
        set(arg0: number, arg1: E): E;
        static of<E>(...arg0: E[]): Internal.List<E>;
        abstract containsAll(arg0: Internal.Collection_<any>): boolean;
        remove(arg0: number): E;
        contains(arg0: any): boolean;
        static of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E): Internal.List<E>;
        static "of(java.lang.Object)"<E>(arg0: E): Internal.List<E>;
        replaceAll(arg0: Internal.UnaryOperator_<E>): void;
        toString(): string;
        notifyAll(): void;
        "toArray(java.lang.Object[])"<T>(arg0: T[]): T[];
        static of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E): Internal.List<E>;
        "toArray(java.util.function.IntFunction)"<T>(arg0: Internal.IntFunction_<T[]>): T[];
        static of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E, arg8: E, arg9: E): Internal.List<E>;
        toArray(): any[];
        hashCode(): number;
        size(): number;
        clear(): void;
        wait(arg0: number): void;
        spliterator(): Internal.Spliterator<E>;
        equals(arg0: any): boolean;
        get class(): typeof any
        get empty(): boolean
    }
    type ArrayList_<E> = ArrayList<E>;
    interface LootParams$DynamicDrop {
        abstract add(arg0: Internal.Consumer_<Internal.ItemStack>): void;
        (arg0: Internal.Consumer<Internal.ItemStack>): void;
    }
    type LootParams$DynamicDrop_ = LootParams$DynamicDrop | ((arg0: Internal.Consumer<Internal.ItemStack>)=> void);
    class LargeAmaranitaFeature extends Internal.DefaultFeature {
        constructor()
        static getPosOnSurfaceWG(world: Internal.WorldGenLevel_, pos: BlockPos_): BlockPos;
        getClass(): typeof any;
        static getPosOnSurface(world: Internal.WorldGenLevel_, pos: BlockPos_): BlockPos;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        place($$0: Internal.NoneFeatureConfiguration_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        static getPosOnSurfaceRaycast(world: Internal.WorldGenLevel_, pos: BlockPos_): BlockPos;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        place(featureConfig: Internal.FeaturePlaceContext_<Internal.NoneFeatureConfiguration>): boolean;
        static getYOnSurfaceWG(world: Internal.WorldGenLevel_, x: number, z: number): number;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        static getPosOnSurfaceRaycast(world: Internal.WorldGenLevel_, pos: BlockPos_, dist: number): BlockPos;
        wait(): void;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.NoneFeatureConfiguration, Feature<Internal.NoneFeatureConfiguration>>>;
        static getYOnSurface(world: Internal.WorldGenLevel_, x: number, z: number): number;
        get class(): typeof any
    }
    type LargeAmaranitaFeature_ = LargeAmaranitaFeature;
    class PlentifulMantleRodItem extends Internal.Item {
        constructor(props: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(world: Internal.Level_, p: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type PlentifulMantleRodItem_ = PlentifulMantleRodItem;
    interface BiomeAccessor {
        abstract callGetTemperature(arg0: BlockPos_): number;
        (arg0: BlockPos): number;
    }
    type BiomeAccessor_ = BiomeAccessor | ((arg0: BlockPos)=> number);
    interface SpectatorMenuListener {
        abstract onSpectatorMenuClosed(arg0: Internal.SpectatorMenu_): void;
        (arg0: Internal.SpectatorMenu): void;
    }
    type SpectatorMenuListener_ = ((arg0: Internal.SpectatorMenu)=> void) | SpectatorMenuListener;
    class CharmOfSinkingItem extends Internal.WearableArtifactItem {
        constructor()
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        static setActivated(stack: Internal.ItemStack_, active: boolean): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        static isActivated(stack: Internal.ItemStack_): boolean;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, world: Internal.Level_, tooltipList: Internal.List_<net.minecraft.network.chat.Component>, flags: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        isOnCooldown(entity: Internal.LivingEntity_): boolean;
        addCooldown(entity: Internal.LivingEntity_, ticks: number): void;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        getFortuneLevel(): number;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        wornTick(entity: Internal.LivingEntity_, stack: Internal.ItemStack_): void;
        getLootingLevel(): number;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        makesPiglinsNeutral(): boolean;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        onUnequip(entity: Internal.LivingEntity_, stack: Internal.ItemStack_): void;
        isEquippedBy(entity: Internal.LivingEntity_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        toggleItem(player: Internal.ServerPlayer_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        addAttributeModifier(attributeModifier: Internal.ArtifactAttributeModifier_): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        static shouldSink(entity: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        getEquipSound(): Internal.SoundEvent;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canWalkOnPowderedSnow(): boolean;
        use(level: Internal.Level_, user: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<any>;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        getAttributeModifiers(): Internal.List<Internal.ArtifactAttributeModifier>;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        hasNonCosmeticEffects(): boolean;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        findAllEquippedBy(entity: Internal.LivingEntity_): Internal.Stream<Internal.ItemStack>;
        isCosmetic(): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        onEquip(entity: Internal.LivingEntity_, stack: Internal.ItemStack_): void;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe(slotStack: Internal.ItemStack_, holdingStack: Internal.ItemStack_, slot: Internal.Slot_, clickAction: Internal.ClickAction_, player: Internal.Player_, slotAccess: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        get fortuneLevel(): number
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        get lootingLevel(): number
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get equipSound(): Internal.SoundEvent
        get maxStackSize(): number
        get attributeModifiers(): Internal.List<Internal.ArtifactAttributeModifier>
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get cosmetic(): boolean
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type CharmOfSinkingItem_ = CharmOfSinkingItem;
    class Painting extends Internal.HangingEntity implements Internal.PaintingAccessor, Internal.VariantHolder<Internal.Holder<Internal.PaintingVariant>> {
        constructor($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_, $$3: Internal.Holder_<Internal.PaintingVariant>)
        constructor($$0: Internal.EntityType_<Internal.Painting>, $$1: Internal.Level_)
        litematica_setWorld(arg0: Internal.Level_): void;
        handler$hak000$gobber2$gobberOccludeVibrationSignals(cir: Internal.CallbackInfoReturnable_<any>): void;
        isInWall(): boolean;
        etf$getType(): Internal.EntityType<any>;
        getAllSlots(): Internal.Iterable<Internal.ItemStack>;
        getUpVector($$0: number): Vec3d;
        gameEvent($$0: Internal.GameEvent_, $$1: Internal.Entity_): void;
        remove($$0: Internal.Entity$RemovalReason_): void;
        getBlockZ(): number;
        isSuppressingBounce(): boolean;
        dampensVibrations(): boolean;
        hasAttached(type: Internal.AttachmentType_<any>): boolean;
        isSilent(): boolean;
        "playSound(net.minecraft.sounds.SoundEvent)"(id: Internal.SoundEvent_): void;
        setCulled(value: boolean): void;
        getPitch(): number;
        isOnFire(): boolean;
        rotate($$0: Internal.Rotation_): number;
        getPositionCodec(): Internal.VecDeltaCodec;
        getPassengersAndSelf(): Internal.Stream<any>;
        setMaxUpStep($$0: number): void;
        updateFluidHeightAndDoFluidPushing($$0: Internal.TagKey_<Internal.Fluid>, $$1: number): boolean;
        setPosition(x: number, y: number, z: number): void;
        runCommandSilent(command: string): number;
        chunkPosition(): Internal.ChunkPos;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        emf$isOnGround(): boolean;
        method_5652($$0: Internal.CompoundTag_): void;
        gameEvent($$0: Internal.GameEvent_): void;
        alwaysAccepts(): boolean;
        isShiftKeyDown(): boolean;
        setUUID($$0: Internal.UUID_): void;
        checkBelowWorld(): void;
        isVisuallyCrawling(): boolean;
        setVariant($$0: Internal.Holder_<Internal.PaintingVariant>): void;
        setMotionZ(z: number): void;
        handler$ieb000$lambdynlights$onRemove(ci: Internal.CallbackInfo_): void;
        "deserializeNBT(net.minecraft.nbt.Tag)"(arg0: Internal.Tag_): void;
        canFreeze(): boolean;
        ignoreExplosion(): boolean;
        port_lib$setRemovalReason(arg0: Internal.Entity$RemovalReason_): void;
        teleportRelative($$0: number, $$1: number, $$2: number): void;
        getBlockY(): number;
        getIsInsideStructureTracker(): Internal.IsInsideStructureTracker;
        isSpectator(): boolean;
        pehkui_setScaleCache(scaleCache: Internal.ScaleData_[]): void;
        isInWaterOrBubble(): boolean;
        spawnAtLocation($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        getPersistentData(): Internal.CompoundTag;
        getPortalCooldown(): number;
        emf$isGlowing(): boolean;
        getItem(): Internal.ItemStack;
        getRandomZ($$0: number): number;
        pehkui_getOnGround(): boolean;
        causeFallDamage($$0: number, $$1: number, $$2: DamageSource_): boolean;
        getFusionModel(layerIndex: number): Internal.Triple<any, any, any>;
        getDynamicLightChunksToRebuild(forced: boolean): Internal.LongSet;
        getPosition($$0: number): Vec3d;
        setRemoved($$0: Internal.Entity$RemovalReason_): void;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>, initializer: Internal.Supplier_<A>): A;
        getDistanceSq($$0: number, $$1: number, $$2: number): number;
        isInWaterRainOrBubble(): boolean;
        getRemovalReason(): Internal.Entity$RemovalReason;
        wait(arg0: number): void;
        isIgnoringBlockTriggers(): boolean;
        etf$getItemsEquipped(): Internal.Iterable<any>;
        getHandHoldingItemAngle($$0: Internal.Item_): Vec3d;
        etf$getVelocity(): Vec3d;
        hex$markHurt(): void;
        distanceToSqr($$0: Vec3d_): number;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        resetFallDistance(): void;
        canSprint(): boolean;
        modifyAttached<A>(type: Internal.AttachmentType_<A>, modifier: Internal.UnaryOperator_<A>): A;
        blockPosition(): BlockPos;
        isSteppingCarefully(): boolean;
        static create($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.Direction_): Optional<Internal.Painting>;
        setBoundingBox($$0: Internal.AABB_): void;
        isAmbientCreature(): boolean;
        "spawnAtLocation(net.minecraft.world.item.ItemStack,float)"($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        getPos(): BlockPos;
        getBlockX(): number;
        /**
         * @deprecated
        */
        getLightLevelDependentMagicValue(): number;
        getEncodeId(): string;
        getY($$0: number): number;
        emf$prevPitch(): number;
        getBlock(): Internal.BlockContainerJS;
        getNbt(): Internal.CompoundTag;
        etf$getHandItems(): Internal.Iterable<any>;
        setInvisible($$0: boolean): void;
        etf$getArmorItems(): Internal.Iterable<any>;
        getName(): net.minecraft.network.chat.Component;
        dropItem($$0: Internal.Entity_): void;
        isSubmergedInLoosely(tag: Internal.TagKey_<any>): boolean;
        onGround(): boolean;
        getDynamicLightY(): number;
        getControlledVehicle(): Internal.Entity;
        isOnSameTeam($$0: Internal.Entity_): boolean;
        attack($$0: DamageSource_, $$1: number): boolean;
        onInsideBubbleColumn($$0: boolean): void;
        tick(): void;
        getEyePosition(): Vec3d;
        getEyeHeight(): number;
        hasPassenger($$0: Internal.Predicate_<Internal.Entity>): boolean;
        getYaw(): number;
        emf$isTouchingWater(): boolean;
        emf$getVariableMap(): Internal.Object2FloatOpenHashMap<any>;
        getComponentContainer(): Internal.ComponentContainer;
        hasPermissions($$0: number): boolean;
        getDynamicLightPrevZ(): number;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        pehkui_readScaleNbt(nbt: Internal.CompoundTag_): void;
        setCustomNameVisible($$0: boolean): void;
        isAlliedTo($$0: Internal.Team_): boolean;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>): A;
        setOutOfCamera(value: boolean): void;
        getControllingPassenger(): Internal.LivingEntity;
        getRemainingFireTicks(): number;
        getScriptType(): Internal.ScriptType;
        onlyOpCanSetNbt(): boolean;
        startRiding($$0: Internal.Entity_): boolean;
        saveWithoutId($$0: Internal.CompoundTag_): Internal.CompoundTag;
        getForward(): Vec3d;
        tcdcommons_getCustomData(): Internal.GenericProperties<any>;
        addMotion($$0: number, $$1: number, $$2: number): void;
        fireImmune(): boolean;
        getMaxFallDistance(): number;
        getZ($$0: number): number;
        getId(): number;
        pehkui_isFirstUpdate(): boolean;
        canBeHitByProjectile(): boolean;
        getTicksFrozen(): number;
        wrapWithCondition$kom000$porting_lib_entity$port_lib$captureDrops(level: Internal.Level_, entity: Internal.Entity_): boolean;
        getRecipientsForComponentSync(): Internal.Iterable<any>;
        getRandomX($$0: number): number;
        getDynamicLightZ(): number;
        getEyeY(): number;
        spawnAtLocation($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        setDirection($$0: Internal.Direction_): void;
        pick($$0: number, $$1: number, $$2: boolean): Internal.HitResult;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        fabric_readAttachmentsFromNbt(nbt: Internal.CompoundTag_): void;
        getBoundingBox(): Internal.AABB;
        changeDimension(p_20118_: Internal.ServerLevel_, teleporter: Internal.ITeleporter_): Internal.Entity;
        isInWaterOrRain(): boolean;
        isDescending(): boolean;
        emf$getPitch(): number;
        setItemSlot($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_): void;
        getYHeadRot(): number;
        handler$cbi000$besmirchment$isTeammate(other: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>): void;
        equals($$0: any): boolean;
        getViewYRot($$0: number): number;
        fabric_setCustomTeleportTarget(teleportTarget: Internal.PortalInfo_): void;
        dismountsUnderwater(): boolean;
        frameworkGetDataHolder(): com.mrcrayfish.framework.entity.sync.DataHolder;
        playerTouch($$0: Internal.Player_): void;
        addTag($$0: string): boolean;
        getAddEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>;
        getEyeHeight($$0: Internal.Pose_): number;
        syncPacketPositionCodec($$0: number, $$1: number, $$2: number): void;
        callIsBeingRainedOn(): boolean;
        getTeam(): Internal.Team;
        shouldRenderAtSqrDistance($$0: number): boolean;
        getAttachedOrSet<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        damageSources(): Internal.DamageSources;
        removeAttached<A>(type: Internal.AttachmentType_<A>): A;
        setTicksFrozen($$0: number): void;
        recreateFromPacket($$0: Internal.ClientboundAddEntityPacket_): void;
        getWidth(): number;
        getMyRidingOffset(): number;
        dismountTo($$0: number, $$1: number, $$2: number): void;
        setDeltaMovement($$0: Vec3d_): void;
        getLeashOffset($$0: number): Vec3d;
        etf$getEntityKey(): string;
        etf$getPose(): Internal.Pose;
        hasCustomName(): boolean;
        captureDrops(): Internal.Collection<any>;
        isCulled(): boolean;
        isLiving(): boolean;
        isGlowing(): boolean;
        getX(): number;
        isVehicle(): boolean;
        static transfer(original: Internal.AttachmentTarget_, target: Internal.AttachmentTarget_, isDeath: boolean): void;
        etf$getOptifineId(): number;
        dynamicLightWorld(): Internal.Level;
        getLeashOffset(): Vec3d;
        resetDynamicLight(): void;
        isAttackable(): boolean;
        spawnAtLocation($$0: Internal.ItemStack_): Internal.ItemEntity;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        thunderHit($$0: Internal.ServerLevel_, $$1: Internal.LightningBolt_): void;
        setIsInPowderSnow($$0: boolean): void;
        etf$distanceTo(entity: Internal.Entity_): number;
        doEnchantDamageEffects($$0: Internal.LivingEntity_, $$1: Internal.Entity_): void;
        setCustomName($$0: net.minecraft.network.chat.Component_): void;
        getSlot($$0: number): Internal.SlotAccess;
        lambdynlights$scheduleTrackedChunksRebuild(renderer: Internal.LevelRenderer_): void;
        "deserializeNBT(net.minecraft.nbt.CompoundTag)"(nbt: Internal.CompoundTag_): void;
        emf$isInLava(): boolean;
        pehkui_constructScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        handler$hak000$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        getTeamId(): string;
        stopSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isUnderWater(): boolean;
        stopRiding(): void;
        isCustomNameVisible(): boolean;
        isSupportedBy($$0: BlockPos_): boolean;
        getPistonPushReaction(): Internal.PushReaction;
        getX($$0: number): number;
        lookAt($$0: Internal.EntityAnchorArgument$Anchor_, $$1: Vec3d_): void;
        getLuminance(): number;
        callUnsetRemoved(): void;
        getSelfAndPassengers(): Internal.Stream<any>;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        getDeltaMovement(): Vec3d;
        collide($$0: Vec3d_): Vec3d;
        getMotionX(): number;
        "onSyncedDataUpdated(java.util.List)"($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        hasPassenger($$0: Internal.Entity_): boolean;
        be_getTravelerState(): Internal.TravelerState;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        hasIndirectPassenger($$0: Internal.Entity_): boolean;
        getDynamicLightX(): number;
        getEntityData(): Internal.SynchedEntityData;
        setSecondsOnFire($$0: number): void;
        moveTo($$0: number, $$1: number, $$2: number): void;
        emf$getZ(): number;
        "getDisplayName()"(): net.minecraft.network.chat.Component;
        handleInsidePortal($$0: BlockPos_): void;
        setMotion($$0: number, $$1: number, $$2: number): void;
        playSound($$0: Internal.SoundEvent_): void;
        absMoveTo($$0: number, $$1: number, $$2: number): void;
        isOnRails(): boolean;
        getAttachedOrThrow<A>(type: Internal.AttachmentType_<A>): A;
        handler$ikg000$lithium$tryShortcutFluidPushing(tag: Internal.TagKey_<any>, speed: number, cir: Internal.CallbackInfoReturnable_<any>, box: Internal.AABB_, x1: number, x2: number, y1: number, y2: number, z1: number, z2: number, zero: number): void;
        handler$hak000$gobber2$setFrozenTicks(frozenTicks: number, ci: Internal.CallbackInfo_): void;
        restoreFrom($$0: Internal.Entity_): void;
        markFusionRecomputeModels(): void;
        getDimensionChangingDelay(): number;
        isPeacefulCreature(): boolean;
        setOnGround($$0: boolean): void;
        emf$getYaw(): number;
        handler$cbi000$besmirchment$getScoreboardTeam(cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDynamicLuminance(): number;
        setPos($$0: number, $$1: number, $$2: number): void;
        setYaw($$0: number): void;
        getPickRadius(): number;
        notify(): void;
        getVehicle(): Internal.Entity;
        isEffectiveAi(): boolean;
        handler$kom000$porting_lib_entity$port_lib$startRiding(entity: Internal.Entity_, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        startRiding($$0: Internal.Entity_, $$1: boolean): boolean;
        getStringUuid(): string;
        isRemoved(): boolean;
        emf$isSneaking(): boolean;
        setSwimming($$0: boolean): void;
        teleportToWithTicket($$0: number, $$1: number, $$2: number): void;
        fillCrashReportCategory($$0: Internal.CrashReportCategory_): void;
        getRotationVector(): Internal.Vec2;
        refreshDimensions(): void;
        pehkui_writeScaleNbt(nbt: Internal.CompoundTag_): Internal.CompoundTag;
        self(): Internal.Entity;
        etf$getBlockY(): number;
        isSprinting(): boolean;
        "spawnAtLocation(net.minecraft.world.level.ItemLike)"($$0: Internal.ItemLike_): Internal.ItemEntity;
        getMotionY(): number;
        canCollideWith($$0: Internal.Entity_): boolean;
        setLuminance(luminance: number): void;
        setShiftKeyDown($$0: boolean): void;
        getEyePosition($$0: number): Vec3d;
        getPassengers(): Internal.EntityArrayList;
        getBlockExplosionResistance($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.FluidState_, $$5: number): number;
        handler$ldh000$puzzleslib$spawnAtLocation(stack: Internal.ItemStack_, offsetY: number, callback: Internal.CallbackInfoReturnable_<any>, itemEntity: Internal.ItemEntity_): void;
        getZ(): number;
        canSpawnSprintParticle(): boolean;
        "moveTo(net.minecraft.core.BlockPos,float,float)"($$0: BlockPos_, $$1: number, $$2: number): void;
        static loadVariant($$0: Internal.CompoundTag_): Optional<Internal.Holder<Internal.PaintingVariant>>;
        teleportTo($$0: number, $$1: number, $$2: number): void;
        handler$zbk000$porting_lib_base$port_lib$spawnSprintParticle(ci: Internal.CallbackInfo_, pos: BlockPos_, state: Internal.BlockState_): void;
        getServer(): Internal.MinecraftServer;
        moveRelative($$0: number, $$1: Vec3d_): void;
        getFirstPassenger(): Internal.Entity;
        handler$gia00e$fastpaintings$tick(ci: Internal.CallbackInfo_): void;
        saveAsPassenger($$0: Internal.CompoundTag_): boolean;
        static gatherClosestChunks(chunks: Internal.LongSet_, x: number, y: number, z: number): void;
        handler$kom000$porting_lib_entity$afterSave(nbt: Internal.CompoundTag_, cir: Internal.CallbackInfoReturnable_<any>): void;
        interact($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        getDismountLocationForPassenger($$0: Internal.LivingEntity_): Vec3d;
        checkSlowFallDistance(): void;
        getSoundSource(): Internal.SoundSource;
        setFabricBalmData(tag: Internal.CompoundTag_): void;
        removeAfterChangingDimensions(): void;
        getPose(): Internal.Pose;
        touchingUnloadedChunk(): boolean;
        getLookAngle(): Vec3d;
        setPositionAndRotation($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        emf$isOnFire(): boolean;
        getMotionZ(): number;
        etf$getUuid(): Internal.UUID;
        removeVehicle(): void;
        isInvisible(): boolean;
        shouldFusionRecomputeModel(layerIndex: number): boolean;
        is($$0: Internal.Entity_): boolean;
        setZ(z: number): void;
        ejectPassengers(): void;
        getY(): number;
        deserializeNBT(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        updateDynamicLightPreviousCoordinates(): void;
        getProfile(): Internal.GameProfile;
        static setViewScale($$0: number): void;
        emf$isAlive(): boolean;
        setLevelCallback($$0: Internal.EntityInLevelCallback_): void;
        showVehicleHealth(): boolean;
        getDistance(pos: BlockPos_): number;
        playSound($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        emf$getVelocity(): Vec3d;
        etf$isBlockEntity(): boolean;
        shouldUpdateDynamicLight(): boolean;
        startSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isOnScoreboardTeam(teamId: string): boolean;
        isPushedByFluid(): boolean;
        localvar$bbb000$architectury$modifyLevelCallback_setLevelCallback(callback: Internal.EntityInLevelCallback_): Internal.EntityInLevelCallback;
        position(): Vec3d;
        setTimeout(): void;
        displayFireAnimation(): boolean;
        turn($$0: number, $$1: number): void;
        isOutOfCamera(): boolean;
        getAirSupply(): number;
        getRopeHoldPosition($$0: number): Vec3d;
        copyPosition($$0: Internal.Entity_): void;
        "hasPassenger(net.minecraft.world.entity.Entity)"($$0: Internal.Entity_): boolean;
        etf$canBeBright(): boolean;
        isCrouching(): boolean;
        moveTo($$0: BlockPos_, $$1: number, $$2: number): void;
        isPlayer(): boolean;
        isAnimal(): boolean;
        survives(): boolean;
        "handler$fgd000$fabric-dimensions-v1$getTeleportTarget"(destination: Internal.ServerLevel_, cir: Internal.CallbackInfoReturnable_<any>): void;
        canBeCollidedWith(): boolean;
        getMotionDirection(): Internal.Direction;
        asComponentProvider(): Internal.ComponentProvider;
        setY(y: number): void;
        getFeetBlockState(): Internal.BlockState;
        lavaHurt(): void;
        handleDamageEvent($$0: DamageSource_): void;
        getFabricBalmData(): Internal.CompoundTag;
        canChangeDimensions(): boolean;
        getChangeListener(): Internal.EntityInLevelCallback;
        static tickEntity(entity: Internal.Entity_): void;
        getCommandSenderWorld(): Internal.Level;
        positionRider($$0: Internal.Entity_): void;
        baseTick(): void;
        broadcastToPlayer($$0: Internal.ServerPlayer_): boolean;
        changeDimension($$0: Internal.ServerLevel_): Internal.Entity;
        setSharedFlag($$0: number, $$1: boolean): void;
        handler$kom000$porting_lib_entity$afterLoad(nbt: Internal.CompoundTag_, ci: Internal.CallbackInfo_): void;
        getCustomName(): net.minecraft.network.chat.Component;
        getClass(): typeof any;
        pehkui_shouldIgnoreScaleNbt(): boolean;
        isMoving(): boolean;
        isVisuallySwimming(): boolean;
        getMaxAirSupply(): number;
        attack(hp: number): void;
        dynamicLightTick(): void;
        getFacing(): Internal.Direction;
        emf$isWet(): boolean;
        "hasPassenger(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.Entity>): boolean;
        getDimensions($$0: Internal.Pose_): Internal.EntityDimensions;
        getHeight(): number;
        isPassengerOfSameVehicle($$0: Internal.Entity_): boolean;
        invokeGetLeashOffset(): Vec3d;
        isSwimming(): boolean;
        getBoundingBoxForCulling(): Internal.AABB;
        mayInteract($$0: Internal.Level_, $$1: BlockPos_): boolean;
        static collideBoundingBox(entity: Internal.Entity_, movement: Vec3d_, entityBoundingBox: Internal.AABB_, world: Internal.Level_, collisions: Internal.List_<any>): Vec3d;
        setSprinting($$0: boolean): void;
        getDynamicLightLevel(): Internal.Level;
        setPortalCooldown(): void;
        setX(x: number): void;
        trackingPosition(): Vec3d;
        getNameTagOffsetY(): number;
        isInvulnerable(): boolean;
        isInLava(): boolean;
        isInWater(): boolean;
        getPortalWaitTime(): number;
        awardKillScore($$0: Internal.Entity_, $$1: number, $$2: DamageSource_): void;
        getBlockStateOn(): Internal.BlockState;
        getFluidHeightLoosely(tag: Internal.TagKey_<any>): number;
        getFluidJumpThreshold(): number;
        unsetRemoved(): void;
        "getVariant()"(): any;
        "setPositionAndRotation(double,double,double,float,float)"($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        isInvisibleTo($$0: Internal.Player_): boolean;
        pehkui_getScaleCache(): Internal.ScaleData[];
        setFusionModel(layerIndex: number, model: Internal.Triple_<any, any, any>): void;
        setAirSupply($$0: number): void;
        getOnPos(): BlockPos;
        getRootVehicle(): Internal.Entity;
        etf$getWorld(): Internal.Level;
        save($$0: Internal.CompoundTag_): boolean;
        pehkui_getScales(): Internal.Map<any, any>;
        isNoGravity(): boolean;
        etf$getNbt(): Internal.CompoundTag;
        acceptsFailure(): boolean;
        etf$getBlockPos(): BlockPos;
        pehkui_setShouldIgnoreScaleNbt(ignore: boolean): void;
        setOnGroundWithKnownMovement($$0: boolean, $$1: Vec3d_): void;
        setOldPosAndRot(): void;
        emf$getY(): number;
        handler$kom000$porting_lib_entity$port_lib$entityInit(entityType: Internal.EntityType_<any>, world: Internal.Level_, ci: Internal.CallbackInfo_): void;
        bookshelf$createHoverEvent(): Internal.HoverEvent;
        isFree($$0: number, $$1: number, $$2: number): boolean;
        updateSwimming(): void;
        "moveTo(double,double,double)"($$0: number, $$1: number, $$2: number): void;
        setRemainingFireTicks($$0: number): void;
        getCachedFeetBlockState(): Internal.BlockState;
        shouldInformAdmins(): boolean;
        rideTick(): void;
        emf$age(): number;
        etf$hasCustomName(): boolean;
        /**
         * @deprecated
        */
        getOnPosLegacy(): BlockPos;
        setPos($$0: Vec3d_): void;
        wait(): void;
        getUuid(): Internal.UUID;
        spawn(): void;
        teleportTo($$0: Internal.ServerLevel_, $$1: number, $$2: number, $$3: number, $$4: Internal.Set_<Internal.RelativeMovement>, $$5: number, $$6: number): boolean;
        handler$kom000$porting_lib_entity$port_lib$removeRidingEntity(ci: Internal.CallbackInfo_): void;
        etf$getCustomName(): net.minecraft.network.chat.Component;
        captureDrops(value: Internal.Collection_<any>): Internal.Collection<any>;
        fabric_writeAttachmentsToNbt(nbt: Internal.CompoundTag_): void;
        shouldShowName(): boolean;
        setSilent($$0: boolean): void;
        getArmorSlots(): Internal.Iterable<Internal.ItemStack>;
        hasExactlyOnePlayerPassenger(): boolean;
        kill(): void;
        isOnPortalCooldown(): boolean;
        animateHurt($$0: number): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        handler$kom000$porting_lib_entity$port_lib$onEntityRemove(reason: Internal.Entity$RemovalReason_, ci: Internal.CallbackInfo_): void;
        lambdynlights$setTrackedLitChunkPos(trackedLitChunkPos: Internal.LongSet_): void;
        callGetEyeHeight(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        setPitch($$0: number): void;
        setPosRaw($$0: number, $$1: number, $$2: number): void;
        handleEntityEvent($$0: number): void;
        isAlwaysTicking(): boolean;
        porting_lib$setVariant(arg0: Internal.Holder_<any>): void;
        interactAt($$0: Internal.Player_, $$1: Vec3d_, $$2: Internal.InteractionHand_): Internal.InteractionResult;
        emf$getX(): number;
        deserializeNBT(arg0: Internal.Tag_): void;
        puzzleslib$acceptCapturedDrops(capturedDrops: Internal.Collection_<any>): Internal.Collection<any>;
        handler$hak000$gobber2$gobberIsFireImmune(cir: Internal.CallbackInfoReturnable_<any>): void;
        lerpTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: boolean): void;
        onPassengerTurned($$0: Internal.Entity_): void;
        modifyReturnValue$zhe000$additionalentityattributes$getMaxAir(original: number): number;
        "setVariant(net.minecraft.core.Holder)"($$0: Internal.Holder_<Internal.PaintingVariant>): void;
        spawnAtLocation($$0: Internal.ItemLike_): Internal.ItemEntity;
        emf$hasPassengers(): boolean;
        serializeNBT(): Internal.CompoundTag;
        setAttached(type: Internal.AttachmentType_<any>, value: any): any;
        getBbWidth(): number;
        splitIntoDynamicLightEntries(): Internal.Stream<Internal.SpatialLookupEntry>;
        port_lib$getEntityString(): string;
        addDeltaMovement($$0: Vec3d_): void;
        pehkui_setOnGround(onGround: boolean): void;
        lithiumOnBlockCacheDeleted(): void;
        "spawnAtLocation(net.minecraft.world.level.ItemLike,int)"($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        setInvulnerable($$0: boolean): void;
        "getName()"(): net.minecraft.network.chat.Component;
        push($$0: Internal.Entity_): void;
        emf$hasVehicle(): boolean;
        mirror($$0: Internal.Mirror_): number;
        static port_lib$collideWithShapes(vec3: Vec3d_, aABB: Internal.AABB_, list: Internal.List_<Internal.VoxelShape>): Vec3d;
        getTicksRequiredToFreeze(): number;
        getDynamicLightPrevY(): number;
        maxUpStep(): number;
        setGlowing($$0: boolean): void;
        load($$0: Internal.CompoundTag_): void;
        isAlive(): boolean;
        emf$prevZ(): number;
        getBbHeight(): number;
        getUsername(): string;
        static storeVariant($$0: Internal.CompoundTag_, $$1: Internal.Holder_<Internal.PaintingVariant>): void;
        move($$0: Internal.MoverType_, $$1: Vec3d_): void;
        getTags(): Internal.Set<string>;
        getViewVector($$0: number): Vec3d;
        "setVariant(java.lang.Object)"(arg0: any): void;
        lithiumOnBlockCacheSet(newState: Internal.BlockState_): void;
        isPickable(): boolean;
        setYHeadRot($$0: number): void;
        hasControllingPassenger(): boolean;
        getVariant(): Internal.Holder<Internal.PaintingVariant>;
        closerThan($$0: Internal.Entity_, $$1: number, $$2: number): boolean;
        absMoveTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        getCustomData(): Internal.CompoundTag;
        getPickResult(): Internal.ItemStack;
        getPercentFrozen(): number;
        getRandomY(): number;
        setPortalCooldown($$0: number): void;
        getDisplayName(): net.minecraft.network.chat.Component;
        hasGlowingTag(): boolean;
        shouldBlockExplode($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: number): boolean;
        emf$isInvisible(): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        emf$isSprinting(): boolean;
        getVariant(): any;
        getDynamicLightPrevX(): number;
        shouldBeSaved(): boolean;
        fabric_hasPersistentAttachments(): boolean;
        getViewXRot($$0: number): number;
        canRiderInteract(): boolean;
        method_5749($$0: Internal.CompoundTag_): void;
        fabric_getAttachments(): Internal.Map<any, any>;
        removeTag($$0: string): boolean;
        setPose($$0: Internal.Pose_): void;
        getFluidHeight($$0: Internal.TagKey_<Internal.Fluid>): number;
        getEntityType(): Internal.EntityType<any>;
        isWaterCreature(): boolean;
        pehkui_getScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        toString(): string;
        notifyAll(): void;
        getPassengersRidingOffset(): number;
        etf$getScoreboardTeam(): Internal.Team;
        distanceToEntitySqr($$0: Internal.Entity_): number;
        handler$ldh000$puzzleslib$removeVehicle(callback: Internal.CallbackInfo_): void;
        "getServer()"(): Internal.MinecraftServer;
        isFrame(): boolean;
        isPushable(): boolean;
        setYBodyRot($$0: number): void;
        discard(): void;
        onClientRemoval(): void;
        "handler$mhe000$step-height-entity-attribute$getStepHeight"(cir: Internal.CallbackInfoReturnable_<any>): void;
        sendSystemMessage($$0: net.minecraft.network.chat.Component_): void;
        acceptsSuccess(): boolean;
        getDistance(x: number, y: number, z: number): number;
        setMotionY(y: number): void;
        setNoGravity($$0: boolean): void;
        getAttached(type: Internal.AttachmentType_<any>): any;
        getIndirectPassengers(): Internal.Iterable<any>;
        setRotation(yaw: number, pitch: number): void;
        isDynamicLightEnabled(): boolean;
        handler$ldh000$puzzleslib$startRiding(vehicle: Internal.Entity_, force: boolean, callback: Internal.CallbackInfoReturnable_<any>): void;
        createCommandSourceStack(): Internal.CommandSourceStack;
        isControlledByLocalInstance(): boolean;
        isMonster(): boolean;
        pehkui_setShouldSyncScales(sync: boolean): void;
        setLastDynamicLuminance(luminance: number): void;
        getHorizontalFacing(): Internal.Direction;
        setId($$0: number): void;
        onSyncedDataUpdated($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        getType(): string;
        getLightProbePosition($$0: number): Vec3d;
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        onAboveBubbleCol($$0: boolean): void;
        emf$prevX(): number;
        "playSound(net.minecraft.sounds.SoundEvent,float,float)"($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        toComponentPacket(key: Internal.ComponentKey_<any>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        isPassenger(): boolean;
        hasPose($$0: Internal.Pose_): boolean;
        checkDespawn(): void;
        pehkui_shouldSyncScales(): boolean;
        isEyeInFluid($$0: Internal.TagKey_<Internal.Fluid>): boolean;
        isInvulnerableTo($$0: DamageSource_): boolean;
        makeStuckInBlock($$0: Internal.BlockState_, $$1: Vec3d_): void;
        getAttachedOrGet<A>(type: Internal.AttachmentType_<A>, defaultValue: Internal.Supplier_<A>): A;
        skipAttackInteraction($$0: Internal.Entity_): boolean;
        lerpMotion($$0: number, $$1: number, $$2: number): void;
        shouldRender($$0: number, $$1: number, $$2: number): boolean;
        onSyncedDataUpdated($$0: Internal.EntityDataAccessor_<any>): void;
        lerpHeadTo($$0: number, $$1: number): void;
        handler$bia000$axiom$onTurn(d: number, e: number, ci: Internal.CallbackInfo_): void;
        static getViewScale(): number;
        setMotionX(x: number): void;
        getHandSlots(): Internal.Iterable<Internal.ItemStack>;
        distanceToEntity($$0: Internal.Entity_): number;
        getVisualRotationYInDegrees(): number;
        playPlacementSound(): void;
        wait(arg0: number, arg1: number): void;
        isDiscrete(): boolean;
        getTeamColor(): number;
        setNbt(nbt: Internal.CompoundTag_): void;
        lithiumSetClimbingMobCachingSectionUpdateBehavior(listening: boolean): void;
        unRide(): void;
        getLevel(): Internal.Level;
        "spawnAtLocation(net.minecraft.world.item.ItemStack)"($$0: Internal.ItemStack_): Internal.ItemEntity;
        lambdynlights$getTrackedLitChunkPos(): Internal.LongSet;
        extinguish(): void;
        setDynamicLightEnabled(enabled: boolean): void;
        updateDynamicGameEventListener($$0: Internal.BiConsumer_<Internal.DynamicGameEventListener<any>, Internal.ServerLevel>): void;
        moveTo($$0: Vec3d_): void;
        isColliding($$0: BlockPos_, $$1: Internal.BlockState_): boolean;
        "onSyncedDataUpdated(net.minecraft.network.syncher.EntityDataAccessor)"($$0: Internal.EntityDataAccessor_<any>): void;
        emf$prevY(): number;
        extinguishFire(): void;
        lambdynlights$updateDynamicLight(renderer: Internal.LevelRenderer_): boolean;
        tell(message: net.minecraft.network.chat.Component_): void;
        "getVariant()"(): Internal.Holder<Internal.PaintingVariant>;
        static port_lib$collideWithShapes$porting_lib_accessors_$md$424943$0(arg0: Vec3d_, arg1: Internal.AABB_, arg2: Internal.List_<any>): Vec3d;
        isForcedVisible(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number): boolean;
        getDistanceSq(pos: BlockPos_): number;
        emf$getTypeString(): string;
        killedEntity($$0: Internal.ServerLevel_, $$1: Internal.LivingEntity_): boolean;
        getAttachedOrElse<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        isFreezing(): boolean;
        setVariant(arg0: any): void;
        isFullyFrozen(): boolean;
        runCommand(command: string): number;
        setSharedFlagOnFire($$0: boolean): void;
        get inWall(): boolean
        get allSlots(): Internal.Iterable<Internal.ItemStack>
        get blockZ(): number
        get suppressingBounce(): boolean
        get silent(): boolean
        set culled(value: boolean)
        get pitch(): number
        get onFire(): boolean
        get positionCodec(): Internal.VecDeltaCodec
        get passengersAndSelf(): Internal.Stream<any>
        set maxUpStep($$0: number)
        get shiftKeyDown(): boolean
        set UUID($$0: Internal.UUID_)
        get visuallyCrawling(): boolean
        set variant($$0: Internal.Holder_<Internal.PaintingVariant>)
        set motionZ(z: number)
        get blockY(): number
        get isInsideStructureTracker(): Internal.IsInsideStructureTracker
        get spectator(): boolean
        get inWaterOrBubble(): boolean
        get persistentData(): Internal.CompoundTag
        get portalCooldown(): number
        get item(): Internal.ItemStack
        set removed($$0: Internal.Entity$RemovalReason_)
        get inWaterRainOrBubble(): boolean
        get removalReason(): Internal.Entity$RemovalReason
        get ignoringBlockTriggers(): boolean
        get steppingCarefully(): boolean
        set boundingBox($$0: Internal.AABB_)
        get ambientCreature(): boolean
        get pos(): BlockPos
        get blockX(): number
        /**
         * @deprecated
        */
        get lightLevelDependentMagicValue(): number
        get encodeId(): string
        get block(): Internal.BlockContainerJS
        get nbt(): Internal.CompoundTag
        set invisible($$0: boolean)
        get name(): net.minecraft.network.chat.Component
        get dynamicLightY(): number
        get controlledVehicle(): Internal.Entity
        get eyePosition(): Vec3d
        get eyeHeight(): number
        get yaw(): number
        get componentContainer(): Internal.ComponentContainer
        get dynamicLightPrevZ(): number
        set customNameVisible($$0: boolean)
        set outOfCamera(value: boolean)
        get controllingPassenger(): Internal.LivingEntity
        get remainingFireTicks(): number
        get scriptType(): Internal.ScriptType
        get forward(): Vec3d
        get maxFallDistance(): number
        get id(): number
        get ticksFrozen(): number
        get recipientsForComponentSync(): Internal.Iterable<any>
        get dynamicLightZ(): number
        get eyeY(): number
        set direction($$0: Internal.Direction_)
        set statusMessage(message: net.minecraft.network.chat.Component_)
        get boundingBox(): Internal.AABB
        get inWaterOrRain(): boolean
        get descending(): boolean
        get YHeadRot(): number
        get addEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>
        get team(): Internal.Team
        set ticksFrozen($$0: number)
        get width(): number
        get myRidingOffset(): number
        set deltaMovement($$0: Vec3d_)
        get culled(): boolean
        get living(): boolean
        get glowing(): boolean
        get x(): number
        get vehicle(): boolean
        get leashOffset(): Vec3d
        get attackable(): boolean
        set isInPowderSnow($$0: boolean)
        set customName($$0: net.minecraft.network.chat.Component_)
        get teamId(): string
        get underWater(): boolean
        get customNameVisible(): boolean
        get pistonPushReaction(): Internal.PushReaction
        get luminance(): number
        get selfAndPassengers(): Internal.Stream<any>
        get deltaMovement(): Vec3d
        get motionX(): number
        get dynamicLightX(): number
        get entityData(): Internal.SynchedEntityData
        set secondsOnFire($$0: number)
        get "displayName()"(): net.minecraft.network.chat.Component
        get onRails(): boolean
        get dimensionChangingDelay(): number
        get peacefulCreature(): boolean
        set onGround($$0: boolean)
        get lastDynamicLuminance(): number
        set yaw($$0: number)
        get pickRadius(): number
        get vehicle(): Internal.Entity
        get effectiveAi(): boolean
        get stringUuid(): string
        get removed(): boolean
        set swimming($$0: boolean)
        get rotationVector(): Internal.Vec2
        get sprinting(): boolean
        get motionY(): number
        set luminance(luminance: number)
        set shiftKeyDown($$0: boolean)
        get passengers(): Internal.EntityArrayList
        get z(): number
        get server(): Internal.MinecraftServer
        get firstPassenger(): Internal.Entity
        get soundSource(): Internal.SoundSource
        set fabricBalmData(tag: Internal.CompoundTag_)
        get pose(): Internal.Pose
        get lookAngle(): Vec3d
        get motionZ(): number
        get invisible(): boolean
        set z(z: number)
        get y(): number
        get profile(): Internal.GameProfile
        set viewScale($$0: number)
        set levelCallback($$0: Internal.EntityInLevelCallback_)
        get pushedByFluid(): boolean
        get outOfCamera(): boolean
        get airSupply(): number
        get crouching(): boolean
        get player(): boolean
        get animal(): boolean
        get motionDirection(): Internal.Direction
        set y(y: number)
        get feetBlockState(): Internal.BlockState
        get fabricBalmData(): Internal.CompoundTag
        get changeListener(): Internal.EntityInLevelCallback
        get commandSenderWorld(): Internal.Level
        get customName(): net.minecraft.network.chat.Component
        get class(): typeof any
        get moving(): boolean
        get visuallySwimming(): boolean
        get maxAirSupply(): number
        get facing(): Internal.Direction
        get height(): number
        get swimming(): boolean
        get boundingBoxForCulling(): Internal.AABB
        set sprinting($$0: boolean)
        get dynamicLightLevel(): Internal.Level
        set x(x: number)
        get nameTagOffsetY(): number
        get invulnerable(): boolean
        get inLava(): boolean
        get inWater(): boolean
        get portalWaitTime(): number
        get blockStateOn(): Internal.BlockState
        get fluidJumpThreshold(): number
        get "variant()"(): any
        set airSupply($$0: number)
        get onPos(): BlockPos
        get rootVehicle(): Internal.Entity
        get noGravity(): boolean
        set remainingFireTicks($$0: number)
        get cachedFeetBlockState(): Internal.BlockState
        /**
         * @deprecated
        */
        get onPosLegacy(): BlockPos
        set pos($$0: Vec3d_)
        get uuid(): Internal.UUID
        set silent($$0: boolean)
        get armorSlots(): Internal.Iterable<Internal.ItemStack>
        get onPortalCooldown(): boolean
        set pitch($$0: number)
        get alwaysTicking(): boolean
        set "variant(net.minecraft.core.Holder)"($$0: Internal.Holder_<Internal.PaintingVariant>)
        get bbWidth(): number
        set invulnerable($$0: boolean)
        get "name()"(): net.minecraft.network.chat.Component
        get ticksRequiredToFreeze(): number
        get dynamicLightPrevY(): number
        set glowing($$0: boolean)
        get alive(): boolean
        get bbHeight(): number
        get username(): string
        get tags(): Internal.Set<string>
        set "variant(java.lang.Object)"(arg0: any)
        get pickable(): boolean
        set YHeadRot($$0: number)
        get variant(): Internal.Holder<Internal.PaintingVariant>
        get customData(): Internal.CompoundTag
        get pickResult(): Internal.ItemStack
        get percentFrozen(): number
        get randomY(): number
        set portalCooldown($$0: number)
        get displayName(): net.minecraft.network.chat.Component
        set position(block: Internal.BlockContainerJS_)
        get variant(): any
        get dynamicLightPrevX(): number
        set pose($$0: Internal.Pose_)
        get entityType(): Internal.EntityType<any>
        get waterCreature(): boolean
        get passengersRidingOffset(): number
        get "server()"(): Internal.MinecraftServer
        get frame(): boolean
        get pushable(): boolean
        set YBodyRot($$0: number)
        set motionY(y: number)
        set noGravity($$0: boolean)
        get indirectPassengers(): Internal.Iterable<any>
        get dynamicLightEnabled(): boolean
        get controlledByLocalInstance(): boolean
        get monster(): boolean
        set lastDynamicLuminance(luminance: number)
        get horizontalFacing(): Internal.Direction
        set id($$0: number)
        get type(): string
        get passenger(): boolean
        get viewScale(): number
        set motionX(x: number)
        get handSlots(): Internal.Iterable<Internal.ItemStack>
        get visualRotationYInDegrees(): number
        get discrete(): boolean
        get teamColor(): number
        set nbt(nbt: Internal.CompoundTag_)
        get level(): Internal.Level
        set dynamicLightEnabled(enabled: boolean)
        get "variant()"(): Internal.Holder<Internal.PaintingVariant>
        get forcedVisible(): boolean
        get freezing(): boolean
        set variant(arg0: any)
        get fullyFrozen(): boolean
        set sharedFlagOnFire($$0: boolean)
        static readonly VARIANT_TAG: ("variant") & (string);
    }
    type Painting_ = Painting;
    class NoiseColumn implements Internal.BlockColumn {
        constructor($$0: number, $$1: Internal.BlockState_[])
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        getBlock($$0: number): Internal.BlockState;
        wait(arg0: number): void;
        setBlock($$0: number, $$1: Internal.BlockState_): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
    }
    type NoiseColumn_ = NoiseColumn;
    interface Boolean2ReferenceFunction <V> extends it.unimi.dsi.fastutil.Function<boolean, V> {
        put(arg0: boolean, arg1: V): V;
        andThenInt(arg0: Internal.Reference2IntFunction_<V>): Internal.Boolean2IntFunction;
        composeShort(arg0: Internal.Short2BooleanFunction_): Internal.Short2ReferenceFunction<V>;
        /**
         * @deprecated
        */
        "getOrDefault(java.lang.Object,java.lang.Object)"(arg0: any, arg1: V): V;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: V): V;
        andThenFloat(arg0: Internal.Reference2FloatFunction_<V>): Internal.Boolean2FloatFunction;
        composeInt(arg0: Internal.Int2BooleanFunction_): Internal.Int2ReferenceFunction<V>;
        composeObject<T>(arg0: Internal.Object2BooleanFunction_<T>): Internal.Object2ReferenceFunction<T, V>;
        /**
         * @deprecated
        */
        "put(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): any;
        composeChar(arg0: Internal.Char2BooleanFunction_): Internal.Char2ReferenceFunction<V>;
        /**
         * @deprecated
        */
        containsKey(arg0: any): boolean;
        composeByte(arg0: Internal.Byte2BooleanFunction_): Internal.Byte2ReferenceFunction<V>;
        composeFloat(arg0: Internal.Float2BooleanFunction_): Internal.Float2ReferenceFunction<V>;
        "remove(boolean)"(arg0: boolean): V;
        /**
         * @deprecated
        */
        put(arg0: boolean, arg1: V): V;
        /**
         * @deprecated
        */
        "get(java.lang.Object)"(arg0: any): V;
        andThenObject<T>(arg0: Internal.Reference2ObjectFunction_<V, T>): Internal.Boolean2ObjectFunction<T>;
        /**
         * @deprecated
        */
        get(arg0: any): V;
        /**
         * @deprecated
        */
        "put(java.lang.Boolean,java.lang.Object)"(arg0: boolean, arg1: V): V;
        andThenShort(arg0: Internal.Reference2ShortFunction_<V>): Internal.Boolean2ShortFunction;
        /**
         * @deprecated
        */
        put(arg0: any, arg1: any): any;
        andThenDouble(arg0: Internal.Reference2DoubleFunction_<V>): Internal.Boolean2DoubleFunction;
        /**
         * @deprecated
        */
        remove(arg0: any): V;
        "containsKey(boolean)"(arg0: boolean): boolean;
        /**
         * @deprecated
        */
        compose<T>(arg0: Internal.Function_<T, boolean>): Internal.Function<T, V>;
        andThenChar(arg0: Internal.Reference2CharFunction_<V>): Internal.Boolean2CharFunction;
        apply(arg0: boolean): V;
        "getOrDefault(boolean,java.lang.Object)"(arg0: boolean, arg1: V): V;
        abstract get(arg0: boolean): V;
        abstract "get(boolean)"(arg0: boolean): V;
        composeDouble(arg0: Internal.Double2BooleanFunction_): Internal.Double2ReferenceFunction<V>;
        andThen<V>(arg0: Internal.Function_<V, V>): Internal.Function<boolean, V>;
        composeReference<T>(arg0: Internal.Reference2BooleanFunction_<T>): Internal.Reference2ReferenceFunction<T, V>;
        "put(boolean,java.lang.Object)"(arg0: boolean, arg1: V): V;
        containsKey(arg0: boolean): boolean;
        remove(arg0: boolean): V;
        size(): number;
        andThenLong(arg0: Internal.Reference2LongFunction_<V>): Internal.Boolean2LongFunction;
        andThenByte(arg0: Internal.Reference2ByteFunction_<V>): Internal.Boolean2ByteFunction;
        andThenReference<T>(arg0: Internal.Reference2ReferenceFunction_<V, T>): Internal.Boolean2ReferenceFunction<T>;
        clear(): void;
        composeLong(arg0: Internal.Long2BooleanFunction_): Internal.Long2ReferenceFunction<V>;
        defaultReturnValue(): V;
        getOrDefault(arg0: boolean, arg1: V): V;
        identity<T>(): Internal.Function<T, T>;
        defaultReturnValue(arg0: V): void;
        /**
         * @deprecated
        */
        "remove(java.lang.Object)"(arg0: any): V;
        /**
         * @deprecated
        */
        "containsKey(java.lang.Object)"(arg0: any): boolean;
    }
    type Boolean2ReferenceFunction_<V> = Boolean2ReferenceFunction<V>;
    interface LocalPlayerInterface {
        abstract getCurrentConstantMood(): number;
        get currentConstantMood(): number
        (): number;
    }
    type LocalPlayerInterface_ = (()=> number) | LocalPlayerInterface;
    interface DensityFunction$SimpleFunction extends Internal.DensityFunction {
        abs(): Internal.DensityFunction;
        halfNegative(): Internal.DensityFunction;
        abstract maxValue(): number;
        abstract codec(): Internal.KeyDispatchDataCodec<Internal.DensityFunction>;
        abstract compute(arg0: Internal.DensityFunction$FunctionContext_): number;
        squeeze(): Internal.DensityFunction;
        square(): Internal.DensityFunction;
        mapAll($$0: Internal.DensityFunction$Visitor_): Internal.DensityFunction;
        clamp($$0: number, $$1: number): Internal.DensityFunction;
        quarterNegative(): Internal.DensityFunction;
        cube(): Internal.DensityFunction;
        fillArray($$0: number[], $$1: Internal.DensityFunction$ContextProvider_): void;
        abstract minValue(): number;
    }
    type DensityFunction$SimpleFunction_ = DensityFunction$SimpleFunction;
    class PosAlwaysTrueTest extends Internal.PosRuleTest {
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        test($$0: BlockPos_, $$1: BlockPos_, $$2: BlockPos_, $$3: Internal.RandomSource_): boolean;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        static readonly INSTANCE: (Internal.PosAlwaysTrueTest) & (Internal.PosAlwaysTrueTest);
        static readonly CODEC: Internal.Codec<Internal.PosAlwaysTrueTest>;
    }
    type PosAlwaysTrueTest_ = PosAlwaysTrueTest;
    class WandOfTheForestRecipe extends Internal.ShapedRecipe {
        constructor(compose: Internal.ShapedRecipe_)
        getGroup(): string;
        static dissolvePattern$bookshelf_$md$424943$3(arg0: string[], arg1: Internal.Map_<any, any>, arg2: number, arg3: number): Internal.NonNullList<any>;
        getToastSymbol(): Internal.ItemStack;
        "matches(net.minecraft.world.inventory.CraftingContainer,net.minecraft.world.level.Level)"($$0: Internal.CraftingContainer_, $$1: Internal.Level_): boolean;
        static keyFromJson$bookshelf_$md$424943$0(arg0: Internal.JsonObject_): Internal.Map<any, any>;
        notify(): void;
        getRemainingItems($$0: Internal.CraftingContainer_): Internal.NonNullList<Internal.ItemStack>;
        assemble(inv: Internal.CraftingContainer_, registries: Internal.RegistryAccess_): Internal.ItemStack;
        getId(): ResourceLocation;
        isIn(tag: ResourceLocation_): boolean;
        handler$bpa000$bclib$bcl_getRemainingItems(container: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>): void;
        static bookshelf$dissolvePattern(pattern: string[], ingredients: Internal.Map_<string, Internal.Ingredient>, width: number, height: number): Internal.NonNullList<Internal.Ingredient>;
        isSpecial(): boolean;
        getWidth(): number;
        "assemble(net.minecraft.world.inventory.CraftingContainer,net.minecraft.core.RegistryAccess)"(inv: Internal.CraftingContainer_, registries: Internal.RegistryAccess_): Internal.ItemStack;
        canCraftInDimensions($$0: number, $$1: number): boolean;
        showNotification(): boolean;
        replaceInput(match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): boolean;
        static itemStackFromJson($$0: Internal.JsonObject_): Internal.ItemStack;
        getType(): ResourceLocation;
        static dissolvePattern($$0: string[], $$1: Internal.Map_<string, Internal.Ingredient>, $$2: number, $$3: number): Internal.NonNullList<Internal.Ingredient>;
        "handler$fie000$fabric-item-api-v1$captureStack"(inventory: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>, defaultedList: Internal.NonNullList_<any>, i: number): void;
        wait(): void;
        isIncomplete(): boolean;
        matches($$0: Internal.CraftingContainer_, $$1: number, $$2: number, $$3: boolean): boolean;
        getClass(): typeof any;
        static keyFromJson($$0: Internal.JsonObject_): Internal.Map<string, Internal.Ingredient>;
        matches($$0: Internal.CraftingContainer_, $$1: Internal.Level_): boolean;
        getSchema(): Internal.RecipeSchema;
        "assemble(net.minecraft.world.Container,net.minecraft.core.RegistryAccess)"(arg0: net.minecraft.world.Container_, arg1: Internal.RegistryAccess_): Internal.ItemStack;
        wait(arg0: number, arg1: number): void;
        category(): Internal.CraftingBookCategory;
        static shrink$bookshelf_$md$424943$1(...arg0: string[]): string[];
        getSerializer(): Internal.RecipeSerializer<any>;
        assemble(arg0: net.minecraft.world.Container_, arg1: Internal.RegistryAccess_): Internal.ItemStack;
        static bookshelf$shrink(...pattern: string[]): string[];
        static bookshelf$keyFromJson($$0: Internal.JsonObject_): Internal.Map<string, Internal.Ingredient>;
        matches(arg0: net.minecraft.world.Container_, arg1: Internal.Level_): boolean;
        getHeight(): number;
        getMod(): string;
        getIngredients(): Internal.NonNullList<Internal.Ingredient>;
        hasOutput(match: Internal.ReplacementMatch_): boolean;
        getResultItem($$0: Internal.RegistryAccess_): Internal.ItemStack;
        toString(): string;
        notifyAll(): void;
        "matches(net.minecraft.world.Container,net.minecraft.world.level.Level)"(arg0: net.minecraft.world.Container_, arg1: Internal.Level_): boolean;
        static patternFromJson($$0: Internal.JsonArray_): string[];
        static shrink(...$$0: string[]): string[];
        setGroup(group: string): void;
        static itemFromJson($$0: Internal.JsonObject_): Internal.Item;
        static bookshelf$patternFromJson(json: Internal.JsonArray_): string[];
        hashCode(): number;
        getOrCreateId(): ResourceLocation;
        hasInput(match: Internal.ReplacementMatch_): boolean;
        static patternFromJson$bookshelf_$md$424943$2(arg0: Internal.JsonArray_): string[];
        wait(arg0: number): void;
        replaceOutput(match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): boolean;
        equals(arg0: any): boolean;
        get group(): string
        get toastSymbol(): Internal.ItemStack
        get id(): ResourceLocation
        get special(): boolean
        get width(): number
        get type(): ResourceLocation
        get incomplete(): boolean
        get class(): typeof any
        get schema(): Internal.RecipeSchema
        get serializer(): Internal.RecipeSerializer<any>
        get height(): number
        get mod(): string
        get ingredients(): Internal.NonNullList<Internal.Ingredient>
        set group(group: string)
        get orCreateId(): ResourceLocation
        static readonly SERIALIZER: (Internal.WandOfTheForestRecipe$Serializer) & (Internal.RecipeSerializer<Internal.WandOfTheForestRecipe>);
    }
    type WandOfTheForestRecipe_ = WandOfTheForestRecipe;
    class AugmentConsumer$Companion {
        constructor($constructor_marker: any_)
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
    }
    type AugmentConsumer$Companion_ = AugmentConsumer$Companion;
    interface Boolean2ByteFunction extends it.unimi.dsi.fastutil.Function<boolean, number> {
        composeFloat(arg0: Internal.Float2BooleanFunction_): Internal.Float2ByteFunction;
        composeDouble(arg0: Internal.Double2BooleanFunction_): Internal.Double2ByteFunction;
        remove(arg0: boolean): number;
        composeByte(arg0: Internal.Byte2BooleanFunction_): Internal.Byte2ByteFunction;
        /**
         * @deprecated
        */
        "put(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): any;
        defaultReturnValue(arg0: number): void;
        /**
         * @deprecated
        */
        remove(arg0: any): number;
        /**
         * @deprecated
        */
        put(arg0: any, arg1: any): any;
        /**
         * @deprecated
        */
        "get(java.lang.Object)"(arg0: any): number;
        defaultReturnValue(): number;
        composeInt(arg0: Internal.Int2BooleanFunction_): Internal.Int2ByteFunction;
        /**
         * @deprecated
        */
        get(arg0: any): number;
        andThenInt(arg0: Internal.Byte2IntFunction_): Internal.Boolean2IntFunction;
        andThenByte(arg0: Internal.Byte2ByteFunction_): this;
        composeLong(arg0: Internal.Long2BooleanFunction_): Internal.Long2ByteFunction;
        andThenLong(arg0: Internal.Byte2LongFunction_): Internal.Boolean2LongFunction;
        abstract "get(boolean)"(arg0: boolean): number;
        apply(arg0: boolean): number;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: number): number;
        /**
         * @deprecated
        */
        "remove(java.lang.Object)"(arg0: any): number;
        "put(boolean,byte)"(arg0: boolean, arg1: number): number;
        "remove(boolean)"(arg0: boolean): number;
        /**
         * @deprecated
        */
        "put(java.lang.Boolean,java.lang.Byte)"(arg0: boolean, arg1: number): number;
        composeReference<T>(arg0: Internal.Reference2BooleanFunction_<T>): Internal.Reference2ByteFunction<T>;
        identity<T>(): Internal.Function<T, T>;
        /**
         * @deprecated
        */
        "containsKey(java.lang.Object)"(arg0: any): boolean;
        andThenDouble(arg0: Internal.Byte2DoubleFunction_): Internal.Boolean2DoubleFunction;
        /**
         * @deprecated
        */
        "getOrDefault(java.lang.Object,java.lang.Byte)"(arg0: any, arg1: number): number;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: any): any;
        /**
         * @deprecated
        */
        compose<T>(arg0: Internal.Function_<T, boolean>): Internal.Function<T, number>;
        composeObject<T>(arg0: Internal.Object2BooleanFunction_<T>): Internal.Object2ByteFunction<T>;
        /**
         * @deprecated
        */
        containsKey(arg0: any): boolean;
        andThenShort(arg0: Internal.Byte2ShortFunction_): Internal.Boolean2ShortFunction;
        /**
         * @deprecated
        */
        "getOrDefault(java.lang.Object,java.lang.Object)"(arg0: any, arg1: any): any;
        composeChar(arg0: Internal.Char2BooleanFunction_): Internal.Char2ByteFunction;
        "containsKey(boolean)"(arg0: boolean): boolean;
        "getOrDefault(boolean,byte)"(arg0: boolean, arg1: number): number;
        andThenFloat(arg0: Internal.Byte2FloatFunction_): Internal.Boolean2FloatFunction;
        abstract get(arg0: boolean): number;
        andThenObject<T>(arg0: Internal.Byte2ObjectFunction_<T>): Internal.Boolean2ObjectFunction<T>;
        containsKey(arg0: boolean): boolean;
        /**
         * @deprecated
        */
        put(arg0: boolean, arg1: number): number;
        getOrDefault(arg0: boolean, arg1: number): number;
        andThenChar(arg0: Internal.Byte2CharFunction_): Internal.Boolean2CharFunction;
        size(): number;
        put(arg0: boolean, arg1: number): number;
        andThenReference<T>(arg0: Internal.Byte2ReferenceFunction_<T>): Internal.Boolean2ReferenceFunction<T>;
        clear(): void;
        composeShort(arg0: Internal.Short2BooleanFunction_): Internal.Short2ByteFunction;
        /**
         * @deprecated
        */
        andThen<T>(arg0: Internal.Function_<number, T>): Internal.Function<boolean, T>;
    }
    type Boolean2ByteFunction_ = Boolean2ByteFunction;
    class QuestLink extends Internal.QuestObject implements Internal.Movable {
        constructor(id: number, chapter: Internal.Chapter_, linkId: number)
        getRelativeProgressFromChildren(data: Internal.TeamData_): number;
        isCompletedRaw(data: Internal.TeamData_): boolean;
        writeData(nbt: Internal.CompoundTag_): void;
        getMutableTitle(): Internal.MutableComponent;
        readData(nbt: Internal.CompoundTag_): void;
        editedFromGUI(): void;
        notify(): void;
        compareTo(arg0: any): number;
        clearCachedData(): void;
        setPosition(qx: number, qy: number): void;
        getMovableID(): number;
        getRawTitle(): string;
        getProgressColor(data: Internal.TeamData_): Internal.Color4I;
        static isNull(object: Internal.QuestObjectBase_): boolean;
        cacheProgress(): boolean;
        deleteSelf(): void;
        componentsToRefresh(): Internal.Set<Internal.RecipeModHelper$Components>;
        static getID(object: Internal.QuestObjectBase_): number;
        linksTo(quest: Internal.Quest_): boolean;
        hasUnclaimedRewardsRaw(teamData: Internal.TeamData_, player: Internal.UUID_): boolean;
        isValid(): boolean;
        onCompleted(data: Internal.QuestProgressEventData_<any>): void;
        static parseCodeString(id: string): number;
        static getRelativeProgressFromChildren(progressSum: number, count: number): number;
        deleteChildren(): void;
        getTags(): Internal.Set<string>;
        forceProgress(teamData: Internal.TeamData_, progressChange: Internal.ProgressChange_): void;
        getChildren(): Internal.Collection<Internal.QuestObject>;
        static "getCodeString(dev.ftb.mods.ftbquests.quest.QuestObjectBase)"(object: Internal.QuestObjectBase_): string;
        getX(): number;
        wait(): void;
        abstract getTitle(): net.minecraft.network.chat.Component;
        setRawIcon(rawIcon: Internal.ItemStack_): void;
        static shouldSendNotifications(): boolean;
        "compareTo(java.lang.Object)"(arg0: any): number;
        getAltIcon(): Internal.Icon;
        static titleToID(s: string): Optional<string>;
        onEditButtonClicked(gui: Internal.Runnable_): void;
        getClass(): typeof any;
        getProgressColor(data: Internal.TeamData_, dim: boolean): Internal.Color4I;
        static getCodeString(object: Internal.QuestObjectBase_): string;
        move(to: Internal.Chapter_, x: number, y: number): void;
        getCodeString(): string;
        static copy<T extends Internal.QuestObjectBase>(orig: T, factory: Internal.Supplier_<T>): T;
        static getCodeString(id: number): string;
        onMoved(newX: number, newY: number, newChapterId: number): void;
        isOptionalForProgression(): boolean;
        createSubGroup(group: Internal.ConfigGroup_): Internal.ConfigGroup;
        getParentID(): number;
        wait(arg0: number, arg1: number): void;
        getChapter(): Internal.Chapter;
        fillConfigGroup(config: Internal.ConfigGroup_): void;
        getWidth(): number;
        copyToClipboard(): void;
        getIcon(): Internal.Icon;
        getShape(): string;
        getAltTitle(): net.minecraft.network.chat.Component;
        getQuest(): Optional<Internal.Quest>;
        static "getCodeString(long)"(id: number): string;
        getHeight(): number;
        "compareTo(dev.ftb.mods.ftbquests.quest.QuestObjectBase)"(other: Internal.QuestObjectBase_): number;
        readNetData(buffer: Internal.FriendlyByteBuf_): void;
        hasTag(tag: string): boolean;
        compareTo(other: Internal.QuestObjectBase_): number;
        setRawTitle(rawTitle: string): void;
        toString(): string;
        onStarted(data: Internal.QuestProgressEventData_<any>): void;
        getQuestChapter(): Internal.Chapter;
        notifyAll(): void;
        getQuestFile(): Internal.BaseQuestFile;
        getObjectType(): Internal.QuestObjectType;
        forceProgressRaw(teamData: Internal.TeamData_, progressChange: Internal.ProgressChange_): void;
        static parseHexId(id: string): Optional<number>;
        getY(): number;
        hashCode(): number;
        getPath(): Optional<string>;
        isVisible(data: Internal.TeamData_): boolean;
        writeNetData(buffer: Internal.FriendlyByteBuf_): void;
        editedFromGUIOnServer(): void;
        onCreated(): void;
        wait(arg0: number): void;
        equals(object: any): boolean;
        drawMoved(graphics: Internal.GuiGraphics_): void;
        get mutableTitle(): Internal.MutableComponent
        get movableID(): number
        get rawTitle(): string
        get valid(): boolean
        get tags(): Internal.Set<string>
        get children(): Internal.Collection<Internal.QuestObject>
        get x(): number
        get title(): net.minecraft.network.chat.Component
        set rawIcon(rawIcon: Internal.ItemStack_)
        get altIcon(): Internal.Icon
        get class(): typeof any
        get codeString(): string
        get optionalForProgression(): boolean
        get parentID(): number
        get chapter(): Internal.Chapter
        get width(): number
        get icon(): Internal.Icon
        get shape(): string
        get altTitle(): net.minecraft.network.chat.Component
        get quest(): Optional<Internal.Quest>
        get height(): number
        set rawTitle(rawTitle: string)
        get questChapter(): Internal.Chapter
        get questFile(): Internal.BaseQuestFile
        get objectType(): Internal.QuestObjectType
        get y(): number
        get path(): Optional<string>
    }
    type QuestLink_ = QuestLink;
    class ClientboundChangeDifficultyPacket implements Internal.Packet<Internal.ClientGamePacketListener> {
        constructor($$0: Internal.FriendlyByteBuf_)
        constructor($$0: Internal.Difficulty_, $$1: boolean)
        handle(arg0: Internal.PacketListener_): void;
        getClass(): typeof any;
        write($$0: Internal.FriendlyByteBuf_): void;
        getDifficulty(): Internal.Difficulty;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        isSkippable(): boolean;
        wait(arg0: number, arg1: number): void;
        isLocked(): boolean;
        hashCode(): number;
        wait(): void;
        handle($$0: Internal.ClientGamePacketListener_): void;
        wait(arg0: number): void;
        "handle(net.minecraft.network.protocol.game.ClientGamePacketListener)"($$0: Internal.ClientGamePacketListener_): void;
        equals(arg0: any): boolean;
        "handle(net.minecraft.network.PacketListener)"(arg0: Internal.PacketListener_): void;
        get class(): typeof any
        get difficulty(): Internal.Difficulty
        get skippable(): boolean
        get locked(): boolean
    }
    type ClientboundChangeDifficultyPacket_ = ClientboundChangeDifficultyPacket;
    class SignedMessageLink extends Internal.Record {
        constructor($$0: number, $$1: Internal.UUID_, $$2: Internal.UUID_)
        getClass(): typeof any;
        advance(): this;
        static unsigned($$0: Internal.UUID_): Internal.SignedMessageLink;
        toString(): string;
        notifyAll(): void;
        index(): number;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        wait(): void;
        static root($$0: Internal.UUID_, $$1: Internal.UUID_): Internal.SignedMessageLink;
        wait(arg0: number): void;
        isDescendantOf($$0: Internal.SignedMessageLink_): boolean;
        equals($$0: any): boolean;
        sessionId(): Internal.UUID;
        updateSignature($$0: Internal.SignatureUpdater$Output_): void;
        sender(): Internal.UUID;
        get class(): typeof any
        static readonly CODEC: Internal.Codec<Internal.SignedMessageLink>;
    }
    type SignedMessageLink_ = SignedMessageLink;
    interface IAntiqueTextProvider {
        abstract setAntiqueInk(arg0: boolean): void;
        abstract hasAntiqueInk(): boolean;
        set antiqueInk(arg0: boolean)
    }
    type IAntiqueTextProvider_ = IAntiqueTextProvider;
    class BCLFeature$Unregistered <F extends Feature<FC>, FC extends Internal.FeatureConfiguration> extends Internal.BCLFeature<F, FC> {
        getClass(): typeof any;
        getDecoration(): Internal.GenerationStep$Decoration;
        toString(): string;
        static register<C extends Internal.FeatureConfiguration, F extends Feature<C>>(location: ResourceLocation_, feature: F): F;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        getConfiguration(): FC;
        wait(): void;
        register(bootstrapContext: Internal.BootstapContext_<Internal.PlacedFeature>): Internal.BCLFeature<F, FC>;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        getFeature(): F;
        getPlacedFeature(): Internal.Holder<Internal.PlacedFeature>;
        get class(): typeof any
        get decoration(): Internal.GenerationStep$Decoration
        get configuration(): FC
        get feature(): F
        get placedFeature(): Internal.Holder<Internal.PlacedFeature>
    }
    type BCLFeature$Unregistered_<F extends Feature<FC>, FC extends Internal.FeatureConfiguration> = BCLFeature$Unregistered<F, FC>;
    class RecipeFinder {
        constructor()
        getClass(): typeof any;
        toString(): string;
        addItem(stack: Internal.ItemStack_, count: number): void;
        notifyAll(): void;
        contains(itemId: number): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        static getItemId(stack: Internal.ItemStack_): number;
        wait(): void;
        findRecipe(ingredients: Internal.NonNullList_<Internal.Ingredient>, intList_1: Internal.IntList_, maxCrafts: number): boolean;
        clear(): void;
        take(itemId: number, amount: number): number;
        countRecipeCrafts(ingredients: Internal.NonNullList_<Internal.Ingredient>, maxCrafts: number, intList_1: Internal.IntList_): number;
        wait(arg0: number): void;
        findRecipe(ingredients: Internal.NonNullList_<Internal.Ingredient>, intList_1: Internal.IntList_): boolean;
        static getStackFromId(itemId: number): Internal.ItemStack;
        equals(arg0: any): boolean;
        addNormalItem(stack: Internal.ItemStack_): void;
        addItem(stack: Internal.ItemStack_): void;
        countRecipeCrafts(ingredients: Internal.NonNullList_<Internal.Ingredient>, intList_1: Internal.IntList_): number;
        get class(): typeof any
        readonly idToAmountMap: Internal.Int2IntMap;
    }
    type RecipeFinder_ = RecipeFinder;
    class Layer <S extends Internal.Screen, R extends Internal.ParentComponent> {
        getClass(): typeof any;
        hashCode(): number;
        instantiate(screen: S): Internal.Layer$Instance<>;
        toString(): string;
        getInstance(screen: S): Internal.Layer$Instance<>;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
    }
    type Layer_<S extends Internal.Screen, R extends Internal.ParentComponent> = Layer<S, R>;
    class HangingSignBlockEntity extends Internal.SignBlockEntity {
        constructor($$0: BlockPos_, $$1: Internal.BlockState_)
        handler$efn000$collective$setLevel(level: Internal.Level_, ci: Internal.CallbackInfo_): void;
        emf$hasVehicle(): boolean;
        etf$getType(): Internal.EntityType<any>;
        emf$getVelocity(): Vec3d;
        etf$isBlockEntity(): boolean;
        playerIsTooFarAwayToEdit($$0: Internal.UUID_): boolean;
        /**
         * @deprecated
        */
        setBlockState($$0: Internal.BlockState_): void;
        hasAttached(type: Internal.AttachmentType_<any>): boolean;
        load($$0: Internal.CompoundTag_): void;
        setChanged(): void;
        setCulled(value: boolean): void;
        updateSignText($$0: Internal.Player_, $$1: boolean, $$2: Internal.List_<Internal.FilteredText>): void;
        saveWithoutMetadata(): Internal.CompoundTag;
        setTimeout(): void;
        getAttachedOrSet<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        static createCommandSourceStack($$0: Internal.Player_, $$1: Internal.Level_, $$2: BlockPos_): Internal.CommandSourceStack;
        removeAttached<A>(type: Internal.AttachmentType_<A>): A;
        canExecuteClickCommands($$0: boolean, $$1: Internal.Player_): boolean;
        isOutOfCamera(): boolean;
        "getUpdatePacket()"(): Internal.Packet<any>;
        emf$prevZ(): number;
        etf$canBeBright(): boolean;
        setRemoved(): void;
        asComponentProvider(): Internal.ComponentProvider;
        emf$isOnGround(): boolean;
        handler$efn000$collective$setRemoved(ci: Internal.CallbackInfo_): void;
        etf$getEntityKey(): string;
        etf$getPose(): Internal.Pose;
        isCulled(): boolean;
        getType(): Internal.BlockEntityType<any>;
        static transfer(original: Internal.AttachmentTarget_, target: Internal.AttachmentTarget_, isDeath: boolean): void;
        etf$getOptifineId(): number;
        getCustomData(): Internal.CompoundTag;
        "getUpdatePacket()"(): Internal.ClientboundBlockEntityDataPacket;
        getClass(): typeof any;
        updateText($$0: Internal.UnaryOperator_<Internal.SignText>, $$1: boolean): boolean;
        emf$isInvisible(): boolean;
        static getPosFromTag($$0: Internal.CompoundTag_): BlockPos;
        getPlayerWhoMayEdit(): Internal.UUID;
        etf$distanceTo(entity: Internal.Entity_): number;
        emf$isSprinting(): boolean;
        hasAnyComparatorNearby(): boolean;
        saveToItem($$0: Internal.ItemStack_): void;
        invokeWriteNbt(arg0: Internal.CompoundTag_): void;
        "deserializeNBT(net.minecraft.nbt.CompoundTag)"(nbt: Internal.CompoundTag_): void;
        static addEntityType($$0: Internal.CompoundTag_, $$1: Internal.BlockEntityType_<any>): void;
        emf$isInLava(): boolean;
        "deserializeNBT(net.minecraft.nbt.Tag)"(arg0: Internal.Tag_): void;
        onComparatorAdded(direction: Internal.Direction_, offset: number): void;
        fabric_hasPersistentAttachments(): boolean;
        clearRemoved(): void;
        emf$isWet(): boolean;
        getUpdatePacket(): Internal.Packet<any>;
        owo$setCachedState(arg0: Internal.BlockState_): void;
        fabric_getAttachments(): Internal.Map<any, any>;
        bookshelf$markUpdated(): void;
        toString(): string;
        triggerEvent($$0: number, $$1: number): boolean;
        emf$isGlowing(): boolean;
        hasLevel(): boolean;
        notifyAll(): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        isFacingFrontText($$0: Internal.Player_): boolean;
        etf$getScoreboardTeam(): Internal.Team;
        emf$getZ(): number;
        getBackText(): Internal.SignText;
        getTextLineHeight(): number;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>, initializer: Internal.Supplier_<A>): A;
        wait(arg0: number): void;
        etf$getItemsEquipped(): Internal.Iterable<any>;
        setAllowedPlayerEditor($$0: Internal.UUID_): void;
        getAttachedOrThrow<A>(type: Internal.AttachmentType_<A>): A;
        etf$getVelocity(): Vec3d;
        setText($$0: Internal.SignText_, $$1: boolean): boolean;
        getAttached(type: Internal.AttachmentType_<any>): any;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        etf$getWorld(): Internal.Level;
        getUpdateTag(): Internal.CompoundTag;
        getRenderAttachmentData(): any;
        emf$getYaw(): number;
        modifyAttached<A>(type: Internal.AttachmentType_<A>, modifier: Internal.UnaryOperator_<A>): A;
        setLevel($$0: Internal.Level_): void;
        notify(): void;
        getBlockPos(): BlockPos;
        isRemoved(): boolean;
        etf$getNbt(): Internal.CompoundTag;
        emf$isSneaking(): boolean;
        etf$getBlockPos(): BlockPos;
        onLoad(): void;
        fillCrashReportCategory($$0: Internal.CrashReportCategory_): void;
        emf$prevPitch(): number;
        etf$getBlockY(): number;
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        etf$getHandItems(): Internal.Iterable<any>;
        etf$getArmorItems(): Internal.Iterable<any>;
        emf$getY(): number;
        invalidateCaps(): void;
        emf$prevX(): number;
        getFrontText(): Internal.SignText;
        getBlockState(): Internal.BlockState;
        handler$zzl000$porting_lib_base$port_lib$invalidate(ci: Internal.CallbackInfo_): void;
        toComponentPacket(key: Internal.ComponentKey_<any>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        isWaxed(): boolean;
        getText($$0: boolean): Internal.SignText;
        getAttachedOrGet<A>(type: Internal.AttachmentType_<A>, defaultValue: Internal.Supplier_<A>): A;
        static tick($$0: Internal.Level_, $$1: BlockPos_, $$2: Internal.BlockState_, $$3: Internal.SignBlockEntity_): void;
        emf$age(): number;
        etf$hasCustomName(): boolean;
        static loadStatic($$0: BlockPos_, $$1: Internal.BlockState_, $$2: Internal.CompoundTag_): Internal.BlockEntity;
        wait(): void;
        executeClickCommandsIfPresent($$0: Internal.Player_, $$1: Internal.Level_, $$2: BlockPos_, $$3: boolean): boolean;
        emf$isTouchingWater(): boolean;
        emf$getVariableMap(): Internal.Object2FloatOpenHashMap<any>;
        getComponentContainer(): Internal.ComponentContainer;
        etf$getCustomName(): net.minecraft.network.chat.Component;
        fabric_writeAttachmentsToNbt(nbt: Internal.CompoundTag_): void;
        getMaxTextLineWidth(): number;
        saveWithId(): Internal.CompoundTag;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>): A;
        setOutOfCamera(value: boolean): void;
        wait(arg0: number, arg1: number): void;
        setWaxed($$0: boolean): boolean;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        getLevel(): Internal.Level;
        onlyOpCanSetNbt(): boolean;
        port_lib$saveMetadata(arg0: Internal.CompoundTag_): void;
        serializeNBT(): Internal.Tag;
        saveWithFullMetadata(): Internal.CompoundTag;
        litematica_getFrontText(): Internal.SignText;
        emf$prevY(): number;
        emf$getX(): number;
        deserializeNBT(arg0: Internal.Tag_): void;
        emf$isOnFire(): boolean;
        getTextFacingPlayer($$0: Internal.Player_): Internal.SignText;
        etf$getUuid(): Internal.UUID;
        getRecipientsForComponentSync(): Internal.Iterable<any>;
        deserializeNBT(state: Internal.BlockState_, nbt: Internal.CompoundTag_): void;
        getUpdatePacket(): Internal.ClientboundBlockEntityDataPacket;
        isForcedVisible(): boolean;
        emf$hasPassengers(): boolean;
        litematica_getBackText(): Internal.SignText;
        setAttached(type: Internal.AttachmentType_<any>, value: any): any;
        deserializeNBT(nbt: Internal.CompoundTag_): void;
        fabric_readAttachmentsFromNbt(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        emf$getTypeString(): string;
        getAttachedOrElse<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        getRenderData(): any;
        emf$getPitch(): number;
        emf$isAlive(): boolean;
        equals(arg0: any): boolean;
        /**
         * @deprecated
        */
        set blockState($$0: Internal.BlockState_)
        set culled(value: boolean)
        get outOfCamera(): boolean
        get "updatePacket()"(): Internal.Packet<any>
        get culled(): boolean
        get type(): Internal.BlockEntityType<any>
        get customData(): Internal.CompoundTag
        get "updatePacket()"(): Internal.ClientboundBlockEntityDataPacket
        get class(): typeof any
        get playerWhoMayEdit(): Internal.UUID
        get updatePacket(): Internal.Packet<any>
        get backText(): Internal.SignText
        get textLineHeight(): number
        set allowedPlayerEditor($$0: Internal.UUID_)
        get updateTag(): Internal.CompoundTag
        get renderAttachmentData(): any
        set level($$0: Internal.Level_)
        get blockPos(): BlockPos
        get removed(): boolean
        get frontText(): Internal.SignText
        get blockState(): Internal.BlockState
        get waxed(): boolean
        get componentContainer(): Internal.ComponentContainer
        get maxTextLineWidth(): number
        set outOfCamera(value: boolean)
        set waxed($$0: boolean)
        get level(): Internal.Level
        get recipientsForComponentSync(): Internal.Iterable<any>
        get updatePacket(): Internal.ClientboundBlockEntityDataPacket
        get forcedVisible(): boolean
        get renderData(): any
    }
    type HangingSignBlockEntity_ = HangingSignBlockEntity;
    interface RiptideTool {
        method_7881(stack: Internal.ItemStack_): number;
        activateRiptide(user: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        performRiptide(stack: Internal.ItemStack_, world: Internal.Level_, user: Internal.LivingEntity_, remainingUseTicks: number): void;
        readonly COOLDOWN: (60) & (number);
        readonly MAX_USE_TIME: (72000) & (number);
        readonly TRIDENT_POWER: (3.0) & (number);
    }
    type RiptideTool_ = RiptideTool;
    class WaterEdgeFeature extends Feature<Internal.NoneFeatureConfiguration> {
        constructor(codec: Internal.Codec_<Internal.NoneFeatureConfiguration>)
        getClass(): typeof any;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        place($$0: Internal.NoneFeatureConfiguration_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        place(context: Internal.FeaturePlaceContext_<Internal.NoneFeatureConfiguration>): boolean;
        placeBlob(level: Internal.LevelAccessor_, pos: BlockPos_): boolean;
        placeBlock(level: Internal.LevelAccessor_, pos: BlockPos_): boolean;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.NoneFeatureConfiguration, Feature<Internal.NoneFeatureConfiguration>>>;
        get class(): typeof any
    }
    type WaterEdgeFeature_ = WaterEdgeFeature;
    class AmbientAdditionsSettings {
        constructor($$0: Internal.Holder_<Internal.SoundEvent>, $$1: number)
        getClass(): typeof any;
        hashCode(): number;
        getTickChance(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getSoundEvent(): Internal.Holder<Internal.SoundEvent>;
        get class(): typeof any
        get tickChance(): number
        get soundEvent(): Internal.Holder<Internal.SoundEvent>
        static readonly CODEC: Internal.Codec<Internal.AmbientAdditionsSettings>;
    }
    type AmbientAdditionsSettings_ = AmbientAdditionsSettings;
    class ClientboundExplodePacket implements Internal.Packet<Internal.ClientGamePacketListener> {
        constructor($$0: Internal.FriendlyByteBuf_)
        constructor($$0: number, $$1: number, $$2: number, $$3: number, $$4: Internal.List_<BlockPos>, $$5: Vec3d_)
        handle(arg0: Internal.PacketListener_): void;
        getClass(): typeof any;
        write($$0: Internal.FriendlyByteBuf_): void;
        toString(): string;
        notifyAll(): void;
        getKnockbackZ(): number;
        notify(): void;
        isSkippable(): boolean;
        wait(arg0: number, arg1: number): void;
        getKnockbackX(): number;
        getKnockbackY(): number;
        getX(): number;
        getToBlow(): Internal.List<BlockPos>;
        getY(): number;
        getZ(): number;
        hashCode(): number;
        getPower(): number;
        wait(): void;
        handle($$0: Internal.ClientGamePacketListener_): void;
        wait(arg0: number): void;
        "handle(net.minecraft.network.protocol.game.ClientGamePacketListener)"($$0: Internal.ClientGamePacketListener_): void;
        equals(arg0: any): boolean;
        "handle(net.minecraft.network.PacketListener)"(arg0: Internal.PacketListener_): void;
        get class(): typeof any
        get knockbackZ(): number
        get skippable(): boolean
        get knockbackX(): number
        get knockbackY(): number
        get x(): number
        get toBlow(): Internal.List<BlockPos>
        get y(): number
        get z(): number
        get power(): number
    }
    type ClientboundExplodePacket_ = ClientboundExplodePacket;
    class IntegerArgumentInfo implements Internal.ArgumentTypeInfo<Internal.IntegerArgumentType, Internal.IntegerArgumentInfo$Template> {
        constructor()
        getClass(): typeof any;
        "unpack(com.mojang.brigadier.arguments.IntegerArgumentType)"($$0: Internal.IntegerArgumentType_): Internal.IntegerArgumentInfo$Template;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        serializeToNetwork($$0: Internal.IntegerArgumentInfo$Template_, $$1: Internal.FriendlyByteBuf_): void;
        unpack($$0: Internal.IntegerArgumentType_): Internal.IntegerArgumentInfo$Template;
        "serializeToNetwork(net.minecraft.commands.synchronization.brigadier.IntegerArgumentInfo$Template,net.minecraft.network.FriendlyByteBuf)"($$0: Internal.IntegerArgumentInfo$Template_, $$1: Internal.FriendlyByteBuf_): void;
        serializeToJson(arg0: Internal.ArgumentTypeInfo$Template_<any>, arg1: Internal.JsonObject_): void;
        deserializeFromNetwork(arg0: Internal.FriendlyByteBuf_): Internal.ArgumentTypeInfo$Template<any>;
        toString(): string;
        notifyAll(): void;
        "deserializeFromNetwork(net.minecraft.network.FriendlyByteBuf)"(arg0: Internal.FriendlyByteBuf_): Internal.ArgumentTypeInfo$Template<any>;
        "unpack(com.mojang.brigadier.arguments.ArgumentType)"(arg0: Internal.ArgumentType_<any>): Internal.ArgumentTypeInfo$Template<any>;
        "serializeToJson(net.minecraft.commands.synchronization.brigadier.IntegerArgumentInfo$Template,com.google.gson.JsonObject)"($$0: Internal.IntegerArgumentInfo$Template_, $$1: Internal.JsonObject_): void;
        unpack(arg0: Internal.ArgumentType_<any>): Internal.ArgumentTypeInfo$Template<any>;
        serializeToJson($$0: Internal.IntegerArgumentInfo$Template_, $$1: Internal.JsonObject_): void;
        hashCode(): number;
        deserializeFromNetwork($$0: Internal.FriendlyByteBuf_): Internal.IntegerArgumentInfo$Template;
        wait(): void;
        wait(arg0: number): void;
        serializeToNetwork(arg0: Internal.ArgumentTypeInfo$Template_<any>, arg1: Internal.FriendlyByteBuf_): void;
        "serializeToNetwork(net.minecraft.commands.synchronization.ArgumentTypeInfo$Template,net.minecraft.network.FriendlyByteBuf)"(arg0: Internal.ArgumentTypeInfo$Template_<any>, arg1: Internal.FriendlyByteBuf_): void;
        equals(arg0: any): boolean;
        "serializeToJson(net.minecraft.commands.synchronization.ArgumentTypeInfo$Template,com.google.gson.JsonObject)"(arg0: Internal.ArgumentTypeInfo$Template_<any>, arg1: Internal.JsonObject_): void;
        "deserializeFromNetwork(net.minecraft.network.FriendlyByteBuf)"($$0: Internal.FriendlyByteBuf_): Internal.IntegerArgumentInfo$Template;
        get class(): typeof any
    }
    type IntegerArgumentInfo_ = IntegerArgumentInfo;
    interface ImageObserver {
        abstract imageUpdate(arg0: Internal.Image_, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): boolean;
        (arg0: Internal.Image, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number): boolean;
        readonly SOMEBITS: (8) & (number);
        readonly ALLBITS: (32) & (number);
        readonly WIDTH: (1) & (number);
        readonly PROPERTIES: (4) & (number);
        readonly ABORT: (128) & (number);
        readonly FRAMEBITS: (16) & (number);
        readonly HEIGHT: (2) & (number);
        readonly ERROR: (64) & (number);
    }
    type ImageObserver_ = ((arg0: Internal.Image, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number)=> boolean) | ImageObserver;
    interface FriendlyByteBuf$Writer <T> extends Internal.BiConsumer<Internal.FriendlyByteBuf, T> {
        andThen(arg0: Internal.BiConsumer_<Internal.FriendlyByteBuf, T>): Internal.BiConsumer<Internal.FriendlyByteBuf, T>;
        abstract accept(arg0: Internal.FriendlyByteBuf_, arg1: T): void;
        asOptional(): Internal.FriendlyByteBuf$Writer<Optional<T>>;
        (arg0: Internal.FriendlyByteBuf, arg1: T): void;
    }
    type FriendlyByteBuf$Writer_<T> = FriendlyByteBuf$Writer<T> | ((arg0: Internal.FriendlyByteBuf, arg1: T)=> void);
    interface WoodTypeAccessor {
        invokeConstructor(name: string, setType: Internal.BlockSetType_): Internal.WoodType;
        invokeRegister(type: Internal.WoodType_): Internal.WoodType;
    }
    type WoodTypeAccessor_ = WoodTypeAccessor;
    interface EntryRegistry extends Internal.Reloadable<Internal.REIClientPlugin> {
        abstract alreadyContain(arg0: Internal.EntryStack_<any>): boolean;
        abstract getPreFilteredList(): Internal.List<Internal.EntryStack<any>>;
        endReload(): void;
        addEntry(stack: Internal.EntryStack_<any>): void;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        abstract appendStacksForItem(arg0: Internal.Item_): Internal.List<Internal.ItemStack>;
        acceptPlugin(plugin: Internal.REIClientPlugin_): void;
        startReload(stage: Internal.ReloadStage_): void;
        "addEntriesAfter(me.shedaniel.rei.api.common.entry.EntryStack,me.shedaniel.rei.api.common.entry.EntryStack[])"(afterStack: Internal.EntryStack_<any>, ...stacks: Internal.EntryStack_<any>[]): void;
        addEntriesAfter(afterStack: Internal.EntryStack_<any>, ...stacks: Internal.EntryStack_<any>[]): void;
        acceptPlugin(plugin: Internal.REIClientPlugin_, stage: Internal.ReloadStage_): void;
        afterReloadablePlugin(stage: Internal.ReloadStage_, other: Internal.Reloadable_<Internal.REIClientPlugin>, plugin: Internal.REIClientPlugin_): void;
        abstract refilterNew(arg0: boolean, arg1: Internal.Collection_<Internal.EntryStack<any>>): Internal.Collection<Internal.EntryStack<any>>;
        abstract isReloading(): boolean;
        "addEntries(me.shedaniel.rei.api.common.entry.EntryStack[])"(...stacks: Internal.EntryStack_<any>[]): void;
        addEntries(...stacks: Internal.EntryStack_<any>[]): void;
        isConcurrent(): boolean;
        postStage(stage: Internal.ReloadStage_): void;
        getStage(): Internal.ReloadStage;
        abstract getEntryStacks(): Internal.Stream<Internal.EntryStack<any>>;
        abstract addEntryAfter(arg0: Internal.EntryStack_<any>, arg1: Internal.EntryStack_<any>): void;
        abstract removeEntryIf(arg0: Internal.Predicate_<Internal.EntryStack<any>>): boolean;
        afterReloadable(stage: Internal.ReloadStage_, other: Internal.Reloadable_<Internal.REIClientPlugin>): void;
        abstract removeEntryFuzzyHashIf(arg0: Internal.LongPredicate_): boolean;
        abstract "addEntriesAfter(me.shedaniel.rei.api.common.entry.EntryStack,java.util.Collection)"(arg0: Internal.EntryStack_<any>, arg1: Internal.Collection_<Internal.EntryStack<any>>): void;
        abstract size(): number;
        endReload(stage: Internal.ReloadStage_): void;
        "addEntries(java.util.Collection)"(stacks: Internal.Collection_<Internal.EntryStack<any>>): void;
        abstract removeEntryExactHashIf(arg0: Internal.LongPredicate_): boolean;
        abstract refilter(): void;
        abstract markFilteringRuleDirty<Cache>(arg0: Internal.FilteringRule_<Cache>, arg1: Internal.Collection_<Internal.EntryStack<any>>, arg2: Internal.LongCollection_): void;
        beforeReloadable(stage: Internal.ReloadStage_, other: Internal.Reloadable_<Internal.REIClientPlugin>): void;
        addEntries(stacks: Internal.Collection_<Internal.EntryStack<any>>): void;
        abstract startReload(): void;
        abstract addEntriesAfter(arg0: Internal.EntryStack_<any>, arg1: Internal.Collection_<Internal.EntryStack<any>>): void;
        preStage(stage: Internal.ReloadStage_): void;
        abstract removeEntry(arg0: Internal.EntryStack_<any>): boolean;
        getInstance(): this;
        beforeReloadablePlugin(stage: Internal.ReloadStage_, other: Internal.Reloadable_<Internal.REIClientPlugin>, plugin: Internal.REIClientPlugin_): void;
        get preFilteredList(): Internal.List<Internal.EntryStack<any>>
        get reloading(): boolean
        get concurrent(): boolean
        get stage(): Internal.ReloadStage
        get entryStacks(): Internal.Stream<Internal.EntryStack<any>>
        get instance(): Internal.EntryRegistry
    }
    type EntryRegistry_ = EntryRegistry;
    class AlternativesEntry$Builder extends Internal.LootPoolEntryContainer$Builder<Internal.AlternativesEntry$Builder> {
        constructor(...$$0: Internal.LootPoolEntryContainer$Builder_<any>[])
        getClass(): typeof any;
        when<E>($$0: Internal.Iterable_<E>, $$1: Internal.Function_<E, Internal.LootItemCondition$Builder>): this;
        otherwise($$0: Internal.LootPoolEntryContainer$Builder_<any>): this;
        toString(): string;
        unwrap(): this;
        "when(net.minecraft.world.level.storage.loot.predicates.LootItemCondition$Builder)"(arg0: Internal.LootItemCondition$Builder_): Internal.ConditionUserBuilder<any>;
        notifyAll(): void;
        then($$0: Internal.LootPoolEntryContainer$Builder_<any>): Internal.SequentialEntry$Builder;
        unwrap(): Internal.ConditionUserBuilder<any>;
        "when(net.minecraft.world.level.storage.loot.predicates.LootItemCondition$Builder)"($$0: Internal.LootItemCondition$Builder_): this;
        "unwrap()"(): this;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        build(): Internal.LootPoolEntryContainer;
        hashCode(): number;
        when(arg0: Internal.LootItemCondition$Builder_): Internal.ConditionUserBuilder<any>;
        wait(): void;
        append($$0: Internal.LootPoolEntryContainer$Builder_<any>): Internal.EntryGroup$Builder;
        when($$0: Internal.LootItemCondition$Builder_): this;
        wait(arg0: number): void;
        "unwrap()"(): Internal.ConditionUserBuilder<any>;
        equals(arg0: any): boolean;
        get class(): typeof any
    }
    type AlternativesEntry$Builder_ = AlternativesEntry$Builder;
    class WorldDownload extends Internal.ValueObject {
        constructor()
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        static parse($$0: string): Internal.WorldDownload;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        downloadLink: string;
        resourcePackUrl: string;
        resourcePackHash: string;
    }
    type WorldDownload_ = WorldDownload;
    class ObeliskStructure extends Internal.Structure {
        constructor(structureSettings: Internal.Structure$StructureSettings_)
        static simpleCodec<S extends Internal.Structure>($$0: Internal.Function_<Internal.Structure$StructureSettings, S>): Internal.Codec<S>;
        getClass(): typeof any;
        generate($$0: Internal.RegistryAccess_, $$1: Internal.ChunkGenerator_, $$2: Internal.BiomeSource_, $$3: Internal.RandomState_, $$4: Internal.StructureTemplateManager_, $$5: number, $$6: Internal.ChunkPos_, $$7: number, $$8: Internal.LevelHeightAccessor_, $$9: Internal.Predicate_<Internal.Holder<Internal.Biome>>): Internal.StructureStart;
        biomes(): Internal.HolderSet<Internal.Biome>;
        findValidGenerationPoint($$0: Internal.Structure$GenerationContext_): Optional<Internal.Structure$GenerationStub>;
        step(): Internal.GenerationStep$Decoration;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        type(): Internal.StructureType<any>;
        structurify$setStructureIdentifier(structureSetIdentifier: ResourceLocation_): void;
        structurify$getStructureIdentifier(): ResourceLocation;
        toString(): string;
        spawnOverrides(): Internal.Map<Internal.MobCategory, Internal.StructureSpawnOverride>;
        notifyAll(): void;
        static canGenerate(context: Internal.Structure$GenerationContext_, blockPos: BlockPos_): boolean;
        terrainAdaptation(): Internal.TerrainAdjustment;
        adjustBoundingBox($$0: Internal.BoundingBox_): Internal.BoundingBox;
        hashCode(): number;
        addPieces(collector: Internal.StructurePiecesBuilder_, context: Internal.Structure$GenerationContext_): void;
        static settingsCodec<S extends Internal.Structure>($$0: Internal.RecordCodecBuilder$Instance_<S>): Internal.RecordCodecBuilder<S, Internal.Structure$StructureSettings>;
        wait(): void;
        wait(arg0: number): void;
        afterPlace($$0: Internal.WorldGenLevel_, $$1: Internal.StructureManager_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: Internal.BoundingBox_, $$5: Internal.ChunkPos_, $$6: Internal.PiecesContainer_): void;
        equals(arg0: any): boolean;
        setStructureBiomes(newBiomes: Internal.HolderSet_<any>): void;
        get class(): typeof any
        set tingsCodec($$0: Internal.RecordCodecBuilder$Instance_<S>)
        set structureBiomes(newBiomes: Internal.HolderSet_<any>)
        static readonly CODEC: Internal.Codec<Internal.ObeliskStructure>;
    }
    type ObeliskStructure_ = ObeliskStructure;
    class SmeltingRecipe extends Internal.AbstractCookingRecipe {
        constructor($$0: ResourceLocation_, $$1: string, $$2: Internal.CookingBookCategory_, $$3: Internal.Ingredient_, $$4: Internal.ItemStack_, $$5: number, $$6: number)
        getClass(): typeof any;
        category(): Internal.CookingBookCategory;
        getGroup(): string;
        getToastSymbol(): Internal.ItemStack;
        getSchema(): Internal.RecipeSchema;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getSerializer(): Internal.RecipeSerializer<any>;
        assemble($$0: net.minecraft.world.Container_, $$1: Internal.RegistryAccess_): Internal.ItemStack;
        getId(): ResourceLocation;
        matches($$0: net.minecraft.world.Container_, $$1: Internal.Level_): boolean;
        getMod(): string;
        isIn(tag: ResourceLocation_): boolean;
        getRemainingItems($$0: net.minecraft.world.Container_): Internal.NonNullList<Internal.ItemStack>;
        getIngredients(): Internal.NonNullList<Internal.Ingredient>;
        handler$bpa000$bclib$bcl_getRemainingItems(container: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getExperience(): number;
        isSpecial(): boolean;
        hasOutput(match: Internal.ReplacementMatch_): boolean;
        getResultItem($$0: Internal.RegistryAccess_): Internal.ItemStack;
        toString(): string;
        notifyAll(): void;
        canCraftInDimensions($$0: number, $$1: number): boolean;
        showNotification(): boolean;
        replaceInput(match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): boolean;
        getCookingTime(): number;
        getType(): ResourceLocation;
        setGroup(group: string): void;
        "handler$fie000$fabric-item-api-v1$captureStack"(inventory: net.minecraft.world.Container_, cir: Internal.CallbackInfoReturnable_<any>, defaultedList: Internal.NonNullList_<any>, i: number): void;
        hashCode(): number;
        getOrCreateId(): ResourceLocation;
        hasInput(match: Internal.ReplacementMatch_): boolean;
        wait(): void;
        isIncomplete(): boolean;
        wait(arg0: number): void;
        replaceOutput(match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): boolean;
        equals(arg0: any): boolean;
        get class(): typeof any
        get group(): string
        get toastSymbol(): Internal.ItemStack
        get schema(): Internal.RecipeSchema
        get serializer(): Internal.RecipeSerializer<any>
        get id(): ResourceLocation
        get mod(): string
        get ingredients(): Internal.NonNullList<Internal.Ingredient>
        get experience(): number
        get special(): boolean
        get cookingTime(): number
        get type(): ResourceLocation
        set group(group: string)
        get orCreateId(): ResourceLocation
        get incomplete(): boolean
    }
    type SmeltingRecipe_ = SmeltingRecipe;
    class BlockHitResult extends Internal.HitResult {
        constructor($$0: Vec3d_, $$1: Internal.Direction_, $$2: BlockPos_, $$3: boolean)
        getClass(): typeof any;
        withPosition($$0: BlockPos_): this;
        distanceTo($$0: Internal.Entity_): number;
        toString(): string;
        withDirection($$0: Internal.Direction_): this;
        notifyAll(): void;
        getLocation(): Vec3d;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getBlockPos(): BlockPos;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        static miss($$0: Vec3d_, $$1: Internal.Direction_, $$2: BlockPos_): Internal.BlockHitResult;
        isInside(): boolean;
        equals(arg0: any): boolean;
        getType(): Internal.HitResult$Type;
        getDirection(): Internal.Direction;
        get class(): typeof any
        get location(): Vec3d
        get blockPos(): BlockPos
        get inside(): boolean
        get type(): Internal.HitResult$Type
        get direction(): Internal.Direction
    }
    type BlockHitResult_ = BlockHitResult;
    interface SpawnTypeMob {
        abstract puzzleslib$getSpawnType(): Internal.MobSpawnType;
        (): Internal.MobSpawnType_;
    }
    type SpawnTypeMob_ = SpawnTypeMob | (()=> Internal.MobSpawnType_);
    interface DraggableComponent <T> extends Internal.Supplier<T> {
        "render(net.minecraft.client.gui.GuiGraphics,me.shedaniel.math.Rectangle,int,int,float)"(graphics: Internal.GuiGraphics_, bounds: me.shedaniel.math.Rectangle_, mouseX: number, mouseY: number, delta: number): void;
        release(result: Internal.DraggedAcceptorResult_): void;
        "ifMatches(java.util.function.Consumer,java.lang.Object[])"<A>(consumer: Internal.Consumer_<A>, ...typeHack: A[]): boolean;
        "ifMatches(java.util.function.Predicate,java.lang.Object[])"<A>(consumer: Internal.Predicate_<A>, ...typeHack: A[]): boolean;
        abstract getWidth(): number;
        render(graphics: Internal.GuiGraphics_, position: me.shedaniel.math.Point_, mouseX: number, mouseY: number, delta: number): void;
        ifMatches<A>(consumer: Internal.Predicate_<A>, ...typeHack: A[]): boolean;
        ifMatches<A>(consumer: Internal.Consumer_<A>, ...typeHack: A[]): boolean;
        "render(net.minecraft.client.gui.GuiGraphics,me.shedaniel.math.Point,int,int,float)"(graphics: Internal.GuiGraphics_, position: me.shedaniel.math.Point_, mouseX: number, mouseY: number, delta: number): void;
        drag(): void;
        getIf<A>(...typeHack: A[]): Optional<Internal.DraggableComponent<A>>;
        render(graphics: Internal.GuiGraphics_, bounds: me.shedaniel.math.Rectangle_, mouseX: number, mouseY: number, delta: number): void;
        getOriginBounds(mouse: me.shedaniel.math.Point_): me.shedaniel.math.Rectangle;
        abstract getHeight(): number;
        abstract get(): T;
        get width(): number
        get height(): number
    }
    type DraggableComponent_<T> = DraggableComponent<T>;
    interface MinecraftClientKJS extends Internal.MinecraftEnvironmentKJS {
        getDisplayName(): net.minecraft.network.chat.Component;
        setCurrentScreen(gui: Internal.Screen_): void;
        scheduleInTicks(ticks: number, callback: Internal.ScheduledEvents$Callback_): Internal.ScheduledEvents$ScheduledEvent;
        isShiftDown(): boolean;
        getName(): net.minecraft.network.chat.Component;
        runCommandSilent(command: string): number;
        scheduleRepeatingInTicks(ticks: number, callback: Internal.ScheduledEvents$Callback_): Internal.ScheduledEvents$ScheduledEvent;
        getCurrentWorldName(): string;
        isCtrlDown(): boolean;
        abstract getScheduledEvents(): Internal.ScheduledEvents;
        tell(message: net.minecraft.network.chat.Component_): void;
        getCurrentScreen(): Internal.Screen;
        self(): Internal.Minecraft;
        schedule(timer: Internal.TemporalAmount_, callback: Internal.ScheduledEvents$Callback_): Internal.ScheduledEvents$ScheduledEvent;
        isAltDown(): boolean;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        scheduleRepeating(timer: Internal.TemporalAmount_, callback: Internal.ScheduledEvents$Callback_): Internal.ScheduledEvents$ScheduledEvent;
        setTitle(t: string): void;
        isKeyDown(key: number): boolean;
        runCommand(command: string): number;
        get displayName(): net.minecraft.network.chat.Component
        set currentScreen(gui: Internal.Screen_)
        get shiftDown(): boolean
        get name(): net.minecraft.network.chat.Component
        get currentWorldName(): string
        get ctrlDown(): boolean
        get scheduledEvents(): Internal.ScheduledEvents
        get currentScreen(): Internal.Screen
        get altDown(): boolean
        set statusMessage(message: net.minecraft.network.chat.Component_)
        set title(t: string)
        (): Internal.ScheduledEvents_;
    }
    type MinecraftClientKJS_ = (()=> Internal.ScheduledEvents_) | MinecraftClientKJS;
    interface ResourceOrTagKeyArgument$Result <T> extends Internal.Predicate<Internal.Holder<T>> {
        not<T>(arg0: Internal.Predicate_<T>): Internal.Predicate<T>;
        abstract test(arg0: Internal.Holder_<T>): boolean;
        negate(): Internal.Predicate<Internal.Holder<T>>;
        abstract cast<E>(arg0: Internal.ResourceKey_<Internal.Registry<E>>): Optional<Internal.ResourceOrTagKeyArgument$Result<E>>;
        abstract asPrintable(): string;
        or(arg0: Internal.Predicate_<Internal.Holder<T>>): Internal.Predicate<Internal.Holder<T>>;
        and(arg0: Internal.Predicate_<Internal.Holder<T>>): Internal.Predicate<Internal.Holder<T>>;
        abstract unwrap(): Internal.Either<Internal.ResourceKey<T>, Internal.TagKey<T>>;
        isEqual<T>(arg0: any): Internal.Predicate<T>;
    }
    type ResourceOrTagKeyArgument$Result_<T> = ResourceOrTagKeyArgument$Result<T>;
    class GossipContainer implements Internal.VillagerGossipEntriesInvoker {
        constructor()
        getClass(): typeof any;
        invokeEntries(): Internal.Stream<any>;
        getCountForType($$0: Internal.GossipType_, $$1: Internal.DoublePredicate_): number;
        toString(): string;
        remove($$0: Internal.UUID_, $$1: Internal.GossipType_): void;
        notifyAll(): void;
        update($$0: Internal.Dynamic_<any>): void;
        decay(): void;
        notify(): void;
        transferFrom($$0: Internal.GossipContainer_, $$1: Internal.RandomSource_, $$2: number): void;
        wait(arg0: number, arg1: number): void;
        getReputation($$0: Internal.UUID_, $$1: Internal.Predicate_<Internal.GossipType>): number;
        getGossipEntries(): Internal.Map<Internal.UUID, Internal.Object2IntMap<Internal.GossipType>>;
        remove($$0: Internal.UUID_, $$1: Internal.GossipType_, $$2: number): void;
        hashCode(): number;
        wait(): void;
        add($$0: Internal.UUID_, $$1: Internal.GossipType_, $$2: number): void;
        unpack(): Internal.Stream<Internal.GossipContainer$GossipEntry>;
        wait(arg0: number): void;
        store<T>($$0: Internal.DynamicOps_<T>): T;
        equals(arg0: any): boolean;
        remove($$0: Internal.GossipType_): void;
        get class(): typeof any
        get gossipEntries(): Internal.Map<Internal.UUID, Internal.Object2IntMap<Internal.GossipType>>
        static readonly DISCARD_THRESHOLD: (2) & (number);
    }
    type GossipContainer_ = GossipContainer;
    class ItemTomeFont extends Internal.ItemTome {
        constructor(fontId: ResourceLocation_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, world: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, flag: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        static fontifyBlock(fontId: ResourceLocation_): Internal.TomeEffect<BlockPos, Internal.InteractionResult>;
        withEntityEffect(entityEffect: Internal.TomeEffect_<Internal.Entity, Internal.InteractionResult>): Internal.ItemTome;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity(stack: Internal.ItemStack_, user: Internal.Player_, target: Internal.LivingEntity_, hand: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn(context: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(world: Internal.Level_, player: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        withUserEffect(userEffect: Internal.TomeEffect_<Internal.Player, Internal.InteractionResultHolder<Internal.ItemStack>>): Internal.ItemTome;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static fontifyEntity(fontId: ResourceLocation_): Internal.TomeEffect<Internal.Entity, Internal.InteractionResult>;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        withBlockEffect(blockEffect: Internal.TomeEffect_<BlockPos, Internal.InteractionResult>): Internal.ItemTome;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type ItemTomeFont_ = ItemTomeFont;
    class IsoEra extends Internal.Enum<Internal.IsoEra> implements Internal.Era {
        getClass(): typeof any;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.IsoEra>>;
        static values(): Internal.IsoEra[];
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        getLong(arg0: Internal.TemporalField_): number;
        getValue(): number;
        getDeclaringClass(): typeof Internal.IsoEra;
        isSupported(arg0: Internal.TemporalField_): boolean;
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        toString(): string;
        adjustInto(arg0: Internal.Temporal_): Internal.Temporal;
        notifyAll(): void;
        "compareTo(java.time.chrono.IsoEra)"(arg0: Internal.IsoEra_): number;
        query<R>(arg0: Internal.TemporalQuery_<R>): R;
        static of(arg0: number): Internal.IsoEra;
        getDisplayName(arg0: Internal.TextStyle_, arg1: Internal.Locale_): string;
        range(arg0: Internal.TemporalField_): Internal.ValueRange;
        name(): string;
        compareTo(arg0: Internal.IsoEra_): number;
        hashCode(): number;
        get(arg0: Internal.TemporalField_): number;
        static valueOf(arg0: string): Internal.IsoEra;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        get class(): typeof any
        get value(): number
        get declaringClass(): typeof Internal.IsoEra
        static readonly BCE: (Internal.IsoEra) & (Internal.IsoEra);
        static readonly CE: (Internal.IsoEra) & (Internal.IsoEra);
    }
    type IsoEra_ = IsoEra | "bce" | "ce";
    class DocGenerationEventJS extends Internal.EventJS {
        constructor()
        addSnippet(name: string, items: Internal.List_<any>): this;
        getClass(): typeof any;
        /**
         * Stops the event with default exit value. Execution will be stopped **immediately**.
         * 
         * `exit` denotes a `default` outcome.
        */
        exit(): any;
        /**
         * Cancels the event with the given exit value. Execution will be stopped **immediately**.
         * 
         * `cancel` denotes a `false` outcome.
        */
        cancel(value: any): any;
        toString(): string;
        transformDocument(clazz: typeof any, transformer: Internal.Consumer_<Internal.DocumentClass>): this;
        addSnippet(name: string, items: Internal.List_<any>, desc: string): this;
        notifyAll(): void;
        getJavaClass(clazz: typeof any): Internal.DocumentClass;
        customSnippet(type: string, prefixes: Internal.List_<string>, body: Internal.List_<any>): this;
        /**
         * Stops the event with the given exit value. Execution will be stopped **immediately**.
         * 
         * `exit` denotes a `default` outcome.
        */
        exit(value: any): any;
        customSnippet(type: string, prefixes: Internal.List_<string>, body: Internal.List_<any>, desc: string): this;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        /**
         * Stops the event with the given exit value. Execution will be stopped **immediately**.
         * 
         * `success` denotes a `true` outcome.
        */
        success(value: any): any;
        hashCode(): number;
        specialType(typeName: string, elements: Internal.List_<any>): this;
        transformByName(clazz: string, transformer: Internal.Consumer_<Internal.DocumentClass>): this;
        getProperty(object: Internal.JsonObject_): Internal.AbstractProperty<any>;
        wait(): void;
        /**
         * Cancels the event with default exit value. Execution will be stopped **immediately**.
         * 
         * `cancel` denotes a `false` outcome.
        */
        cancel(): any;
        wait(arg0: number): void;
        /**
         * Stops the event with default exit value. Execution will be stopped **immediately**.
         * 
         * `success` denotes a `true` outcome.
        */
        success(): any;
        equals(arg0: any): boolean;
        get class(): typeof any
    }
    type DocGenerationEventJS_ = DocGenerationEventJS;
    class ClientboundRemoveMobEffectPacket implements Internal.Packet<Internal.ClientGamePacketListener> {
        constructor($$0: Internal.FriendlyByteBuf_)
        constructor($$0: number, $$1: Internal.MobEffect_)
        handle(arg0: Internal.PacketListener_): void;
        getClass(): typeof any;
        write($$0: Internal.FriendlyByteBuf_): void;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        getEntity($$0: Internal.Level_): Internal.Entity;
        isSkippable(): boolean;
        wait(arg0: number, arg1: number): void;
        getEffect(): Internal.MobEffect;
        hashCode(): number;
        wait(): void;
        handle($$0: Internal.ClientGamePacketListener_): void;
        wait(arg0: number): void;
        "handle(net.minecraft.network.protocol.game.ClientGamePacketListener)"($$0: Internal.ClientGamePacketListener_): void;
        equals(arg0: any): boolean;
        "handle(net.minecraft.network.PacketListener)"(arg0: Internal.PacketListener_): void;
        get class(): typeof any
        get skippable(): boolean
        get effect(): Internal.MobEffect
    }
    type ClientboundRemoveMobEffectPacket_ = ClientboundRemoveMobEffectPacket;
    interface MixinWorldProperties extends Internal.ComponentProvider {
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        asComponentProvider(): Internal.ComponentProvider;
        getRecipientsForComponentSync(): Internal.Iterable<Internal.ServerPlayer>;
        toComponentPacket<C extends Internal.AutoSyncedComponent>(key: Internal.ComponentKey_<C>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        abstract getComponentContainer(): Internal.ComponentContainer;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        get recipientsForComponentSync(): Internal.Iterable<Internal.ServerPlayer>
        get componentContainer(): Internal.ComponentContainer
        (): Internal.ComponentContainer_;
    }
    type MixinWorldProperties_ = MixinWorldProperties | (()=> Internal.ComponentContainer_);
    interface ScheduledEvents$Callback {
        abstract onCallback(arg0: Internal.ScheduledEvents$ScheduledEvent_): void;
        (arg0: Internal.ScheduledEvents$ScheduledEvent): void;
    }
    type ScheduledEvents$Callback_ = ScheduledEvents$Callback | ((arg0: Internal.ScheduledEvents$ScheduledEvent)=> void);
    class LumiseneBottleItem extends Internal.Item {
        constructor(properties: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getUseAnimation(stack: Internal.ItemStack_): Internal.UseAnim;
        getDescriptionId(): string;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(level: Internal.Level_, player: Internal.Player_, usedHand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration(stack: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem(stack: Internal.ItemStack_, level: Internal.Level_, livingEntity: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type LumiseneBottleItem_ = LumiseneBottleItem;
    class Display$BillboardConstraints extends Internal.Enum<Internal.Display$BillboardConstraints> implements Internal.StringRepresentable {
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        getClass(): typeof any;
        getDeclaringClass(): typeof Internal.Display$BillboardConstraints;
        static fromEnumWithMapping<E extends Internal.Enum<E> & Internal.StringRepresentable>($$0: Internal.Supplier_<E[]>, $$1: Internal.Function_<string, string>): Internal.StringRepresentable$EnumCodec<E>;
        static valueOf($$0: string): Internal.Display$BillboardConstraints;
        toString(): string;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.Display$BillboardConstraints>>;
        getSerializedName(): string;
        notifyAll(): void;
        compareTo(arg0: Internal.Display$BillboardConstraints_): number;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        name(): string;
        hashCode(): number;
        static keys($$0: Internal.StringRepresentable_[]): Internal.Keyable;
        static fromEnum<E extends Internal.Enum<E> & Internal.StringRepresentable>($$0: Internal.Supplier_<E[]>): Internal.StringRepresentable$EnumCodec<E>;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        static values(): Internal.Display$BillboardConstraints[];
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        "compareTo(net.minecraft.world.entity.Display$BillboardConstraints)"(arg0: Internal.Display$BillboardConstraints_): number;
        get class(): typeof any
        get declaringClass(): typeof Internal.Display$BillboardConstraints
        get serializedName(): string
        static readonly VERTICAL: (Internal.Display$BillboardConstraints) & (Internal.Display$BillboardConstraints);
        static readonly HORIZONTAL: (Internal.Display$BillboardConstraints) & (Internal.Display$BillboardConstraints);
        static readonly CODEC: Internal.Codec<Internal.Display$BillboardConstraints>;
        static readonly BY_ID: Internal.IntFunction<Internal.Display$BillboardConstraints>;
        static readonly FIXED: (Internal.Display$BillboardConstraints) & (Internal.Display$BillboardConstraints);
        static readonly CENTER: (Internal.Display$BillboardConstraints) & (Internal.Display$BillboardConstraints);
    }
    type Display$BillboardConstraints_ = Display$BillboardConstraints | "fixed" | "center" | "vertical" | "horizontal";
    class ChatReportBuilder$ChatReport {
        getClass(): typeof any;
        hashCode(): number;
        toggleReported($$0: number, $$1: Internal.AbuseReportLimits_): void;
        toString(): string;
        wait(): void;
        copy(): this;
        notifyAll(): void;
        wait(arg0: number): void;
        isReportedPlayer($$0: Internal.UUID_): boolean;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
    }
    type ChatReportBuilder$ChatReport_ = ChatReportBuilder$ChatReport;
    class ModBow extends Internal.Bow {
        constructor(settings: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        addModifierTooltip(stack: Internal.ItemStack_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_, type: Internal.ModifierHelperType_<any>): void;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        static getPowerForTime($$0: number): number;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getUseAnimation(stack: Internal.ItemStack_): Internal.UseAnim;
        getDescriptionId(): string;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getAllSupportedProjectiles(): Internal.Predicate<Internal.ItemStack>;
        fzzy_core_correctSlot(slot: Internal.EquipmentSlot_): boolean;
        getCreativeTab(): string;
        postWearerHit(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        static getHeldProjectile($$0: Internal.LivingEntity_, $$1: Internal.Predicate_<Internal.ItemStack>): Internal.ItemStack;
        modifierObjectPredicate(livingEntity: Internal.LivingEntity_, stack: Internal.ItemStack_): ResourceLocation;
        getSupportedHeldProjectiles(): Internal.Predicate<Internal.ItemStack>;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        handler$mkb000$supplementaries$getAllSupportedProjectiles(cir: Internal.CallbackInfoReturnable_<any>): void;
        fzzy_core_getCorrectSlot(): Internal.EquipmentSlot;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        getDefaultProjectileRange(): number;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(world: Internal.Level_, user: Internal.Player_, hand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        onWearerKilledOther(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, victim: Internal.LivingEntity_, world: Internal.ServerLevel_): void;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        canBeModifiedBy(type: Internal.ModifierHelperType_<any>): boolean;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        incrementKillCount(stack: Internal.ItemStack_): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing(stack: Internal.ItemStack_, world: Internal.Level_, user: Internal.LivingEntity_, remainingUseTicks: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration(stack: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        defaultModifiers(type: Internal.ModifierHelperType_<any>): Internal.List<any>;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        localvar$zba000$porting_lib_base$customArrowTest(oldArrow: Internal.AbstractArrow_): Internal.AbstractArrow;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        localvar$ldd000$puzzleslib$releaseUsing(charge: number): number;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        handler$ega000$collective$use(level: Internal.Level_, player: Internal.Player_, interactionHand: Internal.InteractionHand_, cir: Internal.CallbackInfoReturnable_<any>): void;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getZoomMultiplier(): number;
        handler$ldd000$puzzleslib$releaseUsing(stack: Internal.ItemStack_, level: Internal.Level_, livingEntity: Internal.LivingEntity_, timeCharged: number, callback: Internal.CallbackInfo_, player: Internal.Player_, hasInfiniteAmmo: boolean, projectileStack: Internal.ItemStack_): void;
        getKillCount(stack: Internal.ItemStack_): number;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPullProgress(useTicks: number): number;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get allSupportedProjectiles(): Internal.Predicate<Internal.ItemStack>
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        get supportedHeldProjectiles(): Internal.Predicate<Internal.ItemStack>
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get defaultProjectileRange(): number
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get zoomMultiplier(): number
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
        static speed: (6.5) & (number);
        static roll: (0.0) & (number);
        static zoomMultiplier: (0.45) & (number);
        static flameBurnSecond: (100) & (number);
        static divergence: (0.0) & (number);
        static extraDamage: (0.0) & (number);
        static powerBonus: (0.75) & (number);
        static dropRange: (45) & (number);
    }
    type ModBow_ = ModBow;
    interface FloatingFlowerVariant {
        abstract getIslandType(arg0: Internal.ItemStack_): Internal.FloatingFlower$IslandType;
        (arg0: Internal.ItemStack): Internal.FloatingFlower$IslandType_;
    }
    type FloatingFlowerVariant_ = ((arg0: Internal.ItemStack)=> Internal.FloatingFlower$IslandType_) | FloatingFlowerVariant;
    class WillowBushFeature extends Internal.ContextFeature<Internal.NoneFeatureConfiguration> {
        constructor()
        getClass(): typeof any;
        toString(): string;
        static checkNeighbors($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_, $$2: Internal.Predicate_<Internal.BlockState>): boolean;
        notifyAll(): void;
        place($$0: Internal.NoneFeatureConfiguration_, $$1: Internal.WorldGenLevel_, $$2: Internal.ChunkGenerator_, $$3: Internal.RandomSource_, $$4: BlockPos_): boolean;
        notify(): void;
        static isAdjacentToAir($$0: Internal.Function_<BlockPos, Internal.BlockState>, $$1: BlockPos_): boolean;
        wait(arg0: number, arg1: number): void;
        place(ctx: Internal.FeaturePlaceContext_<Internal.NoneFeatureConfiguration>): boolean;
        static isGrassOrDirt($$0: Internal.LevelSimulatedReader_, $$1: BlockPos_): boolean;
        hashCode(): number;
        wait(): void;
        wait(arg0: number): void;
        static isDirt($$0: Internal.BlockState_): boolean;
        equals(arg0: any): boolean;
        static isReplaceable($$0: Internal.TagKey_<Internal.Block>): Internal.Predicate<Internal.BlockState>;
        configuredCodec(): Internal.Codec<Internal.ConfiguredFeature<Internal.NoneFeatureConfiguration, Feature<Internal.NoneFeatureConfiguration>>>;
        get class(): typeof any
    }
    type WillowBushFeature_ = WillowBushFeature;
    class HeightmapPlacement extends Internal.PlacementModifier {
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        getPositions($$0: Internal.PlacementContext_, $$1: Internal.RandomSource_, $$2: BlockPos_): Internal.Stream<BlockPos>;
        wait(): void;
        type(): Internal.PlacementModifierType<any>;
        notifyAll(): void;
        static onHeightmap($$0: Internal.Heightmap$Types_): Internal.HeightmapPlacement;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        static readonly CODEC: Internal.Codec<Internal.HeightmapPlacement>;
    }
    type HeightmapPlacement_ = HeightmapPlacement;
    class ServerWorldProperty <T> {
        constructor(id: ResourceLocation_, name: string, localizeName: boolean, widget: any_<T>, value: T, handler: Internal.Predicate_<T>)
        getClass(): typeof any;
        write(friendlyByteBuf: Internal.FriendlyByteBuf_): void;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        update(serverLevel: Internal.ServerLevel_, data: number[]): void;
        getId(): ResourceLocation;
        setValue(value: T): void;
        getType(): Internal.WorldPropertyDataType<T>;
        wait(): void;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        get class(): typeof any
        get id(): ResourceLocation
        set value(value: T)
        get type(): Internal.WorldPropertyDataType<T>
    }
    type ServerWorldProperty_<T> = ServerWorldProperty<T>;
    class TelemetryProperty$GameMode extends Internal.Enum<Internal.TelemetryProperty$GameMode> implements Internal.StringRepresentable {
        getClass(): typeof any;
        static fromEnumWithMapping<E extends Internal.Enum<E> & Internal.StringRepresentable>($$0: Internal.Supplier_<E[]>, $$1: Internal.Function_<string, string>): Internal.StringRepresentable$EnumCodec<E>;
        getSerializedName(): string;
        static values(): Internal.TelemetryProperty$GameMode[];
        notify(): void;
        wait(arg0: number, arg1: number): void;
        compareTo(arg0: any): number;
        describeConstable(): Optional<Internal.Enum$EnumDesc<Internal.TelemetryProperty$GameMode>>;
        static fromEnum<E extends Internal.Enum<E> & Internal.StringRepresentable>($$0: Internal.Supplier_<E[]>): Internal.StringRepresentable$EnumCodec<E>;
        id(): number;
        "compareTo(net.minecraft.client.telemetry.TelemetryProperty$GameMode)"(arg0: Internal.TelemetryProperty$GameMode_): number;
        compareTo(arg0: Internal.TelemetryProperty$GameMode_): number;
        static valueOf<T extends Internal.Enum<T>>(arg0: T, arg1: string): T;
        toString(): string;
        notifyAll(): void;
        static valueOf($$0: string): Internal.TelemetryProperty$GameMode;
        name(): string;
        hashCode(): number;
        static keys($$0: Internal.StringRepresentable_[]): Internal.Keyable;
        ordinal(): number;
        wait(): void;
        wait(arg0: number): void;
        "compareTo(java.lang.Object)"(arg0: any): number;
        equals(arg0: any): boolean;
        getDeclaringClass(): typeof Internal.TelemetryProperty$GameMode;
        get class(): typeof any
        get serializedName(): string
        get declaringClass(): typeof Internal.TelemetryProperty$GameMode
        static readonly SURVIVAL: (Internal.TelemetryProperty$GameMode) & (Internal.TelemetryProperty$GameMode);
        static readonly CODEC: Internal.Codec<Internal.TelemetryProperty$GameMode>;
        static readonly HARDCORE: (Internal.TelemetryProperty$GameMode) & (Internal.TelemetryProperty$GameMode);
        static readonly CREATIVE: (Internal.TelemetryProperty$GameMode) & (Internal.TelemetryProperty$GameMode);
        static readonly ADVENTURE: (Internal.TelemetryProperty$GameMode) & (Internal.TelemetryProperty$GameMode);
        static readonly SPECTATOR: (Internal.TelemetryProperty$GameMode) & (Internal.TelemetryProperty$GameMode);
    }
    type TelemetryProperty$GameMode_ = "hardcore" | "spectator" | "adventure" | "survival" | TelemetryProperty$GameMode | "creative";
    interface ExclusionZones extends Internal.OverlayDecider {
        abstract register<T>(arg0: T, arg1: Internal.ExclusionZonesProvider_<T>): void;
        getPriority(): number;
        /**
         * @deprecated
        */
        abstract getExclusionZones(arg0: typeof any, arg1: boolean): Internal.List<me.shedaniel.math.Rectangle>;
        getExclusionZones(screen: Internal.Screen_): Internal.List<me.shedaniel.math.Rectangle>;
        /**
         * @deprecated
        */
        "shouldScreenBeOverlaid(java.lang.Class)"(screen: typeof any): Internal.InteractionResult;
        compareTo(o: Internal.OverlayDecider_): number;
        abstract getZonesCount(): number;
        /**
         * @deprecated
        */
        getExclusionZones(currentScreenClass: typeof any): Internal.List<me.shedaniel.math.Rectangle>;
        shouldRecalculateArea(location: Internal.DisplayPanelLocation_, rectangle: me.shedaniel.math.Rectangle_): boolean;
        isInZone(mouseX: number, mouseY: number): Internal.InteractionResult;
        /**
         * @deprecated
        */
        abstract "getExclusionZones(java.lang.Class,boolean)"(arg0: typeof any, arg1: boolean): Internal.List<me.shedaniel.math.Rectangle>;
        shouldScreenBeOverlaid<R extends Internal.Screen>(screen: R): Internal.InteractionResult;
        getRendererProvider(): Internal.OverlayRendererProvider;
        compareTo(arg0: any): number;
        /**
         * @deprecated
        */
        shouldScreenBeOverlaid(screen: typeof any): Internal.InteractionResult;
        "getExclusionZones(net.minecraft.client.gui.screens.Screen)"(screen: Internal.Screen_): Internal.List<me.shedaniel.math.Rectangle>;
        /**
         * @deprecated
        */
        "getExclusionZones(java.lang.Class)"(currentScreenClass: typeof any): Internal.List<me.shedaniel.math.Rectangle>;
        abstract "getExclusionZones(net.minecraft.client.gui.screens.Screen,boolean)"(arg0: Internal.Screen_, arg1: boolean): Internal.List<me.shedaniel.math.Rectangle>;
        "compareTo(me.shedaniel.rei.api.client.registry.screen.OverlayDecider)"(o: Internal.OverlayDecider_): number;
        abstract isHandingScreen<R extends Internal.Screen>(arg0: R): boolean;
        "shouldScreenBeOverlaid(net.minecraft.client.gui.screens.Screen)"<R extends Internal.Screen>(screen: R): Internal.InteractionResult;
        abstract getExclusionZones(arg0: Internal.Screen_, arg1: boolean): Internal.List<me.shedaniel.math.Rectangle>;
        "compareTo(java.lang.Object)"(arg0: any): number;
        get priority(): number
        get zonesCount(): number
        get rendererProvider(): Internal.OverlayRendererProvider
    }
    type ExclusionZones_ = ExclusionZones;
    class ClientboundClearTitlesPacket implements Internal.Packet<Internal.ClientGamePacketListener> {
        constructor($$0: Internal.FriendlyByteBuf_)
        constructor($$0: boolean)
        handle(arg0: Internal.PacketListener_): void;
        getClass(): typeof any;
        write($$0: Internal.FriendlyByteBuf_): void;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        isSkippable(): boolean;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        shouldResetTimes(): boolean;
        wait(): void;
        handle($$0: Internal.ClientGamePacketListener_): void;
        wait(arg0: number): void;
        "handle(net.minecraft.network.protocol.game.ClientGamePacketListener)"($$0: Internal.ClientGamePacketListener_): void;
        equals(arg0: any): boolean;
        "handle(net.minecraft.network.PacketListener)"(arg0: Internal.PacketListener_): void;
        get class(): typeof any
        get skippable(): boolean
    }
    type ClientboundClearTitlesPacket_ = ClientboundClearTitlesPacket;
    interface OutgoingChatMessage {
        abstract content(): net.minecraft.network.chat.Component;
        create($$0: Internal.PlayerChatMessage_): this;
        abstract sendToPlayer(arg0: Internal.ServerPlayer_, arg1: boolean, arg2: Internal.ChatType$Bound_): void;
    }
    type OutgoingChatMessage_ = OutgoingChatMessage;
    class TagMatchTest extends Internal.RuleTest {
        constructor($$0: Internal.TagKey_<Internal.Block>)
        getClass(): typeof any;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        test($$0: Internal.BlockState_, $$1: Internal.RandomSource_): boolean;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        static readonly CODEC: Internal.Codec<Internal.TagMatchTest>;
    }
    type TagMatchTest_ = TagMatchTest;
    interface SelectableResource <T> {
        abstract setTag(arg0: Internal.CompoundTag_): void;
        item(stack: Internal.ItemStack_): Internal.SelectableResource<Internal.ItemStack>;
        abstract getName(): net.minecraft.network.chat.Component;
        abstract getIcon(): Internal.Icon;
        abstract getCount(): number;
        abstract copyWithCount(arg0: number): this;
        abstract getTag(): Internal.CompoundTag;
        isEmpty(): boolean;
        abstract setCount(arg0: number): void;
        fluid(stack: dev.architectury.fluid.FluidStack_): Internal.SelectableResource<dev.architectury.fluid.FluidStack>;
        abstract stack(): T;
        set tag(arg0: Internal.CompoundTag_)
        get name(): net.minecraft.network.chat.Component
        get icon(): Internal.Icon
        get count(): number
        get tag(): Internal.CompoundTag
        get empty(): boolean
        set count(arg0: number)
    }
    type SelectableResource_<T> = SelectableResource<T>;
    class ThingsItems$HardeningCatalystItem extends Internal.ItemWithExtendableTooltip {
        constructor()
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        tryAppend(tooltip: Internal.List_<net.minecraft.network.chat.Component>): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, world: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        tooltipTranslationKey(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        hasExtendedTooltip(): boolean;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil(stack: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        append(tooltip: Internal.List_<net.minecraft.network.chat.Component>): void;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        appendWrapped(tooltip: Internal.List_<net.minecraft.network.chat.Component>, toAppend: net.minecraft.network.chat.Component_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type ThingsItems$HardeningCatalystItem_ = ThingsItems$HardeningCatalystItem;
    class ResourceKey <T> implements Internal.SpecialEquality {
        constructor($$0: ResourceLocation_, $$1: ResourceLocation_)
        getClass(): typeof any;
        static "create(net.minecraft.resources.ResourceKey,net.minecraft.resources.ResourceLocation)"<T>($$0: Internal.ResourceKey_<Internal.Registry<T>>, $$1: ResourceLocation_): Internal.ResourceKey<T>;
        toString(): string;
        static checkSpecialEquality(o: any, o1: any, shallow: boolean): boolean;
        notifyAll(): void;
        specialEquals(o: any, shallow: boolean): boolean;
        static "create(net.minecraft.resources.ResourceLocation,net.minecraft.resources.ResourceLocation)"<T>($$0: ResourceLocation_, $$1: ResourceLocation_): Internal.ResourceKey<T>;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        static codec<T>($$0: Internal.ResourceKey_<Internal.Registry<T>>): Internal.Codec<Internal.ResourceKey<T>>;
        static create<T>($$0: ResourceLocation_, $$1: ResourceLocation_): Internal.ResourceKey<T>;
        hashCode(): number;
        location(): ResourceLocation;
        static createRegistryKey<T>($$0: ResourceLocation_): Internal.ResourceKey<Internal.Registry<T>>;
        static create<T>($$0: Internal.ResourceKey_<Internal.Registry<T>>, $$1: ResourceLocation_): Internal.ResourceKey<T>;
        wait(): void;
        registry(): ResourceLocation;
        wait(arg0: number): void;
        isFor($$0: Internal.ResourceKey_<Internal.Registry<any>>): boolean;
        getPath(): string;
        equals(arg0: any): boolean;
        getNamespace(): string;
        cast<E>($$0: Internal.ResourceKey_<Internal.Registry<E>>): Optional<Internal.ResourceKey<E>>;
        get class(): typeof any
        get path(): string
        get namespace(): string
    }
    type ResourceKey_<T> = ResourceKey<T>;
    class SoulwovenArmorItem extends Internal.ArmorItem implements Internal.Modifiable {
        constructor(material: Internal.ArmorMaterial_, type: Internal.ArmorItem$Type_, settings: Internal.Item$Properties_)
        onTick(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        getType(): Internal.ArmorItem$Type;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        addModifierTooltip(stack: Internal.ItemStack_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_, type: Internal.ModifierHelperType_<any>): void;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        appendHoverText(stack: Internal.ItemStack_, world: Internal.Level_, tooltip: Internal.List_<net.minecraft.network.chat.Component>, context: Internal.TooltipFlag_): void;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        setAttributeModifiers(arg0: Internal.Multimap_<any, any>): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        fzzy_core_correctSlot(slot: Internal.EquipmentSlot_): boolean;
        getCreativeTab(): string;
        postWearerHit(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, target: Internal.LivingEntity_): void;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        modifierObjectPredicate(livingEntity: Internal.LivingEntity_, stack: Internal.ItemStack_): ResourceLocation;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        defaultModifiers(type: Internal.ModifierHelperType_<any>): Internal.List<ResourceLocation>;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        static get($$0: Internal.ItemStack_): Internal.Equipable;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        kjs$getAttributeMap(): Internal.Multimap<any, any>;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getDefense(): number;
        kjs$getMutableAttributeMap(): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        getModifiers(stack: Internal.ItemStack_, type: Internal.ModifierHelperType_<any>): Internal.List<ResourceLocation>;
        fzzy_core_getCorrectSlot(): Internal.EquipmentSlot;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        getEquipmentSlot(): Internal.EquipmentSlot;
        onWearerKilledOther(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, victim: Internal.LivingEntity_, world: Internal.ServerLevel_): void;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        static access$getAttributeModifiers$s830519506($this: Internal.SoulwovenArmorItem_, slot: Internal.EquipmentSlot_): Internal.Multimap<any, any>;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        canBeModifiedBy(type: Internal.ModifierHelperType_<any>): boolean;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        static dispenseArmor($$0: Internal.BlockSource_, $$1: Internal.ItemStack_): boolean;
        getMaterial(): Internal.ArmorMaterial;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        incrementKillCount(stack: Internal.ItemStack_): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        getEquipSound(): Internal.SoundEvent;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        onAttack(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, attacker: Internal.LivingEntity_, source: DamageSource_, amount: number): number;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers(slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        getToughness(): number;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getKillCount(stack: Internal.ItemStack_): number;
        getTypeItemStackKey(): Internal.ItemStackKey;
        onWearerDamaged(stack: Internal.ItemStack_, wearer: Internal.LivingEntity_, attacker: Internal.LivingEntity_, source: DamageSource_, amount: number): number;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        postWearerMine(stack: Internal.ItemStack_, world: Internal.Level_, state: Internal.BlockState_, pos: BlockPos_, miner: Internal.Player_): void;
        kjs$setAttributeMap(arg0: Internal.Multimap_<any, any>): void;
        swapWithEquipmentSlot($$0: Internal.Item_, $$1: Internal.Level_, $$2: Internal.Player_, $$3: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get type(): Internal.ArmorItem$Type
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        set attributeModifiers(arg0: Internal.Multimap_<any, any>)
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        get defense(): number
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get equipmentSlot(): Internal.EquipmentSlot
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        get material(): Internal.ArmorMaterial
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get equipSound(): Internal.SoundEvent
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get toughness(): number
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type SoulwovenArmorItem_ = SoulwovenArmorItem;
    class ClientExtensionProviderBuilder <IN, OUT> extends Internal.JadeProviderBuilder {
        constructor(uniqueIdentifier: ResourceLocation_)
        getClass(): typeof any;
        toString(): string;
        setCallback(callback: Internal.Consumer_<Internal.GetClientGroupsCallbackJS<IN, OUT>>): this;
        groupCallback(callback: Internal.Consumer_<Internal.GetClientGroupsCallbackJS<IN, OUT>>): this;
        notifyAll(): void;
        callback(callback: Internal.Consumer_<Internal.GetClientGroupsCallbackJS<IN, OUT>>): this;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        onGroups(callback: Internal.Consumer_<Internal.GetClientGroupsCallbackJS<IN, OUT>>): this;
        setDefaultPriority(priority: number): Internal.JadeProviderBuilder;
        getDefaultPriority(): number;
        hashCode(): number;
        wait(): void;
        getUniqueIdentifier(): ResourceLocation;
        wait(arg0: number): void;
        getCallback(): Internal.Consumer<Internal.GetClientGroupsCallbackJS<IN, OUT>>;
        static doNothing<IN, OUT>(callback: Internal.GetClientGroupsCallbackJS_<IN, OUT>): void;
        equals(arg0: any): boolean;
        get class(): typeof any
        set callback(callback: Internal.Consumer_<Internal.GetClientGroupsCallbackJS<IN, OUT>>)
        set defaultPriority(priority: number)
        get defaultPriority(): number
        get uniqueIdentifier(): ResourceLocation
        get callback(): Internal.Consumer<Internal.GetClientGroupsCallbackJS<IN, OUT>>
    }
    type ClientExtensionProviderBuilder_<IN, OUT> = ClientExtensionProviderBuilder<IN, OUT>;
    interface ProjectileAccessor {
        abstract getOwnerUUID(): Internal.UUID;
        get ownerUUID(): Internal.UUID
        (): Internal.UUID_;
    }
    type ProjectileAccessor_ = ProjectileAccessor | (()=> Internal.UUID_);
    interface LevelHeightAccessor {
        getMinSection(): number;
        isOutsideBuildHeight($$0: number): boolean;
        "isOutsideBuildHeight(net.minecraft.core.BlockPos)"($$0: BlockPos_): boolean;
        getSectionIndex($$0: number): number;
        getMaxSection(): number;
        getMaxBuildHeight(): number;
        getSectionYFromSectionIndex($$0: number): number;
        getSectionsCount(): number;
        create($$0: number, $$1: number): this;
        abstract getMinBuildHeight(): number;
        "isOutsideBuildHeight(int)"($$0: number): boolean;
        getSectionIndexFromSectionY($$0: number): number;
        abstract getHeight(): number;
        isOutsideBuildHeight($$0: BlockPos_): boolean;
        get minSection(): number
        get maxSection(): number
        get maxBuildHeight(): number
        get sectionsCount(): number
        get minBuildHeight(): number
        get height(): number
    }
    type LevelHeightAccessor_ = LevelHeightAccessor;
    class EventExit extends Internal.Exception {
        constructor(result: Internal.EventResult_)
        getClass(): typeof any;
        "printStackTrace(java.io.PrintStream)"(arg0: Internal.PrintStream_): void;
        toString(): string;
        getMessage(): string;
        notifyAll(): void;
        "printStackTrace(java.io.PrintWriter)"(arg0: Internal.PrintWriter_): void;
        getCause(): Internal.Throwable;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        getStackTrace(): Internal.StackTraceElement[];
        printStackTrace(arg0: Internal.PrintWriter_): void;
        hashCode(): number;
        getSuppressed(): Internal.Throwable[];
        fillInStackTrace(): Internal.Throwable;
        addSuppressed(arg0: Internal.Throwable_): void;
        wait(): void;
        printStackTrace(): void;
        initCause(arg0: Internal.Throwable_): Internal.Throwable;
        wait(arg0: number): void;
        setStackTrace(arg0: Internal.StackTraceElement_[]): void;
        printStackTrace(arg0: Internal.PrintStream_): void;
        equals(arg0: any): boolean;
        getLocalizedMessage(): string;
        get class(): typeof any
        get message(): string
        get cause(): Internal.Throwable
        get stackTrace(): Internal.StackTraceElement[]
        get suppressed(): Internal.Throwable[]
        set stackTrace(arg0: Internal.StackTraceElement_[])
        get localizedMessage(): string
        readonly result: Internal.EventResult;
    }
    type EventExit_ = EventExit;
    interface Object2ObjectMap <K, V> extends Internal.Object2ObjectFunction<K, V>, Internal.Map<K, V> {
        computeIfAbsent(arg0: K, arg1: Internal.Function_<K, V>): V;
        abstract containsValue(arg0: any): boolean;
        composeShort(arg0: Internal.Short2ObjectFunction_<K>): Internal.Short2ObjectFunction<V>;
        keySet(): Internal.Set<any>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V): Internal.Map<K, V>;
        computeIfAbsent(arg0: K, arg1: Internal.Object2ObjectFunction_<K, V>): V;
        andThenFloat(arg0: Internal.Object2FloatFunction_<V>): Internal.Object2FloatFunction<K>;
        "computeIfAbsent(java.lang.Object,java.util.function.Function)"(arg0: K, arg1: Internal.Function_<K, V>): V;
        abstract get(arg0: any): V;
        copyOf<K, V>(arg0: Internal.Map_<K, V>): Internal.Map<K, V>;
        composeFloat(arg0: Internal.Float2ObjectFunction_<K>): Internal.Float2ObjectFunction<V>;
        entrySet(): Internal.ObjectSet<Internal.Map$Entry<K, V>>;
        putIfAbsent(arg0: K, arg1: V): V;
        apply(arg0: K): V;
        andThenReference<T>(arg0: Internal.Object2ReferenceFunction_<V, T>): Internal.Object2ReferenceFunction<K, T>;
        composeChar(arg0: Internal.Char2ObjectFunction_<K>): Internal.Char2ObjectFunction<V>;
        andThenDouble(arg0: Internal.Object2DoubleFunction_<V>): Internal.Object2DoubleFunction<K>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V): Internal.Map<K, V>;
        composeDouble(arg0: Internal.Double2ObjectFunction_<K>): Internal.Double2ObjectFunction<V>;
        /**
         * @deprecated
        */
        computeObjectIfAbsentPartial(arg0: K, arg1: Internal.Object2ObjectFunction_<K, V>): V;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V): Internal.Map<K, V>;
        andThenChar(arg0: Internal.Object2CharFunction_<V>): Internal.Object2CharFunction<K>;
        ofEntries<K, V>(...arg0: Internal.Map$Entry_<K, V>[]): Internal.Map<K, V>;
        replace(arg0: K, arg1: V, arg2: V): boolean;
        abstract defaultReturnValue(): V;
        identity<T>(): Internal.Function<T, T>;
        abstract defaultReturnValue(arg0: V): void;
        of<K, V>(arg0: K, arg1: V): Internal.Map<K, V>;
        replace(arg0: K, arg1: V): V;
        andThen<V>(arg0: Internal.Function_<V, V>): Internal.Function<K, V>;
        computeIfPresent(arg0: K, arg1: Internal.BiFunction_<K, V, V>): V;
        of<K, V>(): Internal.Map<K, V>;
        getOrDefault(arg0: any, arg1: V): V;
        composeByte(arg0: Internal.Byte2ObjectFunction_<K>): Internal.Byte2ObjectFunction<V>;
        abstract isEmpty(): boolean;
        entry<K, V>(arg0: K, arg1: V): Internal.Map$Entry<K, V>;
        abstract containsKey(arg0: any): boolean;
        put(arg0: K, arg1: V): V;
        abstract object2ObjectEntrySet(): Internal.ObjectSet<Internal.Object2ObjectMap$Entry<K, V>>;
        remove(arg0: any): V;
        merge(arg0: K, arg1: V, arg2: Internal.BiFunction_<V, V, V>): V;
        forEach(arg0: Internal.BiConsumer_<K, V>): void;
        andThenLong(arg0: Internal.Object2LongFunction_<V>): Internal.Object2LongFunction<K>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V): Internal.Map<K, V>;
        andThenInt(arg0: Internal.Object2IntFunction_<V>): Internal.Object2IntFunction<K>;
        andThenShort(arg0: Internal.Object2ShortFunction_<V>): Internal.Object2ShortFunction<K>;
        compute(arg0: K, arg1: Internal.BiFunction_<K, V, V>): V;
        composeInt(arg0: Internal.Int2ObjectFunction_<K>): Internal.Int2ObjectFunction<V>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V): Internal.Map<K, V>;
        remove(arg0: any, arg1: any): boolean;
        composeObject<T>(arg0: Internal.Object2ObjectFunction_<T, K>): Internal.Object2ObjectFunction<T, V>;
        abstract putAll(arg0: Internal.Map_<K, V>): void;
        abstract values(): Internal.ObjectCollection<V>;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V): Internal.Map<K, V>;
        andThenByte(arg0: Internal.Object2ByteFunction_<V>): Internal.Object2ByteFunction<K>;
        composeReference<T>(arg0: Internal.Reference2ObjectFunction_<T, K>): Internal.Reference2ObjectFunction<T, V>;
        abstract size(): number;
        composeLong(arg0: Internal.Long2ObjectFunction_<K>): Internal.Long2ObjectFunction<V>;
        abstract hashCode(): number;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V, arg16: K, arg17: V, arg18: K, arg19: V): Internal.Map<K, V>;
        compose<V>(arg0: Internal.Function_<V, K>): Internal.Function<V, V>;
        "computeIfAbsent(java.lang.Object,it.unimi.dsi.fastutil.objects.Object2ObjectFunction)"(arg0: K, arg1: Internal.Object2ObjectFunction_<K, V>): V;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V, arg16: K, arg17: V): Internal.Map<K, V>;
        clear(): void;
        andThenObject<T>(arg0: Internal.Object2ObjectFunction_<V, T>): Internal.Object2ObjectFunction<K, T>;
        replaceAll(arg0: Internal.BiFunction_<K, V, V>): void;
        of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V): Internal.Map<K, V>;
        abstract equals(arg0: any): boolean;
        get empty(): boolean
    }
    type Object2ObjectMap_<K, V> = Object2ObjectMap<K, V>;
    class ClientboundPlayerInfoUpdatePacket$Entry extends Internal.Record implements Internal.PlayerListS2CPacketEntryAccessor {
        constructor($$0: Internal.UUID_, $$1: Internal.GameProfile_, $$2: boolean, $$3: number, $$4: Internal.GameType_, $$5: net.minecraft.network.chat.Component_, $$6: Internal.RemoteChatSession$Data_)
        getClass(): typeof any;
        chatSession(): Internal.RemoteChatSession$Data;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        displayName(): net.minecraft.network.chat.Component;
        wait(arg0: number, arg1: number): void;
        gameMode(): Internal.GameType;
        setProfile(arg0: Internal.GameProfile_): void;
        setDisplayName(arg0: net.minecraft.network.chat.Component_): void;
        hashCode(): number;
        latency(): number;
        wait(): void;
        wait(arg0: number): void;
        listed(): boolean;
        equals($$0: any): boolean;
        profileId(): Internal.UUID;
        profile(): Internal.GameProfile;
        get class(): typeof any
        set profile(arg0: Internal.GameProfile_)
        set displayName(arg0: net.minecraft.network.chat.Component_)
    }
    type ClientboundPlayerInfoUpdatePacket$Entry_ = ClientboundPlayerInfoUpdatePacket$Entry;
    class IsInsideStructureTracker {
        constructor()
        getClass(): typeof any;
        setInside(world: Internal.Level_, entity: Internal.Entity_, isInside: Internal.IsInsideStructureTracker$IsInside_): void;
        hashCode(): number;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        getTracker(): Internal.IsInsideStructureTracker$IsInside;
        equals(arg0: any): boolean;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        get tracker(): Internal.IsInsideStructureTracker$IsInside
    }
    type IsInsideStructureTracker_ = IsInsideStructureTracker;
    class Goat extends Internal.Animal {
        constructor($$0: Internal.EntityType_<Internal.Goat>, $$1: Internal.Level_)
        handler$hak000$gobber2$gobberOccludeVibrationSignals(cir: Internal.CallbackInfoReturnable_<any>): void;
        handler$fed001$extraalchemy$writeNbt(tag: Internal.CompoundTag_, cb: Internal.CallbackInfo_): void;
        etf$getType(): Internal.EntityType<any>;
        getUpVector($$0: number): Vec3d;
        gameEvent($$0: Internal.GameEvent_, $$1: Internal.Entity_): void;
        static checkMobSpawnRules($$0: Internal.EntityType_<Internal.Mob>, $$1: Internal.LevelAccessor_, $$2: Internal.MobSpawnType_, $$3: BlockPos_, $$4: Internal.RandomSource_): boolean;
        setDefaultMovementSpeedMultiplier(speed: number): void;
        isSuppressingBounce(): boolean;
        setTarget($$0: Internal.LivingEntity_): void;
        handler$han001$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        setCulled(value: boolean): void;
        handler$leb003$puzzleslib$hurt(source: DamageSource_, amount: number, callback: Internal.CallbackInfoReturnable_<any>): void;
        isOnFire(): boolean;
        getPositionCodec(): Internal.VecDeltaCodec;
        setMaxUpStep($$0: number): void;
        updateFluidHeightAndDoFluidPushing($$0: Internal.TagKey_<Internal.Fluid>, $$1: number): boolean;
        convertTo<T extends Internal.Mob>($$0: Internal.EntityType_<T>, $$1: boolean): T;
        getFallFlyingTicks(): number;
        setPosition(x: number, y: number, z: number): void;
        runCommandSilent(command: string): number;
        chunkPosition(): Internal.ChunkPos;
        emf$isOnGround(): boolean;
        dropLeash($$0: boolean, $$1: boolean): void;
        gameEvent($$0: Internal.GameEvent_): void;
        setXxa($$0: number): void;
        setDelayedLeashHolderId($$0: number): void;
        isShiftKeyDown(): boolean;
        setUUID($$0: Internal.UUID_): void;
        checkBelowWorld(): void;
        handler$leb000$puzzleslib$startUsingItem(hand: Internal.InteractionHand_, callback: Internal.CallbackInfo_): void;
        setMotionZ(z: number): void;
        "deserializeNBT(net.minecraft.nbt.Tag)"(arg0: Internal.Tag_): void;
        canFreeze(): boolean;
        ignoreExplosion(): boolean;
        getBlockY(): number;
        getIsInsideStructureTracker(): Internal.IsInsideStructureTracker;
        setPlayerHitTimer(arg0: number): void;
        isSpectator(): boolean;
        setMainHandItem(item: Internal.ItemStack_): void;
        removeEffectNoUpdate($$0: Internal.MobEffect_): Internal.MobEffectInstance;
        spawnAtLocation($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        getPersistentData(): Internal.CompoundTag;
        getHealth(): number;
        getMaxHealth(): number;
        emf$isGlowing(): boolean;
        setPathfindingMalus($$0: Internal.BlockPathTypes_, $$1: number): void;
        isRegisteredToWorld(): boolean;
        getRandomZ($$0: number): number;
        pehkui_getOnGround(): boolean;
        setAggressive($$0: boolean): void;
        handler$lef000$puzzleslib$checkDespawn(callback: Internal.CallbackInfo_): void;
        getFusionModel(layerIndex: number): Internal.Triple<any, any, any>;
        setRemoved($$0: Internal.Entity$RemovalReason_): void;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>, initializer: Internal.Supplier_<A>): A;
        getDistanceSq($$0: number, $$1: number, $$2: number): number;
        isInWaterRainOrBubble(): boolean;
        getRemovalReason(): Internal.Entity$RemovalReason;
        etf$getVelocity(): Vec3d;
        hex$markHurt(): void;
        resetFallDistance(): void;
        canSprint(): boolean;
        blockPosition(): BlockPos;
        setBoundingBox($$0: Internal.AABB_): void;
        isAmbientCreature(): boolean;
        setZza($$0: number): void;
        getBlock(): Internal.BlockContainerJS;
        setEquipment(slot: Internal.EquipmentSlot_, item: Internal.ItemStack_): void;
        etf$getHandItems(): Internal.Iterable<any>;
        randomTeleport($$0: number, $$1: number, $$2: number, $$3: boolean): boolean;
        setScreamingGoat($$0: boolean): void;
        getName(): net.minecraft.network.chat.Component;
        playAmbientSound(): void;
        onGround(): boolean;
        handler$leb000$puzzleslib$canBeAffected(effectInstance: Internal.MobEffectInstance_, callback: Internal.CallbackInfoReturnable_<any>): void;
        getControlledVehicle(): Internal.Entity;
        isOnSameTeam($$0: Internal.Entity_): boolean;
        getArmorValue(): number;
        tick(): void;
        localvar$lef000$puzzleslib$setTarget(entity: Internal.LivingEntity_): Internal.LivingEntity;
        getKillCredit(): Internal.LivingEntity;
        removeHorns(): void;
        emf$isTouchingWater(): boolean;
        emf$getVariableMap(): Internal.Object2FloatOpenHashMap<any>;
        getComponentContainer(): Internal.ComponentContainer;
        hasPermissions($$0: number): boolean;
        getDynamicLightPrevZ(): number;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        pehkui_readScaleNbt(nbt: Internal.CompoundTag_): void;
        setOutOfCamera(value: boolean): void;
        static createMobAttributes(): Internal.AttributeSupplier$Builder;
        isAutoSpinAttack(): boolean;
        getRemainingFireTicks(): number;
        botania_getAmbientSound(): Internal.SoundEvent;
        onlyOpCanSetNbt(): boolean;
        tcdcommons_getCustomData(): Internal.GenericProperties<any>;
        fireImmune(): boolean;
        addMotion($$0: number, $$1: number, $$2: number): void;
        getMaxFallDistance(): number;
        isHolding($$0: Internal.Item_): boolean;
        getZ($$0: number): number;
        static areAllEffectsAmbient($$0: Internal.Collection_<Internal.MobEffectInstance>): boolean;
        doHurtTarget($$0: Internal.Entity_): boolean;
        getTicksFrozen(): number;
        wrapWithCondition$kom000$porting_lib_entity$port_lib$captureDrops(level: Internal.Level_, entity: Internal.Entity_): boolean;
        handler$lef000$puzzleslib$addAdditionalSaveData(compound: Internal.CompoundTag_, callback: Internal.CallbackInfo_): void;
        deflect(chance: number, source: Internal.Entity_): boolean;
        getRandomX($$0: number): number;
        getDynamicLightZ(): number;
        spawnAtLocation($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        pick($$0: number, $$1: number, $$2: boolean): Internal.HitResult;
        getVoicePitch(): number;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        setSleepingPos($$0: BlockPos_): void;
        changeDimension(p_20118_: Internal.ServerLevel_, teleporter: Internal.ITeleporter_): Internal.Entity;
        isDescending(): boolean;
        getAttributeBaseValue($$0: Internal.Attribute_): number;
        emf$getPitch(): number;
        sendEffectToPassengers($$0: Internal.MobEffectInstance_): void;
        getHeadRotSpeed(): number;
        getLastHurtByPlayer(): Internal.Player;
        getYHeadRot(): number;
        handler$cbi000$besmirchment$isTeammate(other: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>): void;
        localvar$leb000$puzzleslib$addEffect(oldEffectInstance: Internal.MobEffectInstance_, effectInstance: Internal.MobEffectInstance_, entity: Internal.Entity_): Internal.MobEffectInstance;
        getProjectile($$0: Internal.ItemStack_): Internal.ItemStack;
        static getAlpha(le: Internal.LivingEntity_, partialTicks: number): number;
        frameworkGetDataHolder(): com.mrcrayfish.framework.entity.sync.DataHolder;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        syncPacketPositionCodec($$0: number, $$1: number, $$2: number): void;
        setAbsorptionAmount($$0: number): void;
        setRecallData(pos: Internal.DimensionalPosition_): void;
        port_lib$spawnItemParticles(arg0: Internal.ItemStack_, arg1: number): void;
        shouldRenderAtSqrDistance($$0: number): boolean;
        getAttachedOrSet<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        damageSources(): Internal.DamageSources;
        removeAttached<A>(type: Internal.AttachmentType_<A>): A;
        removeAllGoals($$0: Internal.Predicate_<Internal.Goal>): void;
        swing(): void;
        recreateFromPacket($$0: Internal.ClientboundAddEntityPacket_): void;
        setDeltaMovement($$0: Vec3d_): void;
        getLeashOffset($$0: number): Vec3d;
        isBaby(): boolean;
        isCulled(): boolean;
        damageEquipment(slot: Internal.EquipmentSlot_): void;
        isGlowing(): boolean;
        getWalkTargetValue($$0: BlockPos_): number;
        canBreatheUnderwater(): boolean;
        getLeashedByEntities(): Internal.Set<any>;
        die($$0: DamageSource_): void;
        etf$getOptifineId(): number;
        removeAllEffects(): boolean;
        dynamicLightWorld(): Internal.Level;
        getLeashOffset(): Vec3d;
        hasLineOfSight($$0: Internal.Entity_): boolean;
        hex$getLastHurt(): number;
        onClimbable(): boolean;
        isAttackable(): boolean;
        getSlot($$0: number): Internal.SlotAccess;
        "deserializeNBT(net.minecraft.nbt.CompoundTag)"(nbt: Internal.CompoundTag_): void;
        emf$isInLava(): boolean;
        pehkui_constructScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        stopSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isUnderWater(): boolean;
        stopRiding(): void;
        getLeashHolder(): Internal.Entity;
        getX($$0: number): number;
        getSensing(): Internal.Sensing;
        localvar$kpc000$porting_lib_entity$port_lib$modifyMultiplier(multiplier: number): number;
        getLegsArmorItem(): Internal.ItemStack;
        getLuminance(): number;
        callUnsetRemoved(): void;
        captureDrops(value: Internal.Collection_<Internal.ItemEntity>): Internal.Collection<Internal.ItemEntity>;
        getSelfAndPassengers(): Internal.Stream<any>;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        "getBreedOffspring(net.minecraft.server.level.ServerLevel,net.minecraft.world.entity.AgeableMob)"($$0: Internal.ServerLevel_, $$1: Internal.AgeableMob_): this;
        handler$egi000$collective$LivingEntity_hurt(damageSource: DamageSource_, f: number, ci: Internal.CallbackInfoReturnable_<any>): void;
        getDeltaMovement(): Vec3d;
        canTakeItem($$0: Internal.ItemStack_): boolean;
        shouldDropExperience(): boolean;
        hasPassenger($$0: Internal.Entity_): boolean;
        be_getTravelerState(): Internal.TravelerState;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_, predicate: Internal.PlayerSyncPredicate_): void;
        getDynamicLightX(): number;
        setSecondsOnFire($$0: number): void;
        moveTo($$0: number, $$1: number, $$2: number): void;
        emf$getZ(): number;
        "getDisplayName()"(): net.minecraft.network.chat.Component;
        getLootTable(): ResourceLocation;
        getTicksUsingItem(): number;
        bettertrims$getWornMaterials(): Internal.List<any>;
        getArrowCount(): number;
        getMoveControl(): Internal.MoveControl;
        setMotion($$0: number, $$1: number, $$2: number): void;
        playSound($$0: Internal.SoundEvent_): void;
        getDefaultMovementSpeed(): number;
        handler$ikg000$lithium$tryShortcutFluidPushing(tag: Internal.TagKey_<any>, speed: number, cir: Internal.CallbackInfoReturnable_<any>, box: Internal.AABB_, x1: number, x2: number, y1: number, y2: number, z1: number, z2: number, zero: number): void;
        handler$hak000$gobber2$setFrozenTicks(frozenTicks: number, ci: Internal.CallbackInfo_): void;
        restoreFrom($$0: Internal.Entity_): void;
        isPeacefulCreature(): boolean;
        setOnGround($$0: boolean): void;
        addEffect($$0: Internal.MobEffectInstance_, $$1: Internal.Entity_): boolean;
        emf$getYaw(): number;
        hasRightHorn(): boolean;
        ate(): void;
        setPos($$0: number, $$1: number, $$2: number): void;
        notify(): void;
        setPersistenceRequired(): void;
        getLastHurtByMobTimestamp(): number;
        getVehicle(): Internal.Entity;
        canFallInLove(): boolean;
        isEffectiveAi(): boolean;
        handler$kom000$porting_lib_entity$port_lib$startRiding(entity: Internal.Entity_, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        startRiding($$0: Internal.Entity_, $$1: boolean): boolean;
        getStringUuid(): string;
        setSwimming($$0: boolean): void;
        getMainArm(): Internal.HumanoidArm;
        checkSpawnRules($$0: Internal.LevelAccessor_, $$1: Internal.MobSpawnType_): boolean;
        getRotationVector(): Internal.Vec2;
        getHurtDir(): number;
        etf$getBlockY(): number;
        isSprinting(): boolean;
        isMaxGroupSizeReached($$0: number): boolean;
        getMotionY(): number;
        getOffhandItem(): Internal.ItemStack;
        canCollideWith($$0: Internal.Entity_): boolean;
        setLuminance(luminance: number): void;
        getBlockExplosionResistance($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: Internal.FluidState_, $$5: number): number;
        setLootTable(arg0: ResourceLocation_): void;
        clearSleepingPos(): void;
        canSpawnSprintParticle(): boolean;
        "moveTo(net.minecraft.core.BlockPos,float,float)"($$0: BlockPos_, $$1: number, $$2: number): void;
        hex$checkTotemDeathProtection(arg0: DamageSource_): boolean;
        getLastHurtMob(): Internal.LivingEntity;
        moveRelative($$0: number, $$1: Vec3d_): void;
        saveAsPassenger($$0: Internal.CompoundTag_): boolean;
        static gatherClosestChunks(chunks: Internal.LongSet_, x: number, y: number, z: number): void;
        handler$kom000$porting_lib_entity$afterSave(nbt: Internal.CompoundTag_, cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDamageSource(): DamageSource;
        getSoundSource(): Internal.SoundSource;
        setNoActionTime($$0: number): void;
        setMovementSpeedAddition(speed: number): void;
        removeAfterChangingDimensions(): void;
        equipmentHasChanged($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        getPose(): Internal.Pose;
        getAttribute($$0: Internal.Attribute_): Internal.AttributeInstance;
        setPositionAndRotation($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        canBeAffected($$0: Internal.MobEffectInstance_): boolean;
        ageUp($$0: number): void;
        getRestrictCenter(): BlockPos;
        isLeftHanded(): boolean;
        invokeShouldDropLoot(): boolean;
        handler$kpc000$porting_lib_entity$port_lib$onFinishUsing(ci: Internal.CallbackInfo_, hand: Internal.InteractionHand_, result: Internal.ItemStack_): void;
        etf$getUuid(): Internal.UUID;
        removeVehicle(): void;
        shouldFusionRecomputeModel(layerIndex: number): boolean;
        modifyExpressionValue$zcl000$porting_lib_base$port_lib$canContinueUsing(original: boolean): boolean;
        setZ(z: number): void;
        getY(): number;
        deserializeNBT(nbt: Internal.CompoundTag_): void;
        hashCode(): number;
        finalizeSpawnChildFromBreeding($$0: Internal.ServerLevel_, $$1: Internal.Animal_, $$2: Internal.AgeableMob_): void;
        eat($$0: Internal.Level_, $$1: Internal.ItemStack_): Internal.ItemStack;
        bookshelf$makePoofParticles(): void;
        isWithinMeleeAttackRange($$0: Internal.LivingEntity_): boolean;
        setCurrentModifyFoodPowers(powers: Internal.List_<any>): void;
        broadcastBreakEvent($$0: Internal.EquipmentSlot_): void;
        modifyExpressionValue$zhf000$additionalentityattributes$additionalEntityAttributes$modifyUpwardSwimming(original: number, fluid: Internal.TagKey_<any>): number;
        handler$nbm000$things$onShieldBlock(source: DamageSource_, cir: Internal.CallbackInfoReturnable_<any>): void;
        showVehicleHealth(): boolean;
        getDistance(pos: BlockPos_): number;
        isBlocking(): boolean;
        "getBreedOffspring(net.minecraft.server.level.ServerLevel,net.minecraft.world.entity.AgeableMob)"(arg0: Internal.ServerLevel_, arg1: Internal.AgeableMob_): Internal.AgeableMob;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number): void;
        removeAttribute(attribute: Internal.Attribute_, identifier: string): void;
        emf$getVelocity(): Vec3d;
        handler$lef000$puzzleslib$finalizeSpawn(level: Internal.ServerLevelAccessor_, difficulty: Internal.DifficultyInstance_, reason: Internal.MobSpawnType_, spawnData: Internal.SpawnGroupData_, dataTag: Internal.CompoundTag_, callback: Internal.CallbackInfoReturnable_<any>): void;
        etf$isBlockEntity(): boolean;
        shouldUpdateDynamicLight(): boolean;
        getBreedOffspring($$0: Internal.ServerLevel_, $$1: Internal.AgeableMob_): this;
        isPushedByFluid(): boolean;
        setOriginalFoodStack(original: Internal.ItemStack_): void;
        getArmorCoverPercentage(): number;
        handleRelativeFrictionAndCalculateMovement($$0: Vec3d_, $$1: number): Vec3d;
        turn($$0: number, $$1: number): void;
        getAirSupply(): number;
        moveTo($$0: BlockPos_, $$1: number, $$2: number): void;
        isPlayer(): boolean;
        isAnimal(): boolean;
        "handler$fgd000$fabric-dimensions-v1$getTeleportTarget"(destination: Internal.ServerLevel_, cir: Internal.CallbackInfoReturnable_<any>): void;
        canBeCollidedWith(): boolean;
        getMotionDirection(): Internal.Direction;
        asComponentProvider(): Internal.ComponentProvider;
        lavaHurt(): void;
        handleDamageEvent($$0: DamageSource_): void;
        getFabricBalmData(): Internal.CompoundTag;
        canChangeDimensions(): boolean;
        static tickEntity(entity: Internal.Entity_): void;
        getCommandSenderWorld(): Internal.Level;
        getTotalMovementSpeed(): number;
        changeDimension($$0: Internal.ServerLevel_): Internal.Entity;
        createHorn(): Internal.ItemStack;
        localvar$zno000$apoli$modifyFallingVelocity(in_: number): number;
        handler$kom000$porting_lib_entity$afterLoad(nbt: Internal.CompoundTag_, ci: Internal.CallbackInfo_): void;
        pehkui_shouldIgnoreScaleNbt(): boolean;
        isMoving(): boolean;
        attack(hp: number): void;
        getAttributes(): Internal.AttributeMap;
        "hasPassenger(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.Entity>): boolean;
        botania_playHurtSound(arg0: DamageSource_): void;
        getDimensions($$0: Internal.Pose_): Internal.EntityDimensions;
        spawnChildFromBreeding($$0: Internal.ServerLevel_, $$1: Internal.Animal_): void;
        setInLoveTime($$0: number): void;
        invokeGetLeashOffset(): Vec3d;
        isSwimming(): boolean;
        setSprinting($$0: boolean): void;
        mayInteract($$0: Internal.Level_, $$1: BlockPos_): boolean;
        handler$kpc000$porting_lib_entity$port_lib$attackEvent(source: DamageSource_, amount: number, cir: Internal.CallbackInfoReturnable_<any>): void;
        getDynamicLightLevel(): Internal.Level;
        setPortalCooldown(): void;
        getAttackAnim($$0: number): number;
        hex$setLastHurt(arg0: number): void;
        setX(x: number): void;
        getPortalWaitTime(): number;
        getBlockStateOn(): Internal.BlockState;
        wantsToPickUp($$0: Internal.ItemStack_): boolean;
        getItemBySlot($$0: Internal.EquipmentSlot_): Internal.ItemStack;
        getFluidHeightLoosely(tag: Internal.TagKey_<any>): number;
        getFluidJumpThreshold(): number;
        getCachedSouls(): number;
        "setPositionAndRotation(double,double,double,float,float)"($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        isInvisibleTo($$0: Internal.Player_): boolean;
        stopSleeping(): void;
        hasLeftHorn(): boolean;
        setAirSupply($$0: number): void;
        getOnPos(): BlockPos;
        etf$getWorld(): Internal.Level;
        isUndead(): boolean;
        static createLivingAttributes(): Internal.AttributeSupplier$Builder;
        setUseItemRemaining(arg0: number): void;
        pehkui_getScales(): Internal.Map<any, any>;
        getTargetSelector(): Internal.GoalSelector;
        setRegisteredToWorld(navigation: Internal.PathNavigation_): void;
        isSleeping(): boolean;
        stopUsingItem(): void;
        etf$getNbt(): Internal.CompoundTag;
        acceptsFailure(): boolean;
        etf$getBlockPos(): BlockPos;
        pehkui_setShouldIgnoreScaleNbt(ignore: boolean): void;
        setOnGroundWithKnownMovement($$0: boolean, $$1: Vec3d_): void;
        getFluidFallingAdjustedMovement($$0: number, $$1: boolean, $$2: Vec3d_): Vec3d;
        setOldPosAndRot(): void;
        localvar$cjk000$bettertridents$doHurtTarget$modifyVariable$store(damageAmount: number, entity: Internal.Entity_): number;
        isFree($$0: number, $$1: number, $$2: number): boolean;
        getDismountPoses(): Internal.ImmutableList<Internal.Pose>;
        getLastHurtMobTimestamp(): number;
        lithiumOnEquipmentChanged(): void;
        "moveTo(double,double,double)"($$0: number, $$1: number, $$2: number): void;
        setRemainingFireTicks($$0: number): void;
        emf$age(): number;
        etf$hasCustomName(): boolean;
        /**
         * @deprecated
        */
        getOnPosLegacy(): BlockPos;
        port_lib$isJumping(): boolean;
        setPos($$0: Vec3d_): void;
        localvar$leb000$puzzleslib$knockback$2(ratioX: number): number;
        static "tickEntity(net.minecraft.world.entity.LivingEntity)"(entity: Internal.LivingEntity_): void;
        updateCachedSouls(): void;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        setCanPickUpLoot($$0: boolean): void;
        getMainHandItem(): Internal.ItemStack;
        handler$kom000$porting_lib_entity$port_lib$removeRidingEntity(ci: Internal.CallbackInfo_): void;
        setSilent($$0: boolean): void;
        captureDrops(): Internal.Collection<Internal.ItemEntity>;
        hasExactlyOnePlayerPassenger(): boolean;
        dropHorn(): boolean;
        canBeSeenAsEnemy(): boolean;
        setLeftHanded($$0: boolean): void;
        getActiveEffects(): Internal.Collection<Internal.MobEffectInstance>;
        isOnPortalCooldown(): boolean;
        hurtArmor($$0: DamageSource_, $$1: number): void;
        canAttack($$0: Internal.LivingEntity_, $$1: Internal.TargetingConditions_): boolean;
        getAttributeValue($$0: Internal.Holder_<Internal.Attribute>): number;
        lambdynlights$setTrackedLitChunkPos(trackedLitChunkPos: Internal.LongSet_): void;
        fzzy_core_setModifierContainer(container: Internal.ModifierContainer_): void;
        setPitch($$0: number): void;
        setPosRaw($$0: number, $$1: number, $$2: number): void;
        handleEntityEvent($$0: number): void;
        isUsingItem(): boolean;
        isAlwaysTicking(): boolean;
        interactAt($$0: Internal.Player_, $$1: Vec3d_, $$2: Internal.InteractionHand_): Internal.InteractionResult;
        emf$getX(): number;
        puzzleslib$acceptCapturedDrops(capturedDrops: Internal.Collection_<any>): Internal.Collection<any>;
        handler$hak000$gobber2$gobberIsFireImmune(cir: Internal.CallbackInfoReturnable_<any>): void;
        lerpTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number, $$5: number, $$6: boolean): void;
        onPassengerTurned($$0: Internal.Entity_): void;
        modifyReturnValue$zhe000$additionalentityattributes$getMaxAir(original: number): number;
        spawnAtLocation($$0: Internal.ItemLike_): Internal.ItemEntity;
        emf$hasPassengers(): boolean;
        serializeNBT(): Internal.CompoundTag;
        setAttached(type: Internal.AttachmentType_<any>, value: any): any;
        port_lib$getEntityString(): string;
        markEffectsDirty(): void;
        lithiumOnBlockCacheDeleted(): void;
        "spawnAtLocation(net.minecraft.world.level.ItemLike,int)"($$0: Internal.ItemLike_, $$1: number): Internal.ItemEntity;
        setInvulnerable($$0: boolean): void;
        push($$0: Internal.Entity_): void;
        emf$hasVehicle(): boolean;
        canMate($$0: Internal.Animal_): boolean;
        method_5992($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        maxUpStep(): number;
        getDynamicLightPrevY(): number;
        localvar$leb000$puzzleslib$hurt$1(amount: number, source: DamageSource_): number;
        setGlowing($$0: boolean): void;
        load($$0: Internal.CompoundTag_): void;
        "broadcastBreakEvent(net.minecraft.world.entity.EquipmentSlot)"($$0: Internal.EquipmentSlot_): void;
        setLeashedTo($$0: Internal.Entity_, $$1: boolean): void;
        isAlive(): boolean;
        startSleeping($$0: BlockPos_): void;
        getBbHeight(): number;
        getMeleeAttackRangeSqr($$0: Internal.LivingEntity_): number;
        handler$fed002$extraalchemy$readNbt(tag: Internal.CompoundTag_, cb: Internal.CallbackInfo_): void;
        bookshelf$getDrinkingSound(arg0: Internal.ItemStack_): Internal.SoundEvent;
        getTags(): Internal.Set<string>;
        getViewVector($$0: number): Vec3d;
        getLastAttacker(): Internal.LivingEntity;
        hasControllingPassenger(): boolean;
        closerThan($$0: Internal.Entity_, $$1: number, $$2: number): boolean;
        absMoveTo($$0: number, $$1: number, $$2: number, $$3: number, $$4: number): void;
        getLastRollTicks(): number;
        getGoalSelector(): Internal.GoalSelector;
        localvar$leb000$puzzleslib$causeFallDamage$2(damageMultiplier: number): number;
        onPathfindingStart(): void;
        handler$zzb000$porting_lib_attributes$port_lib$entityGravity(travelVector: Vec3d_, ci: Internal.CallbackInfo_): void;
        getPercentFrozen(): number;
        setPortalCooldown($$0: number): void;
        hasGlowingTag(): boolean;
        shouldBlockExplode($$0: Internal.Explosion_, $$1: Internal.BlockGetter_, $$2: BlockPos_, $$3: Internal.BlockState_, $$4: number): boolean;
        emf$isInvisible(): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        isLeashed(): boolean;
        addEffect($$0: Internal.MobEffectInstance_): boolean;
        emf$isSprinting(): boolean;
        handler$leb000$puzzleslib$knockback$0(strength: number, ratioX: number, ratioZ: number, callback: Internal.CallbackInfo_): void;
        ageUp($$0: number, $$1: boolean): void;
        handler$egi000$collective$LivingEntity_tick(ci: Internal.CallbackInfo_): void;
        handler$gec000$faster_entity_animations$getLeaningPitch(f: number, info: Internal.CallbackInfoReturnable_<any>): void;
        canRiderInteract(): boolean;
        getViewXRot($$0: number): number;
        handler$leb001$puzzleslib$die(damageSource: DamageSource_, callback: Internal.CallbackInfo_): void;
        fabric_getAttachments(): Internal.Map<any, any>;
        setPose($$0: Internal.Pose_): void;
        getReachDistance(): number;
        getEntityType(): Internal.EntityType<any>;
        isWaterCreature(): boolean;
        hex$playHurtSound(arg0: DamageSource_): void;
        pehkui_getScaleData(type: Internal.ScaleType_): Internal.ScaleData;
        toString(): string;
        etf$getScoreboardTeam(): Internal.Team;
        getBreedOffspring(arg0: Internal.ServerLevel_, arg1: Internal.AgeableMob_): Internal.AgeableMob;
        setLastHurtByPlayer($$0: Internal.Player_): void;
        handler$ldh000$puzzleslib$removeVehicle(callback: Internal.CallbackInfo_): void;
        "getServer()"(): Internal.MinecraftServer;
        wasExperienceConsumed(): boolean;
        isPushable(): boolean;
        setYBodyRot($$0: number): void;
        foodEaten(is: Internal.ItemStack_): void;
        onClientRemoval(): void;
        getDistance(x: number, y: number, z: number): number;
        setMotionY(y: number): void;
        static createAttributes(): Internal.AttributeSupplier$Builder;
        localvar$lcp000$puzzleslib$spawnChildFromBreeding(child: Internal.AgeableMob_, serverLevel: Internal.ServerLevel_, partner: Internal.Animal_): Internal.AgeableMob;
        getAttached(type: Internal.AttachmentType_<any>): any;
        setRotation(yaw: number, pitch: number): void;
        isDynamicLightEnabled(): boolean;
        handler$ldh000$puzzleslib$startRiding(vehicle: Internal.Entity_, force: boolean, callback: Internal.CallbackInfoReturnable_<any>): void;
        calculateEntityAnimation($$0: boolean): void;
        forceAddEffect($$0: Internal.MobEffectInstance_, $$1: Internal.Entity_): void;
        setChestArmorItem(item: Internal.ItemStack_): void;
        getComponent<C extends dev.onyxstudios.cca.api.v3.component.Component>(key: Internal.ComponentKey_<C>): C;
        bookshelf$getHurtSound(arg0: DamageSource_): Internal.SoundEvent;
        onAboveBubbleCol($$0: boolean): void;
        archon$setOwner(uiud: string): void;
        "playSound(net.minecraft.sounds.SoundEvent,float,float)"($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        toComponentPacket(key: Internal.ComponentKey_<any>, writer: Internal.ComponentPacketWriter_, recipient: Internal.ServerPlayer_): Internal.ClientboundCustomPayloadPacket;
        isPassenger(): boolean;
        hasPose($$0: Internal.Pose_): boolean;
        supp$setSlimedTicks(newSlimedTicks: number, sync: boolean): void;
        isEyeInFluid($$0: Internal.TagKey_<Internal.Fluid>): boolean;
        isInvulnerableTo($$0: DamageSource_): boolean;
        makeStuckInBlock($$0: Internal.BlockState_, $$1: Vec3d_): void;
        getAttachedOrGet<A>(type: Internal.AttachmentType_<A>, defaultValue: Internal.Supplier_<A>): A;
        getBrain(): Internal.Brain<Internal.Goat>;
        isSensitiveToWater(): boolean;
        skipAttackInteraction($$0: Internal.Entity_): boolean;
        lerpMotion($$0: number, $$1: number, $$2: number): void;
        "getAttributeValue(net.minecraft.core.Holder)"($$0: Internal.Holder_<Internal.Attribute>): number;
        shouldRender($$0: number, $$1: number, $$2: number): boolean;
        getJumpControl(): Internal.JumpControl;
        localvar$zcl000$porting_lib_base$port_lib$setSlipperiness(p: number): number;
        getFeetArmorItem(): Internal.ItemStack;
        handler$bia000$axiom$onTurn(d: number, e: number, ci: Internal.CallbackInfo_): void;
        static getViewScale(): number;
        handler$mpg000$tcdcommons$onAddStatusEffect(effect: Internal.MobEffectInstance_, source: Internal.Entity_, ci: Internal.CallbackInfoReturnable_<any>): void;
        getVisualRotationYInDegrees(): number;
        setSpeed($$0: number): void;
        requiresCustomPersistence(): boolean;
        handler$nbm000$things$onShieldHit(attacker: Internal.LivingEntity_, ci: Internal.CallbackInfo_): void;
        isDiscrete(): boolean;
        unRide(): void;
        getLevel(): Internal.Level;
        "spawnAtLocation(net.minecraft.world.item.ItemStack)"($$0: Internal.ItemStack_): Internal.ItemEntity;
        getCombatTracker(): Internal.CombatTracker;
        updateDynamicGameEventListener($$0: Internal.BiConsumer_<Internal.DynamicGameEventListener<any>, Internal.ServerLevel>): void;
        canBreed(): boolean;
        "onSyncedDataUpdated(net.minecraft.network.syncher.EntityDataAccessor)"($$0: Internal.EntityDataAccessor_<any>): void;
        emf$prevY(): number;
        isNoAi(): boolean;
        extinguishFire(): void;
        getChestArmorItem(): Internal.ItemStack;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number): void;
        port_lib$lastPos(): BlockPos;
        tell(message: net.minecraft.network.chat.Component_): void;
        closerThan($$0: Internal.Entity_, $$1: number): boolean;
        static checkGoatSpawnRules($$0: Internal.EntityType_<Internal.Animal>, $$1: Internal.LevelAccessor_, $$2: Internal.MobSpawnType_, $$3: BlockPos_, $$4: Internal.RandomSource_): boolean;
        hex$getSoundVolume(): number;
        getDistanceSq(pos: BlockPos_): number;
        indicateDamage($$0: number, $$1: number): void;
        localvar$nbm000$things$waxGlandWater(j: number): number;
        canBeSeenByAnyone(): boolean;
        emf$getTypeString(): string;
        isFullyFrozen(): boolean;
        litematica_setWorld(arg0: Internal.Level_): void;
        isInWall(): boolean;
        getAllSlots(): Internal.Iterable<Internal.ItemStack>;
        handler$bfg003$artifacts$tick(ci: Internal.CallbackInfo_): void;
        remove($$0: Internal.Entity$RemovalReason_): void;
        getScale(): number;
        isSuppressingSlidingDownLadder(): boolean;
        getBlockZ(): number;
        handler$egi000$collective$LivingEntity_die(damageSource: DamageSource_, ci: Internal.CallbackInfo_): void;
        dampensVibrations(): boolean;
        hasAttached(type: Internal.AttachmentType_<any>): boolean;
        isSilent(): boolean;
        setUseItem(arg0: Internal.ItemStack_): void;
        "playSound(net.minecraft.sounds.SoundEvent)"(id: Internal.SoundEvent_): void;
        getPitch(): number;
        getPathfindingMalus($$0: Internal.BlockPathTypes_): number;
        modify$nbm000$things$waxGlandLava(speed: number): number;
        getRandom(): Internal.RandomSource;
        canReplaceEqualItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        rotate($$0: Internal.Rotation_): number;
        handler$hcn000$hexcasting$onThunderHit(entityType: Internal.EntityType_<any>, bl: boolean, cir: Internal.CallbackInfoReturnable_<any>): void;
        getPassengersAndSelf(): Internal.Stream<any>;
        handler$leb000$puzzleslib$causeFallDamage$0(distance: number, damageMultiplier: number, damageSource: DamageSource_, callback: Internal.CallbackInfoReturnable_<any>): void;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        "getAttributeBaseValue(net.minecraft.core.Holder)"($$0: Internal.Holder_<Internal.Attribute>): number;
        method_5652($$0: Internal.CompoundTag_): void;
        clearRestriction(): void;
        redirect$jgg000$moonlight$fixSpawnAnimX(instance: Internal.Mob_, v: number): number;
        getOriginalFoodStack(): Internal.ItemStack;
        getAge(): number;
        rayTrace(): Internal.RayTraceResultJS;
        alwaysAccepts(): boolean;
        "isHolding(java.util.function.Predicate)"($$0: Internal.Predicate_<Internal.ItemStack>): boolean;
        getNoActionTime(): number;
        isVisuallyCrawling(): boolean;
        isAggressive(): boolean;
        setYya($$0: number): void;
        setDropChance($$0: Internal.EquipmentSlot_, $$1: number): void;
        handler$ieb000$lambdynlights$onRemove(ci: Internal.CallbackInfo_): void;
        "broadcastBreakEvent(net.minecraft.world.InteractionHand)"($$0: Internal.InteractionHand_): void;
        port_lib$setRemovalReason(arg0: Internal.Entity$RemovalReason_): void;
        teleportRelative($$0: number, $$1: number, $$2: number): void;
        isFood($$0: Internal.ItemStack_): boolean;
        setBaby($$0: boolean): void;
        getLastHurtByMob(): Internal.LivingEntity;
        pehkui_setScaleCache(scaleCache: Internal.ScaleData_[]): void;
        isInWaterOrBubble(): boolean;
        botania_setLoveCause(arg0: Internal.UUID_): void;
        getPortalCooldown(): number;
        getItem(): Internal.ItemStack;
        causeFallDamage($$0: number, $$1: number, $$2: DamageSource_): boolean;
        getDynamicLightChunksToRebuild(forced: boolean): Internal.LongSet;
        releaseUsingItem(): void;
        bw_getNextAirOnLand(arg0: number): number;
        getPosition($$0: number): Vec3d;
        removeFreeWill(): void;
        handler$leb000$puzzleslib$removeAllEffects(callback: Internal.CallbackInfoReturnable_<any>): void;
        removeWhenFarAway($$0: number): boolean;
        wait(arg0: number): void;
        isIgnoringBlockTriggers(): boolean;
        setRecordPlayingNearby($$0: BlockPos_, $$1: boolean): void;
        etf$getItemsEquipped(): Internal.Iterable<any>;
        getHandHoldingItemAngle($$0: Internal.Item_): Vec3d;
        hasItemInSlot($$0: Internal.EquipmentSlot_): boolean;
        distanceToSqr($$0: Vec3d_): number;
        syncComponent(key: Internal.ComponentKey_<any>): void;
        modifyAttached<A>(type: Internal.AttachmentType_<A>, modifier: Internal.UnaryOperator_<A>): A;
        isSteppingCarefully(): boolean;
        handler$zno000$apoli$doSpiderClimbing(info: Internal.CallbackInfoReturnable_<any>): void;
        "spawnAtLocation(net.minecraft.world.item.ItemStack,float)"($$0: Internal.ItemStack_, $$1: number): Internal.ItemEntity;
        getBlockX(): number;
        /**
         * @deprecated
        */
        getLightLevelDependentMagicValue(): number;
        isFallFlying(): boolean;
        getEncodeId(): string;
        puzzleslib$getSpawnType(): Internal.MobSpawnType;
        bettertrims$setAvoidedDamage(avoidDamage: boolean): void;
        getY($$0: number): number;
        emf$prevPitch(): number;
        getMaxHeadXRot(): number;
        getNbt(): Internal.CompoundTag;
        setInvisible($$0: boolean): void;
        etf$getArmorItems(): Internal.Iterable<any>;
        isSubmergedInLoosely(tag: Internal.TagKey_<any>): boolean;
        getEffect($$0: Internal.MobEffect_): Internal.MobEffectInstance;
        setTotalMovementSpeedMultiplier(speed: number): void;
        getDynamicLightY(): number;
        setHealth($$0: number): void;
        attack($$0: DamageSource_, $$1: number): boolean;
        onInsideBubbleColumn($$0: boolean): void;
        handler$cfa000$betterend$be_hurt(source: DamageSource_, amount: number, info: Internal.CallbackInfoReturnable_<any>): void;
        getEyePosition(): Vec3d;
        getEyeHeight(): number;
        setDiscardFriction($$0: boolean): void;
        hasPassenger($$0: Internal.Predicate_<Internal.Entity>): boolean;
        bettertridents$getLastDamageSource(): DamageSource;
        getYaw(): number;
        swing($$0: Internal.InteractionHand_, $$1: boolean): void;
        getUsedItemHand(): Internal.InteractionHand;
        setDefaultMovementSpeed(speed: number): void;
        canAttackType($$0: Internal.EntityType_<any>): boolean;
        hex$setLastDamageStamp(arg0: number): void;
        canEntityBeSeen(entity: Internal.LivingEntity_): boolean;
        modifyExpressionValue$zhf000$additionalentityattributes$additionalEntityAttributes$knockDownwards(original: number): number;
        modify$bpk000$bclib$be_travel(moveDelta: Vec3d_): Vec3d;
        setCustomNameVisible($$0: boolean): void;
        isAlliedTo($$0: Internal.Team_): boolean;
        getAttachedOrCreate<A>(type: Internal.AttachmentType_<A>): A;
        canFireProjectileWeapon($$0: Internal.ProjectileWeaponItem_): boolean;
        getControllingPassenger(): Internal.LivingEntity;
        bw_getNextAirUnderwater(arg0: number): number;
        getScriptType(): Internal.ScriptType;
        handler$leb000$puzzleslib$releaseUsingItem(callback: Internal.CallbackInfo_): void;
        handler$cbm000$besmirchment$handleStatus(status: number, ci: Internal.CallbackInfo_): void;
        port_lib$getDeathSound(): Internal.SoundEvent;
        shouldDiscardFriction(): boolean;
        startRiding($$0: Internal.Entity_): boolean;
        saveWithoutId($$0: Internal.CompoundTag_): Internal.CompoundTag;
        getForward(): Vec3d;
        setFeetArmorItem(item: Internal.ItemStack_): void;
        getId(): number;
        pehkui_isFirstUpdate(): boolean;
        canBeHitByProjectile(): boolean;
        getRecipientsForComponentSync(): Internal.Iterable<any>;
        handler$zcl000$porting_lib_base$port_lib$onUsingTick(ci: Internal.CallbackInfo_): void;
        getEyeY(): number;
        handler$ham000$gobber2$gobberClimbing(cir: Internal.CallbackInfoReturnable_<any>): void;
        skipDropExperience(): void;
        fabric_readAttachmentsFromNbt(nbt: Internal.CompoundTag_): void;
        localvar$leb000$puzzleslib$getVisibilityPercent(value: number, lookingEntity: Internal.Entity_): number;
        getBoundingBox(): Internal.AABB;
        isInWaterOrRain(): boolean;
        handler$leb000$puzzleslib$die$1(damageSource: DamageSource_, callback: Internal.CallbackInfo_): void;
        setItemSlot($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_): void;
        equals($$0: any): boolean;
        getViewYRot($$0: number): number;
        fabric_setCustomTeleportTarget(teleportTarget: Internal.PortalInfo_): void;
        dismountsUnderwater(): boolean;
        isAffectedByPotions(): boolean;
        playerTouch($$0: Internal.Player_): void;
        addTag($$0: string): boolean;
        getEyeHeight($$0: Internal.Pose_): number;
        getAddEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>;
        callIsBeingRainedOn(): boolean;
        static getEquipmentForSlot($$0: Internal.EquipmentSlot_, $$1: number): Internal.Item;
        isWithinRestriction($$0: BlockPos_): boolean;
        getTeam(): Internal.Team;
        static of(entity: Internal.LivingEntity_): Internal.EntityProperties;
        setTicksFrozen($$0: number): void;
        getUseItem(): Internal.ItemStack;
        getMyRidingOffset(): number;
        handler$hal000$gobber2$gobberCanBreatheInWater(cir: Internal.CallbackInfoReturnable_<any>): void;
        dismountTo($$0: number, $$1: number, $$2: number): void;
        etf$getEntityKey(): string;
        etf$getPose(): Internal.Pose;
        hasCustomName(): boolean;
        getSwimAmount($$0: number): number;
        isLiving(): boolean;
        getX(): number;
        isVehicle(): boolean;
        static transfer(original: Internal.AttachmentTarget_, target: Internal.AttachmentTarget_, isDeath: boolean): void;
        bettertrims$didAvoidDamage(): boolean;
        resetDynamicLight(): void;
        handler$han000$gobber2$gobberSetTarget(target: Internal.LivingEntity_, ci: Internal.CallbackInfo_): void;
        handler$kpc001$porting_lib_entity$onJump(ci: Internal.CallbackInfo_): void;
        spawnAtLocation($$0: Internal.ItemStack_): Internal.ItemEntity;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        handler$zcl000$porting_lib_base$port_lib$canBeAffected(effect: Internal.MobEffectInstance_, cir: Internal.CallbackInfoReturnable_<any>): void;
        thunderHit($$0: Internal.ServerLevel_, $$1: Internal.LightningBolt_): void;
        setIsInPowderSnow($$0: boolean): void;
        etf$distanceTo(entity: Internal.Entity_): number;
        doEnchantDamageEffects($$0: Internal.LivingEntity_, $$1: Internal.Entity_): void;
        setCustomName($$0: net.minecraft.network.chat.Component_): void;
        lambdynlights$scheduleTrackedChunksRebuild(renderer: Internal.LevelRenderer_): void;
        handler$hak000$gobber2$gobberBaseTick(ci: Internal.CallbackInfo_): void;
        getTeamId(): string;
        setStingerCount($$0: number): void;
        getMaxHeadYRot(): number;
        isCustomNameVisible(): boolean;
        isSupportedBy($$0: BlockPos_): boolean;
        getPistonPushReaction(): Internal.PushReaction;
        lookAt($$0: Internal.EntityAnchorArgument$Anchor_, $$1: Vec3d_): void;
        handler$kpc000$porting_lib_entity$port_lib$cancelFall(fallDistance: number, multiplier: number, source: DamageSource_, cir: Internal.CallbackInfoReturnable_<any>): void;
        hurtCurrentlyUsedShield($$0: number): void;
        getLootTableSeed(): number;
        collide($$0: Vec3d_): Vec3d;
        getMotionX(): number;
        "onSyncedDataUpdated(java.util.List)"($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        canBeLeashed($$0: Internal.Player_): boolean;
        hasIndirectPassenger($$0: Internal.Entity_): boolean;
        gear_core_setActiveSets(sets: Internal.HashMap_<any, any>): void;
        getEntityData(): Internal.SynchedEntityData;
        bookshelf$getFallDamageSound(arg0: number): Internal.SoundEvent;
        handleInsidePortal($$0: BlockPos_): void;
        getPotionEffects(): Internal.EntityPotionEffectsJS;
        getLastHurtByPlayerTime(): number;
        absMoveTo($$0: number, $$1: number, $$2: number): void;
        handler$cfa000$betterend$be_canBeAffected(mobEffectInstance: Internal.MobEffectInstance_, info: Internal.CallbackInfoReturnable_<any>): void;
        isOnRails(): boolean;
        getAttachedOrThrow<A>(type: Internal.AttachmentType_<A>): A;
        getStingerCount(): number;
        markFusionRecomputeModels(): void;
        getFallSounds(): Internal.LivingEntity$Fallsounds;
        getAttributeTotalValue(attribute: Internal.Attribute_): number;
        getDimensionChangingDelay(): number;
        handler$cbi000$besmirchment$getScoreboardTeam(cir: Internal.CallbackInfoReturnable_<any>): void;
        getLastDynamicLuminance(): number;
        setYaw($$0: number): void;
        getPickRadius(): number;
        isPathFinding(): boolean;
        supp$getSlimedTicks(): number;
        isRemoved(): boolean;
        emf$isSneaking(): boolean;
        teleportToWithTicket($$0: number, $$1: number, $$2: number): void;
        spawnAnim(): void;
        getJumpBoostPower(): number;
        fillCrashReportCategory($$0: Internal.CrashReportCategory_): void;
        self(): Internal.Entity;
        refreshDimensions(): void;
        pehkui_writeScaleNbt(nbt: Internal.CompoundTag_): Internal.CompoundTag;
        bookshelf$getAmbientSound(): Internal.SoundEvent;
        "isHolding(net.minecraft.world.item.Item)"($$0: Internal.Item_): boolean;
        "getAttributeValue(net.minecraft.world.entity.ai.attributes.Attribute)"($$0: Internal.Attribute_): number;
        "spawnAtLocation(net.minecraft.world.level.ItemLike)"($$0: Internal.ItemLike_): Internal.ItemEntity;
        setShiftKeyDown($$0: boolean): void;
        getEyePosition($$0: number): Vec3d;
        getPassengers(): Internal.EntityArrayList;
        handler$ldh000$puzzleslib$spawnAtLocation(stack: Internal.ItemStack_, offsetY: number, callback: Internal.CallbackInfoReturnable_<any>, itemEntity: Internal.ItemEntity_): void;
        getZ(): number;
        bettertrims$applyCelestialToAttackCooldown(original: number): number;
        teleportTo($$0: number, $$1: number, $$2: number): void;
        handler$zbk000$porting_lib_base$port_lib$spawnSprintParticle(ci: Internal.CallbackInfo_, pos: BlockPos_, state: Internal.BlockState_): void;
        getAttributeBaseValue($$0: Internal.Holder_<Internal.Attribute>): number;
        getServer(): Internal.MinecraftServer;
        getExperienceReward(): number;
        getFirstPassenger(): Internal.Entity;
        heal($$0: number): void;
        handler$leb01a$puzzleslib$tick(callback: Internal.CallbackInfo_): void;
        setLastHurtMob($$0: Internal.Entity_): void;
        setLastHurtByMob($$0: Internal.LivingEntity_): void;
        interact($$0: Internal.Player_, $$1: Internal.InteractionHand_): Internal.InteractionResult;
        getDismountLocationForPassenger($$0: Internal.LivingEntity_): Vec3d;
        checkSlowFallDistance(): void;
        getLeashingEntities(): Internal.Set<any>;
        canStandOnFluid($$0: Internal.FluidState_): boolean;
        setFabricBalmData(tag: Internal.CompoundTag_): void;
        touchingUnloadedChunk(): boolean;
        modifyAttribute(attribute: Internal.Attribute_, identifier: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getLookAngle(): Vec3d;
        modifyReturnValue$zhf000$additionalentityattributes$additionalEntityAttributes$modifyJumpVelocity(original: number): number;
        getAmbientSoundInterval(): number;
        emf$isOnFire(): boolean;
        setArrowCount($$0: number): void;
        getMotionZ(): number;
        isPersistenceRequired(): boolean;
        isInvisible(): boolean;
        is($$0: Internal.Entity_): boolean;
        getBedOrientation(): Internal.Direction;
        ejectPassengers(): void;
        removeEffect($$0: Internal.MobEffect_): boolean;
        updateDynamicLightPreviousCoordinates(): void;
        getProfile(): Internal.GameProfile;
        setInLove($$0: Internal.Player_): void;
        isDeadOrDying(): boolean;
        setHeadArmorItem(item: Internal.ItemStack_): void;
        static setViewScale($$0: number): void;
        emf$isAlive(): boolean;
        take($$0: Internal.Entity_, $$1: number): void;
        setLevelCallback($$0: Internal.EntityInLevelCallback_): void;
        getLookControl(): Internal.LookControl;
        redirect$joh000$origins$method_26317Proxy(entity: Internal.LivingEntity_, d: number, bl: boolean, vec3d: Vec3d_): Vec3d;
        playSound($$0: Internal.SoundEvent_, $$1: number, $$2: number): void;
        canAttack($$0: Internal.LivingEntity_): boolean;
        static getSpeedUpSecondsWhenFeeding($$0: number): number;
        getOffHandItem(): Internal.ItemStack;
        startSeenByPlayer($$0: Internal.ServerPlayer_): void;
        isOnScoreboardTeam(teamId: string): boolean;
        startUsingItem($$0: Internal.InteractionHand_): void;
        invokePlayEquipmentBreakEffects(arg0: Internal.ItemStack_): void;
        localvar$bbb000$architectury$modifyLevelCallback_setLevelCallback(callback: Internal.EntityInLevelCallback_): Internal.EntityInLevelCallback;
        position(): Vec3d;
        setTimeout(): void;
        static getEquipmentSlotForItem($$0: Internal.ItemStack_): Internal.EquipmentSlot;
        getEquipment(slot: Internal.EquipmentSlot_): Internal.ItemStack;
        displayFireAnimation(): boolean;
        isOutOfCamera(): boolean;
        getRopeHoldPosition($$0: number): Vec3d;
        copyPosition($$0: Internal.Entity_): void;
        "hasPassenger(net.minecraft.world.entity.Entity)"($$0: Internal.Entity_): boolean;
        extraalchemy_spawnParticles(arg0: Internal.ItemStack_, arg1: number): void;
        etf$canBeBright(): boolean;
        isCrouching(): boolean;
        "getAttributeBaseValue(net.minecraft.world.entity.ai.attributes.Attribute)"($$0: Internal.Attribute_): number;
        onLeaveCombat(): void;
        wrapOperation$bgd000$artifacts$travel(block: Internal.Block_, original: Internal.Operation_<any>): number;
        setY(y: number): void;
        getAttributeValue($$0: Internal.Attribute_): number;
        getFeetBlockState(): Internal.BlockState;
        archon$isOwner(player: Internal.Player_): boolean;
        isWithinRestriction(): boolean;
        getChangeListener(): Internal.EntityInLevelCallback;
        positionRider($$0: Internal.Entity_): void;
        baseTick(): void;
        broadcastToPlayer($$0: Internal.ServerPlayer_): boolean;
        setSharedFlag($$0: number, $$1: boolean): void;
        getSleepingPos(): Optional<BlockPos>;
        damageHeldItem(): void;
        getCustomName(): net.minecraft.network.chat.Component;
        getClass(): typeof any;
        isVisuallySwimming(): boolean;
        getMaxAirSupply(): number;
        handler$zcl000$porting_lib_base$port_lib$addEffect(newEffect: Internal.MobEffectInstance_, source: Internal.Entity_, cir: Internal.CallbackInfoReturnable_<any>, oldEffect: Internal.MobEffectInstance_): void;
        setItemInHand($$0: Internal.InteractionHand_, $$1: Internal.ItemStack_): void;
        dynamicLightTick(): void;
        setMaxHealth(hp: number): void;
        getFacing(): Internal.Direction;
        emf$isWet(): boolean;
        isPassengerOfSameVehicle($$0: Internal.Entity_): boolean;
        getBoundingBoxForCulling(): Internal.AABB;
        setAge($$0: number): void;
        getTarget(): Internal.LivingEntity;
        static collideBoundingBox(entity: Internal.Entity_, movement: Vec3d_, entityBoundingBox: Internal.AABB_, world: Internal.Level_, collisions: Internal.List_<any>): Vec3d;
        fzzy_core_getModifierContainer(): Internal.ModifierContainer;
        restrictTo($$0: BlockPos_, $$1: number): void;
        isInLove(): boolean;
        trackingPosition(): Vec3d;
        getNameTagOffsetY(): number;
        isInvulnerable(): boolean;
        isInLava(): boolean;
        isInWater(): boolean;
        awardKillScore($$0: Internal.Entity_, $$1: number, $$2: DamageSource_): void;
        finalizeSpawn($$0: Internal.ServerLevelAccessor_, $$1: Internal.DifficultyInstance_, $$2: Internal.MobSpawnType_, $$3: Internal.SpawnGroupData_, $$4: Internal.CompoundTag_): Internal.SpawnGroupData;
        localvar$leb000$puzzleslib$knockback$3(ratioZ: number): number;
        unsetRemoved(): void;
        pehkui_getScaleCache(): Internal.ScaleData[];
        swing($$0: Internal.InteractionHand_): void;
        hasEffect($$0: Internal.MobEffect_): boolean;
        getHeldItem(hand: Internal.InteractionHand_): Internal.ItemStack;
        setFusionModel(layerIndex: number, model: Internal.Triple_<any, any, any>): void;
        getRootVehicle(): Internal.Entity;
        onPathfindingDone(): void;
        save($$0: Internal.CompoundTag_): boolean;
        archon$setLifetime(seconds: number): void;
        modify$zhf000$additionalentityattributes$additionalEntityAttributes$waterSpeed(original: number): number;
        getLocalBoundsForPose($$0: Internal.Pose_): Internal.AABB;
        isNoGravity(): boolean;
        dodge(chance: number): boolean;
        onItemPickup($$0: Internal.ItemEntity_): void;
        hex$setLastDamageSource(arg0: DamageSource_): void;
        emf$getY(): number;
        handler$kom000$porting_lib_entity$port_lib$entityInit(entityType: Internal.EntityType_<any>, world: Internal.Level_, ci: Internal.CallbackInfo_): void;
        resetLove(): void;
        bookshelf$createHoverEvent(): Internal.HoverEvent;
        updateSwimming(): void;
        isHolding($$0: Internal.Predicate_<Internal.ItemStack>): boolean;
        getSpeed(): number;
        abstract getCachedFeetBlockState(): Internal.BlockState;
        shouldInformAdmins(): boolean;
        rideTick(): void;
        port_lib$onEffectRemoved(arg0: Internal.MobEffectInstance_): void;
        handler$zll000$amethyst_imbuement$onAttackWhilstStunnedNoTarget(hand: Internal.InteractionHand_, ci: Internal.CallbackInfo_): void;
        wait(): void;
        getUuid(): Internal.UUID;
        setOffHandItem(item: Internal.ItemStack_): void;
        spawn(): void;
        setNoAi($$0: boolean): void;
        teleportTo($$0: Internal.ServerLevel_, $$1: number, $$2: number, $$3: number, $$4: Internal.Set_<Internal.RelativeMovement>, $$5: number, $$6: number): boolean;
        etf$getCustomName(): net.minecraft.network.chat.Component;
        addHorns(): void;
        fabric_writeAttachmentsToNbt(nbt: Internal.CompoundTag_): void;
        shouldShowName(): boolean;
        getArmorSlots(): Internal.Iterable<Internal.ItemStack>;
        canPickUpLoot(): boolean;
        kill(): void;
        onEnterCombat(): void;
        updateNavigationRegistration(): void;
        animateHurt($$0: number): void;
        syncComponent(key: Internal.ComponentKey_<any>, packetWriter: Internal.ComponentPacketWriter_): void;
        handler$kom000$porting_lib_entity$port_lib$onEntityRemove(reason: Internal.Entity$RemovalReason_, ci: Internal.CallbackInfo_): void;
        static resetForwardDirectionOfRelativePortalPosition($$0: Vec3d_): Vec3d;
        callGetEyeHeight(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        hasRestriction(): boolean;
        getHeadArmorItem(): Internal.ItemStack;
        deserializeNBT(arg0: Internal.Tag_): void;
        getCurrentModifyFoodPowers(): Internal.List<any>;
        getBbWidth(): number;
        splitIntoDynamicLightEntries(): Internal.Stream<Internal.SpatialLookupEntry>;
        addDeltaMovement($$0: Vec3d_): void;
        pehkui_setOnGround(onGround: boolean): void;
        localvar$leb000$puzzleslib$knockback$1(strength: number): number;
        bettertrims$addLateAttributes(adder: Internal.Consumer_<any>): void;
        handler$lef000$puzzleslib$readAdditionalSaveData(compound: Internal.CompoundTag_, callback: Internal.CallbackInfo_): void;
        sendLeashState(): void;
        "getName()"(): net.minecraft.network.chat.Component;
        mirror($$0: Internal.Mirror_): number;
        static port_lib$collideWithShapes(vec3: Vec3d_, aABB: Internal.AABB_, list: Internal.List_<Internal.VoxelShape>): Vec3d;
        knockback($$0: number, $$1: number, $$2: number): void;
        getTicksRequiredToFreeze(): number;
        getVisibilityPercent($$0: Internal.Entity_): number;
        getMaxSpawnClusterSize(): number;
        localvar$kpc000$porting_lib_entity$port_lib$modifyDistance(fallDistance: number): number;
        artifacts$getPocketPistonLength(): number;
        emf$prevZ(): number;
        getUsername(): string;
        getInLoveTime(): number;
        move($$0: Internal.MoverType_, $$1: Vec3d_): void;
        lithiumOnBlockCacheSet(newState: Internal.BlockState_): void;
        isPickable(): boolean;
        setYHeadRot($$0: number): void;
        isScreamingGoat(): boolean;
        setJumping($$0: boolean): void;
        getCustomData(): Internal.CompoundTag;
        handler$zno000$apoli$getGroup(info: Internal.CallbackInfoReturnable_<any>): void;
        getPickResult(): Internal.ItemStack;
        "getMainHandItem()"(): Internal.ItemStack;
        getAbsorptionAmount(): number;
        getRandomY(): number;
        onEffectRemoved($$0: Internal.MobEffectInstance_): void;
        getDisplayName(): net.minecraft.network.chat.Component;
        static "tickEntity(net.minecraft.world.entity.Entity)"(entity: Internal.Entity_): void;
        getMobType(): Internal.MobType;
        travel($$0: Vec3d_): void;
        getItemInHand($$0: Internal.InteractionHand_): Internal.ItemStack;
        localvar$leb000$puzzleslib$hurt$0(amount: number, source: DamageSource_): number;
        getDynamicLightPrevX(): number;
        shouldBeSaved(): boolean;
        fabric_hasPersistentAttachments(): boolean;
        method_5749($$0: Internal.CompoundTag_): void;
        hurtHelmet($$0: DamageSource_, $$1: number): void;
        getRammingXHeadRot(): number;
        removeTag($$0: string): boolean;
        isHoldingInAnyHand(i: Internal.Ingredient_): boolean;
        getFluidHeight($$0: Internal.TagKey_<Internal.Fluid>): number;
        canSpawnSoulSpeedParticle(): boolean;
        notifyAll(): void;
        aiStep(): void;
        handler$leb000$puzzleslib$removeEffect(effect: Internal.MobEffect_, callback: Internal.CallbackInfoReturnable_<any>): void;
        getPassengersRidingOffset(): number;
        setAttributeBaseValue(attribute: Internal.Attribute_, value: number): void;
        distanceToEntitySqr($$0: Internal.Entity_): number;
        isFrame(): boolean;
        broadcastBreakEvent($$0: Internal.InteractionHand_): void;
        setLegsArmorItem(item: Internal.ItemStack_): void;
        localvar$leb000$puzzleslib$causeFallDamage$1(fallDistance: number): number;
        discard(): void;
        "handler$mhe000$step-height-entity-attribute$getStepHeight"(cir: Internal.CallbackInfoReturnable_<any>): void;
        sendSystemMessage($$0: net.minecraft.network.chat.Component_): void;
        acceptsSuccess(): boolean;
        static tickEntity(entity: Internal.LivingEntity_): void;
        setNoGravity($$0: boolean): void;
        getUseItemRemainingTicks(): number;
        gear_core_getActiveSets(): Internal.HashMap<any, any>;
        getIndirectPassengers(): Internal.Iterable<any>;
        attackable(): boolean;
        createCommandSourceStack(): Internal.CommandSourceStack;
        getNavigation(): Internal.PathNavigation;
        isControlledByLocalInstance(): boolean;
        isMonster(): boolean;
        pehkui_setShouldSyncScales(sync: boolean): void;
        handler$cbm000$besmirchment$canTarget(type: Internal.EntityType_<any>, cir: Internal.CallbackInfoReturnable_<any>): void;
        getLoveCause(): Internal.ServerPlayer;
        getLastClimbablePos(): Optional<BlockPos>;
        getEatingSound($$0: Internal.ItemStack_): Internal.SoundEvent;
        setLastDynamicLuminance(luminance: number): void;
        getPerceivedTargetDistanceSquareForMeleeAttack($$0: Internal.LivingEntity_): number;
        setId($$0: number): void;
        onSyncedDataUpdated($$0: Internal.List_<Internal.SynchedEntityData$DataValue<any>>): void;
        getHorizontalFacing(): Internal.Direction;
        getType(): string;
        static checkAnimalSpawnRules($$0: Internal.EntityType_<Internal.Animal>, $$1: Internal.LevelAccessor_, $$2: Internal.MobSpawnType_, $$3: BlockPos_, $$4: Internal.RandomSource_): boolean;
        isDamageSourceBlocked($$0: DamageSource_): boolean;
        getLightProbePosition($$0: number): Vec3d;
        getActiveEffectsMap(): Internal.Map<Internal.MobEffect, Internal.MobEffectInstance>;
        wrapOperation$mac000$smarterfarmers$smarterFarmers$overrideMobGriefing(instance: Internal.GameRules_, key: Internal.GameRules$Key_<any>, original: Internal.Operation_<any>): boolean;
        emf$prevX(): number;
        onEquipItem($$0: Internal.EquipmentSlot_, $$1: Internal.ItemStack_, $$2: Internal.ItemStack_): void;
        checkDespawn(): void;
        pehkui_shouldSyncScales(): boolean;
        getWalkTargetValue($$0: BlockPos_, $$1: Internal.LevelReader_): number;
        lookAt($$0: Internal.Entity_, $$1: number, $$2: number): void;
        setHeldItem(hand: Internal.InteractionHand_, item: Internal.ItemStack_): void;
        port_lib$maybeDisableShield(arg0: Internal.Player_, arg1: Internal.ItemStack_, arg2: Internal.ItemStack_): void;
        equipItemIfPossible($$0: Internal.ItemStack_): Internal.ItemStack;
        onSyncedDataUpdated($$0: Internal.EntityDataAccessor_<any>): void;
        lerpHeadTo($$0: number, $$1: number): void;
        canDisableShield(): boolean;
        setMotionX(x: number): void;
        getHandSlots(): Internal.Iterable<Internal.ItemStack>;
        distanceToEntity($$0: Internal.Entity_): number;
        bookshelf$getDeathSound(): Internal.SoundEvent;
        wait(arg0: number, arg1: number): void;
        getTeamColor(): number;
        lithiumSetClimbingMobCachingSectionUpdateBehavior(listenForCachedBlockChanges: boolean): void;
        setNbt(nbt: Internal.CompoundTag_): void;
        lambdynlights$getTrackedLitChunkPos(): Internal.LongSet;
        checkSpawnObstruction($$0: Internal.LevelReader_): boolean;
        getRecallPosition(): Internal.DimensionalPosition;
        extinguish(): void;
        setDynamicLightEnabled(enabled: boolean): void;
        getRestrictRadius(): number;
        moveTo($$0: Vec3d_): void;
        isColliding($$0: BlockPos_, $$1: Internal.BlockState_): boolean;
        "swing(net.minecraft.world.InteractionHand)"($$0: Internal.InteractionHand_): void;
        lambdynlights$updateDynamicLight(renderer: Internal.LevelRenderer_): boolean;
        getRegisteredNavigation(): Internal.PathNavigation;
        bettertrims$isWearing(effect: Internal.TrimEffect_): boolean;
        static port_lib$collideWithShapes$porting_lib_accessors_$md$424943$0(arg0: Vec3d_, arg1: Internal.AABB_, arg2: Internal.List_<any>): Vec3d;
        isForcedVisible(): boolean;
        isInvertedHealAndHarm(): boolean;
        handler$jon000$origins$doWaterBreathing(info: Internal.CallbackInfoReturnable_<any>): void;
        canHoldItem($$0: Internal.ItemStack_): boolean;
        killedEntity($$0: Internal.ServerLevel_, $$1: Internal.LivingEntity_): boolean;
        getAttachedOrElse<A>(type: Internal.AttachmentType_<A>, defaultValue: A): A;
        isFreezing(): boolean;
        runCommand(command: string): number;
        hex$getDeathSound(): Internal.SoundEvent;
        setGuaranteedDrop($$0: Internal.EquipmentSlot_): void;
        setSharedFlagOnFire($$0: boolean): void;
        set defaultMovementSpeedMultiplier(speed: number)
        get suppressingBounce(): boolean
        set target($$0: Internal.LivingEntity_)
        set culled(value: boolean)
        get onFire(): boolean
        get positionCodec(): Internal.VecDeltaCodec
        set maxUpStep($$0: number)
        get fallFlyingTicks(): number
        set xxa($$0: number)
        set delayedLeashHolderId($$0: number)
        get shiftKeyDown(): boolean
        set UUID($$0: Internal.UUID_)
        set motionZ(z: number)
        get blockY(): number
        get isInsideStructureTracker(): Internal.IsInsideStructureTracker
        set playerHitTimer(arg0: number)
        get spectator(): boolean
        set mainHandItem(item: Internal.ItemStack_)
        get persistentData(): Internal.CompoundTag
        get health(): number
        get maxHealth(): number
        get registeredToWorld(): boolean
        set aggressive($$0: boolean)
        set removed($$0: Internal.Entity$RemovalReason_)
        get inWaterRainOrBubble(): boolean
        get removalReason(): Internal.Entity$RemovalReason
        set boundingBox($$0: Internal.AABB_)
        get ambientCreature(): boolean
        set zza($$0: number)
        get block(): Internal.BlockContainerJS
        set screamingGoat($$0: boolean)
        get name(): net.minecraft.network.chat.Component
        get controlledVehicle(): Internal.Entity
        get armorValue(): number
        get killCredit(): Internal.LivingEntity
        get componentContainer(): Internal.ComponentContainer
        get dynamicLightPrevZ(): number
        set outOfCamera(value: boolean)
        get autoSpinAttack(): boolean
        get remainingFireTicks(): number
        get maxFallDistance(): number
        get ticksFrozen(): number
        get dynamicLightZ(): number
        get voicePitch(): number
        set statusMessage(message: net.minecraft.network.chat.Component_)
        set sleepingPos($$0: BlockPos_)
        get descending(): boolean
        get headRotSpeed(): number
        get lastHurtByPlayer(): Internal.Player
        get YHeadRot(): number
        set absorptionAmount($$0: number)
        set recallData(pos: Internal.DimensionalPosition_)
        set deltaMovement($$0: Vec3d_)
        get baby(): boolean
        get culled(): boolean
        get glowing(): boolean
        get leashedByEntities(): Internal.Set<any>
        get leashOffset(): Vec3d
        get attackable(): boolean
        get underWater(): boolean
        get leashHolder(): Internal.Entity
        get sensing(): Internal.Sensing
        get legsArmorItem(): Internal.ItemStack
        get luminance(): number
        get selfAndPassengers(): Internal.Stream<any>
        get deltaMovement(): Vec3d
        get dynamicLightX(): number
        set secondsOnFire($$0: number)
        get "displayName()"(): net.minecraft.network.chat.Component
        get lootTable(): ResourceLocation
        get ticksUsingItem(): number
        get arrowCount(): number
        get moveControl(): Internal.MoveControl
        get defaultMovementSpeed(): number
        get peacefulCreature(): boolean
        set onGround($$0: boolean)
        get lastHurtByMobTimestamp(): number
        get vehicle(): Internal.Entity
        get effectiveAi(): boolean
        get stringUuid(): string
        set swimming($$0: boolean)
        get mainArm(): Internal.HumanoidArm
        get rotationVector(): Internal.Vec2
        get hurtDir(): number
        get sprinting(): boolean
        get motionY(): number
        get offhandItem(): Internal.ItemStack
        set luminance(luminance: number)
        set lootTable(arg0: ResourceLocation_)
        get lastHurtMob(): Internal.LivingEntity
        get lastDamageSource(): DamageSource
        get soundSource(): Internal.SoundSource
        set noActionTime($$0: number)
        set movementSpeedAddition(speed: number)
        get pose(): Internal.Pose
        get restrictCenter(): BlockPos
        get leftHanded(): boolean
        set z(z: number)
        get y(): number
        set currentModifyFoodPowers(powers: Internal.List_<any>)
        get blocking(): boolean
        get pushedByFluid(): boolean
        set originalFoodStack(original: Internal.ItemStack_)
        get armorCoverPercentage(): number
        get airSupply(): number
        get player(): boolean
        get animal(): boolean
        get motionDirection(): Internal.Direction
        get fabricBalmData(): Internal.CompoundTag
        get commandSenderWorld(): Internal.Level
        get totalMovementSpeed(): number
        get moving(): boolean
        get attributes(): Internal.AttributeMap
        set inLoveTime($$0: number)
        get swimming(): boolean
        set sprinting($$0: boolean)
        get dynamicLightLevel(): Internal.Level
        set x(x: number)
        get portalWaitTime(): number
        get blockStateOn(): Internal.BlockState
        get fluidJumpThreshold(): number
        get cachedSouls(): number
        set airSupply($$0: number)
        get onPos(): BlockPos
        get undead(): boolean
        set useItemRemaining(arg0: number)
        get targetSelector(): Internal.GoalSelector
        set registeredToWorld(navigation: Internal.PathNavigation_)
        get sleeping(): boolean
        get dismountPoses(): Internal.ImmutableList<Internal.Pose>
        get lastHurtMobTimestamp(): number
        set remainingFireTicks($$0: number)
        /**
         * @deprecated
        */
        get onPosLegacy(): BlockPos
        set pos($$0: Vec3d_)
        set canPickUpLoot($$0: boolean)
        get mainHandItem(): Internal.ItemStack
        set silent($$0: boolean)
        set leftHanded($$0: boolean)
        get activeEffects(): Internal.Collection<Internal.MobEffectInstance>
        get onPortalCooldown(): boolean
        set pitch($$0: number)
        get usingItem(): boolean
        get alwaysTicking(): boolean
        set invulnerable($$0: boolean)
        get dynamicLightPrevY(): number
        set glowing($$0: boolean)
        get alive(): boolean
        get bbHeight(): number
        get tags(): Internal.Set<string>
        get lastAttacker(): Internal.LivingEntity
        get lastRollTicks(): number
        get goalSelector(): Internal.GoalSelector
        get percentFrozen(): number
        set portalCooldown($$0: number)
        set position(block: Internal.BlockContainerJS_)
        get leashed(): boolean
        set pose($$0: Internal.Pose_)
        get reachDistance(): number
        get entityType(): Internal.EntityType<any>
        get waterCreature(): boolean
        set lastHurtByPlayer($$0: Internal.Player_)
        get "server()"(): Internal.MinecraftServer
        get pushable(): boolean
        set YBodyRot($$0: number)
        set motionY(y: number)
        get dynamicLightEnabled(): boolean
        set chestArmorItem(item: Internal.ItemStack_)
        get passenger(): boolean
        get brain(): Internal.Brain<Internal.Goat>
        get sensitiveToWater(): boolean
        get jumpControl(): Internal.JumpControl
        get feetArmorItem(): Internal.ItemStack
        get viewScale(): number
        get visualRotationYInDegrees(): number
        set speed($$0: number)
        get discrete(): boolean
        get level(): Internal.Level
        get combatTracker(): Internal.CombatTracker
        get noAi(): boolean
        get chestArmorItem(): Internal.ItemStack
        get fullyFrozen(): boolean
        get inWall(): boolean
        get allSlots(): Internal.Iterable<Internal.ItemStack>
        get scale(): number
        get suppressingSlidingDownLadder(): boolean
        get blockZ(): number
        get silent(): boolean
        set useItem(arg0: Internal.ItemStack_)
        get pitch(): number
        get random(): Internal.RandomSource
        get passengersAndSelf(): Internal.Stream<any>
        get originalFoodStack(): Internal.ItemStack
        get age(): number
        get noActionTime(): number
        get visuallyCrawling(): boolean
        get aggressive(): boolean
        set yya($$0: number)
        set baby($$0: boolean)
        get lastHurtByMob(): Internal.LivingEntity
        get inWaterOrBubble(): boolean
        get portalCooldown(): number
        get item(): Internal.ItemStack
        get ignoringBlockTriggers(): boolean
        get steppingCarefully(): boolean
        get blockX(): number
        /**
         * @deprecated
        */
        get lightLevelDependentMagicValue(): number
        get fallFlying(): boolean
        get encodeId(): string
        get maxHeadXRot(): number
        get nbt(): Internal.CompoundTag
        set invisible($$0: boolean)
        set totalMovementSpeedMultiplier(speed: number)
        get dynamicLightY(): number
        set health($$0: number)
        get eyePosition(): Vec3d
        get eyeHeight(): number
        set discardFriction($$0: boolean)
        get yaw(): number
        get usedItemHand(): Internal.InteractionHand
        set defaultMovementSpeed(speed: number)
        set customNameVisible($$0: boolean)
        get controllingPassenger(): Internal.LivingEntity
        get scriptType(): Internal.ScriptType
        get forward(): Vec3d
        set feetArmorItem(item: Internal.ItemStack_)
        get id(): number
        get recipientsForComponentSync(): Internal.Iterable<any>
        get eyeY(): number
        get boundingBox(): Internal.AABB
        get inWaterOrRain(): boolean
        get affectedByPotions(): boolean
        get addEntityPacket(): Internal.Packet<Internal.ClientGamePacketListener>
        get team(): Internal.Team
        set ticksFrozen($$0: number)
        get useItem(): Internal.ItemStack
        get myRidingOffset(): number
        get living(): boolean
        get x(): number
        get vehicle(): boolean
        set isInPowderSnow($$0: boolean)
        set customName($$0: net.minecraft.network.chat.Component_)
        get teamId(): string
        set stingerCount($$0: number)
        get maxHeadYRot(): number
        get customNameVisible(): boolean
        get pistonPushReaction(): Internal.PushReaction
        get lootTableSeed(): number
        get motionX(): number
        get entityData(): Internal.SynchedEntityData
        get potionEffects(): Internal.EntityPotionEffectsJS
        get lastHurtByPlayerTime(): number
        get onRails(): boolean
        get stingerCount(): number
        get fallSounds(): Internal.LivingEntity$Fallsounds
        get dimensionChangingDelay(): number
        get lastDynamicLuminance(): number
        set yaw($$0: number)
        get pickRadius(): number
        get pathFinding(): boolean
        get removed(): boolean
        get jumpBoostPower(): number
        set shiftKeyDown($$0: boolean)
        get passengers(): Internal.EntityArrayList
        get z(): number
        get server(): Internal.MinecraftServer
        get experienceReward(): number
        get firstPassenger(): Internal.Entity
        set lastHurtMob($$0: Internal.Entity_)
        set lastHurtByMob($$0: Internal.LivingEntity_)
        get leashingEntities(): Internal.Set<any>
        set fabricBalmData(tag: Internal.CompoundTag_)
        get lookAngle(): Vec3d
        get ambientSoundInterval(): number
        set arrowCount($$0: number)
        get motionZ(): number
        get persistenceRequired(): boolean
        get invisible(): boolean
        get bedOrientation(): Internal.Direction
        get profile(): Internal.GameProfile
        set inLove($$0: Internal.Player_)
        get deadOrDying(): boolean
        set headArmorItem(item: Internal.ItemStack_)
        set viewScale($$0: number)
        set levelCallback($$0: Internal.EntityInLevelCallback_)
        get lookControl(): Internal.LookControl
        get offHandItem(): Internal.ItemStack
        get outOfCamera(): boolean
        get crouching(): boolean
        set y(y: number)
        get feetBlockState(): Internal.BlockState
        get withinRestriction(): boolean
        get changeListener(): Internal.EntityInLevelCallback
        get sleepingPos(): Optional<BlockPos>
        get customName(): net.minecraft.network.chat.Component
        get class(): typeof any
        get visuallySwimming(): boolean
        get maxAirSupply(): number
        set maxHealth(hp: number)
        get facing(): Internal.Direction
        get boundingBoxForCulling(): Internal.AABB
        set age($$0: number)
        get target(): Internal.LivingEntity
        get inLove(): boolean
        get nameTagOffsetY(): number
        get invulnerable(): boolean
        get inLava(): boolean
        get inWater(): boolean
        get rootVehicle(): Internal.Entity
        get noGravity(): boolean
        get speed(): number
        get cachedFeetBlockState(): Internal.BlockState
        get uuid(): Internal.UUID
        set offHandItem(item: Internal.ItemStack_)
        set noAi($$0: boolean)
        get armorSlots(): Internal.Iterable<Internal.ItemStack>
        get headArmorItem(): Internal.ItemStack
        get currentModifyFoodPowers(): Internal.List<any>
        get bbWidth(): number
        get "name()"(): net.minecraft.network.chat.Component
        get ticksRequiredToFreeze(): number
        get maxSpawnClusterSize(): number
        get username(): string
        get inLoveTime(): number
        get pickable(): boolean
        set YHeadRot($$0: number)
        get screamingGoat(): boolean
        set jumping($$0: boolean)
        get customData(): Internal.CompoundTag
        get pickResult(): Internal.ItemStack
        get "mainHandItem()"(): Internal.ItemStack
        get absorptionAmount(): number
        get randomY(): number
        get displayName(): net.minecraft.network.chat.Component
        get mobType(): Internal.MobType
        get dynamicLightPrevX(): number
        get rammingXHeadRot(): number
        get passengersRidingOffset(): number
        get frame(): boolean
        set legsArmorItem(item: Internal.ItemStack_)
        set noGravity($$0: boolean)
        get useItemRemainingTicks(): number
        get indirectPassengers(): Internal.Iterable<any>
        get navigation(): Internal.PathNavigation
        get controlledByLocalInstance(): boolean
        get monster(): boolean
        get loveCause(): Internal.ServerPlayer
        get lastClimbablePos(): Optional<BlockPos>
        set lastDynamicLuminance(luminance: number)
        set id($$0: number)
        get horizontalFacing(): Internal.Direction
        get type(): string
        get activeEffectsMap(): Internal.Map<Internal.MobEffect, Internal.MobEffectInstance>
        set motionX(x: number)
        get handSlots(): Internal.Iterable<Internal.ItemStack>
        get teamColor(): number
        set nbt(nbt: Internal.CompoundTag_)
        get recallPosition(): Internal.DimensionalPosition
        set dynamicLightEnabled(enabled: boolean)
        get restrictRadius(): number
        get registeredNavigation(): Internal.PathNavigation
        get forcedVisible(): boolean
        get invertedHealAndHarm(): boolean
        get freezing(): boolean
        set guaranteedDrop($$0: Internal.EquipmentSlot_)
        set sharedFlagOnFire($$0: boolean)
        static readonly LONG_JUMPING_DIMENSIONS: (Internal.EntityDimensions) & (Internal.EntityDimensions);
        static readonly UNIHORN_CHANCE: (0.10000000149011612) & (number);
        static readonly GOAT_FALL_DAMAGE_REDUCTION: (10) & (number);
        static readonly GOAT_SCREAMING_CHANCE: (0.02) & (number);
    }
    type Goat_ = Goat;
    class LavaSubmergedBlockProcessor extends Internal.StructureProcessor {
        constructor()
        getClass(): typeof any;
        toString(): string;
        notifyAll(): void;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hashCode(): number;
        processEntity(world: Internal.LevelReader_, seedPos: BlockPos_, rawEntityInfo: Internal.StructureTemplate$StructureEntityInfo_, entityInfo: Internal.StructureTemplate$StructureEntityInfo_, placementSettings: Internal.StructurePlaceSettings_, template: Internal.StructureTemplate_): Internal.StructureTemplate$StructureEntityInfo;
        wait(): void;
        wait(arg0: number): void;
        processBlock($$0: Internal.LevelReader_, $$1: BlockPos_, $$2: BlockPos_, $$3: Internal.StructureTemplate$StructureBlockInfo_, $$4: Internal.StructureTemplate$StructureBlockInfo_, $$5: Internal.StructurePlaceSettings_): Internal.StructureTemplate$StructureBlockInfo;
        finalizeProcessing($$0: Internal.ServerLevelAccessor_, $$1: BlockPos_, $$2: BlockPos_, $$3: Internal.List_<Internal.StructureTemplate$StructureBlockInfo>, $$4: Internal.List_<Internal.StructureTemplate$StructureBlockInfo>, $$5: Internal.StructurePlaceSettings_): Internal.List<Internal.StructureTemplate$StructureBlockInfo>;
        equals(arg0: any): boolean;
        callGetType(): Internal.StructureProcessorType<any>;
        get class(): typeof any
        static readonly CODEC: Internal.Codec<Internal.LavaSubmergedBlockProcessor>;
        static readonly INSTANCE: (Internal.LavaSubmergedBlockProcessor) & (Internal.LavaSubmergedBlockProcessor);
    }
    type LavaSubmergedBlockProcessor_ = LavaSubmergedBlockProcessor;
    interface DyeableEntity {
        abstract getColor(): number;
        abstract setColor(arg0: number): void;
        get color(): number
        set color(arg0: number)
    }
    type DyeableEntity_ = DyeableEntity;
    interface DoubleConsumer {
        abstract accept(arg0: number): void;
        andThen(arg0: Internal.DoubleConsumer_): this;
        (arg0: number): void;
    }
    type DoubleConsumer_ = ((arg0: number)=> void) | DoubleConsumer;
    interface TooltipAccessor {
        abstract puzzleslib$setCachedTooltip(arg0: Internal.List_<Internal.FormattedCharSequence>): void;
        (arg0: Internal.List<Internal.FormattedCharSequence>): void;
    }
    type TooltipAccessor_ = ((arg0: Internal.List<Internal.FormattedCharSequence>)=> void) | TooltipAccessor;
    interface ModelStateHolder {
        setModelState(state: number, world: Internal.Level_, pos: BlockPos_): void;
        abstract applyModelState(arg0: number): void;
        abstract getModelState(): number;
        get modelState(): number
    }
    type ModelStateHolder_ = ModelStateHolder;
    class GrapplingHookItem extends Internal.Item {
        constructor(properties: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        setRarity(arg0: Internal.Rarity_): void;
        isEnabled($$0: Internal.FeatureFlagSet_): boolean;
        getRecipeRemainder(stack: Internal.ItemStack_): Internal.ItemStack;
        allowContinuingBlockBreaking(player: Internal.Player_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        getDestroySpeed($$0: Internal.ItemStack_, $$1: Internal.BlockState_): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        onDestroyed($$0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onCraftedBy($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Player_): void;
        isComplex(): boolean;
        onUseTick($$0: Internal.Level_, $$1: Internal.LivingEntity_, $$2: Internal.ItemStack_, $$3: number): void;
        appendHoverText($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.List_<net.minecraft.network.chat.Component>, $$3: Internal.TooltipFlag_): void;
        canBeHurtBy($$0: DamageSource_): boolean;
        getFoodProperties(): Internal.FoodProperties;
        fabric_setEquipmentSlotProvider(equipmentSlotProvider: Internal.EquipmentSlotProvider_): void;
        getDescriptionId(): string;
        getUseAnimation($$0: Internal.ItemStack_): Internal.UseAnim;
        isValidRepairItem($$0: Internal.ItemStack_, $$1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getCreativeTab(): string;
        asItem(): Internal.Item;
        getDefaultInstance(): Internal.ItemStack;
        getTypeData(): Internal.CompoundTag;
        getDefaultTooltipHideFlags(stack: Internal.ItemStack_): number;
        getCreatorModId(itemStack: Internal.ItemStack_): string;
        fabric_setCustomDamageHandler(handler: Internal.CustomDamageHandler_): void;
        setBurnTime(i: number): void;
        setMaxStackSize(arg0: number): void;
        getBarWidth($$0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getBarColor($$0: Internal.ItemStack_): number;
        getItem(): Internal.Item;
        onLeftClickEntity(stack: Internal.ItemStack_, player: Internal.Player_, entity: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        hasCraftingRemainingItem(): boolean;
        owo$stackGenerator(): Internal.BiConsumer<any, any>;
        getClass(): typeof any;
        static getAttackDamageModifierId(): Internal.UUID;
        static byId($$0: number): Internal.Item;
        static port_lib$getPlayerPOVHitResult$porting_lib_accessors_$md$424943$0(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        interactLivingEntity($$0: Internal.ItemStack_, $$1: Internal.Player_, $$2: Internal.LivingEntity_, $$3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$setClientAnimationExtension(obj: any): void;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        handler$feb000$extraalchemy$potionutils_getTooltipData(stack: Internal.ItemStack_, cir: Internal.CallbackInfoReturnable_<any>): void;
        useOn($$0: Internal.UseOnContext_): Internal.InteractionResult;
        amethyst_imbuement_getAiItemGroup(): Internal.AiItemSettings$AiItemGroup;
        getRarity($$0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        static getAttackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        getTooltipImage($$0: Internal.ItemStack_): Optional<Internal.TooltipComponent>;
        isEdible(): boolean;
        getAttributeModifiers(stack: Internal.ItemStack_, slot: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(level: Internal.Level_, player: Internal.Player_, interactionHand: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        things$setRecipeRemainder(arg0: Internal.Item_): void;
        toString(): string;
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        notifyAll(): void;
        static getPlayerPOVHitResult$decorative_blocks_$md$424943$4(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getId(): string;
        isEnchantable($$0: Internal.ItemStack_): boolean;
        wait(arg0: number): void;
        isSuitableFor(stack: Internal.ItemStack_, state: Internal.BlockState_): boolean;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther($$0: Internal.ItemStack_, $$1: Internal.Slot_, $$2: Internal.ClickAction_, $$3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        cardinal_createComponents(stack: Internal.ItemStack_): Internal.ComponentContainer;
        onBlockStartBreak(itemstack: Internal.ItemStack_, pos: BlockPos_, player: Internal.Player_): boolean;
        isFoil($$0: Internal.ItemStack_): boolean;
        "setFoodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_): void;
        useOnRelease($$0: Internal.ItemStack_): boolean;
        static "getPlayerPOVHitResult(net.minecraft.world.level.Level,net.minecraft.world.entity.player.Player,net.minecraft.world.level.ClipContext$Fluid)"(level: Internal.Level_, player: Internal.Player_, ctx: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        canAttackBlock($$0: Internal.BlockState_, $$1: Internal.Level_, $$2: BlockPos_, $$3: Internal.Player_): boolean;
        fabric_getEquipmentSlotProvider(): Internal.EquipmentSlotProvider;
        notify(): void;
        setDigSpeed(speed: number): void;
        getDescriptionId($$0: Internal.ItemStack_): string;
        releaseUsing($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_, $$3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible($$0: Internal.ItemStack_): boolean;
        getUseDuration($$0: Internal.ItemStack_): number;
        static port_lib$getPlayerPOVHitResult(level: Internal.Level_, player: Internal.Player_, fluidMode: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock($$0: Internal.Block_): Internal.Item;
        owo$tab(): number;
        bookshelf$setCraftingRemainder(arg0: Internal.Item_): void;
        canFitInsideContainerItems(): boolean;
        wait(): void;
        isCorrectToolForDrops($$0: Internal.BlockState_): boolean;
        verifyTagAfterLoad($$0: Internal.CompoundTag_): void;
        "setFoodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        finishUsingItem($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        getEatingSound(): Internal.SoundEvent;
        owo$setGroup(group: Internal.CreativeModeTab_): void;
        hasCustomEntity(stack: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        mineBlock($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.BlockState_, $$3: BlockPos_, $$4: Internal.LivingEntity_): boolean;
        wait(arg0: number, arg1: number): void;
        setNameKey(arg0: string): void;
        getLightColor(player: Internal.Player_, stack: Internal.ItemStack_): Vec3f;
        getName($$0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        getDefaultAttributeModifiers($$0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getMod(): string;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(level: Internal.Level_, location: Internal.Entity_, stack: Internal.ItemStack_): Internal.Entity;
        setArmorProtection(armorProtection: number): void;
        getLightEmission(player: Internal.Player_, stack: Internal.ItemStack_): number;
        owo$group(): Internal.CreativeModeTab;
        inventoryTick($$0: Internal.ItemStack_, $$1: Internal.Level_, $$2: Internal.Entity_, $$3: number, $$4: boolean): void;
        allowNbtUpdateAnimation(player: Internal.Player_, hand: Internal.InteractionHand_, oldStack: Internal.ItemStack_, newStack: Internal.ItemStack_): boolean;
        hurtEnemy($$0: Internal.ItemStack_, $$1: Internal.LivingEntity_, $$2: Internal.LivingEntity_): boolean;
        getCraftingRemainingItem(): Internal.Item;
        modifyReturnValue$bie000$axiom$isFoil(isFoil: boolean, itemStack: Internal.ItemStack_): boolean;
        getTypeItemStackKey(): Internal.ItemStackKey;
        setFoodComponent(arg0: Internal.FoodProperties_): void;
        shouldOverrideMultiplayerNbt(): boolean;
        requiredFeatures(): Internal.FeatureFlagSet;
        fabric_getCachedItemVariant(): Internal.ItemVariant;
        hashCode(): number;
        static getId($$0: Internal.Item_): number;
        overrideOtherStackedOnMe($$0: Internal.ItemStack_, $$1: Internal.ItemStack_, $$2: Internal.Slot_, $$3: Internal.ClickAction_, $$4: Internal.Player_, $$5: Internal.SlotAccess_): boolean;
        fabric_getCustomDamageHandler(): Internal.CustomDamageHandler;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        static getPlayerPOVHitResult($$0: Internal.Level_, $$1: Internal.Player_, $$2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        equals(arg0: any): boolean;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get defaultInstance(): Internal.ItemStack
        get typeData(): Internal.CompoundTag
        set burnTime(i: number)
        set maxStackSize(arg0: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get class(): typeof any
        get attackDamageModifierId(): Internal.UUID
        set itemBuilder(b: Internal.ItemBuilder_)
        get attackDamageModifierId$bettertrims_$md$424943$3(): Internal.UUID
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set "foodProperties(net.minecraft.world.food.FoodProperties)"(arg0: Internal.FoodProperties_)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get maxStackSize(): number
        set "foodProperties(java.util.function.Consumer)"(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodComponent(arg0: Internal.FoodProperties_)
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
    }
    type GrapplingHookItem_ = GrapplingHookItem;
    class AzaleaFlowerPatchConfig extends Internal.Record implements Internal.FeatureConfiguration {
        constructor(xzRadius: Internal.IntProvider_, verticalRange: number)
        getClass(): typeof any;
        verticalRange(): number;
        hashCode(): number;
        getFeatures(): Internal.Stream<Internal.ConfiguredFeature<any, any>>;
        toString(): string;
        wait(): void;
        notifyAll(): void;
        wait(arg0: number): void;
        equals(o: any): boolean;
        notify(): void;
        xzRadius(): Internal.IntProvider;
        wait(arg0: number, arg1: number): void;
        get class(): typeof any
        get features(): Internal.Stream<Internal.ConfiguredFeature<any, any>>
        static readonly CODEC: Internal.Codec<Internal.AzaleaFlowerPatchConfig>;
    }
    type AzaleaFlowerPatchConfig_ = AzaleaFlowerPatchConfig;
}
declare namespace com.kirdow.itemlocks.mixin {
    interface KeyMappingAccessor {
        abstract getBoundKey(): Internal.InputConstants$Key;
        abstract getTranslationKey(): string;
        get boundKey(): Internal.InputConstants$Key
        get translationKey(): string
    }
    type KeyMappingAccessor_ = KeyMappingAccessor;
}
declare namespace com.mojang.authlib.properties {
    class Property {
        constructor(arg0: string, arg1: string, arg2: string)
        constructor(arg0: string, arg1: string)
        /**
         * @deprecated
        */
        isSignatureValid(arg0: Internal.PublicKey_): boolean;
        getClass(): typeof any;
        getValue(): string;
        toString(): string;
        notifyAll(): void;
        getSignature(): string;
        notify(): void;
        wait(arg0: number, arg1: number): void;
        hasSignature(): boolean;
        hashCode(): number;
        wait(): void;
        getName(): string;
        wait(arg0: number): void;
        equals(arg0: any): boolean;
        get class(): typeof any
        get value(): string
        get signature(): string
        get name(): string
    }
    type Property_ = Property;
}
declare namespace org.apache.logging.log4j.core.time {
    interface Instant extends Internal.StringBuilderFormattable {
        abstract getEpochSecond(): number;
        abstract formatTo(buffer: Internal.StringBuilder_): void;
        abstract getNanoOfMillisecond(): number;
        abstract getEpochMillisecond(): number;
        abstract getNanoOfSecond(): number;
        get epochSecond(): number
        get nanoOfMillisecond(): number
        get epochMillisecond(): number
        get nanoOfSecond(): number
    }
    type Instant_ = Instant;
}
