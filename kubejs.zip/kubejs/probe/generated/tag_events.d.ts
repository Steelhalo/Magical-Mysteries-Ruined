/// <reference path="./globals.d.ts" />
declare namespace TagEvent {
    class Boat extends Internal.TagEventJS {
    get(id: Special.BoatTag): Internal.TagWrapper
    add(tag: Special.BoatTag, ...id: Special.Boat[]): Internal.TagWrapper
    remove(tag: Special.BoatTag, ...id: Special.Boat[]): Internal.TagWrapper
    removeAll(tag: Special.BoatTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Boat[]): Internal.TagWrapper
    }
    class BientityAction extends Internal.TagEventJS {
    get(id: Special.BientityActionTag): Internal.TagWrapper
    add(tag: Special.BientityActionTag, ...id: Special.BientityAction[]): Internal.TagWrapper
    remove(tag: Special.BientityActionTag, ...id: Special.BientityAction[]): Internal.TagWrapper
    removeAll(tag: Special.BientityActionTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.BientityAction[]): Internal.TagWrapper
    }
    class ItemCondition extends Internal.TagEventJS {
    get(id: Special.ItemConditionTag): Internal.TagWrapper
    add(tag: Special.ItemConditionTag, ...id: Special.ItemCondition[]): Internal.TagWrapper
    remove(tag: Special.ItemConditionTag, ...id: Special.ItemCondition[]): Internal.TagWrapper
    removeAll(tag: Special.ItemConditionTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.ItemCondition[]): Internal.TagWrapper
    }
    class LootNbtProviderType extends Internal.TagEventJS {
    get(id: Special.LootNbtProviderTypeTag): Internal.TagWrapper
    add(tag: Special.LootNbtProviderTypeTag, ...id: Special.LootNbtProviderType[]): Internal.TagWrapper
    remove(tag: Special.LootNbtProviderTypeTag, ...id: Special.LootNbtProviderType[]): Internal.TagWrapper
    removeAll(tag: Special.LootNbtProviderTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.LootNbtProviderType[]): Internal.TagWrapper
    }
    class ChunkGenerator extends Internal.TagEventJS {
    get(id: Special.ChunkGeneratorTag): Internal.TagWrapper
    add(tag: Special.ChunkGeneratorTag, ...id: Special.ChunkGenerator[]): Internal.TagWrapper
    remove(tag: Special.ChunkGeneratorTag, ...id: Special.ChunkGenerator[]): Internal.TagWrapper
    removeAll(tag: Special.ChunkGeneratorTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.ChunkGenerator[]): Internal.TagWrapper
    }
    class Dimension extends Internal.TagEventJS {
    get(id: Special.DimensionTag): Internal.TagWrapper
    add(tag: Special.DimensionTag, ...id: Special.Dimension[]): Internal.TagWrapper
    remove(tag: Special.DimensionTag, ...id: Special.Dimension[]): Internal.TagWrapper
    removeAll(tag: Special.DimensionTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Dimension[]): Internal.TagWrapper
    }
    class Feature extends Internal.TagEventJS {
    get(id: Special.FeatureTag): Internal.TagWrapper
    add(tag: Special.FeatureTag, ...id: Special.Feature[]): Internal.TagWrapper
    remove(tag: Special.FeatureTag, ...id: Special.Feature[]): Internal.TagWrapper
    removeAll(tag: Special.FeatureTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Feature[]): Internal.TagWrapper
    }
    class FlatLevelGeneratorPreset extends Internal.TagEventJS {
    get(id: Special.FlatLevelGeneratorPresetTag): Internal.TagWrapper
    add(tag: Special.FlatLevelGeneratorPresetTag, ...id: Special.FlatLevelGeneratorPreset[]): Internal.TagWrapper
    remove(tag: Special.FlatLevelGeneratorPresetTag, ...id: Special.FlatLevelGeneratorPreset[]): Internal.TagWrapper
    removeAll(tag: Special.FlatLevelGeneratorPresetTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.FlatLevelGeneratorPreset[]): Internal.TagWrapper
    }
    class ChatType extends Internal.TagEventJS {
    get(id: Special.ChatTypeTag): Internal.TagWrapper
    add(tag: Special.ChatTypeTag, ...id: Special.ChatType[]): Internal.TagWrapper
    remove(tag: Special.ChatTypeTag, ...id: Special.ChatType[]): Internal.TagWrapper
    removeAll(tag: Special.ChatTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.ChatType[]): Internal.TagWrapper
    }
    class PowerFactory extends Internal.TagEventJS {
    get(id: Special.PowerFactoryTag): Internal.TagWrapper
    add(tag: Special.PowerFactoryTag, ...id: Special.PowerFactory[]): Internal.TagWrapper
    remove(tag: Special.PowerFactoryTag, ...id: Special.PowerFactory[]): Internal.TagWrapper
    removeAll(tag: Special.PowerFactoryTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.PowerFactory[]): Internal.TagWrapper
    }
    class RuleTest extends Internal.TagEventJS {
    get(id: Special.RuleTestTag): Internal.TagWrapper
    add(tag: Special.RuleTestTag, ...id: Special.RuleTest[]): Internal.TagWrapper
    remove(tag: Special.RuleTestTag, ...id: Special.RuleTest[]): Internal.TagWrapper
    removeAll(tag: Special.RuleTestTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.RuleTest[]): Internal.TagWrapper
    }
    class IotaType extends Internal.TagEventJS {
    get(id: Special.IotaTypeTag): Internal.TagWrapper
    add(tag: Special.IotaTypeTag, ...id: Special.IotaType[]): Internal.TagWrapper
    remove(tag: Special.IotaTypeTag, ...id: Special.IotaType[]): Internal.TagWrapper
    removeAll(tag: Special.IotaTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.IotaType[]): Internal.TagWrapper
    }
    class CatVariant extends Internal.TagEventJS {
    get(id: Special.CatVariantTag): Internal.TagWrapper
    add(tag: Special.CatVariantTag, ...id: Special.CatVariant[]): Internal.TagWrapper
    remove(tag: Special.CatVariantTag, ...id: Special.CatVariant[]): Internal.TagWrapper
    removeAll(tag: Special.CatVariantTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.CatVariant[]): Internal.TagWrapper
    }
    class SoftFluids extends Internal.TagEventJS {
    get(id: Special.SoftFluidsTag): Internal.TagWrapper
    add(tag: Special.SoftFluidsTag, ...id: Special.SoftFluids[]): Internal.TagWrapper
    remove(tag: Special.SoftFluidsTag, ...id: Special.SoftFluids[]): Internal.TagWrapper
    removeAll(tag: Special.SoftFluidsTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.SoftFluids[]): Internal.TagWrapper
    }
    class ValueDeserializers extends Internal.TagEventJS {
    get(id: Special.ValueDeserializersTag): Internal.TagWrapper
    add(tag: Special.ValueDeserializersTag, ...id: Special.ValueDeserializers[]): Internal.TagWrapper
    remove(tag: Special.ValueDeserializersTag, ...id: Special.ValueDeserializers[]): Internal.TagWrapper
    removeAll(tag: Special.ValueDeserializersTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.ValueDeserializers[]): Internal.TagWrapper
    }
    class ProcessorConditionType extends Internal.TagEventJS {
    get(id: Special.ProcessorConditionTypeTag): Internal.TagWrapper
    add(tag: Special.ProcessorConditionTypeTag, ...id: Special.ProcessorConditionType[]): Internal.TagWrapper
    remove(tag: Special.ProcessorConditionTypeTag, ...id: Special.ProcessorConditionType[]): Internal.TagWrapper
    removeAll(tag: Special.ProcessorConditionTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.ProcessorConditionType[]): Internal.TagWrapper
    }
    class FluidCondition extends Internal.TagEventJS {
    get(id: Special.FluidConditionTag): Internal.TagWrapper
    add(tag: Special.FluidConditionTag, ...id: Special.FluidCondition[]): Internal.TagWrapper
    remove(tag: Special.FluidConditionTag, ...id: Special.FluidCondition[]): Internal.TagWrapper
    removeAll(tag: Special.FluidConditionTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.FluidCondition[]): Internal.TagWrapper
    }
    class WorldPreset extends Internal.TagEventJS {
    get(id: Special.WorldPresetTag): Internal.TagWrapper
    add(tag: Special.WorldPresetTag, ...id: Special.WorldPreset[]): Internal.TagWrapper
    remove(tag: Special.WorldPresetTag, ...id: Special.WorldPreset[]): Internal.TagWrapper
    removeAll(tag: Special.WorldPresetTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.WorldPreset[]): Internal.TagWrapper
    }
    class DamageType extends Internal.TagEventJS {
    get(id: Special.DamageTypeTag): Internal.TagWrapper
    add(tag: Special.DamageTypeTag, ...id: Special.DamageType[]): Internal.TagWrapper
    remove(tag: Special.DamageTypeTag, ...id: Special.DamageType[]): Internal.TagWrapper
    removeAll(tag: Special.DamageTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.DamageType[]): Internal.TagWrapper
    }
    class FloatProviderType extends Internal.TagEventJS {
    get(id: Special.FloatProviderTypeTag): Internal.TagWrapper
    add(tag: Special.FloatProviderTypeTag, ...id: Special.FloatProviderType[]): Internal.TagWrapper
    remove(tag: Special.FloatProviderTypeTag, ...id: Special.FloatProviderType[]): Internal.TagWrapper
    removeAll(tag: Special.FloatProviderTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.FloatProviderType[]): Internal.TagWrapper
    }
    class WorldgenModifier extends Internal.TagEventJS {
    get(id: Special.WorldgenModifierTag): Internal.TagWrapper
    add(tag: Special.WorldgenModifierTag, ...id: Special.WorldgenModifier[]): Internal.TagWrapper
    remove(tag: Special.WorldgenModifierTag, ...id: Special.WorldgenModifier[]): Internal.TagWrapper
    removeAll(tag: Special.WorldgenModifierTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.WorldgenModifier[]): Internal.TagWrapper
    }
    class Activity extends Internal.TagEventJS {
    get(id: Special.ActivityTag): Internal.TagWrapper
    add(tag: Special.ActivityTag, ...id: Special.Activity[]): Internal.TagWrapper
    remove(tag: Special.ActivityTag, ...id: Special.Activity[]): Internal.TagWrapper
    removeAll(tag: Special.ActivityTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Activity[]): Internal.TagWrapper
    }
    class Structure extends Internal.TagEventJS {
    get(id: Special.StructureTag): Internal.TagWrapper
    add(tag: Special.StructureTag, ...id: Special.Structure[]): Internal.TagWrapper
    remove(tag: Special.StructureTag, ...id: Special.Structure[]): Internal.TagWrapper
    removeAll(tag: Special.StructureTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Structure[]): Internal.TagWrapper
    }
    class DensityFunction extends Internal.TagEventJS {
    get(id: Special.DensityFunctionTag): Internal.TagWrapper
    add(tag: Special.DensityFunctionTag, ...id: Special.DensityFunction[]): Internal.TagWrapper
    remove(tag: Special.DensityFunctionTag, ...id: Special.DensityFunction[]): Internal.TagWrapper
    removeAll(tag: Special.DensityFunctionTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.DensityFunction[]): Internal.TagWrapper
    }
    class PlacementConditionType extends Internal.TagEventJS {
    get(id: Special.PlacementConditionTypeTag): Internal.TagWrapper
    add(tag: Special.PlacementConditionTypeTag, ...id: Special.PlacementConditionType[]): Internal.TagWrapper
    remove(tag: Special.PlacementConditionTypeTag, ...id: Special.PlacementConditionType[]): Internal.TagWrapper
    removeAll(tag: Special.PlacementConditionTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.PlacementConditionType[]): Internal.TagWrapper
    }
    class EntityAction extends Internal.TagEventJS {
    get(id: Special.EntityActionTag): Internal.TagWrapper
    add(tag: Special.EntityActionTag, ...id: Special.EntityAction[]): Internal.TagWrapper
    remove(tag: Special.EntityActionTag, ...id: Special.EntityAction[]): Internal.TagWrapper
    removeAll(tag: Special.EntityActionTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.EntityAction[]): Internal.TagWrapper
    }
    class BlockStateProviderType extends Internal.TagEventJS {
    get(id: Special.BlockStateProviderTypeTag): Internal.TagWrapper
    add(tag: Special.BlockStateProviderTypeTag, ...id: Special.BlockStateProviderType[]): Internal.TagWrapper
    remove(tag: Special.BlockStateProviderTypeTag, ...id: Special.BlockStateProviderType[]): Internal.TagWrapper
    removeAll(tag: Special.BlockStateProviderTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.BlockStateProviderType[]): Internal.TagWrapper
    }
    class VillagerType extends Internal.TagEventJS {
    get(id: Special.VillagerTypeTag): Internal.TagWrapper
    add(tag: Special.VillagerTypeTag, ...id: Special.VillagerType[]): Internal.TagWrapper
    remove(tag: Special.VillagerTypeTag, ...id: Special.VillagerType[]): Internal.TagWrapper
    removeAll(tag: Special.VillagerTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.VillagerType[]): Internal.TagWrapper
    }
    class Brews extends Internal.TagEventJS {
    get(id: Special.BrewsTag): Internal.TagWrapper
    add(tag: Special.BrewsTag, ...id: Special.Brews[]): Internal.TagWrapper
    remove(tag: Special.BrewsTag, ...id: Special.Brews[]): Internal.TagWrapper
    removeAll(tag: Special.BrewsTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Brews[]): Internal.TagWrapper
    }
    class ChunkStatus extends Internal.TagEventJS {
    get(id: Special.ChunkStatusTag): Internal.TagWrapper
    add(tag: Special.ChunkStatusTag, ...id: Special.ChunkStatus[]): Internal.TagWrapper
    remove(tag: Special.ChunkStatusTag, ...id: Special.ChunkStatus[]): Internal.TagWrapper
    removeAll(tag: Special.ChunkStatusTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.ChunkStatus[]): Internal.TagWrapper
    }
    class ModifierPredicateType extends Internal.TagEventJS {
    get(id: Special.ModifierPredicateTypeTag): Internal.TagWrapper
    add(tag: Special.ModifierPredicateTypeTag, ...id: Special.ModifierPredicateType[]): Internal.TagWrapper
    remove(tag: Special.ModifierPredicateTypeTag, ...id: Special.ModifierPredicateType[]): Internal.TagWrapper
    removeAll(tag: Special.ModifierPredicateTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.ModifierPredicateType[]): Internal.TagWrapper
    }
    class Fortune extends Internal.TagEventJS {
    get(id: Special.FortuneTag): Internal.TagWrapper
    add(tag: Special.FortuneTag, ...id: Special.Fortune[]): Internal.TagWrapper
    remove(tag: Special.FortuneTag, ...id: Special.Fortune[]): Internal.TagWrapper
    removeAll(tag: Special.FortuneTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Fortune[]): Internal.TagWrapper
    }
    class Instrument extends Internal.TagEventJS {
    get(id: Special.InstrumentTag): Internal.TagWrapper
    add(tag: Special.InstrumentTag, ...id: Special.Instrument[]): Internal.TagWrapper
    remove(tag: Special.InstrumentTag, ...id: Special.Instrument[]): Internal.TagWrapper
    removeAll(tag: Special.InstrumentTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Instrument[]): Internal.TagWrapper
    }
    class BiomeCodec extends Internal.TagEventJS {
    get(id: Special.BiomeCodecTag): Internal.TagWrapper
    add(tag: Special.BiomeCodecTag, ...id: Special.BiomeCodec[]): Internal.TagWrapper
    remove(tag: Special.BiomeCodecTag, ...id: Special.BiomeCodec[]): Internal.TagWrapper
    removeAll(tag: Special.BiomeCodecTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.BiomeCodec[]): Internal.TagWrapper
    }
    class Potion extends Internal.TagEventJS {
    get(id: Special.PotionTag): Internal.TagWrapper
    add(tag: Special.PotionTag, ...id: Special.Potion[]): Internal.TagWrapper
    remove(tag: Special.PotionTag, ...id: Special.Potion[]): Internal.TagWrapper
    removeAll(tag: Special.PotionTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Potion[]): Internal.TagWrapper
    }
    class SurfaceRules extends Internal.TagEventJS {
    get(id: Special.SurfaceRulesTag): Internal.TagWrapper
    add(tag: Special.SurfaceRulesTag, ...id: Special.SurfaceRules[]): Internal.TagWrapper
    remove(tag: Special.SurfaceRulesTag, ...id: Special.SurfaceRules[]): Internal.TagWrapper
    removeAll(tag: Special.SurfaceRulesTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.SurfaceRules[]): Internal.TagWrapper
    }
    class CholemVariants extends Internal.TagEventJS {
    get(id: Special.CholemVariantsTag): Internal.TagWrapper
    add(tag: Special.CholemVariantsTag, ...id: Special.CholemVariants[]): Internal.TagWrapper
    remove(tag: Special.CholemVariantsTag, ...id: Special.CholemVariants[]): Internal.TagWrapper
    removeAll(tag: Special.CholemVariantsTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.CholemVariants[]): Internal.TagWrapper
    }
    class ConfiguredCarver extends Internal.TagEventJS {
    get(id: Special.ConfiguredCarverTag): Internal.TagWrapper
    add(tag: Special.ConfiguredCarverTag, ...id: Special.ConfiguredCarver[]): Internal.TagWrapper
    remove(tag: Special.ConfiguredCarverTag, ...id: Special.ConfiguredCarver[]): Internal.TagWrapper
    removeAll(tag: Special.ConfiguredCarverTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.ConfiguredCarver[]): Internal.TagWrapper
    }
    class BiomeSource extends Internal.TagEventJS {
    get(id: Special.BiomeSourceTag): Internal.TagWrapper
    add(tag: Special.BiomeSourceTag, ...id: Special.BiomeSource[]): Internal.TagWrapper
    remove(tag: Special.BiomeSourceTag, ...id: Special.BiomeSource[]): Internal.TagWrapper
    removeAll(tag: Special.BiomeSourceTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.BiomeSource[]): Internal.TagWrapper
    }
    class NoiseSettings extends Internal.TagEventJS {
    get(id: Special.NoiseSettingsTag): Internal.TagWrapper
    add(tag: Special.NoiseSettingsTag, ...id: Special.NoiseSettings[]): Internal.TagWrapper
    remove(tag: Special.NoiseSettingsTag, ...id: Special.NoiseSettings[]): Internal.TagWrapper
    removeAll(tag: Special.NoiseSettingsTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.NoiseSettings[]): Internal.TagWrapper
    }
    class ModifierType extends Internal.TagEventJS {
    get(id: Special.ModifierTypeTag): Internal.TagWrapper
    add(tag: Special.ModifierTypeTag, ...id: Special.ModifierType[]): Internal.TagWrapper
    remove(tag: Special.ModifierTypeTag, ...id: Special.ModifierType[]): Internal.TagWrapper
    removeAll(tag: Special.ModifierTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.ModifierType[]): Internal.TagWrapper
    }
    class EvalSound extends Internal.TagEventJS {
    get(id: Special.EvalSoundTag): Internal.TagWrapper
    add(tag: Special.EvalSoundTag, ...id: Special.EvalSound[]): Internal.TagWrapper
    remove(tag: Special.EvalSoundTag, ...id: Special.EvalSound[]): Internal.TagWrapper
    removeAll(tag: Special.EvalSoundTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.EvalSound[]): Internal.TagWrapper
    }
    class CommandArgumentType extends Internal.TagEventJS {
    get(id: Special.CommandArgumentTypeTag): Internal.TagWrapper
    add(tag: Special.CommandArgumentTypeTag, ...id: Special.CommandArgumentType[]): Internal.TagWrapper
    remove(tag: Special.CommandArgumentTypeTag, ...id: Special.CommandArgumentType[]): Internal.TagWrapper
    removeAll(tag: Special.CommandArgumentTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.CommandArgumentType[]): Internal.TagWrapper
    }
    class IngredientDeserializers extends Internal.TagEventJS {
    get(id: Special.IngredientDeserializersTag): Internal.TagWrapper
    add(tag: Special.IngredientDeserializersTag, ...id: Special.IngredientDeserializers[]): Internal.TagWrapper
    remove(tag: Special.IngredientDeserializersTag, ...id: Special.IngredientDeserializers[]): Internal.TagWrapper
    removeAll(tag: Special.IngredientDeserializersTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.IngredientDeserializers[]): Internal.TagWrapper
    }
    class LootConditionType extends Internal.TagEventJS {
    get(id: Special.LootConditionTypeTag): Internal.TagWrapper
    add(tag: Special.LootConditionTypeTag, ...id: Special.LootConditionType[]): Internal.TagWrapper
    remove(tag: Special.LootConditionTypeTag, ...id: Special.LootConditionType[]): Internal.TagWrapper
    removeAll(tag: Special.LootConditionTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.LootConditionType[]): Internal.TagWrapper
    }
    class BlockAction extends Internal.TagEventJS {
    get(id: Special.BlockActionTag): Internal.TagWrapper
    add(tag: Special.BlockActionTag, ...id: Special.BlockAction[]): Internal.TagWrapper
    remove(tag: Special.BlockActionTag, ...id: Special.BlockAction[]): Internal.TagWrapper
    removeAll(tag: Special.BlockActionTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.BlockAction[]): Internal.TagWrapper
    }
    class VillagerTradesItemListing extends Internal.TagEventJS {
    get(id: Special.VillagerTradesItemListingTag): Internal.TagWrapper
    add(tag: Special.VillagerTradesItemListingTag, ...id: Special.VillagerTradesItemListing[]): Internal.TagWrapper
    remove(tag: Special.VillagerTradesItemListingTag, ...id: Special.VillagerTradesItemListing[]): Internal.TagWrapper
    removeAll(tag: Special.VillagerTradesItemListingTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.VillagerTradesItemListing[]): Internal.TagWrapper
    }
    class RecipeSerializer extends Internal.TagEventJS {
    get(id: Special.RecipeSerializerTag): Internal.TagWrapper
    add(tag: Special.RecipeSerializerTag, ...id: Special.RecipeSerializer[]): Internal.TagWrapper
    remove(tag: Special.RecipeSerializerTag, ...id: Special.RecipeSerializer[]): Internal.TagWrapper
    removeAll(tag: Special.RecipeSerializerTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.RecipeSerializer[]): Internal.TagWrapper
    }
    class BiomeCondition extends Internal.TagEventJS {
    get(id: Special.BiomeConditionTag): Internal.TagWrapper
    add(tag: Special.BiomeConditionTag, ...id: Special.BiomeCondition[]): Internal.TagWrapper
    remove(tag: Special.BiomeConditionTag, ...id: Special.BiomeCondition[]): Internal.TagWrapper
    removeAll(tag: Special.BiomeConditionTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.BiomeCondition[]): Internal.TagWrapper
    }
    class Action extends Internal.TagEventJS {
    get(id: Special.ActionTag): Internal.TagWrapper
    add(tag: Special.ActionTag, ...id: Special.Action[]): Internal.TagWrapper
    remove(tag: Special.ActionTag, ...id: Special.Action[]): Internal.TagWrapper
    removeAll(tag: Special.ActionTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Action[]): Internal.TagWrapper
    }
    class MemoryModuleType extends Internal.TagEventJS {
    get(id: Special.MemoryModuleTypeTag): Internal.TagWrapper
    add(tag: Special.MemoryModuleTypeTag, ...id: Special.MemoryModuleType[]): Internal.TagWrapper
    remove(tag: Special.MemoryModuleTypeTag, ...id: Special.MemoryModuleType[]): Internal.TagWrapper
    removeAll(tag: Special.MemoryModuleTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.MemoryModuleType[]): Internal.TagWrapper
    }
    class MaterialCondition extends Internal.TagEventJS {
    get(id: Special.MaterialConditionTag): Internal.TagWrapper
    add(tag: Special.MaterialConditionTag, ...id: Special.MaterialCondition[]): Internal.TagWrapper
    remove(tag: Special.MaterialConditionTag, ...id: Special.MaterialCondition[]): Internal.TagWrapper
    removeAll(tag: Special.MaterialConditionTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.MaterialCondition[]): Internal.TagWrapper
    }
    class BlendingFunction extends Internal.TagEventJS {
    get(id: Special.BlendingFunctionTag): Internal.TagWrapper
    add(tag: Special.BlendingFunctionTag, ...id: Special.BlendingFunction[]): Internal.TagWrapper
    remove(tag: Special.BlendingFunctionTag, ...id: Special.BlendingFunction[]): Internal.TagWrapper
    removeAll(tag: Special.BlendingFunctionTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.BlendingFunction[]): Internal.TagWrapper
    }
    class FeatureSizeType extends Internal.TagEventJS {
    get(id: Special.FeatureSizeTypeTag): Internal.TagWrapper
    add(tag: Special.FeatureSizeTypeTag, ...id: Special.FeatureSizeType[]): Internal.TagWrapper
    remove(tag: Special.FeatureSizeTypeTag, ...id: Special.FeatureSizeType[]): Internal.TagWrapper
    removeAll(tag: Special.FeatureSizeTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.FeatureSizeType[]): Internal.TagWrapper
    }
    class TrimPattern extends Internal.TagEventJS {
    get(id: Special.TrimPatternTag): Internal.TagWrapper
    add(tag: Special.TrimPatternTag, ...id: Special.TrimPattern[]): Internal.TagWrapper
    remove(tag: Special.TrimPatternTag, ...id: Special.TrimPattern[]): Internal.TagWrapper
    removeAll(tag: Special.TrimPatternTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.TrimPattern[]): Internal.TagWrapper
    }
    class Condition extends Internal.TagEventJS {
    get(id: Special.ConditionTag): Internal.TagWrapper
    add(tag: Special.ConditionTag, ...id: Special.Condition[]): Internal.TagWrapper
    remove(tag: Special.ConditionTag, ...id: Special.Condition[]): Internal.TagWrapper
    removeAll(tag: Special.ConditionTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Condition[]): Internal.TagWrapper
    }
    class BientityCondition extends Internal.TagEventJS {
    get(id: Special.BientityConditionTag): Internal.TagWrapper
    add(tag: Special.BientityConditionTag, ...id: Special.BientityCondition[]): Internal.TagWrapper
    remove(tag: Special.BientityConditionTag, ...id: Special.BientityCondition[]): Internal.TagWrapper
    removeAll(tag: Special.BientityConditionTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.BientityCondition[]): Internal.TagWrapper
    }
    class PositionSourceType extends Internal.TagEventJS {
    get(id: Special.PositionSourceTypeTag): Internal.TagWrapper
    add(tag: Special.PositionSourceTypeTag, ...id: Special.PositionSourceType[]): Internal.TagWrapper
    remove(tag: Special.PositionSourceTypeTag, ...id: Special.PositionSourceType[]): Internal.TagWrapper
    removeAll(tag: Special.PositionSourceTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.PositionSourceType[]): Internal.TagWrapper
    }
    class StructureProcessor extends Internal.TagEventJS {
    get(id: Special.StructureProcessorTag): Internal.TagWrapper
    add(tag: Special.StructureProcessorTag, ...id: Special.StructureProcessor[]): Internal.TagWrapper
    remove(tag: Special.StructureProcessorTag, ...id: Special.StructureProcessor[]): Internal.TagWrapper
    removeAll(tag: Special.StructureProcessorTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.StructureProcessor[]): Internal.TagWrapper
    }
    class Item extends Internal.TagEventJS {
    get(id: Special.ItemTag): Internal.TagWrapper
    add(tag: Special.ItemTag, ...id: Special.Item[]): Internal.TagWrapper
    remove(tag: Special.ItemTag, ...id: Special.Item[]): Internal.TagWrapper
    removeAll(tag: Special.ItemTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Item[]): Internal.TagWrapper
    }
    class LootPoolEntryType extends Internal.TagEventJS {
    get(id: Special.LootPoolEntryTypeTag): Internal.TagWrapper
    add(tag: Special.LootPoolEntryTypeTag, ...id: Special.LootPoolEntryType[]): Internal.TagWrapper
    remove(tag: Special.LootPoolEntryTypeTag, ...id: Special.LootPoolEntryType[]): Internal.TagWrapper
    removeAll(tag: Special.LootPoolEntryTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.LootPoolEntryType[]): Internal.TagWrapper
    }
    class StructurePoolElement extends Internal.TagEventJS {
    get(id: Special.StructurePoolElementTag): Internal.TagWrapper
    add(tag: Special.StructurePoolElementTag, ...id: Special.StructurePoolElement[]): Internal.TagWrapper
    remove(tag: Special.StructurePoolElementTag, ...id: Special.StructurePoolElement[]): Internal.TagWrapper
    removeAll(tag: Special.StructurePoolElementTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.StructurePoolElement[]): Internal.TagWrapper
    }
    class BannerPattern extends Internal.TagEventJS {
    get(id: Special.BannerPatternTag): Internal.TagWrapper
    add(tag: Special.BannerPatternTag, ...id: Special.BannerPattern[]): Internal.TagWrapper
    remove(tag: Special.BannerPatternTag, ...id: Special.BannerPattern[]): Internal.TagWrapper
    removeAll(tag: Special.BannerPatternTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.BannerPattern[]): Internal.TagWrapper
    }
    class LootFunctionType extends Internal.TagEventJS {
    get(id: Special.LootFunctionTypeTag): Internal.TagWrapper
    add(tag: Special.LootFunctionTypeTag, ...id: Special.LootFunctionType[]): Internal.TagWrapper
    remove(tag: Special.LootFunctionTypeTag, ...id: Special.LootFunctionType[]): Internal.TagWrapper
    removeAll(tag: Special.LootFunctionTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.LootFunctionType[]): Internal.TagWrapper
    }
    class MultiNoiseBiomeSourceParameterList extends Internal.TagEventJS {
    get(id: Special.MultiNoiseBiomeSourceParameterListTag): Internal.TagWrapper
    add(tag: Special.MultiNoiseBiomeSourceParameterListTag, ...id: Special.MultiNoiseBiomeSourceParameterList[]): Internal.TagWrapper
    remove(tag: Special.MultiNoiseBiomeSourceParameterListTag, ...id: Special.MultiNoiseBiomeSourceParameterList[]): Internal.TagWrapper
    removeAll(tag: Special.MultiNoiseBiomeSourceParameterListTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.MultiNoiseBiomeSourceParameterList[]): Internal.TagWrapper
    }
    class BlockCondition extends Internal.TagEventJS {
    get(id: Special.BlockConditionTag): Internal.TagWrapper
    add(tag: Special.BlockConditionTag, ...id: Special.BlockCondition[]): Internal.TagWrapper
    remove(tag: Special.BlockConditionTag, ...id: Special.BlockCondition[]): Internal.TagWrapper
    removeAll(tag: Special.BlockConditionTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.BlockCondition[]): Internal.TagWrapper
    }
    class SensorType extends Internal.TagEventJS {
    get(id: Special.SensorTypeTag): Internal.TagWrapper
    add(tag: Special.SensorTypeTag, ...id: Special.SensorType[]): Internal.TagWrapper
    remove(tag: Special.SensorTypeTag, ...id: Special.SensorType[]): Internal.TagWrapper
    removeAll(tag: Special.SensorTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.SensorType[]): Internal.TagWrapper
    }
    class HeightProviderType extends Internal.TagEventJS {
    get(id: Special.HeightProviderTypeTag): Internal.TagWrapper
    add(tag: Special.HeightProviderTypeTag, ...id: Special.HeightProviderType[]): Internal.TagWrapper
    remove(tag: Special.HeightProviderTypeTag, ...id: Special.HeightProviderType[]): Internal.TagWrapper
    removeAll(tag: Special.HeightProviderTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.HeightProviderType[]): Internal.TagWrapper
    }
    class Biome extends Internal.TagEventJS {
    get(id: Special.BiomeTag): Internal.TagWrapper
    add(tag: Special.BiomeTag, ...id: Special.Biome[]): Internal.TagWrapper
    remove(tag: Special.BiomeTag, ...id: Special.Biome[]): Internal.TagWrapper
    removeAll(tag: Special.BiomeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Biome[]): Internal.TagWrapper
    }
    class RootPlacerType extends Internal.TagEventJS {
    get(id: Special.RootPlacerTypeTag): Internal.TagWrapper
    add(tag: Special.RootPlacerTypeTag, ...id: Special.RootPlacerType[]): Internal.TagWrapper
    remove(tag: Special.RootPlacerTypeTag, ...id: Special.RootPlacerType[]): Internal.TagWrapper
    removeAll(tag: Special.RootPlacerTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.RootPlacerType[]): Internal.TagWrapper
    }
    class StructurePiece extends Internal.TagEventJS {
    get(id: Special.StructurePieceTag): Internal.TagWrapper
    add(tag: Special.StructurePieceTag, ...id: Special.StructurePiece[]): Internal.TagWrapper
    remove(tag: Special.StructurePieceTag, ...id: Special.StructurePiece[]): Internal.TagWrapper
    removeAll(tag: Special.StructurePieceTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.StructurePiece[]): Internal.TagWrapper
    }
    class GlobalLootModifierSerializers extends Internal.TagEventJS {
    get(id: Special.GlobalLootModifierSerializersTag): Internal.TagWrapper
    add(tag: Special.GlobalLootModifierSerializersTag, ...id: Special.GlobalLootModifierSerializers[]): Internal.TagWrapper
    remove(tag: Special.GlobalLootModifierSerializersTag, ...id: Special.GlobalLootModifierSerializers[]): Internal.TagWrapper
    removeAll(tag: Special.GlobalLootModifierSerializersTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.GlobalLootModifierSerializers[]): Internal.TagWrapper
    }
    class TrimMaterial extends Internal.TagEventJS {
    get(id: Special.TrimMaterialTag): Internal.TagWrapper
    add(tag: Special.TrimMaterialTag, ...id: Special.TrimMaterial[]): Internal.TagWrapper
    remove(tag: Special.TrimMaterialTag, ...id: Special.TrimMaterial[]): Internal.TagWrapper
    removeAll(tag: Special.TrimMaterialTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.TrimMaterial[]): Internal.TagWrapper
    }
    class DecoratedPotPatterns extends Internal.TagEventJS {
    get(id: Special.DecoratedPotPatternsTag): Internal.TagWrapper
    add(tag: Special.DecoratedPotPatternsTag, ...id: Special.DecoratedPotPatterns[]): Internal.TagWrapper
    remove(tag: Special.DecoratedPotPatternsTag, ...id: Special.DecoratedPotPatterns[]): Internal.TagWrapper
    removeAll(tag: Special.DecoratedPotPatternsTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.DecoratedPotPatterns[]): Internal.TagWrapper
    }
    class ProcessorList extends Internal.TagEventJS {
    get(id: Special.ProcessorListTag): Internal.TagWrapper
    add(tag: Special.ProcessorListTag, ...id: Special.ProcessorList[]): Internal.TagWrapper
    remove(tag: Special.ProcessorListTag, ...id: Special.ProcessorList[]): Internal.TagWrapper
    removeAll(tag: Special.ProcessorListTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.ProcessorList[]): Internal.TagWrapper
    }
    class FoliagePlacerType extends Internal.TagEventJS {
    get(id: Special.FoliagePlacerTypeTag): Internal.TagWrapper
    add(tag: Special.FoliagePlacerTypeTag, ...id: Special.FoliagePlacerType[]): Internal.TagWrapper
    remove(tag: Special.FoliagePlacerTypeTag, ...id: Special.FoliagePlacerType[]): Internal.TagWrapper
    removeAll(tag: Special.FoliagePlacerTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.FoliagePlacerType[]): Internal.TagWrapper
    }
    class IntProviderType extends Internal.TagEventJS {
    get(id: Special.IntProviderTypeTag): Internal.TagWrapper
    add(tag: Special.IntProviderTypeTag, ...id: Special.IntProviderType[]): Internal.TagWrapper
    remove(tag: Special.IntProviderTypeTag, ...id: Special.IntProviderType[]): Internal.TagWrapper
    removeAll(tag: Special.IntProviderTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.IntProviderType[]): Internal.TagWrapper
    }
    class PlacedFeature extends Internal.TagEventJS {
    get(id: Special.PlacedFeatureTag): Internal.TagWrapper
    add(tag: Special.PlacedFeatureTag, ...id: Special.PlacedFeature[]): Internal.TagWrapper
    remove(tag: Special.PlacedFeatureTag, ...id: Special.PlacedFeature[]): Internal.TagWrapper
    removeAll(tag: Special.PlacedFeatureTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.PlacedFeature[]): Internal.TagWrapper
    }
    class RuleBlockEntityModifier extends Internal.TagEventJS {
    get(id: Special.RuleBlockEntityModifierTag): Internal.TagWrapper
    add(tag: Special.RuleBlockEntityModifierTag, ...id: Special.RuleBlockEntityModifier[]): Internal.TagWrapper
    remove(tag: Special.RuleBlockEntityModifierTag, ...id: Special.RuleBlockEntityModifier[]): Internal.TagWrapper
    removeAll(tag: Special.RuleBlockEntityModifierTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.RuleBlockEntityModifier[]): Internal.TagWrapper
    }
    class HamsterVariants extends Internal.TagEventJS {
    get(id: Special.HamsterVariantsTag): Internal.TagWrapper
    add(tag: Special.HamsterVariantsTag, ...id: Special.HamsterVariants[]): Internal.TagWrapper
    remove(tag: Special.HamsterVariantsTag, ...id: Special.HamsterVariants[]): Internal.TagWrapper
    removeAll(tag: Special.HamsterVariantsTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.HamsterVariants[]): Internal.TagWrapper
    }
    class Arithmetic extends Internal.TagEventJS {
    get(id: Special.ArithmeticTag): Internal.TagWrapper
    add(tag: Special.ArithmeticTag, ...id: Special.Arithmetic[]): Internal.TagWrapper
    remove(tag: Special.ArithmeticTag, ...id: Special.Arithmetic[]): Internal.TagWrapper
    removeAll(tag: Special.ArithmeticTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Arithmetic[]): Internal.TagWrapper
    }
    class ChorseVariants extends Internal.TagEventJS {
    get(id: Special.ChorseVariantsTag): Internal.TagWrapper
    add(tag: Special.ChorseVariantsTag, ...id: Special.ChorseVariants[]): Internal.TagWrapper
    remove(tag: Special.ChorseVariantsTag, ...id: Special.ChorseVariants[]): Internal.TagWrapper
    removeAll(tag: Special.ChorseVariantsTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.ChorseVariants[]): Internal.TagWrapper
    }
    class RitualFunction extends Internal.TagEventJS {
    get(id: Special.RitualFunctionTag): Internal.TagWrapper
    add(tag: Special.RitualFunctionTag, ...id: Special.RitualFunction[]): Internal.TagWrapper
    remove(tag: Special.RitualFunctionTag, ...id: Special.RitualFunction[]): Internal.TagWrapper
    removeAll(tag: Special.RitualFunctionTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.RitualFunction[]): Internal.TagWrapper
    }
    class BlockPredicateType extends Internal.TagEventJS {
    get(id: Special.BlockPredicateTypeTag): Internal.TagWrapper
    add(tag: Special.BlockPredicateTypeTag, ...id: Special.BlockPredicateType[]): Internal.TagWrapper
    remove(tag: Special.BlockPredicateTypeTag, ...id: Special.BlockPredicateType[]): Internal.TagWrapper
    removeAll(tag: Special.BlockPredicateTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.BlockPredicateType[]): Internal.TagWrapper
    }
    class CustomStat extends Internal.TagEventJS {
    get(id: Special.CustomStatTag): Internal.TagWrapper
    add(tag: Special.CustomStatTag, ...id: Special.CustomStat[]): Internal.TagWrapper
    remove(tag: Special.CustomStatTag, ...id: Special.CustomStat[]): Internal.TagWrapper
    removeAll(tag: Special.CustomStatTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.CustomStat[]): Internal.TagWrapper
    }
    class Schedule extends Internal.TagEventJS {
    get(id: Special.ScheduleTag): Internal.TagWrapper
    add(tag: Special.ScheduleTag, ...id: Special.Schedule[]): Internal.TagWrapper
    remove(tag: Special.ScheduleTag, ...id: Special.Schedule[]): Internal.TagWrapper
    removeAll(tag: Special.ScheduleTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Schedule[]): Internal.TagWrapper
    }
    class MapMarkers extends Internal.TagEventJS {
    get(id: Special.MapMarkersTag): Internal.TagWrapper
    add(tag: Special.MapMarkersTag, ...id: Special.MapMarkers[]): Internal.TagWrapper
    remove(tag: Special.MapMarkersTag, ...id: Special.MapMarkers[]): Internal.TagWrapper
    removeAll(tag: Special.MapMarkersTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.MapMarkers[]): Internal.TagWrapper
    }
    class LegacySkyboxDeserializer extends Internal.TagEventJS {
    get(id: Special.LegacySkyboxDeserializerTag): Internal.TagWrapper
    add(tag: Special.LegacySkyboxDeserializerTag, ...id: Special.LegacySkyboxDeserializer[]): Internal.TagWrapper
    remove(tag: Special.LegacySkyboxDeserializerTag, ...id: Special.LegacySkyboxDeserializer[]): Internal.TagWrapper
    removeAll(tag: Special.LegacySkyboxDeserializerTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.LegacySkyboxDeserializer[]): Internal.TagWrapper
    }
    class BlockEntityType extends Internal.TagEventJS {
    get(id: Special.BlockEntityTypeTag): Internal.TagWrapper
    add(tag: Special.BlockEntityTypeTag, ...id: Special.BlockEntityType[]): Internal.TagWrapper
    remove(tag: Special.BlockEntityTypeTag, ...id: Special.BlockEntityType[]): Internal.TagWrapper
    removeAll(tag: Special.BlockEntityTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.BlockEntityType[]): Internal.TagWrapper
    }
    class DamageCondition extends Internal.TagEventJS {
    get(id: Special.DamageConditionTag): Internal.TagWrapper
    add(tag: Special.DamageConditionTag, ...id: Special.DamageCondition[]): Internal.TagWrapper
    remove(tag: Special.DamageConditionTag, ...id: Special.DamageCondition[]): Internal.TagWrapper
    removeAll(tag: Special.DamageConditionTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.DamageCondition[]): Internal.TagWrapper
    }
    class ModifierHelperType extends Internal.TagEventJS {
    get(id: Special.ModifierHelperTypeTag): Internal.TagWrapper
    add(tag: Special.ModifierHelperTypeTag, ...id: Special.ModifierHelperType[]): Internal.TagWrapper
    remove(tag: Special.ModifierHelperTypeTag, ...id: Special.ModifierHelperType[]): Internal.TagWrapper
    removeAll(tag: Special.ModifierHelperTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.ModifierHelperType[]): Internal.TagWrapper
    }
    class PointOfInterestType extends Internal.TagEventJS {
    get(id: Special.PointOfInterestTypeTag): Internal.TagWrapper
    add(tag: Special.PointOfInterestTypeTag, ...id: Special.PointOfInterestType[]): Internal.TagWrapper
    remove(tag: Special.PointOfInterestTypeTag, ...id: Special.PointOfInterestType[]): Internal.TagWrapper
    removeAll(tag: Special.PointOfInterestTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.PointOfInterestType[]): Internal.TagWrapper
    }
    class MaterialRule extends Internal.TagEventJS {
    get(id: Special.MaterialRuleTag): Internal.TagWrapper
    add(tag: Special.MaterialRuleTag, ...id: Special.MaterialRule[]): Internal.TagWrapper
    remove(tag: Special.MaterialRuleTag, ...id: Special.MaterialRule[]): Internal.TagWrapper
    removeAll(tag: Special.MaterialRuleTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.MaterialRule[]): Internal.TagWrapper
    }
    class ContinuationType extends Internal.TagEventJS {
    get(id: Special.ContinuationTypeTag): Internal.TagWrapper
    add(tag: Special.ContinuationTypeTag, ...id: Special.ContinuationType[]): Internal.TagWrapper
    remove(tag: Special.ContinuationTypeTag, ...id: Special.ContinuationType[]): Internal.TagWrapper
    removeAll(tag: Special.ContinuationTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.ContinuationType[]): Internal.TagWrapper
    }
    class FluidType extends Internal.TagEventJS {
    get(id: Special.FluidTypeTag): Internal.TagWrapper
    add(tag: Special.FluidTypeTag, ...id: Special.FluidType[]): Internal.TagWrapper
    remove(tag: Special.FluidTypeTag, ...id: Special.FluidType[]): Internal.TagWrapper
    removeAll(tag: Special.FluidTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.FluidType[]): Internal.TagWrapper
    }
    class Curse extends Internal.TagEventJS {
    get(id: Special.CurseTag): Internal.TagWrapper
    add(tag: Special.CurseTag, ...id: Special.Curse[]): Internal.TagWrapper
    remove(tag: Special.CurseTag, ...id: Special.Curse[]): Internal.TagWrapper
    removeAll(tag: Special.CurseTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Curse[]): Internal.TagWrapper
    }
    class SoundEvent extends Internal.TagEventJS {
    get(id: Special.SoundEventTag): Internal.TagWrapper
    add(tag: Special.SoundEventTag, ...id: Special.SoundEvent[]): Internal.TagWrapper
    remove(tag: Special.SoundEventTag, ...id: Special.SoundEvent[]): Internal.TagWrapper
    removeAll(tag: Special.SoundEventTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.SoundEvent[]): Internal.TagWrapper
    }
    class Block extends Internal.TagEventJS {
    get(id: Special.BlockTag): Internal.TagWrapper
    add(tag: Special.BlockTag, ...id: Special.Block[]): Internal.TagWrapper
    remove(tag: Special.BlockTag, ...id: Special.Block[]): Internal.TagWrapper
    removeAll(tag: Special.BlockTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Block[]): Internal.TagWrapper
    }
    class RecipeType extends Internal.TagEventJS {
    get(id: Special.RecipeTypeTag): Internal.TagWrapper
    add(tag: Special.RecipeTypeTag, ...id: Special.RecipeType[]): Internal.TagWrapper
    remove(tag: Special.RecipeTypeTag, ...id: Special.RecipeType[]): Internal.TagWrapper
    removeAll(tag: Special.RecipeTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.RecipeType[]): Internal.TagWrapper
    }
    class ItemAction extends Internal.TagEventJS {
    get(id: Special.ItemActionTag): Internal.TagWrapper
    add(tag: Special.ItemActionTag, ...id: Special.ItemAction[]): Internal.TagWrapper
    remove(tag: Special.ItemActionTag, ...id: Special.ItemAction[]): Internal.TagWrapper
    removeAll(tag: Special.ItemActionTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.ItemAction[]): Internal.TagWrapper
    }
    class ModifierConsumerType extends Internal.TagEventJS {
    get(id: Special.ModifierConsumerTypeTag): Internal.TagWrapper
    add(tag: Special.ModifierConsumerTypeTag, ...id: Special.ModifierConsumerType[]): Internal.TagWrapper
    remove(tag: Special.ModifierConsumerTypeTag, ...id: Special.ModifierConsumerType[]): Internal.TagWrapper
    removeAll(tag: Special.ModifierConsumerTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.ModifierConsumerType[]): Internal.TagWrapper
    }
    class Attribute extends Internal.TagEventJS {
    get(id: Special.AttributeTag): Internal.TagWrapper
    add(tag: Special.AttributeTag, ...id: Special.Attribute[]): Internal.TagWrapper
    remove(tag: Special.AttributeTag, ...id: Special.Attribute[]): Internal.TagWrapper
    removeAll(tag: Special.AttributeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Attribute[]): Internal.TagWrapper
    }
    class LootNumberProviderType extends Internal.TagEventJS {
    get(id: Special.LootNumberProviderTypeTag): Internal.TagWrapper
    add(tag: Special.LootNumberProviderTypeTag, ...id: Special.LootNumberProviderType[]): Internal.TagWrapper
    remove(tag: Special.LootNumberProviderTypeTag, ...id: Special.LootNumberProviderType[]): Internal.TagWrapper
    removeAll(tag: Special.LootNumberProviderTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.LootNumberProviderType[]): Internal.TagWrapper
    }
    class ModifierOperation extends Internal.TagEventJS {
    get(id: Special.ModifierOperationTag): Internal.TagWrapper
    add(tag: Special.ModifierOperationTag, ...id: Special.ModifierOperation[]): Internal.TagWrapper
    remove(tag: Special.ModifierOperationTag, ...id: Special.ModifierOperation[]): Internal.TagWrapper
    removeAll(tag: Special.ModifierOperationTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.ModifierOperation[]): Internal.TagWrapper
    }
    class TrunkPlacerType extends Internal.TagEventJS {
    get(id: Special.TrunkPlacerTypeTag): Internal.TagWrapper
    add(tag: Special.TrunkPlacerTypeTag, ...id: Special.TrunkPlacerType[]): Internal.TagWrapper
    remove(tag: Special.TrunkPlacerTypeTag, ...id: Special.TrunkPlacerType[]): Internal.TagWrapper
    removeAll(tag: Special.TrunkPlacerTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.TrunkPlacerType[]): Internal.TagWrapper
    }
    class TreeDecoratorType extends Internal.TagEventJS {
    get(id: Special.TreeDecoratorTypeTag): Internal.TagWrapper
    add(tag: Special.TreeDecoratorTypeTag, ...id: Special.TreeDecoratorType[]): Internal.TagWrapper
    remove(tag: Special.TreeDecoratorTypeTag, ...id: Special.TreeDecoratorType[]): Internal.TagWrapper
    removeAll(tag: Special.TreeDecoratorTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.TreeDecoratorType[]): Internal.TagWrapper
    }
    class PaintingVariant extends Internal.TagEventJS {
    get(id: Special.PaintingVariantTag): Internal.TagWrapper
    add(tag: Special.PaintingVariantTag, ...id: Special.PaintingVariant[]): Internal.TagWrapper
    remove(tag: Special.PaintingVariantTag, ...id: Special.PaintingVariant[]): Internal.TagWrapper
    removeAll(tag: Special.PaintingVariantTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.PaintingVariant[]): Internal.TagWrapper
    }
    class Spell extends Internal.TagEventJS {
    get(id: Special.SpellTag): Internal.TagWrapper
    add(tag: Special.SpellTag, ...id: Special.Spell[]): Internal.TagWrapper
    remove(tag: Special.SpellTag, ...id: Special.Spell[]): Internal.TagWrapper
    removeAll(tag: Special.SpellTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Spell[]): Internal.TagWrapper
    }
    class Fluid extends Internal.TagEventJS {
    get(id: Special.FluidTag): Internal.TagWrapper
    add(tag: Special.FluidTag, ...id: Special.Fluid[]): Internal.TagWrapper
    remove(tag: Special.FluidTag, ...id: Special.Fluid[]): Internal.TagWrapper
    removeAll(tag: Special.FluidTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Fluid[]): Internal.TagWrapper
    }
    class MobEffect extends Internal.TagEventJS {
    get(id: Special.MobEffectTag): Internal.TagWrapper
    add(tag: Special.MobEffectTag, ...id: Special.MobEffect[]): Internal.TagWrapper
    remove(tag: Special.MobEffectTag, ...id: Special.MobEffect[]): Internal.TagWrapper
    removeAll(tag: Special.MobEffectTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.MobEffect[]): Internal.TagWrapper
    }
    class Sigil extends Internal.TagEventJS {
    get(id: Special.SigilTag): Internal.TagWrapper
    add(tag: Special.SigilTag, ...id: Special.Sigil[]): Internal.TagWrapper
    remove(tag: Special.SigilTag, ...id: Special.Sigil[]): Internal.TagWrapper
    removeAll(tag: Special.SigilTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Sigil[]): Internal.TagWrapper
    }
    class TemplatePool extends Internal.TagEventJS {
    get(id: Special.TemplatePoolTag): Internal.TagWrapper
    add(tag: Special.TemplatePoolTag, ...id: Special.TemplatePool[]): Internal.TagWrapper
    remove(tag: Special.TemplatePoolTag, ...id: Special.TemplatePool[]): Internal.TagWrapper
    removeAll(tag: Special.TemplatePoolTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.TemplatePool[]): Internal.TagWrapper
    }
    class PlacementModifierType extends Internal.TagEventJS {
    get(id: Special.PlacementModifierTypeTag): Internal.TagWrapper
    add(tag: Special.PlacementModifierTypeTag, ...id: Special.PlacementModifierType[]): Internal.TagWrapper
    remove(tag: Special.PlacementModifierTypeTag, ...id: Special.PlacementModifierType[]): Internal.TagWrapper
    removeAll(tag: Special.PlacementModifierTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.PlacementModifierType[]): Internal.TagWrapper
    }
    class Biome extends Internal.TagEventJS {
    get(id: Special.BiomeTag): Internal.TagWrapper
    add(tag: Special.BiomeTag, ...id: Special.Biome[]): Internal.TagWrapper
    remove(tag: Special.BiomeTag, ...id: Special.Biome[]): Internal.TagWrapper
    removeAll(tag: Special.BiomeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Biome[]): Internal.TagWrapper
    }
    class EntityType extends Internal.TagEventJS {
    get(id: Special.EntityTypeTag): Internal.TagWrapper
    add(tag: Special.EntityTypeTag, ...id: Special.EntityType[]): Internal.TagWrapper
    remove(tag: Special.EntityTypeTag, ...id: Special.EntityType[]): Internal.TagWrapper
    removeAll(tag: Special.EntityTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.EntityType[]): Internal.TagWrapper
    }
    class StructureType extends Internal.TagEventJS {
    get(id: Special.StructureTypeTag): Internal.TagWrapper
    add(tag: Special.StructureTypeTag, ...id: Special.StructureType[]): Internal.TagWrapper
    remove(tag: Special.StructureTypeTag, ...id: Special.StructureType[]): Internal.TagWrapper
    removeAll(tag: Special.StructureTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.StructureType[]): Internal.TagWrapper
    }
    class SkyboxType extends Internal.TagEventJS {
    get(id: Special.SkyboxTypeTag): Internal.TagWrapper
    add(tag: Special.SkyboxTypeTag, ...id: Special.SkyboxType[]): Internal.TagWrapper
    remove(tag: Special.SkyboxTypeTag, ...id: Special.SkyboxType[]): Internal.TagWrapper
    removeAll(tag: Special.SkyboxTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.SkyboxType[]): Internal.TagWrapper
    }
    class LootScoreProviderType extends Internal.TagEventJS {
    get(id: Special.LootScoreProviderTypeTag): Internal.TagWrapper
    add(tag: Special.LootScoreProviderTypeTag, ...id: Special.LootScoreProviderType[]): Internal.TagWrapper
    remove(tag: Special.LootScoreProviderTypeTag, ...id: Special.LootScoreProviderType[]): Internal.TagWrapper
    removeAll(tag: Special.LootScoreProviderTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.LootScoreProviderType[]): Internal.TagWrapper
    }
    class Carver extends Internal.TagEventJS {
    get(id: Special.CarverTag): Internal.TagWrapper
    add(tag: Special.CarverTag, ...id: Special.Carver[]): Internal.TagWrapper
    remove(tag: Special.CarverTag, ...id: Special.Carver[]): Internal.TagWrapper
    removeAll(tag: Special.CarverTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Carver[]): Internal.TagWrapper
    }
    class PosRuleTest extends Internal.TagEventJS {
    get(id: Special.PosRuleTestTag): Internal.TagWrapper
    add(tag: Special.PosRuleTestTag, ...id: Special.PosRuleTest[]): Internal.TagWrapper
    remove(tag: Special.PosRuleTestTag, ...id: Special.PosRuleTest[]): Internal.TagWrapper
    removeAll(tag: Special.PosRuleTestTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.PosRuleTest[]): Internal.TagWrapper
    }
    class SpecialHandler extends Internal.TagEventJS {
    get(id: Special.SpecialHandlerTag): Internal.TagWrapper
    add(tag: Special.SpecialHandlerTag, ...id: Special.SpecialHandler[]): Internal.TagWrapper
    remove(tag: Special.SpecialHandlerTag, ...id: Special.SpecialHandler[]): Internal.TagWrapper
    removeAll(tag: Special.SpecialHandlerTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.SpecialHandler[]): Internal.TagWrapper
    }
    class EntityCondition extends Internal.TagEventJS {
    get(id: Special.EntityConditionTag): Internal.TagWrapper
    add(tag: Special.EntityConditionTag, ...id: Special.EntityCondition[]): Internal.TagWrapper
    remove(tag: Special.EntityConditionTag, ...id: Special.EntityCondition[]): Internal.TagWrapper
    removeAll(tag: Special.EntityConditionTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.EntityCondition[]): Internal.TagWrapper
    }
    class DimensionType extends Internal.TagEventJS {
    get(id: Special.DimensionTypeTag): Internal.TagWrapper
    add(tag: Special.DimensionTypeTag, ...id: Special.DimensionType[]): Internal.TagWrapper
    remove(tag: Special.DimensionTypeTag, ...id: Special.DimensionType[]): Internal.TagWrapper
    removeAll(tag: Special.DimensionTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.DimensionType[]): Internal.TagWrapper
    }
    class Contract extends Internal.TagEventJS {
    get(id: Special.ContractTag): Internal.TagWrapper
    add(tag: Special.ContractTag, ...id: Special.Contract[]): Internal.TagWrapper
    remove(tag: Special.ContractTag, ...id: Special.Contract[]): Internal.TagWrapper
    removeAll(tag: Special.ContractTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Contract[]): Internal.TagWrapper
    }
    class ModifierPredicateType extends Internal.TagEventJS {
    get(id: Special.ModifierPredicateTypeTag): Internal.TagWrapper
    add(tag: Special.ModifierPredicateTypeTag, ...id: Special.ModifierPredicateType[]): Internal.TagWrapper
    remove(tag: Special.ModifierPredicateTypeTag, ...id: Special.ModifierPredicateType[]): Internal.TagWrapper
    removeAll(tag: Special.ModifierPredicateTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.ModifierPredicateType[]): Internal.TagWrapper
    }
    class ConfiguredFeature extends Internal.TagEventJS {
    get(id: Special.ConfiguredFeatureTag): Internal.TagWrapper
    add(tag: Special.ConfiguredFeatureTag, ...id: Special.ConfiguredFeature[]): Internal.TagWrapper
    remove(tag: Special.ConfiguredFeatureTag, ...id: Special.ConfiguredFeature[]): Internal.TagWrapper
    removeAll(tag: Special.ConfiguredFeatureTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.ConfiguredFeature[]): Internal.TagWrapper
    }
    class GameEvent extends Internal.TagEventJS {
    get(id: Special.GameEventTag): Internal.TagWrapper
    add(tag: Special.GameEventTag, ...id: Special.GameEvent[]): Internal.TagWrapper
    remove(tag: Special.GameEventTag, ...id: Special.GameEvent[]): Internal.TagWrapper
    removeAll(tag: Special.GameEventTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.GameEvent[]): Internal.TagWrapper
    }
    class Noise extends Internal.TagEventJS {
    get(id: Special.NoiseTag): Internal.TagWrapper
    add(tag: Special.NoiseTag, ...id: Special.Noise[]): Internal.TagWrapper
    remove(tag: Special.NoiseTag, ...id: Special.Noise[]): Internal.TagWrapper
    removeAll(tag: Special.NoiseTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Noise[]): Internal.TagWrapper
    }
    class Menu extends Internal.TagEventJS {
    get(id: Special.MenuTag): Internal.TagWrapper
    add(tag: Special.MenuTag, ...id: Special.Menu[]): Internal.TagWrapper
    remove(tag: Special.MenuTag, ...id: Special.Menu[]): Internal.TagWrapper
    removeAll(tag: Special.MenuTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Menu[]): Internal.TagWrapper
    }
    class VillagerProfession extends Internal.TagEventJS {
    get(id: Special.VillagerProfessionTag): Internal.TagWrapper
    add(tag: Special.VillagerProfessionTag, ...id: Special.VillagerProfession[]): Internal.TagWrapper
    remove(tag: Special.VillagerProfessionTag, ...id: Special.VillagerProfession[]): Internal.TagWrapper
    removeAll(tag: Special.VillagerProfessionTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.VillagerProfession[]): Internal.TagWrapper
    }
    class DensityFunctionType extends Internal.TagEventJS {
    get(id: Special.DensityFunctionTypeTag): Internal.TagWrapper
    add(tag: Special.DensityFunctionTypeTag, ...id: Special.DensityFunctionType[]): Internal.TagWrapper
    remove(tag: Special.DensityFunctionTypeTag, ...id: Special.DensityFunctionType[]): Internal.TagWrapper
    removeAll(tag: Special.DensityFunctionTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.DensityFunctionType[]): Internal.TagWrapper
    }
    class TrimEffects extends Internal.TagEventJS {
    get(id: Special.TrimEffectsTag): Internal.TagWrapper
    add(tag: Special.TrimEffectsTag, ...id: Special.TrimEffects[]): Internal.TagWrapper
    remove(tag: Special.TrimEffectsTag, ...id: Special.TrimEffects[]): Internal.TagWrapper
    removeAll(tag: Special.TrimEffectsTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.TrimEffects[]): Internal.TagWrapper
    }
    class StatType extends Internal.TagEventJS {
    get(id: Special.StatTypeTag): Internal.TagWrapper
    add(tag: Special.StatTypeTag, ...id: Special.StatType[]): Internal.TagWrapper
    remove(tag: Special.StatTypeTag, ...id: Special.StatType[]): Internal.TagWrapper
    removeAll(tag: Special.StatTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.StatType[]): Internal.TagWrapper
    }
    class Enchantment extends Internal.TagEventJS {
    get(id: Special.EnchantmentTag): Internal.TagWrapper
    add(tag: Special.EnchantmentTag, ...id: Special.Enchantment[]): Internal.TagWrapper
    remove(tag: Special.EnchantmentTag, ...id: Special.Enchantment[]): Internal.TagWrapper
    removeAll(tag: Special.EnchantmentTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Enchantment[]): Internal.TagWrapper
    }
    class StructurePlacement extends Internal.TagEventJS {
    get(id: Special.StructurePlacementTag): Internal.TagWrapper
    add(tag: Special.StructurePlacementTag, ...id: Special.StructurePlacement[]): Internal.TagWrapper
    remove(tag: Special.StructurePlacementTag, ...id: Special.StructurePlacement[]): Internal.TagWrapper
    removeAll(tag: Special.StructurePlacementTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.StructurePlacement[]): Internal.TagWrapper
    }
    class ParticleType extends Internal.TagEventJS {
    get(id: Special.ParticleTypeTag): Internal.TagWrapper
    add(tag: Special.ParticleTypeTag, ...id: Special.ParticleType[]): Internal.TagWrapper
    remove(tag: Special.ParticleTypeTag, ...id: Special.ParticleType[]): Internal.TagWrapper
    removeAll(tag: Special.ParticleTypeTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.ParticleType[]): Internal.TagWrapper
    }
    class FrogVariant extends Internal.TagEventJS {
    get(id: Special.FrogVariantTag): Internal.TagWrapper
    add(tag: Special.FrogVariantTag, ...id: Special.FrogVariant[]): Internal.TagWrapper
    remove(tag: Special.FrogVariantTag, ...id: Special.FrogVariant[]): Internal.TagWrapper
    removeAll(tag: Special.FrogVariantTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.FrogVariant[]): Internal.TagWrapper
    }
    class CreativeModeTab extends Internal.TagEventJS {
    get(id: Special.CreativeModeTabTag): Internal.TagWrapper
    add(tag: Special.CreativeModeTabTag, ...id: Special.CreativeModeTab[]): Internal.TagWrapper
    remove(tag: Special.CreativeModeTabTag, ...id: Special.CreativeModeTab[]): Internal.TagWrapper
    removeAll(tag: Special.CreativeModeTabTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.CreativeModeTab[]): Internal.TagWrapper
    }
    class Transformation extends Internal.TagEventJS {
    get(id: Special.TransformationTag): Internal.TagWrapper
    add(tag: Special.TransformationTag, ...id: Special.Transformation[]): Internal.TagWrapper
    remove(tag: Special.TransformationTag, ...id: Special.Transformation[]): Internal.TagWrapper
    removeAll(tag: Special.TransformationTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.Transformation[]): Internal.TagWrapper
    }
    class StructureSet extends Internal.TagEventJS {
    get(id: Special.StructureSetTag): Internal.TagWrapper
    add(tag: Special.StructureSetTag, ...id: Special.StructureSet[]): Internal.TagWrapper
    remove(tag: Special.StructureSetTag, ...id: Special.StructureSet[]): Internal.TagWrapper
    removeAll(tag: Special.StructureSetTag): Internal.TagWrapper
    removeAllTagsFrom(...id: Special.StructureSet[]): Internal.TagWrapper
    }
}